summarize the top 10 Ai and triage medical or healthcare related evaluations including human in the loop practices for being able to evaluate performance metrics of AI along with\n studies of triage that are published acceptance test cases\n for triage accuracy\n and understanding of complex differential diagnosis\n

### 🔎 summarize the top 10 Ai and triage medical or healthcare related evaluations including human in the loop practices for being able to evaluate performance metrics of AI along with\n studies of triage that are published acceptance test cases\n for triage accuracy\n and understanding of complex differential diagnosis\n

 and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind the AI\n and the ability to explain the reasoning behind
# 🩺🔍 Search Results
### 27 Jun 2018 | [A comparative study of artificial intelligence and human doctors for the  purpose of triage and diagnosis](https://arxiv.org/abs/1806.10698) | [⬇️](https://arxiv.org/pdf/1806.10698)
*Salman Razzaki, Adam Baker, Yura Perov, Katherine Middleton, Janie  Baxter, Daniel Mullarkey, Davinder Sangar, Michael Taliercio, Mobasher Butt,  Azeem Majeed, Arnold DoRosario, Megan Mahoney, Saurabh Johri* 

  Online symptom checkers have significant potential to improve patient care,
however their reliability and accuracy remain variable. We hypothesised that an
artificial intelligence (AI) powered triage and diagnostic system would compare
favourably with human doctors with respect to triage and diagnostic accuracy.
We performed a prospective validation study of the accuracy and safety of an AI
powered triage and diagnostic system. Identical cases were evaluated by both an
AI system and human doctors. Differential diagnoses and triage outcomes were
evaluated by an independent judge, who was blinded from knowing the source (AI
system or human doctor) of the outcomes. Independently of these cases,
vignettes from publicly available resources were also assessed to provide a
benchmark to previous studies and the diagnostic component of the MRCGP exam.
Overall we found that the Babylon AI powered Triage and Diagnostic System was
able to identify the condition modelled by a clinical vignette with accuracy
comparable to human doctors (in terms of precision and recall). In addition, we
found that the triage advice recommended by the AI System was, on average,
safer than that of human doctors, when compared to the ranges of acceptable
triage provided by independent expert judges, with only a minimal reduction in
appropriateness.

---------------

### 09 May 2023 | [The Case Records of ChatGPT: Language Models and Complex Clinical  Questions](https://arxiv.org/abs/2305.05609) | [⬇️](https://arxiv.org/pdf/2305.05609)
*Timothy Poterucha, Pierre Elias, Christopher M. Haggerty* 

  Background: Artificial intelligence language models have shown promise in
various applications, including assisting with clinical decision-making as
demonstrated by strong performance of large language models on medical
licensure exams. However, their ability to solve complex, open-ended cases,
which may be representative of clinical practice, remains unexplored. Methods:
In this study, the accuracy of large language AI models GPT4 and GPT3.5 in
diagnosing complex clinical cases was investigated using published Case Records
of the Massachusetts General Hospital. A total of 50 cases requiring a
diagnosis and diagnostic test published from January 1, 2022 to April 16, 2022
were identified. For each case, models were given a prompt requesting the top
three specific diagnoses and associated diagnostic tests, followed by case
text, labs, and figure legends. Model outputs were assessed in comparison to
the final clinical diagnosis and whether the model-predicted test would result
in a correct diagnosis. Results: GPT4 and GPT3.5 accurately provided the
correct diagnosis in 26% and 22% of cases in one attempt, and 46% and 42%
within three attempts, respectively. GPT4 and GPT3.5 provided a correct
essential diagnostic test in 28% and 24% of cases in one attempt, and 44% and
50% within three attempts, respectively. No significant differences were found
between the two models, and multiple trials with identical prompts using the
GPT3.5 model provided similar results. Conclusions: In summary, these models
demonstrate potential usefulness in generating differential diagnoses but
remain limited in their ability to provide a single unifying diagnosis in
complex, open-ended cases. Future research should focus on evaluating model
performance in larger datasets of open-ended clinical challenges and exploring
potential human-AI collaboration strategies to enhance clinical
decision-making.

---------------

### 28 May 2021 | [Can artificial intelligence (AI) be used to accurately detect  tuberculosis (TB) from chest X-rays? An evaluation of five AI products for TB  screening and triaging in a high TB burden setting](https://arxiv.org/abs/2006.05509) | [⬇️](https://arxiv.org/pdf/2006.05509)
*Zhi Zhen Qin, Shahriar Ahmed, Mohammad Shahnewaz Sarker, Kishor Paul,  Ahammad Shafiq Sikder Adel, Tasneem Naheyan, Rachael Barrett, Sayera Banu,  Jacob Creswell* 

  Artificial intelligence (AI) products can be trained to recognize
tuberculosis (TB)-related abnormalities on chest radiographs. Various AI
products are available commercially, yet there is lack of evidence on how their
performance compared with each other and with radiologists. We evaluated five
AI software products for screening and triaging TB using a large dataset that
had not been used to train any commercial AI products. Individuals (>=15 years
old) presenting to three TB screening centers in Dhaka, Bangladesh, were
recruited consecutively. All CXR were read independently by a group of three
Bangladeshi registered radiologists and five commercial AI products: CAD4TB
(v7), InferReadDR (v2), Lunit INSIGHT CXR (v4.9.0), JF CXR-1 (v2), and qXR
(v3). All five AI products significantly outperformed the Bangladeshi
radiologists. The areas under the receiver operating characteristic curve are
qXR: 90.81% (95% CI:90.33-91.29%), CAD4TB: 90.34% (95% CI:89.81-90.87), Lunit
INSIGHT CXR: 88.61% (95% CI:88.03%-89.20%), InferReadDR: 84.90% (95% CI:
84.27-85.54%) and JF CXR-1: 84.89% (95% CI:84.26-85.53%). Only qXR met the TPP
with 74.3% specificity at 90% sensitivity. Five AI algorithms can reduce the
number of Xpert tests required by 50%, while maintaining a sensitivity above
90%. All AI algorithms performed worse among the older age and people with
prior TB history. AI products can be highly accurate and useful screening and
triage tools for TB detection in high burden regions and outperform human
readers.

---------------

### 11 May 2022 | [Performance of a deep learning system for detection of referable  diabetic retinopathy in real clinical settings](https://arxiv.org/abs/2205.05554) | [⬇️](https://arxiv.org/pdf/2205.05554)
*Ver\'onica S\'anchez-Guti\'errez, Paula Hern\'andez-Mart\'inez,  Francisco J. Mu\~noz-Negrete, Jonne Engelberts, Allison M. Luger, Mark J.J.P.  van Grinsven* 

  Background: To determine the ability of a commercially available deep
learning system, RetCAD v.1.3.1 (Thirona, Nijmegen, The Netherlands) for the
automatic detection of referable diabetic retinopathy (DR) on a dataset of
colour fundus images acquired during routine clinical practice in a tertiary
hospital screening program, analyzing the reduction of workload that can be
released incorporating this artificial intelligence-based technology. Methods:
Evaluation of the software was performed on a dataset of 7195 nonmydriatic
fundus images from 6325 eyes of 3189 diabetic patients attending our screening
program between February to December of 2019. The software generated a DR
severity score for each colour fundus image which was combined into an
eye-level score. This score was then compared with a reference standard as set
by a human expert using receiver operating characteristic (ROC) curve analysis.
Results: The artificial intelligence (AI) software achieved an area under the
ROC curve (AUC) value of 0.988 [0.981:0.993] for the detection of referable DR.
At the proposed operating point, the sensitivity of the RetCAD software for DR
is 90.53% and specificity is 97.13%. A workload reduction of 96% could be
achieved at the cost of only 6 false negatives. Conclusions: The AI software
correctly identified the vast majority of referable DR cases, with a workload
reduction of 96% of the cases that would need to be checked, while missing
almost no true cases, so it may therefore be used as an instrument for triage.

---------------

### 18 Feb 2022 | [An Integrated Optimization and Machine Learning Models to Predict the  Admission Status of Emergency Patients](https://arxiv.org/abs/2202.09196) | [⬇️](https://arxiv.org/pdf/2202.09196)
*Abdulaziz Ahmed, Omar Ashour, Haneen Ali, Mohammad Firouz* 

  This work proposes a framework for optimizing machine learning algorithms.
The practicality of the framework is illustrated using an important case study
from the healthcare domain, which is predicting the admission status of
emergency department (ED) patients (e.g., admitted vs. discharged) using
patient data at the time of triage. The proposed framework can mitigate the
crowding problem by proactively planning the patient boarding process. A large
retrospective dataset of patient records is obtained from the electronic health
record database of all ED visits over three years from three major locations of
a healthcare provider in the Midwest of the US. Three machine learning
algorithms are proposed: T-XGB, T-ADAB, and T-MLP. T-XGB integrates extreme
gradient boosting (XGB) and Tabu Search (TS), T-ADAB integrates Adaboost and
TS, and T-MLP integrates multi-layer perceptron (MLP) and TS. The proposed
algorithms are compared with the traditional algorithms: XGB, ADAB, and MLP, in
which their parameters are tunned using grid search. The three proposed
algorithms and the original ones are trained and tested using nine data groups
that are obtained from different feature selection methods. In other words, 54
models are developed. Performance was evaluated using five measures: Area under
the curve (AUC), sensitivity, specificity, F1, and accuracy. The results show
that the newly proposed algorithms resulted in high AUC and outperformed the
traditional algorithms. The T-ADAB performs the best among the newly developed
algorithms. The AUC, sensitivity, specificity, F1, and accuracy of the best
model are 95.4%, 99.3%, 91.4%, 95.2%, 97.2%, respectively.

---------------

### 07 Jan 2022 | [Monitoring Covid-19 on social media using a novel triage and diagnosis  approach](https://arxiv.org/abs/2103.11850) | [⬇️](https://arxiv.org/pdf/2103.11850)
*Abul Hasan, Mark Levene, David Weston, Renate Fromson, Nicolas  Koslover, and Tamara Levene* 

  Objective: This study aims to develop an end-to-end natural language
processing pipeline for triage and diagnosis of COVID-19 from patient-authored
social media posts, in order to provide researchers and public health
practitioners with additional information on the symptoms, severity and
prevalence of the disease rather than to provide an actionable decision at the
individual level. Materials and Methods: The text processing pipeline first
extracts COVID-19 symptoms and related concepts such as severity, duration,
negations, and body parts from patients' posts using conditional random fields.
An unsupervised rule-based algorithm is then applied to establish relations
between concepts in the next step of the pipeline. The extracted concepts and
relations are subsequently used to construct two different vector
representations of each post. These vectors are applied separately to build
support vector machine learning models to triage patients into three categories
and diagnose them for COVID-19. Results: We report that macro- and
micro-averaged F1 scores in the range of 71-96% and 61-87%, respectively, for
the triage and diagnosis of COVID-19, when the models are trained on human
labelled data. Our experimental results indicate that similar performance can
be achieved when the models are trained using predicted labels from concept
extraction and rule-based classifiers, thus yielding end-to-end machine
learning. Also, we highlight important features uncovered by our diagnostic
machine learning models and compare them with the most frequent symptoms
revealed in another COVID-19 dataset. In particular, we found that the most
important features are not always the most frequent ones.

---------------

### 29 Jun 2023 | [Improving Patient Pre-screening for Clinical Trials: Assisting  Physicians with Large Language Models](https://arxiv.org/abs/2304.07396) | [⬇️](https://arxiv.org/pdf/2304.07396)
*Danny M. den Hamer, Perry Schoor, Tobias B. Polak and Daniel Kapitan* 

  Physicians considering clinical trials for their patients are met with the
laborious process of checking many text based eligibility criteria. Large
Language Models (LLMs) have shown to perform well for clinical information
extraction and clinical reasoning, including medical tests, but not yet in
real-world scenarios. This paper investigates the use of InstructGPT to assist
physicians in determining eligibility for clinical trials based on a patient's
summarised medical profile. Using a prompting strategy combining one-shot,
selection-inference and chain-of-thought techniques, we investigate the
performance of LLMs on 10 synthetically created patient profiles. Performance
is evaluated at four levels: ability to identify screenable eligibility
criteria from a trial given a medical profile; ability to classify for each
individual criterion whether the patient qualifies; the overall classification
whether a patient is eligible for a clinical trial and the percentage of
criteria to be screened by physician. We evaluated against 146 clinical trials
and a total of 4,135 eligibility criteria. The LLM was able to correctly
identify the screenability of 72% (2,994/4,135) of the criteria. Additionally,
72% (341/471) of the screenable criteria were evaluated correctly. The
resulting trial level classification as eligible or ineligible resulted in a
recall of 0.5. By leveraging LLMs with a physician-in-the-loop, a recall of 1.0
and precision of 0.71 on clinical trial level can be achieved while reducing
the amount of criteria to be checked by an estimated 90%. LLMs can be used to
assist physicians with pre-screening of patients for clinical trials. By
forcing instruction-tuned LLMs to produce chain-of-thought responses, the
reasoning can be made transparent to and the decision process becomes amenable
by physicians, thereby making such a system feasible for use in real-world
scenarios.

---------------

### 14 Jan 2024 | [Enabling Collaborative Clinical Diagnosis of Infectious Keratitis by  Integrating Expert Knowledge and Interpretable Data-driven Intelligence](https://arxiv.org/abs/2401.08695) | [⬇️](https://arxiv.org/pdf/2401.08695)
*Zhengqing Fang, Shuowen Zhou, Zhouhang Yuan, Yuxuan Si, Mengze Li,  Jinxu Li, Yesheng Xu, Wenjia Xie, Kun Kuang, Yingming Li, Fei Wu, and Yu-Feng  Yao* 

  Although data-driven artificial intelligence (AI) in medical image diagnosis
has shown impressive performance in silico, the lack of interpretability makes
it difficult to incorporate the "black box" into clinicians' workflows. To make
the diagnostic patterns learned from data understandable by clinicians, we
develop an interpretable model, knowledge-guided diagnosis model (KGDM), that
provides a visualized reasoning process containing AI-based biomarkers and
retrieved cases that with the same diagnostic patterns. It embraces clinicians'
prompts into the interpreted reasoning through human-AI interaction, leading to
potentially enhanced safety and more accurate predictions. This study
investigates the performance, interpretability, and clinical utility of KGDM in
the diagnosis of infectious keratitis (IK), which is the leading cause of
corneal blindness. The classification performance of KGDM is evaluated on a
prospective validation dataset, an external testing dataset, and an publicly
available testing dataset. The diagnostic odds ratios (DOR) of the interpreted
AI-based biomarkers are effective, ranging from 3.011 to 35.233 and exhibit
consistent diagnostic patterns with clinic experience. Moreover, a human-AI
collaborative diagnosis test is conducted and the participants with
collaboration achieved a performance exceeding that of both humans and AI. By
synergistically integrating interpretability and interaction, this study
facilitates the convergence of clinicians' expertise and data-driven
intelligence. The promotion of inexperienced ophthalmologists with the aid of
AI-based biomarkers, as well as increased AI prediction by intervention from
experienced ones, demonstrate a promising diagnostic paradigm for infectious
keratitis using KGDM, which holds the potential for extension to other diseases
where experienced medical practitioners are limited and the safety of AI is
concerned.

---------------

### 28 Jun 2021 | [Using machine learning techniques to predict hospital admission at the  emergency department](https://arxiv.org/abs/2106.12921) | [⬇️](https://arxiv.org/pdf/2106.12921)
*Georgios Feretzakis, George Karlis, Evangelos Loupelis, Dimitris  Kalles, Rea Chatzikyriakou, Nikolaos Trakas, Eugenia Karakou, Aikaterini  Sakagianni, Lazaros Tzelves, Stavroula Petropoulou, Aikaterini Tika, Ilias  Dalainas and Vasileios Kaldis* 

  Introduction: One of the most important tasks in the Emergency Department
(ED) is to promptly identify the patients who will benefit from hospital
admission. Machine Learning (ML) techniques show promise as diagnostic aids in
healthcare. Material and methods: We investigated the following features
seeking to investigate their performance in predicting hospital admission:
serum levels of Urea, Creatinine, Lactate Dehydrogenase, Creatine Kinase,
C-Reactive Protein, Complete Blood Count with differential, Activated Partial
Thromboplastin Time, D Dimer, International Normalized Ratio, age, gender,
triage disposition to ED unit and ambulance utilization. A total of 3,204 ED
visits were analyzed. Results: The proposed algorithms generated models which
demonstrated acceptable performance in predicting hospital admission of ED
patients. The range of F-measure and ROC Area values of all eight evaluated
algorithms were [0.679-0.708] and [0.734-0.774], respectively. Discussion: The
main advantages of this tool include easy access, availability, yes/no result,
and low cost. The clinical implications of our approach might facilitate a
shift from traditional clinical decision-making to a more sophisticated model.
Conclusion: Developing robust prognostic models with the utilization of common
biomarkers is a project that might shape the future of emergency medicine. Our
findings warrant confirmation with implementation in pragmatic ED trials.

---------------

### 13 Sep 2018 | [Focus Group on Artificial Intelligence for Health](https://arxiv.org/abs/1809.04797) | [⬇️](https://arxiv.org/pdf/1809.04797)
*Marcel Salath\'e, Thomas Wiegand, Markus Wenzel* 

  Artificial Intelligence (AI) - the phenomenon of machines being able to solve
problems that require human intelligence - has in the past decade seen an
enormous rise of interest due to significant advances in effectiveness and use.
The health sector, one of the most important sectors for societies and
economies worldwide, is particularly interesting for AI applications, given the
ongoing digitalisation of all types of health information. The potential for AI
assistance in the health domain is immense, because AI can support medical
decision making at reduced costs, everywhere. However, due to the complexity of
AI algorithms, it is difficult to distinguish good from bad AI-based solutions
and to understand their strengths and weaknesses, which is crucial for
clarifying responsibilities and for building trust. For this reason, the
International Telecommunication Union (ITU) has established a new Focus Group
on "Artificial Intelligence for Health" (FG-AI4H) in partnership with the World
Health Organization (WHO). Health and care services are usually the
responsibility of a government - even when provided through private insurance
systems - and thus under the responsibility of WHO/ITU member states. FG-AI4H
will identify opportunities for international standardization, which will
foster the application of AI to health issues on a global scale. In particular,
it will establish a standardized assessment framework with open benchmarks for
the evaluation of AI-based methods for health, such as AI-based diagnosis,
triage or treatment decisions.

---------------

### 31 Aug 2022 | [Robustness of an Artificial Intelligence Solution for Diagnosis of  Normal Chest X-Rays](https://arxiv.org/abs/2209.09204) | [⬇️](https://arxiv.org/pdf/2209.09204)
*Tom Dyer, Jordan Smith, Gaetan Dissez, Nicole Tay, Qaiser Malik, Tom  Naunton Morgan, Paul Williams, Liliana Garcia-Mondragon, George Pearse, and  Simon Rasalingham* 

  Purpose: Artificial intelligence (AI) solutions for medical diagnosis require
thorough evaluation to demonstrate that performance is maintained for all
patient sub-groups and to ensure that proposed improvements in care will be
delivered equitably. This study evaluates the robustness of an AI solution for
the diagnosis of normal chest X-rays (CXRs) by comparing performance across
multiple patient and environmental subgroups, as well as comparing AI errors
with those made by human experts.
  Methods: A total of 4,060 CXRs were sampled to represent a diverse dataset of
NHS patients and care settings. Ground-truth labels were assigned by a
3-radiologist panel. AI performance was evaluated against assigned labels and
sub-groups analysis was conducted against patient age and sex, as well as CXR
view, modality, device manufacturer and hospital site.
  Results: The AI solution was able to remove 18.5% of the dataset by
classification as High Confidence Normal (HCN). This was associated with a
negative predictive value (NPV) of 96.0%, compared to 89.1% for diagnosis of
normal scans by radiologists. In all AI false negative (FN) cases, a
radiologist was found to have also made the same error when compared to final
ground-truth labels. Subgroup analysis showed no statistically significant
variations in AI performance, whilst reduced normal classification was observed
in data from some hospital sites.
  Conclusion: We show the AI solution could provide meaningful workload savings
by diagnosis of 18.5% of scans as HCN with a superior NPV to human readers. The
AI solution is shown to perform well across patient subgroups and error cases
were shown to be subjective or subtle in nature.

---------------

### 11 Dec 2023 | [The Limits of Fair Medical Imaging AI In The Wild](https://arxiv.org/abs/2312.10083) | [⬇️](https://arxiv.org/pdf/2312.10083)
*Yuzhe Yang, Haoran Zhang, Judy W Gichoya, Dina Katabi, Marzyeh  Ghassemi* 

  As artificial intelligence (AI) rapidly approaches human-level performance in
medical imaging, it is crucial that it does not exacerbate or propagate
healthcare disparities. Prior research has established AI's capacity to infer
demographic data from chest X-rays, leading to a key concern: do models using
demographic shortcuts have unfair predictions across subpopulations? In this
study, we conduct a thorough investigation into the extent to which medical AI
utilizes demographic encodings, focusing on potential fairness discrepancies
within both in-distribution training sets and external test sets. Our analysis
covers three key medical imaging disciplines: radiology, dermatology, and
ophthalmology, and incorporates data from six global chest X-ray datasets. We
confirm that medical imaging AI leverages demographic shortcuts in disease
classification. While correcting shortcuts algorithmically effectively
addresses fairness gaps to create "locally optimal" models within the original
data distribution, this optimality is not true in new test settings.
Surprisingly, we find that models with less encoding of demographic attributes
are often most "globally optimal", exhibiting better fairness during model
evaluation in new test environments. Our work establishes best practices for
medical imaging models which maintain their performance and fairness in
deployments beyond their initial training contexts, underscoring critical
considerations for AI clinical deployments across populations and sites.

---------------

### 04 Sep 2020 | [A New Screening Method for COVID-19 based on Ocular Feature Recognition  by Machine Learning Tools](https://arxiv.org/abs/2009.03184) | [⬇️](https://arxiv.org/pdf/2009.03184)
*Yanwei Fu, Feng Li, Wenxuan Wang, Haicheng Tang, Xuelin Qian, Mengwei  Gu, Xiangyang Xue* 

  The Coronavirus disease 2019 (COVID-19) has affected several million people.
With the outbreak of the epidemic, many researchers are devoting themselves to
the COVID-19 screening system. The standard practices for rapid risk screening
of COVID-19 are the CT imaging or RT-PCR (real-time polymerase chain reaction).
However, these methods demand professional efforts of the acquisition of CT
images and saliva samples, a certain amount of waiting time, and most
importantly prohibitive examination fee in some countries. Recently, some
literatures have shown that the COVID-19 patients usually accompanied by ocular
manifestations consistent with the conjunctivitis, including conjunctival
hyperemia, chemosis, epiphora, or increased secretions. After more than four
months study, we found that the confirmed cases of COVID-19 present the
consistent ocular pathological symbols; and we propose a new screening method
of analyzing the eye-region images, captured by common CCD and CMOS cameras,
could reliably make a rapid risk screening of COVID-19 with very high accuracy.
We believe a system implementing such an algorithm should assist the triage
management or the clinical diagnosis. To further evaluate our algorithm and
approved by the Ethics Committee of Shanghai public health clinic center of
Fudan University, we conduct a study of analyzing the eye-region images of 303
patients (104 COVID-19, 131 pulmonary, and 68 ocular patients), as well as 136
healthy people. Remarkably, our results of COVID-19 patients in testing set
consistently present similar ocular pathological symbols; and very high testing
results have been achieved in terms of sensitivity and specificity. We hope
this study can be inspiring and helpful for encouraging more researches in this
topic.

---------------

### 21 Feb 2024 | [ED-Copilot: Reduce Emergency Department Wait Time with Language Model  Diagnostic Assistance](https://arxiv.org/abs/2402.13448) | [⬇️](https://arxiv.org/pdf/2402.13448)
*Liwen Sun, Abhineet Agarwal, Aaron Kornblith, Bin Yu, Chenyan Xiong* 

  In the emergency department (ED), patients undergo triage and multiple
laboratory tests before diagnosis. This process is time-consuming, and causes
ED crowding which significantly impacts patient mortality, medical errors,
staff burnout, etc. This work proposes (time) cost-effective diagnostic
assistance that explores the potential of artificial intelligence (AI) systems
in assisting ED clinicians to make time-efficient and accurate diagnoses. Using
publicly available patient data, we collaborate with ED clinicians to curate
MIMIC-ED-Assist, a benchmark that measures the ability of AI systems in
suggesting laboratory tests that minimize ED wait times, while correctly
predicting critical outcomes such as death. We develop ED-Copilot which
sequentially suggests patient-specific laboratory tests and makes diagnostic
predictions. ED-Copilot uses a pre-trained bio-medical language model to encode
patient information and reinforcement learning to minimize ED wait time and
maximize prediction accuracy of critical outcomes. On MIMIC-ED-Assist,
ED-Copilot improves prediction accuracy over baselines while halving average
wait time from four hours to two hours. Ablation studies demonstrate the
importance of model scale and use of a bio-medical language model. Further
analyses reveal the necessity of personalized laboratory test suggestions for
diagnosing patients with severe cases, as well as the potential of ED-Copilot
in providing ED clinicians with informative laboratory test recommendations.
Our code is available at https://github.com/cxcscmu/ED-Copilot.

---------------

### 13 Jun 2022 | [SyntheX: Scaling Up Learning-based X-ray Image Analysis Through In  Silico Experiments](https://arxiv.org/abs/2206.06127) | [⬇️](https://arxiv.org/pdf/2206.06127)
*Cong Gao, Benjamin D. Killeen, Yicheng Hu, Robert B. Grupp, Russell H.  Taylor, Mehran Armand, Mathias Unberath* 

  Artificial intelligence (AI) now enables automated interpretation of medical
images for clinical use. However, AI's potential use for interventional images
(versus those involved in triage or diagnosis), such as for guidance during
surgery, remains largely untapped. This is because surgical AI systems are
currently trained using post hoc analysis of data collected during live
surgeries, which has fundamental and practical limitations, including ethical
considerations, expense, scalability, data integrity, and a lack of ground
truth. Here, we demonstrate that creating realistic simulated images from human
models is a viable alternative and complement to large-scale in situ data
collection. We show that training AI image analysis models on realistically
synthesized data, combined with contemporary domain generalization or
adaptation techniques, results in models that on real data perform comparably
to models trained on a precisely matched real data training set. Because
synthetic generation of training data from human-based models scales easily, we
find that our model transfer paradigm for X-ray image analysis, which we refer
to as SyntheX, can even outperform real data-trained models due to the
effectiveness of training on a larger dataset. We demonstrate the potential of
SyntheX on three clinical tasks: Hip image analysis, surgical robotic tool
detection, and COVID-19 lung lesion segmentation. SyntheX provides an
opportunity to drastically accelerate the conception, design, and evaluation of
intelligent systems for X-ray-based medicine. In addition, simulated image
environments provide the opportunity to test novel instrumentation, design
complementary surgical approaches, and envision novel techniques that improve
outcomes, save time, or mitigate human error, freed from the ethical and
practical considerations of live human data collection.

---------------

### 12 May 2022 | [Benchmark datasets driving artificial intelligence development fail to  capture the needs of medical professionals](https://arxiv.org/abs/2201.07040) | [⬇️](https://arxiv.org/pdf/2201.07040)
*Kathrin Blagec, Jakob Kraiger, Wolfgang Fr\"uhwirt, Matthias Samwald* 

  Publicly accessible benchmarks that allow for assessing and comparing model
performances are important drivers of progress in artificial intelligence (AI).
While recent advances in AI capabilities hold the potential to transform
medical practice by assisting and augmenting the cognitive processes of
healthcare professionals, the coverage of clinically relevant tasks by AI
benchmarks is largely unclear. Furthermore, there is a lack of systematized
meta-information that allows clinical AI researchers to quickly determine
accessibility, scope, content and other characteristics of datasets and
benchmark datasets relevant to the clinical domain.
  To address these issues, we curated and released a comprehensive catalogue of
datasets and benchmarks pertaining to the broad domain of clinical and
biomedical natural language processing (NLP), based on a systematic review of
literature and online resources. A total of 450 NLP datasets were manually
systematized and annotated with rich metadata, such as targeted tasks, clinical
applicability, data types, performance metrics, accessibility and licensing
information, and availability of data splits. We then compared tasks covered by
AI benchmark datasets with relevant tasks that medical practitioners reported
as highly desirable targets for automation in a previous empirical study.
  Our analysis indicates that AI benchmarks of direct clinical relevance are
scarce and fail to cover most work activities that clinicians want to see
addressed. In particular, tasks associated with routine documentation and
patient data administration workflows are not represented despite significant
associated workloads. Thus, currently available AI benchmarks are improperly
aligned with desired targets for AI automation in clinical settings, and novel
benchmarks should be created to fill these gaps.

---------------

### 26 Jan 2024 | [Enhancing Diagnostic Accuracy through Multi-Agent Conversations: Using  Large Language Models to Mitigate Cognitive Bias](https://arxiv.org/abs/2401.14589) | [⬇️](https://arxiv.org/pdf/2401.14589)
*Yu He Ke, Rui Yang, Sui An Lie, Taylor Xin Yi Lim, Hairil Rizal  Abdullah, Daniel Shu Wei Ting, Nan Liu* 

  Background: Cognitive biases in clinical decision-making significantly
contribute to errors in diagnosis and suboptimal patient outcomes. Addressing
these biases presents a formidable challenge in the medical field. This study
explores the role of large language models (LLMs) in mitigating these biases
through the utilization of a multi-agent framework. We simulate the clinical
decision-making processes through multi-agent conversation and evaluate its
efficacy in improving diagnostic accuracy. Methods: A total of 16 published and
unpublished case reports where cognitive biases have resulted in misdiagnoses
were identified from the literature. In the multi-agent system, we leveraged
GPT-4 Turbo to facilitate interactions among four simulated agents to replicate
clinical team dynamics. Each agent has a distinct role: 1) To make the initial
and final diagnosis after considering the discussions, 2) The devil's advocate
and correct confirmation and anchoring bias, 3) The tutor and facilitator of
the discussion to reduce premature closure bias, and 4) To record and summarize
the findings. A total of 80 simulations were evaluated for the accuracy of
initial diagnosis, top differential diagnosis and final two differential
diagnoses. Findings: In a total of 80 responses evaluating both initial and
final diagnoses, the initial diagnosis had an accuracy of 0% (0/80), but
following multi-agent discussions, the accuracy for the top differential
diagnosis increased to 71.3% (57/80), and for the final two differential
diagnoses, to 80.0% (64/80). The system demonstrated an ability to reevaluate
and correct misconceptions, even in scenarios with misleading initial
investigations. Interpretation: The LLM-driven multi-agent conversation system
shows promise in enhancing diagnostic accuracy in diagnostically challenging
medical scenarios.

---------------

### 16 May 2023 | [Towards Expert-Level Medical Question Answering with Large Language  Models](https://arxiv.org/abs/2305.09617) | [⬇️](https://arxiv.org/pdf/2305.09617)
*Karan Singhal, Tao Tu, Juraj Gottweis, Rory Sayres, Ellery Wulczyn, Le  Hou, Kevin Clark, Stephen Pfohl, Heather Cole-Lewis, Darlene Neal, Mike  Schaekermann, Amy Wang, Mohamed Amin, Sami Lachgar, Philip Mansfield, Sushant  Prakash, Bradley Green, Ewa Dominowska, Blaise Aguera y Arcas, Nenad Tomasev,  Yun Liu, Renee Wong, Christopher Semturs, S. Sara Mahdavi, Joelle Barral,  Dale Webster, Greg S. Corrado, Yossi Matias, Shekoofeh Azizi, Alan  Karthikesalingam, Vivek Natarajan* 

  Recent artificial intelligence (AI) systems have reached milestones in "grand
challenges" ranging from Go to protein-folding. The capability to retrieve
medical knowledge, reason over it, and answer medical questions comparably to
physicians has long been viewed as one such grand challenge.
  Large language models (LLMs) have catalyzed significant progress in medical
question answering; Med-PaLM was the first model to exceed a "passing" score in
US Medical Licensing Examination (USMLE) style questions with a score of 67.2%
on the MedQA dataset. However, this and other prior work suggested significant
room for improvement, especially when models' answers were compared to
clinicians' answers. Here we present Med-PaLM 2, which bridges these gaps by
leveraging a combination of base LLM improvements (PaLM 2), medical domain
finetuning, and prompting strategies including a novel ensemble refinement
approach.
  Med-PaLM 2 scored up to 86.5% on the MedQA dataset, improving upon Med-PaLM
by over 19% and setting a new state-of-the-art. We also observed performance
approaching or exceeding state-of-the-art across MedMCQA, PubMedQA, and MMLU
clinical topics datasets.
  We performed detailed human evaluations on long-form questions along multiple
axes relevant to clinical applications. In pairwise comparative ranking of 1066
consumer medical questions, physicians preferred Med-PaLM 2 answers to those
produced by physicians on eight of nine axes pertaining to clinical utility (p
< 0.001). We also observed significant improvements compared to Med-PaLM on
every evaluation axis (p < 0.001) on newly introduced datasets of 240 long-form
"adversarial" questions to probe LLM limitations.
  While further studies are necessary to validate the efficacy of these models
in real-world settings, these results highlight rapid progress towards
physician-level performance in medical question answering.

---------------

### 13 Feb 2024 | [Leveraging cough sounds to optimize chest x-ray usage in low-resource  settings](https://arxiv.org/abs/2402.08789) | [⬇️](https://arxiv.org/pdf/2402.08789)
*Alexander Philip, Sanya Chawla, Lola Jover, George P. Kafentzis, Joe  Brew, Vishakh Saraf, Shibu Vijayan, Peter Small, Carlos Chaccour* 

  Chest X-ray is a commonly used tool during triage, diagnosis and management
of respiratory diseases. In resource-constricted settings, optimizing this
resource can lead to valuable cost savings for the health care system and the
patients as well as to and improvement in consult time. We used
prospectively-collected data from 137 patients referred for chest X-ray at the
Christian Medical Center and Hospital (CMCH) in Purnia, Bihar, India. Each
patient provided at least five coughs while awaiting radiography. Collected
cough sounds were analyzed using acoustic AI methods. Cross-validation was done
on temporal and spectral features on the cough sounds of each patient. Features
were summarized using standard statistical approaches. Three models were
developed, tested and compared in their capacity to predict an abnormal result
in the chest X-ray. All three methods yielded models that could discriminate to
some extent between normal and abnormal with the logistic regression performing
best with an area under the receiver operating characteristic curves ranging
from 0.7 to 0.78. Despite limitations and its relatively small sample size,
this study shows that AI-enabled algorithms can use cough sounds to predict
which individuals presenting for chest radiographic examination will have a
normal or abnormal results. These results call for expanding this research
given the potential optimization of limited health care resources in low- and
middle-income countries.

---------------

### 22 Oct 2019 | [Who wants accurate models? Arguing for a different metrics to take  classification models seriously](https://arxiv.org/abs/1910.09246) | [⬇️](https://arxiv.org/pdf/1910.09246)
*Federico Cabitza and Andrea Campagner* 

  With the increasing availability of AI-based decision support, there is an
increasing need for their certification by both AI manufacturers and notified
bodies, as well as the pragmatic (real-world) validation of these systems.
Therefore, there is the need for meaningful and informative ways to assess the
performance of AI systems in clinical practice. Common metrics (like accuracy
scores and areas under the ROC curve) have known problems and they do not take
into account important information about the preferences of clinicians and the
needs of their specialist practice, like the likelihood and impact of errors
and the complexity of cases. In this paper, we present a new accuracy measure,
the H-accuracy (Ha), which we claim is more informative in the medical domain
(and others of similar needs) for the elements it encompasses. We also provide
proof that the H-accuracy is a generalization of the balanced accuracy and
establish a relation between the H-accuracy and the Net Benefit. Finally, we
illustrate an experimentation in two user studies to show the descriptive power
of the Ha score and how complementary and differently informative measures can
be derived from its formulation (a Python script to compute Ha is also made
available).

---------------
**Date:** 27 Jun 2018

**Title:** A comparative study of artificial intelligence and human doctors for the  purpose of triage and diagnosis

**Abstract Link:** [https://arxiv.org/abs/1806.10698](https://arxiv.org/abs/1806.10698)

**PDF Link:** [https://arxiv.org/pdf/1806.10698](https://arxiv.org/pdf/1806.10698)

---

**Date:** 09 May 2023

**Title:** The Case Records of ChatGPT: Language Models and Complex Clinical  Questions

**Abstract Link:** [https://arxiv.org/abs/2305.05609](https://arxiv.org/abs/2305.05609)

**PDF Link:** [https://arxiv.org/pdf/2305.05609](https://arxiv.org/pdf/2305.05609)

---

**Date:** 28 May 2021

**Title:** Can artificial intelligence (AI) be used to accurately detect  tuberculosis (TB) from chest X-rays? An evaluation of five AI products for TB  screening and triaging in a high TB burden setting

**Abstract Link:** [https://arxiv.org/abs/2006.05509](https://arxiv.org/abs/2006.05509)

**PDF Link:** [https://arxiv.org/pdf/2006.05509](https://arxiv.org/pdf/2006.05509)

---

**Date:** 11 May 2022

**Title:** Performance of a deep learning system for detection of referable  diabetic retinopathy in real clinical settings

**Abstract Link:** [https://arxiv.org/abs/2205.05554](https://arxiv.org/abs/2205.05554)

**PDF Link:** [https://arxiv.org/pdf/2205.05554](https://arxiv.org/pdf/2205.05554)

---

**Date:** 18 Feb 2022

**Title:** An Integrated Optimization and Machine Learning Models to Predict the  Admission Status of Emergency Patients

**Abstract Link:** [https://arxiv.org/abs/2202.09196](https://arxiv.org/abs/2202.09196)

**PDF Link:** [https://arxiv.org/pdf/2202.09196](https://arxiv.org/pdf/2202.09196)

---

**Date:** 07 Jan 2022

**Title:** Monitoring Covid-19 on social media using a novel triage and diagnosis  approach

**Abstract Link:** [https://arxiv.org/abs/2103.11850](https://arxiv.org/abs/2103.11850)

**PDF Link:** [https://arxiv.org/pdf/2103.11850](https://arxiv.org/pdf/2103.11850)

---

**Date:** 29 Jun 2023

**Title:** Improving Patient Pre-screening for Clinical Trials: Assisting  Physicians with Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2304.07396](https://arxiv.org/abs/2304.07396)

**PDF Link:** [https://arxiv.org/pdf/2304.07396](https://arxiv.org/pdf/2304.07396)

---

**Date:** 14 Jan 2024

**Title:** Enabling Collaborative Clinical Diagnosis of Infectious Keratitis by  Integrating Expert Knowledge and Interpretable Data-driven Intelligence

**Abstract Link:** [https://arxiv.org/abs/2401.08695](https://arxiv.org/abs/2401.08695)

**PDF Link:** [https://arxiv.org/pdf/2401.08695](https://arxiv.org/pdf/2401.08695)

---

**Date:** 28 Jun 2021

**Title:** Using machine learning techniques to predict hospital admission at the  emergency department

**Abstract Link:** [https://arxiv.org/abs/2106.12921](https://arxiv.org/abs/2106.12921)

**PDF Link:** [https://arxiv.org/pdf/2106.12921](https://arxiv.org/pdf/2106.12921)

---

**Date:** 13 Sep 2018

**Title:** Focus Group on Artificial Intelligence for Health

**Abstract Link:** [https://arxiv.org/abs/1809.04797](https://arxiv.org/abs/1809.04797)

**PDF Link:** [https://arxiv.org/pdf/1809.04797](https://arxiv.org/pdf/1809.04797)

---

**Date:** 31 Aug 2022

**Title:** Robustness of an Artificial Intelligence Solution for Diagnosis of  Normal Chest X-Rays

**Abstract Link:** [https://arxiv.org/abs/2209.09204](https://arxiv.org/abs/2209.09204)

**PDF Link:** [https://arxiv.org/pdf/2209.09204](https://arxiv.org/pdf/2209.09204)

---

**Date:** 11 Dec 2023

**Title:** The Limits of Fair Medical Imaging AI In The Wild

**Abstract Link:** [https://arxiv.org/abs/2312.10083](https://arxiv.org/abs/2312.10083)

**PDF Link:** [https://arxiv.org/pdf/2312.10083](https://arxiv.org/pdf/2312.10083)

---

**Date:** 04 Sep 2020

**Title:** A New Screening Method for COVID-19 based on Ocular Feature Recognition  by Machine Learning Tools

**Abstract Link:** [https://arxiv.org/abs/2009.03184](https://arxiv.org/abs/2009.03184)

**PDF Link:** [https://arxiv.org/pdf/2009.03184](https://arxiv.org/pdf/2009.03184)

---

**Date:** 21 Feb 2024

**Title:** ED-Copilot: Reduce Emergency Department Wait Time with Language Model  Diagnostic Assistance

**Abstract Link:** [https://arxiv.org/abs/2402.13448](https://arxiv.org/abs/2402.13448)

**PDF Link:** [https://arxiv.org/pdf/2402.13448](https://arxiv.org/pdf/2402.13448)

---

**Date:** 13 Jun 2022

**Title:** SyntheX: Scaling Up Learning-based X-ray Image Analysis Through In  Silico Experiments

**Abstract Link:** [https://arxiv.org/abs/2206.06127](https://arxiv.org/abs/2206.06127)

**PDF Link:** [https://arxiv.org/pdf/2206.06127](https://arxiv.org/pdf/2206.06127)

---

**Date:** 12 May 2022

**Title:** Benchmark datasets driving artificial intelligence development fail to  capture the needs of medical professionals

**Abstract Link:** [https://arxiv.org/abs/2201.07040](https://arxiv.org/abs/2201.07040)

**PDF Link:** [https://arxiv.org/pdf/2201.07040](https://arxiv.org/pdf/2201.07040)

---

**Date:** 26 Jan 2024

**Title:** Enhancing Diagnostic Accuracy through Multi-Agent Conversations: Using  Large Language Models to Mitigate Cognitive Bias

**Abstract Link:** [https://arxiv.org/abs/2401.14589](https://arxiv.org/abs/2401.14589)

**PDF Link:** [https://arxiv.org/pdf/2401.14589](https://arxiv.org/pdf/2401.14589)

---

**Date:** 16 May 2023

**Title:** Towards Expert-Level Medical Question Answering with Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2305.09617](https://arxiv.org/abs/2305.09617)

**PDF Link:** [https://arxiv.org/pdf/2305.09617](https://arxiv.org/pdf/2305.09617)

---

**Date:** 13 Feb 2024

**Title:** Leveraging cough sounds to optimize chest x-ray usage in low-resource  settings

**Abstract Link:** [https://arxiv.org/abs/2402.08789](https://arxiv.org/abs/2402.08789)

**PDF Link:** [https://arxiv.org/pdf/2402.08789](https://arxiv.org/pdf/2402.08789)

---

**Date:** 22 Oct 2019

**Title:** Who wants accurate models? Arguing for a different metrics to take  classification models seriously

**Abstract Link:** [https://arxiv.org/abs/1910.09246](https://arxiv.org/abs/1910.09246)

**PDF Link:** [https://arxiv.org/pdf/1910.09246](https://arxiv.org/pdf/1910.09246)

---

