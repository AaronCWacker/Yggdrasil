in ai-led medical interviews we collect initial evidence such as symptoms risk factors pre-existing conditions I existing provider details and then also patient demographic data\n with intelligent interviews and drawing conclusions to be able to make triage recommendations we require that we have human in the loop testing and also evaluation of the accuracy of differential diagnosis outcomes along with patient education information what is the state of the art of understanding the performance metrics the bias and fairness and also AI safety testing to be able to do this accurately and in an environment with clinical reviews with medical professionals being able to evaluate and provide feedback on conditions symptoms risk factors and the outcome data\n

### 🔎 in ai-led medical interviews we collect initial evidence such as symptoms risk factors pre-existing conditions I existing provider details and then also patient demographic data\n with intelligent interviews and drawing conclusions to be able to make triage recommendations we require that we have human in the loop testing and also evaluation of the accuracy of differential diagnosis outcomes along with patient education information what is the state of the art of understanding the performance metrics the bias and fairness and also AI safety testing to be able to do this accurately and in an environment with clinical reviews with medical professionals being able to evaluate and provide feedback on conditions symptoms risk factors and the outcome data\n

 what are the best practices for AI safety testing and evaluation of AI models in the medical domain?

The state of the art in understanding the performance metrics, bias, fairness, and AI safety testing in the medical domain is still evolving. However, there are some best practices that can be followed to ensure the safe and effective use of AI in medical interviews and diagnosis.

1. Human-in-the-loop testing: It is important to have human experts in the loop during the development and testing of AI models for medical interviews. This can help ensure that the AI model is making accurate and safe recommendations, and can also help identify any potential biases or errors in the model.
2. Accuracy and precision: The accuracy and precision of the AI model should be evaluated using appropriate metrics, such as sensitivity, specificity, and positive predictive value. These metrics should be calculated using a diverse and representative dataset to ensure that the model performs well across different populations.
3. Bias and fairness: Bias and fairness should be evaluated by testing the AI model on a diverse and representative dataset. It is important to ensure that the model does not discriminate against certain groups or populations, and that it performs equally well across different demographics.
4. Explainability: The AI model should be explainable, meaning that it should be possible to understand how the model is making its recommendations. This is important for building trust with patients and healthcare providers, and for ensuring that the model is making safe and appropriate recommendations.
5. Clinical reviews: The AI model should be reviewed by medical professionals to ensure that the recommendations are clinically sound and safe. This can help identify any potential issues or concerns with the model, and can also provide valuable feedback for improving the model.
6. Patient education: It is important to provide patients with education and resources to help them understand their condition and treatment options. This can help ensure that patients are informed and empowered to make decisions about their healthcare.
7. Continuous monitoring: The AI model should be continuously monitored and evaluated to ensure that it is performing accurately and safely. This can help identify any potential issues or concerns, and can also provide valuable feedback for improving the model.

Overall, the safe and effective use of AI in medical interviews and diagnosis requires a multifaceted approach that includes human-in-the-loop testing, accuracy and precision evaluation, bias and fairness assessment, explainability, clinical reviews
# 🩺🔍 Search Results
### 18 Jan 2022 | [Label-dependent and event-guided interpretable disease risk prediction  using EHRs](https://arxiv.org/abs/2201.06783) | [⬇️](https://arxiv.org/pdf/2201.06783)
*Shuai Niu and Yunya Song and Qing Yin and Yike Guo and Xian Yang* 

  Electronic health records (EHRs) contain patients' heterogeneous data that
are collected from medical providers involved in the patient's care, including
medical notes, clinical events, laboratory test results, symptoms, and
diagnoses. In the field of modern healthcare, predicting whether patients would
experience any risks based on their EHRs has emerged as a promising research
area, in which artificial intelligence (AI) plays a key role. To make AI models
practically applicable, it is required that the prediction results should be
both accurate and interpretable. To achieve this goal, this paper proposed a
label-dependent and event-guided risk prediction model (LERP) to predict the
presence of multiple disease risks by mainly extracting information from
unstructured medical notes. Our model is featured in the following aspects.
First, we adopt a label-dependent mechanism that gives greater attention to
words from medical notes that are semantically similar to the names of risk
labels. Secondly, as the clinical events (e.g., treatments and drugs) can also
indicate the health status of patients, our model utilizes the information from
events and uses them to generate an event-guided representation of medical
notes. Thirdly, both label-dependent and event-guided representations are
integrated to make a robust prediction, in which the interpretability is
enabled by the attention weights over words from medical notes. To demonstrate
the applicability of the proposed method, we apply it to the MIMIC-III dataset,
which contains real-world EHRs collected from hospitals. Our method is
evaluated in both quantitative and qualitative ways.

---------------

### 11 Feb 2023 | [Informing clinical assessment by contextualizing post-hoc explanations  of risk prediction models in type-2 diabetes](https://arxiv.org/abs/2302.05752) | [⬇️](https://arxiv.org/pdf/2302.05752)
*Shruthi Chari, Prasant Acharya, Daniel M. Gruen, Olivia Zhang, Elif K.  Eyigoz, Mohamed Ghalwash, Oshani Seneviratne, Fernando Suarez Saiz, Pablo  Meyer, Prithwish Chakraborty, Deborah L. McGuinness* 

  Medical experts may use Artificial Intelligence (AI) systems with greater
trust if these are supported by contextual explanations that let the
practitioner connect system inferences to their context of use. However, their
importance in improving model usage and understanding has not been extensively
studied. Hence, we consider a comorbidity risk prediction scenario and focus on
contexts regarding the patients clinical state, AI predictions about their risk
of complications, and algorithmic explanations supporting the predictions. We
explore how relevant information for such dimensions can be extracted from
Medical guidelines to answer typical questions from clinical practitioners. We
identify this as a question answering (QA) task and employ several
state-of-the-art LLMs to present contexts around risk prediction model
inferences and evaluate their acceptability. Finally, we study the benefits of
contextual explanations by building an end-to-end AI pipeline including data
cohorting, AI risk modeling, post-hoc model explanations, and prototyped a
visual dashboard to present the combined insights from different context
dimensions and data sources, while predicting and identifying the drivers of
risk of Chronic Kidney Disease - a common type-2 diabetes comorbidity. All of
these steps were performed in engagement with medical experts, including a
final evaluation of the dashboard results by an expert medical panel. We show
that LLMs, in particular BERT and SciBERT, can be readily deployed to extract
some relevant explanations to support clinical usage. To understand the
value-add of the contextual explanations, the expert panel evaluated these
regarding actionable insights in the relevant clinical setting. Overall, our
paper is one of the first end-to-end analyses identifying the feasibility and
benefits of contextual explanations in a real-world clinical use case.

---------------

### 27 Jun 2018 | [A comparative study of artificial intelligence and human doctors for the  purpose of triage and diagnosis](https://arxiv.org/abs/1806.10698) | [⬇️](https://arxiv.org/pdf/1806.10698)
*Salman Razzaki, Adam Baker, Yura Perov, Katherine Middleton, Janie  Baxter, Daniel Mullarkey, Davinder Sangar, Michael Taliercio, Mobasher Butt,  Azeem Majeed, Arnold DoRosario, Megan Mahoney, Saurabh Johri* 

  Online symptom checkers have significant potential to improve patient care,
however their reliability and accuracy remain variable. We hypothesised that an
artificial intelligence (AI) powered triage and diagnostic system would compare
favourably with human doctors with respect to triage and diagnostic accuracy.
We performed a prospective validation study of the accuracy and safety of an AI
powered triage and diagnostic system. Identical cases were evaluated by both an
AI system and human doctors. Differential diagnoses and triage outcomes were
evaluated by an independent judge, who was blinded from knowing the source (AI
system or human doctor) of the outcomes. Independently of these cases,
vignettes from publicly available resources were also assessed to provide a
benchmark to previous studies and the diagnostic component of the MRCGP exam.
Overall we found that the Babylon AI powered Triage and Diagnostic System was
able to identify the condition modelled by a clinical vignette with accuracy
comparable to human doctors (in terms of precision and recall). In addition, we
found that the triage advice recommended by the AI System was, on average,
safer than that of human doctors, when compared to the ranges of acceptable
triage provided by independent expert judges, with only a minimal reduction in
appropriateness.

---------------

### 15 Jul 2021 | [Leveraging Clinical Context for User-Centered Explainability: A Diabetes  Use Case](https://arxiv.org/abs/2107.02359) | [⬇️](https://arxiv.org/pdf/2107.02359)
*Shruthi Chari, Prithwish Chakraborty, Mohamed Ghalwash, Oshani  Seneviratne, Elif K. Eyigoz, Daniel M. Gruen, Fernando Suarez Saiz, Ching-Hua  Chen, Pablo Meyer Rojas, Deborah L. McGuinness* 

  Academic advances of AI models in high-precision domains, like healthcare,
need to be made explainable in order to enhance real-world adoption. Our past
studies and ongoing interactions indicate that medical experts can use AI
systems with greater trust if there are ways to connect the model inferences
about patients to explanations that are tied back to the context of use.
Specifically, risk prediction is a complex problem of diagnostic and
interventional importance to clinicians wherein they consult different sources
to make decisions. To enable the adoption of the ever improving AI risk
prediction models in practice, we have begun to explore techniques to
contextualize such models along three dimensions of interest: the patients'
clinical state, AI predictions about their risk of complications, and
algorithmic explanations supporting the predictions. We validate the importance
of these dimensions by implementing a proof-of-concept (POC) in type-2 diabetes
(T2DM) use case where we assess the risk of chronic kidney disease (CKD) - a
common T2DM comorbidity. Within the POC, we include risk prediction models for
CKD, post-hoc explainers of the predictions, and other natural-language modules
which operationalize domain knowledge and CPGs to provide context. With primary
care physicians (PCP) as our end-users, we present our initial results and
clinician feedback in this paper. Our POC approach covers multiple knowledge
sources and clinical scenarios, blends knowledge to explain data and
predictions to PCPs, and received an enthusiastic response from our medical
expert.

---------------

### 08 Feb 2021 | [Clinical Outcome Prediction from Admission Notes using Self-Supervised  Knowledge Integration](https://arxiv.org/abs/2102.04110) | [⬇️](https://arxiv.org/pdf/2102.04110)
*Betty van Aken, Jens-Michalis Papaioannou, Manuel Mayrdorfer, Klemens  Budde, Felix A. Gers, Alexander L\"oser* 

  Outcome prediction from clinical text can prevent doctors from overlooking
possible risks and help hospitals to plan capacities. We simulate patients at
admission time, when decision support can be especially valuable, and
contribute a novel admission to discharge task with four common outcome
prediction targets: Diagnoses at discharge, procedures performed, in-hospital
mortality and length-of-stay prediction. The ideal system should infer outcomes
based on symptoms, pre-conditions and risk factors of a patient. We evaluate
the effectiveness of language models to handle this scenario and propose
clinical outcome pre-training to integrate knowledge about patient outcomes
from multiple public sources. We further present a simple method to incorporate
ICD code hierarchy into the models. We show that our approach improves
performance on the outcome tasks against several baselines. A detailed analysis
reveals further strengths of the model, including transferability, but also
weaknesses such as handling of vital values and inconsistencies in the
underlying data.

---------------

### 02 Aug 2019 | [Mixed-Integer Optimization Approach to Learning Association Rules for  Unplanned ICU Transfer](https://arxiv.org/abs/1908.00966) | [⬇️](https://arxiv.org/pdf/1908.00966)
*Chun-An Chou and Qingtao Cao and Shao-Jen Weng and Che-Hung Tsai* 

  After admission to emergency department (ED), patients with critical
illnesses are transferred to intensive care unit (ICU) due to unexpected
clinical deterioration occurrence. Identifying such unplanned ICU transfers is
urgently needed for medical physicians to achieve two-fold goals: improving
critical care quality and preventing mortality. A priority task is to
understand the crucial rationale behind diagnosis results of individual
patients during stay in ED, which helps prepare for an early transfer to ICU.
Most existing prediction studies were based on univariate analysis or multiple
logistic regression to provide one-size-fit-all results. However, patient
condition varying from case to case may not be accurately examined by the only
judgment. In this study, we present a new decision tool using a mathematical
optimization approach aiming to automatically discover rules associating
diagnostic features with high-risk outcome (i.e., unplanned transfers) in
different deterioration scenarios. We consider four mutually exclusive patient
subgroups based on the principal reasons of ED visits: infections,
cardiovascular/respiratory diseases, gastrointestinal diseases, and
neurological/other diseases at a suburban teaching hospital. The analysis
results demonstrate significant rules associated with unplanned transfer
outcome for each subgroups and also show comparable prediction accuracy,
compared to state-of-the-art machine learning methods while providing
easy-to-interpret symptom-outcome information.

---------------

### 21 Feb 2024 | [ED-Copilot: Reduce Emergency Department Wait Time with Language Model  Diagnostic Assistance](https://arxiv.org/abs/2402.13448) | [⬇️](https://arxiv.org/pdf/2402.13448)
*Liwen Sun, Abhineet Agarwal, Aaron Kornblith, Bin Yu, Chenyan Xiong* 

  In the emergency department (ED), patients undergo triage and multiple
laboratory tests before diagnosis. This process is time-consuming, and causes
ED crowding which significantly impacts patient mortality, medical errors,
staff burnout, etc. This work proposes (time) cost-effective diagnostic
assistance that explores the potential of artificial intelligence (AI) systems
in assisting ED clinicians to make time-efficient and accurate diagnoses. Using
publicly available patient data, we collaborate with ED clinicians to curate
MIMIC-ED-Assist, a benchmark that measures the ability of AI systems in
suggesting laboratory tests that minimize ED wait times, while correctly
predicting critical outcomes such as death. We develop ED-Copilot which
sequentially suggests patient-specific laboratory tests and makes diagnostic
predictions. ED-Copilot uses a pre-trained bio-medical language model to encode
patient information and reinforcement learning to minimize ED wait time and
maximize prediction accuracy of critical outcomes. On MIMIC-ED-Assist,
ED-Copilot improves prediction accuracy over baselines while halving average
wait time from four hours to two hours. Ablation studies demonstrate the
importance of model scale and use of a bio-medical language model. Further
analyses reveal the necessity of personalized laboratory test suggestions for
diagnosing patients with severe cases, as well as the potential of ED-Copilot
in providing ED clinicians with informative laboratory test recommendations.
Our code is available at https://github.com/cxcscmu/ED-Copilot.

---------------

### 16 Aug 2023 | [Explainable AI for clinical risk prediction: a survey of concepts,  methods, and modalities](https://arxiv.org/abs/2308.08407) | [⬇️](https://arxiv.org/pdf/2308.08407)
*Munib Mesinovic, Peter Watkinson, Tingting Zhu* 

  Recent advancements in AI applications to healthcare have shown incredible
promise in surpassing human performance in diagnosis and disease prognosis.
With the increasing complexity of AI models, however, concerns regarding their
opacity, potential biases, and the need for interpretability. To ensure trust
and reliability in AI systems, especially in clinical risk prediction models,
explainability becomes crucial. Explainability is usually referred to as an AI
system's ability to provide a robust interpretation of its decision-making
logic or the decisions themselves to human stakeholders. In clinical risk
prediction, other aspects of explainability like fairness, bias, trust, and
transparency also represent important concepts beyond just interpretability. In
this review, we address the relationship between these concepts as they are
often used together or interchangeably. This review also discusses recent
progress in developing explainable models for clinical risk prediction,
highlighting the importance of quantitative and clinical evaluation and
validation across multiple common modalities in clinical practice. It
emphasizes the need for external validation and the combination of diverse
interpretability methods to enhance trust and fairness. Adopting rigorous
testing, such as using synthetic datasets with known generative factors, can
further improve the reliability of explainability methods. Open access and
code-sharing resources are essential for transparency and reproducibility,
enabling the growth and trustworthiness of explainable research. While
challenges exist, an end-to-end approach to explainability in clinical risk
prediction, incorporating stakeholders from clinicians to developers, is
essential for success.

---------------

### 06 Dec 2023 | [Domain constraints improve risk prediction when outcome data is missing](https://arxiv.org/abs/2312.03878) | [⬇️](https://arxiv.org/pdf/2312.03878)
*Sidhika Balachandar, Nikhil Garg, Emma Pierson* 

  Machine learning models are often trained to predict the outcome resulting
from a human decision. For example, if a doctor decides to test a patient for
disease, will the patient test positive? A challenge is that the human decision
censors the outcome data: we only observe test outcomes for patients doctors
historically tested. Untested patients, for whom outcomes are unobserved, may
differ from tested patients along observed and unobserved dimensions. We
propose a Bayesian model class which captures this setting. The purpose of the
model is to accurately estimate risk for both tested and untested patients.
Estimating this model is challenging due to the wide range of possibilities for
untested patients. To address this, we propose two domain constraints which are
plausible in health settings: a prevalence constraint, where the overall
disease prevalence is known, and an expertise constraint, where the human
decision-maker deviates from purely risk-based decision-making only along a
constrained feature set. We show theoretically and on synthetic data that
domain constraints improve parameter inference. We apply our model to a case
study of cancer risk prediction, showing that the model's inferred risk
predicts cancer diagnoses, its inferred testing policy captures known public
health policies, and it can identify suboptimalities in test allocation. Though
our case study is in healthcare, our analysis reveals a general class of domain
constraints which can improve model estimation in many settings.

---------------

### 11 Aug 2023 | [ExBEHRT: Extended Transformer for Electronic Health Records to Predict  Disease Subtypes & Progressions](https://arxiv.org/abs/2303.12364) | [⬇️](https://arxiv.org/pdf/2303.12364)
*Maurice Rupp, Oriane Peter, Thirupathi Pattipaka* 

  In this study, we introduce ExBEHRT, an extended version of BEHRT (BERT
applied to electronic health records), and apply different algorithms to
interpret its results. While BEHRT considers only diagnoses and patient age, we
extend the feature space to several multimodal records, namely demographics,
clinical characteristics, vital signs, smoking status, diagnoses, procedures,
medications, and laboratory tests, by applying a novel method to unify the
frequencies and temporal dimensions of the different features. We show that
additional features significantly improve model performance for various
downstream tasks in different diseases. To ensure robustness, we interpret
model predictions using an adaptation of expected gradients, which has not been
previously applied to transformers with EHR data and provides more granular
interpretations than previous approaches such as feature and token importances.
Furthermore, by clustering the model representations of oncology patients, we
show that the model has an implicit understanding of the disease and is able to
classify patients with the same cancer type into different risk groups. Given
the additional features and interpretability, ExBEHRT can help make informed
decisions about disease trajectories, diagnoses, and risk factors of various
diseases.

---------------

### 15 Feb 2024 | [Towards Reducing Diagnostic Errors with Interpretable Risk Prediction](https://arxiv.org/abs/2402.10109) | [⬇️](https://arxiv.org/pdf/2402.10109)
*Denis Jered McInerney, William Dickinson, Lucy Flynn, Andrea Young,  Geoffrey Young, Jan-Willem van de Meent, Byron C. Wallace* 

  Many diagnostic errors occur because clinicians cannot easily access relevant
information in patient Electronic Health Records (EHRs). In this work we
propose a method to use LLMs to identify pieces of evidence in patient EHR data
that indicate increased or decreased risk of specific diagnoses; our ultimate
aim is to increase access to evidence and reduce diagnostic errors. In
particular, we propose a Neural Additive Model to make predictions backed by
evidence with individualized risk estimates at time-points where clinicians are
still uncertain, aiming to specifically mitigate delays in diagnosis and errors
stemming from an incomplete differential. To train such a model, it is
necessary to infer temporally fine-grained retrospective labels of eventual
"true" diagnoses. We do so with LLMs, to ensure that the input text is from
before a confident diagnosis can be made. We use an LLM to retrieve an initial
pool of evidence, but then refine this set of evidence according to
correlations learned by the model. We conduct an in-depth evaluation of the
usefulness of our approach by simulating how it might be used by a clinician to
decide between a pre-defined list of differential diagnoses.

---------------

### 15 Oct 2021 | [A New Approach for Interpretability and Reliability in Clinical Risk  Prediction: Acute Coronary Syndrome Scenario](https://arxiv.org/abs/2110.08331) | [⬇️](https://arxiv.org/pdf/2110.08331)
*Francisco Valente, Jorge Henriques, Sim\~ao Paredes, Teresa Rocha,  Paulo de Carvalho, Jo\~ao Morais* 

  We intend to create a new risk assessment methodology that combines the best
characteristics of both risk score and machine learning models. More
specifically, we aim to develop a method that, besides having a good
performance, offers a personalized model and outcome for each patient, presents
high interpretability, and incorporates an estimation of the prediction
reliability which is not usually available. By combining these features in the
same approach we expect that it can boost the confidence of physicians to use
such a tool in their daily activity. In order to achieve the mentioned goals, a
three-step methodology was developed: several rules were created by
dichotomizing risk factors; such rules were trained with a machine learning
classifier to predict the acceptance degree of each rule (the probability that
the rule is correct) for each patient; that information was combined and used
to compute the risk of mortality and the reliability of such prediction. The
methodology was applied to a dataset of patients admitted with any type of
acute coronary syndromes (ACS), to assess the 30-days all-cause mortality risk.
The performance was compared with state-of-the-art approaches: logistic
regression (LR), artificial neural network (ANN), and clinical risk score model
(Global Registry of Acute Coronary Events - GRACE). The proposed approach
achieved testing results identical to the standard LR, but offers superior
interpretability and personalization; it also significantly outperforms the
GRACE risk model and the standard ANN model. The calibration curve also
suggests a very good generalization ability of the obtained model as it
approaches the ideal curve. Finally, the reliability estimation of individual
predictions presented a great correlation with the misclassifications rate.
Those properties may have a beneficial application in other clinical scenarios
as well. [abridged]

---------------

### 26 Feb 2024 | [Rethinking Human-AI Collaboration in Complex Medical Decision Making: A  Case Study in Sepsis Diagnosis](https://arxiv.org/abs/2309.12368) | [⬇️](https://arxiv.org/pdf/2309.12368)
*Shao Zhang, Jianing Yu, Xuhai Xu, Changchang Yin, Yuxuan Lu, Bingsheng  Yao, Melanie Tory, Lace M. Padilla, Jeffrey Caterino, Ping Zhang, Dakuo Wang* 

  Today's AI systems for medical decision support often succeed on benchmark
datasets in research papers but fail in real-world deployment. This work
focuses on the decision making of sepsis, an acute life-threatening systematic
infection that requires an early diagnosis with high uncertainty from the
clinician. Our aim is to explore the design requirements for AI systems that
can support clinical experts in making better decisions for the early diagnosis
of sepsis. The study begins with a formative study investigating why clinical
experts abandon an existing AI-powered Sepsis predictive module in their
electrical health record (EHR) system. We argue that a human-centered AI system
needs to support human experts in the intermediate stages of a medical
decision-making process (e.g., generating hypotheses or gathering data),
instead of focusing only on the final decision. Therefore, we build SepsisLab
based on a state-of-the-art AI algorithm and extend it to predict the future
projection of sepsis development, visualize the prediction uncertainty, and
propose actionable suggestions (i.e., which additional laboratory tests can be
collected) to reduce such uncertainty. Through heuristic evaluation with six
clinicians using our prototype system, we demonstrate that SepsisLab enables a
promising human-AI collaboration paradigm for the future of AI-assisted sepsis
diagnosis and other high-stakes medical decision making.

---------------

### 29 Jan 2024 | [Beyond Direct Diagnosis: LLM-based Multi-Specialist Agent Consultation  for Automatic Diagnosis](https://arxiv.org/abs/2401.16107) | [⬇️](https://arxiv.org/pdf/2401.16107)
*Haochun Wang, Sendong Zhao, Zewen Qiang, Nuwa Xi, Bing Qin, Ting Liu* 

  Automatic diagnosis is a significant application of AI in healthcare, where
diagnoses are generated based on the symptom description of patients. Previous
works have approached this task directly by modeling the relationship between
the normalized symptoms and all possible diseases. However, in the clinical
diagnostic process, patients are initially consulted by a general practitioner
and, if necessary, referred to specialists in specific domains for a more
comprehensive evaluation. The final diagnosis often emerges from a
collaborative consultation among medical specialist groups. Recently, large
language models have shown impressive capabilities in natural language
understanding. In this study, we adopt tuning-free LLM-based agents as medical
practitioners and propose the Agent-derived Multi-Specialist Consultation
(AMSC) framework to model the diagnosis process in the real world by adaptively
fusing probability distributions of agents over potential diseases.
Experimental results demonstrate the superiority of our approach compared with
baselines. Notably, our approach requires significantly less parameter updating
and training time, enhancing efficiency and practical utility. Furthermore, we
delve into a novel perspective on the role of implicit symptoms within the
context of automatic diagnosis.

---------------

### 07 Feb 2023 | [An Expert System to Diagnose Spinal Disorders](https://arxiv.org/abs/2302.03625) | [⬇️](https://arxiv.org/pdf/2302.03625)
*Seyed Mohammad Sadegh Dashti, Seyedeh Fatemeh Dashti* 

  Objective: Until now, traditional invasive approaches have been the only
means being leveraged to diagnose spinal disorders. Traditional manual
diagnostics require a high workload, and diagnostic errors are likely to occur
due to the prolonged work of physicians. In this research, we develop an expert
system based on a hybrid inference algorithm and comprehensive integrated
knowledge for assisting the experts in the fast and high-quality diagnosis of
spinal disorders.
  Methods: First, for each spinal anomaly, the accurate and integrated
knowledge was acquired from related experts and resources. Second, based on
probability distributions and dependencies between symptoms of each anomaly, a
unique numerical value known as certainty effect value was assigned to each
symptom. Third, a new hybrid inference algorithm was designed to obtain
excellent performance, which was an incorporation of the Backward Chaining
Inference and Theory of Uncertainty.
  Results: The proposed expert system was evaluated in two different phases,
real-world samples, and medical records evaluation. Evaluations show that in
terms of real-world samples analysis, the system achieved excellent accuracy.
Application of the system on the sample with anomalies revealed the degree of
severity of disorders and the risk of development of abnormalities in unhealthy
and healthy patients. In the case of medical records analysis, our expert
system proved to have promising performance, which was very close to those of
experts.
  Conclusion: Evaluations suggest that the proposed expert system provides
promising performance, helping specialists to validate the accuracy and
integrity of their diagnosis. It can also serve as an intelligent educational
software for medical students to gain familiarity with spinal disorder
diagnosis process, and related symptoms.

---------------

### 27 Nov 2019 | [AdaCare: Explainable Clinical Health Status Representation Learning via  Scale-Adaptive Feature Extraction and Recalibration](https://arxiv.org/abs/1911.12205) | [⬇️](https://arxiv.org/pdf/1911.12205)
*Liantao Ma, Junyi Gao, Yasha Wang, Chaohe Zhang, Jiangtao Wang, Wenjie  Ruan, Wen Tang, Xin Gao, Xinyu Ma* 

  Deep learning-based health status representation learning and clinical
prediction have raised much research interest in recent years. Existing models
have shown superior performance, but there are still several major issues that
have not been fully taken into consideration. First, the historical variation
pattern of the biomarker in diverse time scales plays a vital role in
indicating the health status, but it has not been explicitly extracted by
existing works. Second, key factors that strongly indicate the health risk are
different among patients. It is still challenging to adaptively make use of the
features for patients in diverse conditions. Third, using prediction models as
the black box will limit the reliability in clinical practice. However, none of
the existing works can provide satisfying interpretability and meanwhile
achieve high prediction performance. In this work, we develop a general health
status representation learning model, named AdaCare. It can capture the long
and short-term variations of biomarkers as clinical features to depict the
health status in multiple time scales. It also models the correlation between
clinical features to enhance the ones which strongly indicate the health status
and thus can maintain a state-of-the-art performance in terms of prediction
accuracy while providing qualitative interpretability. We conduct a health risk
prediction experiment on two real-world datasets. Experiment results indicate
that AdaCare outperforms state-of-the-art approaches and provides effective
interpretability, which is verifiable by clinical experts.

---------------

### 28 Nov 2018 | [Disease phenotyping using deep learning: A diabetes case study](https://arxiv.org/abs/1811.11818) | [⬇️](https://arxiv.org/pdf/1811.11818)
*Sina Rashidian, Janos Hajagos, Richard Moffitt, Fusheng Wang, Xinyu  Dong, Kayley Abell-Hart, Kimberly Noel, Rajarsi Gupta, Mathew Tharakan, Veena  Lingam, Joel Saltz, Mary Saltz* 

  Characterization of a patient clinical phenotype is central to biomedical
informatics. ICD codes, assigned to inpatient encounters by coders, is
important for population health and cohort discovery when clinical information
is limited. While ICD codes are assigned to patients by professionals trained
and certified in coding there is substantial variability in coding. We present
a methodology that uses deep learning methods to model coder decision making
and that predicts ICD codes. Our approach predicts codes based on demographics,
lab results, and medications, as well as codes from previous encounters. We are
able to predict existing codes with high accuracy for all three of the test
cases we investigated: diabetes, acute renal failure, and chronic kidney
disease. We employed a panel of clinicians, in a blinded manner, to assess
ground truth and compared the predictions of coders, model and clinicians. When
disparities between the model prediction and coder assigned codes were
reviewed, our model outperformed coder assigned ICD codes.

---------------

### 27 Oct 2023 | [Auditing for Human Expertise](https://arxiv.org/abs/2306.01646) | [⬇️](https://arxiv.org/pdf/2306.01646)
*Rohan Alur, Loren Laine, Darrick K. Li, Manish Raghavan, Devavrat  Shah, Dennis Shung* 

  High-stakes prediction tasks (e.g., patient diagnosis) are often handled by
trained human experts. A common source of concern about automation in these
settings is that experts may exercise intuition that is difficult to model
and/or have access to information (e.g., conversations with a patient) that is
simply unavailable to a would-be algorithm. This raises a natural question
whether human experts add value which could not be captured by an algorithmic
predictor. We develop a statistical framework under which we can pose this
question as a natural hypothesis test. Indeed, as our framework highlights,
detecting human expertise is more subtle than simply comparing the accuracy of
expert predictions to those made by a particular learning algorithm. Instead,
we propose a simple procedure which tests whether expert predictions are
statistically independent from the outcomes of interest after conditioning on
the available inputs (`features'). A rejection of our test thus suggests that
human experts may add value to any algorithm trained on the available data, and
has direct implications for whether human-AI `complementarity' is achievable in
a given prediction task. We highlight the utility of our procedure using
admissions data collected from the emergency department of a large academic
hospital system, where we show that physicians' admit/discharge decisions for
patients with acute gastrointestinal bleeding (AGIB) appear to be incorporating
information that is not available to a standard algorithmic screening tool.
This is despite the fact that the screening tool is arguably more accurate than
physicians' discretionary decisions, highlighting that -- even absent normative
concerns about accountability or interpretability -- accuracy is insufficient
to justify algorithmic automation.

---------------

### 09 Oct 2023 | [RECAP-KG: Mining Knowledge Graphs from Raw GP Notes for Remote COVID-19  Assessment in Primary Care](https://arxiv.org/abs/2306.17175) | [⬇️](https://arxiv.org/pdf/2306.17175)
*Rakhilya Lee Mekhtieva, Brandon Forbes, Dalal Alrajeh, Brendan  Delaney, Alessandra Russo* 

  Clinical decision-making is a fundamental stage in delivering appropriate
care to patients. In recent years several decision-making systems designed to
aid the clinician in this process have been developed. However, technical
solutions currently in use are based on simple regression models and are only
able to take into account simple pre-defined multiple-choice features, such as
patient age, pre-existing conditions, smoker status, etc. One particular source
of patient data, that available decision-making systems are incapable of
processing is the collection of patient consultation GP notes. These contain
crucial signs and symptoms - the information used by clinicians in order to
make a final decision and direct the patient to the appropriate care.
Extracting information from GP notes is a technically challenging problem, as
they tend to include abbreviations, typos, and incomplete sentences.
  This paper addresses this open challenge. We present a framework that
performs knowledge graph construction from raw GP medical notes written during
or after patient consultations. By relying on support phrases mined from the
SNOMED ontology, as well as predefined supported facts from values used in the
RECAP (REmote COVID-19 Assessment in Primary Care) patient risk prediction
tool, our graph generative framework is able to extract structured knowledge
graphs from the highly unstructured and inconsistent format that consultation
notes are written in. Our knowledge graphs include information about existing
patient symptoms, their duration, and their severity.
  We apply our framework to consultation notes of COVID-19 patients in the UK
COVID-19 Clinical Assesment Servcie (CCAS) patient dataset. We provide a
quantitative evaluation of the performance of our framework, demonstrating that
our approach has better accuracy than traditional NLP methods when answering
questions about patients.

---------------

### 14 May 2021 | [A causal learning framework for the analysis and interpretation of  COVID-19 clinical data](https://arxiv.org/abs/2105.06998) | [⬇️](https://arxiv.org/pdf/2105.06998)
*Elisa Ferrari, Luna Gargani, Greta Barbieri, Lorenzo Ghiadoni,  Francesco Faita, Davide Bacciu* 

  We present a workflow for clinical data analysis that relies on Bayesian
Structure Learning (BSL), an unsupervised learning approach, robust to noise
and biases, that allows to incorporate prior medical knowledge into the
learning process and that provides explainable results in the form of a graph
showing the causal connections among the analyzed features. The workflow
consists in a multi-step approach that goes from identifying the main causes of
patient's outcome through BSL, to the realization of a tool suitable for
clinical practice, based on a Binary Decision Tree (BDT), to recognize patients
at high-risk with information available already at hospital admission time. We
evaluate our approach on a feature-rich COVID-19 dataset, showing that the
proposed framework provides a schematic overview of the multi-factorial
processes that jointly contribute to the outcome. We discuss how these
computational findings are confirmed by current understanding of the COVID-19
pathogenesis. Further, our approach yields to a highly interpretable tool
correctly predicting the outcome of 85% of subjects based exclusively on 3
features: age, a previous history of chronic obstructive pulmonary disease and
the PaO2/FiO2 ratio at the time of arrival to the hospital. The inclusion of
additional information from 4 routine blood tests (Creatinine, Glucose, pO2 and
Sodium) increases predictive accuracy to 94.5%.

---------------
**Date:** 18 Jan 2022

**Title:** Label-dependent and event-guided interpretable disease risk prediction  using EHRs

**Abstract Link:** [https://arxiv.org/abs/2201.06783](https://arxiv.org/abs/2201.06783)

**PDF Link:** [https://arxiv.org/pdf/2201.06783](https://arxiv.org/pdf/2201.06783)

---

**Date:** 11 Feb 2023

**Title:** Informing clinical assessment by contextualizing post-hoc explanations  of risk prediction models in type-2 diabetes

**Abstract Link:** [https://arxiv.org/abs/2302.05752](https://arxiv.org/abs/2302.05752)

**PDF Link:** [https://arxiv.org/pdf/2302.05752](https://arxiv.org/pdf/2302.05752)

---

**Date:** 27 Jun 2018

**Title:** A comparative study of artificial intelligence and human doctors for the  purpose of triage and diagnosis

**Abstract Link:** [https://arxiv.org/abs/1806.10698](https://arxiv.org/abs/1806.10698)

**PDF Link:** [https://arxiv.org/pdf/1806.10698](https://arxiv.org/pdf/1806.10698)

---

**Date:** 15 Jul 2021

**Title:** Leveraging Clinical Context for User-Centered Explainability: A Diabetes  Use Case

**Abstract Link:** [https://arxiv.org/abs/2107.02359](https://arxiv.org/abs/2107.02359)

**PDF Link:** [https://arxiv.org/pdf/2107.02359](https://arxiv.org/pdf/2107.02359)

---

**Date:** 08 Feb 2021

**Title:** Clinical Outcome Prediction from Admission Notes using Self-Supervised  Knowledge Integration

**Abstract Link:** [https://arxiv.org/abs/2102.04110](https://arxiv.org/abs/2102.04110)

**PDF Link:** [https://arxiv.org/pdf/2102.04110](https://arxiv.org/pdf/2102.04110)

---

**Date:** 02 Aug 2019

**Title:** Mixed-Integer Optimization Approach to Learning Association Rules for  Unplanned ICU Transfer

**Abstract Link:** [https://arxiv.org/abs/1908.00966](https://arxiv.org/abs/1908.00966)

**PDF Link:** [https://arxiv.org/pdf/1908.00966](https://arxiv.org/pdf/1908.00966)

---

**Date:** 21 Feb 2024

**Title:** ED-Copilot: Reduce Emergency Department Wait Time with Language Model  Diagnostic Assistance

**Abstract Link:** [https://arxiv.org/abs/2402.13448](https://arxiv.org/abs/2402.13448)

**PDF Link:** [https://arxiv.org/pdf/2402.13448](https://arxiv.org/pdf/2402.13448)

---

**Date:** 16 Aug 2023

**Title:** Explainable AI for clinical risk prediction: a survey of concepts,  methods, and modalities

**Abstract Link:** [https://arxiv.org/abs/2308.08407](https://arxiv.org/abs/2308.08407)

**PDF Link:** [https://arxiv.org/pdf/2308.08407](https://arxiv.org/pdf/2308.08407)

---

**Date:** 06 Dec 2023

**Title:** Domain constraints improve risk prediction when outcome data is missing

**Abstract Link:** [https://arxiv.org/abs/2312.03878](https://arxiv.org/abs/2312.03878)

**PDF Link:** [https://arxiv.org/pdf/2312.03878](https://arxiv.org/pdf/2312.03878)

---

**Date:** 11 Aug 2023

**Title:** ExBEHRT: Extended Transformer for Electronic Health Records to Predict  Disease Subtypes & Progressions

**Abstract Link:** [https://arxiv.org/abs/2303.12364](https://arxiv.org/abs/2303.12364)

**PDF Link:** [https://arxiv.org/pdf/2303.12364](https://arxiv.org/pdf/2303.12364)

---

**Date:** 15 Feb 2024

**Title:** Towards Reducing Diagnostic Errors with Interpretable Risk Prediction

**Abstract Link:** [https://arxiv.org/abs/2402.10109](https://arxiv.org/abs/2402.10109)

**PDF Link:** [https://arxiv.org/pdf/2402.10109](https://arxiv.org/pdf/2402.10109)

---

**Date:** 15 Oct 2021

**Title:** A New Approach for Interpretability and Reliability in Clinical Risk  Prediction: Acute Coronary Syndrome Scenario

**Abstract Link:** [https://arxiv.org/abs/2110.08331](https://arxiv.org/abs/2110.08331)

**PDF Link:** [https://arxiv.org/pdf/2110.08331](https://arxiv.org/pdf/2110.08331)

---

**Date:** 26 Feb 2024

**Title:** Rethinking Human-AI Collaboration in Complex Medical Decision Making: A  Case Study in Sepsis Diagnosis

**Abstract Link:** [https://arxiv.org/abs/2309.12368](https://arxiv.org/abs/2309.12368)

**PDF Link:** [https://arxiv.org/pdf/2309.12368](https://arxiv.org/pdf/2309.12368)

---

**Date:** 29 Jan 2024

**Title:** Beyond Direct Diagnosis: LLM-based Multi-Specialist Agent Consultation  for Automatic Diagnosis

**Abstract Link:** [https://arxiv.org/abs/2401.16107](https://arxiv.org/abs/2401.16107)

**PDF Link:** [https://arxiv.org/pdf/2401.16107](https://arxiv.org/pdf/2401.16107)

---

**Date:** 07 Feb 2023

**Title:** An Expert System to Diagnose Spinal Disorders

**Abstract Link:** [https://arxiv.org/abs/2302.03625](https://arxiv.org/abs/2302.03625)

**PDF Link:** [https://arxiv.org/pdf/2302.03625](https://arxiv.org/pdf/2302.03625)

---

**Date:** 27 Nov 2019

**Title:** AdaCare: Explainable Clinical Health Status Representation Learning via  Scale-Adaptive Feature Extraction and Recalibration

**Abstract Link:** [https://arxiv.org/abs/1911.12205](https://arxiv.org/abs/1911.12205)

**PDF Link:** [https://arxiv.org/pdf/1911.12205](https://arxiv.org/pdf/1911.12205)

---

**Date:** 28 Nov 2018

**Title:** Disease phenotyping using deep learning: A diabetes case study

**Abstract Link:** [https://arxiv.org/abs/1811.11818](https://arxiv.org/abs/1811.11818)

**PDF Link:** [https://arxiv.org/pdf/1811.11818](https://arxiv.org/pdf/1811.11818)

---

**Date:** 27 Oct 2023

**Title:** Auditing for Human Expertise

**Abstract Link:** [https://arxiv.org/abs/2306.01646](https://arxiv.org/abs/2306.01646)

**PDF Link:** [https://arxiv.org/pdf/2306.01646](https://arxiv.org/pdf/2306.01646)

---

**Date:** 09 Oct 2023

**Title:** RECAP-KG: Mining Knowledge Graphs from Raw GP Notes for Remote COVID-19  Assessment in Primary Care

**Abstract Link:** [https://arxiv.org/abs/2306.17175](https://arxiv.org/abs/2306.17175)

**PDF Link:** [https://arxiv.org/pdf/2306.17175](https://arxiv.org/pdf/2306.17175)

---

**Date:** 14 May 2021

**Title:** A causal learning framework for the analysis and interpretation of  COVID-19 clinical data

**Abstract Link:** [https://arxiv.org/abs/2105.06998](https://arxiv.org/abs/2105.06998)

**PDF Link:** [https://arxiv.org/pdf/2105.06998](https://arxiv.org/pdf/2105.06998)

---

