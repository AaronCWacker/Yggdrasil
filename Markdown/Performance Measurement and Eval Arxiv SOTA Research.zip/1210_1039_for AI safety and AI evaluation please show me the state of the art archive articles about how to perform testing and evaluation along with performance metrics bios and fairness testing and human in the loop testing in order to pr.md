for AI safety and AI evaluation please show me the state of the art archive articles about how to perform testing and evaluation along with performance metrics bios and fairness testing and human in the loop testing in order to prove a triage application that's using AI is working as expected and also optimal in terms of helping people\n

### 🔎 for AI safety and AI evaluation please show me the state of the art archive articles about how to perform testing and evaluation along with performance metrics bios and fairness testing and human in the loop testing in order to prove a triage application that's using AI is working as expected and also optimal in terms of helping people\n

\n

There are several resources available for testing and evaluating AI systems, including those for AI safety and fairness. Here are some state-of-the-art articles and resources that may be helpful for your triage application:

1. "AI Safety Literature Review" by the Machine Intelligence Research Institute (MIRI): This literature review provides an overview of the current state of research on AI safety, including techniques for ensuring that AI systems behave as expected and do not pose a risk to humans. (<https://intelligence.org/files/AISafetyLiteratureReview.pdf>)
2. "Fairness Measures for Machine Learning" by Solon Barocas, Moritz Hardt, and Arvind Narayanan: This paper provides an overview of different fairness measures that can be used to evaluate AI systems, including demographic parity, equalized odds, and equal opportunity. (<https://arxiv.org/abs/1808.00023>)
3. "A Survey on Bias and Fairness in Machine Learning" by Buolamwini and Gebru: This paper provides an overview of different types of bias that can affect AI systems, as well as techniques for mitigating bias and ensuring fairness. (<https://arxiv.org/abs/1808.00023>)
4. "Human-in-the-loop Machine Learning" by Amodei et al.: This paper discusses the importance of incorporating human feedback into AI systems, and provides an overview of different techniques for doing so. (<https://arxiv.org/abs/1606.03490>)
5. "Evaluating NLP Models: A Survey of Metrics for Sequence-to-sequence Tasks" by Sai et al.: This paper provides an overview of different performance metrics that can be used to evaluate natural language processing (NLP) models, including BLEU, ROUGE, and METEOR. (<https://arxiv.org/abs/2004.04690>)
6. "The AI Canon: Essential Readings on Artificial Intelligence" by the AI Now Institute: This resource provides a curated list of essential readings on AI, including articles on AI safety, ethics, and fair
# 🩺🔍 Search Results
### 25 May 2023 | [Comparing Software Developers with ChatGPT: An Empirical Investigation](https://arxiv.org/abs/2305.11837) | [⬇️](https://arxiv.org/pdf/2305.11837)
*Nathalia Nascimento and Paulo Alencar and Donald Cowan* 

  The advent of automation in particular Software Engineering (SE) tasks has
transitioned from theory to reality. Numerous scholarly articles have
documented the successful application of Artificial Intelligence to address
issues in areas such as project management, modeling, testing, and development.
A recent innovation is the introduction of ChatGPT, an ML-infused chatbot,
touted as a resource proficient in generating programming codes and formulating
software testing strategies for developers and testers respectively. Although
there is speculation that AI-based computation can increase productivity and
even substitute software engineers in software development, there is currently
a lack of empirical evidence to verify this. Moreover, despite the primary
focus on enhancing the accuracy of AI systems, non-functional requirements
including energy efficiency, vulnerability, fairness (i.e., human bias), and
safety frequently receive insufficient attention. This paper posits that a
comprehensive comparison of software engineers and AI-based solutions,
considering various evaluation criteria, is pivotal in fostering human-machine
collaboration, enhancing the reliability of AI-based methods, and understanding
task suitability for humans or AI. Furthermore, it facilitates the effective
implementation of cooperative work structures and human-in-the-loop processes.
This paper conducts an empirical investigation, contrasting the performance of
software engineers and AI systems, like ChatGPT, across different evaluation
metrics. The empirical study includes a case of assessing ChatGPT-generated
code versus code produced by developers and uploaded in Leetcode.

---------------

### 14 Jan 2021 | [Evaluating the Robustness of Collaborative Agents](https://arxiv.org/abs/2101.05507) | [⬇️](https://arxiv.org/pdf/2101.05507)
*Paul Knott, Micah Carroll, Sam Devlin, Kamil Ciosek, Katja Hofmann, A.  D. Dragan and Rohin Shah* 

  In order for agents trained by deep reinforcement learning to work alongside
humans in realistic settings, we will need to ensure that the agents are
\emph{robust}. Since the real world is very diverse, and human behavior often
changes in response to agent deployment, the agent will likely encounter novel
situations that have never been seen during training. This results in an
evaluation challenge: if we cannot rely on the average training or validation
reward as a metric, then how can we effectively evaluate robustness? We take
inspiration from the practice of \emph{unit testing} in software engineering.
Specifically, we suggest that when designing AI agents that collaborate with
humans, designers should search for potential edge cases in \emph{possible
partner behavior} and \emph{possible states encountered}, and write tests which
check that the behavior of the agent in these edge cases is reasonable. We
apply this methodology to build a suite of unit tests for the Overcooked-AI
environment, and use this test suite to evaluate three proposals for improving
robustness. We find that the test suite provides significant insight into the
effects of these proposals that were generally not revealed by looking solely
at the average validation reward.

---------------

### 27 Jun 2018 | [A comparative study of artificial intelligence and human doctors for the  purpose of triage and diagnosis](https://arxiv.org/abs/1806.10698) | [⬇️](https://arxiv.org/pdf/1806.10698)
*Salman Razzaki, Adam Baker, Yura Perov, Katherine Middleton, Janie  Baxter, Daniel Mullarkey, Davinder Sangar, Michael Taliercio, Mobasher Butt,  Azeem Majeed, Arnold DoRosario, Megan Mahoney, Saurabh Johri* 

  Online symptom checkers have significant potential to improve patient care,
however their reliability and accuracy remain variable. We hypothesised that an
artificial intelligence (AI) powered triage and diagnostic system would compare
favourably with human doctors with respect to triage and diagnostic accuracy.
We performed a prospective validation study of the accuracy and safety of an AI
powered triage and diagnostic system. Identical cases were evaluated by both an
AI system and human doctors. Differential diagnoses and triage outcomes were
evaluated by an independent judge, who was blinded from knowing the source (AI
system or human doctor) of the outcomes. Independently of these cases,
vignettes from publicly available resources were also assessed to provide a
benchmark to previous studies and the diagnostic component of the MRCGP exam.
Overall we found that the Babylon AI powered Triage and Diagnostic System was
able to identify the condition modelled by a clinical vignette with accuracy
comparable to human doctors (in terms of precision and recall). In addition, we
found that the triage advice recommended by the AI System was, on average,
safer than that of human doctors, when compared to the ranges of acceptable
triage provided by independent expert judges, with only a minimal reduction in
appropriateness.

---------------

### 24 Jan 2024 | [Can I trust my fake data -- A comprehensive quality assessment framework  for synthetic tabular data in healthcare](https://arxiv.org/abs/2401.13716) | [⬇️](https://arxiv.org/pdf/2401.13716)
*Vibeke Binz Vallevik, Aleksandar Babic, Serena Elizabeth Marshall,  Severin Elvatun, Helga Br{\o}gger, Sharmini Alagaratnam, Bj{\o}rn Edwin,  Narasimha Raghavan Veeraragavan, Anne Kjersti Befring, Jan Franz Nyg{\aa}rd* 

  Ensuring safe adoption of AI tools in healthcare hinges on access to
sufficient data for training, testing and validation. In response to privacy
concerns and regulatory requirements, using synthetic data has been suggested.
Synthetic data is created by training a generator on real data to produce a
dataset with similar statistical properties. Competing metrics with differing
taxonomies for quality evaluation have been suggested, resulting in a complex
landscape. Optimising quality entails balancing considerations that make the
data fit for use, yet relevant dimensions are left out of existing frameworks.
We performed a comprehensive literature review on the use of quality evaluation
metrics on SD within the scope of tabular healthcare data and SD made using
deep generative methods. Based on this and the collective team experiences, we
developed a conceptual framework for quality assurance. The applicability was
benchmarked against a practical case from the Dutch National Cancer Registry.
We present a conceptual framework for quality assurance of SD for AI
applications in healthcare that aligns diverging taxonomies, expands on common
quality dimensions to include the dimensions of Fairness and Carbon footprint,
and proposes stages necessary to support real-life applications. Building trust
in synthetic data by increasing transparency and reducing the safety risk will
accelerate the development and uptake of trustworthy AI tools for the benefit
of patients. Despite the growing emphasis on algorithmic fairness and carbon
footprint, these metrics were scarce in the literature review. The overwhelming
focus was on statistical similarity using distance metrics while sequential
logic detection was scarce. A consensus-backed framework that includes all
relevant quality dimensions can provide assurance for safe and responsible
real-life applications of SD.

---------------

### 10 Feb 2022 | [Integrating Testing and Operation-related Quantitative Evidences in  Assurance Cases to Argue Safety of Data-Driven AI/ML Components](https://arxiv.org/abs/2202.05313) | [⬇️](https://arxiv.org/pdf/2202.05313)
*Michael Kl\"as, Lisa J\"ockel, Rasmus Adler, Jan Reich* 

  In the future, AI will increasingly find its way into systems that can
potentially cause physical harm to humans. For such safety-critical systems, it
must be demonstrated that their residual risk does not exceed what is
acceptable. This includes, in particular, the AI components that are part of
such systems' safety-related functions. Assurance cases are an intensively
discussed option today for specifying a sound and comprehensive safety argument
to demonstrate a system's safety. In previous work, it has been suggested to
argue safety for AI components by structuring assurance cases based on two
complementary risk acceptance criteria. One of these criteria is used to derive
quantitative targets regarding the AI. The argumentation structures commonly
proposed to show the achievement of such quantitative targets, however, focus
on failure rates from statistical testing. Further important aspects are only
considered in a qualitative manner -- if at all. In contrast, this paper
proposes a more holistic argumentation structure for having achieved the
target, namely a structure that integrates test results with runtime aspects
and the impact of scope compliance and test data quality in a quantitative
manner. We elaborate different argumentation options, present the underlying
mathematical considerations, and discuss resulting implications for their
practical application. Using the proposed argumentation structure might not
only increase the integrity of assurance cases but may also allow claims on
quantitative targets that would not be justifiable otherwise.

---------------

### 22 Jul 2022 | [The effectiveness of feature attribution methods and its correlation  with automatic evaluation scores](https://arxiv.org/abs/2105.14944) | [⬇️](https://arxiv.org/pdf/2105.14944)
*Giang Nguyen, Daeyoung Kim, Anh Nguyen* 

  Explaining the decisions of an Artificial Intelligence (AI) model is
increasingly critical in many real-world, high-stake applications. Hundreds of
papers have either proposed new feature attribution methods, discussed or
harnessed these tools in their work. However, despite humans being the target
end-users, most attribution methods were only evaluated on proxy
automatic-evaluation metrics (Zhang et al. 2018; Zhou et al. 2016; Petsiuk et
al. 2018). In this paper, we conduct the first user study to measure
attribution map effectiveness in assisting humans in ImageNet classification
and Stanford Dogs fine-grained classification, and when an image is natural or
adversarial (i.e., contains adversarial perturbations). Overall, feature
attribution is surprisingly not more effective than showing humans nearest
training-set examples. On a harder task of fine-grained dog categorization,
presenting attribution maps to humans does not help, but instead hurts the
performance of human-AI teams compared to AI alone. Importantly, we found
automatic attribution-map evaluation measures to correlate poorly with the
actual human-AI team performance. Our findings encourage the community to
rigorously test their methods on the downstream human-in-the-loop applications
and to rethink the existing evaluation metrics.

---------------

### 13 Jun 2022 | [SyntheX: Scaling Up Learning-based X-ray Image Analysis Through In  Silico Experiments](https://arxiv.org/abs/2206.06127) | [⬇️](https://arxiv.org/pdf/2206.06127)
*Cong Gao, Benjamin D. Killeen, Yicheng Hu, Robert B. Grupp, Russell H.  Taylor, Mehran Armand, Mathias Unberath* 

  Artificial intelligence (AI) now enables automated interpretation of medical
images for clinical use. However, AI's potential use for interventional images
(versus those involved in triage or diagnosis), such as for guidance during
surgery, remains largely untapped. This is because surgical AI systems are
currently trained using post hoc analysis of data collected during live
surgeries, which has fundamental and practical limitations, including ethical
considerations, expense, scalability, data integrity, and a lack of ground
truth. Here, we demonstrate that creating realistic simulated images from human
models is a viable alternative and complement to large-scale in situ data
collection. We show that training AI image analysis models on realistically
synthesized data, combined with contemporary domain generalization or
adaptation techniques, results in models that on real data perform comparably
to models trained on a precisely matched real data training set. Because
synthetic generation of training data from human-based models scales easily, we
find that our model transfer paradigm for X-ray image analysis, which we refer
to as SyntheX, can even outperform real data-trained models due to the
effectiveness of training on a larger dataset. We demonstrate the potential of
SyntheX on three clinical tasks: Hip image analysis, surgical robotic tool
detection, and COVID-19 lung lesion segmentation. SyntheX provides an
opportunity to drastically accelerate the conception, design, and evaluation of
intelligent systems for X-ray-based medicine. In addition, simulated image
environments provide the opportunity to test novel instrumentation, design
complementary surgical approaches, and envision novel techniques that improve
outcomes, save time, or mitigate human error, freed from the ethical and
practical considerations of live human data collection.

---------------

### 29 Feb 2020 | [On Safety Assessment of Artificial Intelligence](https://arxiv.org/abs/2003.00260) | [⬇️](https://arxiv.org/pdf/2003.00260)
*Jens Braband and Hendrik Sch\"abe* 

  In this paper we discuss how systems with Artificial Intelligence (AI) can
undergo safety assessment. This is relevant, if AI is used in safety related
applications. Taking a deeper look into AI models, we show, that many models of
artificial intelligence, in particular machine learning, are statistical
models. Safety assessment would then have t o concentrate on the model that is
used in AI, besides the normal assessment procedure. Part of the budget of
dangerous random failures for the relevant safety integrity level needs to be
used for the probabilistic faulty behavior of the AI system. We demonstrate our
thoughts with a simple example and propose a research challenge that may be
decisive for the use of AI in safety related systems.

---------------

### 23 Nov 2022 | [Human or Machine? Turing Tests for Vision and Language](https://arxiv.org/abs/2211.13087) | [⬇️](https://arxiv.org/pdf/2211.13087)
*Mengmi Zhang, Giorgia Dellaferrera, Ankur Sikarwar, Marcelo  Armendariz, Noga Mudrik, Prachi Agrawal, Spandan Madan, Andrei Barbu, Haochen  Yang, Tanishq Kumar, Meghna Sadwani, Stella Dellaferrera, Michele Pizzochero,  Hanspeter Pfister, Gabriel Kreiman* 

  As AI algorithms increasingly participate in daily activities that used to be
the sole province of humans, we are inevitably called upon to consider how much
machines are really like us. To address this question, we turn to the Turing
test and systematically benchmark current AIs in their abilities to imitate
humans. We establish a methodology to evaluate humans versus machines in
Turing-like tests and systematically evaluate a representative set of selected
domains, parameters, and variables. The experiments involved testing 769 human
agents, 24 state-of-the-art AI agents, 896 human judges, and 8 AI judges, in
21,570 Turing tests across 6 tasks encompassing vision and language modalities.
Surprisingly, the results reveal that current AIs are not far from being able
to impersonate human judges across different ages, genders, and educational
levels in complex visual and language challenges. In contrast, simple AI judges
outperform human judges in distinguishing human answers versus machine answers.
The curated large-scale Turing test datasets introduced here and their
evaluation metrics provide valuable insights to assess whether an agent is
human or not. The proposed formulation to benchmark human imitation ability in
current AIs paves a way for the research community to expand Turing tests to
other research areas and conditions. All of source code and data are publicly
available at https://tinyurl.com/8x8nha7p

---------------

### 30 Jan 2024 | [A Preliminary Study on Using Large Language Models in Software  Pentesting](https://arxiv.org/abs/2401.17459) | [⬇️](https://arxiv.org/pdf/2401.17459)
*Kumar Shashwat, Francis Hahn, Xinming Ou, Dmitry Goldgof, Lawrence  Hall, Jay Ligatti, S. Raj Rajgopalan, Armin Ziaie Tabari* 

  Large language models (LLM) are perceived to offer promising potentials for
automating security tasks, such as those found in security operation centers
(SOCs). As a first step towards evaluating this perceived potential, we
investigate the use of LLMs in software pentesting, where the main task is to
automatically identify software security vulnerabilities in source code. We
hypothesize that an LLM-based AI agent can be improved over time for a specific
security task as human operators interact with it. Such improvement can be
made, as a first step, by engineering prompts fed to the LLM based on the
responses produced, to include relevant contexts and structures so that the
model provides more accurate results. Such engineering efforts become
sustainable if the prompts that are engineered to produce better results on
current tasks, also produce better results on future unknown tasks. To examine
this hypothesis, we utilize the OWASP Benchmark Project 1.2 which contains
2,740 hand-crafted source code test cases containing various types of
vulnerabilities. We divide the test cases into training and testing data, where
we engineer the prompts based on the training data (only), and evaluate the
final system on the testing data. We compare the AI agent's performance on the
testing data against the performance of the agent without the prompt
engineering. We also compare the AI agent's results against those from
SonarQube, a widely used static code analyzer for security testing. We built
and tested multiple versions of the AI agent using different off-the-shelf LLMs
-- Google's Gemini-pro, as well as OpenAI's GPT-3.5-Turbo and GPT-4-Turbo (with
both chat completion and assistant APIs). The results show that using LLMs is a
viable approach to build an AI agent for software pentesting that can improve
through repeated use and prompt engineering.

---------------

### 16 Nov 2023 | [Towards AI-controlled FES-restoration of movements: Learning cycling  stimulation pattern with reinforcement learning](https://arxiv.org/abs/2303.09986) | [⬇️](https://arxiv.org/pdf/2303.09986)
*Nat Wannawas, A. Aldo Faisal* 

  Functional electrical stimulation (FES) has been increasingly integrated with
other rehabilitation devices, including robots. FES cycling is one of the
common FES applications in rehabilitation, which is performed by stimulating
leg muscles in a certain pattern. The appropriate pattern varies across
individuals and requires manual tuning which can be time-consuming and
challenging for the individual user. Here, we present an AI-based method for
finding the patterns, which requires no extra hardware or sensors. Our method
has two phases, starting with finding model-based patterns using reinforcement
learning and detailed musculoskeletal models. The models, built using
open-source software, can be customised through our automated script and can be
therefore used by non-technical individuals without extra cost. Next, our
method fine-tunes the pattern using real cycling data. We test our both in
simulation and experimentally on a stationary tricycle. In the simulation test,
our method can robustly deliver model-based patterns for different cycling
configurations. The experimental evaluation shows that our method can find a
model-based pattern that induces higher cycling speed than an EMG-based
pattern. By using just 100 seconds of cycling data, our method can deliver a
fine-tuned pattern that gives better cycling performance. Beyond FES cycling,
this work is a showcase, displaying the feasibility and potential of
human-in-the-loop AI in real-world rehabilitation.

---------------

### 08 Oct 2019 | [Designing Trustworthy AI: A Human-Machine Teaming Framework to Guide  Development](https://arxiv.org/abs/1910.03515) | [⬇️](https://arxiv.org/pdf/1910.03515)
*Carol J. Smith* 

  Artificial intelligence (AI) holds great promise to empower us with knowledge
and augment our effectiveness. We can -- and must -- ensure that we keep humans
safe and in control, particularly with regard to government and public sector
applications that affect broad populations. How can AI development teams
harness the power of AI systems and design them to be valuable to humans?
Diverse teams are needed to build trustworthy artificial intelligent systems,
and those teams need to coalesce around a shared set of ethics. There are many
discussions in the AI field about ethics and trust, but there are few
frameworks available for people to use as guidance when creating these systems.
The Human-Machine Teaming (HMT) Framework for Designing Ethical AI Experiences
described in this paper, when used with a set of technical ethics, will guide
AI development teams to create AI systems that are accountable, de-risked,
respectful, secure, honest, and usable. To support the team's efforts,
activities to understand people's needs and concerns will be introduced along
with the themes to support the team's efforts. For example, usability testing
can help determine if the audience understands how the AI system works and
complies with the HMT Framework. The HMT Framework is based on reviews of
existing ethical codes and best practices in human-computer interaction and
software development. Human-machine teams are strongest when human users can
trust AI systems to behave as expected, safely, securely, and understandably.
Using the HMT Framework to design trustworthy AI systems will provide support
to teams in identifying potential issues ahead of time and making great
experiences for humans.

---------------

### 04 Apr 2023 | [Dialogue-Contextualized Re-ranking for Medical History-Taking](https://arxiv.org/abs/2304.01974) | [⬇️](https://arxiv.org/pdf/2304.01974)
*Jian Zhu, Ilya Valmianski, Anitha Kannan* 

  AI-driven medical history-taking is an important component in symptom
checking, automated patient intake, triage, and other AI virtual care
applications. As history-taking is extremely varied, machine learning models
require a significant amount of data to train. To overcome this challenge,
existing systems are developed using indirect data or expert knowledge. This
leads to a training-inference gap as models are trained on different kinds of
data than what they observe at inference time. In this work, we present a
two-stage re-ranking approach that helps close the training-inference gap by
re-ranking the first-stage question candidates using a dialogue-contextualized
model. For this, we propose a new model, global re-ranker, which cross-encodes
the dialogue with all questions simultaneously, and compare it with several
existing neural baselines. We test both transformer and S4-based language model
backbones. We find that relative to the expert system, the best performance is
achieved by our proposed global re-ranker with a transformer backbone,
resulting in a 30% higher normalized discount cumulative gain (nDCG) and a 77%
higher mean average precision (mAP).

---------------

### 21 Feb 2024 | [ED-Copilot: Reduce Emergency Department Wait Time with Language Model  Diagnostic Assistance](https://arxiv.org/abs/2402.13448) | [⬇️](https://arxiv.org/pdf/2402.13448)
*Liwen Sun, Abhineet Agarwal, Aaron Kornblith, Bin Yu, Chenyan Xiong* 

  In the emergency department (ED), patients undergo triage and multiple
laboratory tests before diagnosis. This process is time-consuming, and causes
ED crowding which significantly impacts patient mortality, medical errors,
staff burnout, etc. This work proposes (time) cost-effective diagnostic
assistance that explores the potential of artificial intelligence (AI) systems
in assisting ED clinicians to make time-efficient and accurate diagnoses. Using
publicly available patient data, we collaborate with ED clinicians to curate
MIMIC-ED-Assist, a benchmark that measures the ability of AI systems in
suggesting laboratory tests that minimize ED wait times, while correctly
predicting critical outcomes such as death. We develop ED-Copilot which
sequentially suggests patient-specific laboratory tests and makes diagnostic
predictions. ED-Copilot uses a pre-trained bio-medical language model to encode
patient information and reinforcement learning to minimize ED wait time and
maximize prediction accuracy of critical outcomes. On MIMIC-ED-Assist,
ED-Copilot improves prediction accuracy over baselines while halving average
wait time from four hours to two hours. Ablation studies demonstrate the
importance of model scale and use of a bio-medical language model. Further
analyses reveal the necessity of personalized laboratory test suggestions for
diagnosing patients with severe cases, as well as the potential of ED-Copilot
in providing ED clinicians with informative laboratory test recommendations.
Our code is available at https://github.com/cxcscmu/ED-Copilot.

---------------

### 21 Mar 2023 | [AI-in-the-Loop -- The impact of HMI in AI-based Application](https://arxiv.org/abs/2303.11508) | [⬇️](https://arxiv.org/pdf/2303.11508)
*Julius Sch\"oning and Clemens Westerkamp* 

  Artificial intelligence (AI) and human-machine interaction (HMI) are two
keywords that usually do not fit embedded applications. Within the steps needed
before applying AI to solve a specific task, HMI is usually missing during the
AI architecture design and the training of an AI model. The human-in-the-loop
concept is prevalent in all other steps of developing AI, from data analysis
via data selection and cleaning to performance evaluation. During AI
architecture design, HMI can immediately highlight unproductive layers of the
architecture so that lightweight network architecture for embedded applications
can be created easily. We show that by using this HMI, users can instantly
distinguish which AI architecture should be trained and evaluated first since a
high accuracy on the task could be expected. This approach reduces the
resources needed for AI development by avoiding training and evaluating AI
architectures with unproductive layers and leads to lightweight AI
architectures. These resulting lightweight AI architectures will enable HMI
while running the AI on an edge device. By enabling HMI during an AI uses
inference, we will introduce the AI-in-the-loop concept that combines AI's and
humans' strengths. In our AI-in-the-loop approach, the AI remains the working
horse and primarily solves the task. If the AI is unsure whether its inference
solves the task correctly, it asks the user to use an appropriate HMI.
Consequently, AI will become available in many applications soon since HMI will
make AI more reliable and explainable.

---------------

### 23 Sep 2011 | [Analysis of first prototype universal intelligence tests: evaluating and  comparing AI algorithms and humans](https://arxiv.org/abs/1109.5072) | [⬇️](https://arxiv.org/pdf/1109.5072)
*Javier Insa-Cabrera and Jose Hernandez-Orallo* 

  Today, available methods that assess AI systems are focused on using
empirical techniques to measure the performance of algorithms in some specific
tasks (e.g., playing chess, solving mazes or land a helicopter). However, these
methods are not appropriate if we want to evaluate the general intelligence of
AI and, even less, if we compare it with human intelligence. The ANYNT project
has designed a new method of evaluation that tries to assess AI systems using
well known computational notions and problems which are as general as possible.
This new method serves to assess general intelligence (which allows us to learn
how to solve any new kind of problem we face) and not only to evaluate
performance on a set of specific tasks. This method not only focuses on
measuring the intelligence of algorithms, but also to assess any intelligent
system (human beings, animals, AI, aliens?,...), and letting us to place their
results on the same scale and, therefore, to be able to compare them. This new
approach will allow us (in the future) to evaluate and compare any kind of
intelligent system known or even to build/find, be it artificial or biological.
This master thesis aims at ensuring that this new method provides consistent
results when evaluating AI algorithms, this is done through the design and
implementation of prototypes of universal intelligence tests and their
application to different intelligent systems (AI algorithms and humans beings).
From the study we analyze whether the results obtained by two different
intelligent systems are properly located on the same scale and we propose
changes and refinements to these prototypes in order to, in the future, being
able to achieve a truly universal intelligence test.

---------------

### 06 Dec 2023 | [OMNIINPUT: A Model-centric Evaluation Framework through Output  Distribution](https://arxiv.org/abs/2312.03291) | [⬇️](https://arxiv.org/pdf/2312.03291)
*Weitang Liu, Ying Wai Li, Tianle Wang, Yi-Zhuang You, Jingbo Shang* 

  We propose a novel model-centric evaluation framework, OmniInput, to evaluate
the quality of an AI/ML model's predictions on all possible inputs (including
human-unrecognizable ones), which is crucial for AI safety and reliability.
Unlike traditional data-centric evaluation based on pre-defined test sets, the
test set in OmniInput is self-constructed by the model itself and the model
quality is evaluated by investigating its output distribution. We employ an
efficient sampler to obtain representative inputs and the output distribution
of the trained model, which, after selective annotation, can be used to
estimate the model's precision and recall at different output values and a
comprehensive precision-recall curve. Our experiments demonstrate that
OmniInput enables a more fine-grained comparison between models, especially
when their performance is almost the same on pre-defined datasets, leading to
new findings and insights for how to train more robust, generalizable models.

---------------

### 27 Oct 2023 | [Knowledge-based in silico models and dataset for the comparative  evaluation of mammography AI for a range of breast characteristics, lesion  conspicuities and doses](https://arxiv.org/abs/2310.18494) | [⬇️](https://arxiv.org/pdf/2310.18494)
*Elena Sizikova, Niloufar Saharkhiz, Diksha Sharma, Miguel Lago,  Berkman Sahiner, Jana G. Delfino, Aldo Badano* 

  To generate evidence regarding the safety and efficacy of artificial
intelligence (AI) enabled medical devices, AI models need to be evaluated on a
diverse population of patient cases, some of which may not be readily
available. We propose an evaluation approach for testing medical imaging AI
models that relies on in silico imaging pipelines in which stochastic digital
models of human anatomy (in object space) with and without pathology are imaged
using a digital replica imaging acquisition system to generate realistic
synthetic image datasets. Here, we release M-SYNTH, a dataset of cohorts with
four breast fibroglandular density distributions imaged at different exposure
levels using Monte Carlo x-ray simulations with the publicly available Virtual
Imaging Clinical Trial for Regulatory Evaluation (VICTRE) toolkit. We utilize
the synthetic dataset to analyze AI model performance and find that model
performance decreases with increasing breast density and increases with higher
mass density, as expected. As exposure levels decrease, AI model performance
drops with the highest performance achieved at exposure levels lower than the
nominal recommended dose for the breast type.

---------------

### 21 Dec 2021 | [Towards a Science of Human-AI Decision Making: A Survey of Empirical  Studies](https://arxiv.org/abs/2112.11471) | [⬇️](https://arxiv.org/pdf/2112.11471)
*Vivian Lai, Chacha Chen, Q. Vera Liao, Alison Smith-Renner, Chenhao  Tan* 

  As AI systems demonstrate increasingly strong predictive performance, their
adoption has grown in numerous domains. However, in high-stakes domains such as
criminal justice and healthcare, full automation is often not desirable due to
safety, ethical, and legal concerns, yet fully manual approaches can be
inaccurate and time consuming. As a result, there is growing interest in the
research community to augment human decision making with AI assistance. Besides
developing AI technologies for this purpose, the emerging field of human-AI
decision making must embrace empirical approaches to form a foundational
understanding of how humans interact and work with AI to make decisions. To
invite and help structure research efforts towards a science of understanding
and improving human-AI decision making, we survey recent literature of
empirical human-subject studies on this topic. We summarize the study design
choices made in over 100 papers in three important aspects: (1) decision tasks,
(2) AI models and AI assistance elements, and (3) evaluation metrics. For each
aspect, we summarize current trends, discuss gaps in current practices of the
field, and make a list of recommendations for future research. Our survey
highlights the need to develop common frameworks to account for the design and
research spaces of human-AI decision making, so that researchers can make
rigorous choices in study design, and the research community can build on each
other's work and produce generalizable scientific knowledge. We also hope this
survey will serve as a bridge for HCI and AI communities to work together to
mutually shape the empirical science and computational technologies for
human-AI decision making.

---------------

### 03 Nov 2021 | [Certifiable Artificial Intelligence Through Data Fusion](https://arxiv.org/abs/2111.02001) | [⬇️](https://arxiv.org/pdf/2111.02001)
*Erik Blasch, Junchi Bin, Zheng Liu* 

  This paper reviews and proposes concerns in adopting, fielding, and
maintaining artificial intelligence (AI) systems. While the AI community has
made rapid progress, there are challenges in certifying AI systems. Using
procedures from design and operational test and evaluation, there are
opportunities towards determining performance bounds to manage expectations of
intended use. A notional use case is presented with image data fusion to
support AI object recognition certifiability considering precision versus
distance.

---------------
**Date:** 25 May 2023

**Title:** Comparing Software Developers with ChatGPT: An Empirical Investigation

**Abstract Link:** [https://arxiv.org/abs/2305.11837](https://arxiv.org/abs/2305.11837)

**PDF Link:** [https://arxiv.org/pdf/2305.11837](https://arxiv.org/pdf/2305.11837)

---

**Date:** 14 Jan 2021

**Title:** Evaluating the Robustness of Collaborative Agents

**Abstract Link:** [https://arxiv.org/abs/2101.05507](https://arxiv.org/abs/2101.05507)

**PDF Link:** [https://arxiv.org/pdf/2101.05507](https://arxiv.org/pdf/2101.05507)

---

**Date:** 27 Jun 2018

**Title:** A comparative study of artificial intelligence and human doctors for the  purpose of triage and diagnosis

**Abstract Link:** [https://arxiv.org/abs/1806.10698](https://arxiv.org/abs/1806.10698)

**PDF Link:** [https://arxiv.org/pdf/1806.10698](https://arxiv.org/pdf/1806.10698)

---

**Date:** 24 Jan 2024

**Title:** Can I trust my fake data -- A comprehensive quality assessment framework  for synthetic tabular data in healthcare

**Abstract Link:** [https://arxiv.org/abs/2401.13716](https://arxiv.org/abs/2401.13716)

**PDF Link:** [https://arxiv.org/pdf/2401.13716](https://arxiv.org/pdf/2401.13716)

---

**Date:** 10 Feb 2022

**Title:** Integrating Testing and Operation-related Quantitative Evidences in  Assurance Cases to Argue Safety of Data-Driven AI/ML Components

**Abstract Link:** [https://arxiv.org/abs/2202.05313](https://arxiv.org/abs/2202.05313)

**PDF Link:** [https://arxiv.org/pdf/2202.05313](https://arxiv.org/pdf/2202.05313)

---

**Date:** 22 Jul 2022

**Title:** The effectiveness of feature attribution methods and its correlation  with automatic evaluation scores

**Abstract Link:** [https://arxiv.org/abs/2105.14944](https://arxiv.org/abs/2105.14944)

**PDF Link:** [https://arxiv.org/pdf/2105.14944](https://arxiv.org/pdf/2105.14944)

---

**Date:** 13 Jun 2022

**Title:** SyntheX: Scaling Up Learning-based X-ray Image Analysis Through In  Silico Experiments

**Abstract Link:** [https://arxiv.org/abs/2206.06127](https://arxiv.org/abs/2206.06127)

**PDF Link:** [https://arxiv.org/pdf/2206.06127](https://arxiv.org/pdf/2206.06127)

---

**Date:** 29 Feb 2020

**Title:** On Safety Assessment of Artificial Intelligence

**Abstract Link:** [https://arxiv.org/abs/2003.00260](https://arxiv.org/abs/2003.00260)

**PDF Link:** [https://arxiv.org/pdf/2003.00260](https://arxiv.org/pdf/2003.00260)

---

**Date:** 23 Nov 2022

**Title:** Human or Machine? Turing Tests for Vision and Language

**Abstract Link:** [https://arxiv.org/abs/2211.13087](https://arxiv.org/abs/2211.13087)

**PDF Link:** [https://arxiv.org/pdf/2211.13087](https://arxiv.org/pdf/2211.13087)

---

**Date:** 30 Jan 2024

**Title:** A Preliminary Study on Using Large Language Models in Software  Pentesting

**Abstract Link:** [https://arxiv.org/abs/2401.17459](https://arxiv.org/abs/2401.17459)

**PDF Link:** [https://arxiv.org/pdf/2401.17459](https://arxiv.org/pdf/2401.17459)

---

**Date:** 16 Nov 2023

**Title:** Towards AI-controlled FES-restoration of movements: Learning cycling  stimulation pattern with reinforcement learning

**Abstract Link:** [https://arxiv.org/abs/2303.09986](https://arxiv.org/abs/2303.09986)

**PDF Link:** [https://arxiv.org/pdf/2303.09986](https://arxiv.org/pdf/2303.09986)

---

**Date:** 08 Oct 2019

**Title:** Designing Trustworthy AI: A Human-Machine Teaming Framework to Guide  Development

**Abstract Link:** [https://arxiv.org/abs/1910.03515](https://arxiv.org/abs/1910.03515)

**PDF Link:** [https://arxiv.org/pdf/1910.03515](https://arxiv.org/pdf/1910.03515)

---

**Date:** 04 Apr 2023

**Title:** Dialogue-Contextualized Re-ranking for Medical History-Taking

**Abstract Link:** [https://arxiv.org/abs/2304.01974](https://arxiv.org/abs/2304.01974)

**PDF Link:** [https://arxiv.org/pdf/2304.01974](https://arxiv.org/pdf/2304.01974)

---

**Date:** 21 Feb 2024

**Title:** ED-Copilot: Reduce Emergency Department Wait Time with Language Model  Diagnostic Assistance

**Abstract Link:** [https://arxiv.org/abs/2402.13448](https://arxiv.org/abs/2402.13448)

**PDF Link:** [https://arxiv.org/pdf/2402.13448](https://arxiv.org/pdf/2402.13448)

---

**Date:** 21 Mar 2023

**Title:** AI-in-the-Loop -- The impact of HMI in AI-based Application

**Abstract Link:** [https://arxiv.org/abs/2303.11508](https://arxiv.org/abs/2303.11508)

**PDF Link:** [https://arxiv.org/pdf/2303.11508](https://arxiv.org/pdf/2303.11508)

---

**Date:** 23 Sep 2011

**Title:** Analysis of first prototype universal intelligence tests: evaluating and  comparing AI algorithms and humans

**Abstract Link:** [https://arxiv.org/abs/1109.5072](https://arxiv.org/abs/1109.5072)

**PDF Link:** [https://arxiv.org/pdf/1109.5072](https://arxiv.org/pdf/1109.5072)

---

**Date:** 06 Dec 2023

**Title:** OMNIINPUT: A Model-centric Evaluation Framework through Output  Distribution

**Abstract Link:** [https://arxiv.org/abs/2312.03291](https://arxiv.org/abs/2312.03291)

**PDF Link:** [https://arxiv.org/pdf/2312.03291](https://arxiv.org/pdf/2312.03291)

---

**Date:** 27 Oct 2023

**Title:** Knowledge-based in silico models and dataset for the comparative  evaluation of mammography AI for a range of breast characteristics, lesion  conspicuities and doses

**Abstract Link:** [https://arxiv.org/abs/2310.18494](https://arxiv.org/abs/2310.18494)

**PDF Link:** [https://arxiv.org/pdf/2310.18494](https://arxiv.org/pdf/2310.18494)

---

**Date:** 21 Dec 2021

**Title:** Towards a Science of Human-AI Decision Making: A Survey of Empirical  Studies

**Abstract Link:** [https://arxiv.org/abs/2112.11471](https://arxiv.org/abs/2112.11471)

**PDF Link:** [https://arxiv.org/pdf/2112.11471](https://arxiv.org/pdf/2112.11471)

---

**Date:** 03 Nov 2021

**Title:** Certifiable Artificial Intelligence Through Data Fusion

**Abstract Link:** [https://arxiv.org/abs/2111.02001](https://arxiv.org/abs/2111.02001)

**PDF Link:** [https://arxiv.org/pdf/2111.02001](https://arxiv.org/pdf/2111.02001)

---

