Create a list of image title in unicode font with orange emojis

Here's a list of image titles in unicode font with orange emojis:

🍊 𝓜𝓸𝓷𝓴𝓮𝔂 𝓑𝓾𝓼𝓲𝓷𝓮𝓼𝓼 🍊
🍊 𝓢𝓾𝓷𝓼𝓮𝓽 𝓞𝓿𝓮𝓻 𝓽𝓱𝓮 𝓞𝓬𝓮𝓪𝓷 🍊
🍊 𝓑𝓵𝓸𝓼𝓼𝓸𝓶𝓲𝓷𝓰 𝓒𝓱𝓮𝓻𝓻𝓲𝓮𝓼 🍊
🍊 𝓐𝓷𝓬𝓲𝓮𝓷𝓽 𝓡𝓾𝓲𝓷𝓼 🍊
🍊 𝓦𝓲𝓷𝓽𝓮𝓻 𝓦𝓸𝓷𝓭𝓮𝓻𝓵𝓪𝓷𝓭 🍊
🍊 𝓒𝓸𝓼𝓶𝓲𝓬 𝓒𝓵𝓸𝓾𝓭𝓼 🍊
🍊 𝓢𝓮𝓻𝓮𝓷𝓮 𝓛𝓪𝓴𝓮 𝓥𝓲𝓮𝔀 🍊
🍊 𝓤𝓻𝓫𝓪𝓷 𝓙𝓾𝓷𝓰𝓵𝓮 🍊
🍊 𝓜𝓲𝓷𝓲𝓶𝓪𝓵𝓲𝓼𝓽 𝓟𝓸𝓻𝓽𝓻𝓪𝓲𝓽 🍊
🍊 𝓒𝓵𝓪𝓼𝓼𝓲𝓬 𝓒𝓪𝓻 𝓒𝓸𝓵𝓵𝓮𝓬𝓽𝓲𝓸𝓷 🍊