Create a list of Blue things

Here's a list of blue things:

1. Blueberries
2. Ocean
3. Sapphire
4. Denim jeans
5. Bluebird
6. Blueberry muffins
7. Cornflowers
8. Lapis lazuli
9. Blue whale
10. Bluebells
11. Blue cheese
12. Blue crayons
13. Blue ink
14. Blue topaz
15. Bluefish
16. Blue spruce
17. Blue morpho butterfly
18. Blue raspberries
19. Blue mosque (in Istanbul, Turkey)
20. Blue Monday (the day after a weekend)
21. Blue screen of death (in computing)
22. Blue danube (a waltz by Johann Strauss II)
23. Blue suede shoes
24. Blue ribbon (symbolizing first place)
25. Blue jay (a bird)