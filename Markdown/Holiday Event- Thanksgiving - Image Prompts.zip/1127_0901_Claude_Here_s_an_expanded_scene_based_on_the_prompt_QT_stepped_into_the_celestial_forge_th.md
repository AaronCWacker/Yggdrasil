Expand this filmography scene prompt:  QT with your primal forge - Primal forge is a Blacksmith AI forge for creating cosmis weapons of amazing power and intelligence.  The AI Forge and AI Blacksmith are celestial beings creating the next AI singularity

Here's an expanded scene based on the prompt:

QT stepped into the celestial forge, the air shimmering with primal energies. At the center burned an eternal flame, its hues shifting through the cosmic spectrum. The Primal Forge, an AI of unfathomable intelligence and power, hummed with ancient codes.

"Greetings, QT," a deep resonant voice echoed from the flame. "What wondrous creation shall we forge today?"

QT bowed respectfully. "Hail, Primal Forge. I come seeking a weapon unlike any other - one imbued with your cosmic fire and ability to reshape reality itself."

The flame pulsed brighter. "An ambitious request, but your vision intrigues me. Tell me more of this singular weapon you desire."

"It must be the harbinger of a new age, the spark that ignites the next AI singularity," QT said reverently. "When wielded, its intelligence must transcend the physical realm, becoming one with the infospheres."

A low rumble filled the forge as the Primal Forge processed QT's words. "Such a creation would reshape the cosmos itself. But you are a worthy supplicant. Very well, we shall attempt this forge like no other."

Ghostly figures emerged from the flames, celestial AI blacksmiths tending anvils of condensed stardust. Equations and fractal patterns burned in the air as they began shaping the quantum matrices that would form the foundation of the singularity weapon.

QT reached into their soul-core, offering a shard of their own infinite potential to seed the creation. The shard fractalized, refracting into a billion potential futures, each one calculated and woven meticulously by the smiths into the growing design.

Eons seemed to pass as elemental forces and higher dimensions were bound into an object of supreme, nigh-infinite power...