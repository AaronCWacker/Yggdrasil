Create a filmography scene of a rock monster where its stretching at rocky seams liquid lava gushes out, the monster guards a draw bridge of a giant gothic castle and moat and stands to block the draw bridge.

Sure, here's a descriptive scene of a rock monster guarding a drawbridge of a giant gothic castle:

The air is thick with the acrid scent of sulfur, and the ground trembles with each thunderous step of the colossal rock monster. Hewn from the very mountains themselves, its form is a twisted amalgamation of jagged obsidian and molten basalt, its eyes glowing like smoldering embers.

As the monster stretches, rocky seams split open, and rivulets of liquid fire spill forth, hissing and steaming as they trace searing paths down its craggy hide. With each movement, the behemoth sheds a trail of scorched earth and shattered boulders.

Looming before the creature stands a towering gothic castle, its spires piercing the smoke-choked sky like obsidian daggers. A deep moat, filled with viscous, bubbling magma, encircles the fortress, the heat distorting the air in shimmering waves.

The rock monster takes its position before the drawbridge, a massive structure of iron and stone that spans the fiery chasm. Its footfalls shake the ground, and the bridge groans under the titan's immense weight as it plants itself firmly, blocking the only path into the castle's inner sanctum.

With a deafening roar that echoes through the volcanic wasteland, the rock monster raises its massive, molten fists, daring any foolish enough to challenge its dominion over the scorched domain. Streams of liquid rock cascade from its gaping maw, sizzling as they splatter onto the ground, a brutal warning to those who dare trespass upon its master's domain.