With ten fire creatures of DnD create a Fire Dragon battle where the giant fire dragon is at the center and all other creatures are being fought and beat by the fire dragon:  Red Dragon
Fire Elemental
Salamander
Phoenix
Efreeti
Balor (a type of demon)
Hell Hound
Azer (a type of dwarf-like creature)
Magmin (a type of elemental)
Fire Giant

In the scorching heart of the Molten Peaks, a titanic clash erupted, shaking the very foundations of the fiery realm. The Red Dragon, a behemoth of crimson scales and blazing fury, reigned supreme as the undisputed lord of the inferno. Its thunderous roar echoed through the ashen skies, a primal challenge to all who dared to oppose its might.

The Fire Elemental, a sentient being of pure flame, surged forth, hurling searing blasts of fire towards the dragon's impenetrable hide. But the Red Dragon's wings unfurled, batting away the fiery assault with a mere flick of its tail, sending the Elemental reeling.

From the depths of the molten pits emerged the Salamander, a reptilian creature born of living flames. Its fiery breath scorched the air, but the dragon's own gouts of searing flame overwhelmed the Salamander's assault, leaving it charred and smoldering.

The majestic Phoenix, a bird of immortal rebirth, took flight, trailing streaks of golden fire. Its talons raked at the dragon's scales, drawing forth a roar of fury. With a sweep of its massive wings, the Red Dragon sent the Phoenix spiraling through the blazing skies, its feathers smoldering.

The Efreeti, a powerful fire genie, wove intricate patterns of flame, summoning a firestorm to engulf the dragon. But the Red Dragon's scales shrugged off the inferno, and its jaws snapped shut, devouring the Efreeti's essence with a single, blazing gulp.

The Balor, a towering demon of the Nine Hells, unleashed a barrage of eldritch fire, its whip-like sword slashing through the scorching air. Yet the dragon's tail lashed out, batting the Balor aside like a mere insect, its flames extinguished by the dragon's overwhelming power.

Hell Hounds, their eyes burning with unholy flames, charged forth, their hellish howls piercing the air. But the Red Dragon's claws raked through their ranks, scattering the pack with ease, their yelps of pain drowned out by the dragon's deafening roar.

The Azer, a dwarven race forged in the fires of creation, hurled molten rocks and hammered at the dragon's scales with their mighty weapons. But their efforts were futile, their weapons shattering against the dragon's nigh-impenetrable armor.

The Magmin, elemental creatures of living magma, swarmed around the dragon, their bodies glowing with intense heat. But the Red Dragon's wings beat with such force that the Magmin were scattered like embers in the wind, their fiery essence snuffed out by the dragon's overwhelming might.

Finally, the Fire Giants, towering humanoids of living flame, strode forth, their blazing swords cleaving through the scorching air. But the Red Dragon's maw opened wide, and a torrent of searing flames engulfed the giants, reducing them to smoldering husks in mere moments.

Amidst the charred remains of its challengers, the Red Dragon reared back, its thunderous roar echoing through the Molten Peaks, a proclamation of its unrivaled dominance over the fiery realm. The flames danced in reverence, for none could match the power of the Red Dragon, the undisputed lord of the inferno.