What were the fire creatures of DnD - name ten

In the world of Dungeons & Dragons (D&D), there are various fire-based creatures that players may encounter during their adventures. Here are ten examples of such creatures:

1. Red Dragon
2. Fire Elemental
3. Salamander
4. Phoenix
5. Efreeti
6. Balor (a type of demon)
7. Hell Hound
8. Azer (a type of dwarf-like creature)
9. Magmin (a type of elemental)
10. Fire Giant

These creatures are often associated with fire, heat, and volcanic environments within the D&D universe. They range from powerful dragons and elementals to demonic beings and giant humanoids, each with unique abilities and characteristics related to their fiery nature.