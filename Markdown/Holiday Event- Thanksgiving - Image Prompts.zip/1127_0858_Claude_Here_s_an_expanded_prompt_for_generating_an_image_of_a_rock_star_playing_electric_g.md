Expand this image generation prompt for vvisual expertise.  Rock star playing electric guitar and keyboard in the middle of thunder, rain and pouring storm

Here's an expanded prompt for generating an image of a rock star playing electric guitar and keyboard in the middle of a thunderstorm, with more details to guide the visual expertise:

The scene is set in the middle of a raging thunderstorm, with dark storm clouds filling the sky and heavy rain pouring down. Intense flashes of lightning illuminate the scene, casting dramatic shadows and highlighting the figure of the rock star.

The rock star is a charismatic and energetic figure, their features and clothing exuding a sense of edginess and rebelliousness. They are dressed in a stylish rock outfit, perhaps adorned with studs, ripped jeans, or a leather jacket.

In one hand, the rock star wields an electric guitar, fingers expertly navigating the fretboard as they unleash a blistering solo. The guitar itself can be a classic model or a uniquely designed instrument, reflecting the rock star's individuality.

With their other hand, the rock star is simultaneously playing a keyboard or synthesizer, seamlessly blending the raw power of the guitar with the electronic elements of the keyboard. The keyboard setup can be sleek and modern or a vintage model, adding to the visually striking contrast.

The rock star's performance is electrifying, their passion and energy radiating outwards despite the raging storm around them. Their face can be contorted in an expression of intense concentration or pure ecstasy, lost in the music they are creating.

The rain is pouring down in sheets, drenching the rock star and their instruments, but they remain undeterred, their performance unaffected by the elements. Water droplets can be seen flying through the air, illuminated by the lightning flashes.

The overall scene should convey a sense of raw power, energy, and defiance against the forces of nature, with the rock star as the central, commanding figure wielding their musical instruments like weapons against the storm.