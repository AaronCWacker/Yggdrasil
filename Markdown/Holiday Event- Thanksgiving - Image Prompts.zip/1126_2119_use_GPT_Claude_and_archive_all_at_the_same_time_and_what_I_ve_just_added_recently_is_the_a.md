use GPT Claude and archive all at the same time
 and what I've just added recently is the ability to talk to it in real time
 and so it is doing live real-time speech transcription directly to the interface
 and here we go what we're going to do is we're going to ask it to solve a challenge so here's the challenge
 give me 10 ideas to participate in evaluation study of sorting different types of artificial intelligence evaluation and using crowdsourcing and multiple users evaluation based on what they see and what they like they dislike and what they score on a scale of 0 to 10 along with any verbal feedback that they can supply in this evaluation then results in a better and better output by having the AI use that same criteria for scoring

### 🔎 use GPT Claude and archive all at the same time
 and what I've just added recently is the ability to talk to it in real time
 and so it is doing live real-time speech transcription directly to the interface
 and here we go what we're going to do is we're going to ask it to solve a challenge so here's the challenge
 give me 10 ideas to participate in evaluation study of sorting different types of artificial intelligence evaluation and using crowdsourcing and multiple users evaluation based on what they see and what they like they dislike and what they score on a scale of 0 to 10 along with any verbal feedback that they can supply in this evaluation then results in a better and better output by having the AI use that same criteria for scoring

 and then improving its output based on that feedback and here's the output
 1. Use a platform like Amazon Mechanical Turk or Upwork to recruit a diverse group of participants for the evaluation study.
 2. Create a detailed survey with specific questions about the different types of artificial intelligence being evaluated, including their strengths and weaknesses.
 3. Incorporate a rating system for participants to score the AI on a scale of 0 to 10, with clear instructions on what each score represents.
 4. Encourage participants to provide verbal feedback on their experience with the AI, including what they liked and disliked.
 5. Use a crowdsourcing platform like Figure Eight or Appen to manage the evaluation study and collect data from multiple users.
 6. Implement a real-time feedback system, allowing participants to see how their feedback is impacting the AI's output.
 7. Use machine learning algorithms to analyze the data collected from the evaluation study and improve the AI's output based on the feedback received.
 8. Continuously iterate on the evaluation study, incorporating new types of AI and refining the questions and rating system as needed.
 9. Provide incentives for participants to complete the evaluation study, such as monetary rewards or access to exclusive features.
 10. Share the results of the evaluation study with the wider AI community, contributing to the ongoing development and improvement of artificial intelligence.











































































































































































































# 🩺🔍 Search Results
### 22 Dec 2020 | [A Hierarchical Reasoning Graph Neural Network for The Automatic Scoring  of Answer Transcriptions in Video Job Interviews](https://arxiv.org/abs/2012.11960) | [⬇️](https://arxiv.org/pdf/2012.11960)
*Kai Chen, Meng Niu, Qingcai Chen* 

  We address the task of automatically scoring the competency of candidates
based on textual features, from the automatic speech recognition (ASR)
transcriptions in the asynchronous video job interview (AVI). The key challenge
is how to construct the dependency relation between questions and answers, and
conduct the semantic level interaction for each question-answer (QA) pair.
However, most of the recent studies in AVI focus on how to represent questions
and answers better, but ignore the dependency information and interaction
between them, which is critical for QA evaluation. In this work, we propose a
Hierarchical Reasoning Graph Neural Network (HRGNN) for the automatic
assessment of question-answer pairs. Specifically, we construct a
sentence-level relational graph neural network to capture the dependency
information of sentences in or between the question and the answer. Based on
these graphs, we employ a semantic-level reasoning graph attention network to
model the interaction states of the current QA session. Finally, we propose a
gated recurrent unit encoder to represent the temporal question-answer pairs
for the final prediction. Empirical results conducted on CHNAT (a real-world
dataset) validate that our proposed model significantly outperforms
text-matching based benchmark models. Ablation studies and experimental results
with 10 random seeds also show the effectiveness and stability of our models.

---------------

### 03 Nov 2023 | [Improving Interpersonal Communication by Simulating Audiences with  Language Models](https://arxiv.org/abs/2311.00687) | [⬇️](https://arxiv.org/pdf/2311.00687)
*Ryan Liu and Howard Yen and Raja Marjieh and Thomas L. Griffiths and  Ranjay Krishna* 

  How do we communicate with others to achieve our goals? We use our prior
experience or advice from others, or construct a candidate utterance by
predicting how it will be received. However, our experiences are limited and
biased, and reasoning about potential outcomes can be difficult and cognitively
challenging. In this paper, we explore how we can leverage Large Language Model
(LLM) simulations to help us communicate better. We propose the
Explore-Generate-Simulate (EGS) framework, which takes as input any scenario
where an individual is communicating to an audience with a goal they want to
achieve. EGS (1) explores the solution space by producing a diverse set of
advice relevant to the scenario, (2) generates communication candidates
conditioned on subsets of the advice, and (3) simulates the reactions from
various audiences to determine both the best candidate and advice to use. We
evaluate the framework on eight scenarios spanning the ten fundamental
processes of interpersonal communication. For each scenario, we collect a
dataset of human evaluations across candidates and baselines, and showcase that
our framework's chosen candidate is preferred over popular generation
mechanisms including Chain-of-Thought. We also find that audience simulations
achieve reasonably high agreement with human raters across 5 of the 8
scenarios. Finally, we demonstrate the generality of our framework by applying
it to real-world scenarios described by users on web forums. Through
evaluations and demonstrations, we show that EGS enhances the effectiveness and
outcomes of goal-oriented communication across a variety of situations, thus
opening up new possibilities for the application of large language models in
revolutionizing communication and decision-making processes.

---------------

### 22 Aug 2023 | [Learning to generate and corr- uh I mean repair language in real-time](https://arxiv.org/abs/2308.11683) | [⬇️](https://arxiv.org/pdf/2308.11683)
*Arash Eshghi, Arash Ashrafzadeh* 

  In conversation, speakers produce language incrementally, word by word, while
continuously monitoring the appropriateness of their own contribution in the
dynamically unfolding context of the conversation; and this often leads them to
repair their own utterance on the fly. This real-time language processing
capacity is furthermore crucial to the development of fluent and natural
conversational AI. In this paper, we use a previously learned Dynamic Syntax
grammar and the CHILDES corpus to develop, train and evaluate a probabilistic
model for incremental generation where input to the model is a purely semantic
generation goal concept in Type Theory with Records (TTR). We show that the
model's output exactly matches the gold candidate in 78% of cases with a
ROUGE-l score of 0.86. We further do a zero-shot evaluation of the ability of
the same model to generate self-repairs when the generation goal changes
mid-utterance. Automatic evaluation shows that the model can generate
self-repairs correctly in 85% of cases. A small human evaluation confirms the
naturalness and grammaticality of the generated self-repairs. Overall, these
results further highlight the generalisation power of grammar-based models and
lay the foundations for more controllable, and naturally interactive
conversational AI systems.

---------------

### 26 Aug 2020 | [Machine learning approach of Japanese composition scoring and writing  aided system's design](https://arxiv.org/abs/2008.11488) | [⬇️](https://arxiv.org/pdf/2008.11488)
*Wanhong Huang* 

  Automatic scoring system is extremely complex for any language. Because
natural language itself is a complex model. When we evaluate articles generated
by natural language, we need to view the articles from many dimensions such as
word features, grammatical features, semantic features, text structure and so
on. Even human beings sometimes can't accurately grade a composition because
different people have different opinions about the same article. But a
composition scoring system can greatly assist language learners. It can make
language leaner improve themselves in the process of output something. Though
it is still difficult for machines to directly evaluate a composition at the
semantic and pragmatic levels, especially for Japanese, Chinese and other
language in high context cultures, we can make machine evaluate a passage in
word and grammar levels, which can as an assistance of composition rater or
language learner. Especially for foreign language learners, lexical and
syntactic content are usually what they are more concerned about. In our
experiments, we did the follows works: 1) We use word segmentation tools and
dictionaries to achieve word segmentation of an article, and extract word
features, as well as generate a words' complexity feature of an article. And
Bow technique are used to extract the theme features. 2) We designed a
Turing-complete automata model and create 300+ automatons for the grammars that
appear in the JLPT examination. And extract grammars features by using these
automatons. 3) We propose a statistical approach for scoring a specify theme of
composition, the final score will depend on all the writings that submitted to
the system. 4) We design an grammar hint function for language leaner, so that
they can know currently what grammars they can use.

---------------

### 05 Jun 2020 | [Human or Machine: Automating Human Likeliness Evaluation of NLG Texts](https://arxiv.org/abs/2006.03189) | [⬇️](https://arxiv.org/pdf/2006.03189)
*Erion \c{C}ano and Ond\v{r}ej Bojar* 

  Automatic evaluation of various text quality criteria produced by data-driven
intelligent methods is very common and useful because it is cheap, fast, and
usually yields repeatable results. In this paper, we present an attempt to
automate the human likeliness evaluation of the output text samples coming from
natural language generation methods used to solve several tasks. We propose to
use a human likeliness score that shows the percentage of the output samples
from a method that look as if they were written by a human. Instead of having
human participants label or rate those samples, we completely automate the
process by using a discrimination procedure based on large pretrained language
models and their probability distributions. As follow up, we plan to perform an
empirical analysis of human-written and machine-generated texts to find the
optimal setup of this evaluation approach. A validation procedure involving
human participants will also check how the automatic evaluation correlates with
human judgments.

---------------

### 30 Jan 2024 | [Synthetic Dialogue Dataset Generation using LLM Agents](https://arxiv.org/abs/2401.17461) | [⬇️](https://arxiv.org/pdf/2401.17461)
*Yelaman Abdullin, Diego Molla-Aliod, Bahadorreza Ofoghi, John  Yearwood, Qingyang Li* 

  Linear programming (LP) problems are pervasive in real-life applications.
However, despite their apparent simplicity, an untrained user may find it
difficult to determine the linear model of their specific problem. We envisage
the creation of a goal-oriented conversational agent that will engage in
conversation with the user to elicit all information required so that a
subsequent agent can generate the linear model. In this paper, we present an
approach for the generation of sample dialogues that can be used to develop and
train such a conversational agent. Using prompt engineering, we develop two
agents that "talk" to each other, one acting as the conversational agent, and
the other acting as the user. Using a set of text descriptions of linear
problems from NL4Opt available to the user only, the agent and the user engage
in conversation until the agent has retrieved all key information from the
original problem description. We also propose an extrinsic evaluation of the
dialogues by assessing how well the summaries generated by the dialogues match
the original problem descriptions. We conduct human and automatic evaluations,
including an evaluation approach that uses GPT-4 to mimic the human evaluation
metrics. The evaluation results show an overall good quality of the dialogues,
though research is still needed to improve the quality of the GPT-4 evaluation
metrics. The resulting dialogues, including the human annotations of a subset,
are available to the research community. The conversational agent used for the
generation of the dialogues can be used as a baseline.

---------------

### 17 Dec 2023 | [LLMEval: A Preliminary Study on How to Evaluate Large Language Models](https://arxiv.org/abs/2312.07398) | [⬇️](https://arxiv.org/pdf/2312.07398)
*Yue Zhang, Ming Zhang, Haipeng Yuan, Shichun Liu, Yongyao Shi, Tao  Gui, Qi Zhang and Xuanjing Huang* 

  Recently, the evaluation of Large Language Models has emerged as a popular
area of research. The three crucial questions for LLM evaluation are ``what,
where, and how to evaluate''. However, the existing research mainly focuses on
the first two questions, which are basically what tasks to give the LLM during
testing and what kind of knowledge it should deal with. As for the third
question, which is about what standards to use, the types of evaluators, how to
score, and how to rank, there hasn't been much discussion. In this paper, we
analyze evaluation methods by comparing various criteria with both manual and
automatic evaluation, utilizing onsite, crowd-sourcing, public annotators and
GPT-4, with different scoring methods and ranking systems. We propose a new
dataset, LLMEval and conduct evaluations on 20 LLMs. A total of 2,186
individuals participated, leading to the generation of 243,337 manual
annotations and 57,511 automatic evaluation results. We perform comparisons and
analyses of different settings and conduct 10 conclusions that can provide some
insights for evaluating LLM in the future. The dataset and the results are
publicly available at https://github.com/llmeval .

---------------

### 30 Jun 2021 | [Towards the evaluation of automatic simultaneous speech translation from  a communicative perspective](https://arxiv.org/abs/2103.08364) | [⬇️](https://arxiv.org/pdf/2103.08364)
*Claudio Fantinuoli, Bianca Prandi* 

  In recent years, automatic speech-to-speech and speech-to-text translation
has gained momentum thanks to advances in artificial intelligence, especially
in the domains of speech recognition and machine translation. The quality of
such applications is commonly tested with automatic metrics, such as BLEU,
primarily with the goal of assessing improvements of releases or in the context
of evaluation campaigns. However, little is known about how the output of such
systems is perceived by end users or how they compare to human performances in
similar communicative tasks.
  In this paper, we present the results of an experiment aimed at evaluating
the quality of a real-time speech translation engine by comparing it to the
performance of professional simultaneous interpreters. To do so, we adopt a
framework developed for the assessment of human interpreters and use it to
perform a manual evaluation on both human and machine performances. In our
sample, we found better performance for the human interpreters in terms of
intelligibility, while the machine performs slightly better in terms of
informativeness. The limitations of the study and the possible enhancements of
the chosen framework are discussed. Despite its intrinsic limitations, the use
of this framework represents a first step towards a user-centric and
communication-oriented methodology for evaluating real-time automatic speech
translation.

---------------

### 13 Jun 2023 | [Speech Enhancement and Dereverberation with Diffusion-based Generative  Models](https://arxiv.org/abs/2208.05830) | [⬇️](https://arxiv.org/pdf/2208.05830)
*Julius Richter, Simon Welker, Jean-Marie Lemercier, Bunlong Lay, Timo  Gerkmann* 

  In this work, we build upon our previous publication and use diffusion-based
generative models for speech enhancement. We present a detailed overview of the
diffusion process that is based on a stochastic differential equation and delve
into an extensive theoretical examination of its implications. Opposed to usual
conditional generation tasks, we do not start the reverse process from pure
Gaussian noise but from a mixture of noisy speech and Gaussian noise. This
matches our forward process which moves from clean speech to noisy speech by
including a drift term. We show that this procedure enables using only 30
diffusion steps to generate high-quality clean speech estimates. By adapting
the network architecture, we are able to significantly improve the speech
enhancement performance, indicating that the network, rather than the
formalism, was the main limitation of our original approach. In an extensive
cross-dataset evaluation, we show that the improved method can compete with
recent discriminative models and achieves better generalization when evaluating
on a different corpus than used for training. We complement the results with an
instrumental evaluation using real-world noisy recordings and a listening
experiment, in which our proposed method is rated best. Examining different
sampler configurations for solving the reverse process allows us to balance the
performance and computational speed of the proposed method. Moreover, we show
that the proposed method is also suitable for dereverberation and thus not
limited to additive background noise removal. Code and audio examples are
available online, see https://github.com/sp-uhh/sgmse

---------------

### 06 Jul 2021 | [Location, Location: Enhancing the Evaluation of Text-to-Speech Synthesis  Using the Rapid Prosody Transcription Paradigm](https://arxiv.org/abs/2107.02527) | [⬇️](https://arxiv.org/pdf/2107.02527)
*Elijah Gutierrez, Pilar Oplustil-Gallegos, Catherine Lai* 

  Text-to-Speech synthesis systems are generally evaluated using Mean Opinion
Score (MOS) tests, where listeners score samples of synthetic speech on a
Likert scale. A major drawback of MOS tests is that they only offer a general
measure of overall quality-i.e., the naturalness of an utterance-and so cannot
tell us where exactly synthesis errors occur. This can make evaluation of the
appropriateness of prosodic variation within utterances inconclusive. To
address this, we propose a novel evaluation method based on the Rapid Prosody
Transcription paradigm. This allows listeners to mark the locations of errors
in an utterance in real-time, providing a probabilistic representation of the
perceptual errors that occur in the synthetic signal. We conduct experiments
that confirm that the fine-grained evaluation can be mapped to system rankings
of standard MOS tests, but the error marking gives a much more comprehensive
assessment of synthesized prosody. In particular, for standard audiobook test
set samples, we see that error marks consistently cluster around words at major
prosodic boundaries indicated by punctuation. However, for question-answer
based stimuli, where we control information structure, we see differences
emerge in the ability of neural TTS systems to generate context-appropriate
prosodic prominence.

---------------

### 19 Sep 2023 | [Large Language Models are Diverse Role-Players for Summarization  Evaluation](https://arxiv.org/abs/2303.15078) | [⬇️](https://arxiv.org/pdf/2303.15078)
*Ning Wu, Ming Gong, Linjun Shou, Shining Liang, Daxin Jiang* 

  Text summarization has a wide range of applications in many scenarios. The
evaluation of the quality of the generated text is a complex problem. A big
challenge to language evaluation is that there is a clear divergence between
existing metrics and human evaluation. A document summary's quality can be
assessed by human annotators on various criteria, both objective ones like
grammar and correctness, and subjective ones like informativeness,
succinctness, and appeal. Most of the automatic evaluation methods like
BLUE/ROUGE may be not able to adequately capture the above dimensions. In this
paper, we propose a new evaluation framework based on LLMs, which provides a
comprehensive evaluation framework by comparing generated text and reference
text from both objective and subjective aspects. First, we propose to model
objective and subjective dimensions of generated text based on roleplayers
prompting mechanism. Furthermore, we introduce a context-based prompting
mechanism that is able to generate dynamic roleplayer profiles based on input
context. Finally, we design a multi-roleplayer prompting technology based on
batch prompting and integrate multiple outputs into the final evaluation
results. Experimental results on three real datasets for summarization show
that our model is highly competitive and has a very high consistency with human
annotators.

---------------

### 12 Oct 2023 | [MINT: Evaluating LLMs in Multi-turn Interaction with Tools and Language  Feedback](https://arxiv.org/abs/2309.10691) | [⬇️](https://arxiv.org/pdf/2309.10691)
*Xingyao Wang, Zihan Wang, Jiateng Liu, Yangyi Chen, Lifan Yuan, Hao  Peng, Heng Ji* 

  To solve complex tasks, large language models (LLMs) often require multiple
rounds of interactions with the user, sometimes assisted by external tools.
However, current evaluation protocols often emphasize benchmark performance
with single-turn exchanges, neglecting the nuanced interactions among the user,
LLMs, and external tools, while also underestimating the importance of natural
language feedback from users. These oversights contribute to discrepancies
between research benchmark evaluations and real-world use cases. We introduce
MINT, a benchmark that evaluates LLMs' ability to solve tasks with multi-turn
interactions by (1) using tools and (2) leveraging natural language feedback.
To ensure reproducibility, we provide an evaluation framework where LLMs can
access tools by executing Python code and receive users' natural language
feedback simulated by GPT-4. We repurpose a diverse set of established
evaluation datasets focusing on reasoning, coding, and decision-making and
carefully curate them into a compact subset for efficient evaluation. Our
analysis of 20 open- and closed-source LLMs offers intriguing findings. (a)
LLMs generally benefit from tools and language feedback, with performance gains
(absolute, same below) of 1-8% for each turn of tool use and 2-17% with natural
language feedback. (b) Better single-turn performance does not guarantee better
multi-turn performance. (c) Surprisingly, on the LLMs evaluated, supervised
instruction-finetuning (SIFT) and reinforcement learning from human feedback
(RLHF) generally hurt multi-turn capabilities. We expect MINT can help measure
progress and incentivize research in improving LLMs' capabilities in multi-turn
interactions, especially for open-source communities where multi-turn human
evaluation can be less accessible compared to commercial LLMs with a larger
user base.

---------------

### 25 Aug 2023 | [Approximating Online Human Evaluation of Social Chatbots with Prompting](https://arxiv.org/abs/2304.05253) | [⬇️](https://arxiv.org/pdf/2304.05253)
*Ekaterina Svikhnushina and Pearl Pu* 

  As conversational models become increasingly available to the general public,
users are engaging with this technology in social interactions. Such
unprecedented interaction experiences may pose considerable social and
psychological risks to the users unless the technology is properly controlled.
This highlights the need for scalable and robust evaluation metrics for
conversational chatbots. Existing evaluation metrics aim to automate offline
user evaluation and approximate human judgment of pre-curated dialogs. However,
they are limited in their ability to capture subjective perceptions of users
who actually interact with the bots and might not generalize to real-world
settings. To address this limitation, we propose an approach to approximate
online human evaluation leveraging large language models (LLMs) from the GPT
family. We introduce a new Dialog system Evaluation framework based on
Prompting (DEP), which enables a fully automatic evaluation pipeline that
replicates live user studies and achieves an impressive correlation with human
judgment (up to Pearson r=0.95 on a system level). The DEP approach involves
collecting synthetic chat logs of evaluated bots with an LLM in the other-play
setting, where the LLM is carefully conditioned to follow a specific scenario.
We further explore different prompting approaches to produce evaluation scores
with the same LLM. The best performing prompts, which contain few-shot
demonstrations and instructions, show outstanding performance on the tested
dataset and demonstrate the ability to generalize to other dialog corpora.

---------------

### 16 May 2022 | [The AI Teacher Test: Measuring the Pedagogical Ability of Blender and  GPT-3 in Educational Dialogues](https://arxiv.org/abs/2205.07540) | [⬇️](https://arxiv.org/pdf/2205.07540)
*Ana\"is Tack and Chris Piech* 

  How can we test whether state-of-the-art generative models, such as Blender
and GPT-3, are good AI teachers, capable of replying to a student in an
educational dialogue? Designing an AI teacher test is challenging: although
evaluation methods are much-needed, there is no off-the-shelf solution to
measuring pedagogical ability. This paper reports on a first attempt at an AI
teacher test. We built a solution around the insight that you can run
conversational agents in parallel to human teachers in real-world dialogues,
simulate how different agents would respond to a student, and compare these
counterpart responses in terms of three abilities: speak like a teacher,
understand a student, help a student. Our method builds on the reliability of
comparative judgments in education and uses a probabilistic model and Bayesian
sampling to infer estimates of pedagogical ability. We find that, even though
conversational agents (Blender in particular) perform well on conversational
uptake, they are quantifiably worse than real teachers on several pedagogical
dimensions, especially with regard to helpfulness (Blender: {\Delta} ability =
-0.75; GPT-3: {\Delta} ability = -0.93).

---------------

### 09 May 2020 | [LinCE: A Centralized Benchmark for Linguistic Code-switching Evaluation](https://arxiv.org/abs/2005.04322) | [⬇️](https://arxiv.org/pdf/2005.04322)
*Gustavo Aguilar, Sudipta Kar, and Thamar Solorio* 

  Recent trends in NLP research have raised an interest in linguistic
code-switching (CS); modern approaches have been proposed to solve a wide range
of NLP tasks on multiple language pairs. Unfortunately, these proposed methods
are hardly generalizable to different code-switched languages. In addition, it
is unclear whether a model architecture is applicable for a different task
while still being compatible with the code-switching setting. This is mainly
because of the lack of a centralized benchmark and the sparse corpora that
researchers employ based on their specific needs and interests. To facilitate
research in this direction, we propose a centralized benchmark for Linguistic
Code-switching Evaluation (LinCE) that combines ten corpora covering four
different code-switched language pairs (i.e., Spanish-English, Nepali-English,
Hindi-English, and Modern Standard Arabic-Egyptian Arabic) and four tasks
(i.e., language identification, named entity recognition, part-of-speech
tagging, and sentiment analysis). As part of the benchmark centralization
effort, we provide an online platform at ritual.uh.edu/lince, where researchers
can submit their results while comparing with others in real-time. In addition,
we provide the scores of different popular models, including LSTM, ELMo, and
multilingual BERT so that the NLP community can compare against
state-of-the-art systems. LinCE is a continuous effort, and we will expand it
with more low-resource languages and tasks.

---------------

### 04 Nov 2019 | [Approximating Interactive Human Evaluation with Self-Play for  Open-Domain Dialog Systems](https://arxiv.org/abs/1906.09308) | [⬇️](https://arxiv.org/pdf/1906.09308)
*Asma Ghandeharioun, Judy Hanwen Shen, Natasha Jaques, Craig Ferguson,  Noah Jones, Agata Lapedriza, Rosalind Picard* 

  Building an open-domain conversational agent is a challenging problem.
Current evaluation methods, mostly post-hoc judgments of static conversation,
do not capture conversation quality in a realistic interactive context. In this
paper, we investigate interactive human evaluation and provide evidence for its
necessity; we then introduce a novel, model-agnostic, and dataset-agnostic
method to approximate it. In particular, we propose a self-play scenario where
the dialog system talks to itself and we calculate a combination of proxies
such as sentiment and semantic coherence on the conversation trajectory. We
show that this metric is capable of capturing the human-rated quality of a
dialog model better than any automated metric known to-date, achieving a
significant Pearson correlation (r>.7, p<.05). To investigate the strengths of
this novel metric and interactive evaluation in comparison to state-of-the-art
metrics and human evaluation of static conversations, we perform extended
experiments with a set of models, including several that make novel
improvements to recent hierarchical dialog generation architectures through
sentiment and semantic knowledge distillation on the utterance level. Finally,
we open-source the interactive evaluation platform we built and the dataset we
collected to allow researchers to efficiently deploy and evaluate dialog
models.

---------------

### 07 Mar 2018 | [Automating Reading Comprehension by Generating Question and Answer Pairs](https://arxiv.org/abs/1803.03664) | [⬇️](https://arxiv.org/pdf/1803.03664)
*Vishwajeet Kumar, Kireeti Boorla, Yogesh Meena, Ganesh Ramakrishnan  and Yuan-Fang Li* 

  Neural network-based methods represent the state-of-the-art in question
generation from text. Existing work focuses on generating only questions from
text without concerning itself with answer generation. Moreover, our analysis
shows that handling rare words and generating the most appropriate question
given a candidate answer are still challenges facing existing approaches. We
present a novel two-stage process to generate question-answer pairs from the
text. For the first stage, we present alternatives for encoding the span of the
pivotal answer in the sentence using Pointer Networks. In our second stage, we
employ sequence to sequence models for question generation, enhanced with rich
linguistic features. Finally, global attention and answer encoding are used for
generating the question most relevant to the answer. We motivate and
linguistically analyze the role of each component in our framework and consider
compositions of these. This analysis is supported by extensive experimental
evaluations. Using standard evaluation metrics as well as human evaluations,
our experimental results validate the significant improvement in the quality of
questions generated by our framework over the state-of-the-art. The technique
presented here represents another step towards more automated reading
comprehension assessment. We also present a live system \footnote{Demo of the
system is available at
\url{https://www.cse.iitb.ac.in/~vishwajeet/autoqg.html}.} to demonstrate the
effectiveness of our approach.

---------------

### 13 Oct 2022 | [Real-Time Automated Answer Scoring](https://arxiv.org/abs/2210.09004) | [⬇️](https://arxiv.org/pdf/2210.09004)
*Akash Nagaraj, Mukund Sood and Gowri Srinivasa* 

  In recent years, the role of big data analytics has exponentially grown and
is now slowly making its way into the education industry. Several attempts are
being made in this sphere in order to improve the quality of education being
provided to students and while many collaborations have been carried out
before, automated scoring of answers has been explored to a rather limited
extent. One of the biggest hurdles to choosing constructed-response assessments
over multiple-choice assessments is the effort and large cost that comes with
their evaluation and this is precisely the issue that this project aims to
solve. The aim is to accept raw-input from the student in the form of their
answer, preprocess the answer, and automatically score the answer. In addition,
we have made this a real-time system that captures "snapshots" of the writer's
progress with respect to the answer, allowing us to unearth trends with respect
to the way a student thinks, and how the student has arrived at their final
answer.

---------------

### 11 Jan 2016 | [Evaluating the Performance of a Speech Recognition based System](https://arxiv.org/abs/1601.02543) | [⬇️](https://arxiv.org/pdf/1601.02543)
*Vinod Kumar Pandey, Sunil Kumar Kopparapu* 

  Speech based solutions have taken center stage with growth in the services
industry where there is a need to cater to a very large number of people from
all strata of the society. While natural language speech interfaces are the
talk in the research community, yet in practice, menu based speech solutions
thrive. Typically in a menu based speech solution the user is required to
respond by speaking from a closed set of words when prompted by the system. A
sequence of human speech response to the IVR prompts results in the completion
of a transaction. A transaction is deemed successful if the speech solution can
correctly recognize all the spoken utterances of the user whenever prompted by
the system. The usual mechanism to evaluate the performance of a speech
solution is to do an extensive test of the system by putting it to actual
people use and then evaluating the performance by analyzing the logs for
successful transactions. This kind of evaluation could lead to dissatisfied
test users especially if the performance of the system were to result in a poor
transaction completion rate. To negate this the Wizard of Oz approach is
adopted during evaluation of a speech system. Overall this kind of evaluations
is an expensive proposition both in terms of time and cost. In this paper, we
propose a method to evaluate the performance of a speech solution without
actually putting it to people use. We first describe the methodology and then
show experimentally that this can be used to identify the performance
bottlenecks of the speech solution even before the system is actually used thus
saving evaluation time and expenses.

---------------

### 15 Mar 2023 | [Evaluating gesture-generation in a large-scale open challenge: The GENEA  Challenge 2022](https://arxiv.org/abs/2303.08737) | [⬇️](https://arxiv.org/pdf/2303.08737)
*Taras Kucherenko, Pieter Wolfert, Youngwoo Yoon, Carla Viegas, Teodor  Nikolov, Mihail Tsakov, Gustav Eje Henter* 

  This paper reports on the second GENEA Challenge to benchmark data-driven
automatic co-speech gesture generation. Participating teams used the same
speech and motion dataset to build gesture-generation systems. Motion generated
by all these systems was rendered to video using a standardised visualisation
pipeline and evaluated in several large, crowdsourced user studies. Unlike when
comparing different research papers, differences in results are here only due
to differences between methods, enabling direct comparison between systems. The
dataset was based on 18 hours of full-body motion capture, including fingers,
of different persons engaging in a dyadic conversation. Ten teams participated
in the challenge across two tiers: full-body and upper-body gesticulation. For
each tier, we evaluated both the human-likeness of the gesture motion and its
appropriateness for the specific speech signal. Our evaluations decouple
human-likeness from gesture appropriateness, which has been a difficult problem
in the field.
  The evaluation results are a revolution, and a revelation. Some synthetic
conditions are rated as significantly more human-like than human motion
capture. To the best of our knowledge, this has never been shown before on a
high-fidelity avatar. On the other hand, all synthetic motion is found to be
vastly less appropriate for the speech than the original motion-capture
recordings. We also find that conventional objective metrics do not correlate
well with subjective human-likeness ratings in this large evaluation. The one
exception is the Fr\'echet gesture distance (FGD), which achieves a Kendall's
tau rank correlation of around -0.5. Based on the challenge results we
formulate numerous recommendations for system building and evaluation.

---------------
**Date:** 22 Dec 2020

**Title:** A Hierarchical Reasoning Graph Neural Network for The Automatic Scoring  of Answer Transcriptions in Video Job Interviews

**Abstract Link:** [https://arxiv.org/abs/2012.11960](https://arxiv.org/abs/2012.11960)

**PDF Link:** [https://arxiv.org/pdf/2012.11960](https://arxiv.org/pdf/2012.11960)

---

**Date:** 03 Nov 2023

**Title:** Improving Interpersonal Communication by Simulating Audiences with  Language Models

**Abstract Link:** [https://arxiv.org/abs/2311.00687](https://arxiv.org/abs/2311.00687)

**PDF Link:** [https://arxiv.org/pdf/2311.00687](https://arxiv.org/pdf/2311.00687)

---

**Date:** 22 Aug 2023

**Title:** Learning to generate and corr- uh I mean repair language in real-time

**Abstract Link:** [https://arxiv.org/abs/2308.11683](https://arxiv.org/abs/2308.11683)

**PDF Link:** [https://arxiv.org/pdf/2308.11683](https://arxiv.org/pdf/2308.11683)

---

**Date:** 26 Aug 2020

**Title:** Machine learning approach of Japanese composition scoring and writing  aided system's design

**Abstract Link:** [https://arxiv.org/abs/2008.11488](https://arxiv.org/abs/2008.11488)

**PDF Link:** [https://arxiv.org/pdf/2008.11488](https://arxiv.org/pdf/2008.11488)

---

**Date:** 05 Jun 2020

**Title:** Human or Machine: Automating Human Likeliness Evaluation of NLG Texts

**Abstract Link:** [https://arxiv.org/abs/2006.03189](https://arxiv.org/abs/2006.03189)

**PDF Link:** [https://arxiv.org/pdf/2006.03189](https://arxiv.org/pdf/2006.03189)

---

**Date:** 30 Jan 2024

**Title:** Synthetic Dialogue Dataset Generation using LLM Agents

**Abstract Link:** [https://arxiv.org/abs/2401.17461](https://arxiv.org/abs/2401.17461)

**PDF Link:** [https://arxiv.org/pdf/2401.17461](https://arxiv.org/pdf/2401.17461)

---

**Date:** 17 Dec 2023

**Title:** LLMEval: A Preliminary Study on How to Evaluate Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2312.07398](https://arxiv.org/abs/2312.07398)

**PDF Link:** [https://arxiv.org/pdf/2312.07398](https://arxiv.org/pdf/2312.07398)

---

**Date:** 30 Jun 2021

**Title:** Towards the evaluation of automatic simultaneous speech translation from  a communicative perspective

**Abstract Link:** [https://arxiv.org/abs/2103.08364](https://arxiv.org/abs/2103.08364)

**PDF Link:** [https://arxiv.org/pdf/2103.08364](https://arxiv.org/pdf/2103.08364)

---

**Date:** 13 Jun 2023

**Title:** Speech Enhancement and Dereverberation with Diffusion-based Generative  Models

**Abstract Link:** [https://arxiv.org/abs/2208.05830](https://arxiv.org/abs/2208.05830)

**PDF Link:** [https://arxiv.org/pdf/2208.05830](https://arxiv.org/pdf/2208.05830)

---

**Date:** 06 Jul 2021

**Title:** Location, Location: Enhancing the Evaluation of Text-to-Speech Synthesis  Using the Rapid Prosody Transcription Paradigm

**Abstract Link:** [https://arxiv.org/abs/2107.02527](https://arxiv.org/abs/2107.02527)

**PDF Link:** [https://arxiv.org/pdf/2107.02527](https://arxiv.org/pdf/2107.02527)

---

**Date:** 19 Sep 2023

**Title:** Large Language Models are Diverse Role-Players for Summarization  Evaluation

**Abstract Link:** [https://arxiv.org/abs/2303.15078](https://arxiv.org/abs/2303.15078)

**PDF Link:** [https://arxiv.org/pdf/2303.15078](https://arxiv.org/pdf/2303.15078)

---

**Date:** 12 Oct 2023

**Title:** MINT: Evaluating LLMs in Multi-turn Interaction with Tools and Language  Feedback

**Abstract Link:** [https://arxiv.org/abs/2309.10691](https://arxiv.org/abs/2309.10691)

**PDF Link:** [https://arxiv.org/pdf/2309.10691](https://arxiv.org/pdf/2309.10691)

---

**Date:** 25 Aug 2023

**Title:** Approximating Online Human Evaluation of Social Chatbots with Prompting

**Abstract Link:** [https://arxiv.org/abs/2304.05253](https://arxiv.org/abs/2304.05253)

**PDF Link:** [https://arxiv.org/pdf/2304.05253](https://arxiv.org/pdf/2304.05253)

---

**Date:** 16 May 2022

**Title:** The AI Teacher Test: Measuring the Pedagogical Ability of Blender and  GPT-3 in Educational Dialogues

**Abstract Link:** [https://arxiv.org/abs/2205.07540](https://arxiv.org/abs/2205.07540)

**PDF Link:** [https://arxiv.org/pdf/2205.07540](https://arxiv.org/pdf/2205.07540)

---

**Date:** 09 May 2020

**Title:** LinCE: A Centralized Benchmark for Linguistic Code-switching Evaluation

**Abstract Link:** [https://arxiv.org/abs/2005.04322](https://arxiv.org/abs/2005.04322)

**PDF Link:** [https://arxiv.org/pdf/2005.04322](https://arxiv.org/pdf/2005.04322)

---

**Date:** 04 Nov 2019

**Title:** Approximating Interactive Human Evaluation with Self-Play for  Open-Domain Dialog Systems

**Abstract Link:** [https://arxiv.org/abs/1906.09308](https://arxiv.org/abs/1906.09308)

**PDF Link:** [https://arxiv.org/pdf/1906.09308](https://arxiv.org/pdf/1906.09308)

---

**Date:** 07 Mar 2018

**Title:** Automating Reading Comprehension by Generating Question and Answer Pairs

**Abstract Link:** [https://arxiv.org/abs/1803.03664](https://arxiv.org/abs/1803.03664)

**PDF Link:** [https://arxiv.org/pdf/1803.03664](https://arxiv.org/pdf/1803.03664)

---

**Date:** 13 Oct 2022

**Title:** Real-Time Automated Answer Scoring

**Abstract Link:** [https://arxiv.org/abs/2210.09004](https://arxiv.org/abs/2210.09004)

**PDF Link:** [https://arxiv.org/pdf/2210.09004](https://arxiv.org/pdf/2210.09004)

---

**Date:** 11 Jan 2016

**Title:** Evaluating the Performance of a Speech Recognition based System

**Abstract Link:** [https://arxiv.org/abs/1601.02543](https://arxiv.org/abs/1601.02543)

**PDF Link:** [https://arxiv.org/pdf/1601.02543](https://arxiv.org/pdf/1601.02543)

---

**Date:** 15 Mar 2023

**Title:** Evaluating gesture-generation in a large-scale open challenge: The GENEA  Challenge 2022

**Abstract Link:** [https://arxiv.org/abs/2303.08737](https://arxiv.org/abs/2303.08737)

**PDF Link:** [https://arxiv.org/pdf/2303.08737](https://arxiv.org/pdf/2303.08737)

---

