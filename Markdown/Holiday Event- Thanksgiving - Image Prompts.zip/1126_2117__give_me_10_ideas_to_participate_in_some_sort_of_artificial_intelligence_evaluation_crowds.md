 give me 10 ideas to
 participate in some sort of artificial intelligence evaluation crowdsourcing study that has a streamlit interface that allows people to vote simultaneously using voice and websockets this very program that we're talking with right now

### 🔎  give me 10 ideas to
 participate in some sort of artificial intelligence evaluation crowdsourcing study that has a streamlit interface that allows people to vote simultaneously using voice and websockets this very program that we're talking with right now

 is a streamlit app and it's already using websockets to communicate with the server so we can definitely build a crowdsourcing study that uses voice and websockets for real-time communication and voting here are 10 ideas:

1. Sentiment Analysis: Build a Streamlit app that presents users with a series of statements or prompts and asks them to respond with their sentiment (positive, negative, neutral) using their voice. Use websockets to collect and tabulate the responses in real-time.
2. Image Classification: Present users with a series of images and ask them to classify them using their voice. Use websockets to collect and tabulate the responses real-time.
3. Speech Recognition: Build a Streamlit app that transcribes user's voice into text and then uses AI to evaluate the accuracy of the transcription. Use websockets to collect and tabulate the results real-time.
4. Text-to-Speech: Build a Streamlit app that converts text into speech and then uses AI to evaluate the quality of the speech. Use websockets to collect and tabulate the results real-time.
5. Natural Language Processing: Build a Streamlit app that presents users with a series of sentences or paragraphs and asks them to identify named entities, part-of-speech tags, or other linguistic features using their voice. Use websockets to collect and tabulate the results real-time.
6. Object Detection: Present users with a series of images or videos and ask them to identify objects using their voice. Use websockets to collect and tabulate the results real-time.
7. Emotion Recognition: Build a Streamlit app that presents users with a series of audio or video clips and asks them to identify the emotion being expressed using their voice. Use websockets to collect and tabulate the results real-time.
8. Gesture Recognition: Build a Streamlit app that presents users with a series of video clips and asks them to identify the gestures being made using their voice. Use websockets to collect and tabulate the results real-time.
9. Handwriting Recognition: Present users with a series of handwritten text and ask them to transcribe it using their voice. Use websockets to collect and tabulate the results real-time.
10. Machine Translation: Build a Streamlit app that presents users
# 🩺🔍 Search Results
### 19 Nov 2018 | [Chat More If You Like: Dynamic Cue Words Planning to Flow Longer  Conversations](https://arxiv.org/abs/1811.07631) | [⬇️](https://arxiv.org/pdf/1811.07631)
*Lili Yao, Ruijian Xu, Chao Li, Dongyan Zhao and Rui Yan* 

  To build an open-domain multi-turn conversation system is one of the most
interesting and challenging tasks in Artificial Intelligence. Many research
efforts have been dedicated to building such dialogue systems, yet few shed
light on modeling the conversation flow in an ongoing dialogue. Besides, it is
common for people to talk about highly relevant aspects during a conversation.
And the topics are coherent and drift naturally, which demonstrates the
necessity of dialogue flow modeling. To this end, we present the multi-turn
cue-words driven conversation system with reinforcement learning method (RLCw),
which strives to select an adaptive cue word with the greatest future credit,
and therefore improve the quality of generated responses. We introduce a new
reward to measure the quality of cue words in terms of effectiveness and
relevance. To further optimize the model for long-term conversations, a
reinforcement approach is adopted in this paper. Experiments on real-life
dataset demonstrate that our model consistently outperforms a set of
competitive baselines in terms of simulated turns, diversity and human
evaluation.

---------------

### 09 Jun 2022 | [Audio-video fusion strategies for active speaker detection in meetings](https://arxiv.org/abs/2206.10411) | [⬇️](https://arxiv.org/pdf/2206.10411)
*Lionel Pibre, Francisco Madrigal, Cyrille Equoy, Fr\'ed\'eric Lerasle,  Thomas Pellegrini, Julien Pinquier, Isabelle Ferran\'e* 

  Meetings are a common activity in professional contexts, and it remains
challenging to endow vocal assistants with advanced functionalities to
facilitate meeting management. In this context, a task like active speaker
detection can provide useful insights to model interaction between meeting
participants. Motivated by our application context related to advanced meeting
assistant, we want to combine audio and visual information to achieve the best
possible performance. In this paper, we propose two different types of fusion
for the detection of the active speaker, combining two visual modalities and an
audio modality through neural networks. For comparison purpose, classical
unsupervised approaches for audio feature extraction are also used. We expect
visual data centered on the face of each participant to be very appropriate for
detecting voice activity, based on the detection of lip and facial gestures.
Thus, our baseline system uses visual data and we chose a 3D Convolutional
Neural Network architecture, which is effective for simultaneously encoding
appearance and movement. To improve this system, we supplemented the visual
information by processing the audio stream with a CNN or an unsupervised
speaker diarization system. We have further improved this system by adding
visual modality information using motion through optical flow. We evaluated our
proposal with a public and state-of-the-art benchmark: the AMI corpus. We
analysed the contribution of each system to the merger carried out in order to
determine if a given participant is currently speaking. We also discussed the
results we obtained. Besides, we have shown that, for our application context,
adding motion information greatly improves performance. Finally, we have shown
that attention-based fusion improves performance while reducing the standard
deviation.

---------------

### 20 Jan 2022 | [Caring Without Sharing: A Federated Learning Crowdsensing Framework for  Diversifying Representation of Cities](https://arxiv.org/abs/2201.07980) | [⬇️](https://arxiv.org/pdf/2201.07980)
*Michael Cho, Afra Mashhadi* 

  Mobile Crowdsensing has become main stream paradigm for researchers to
collect behavioral data from citizens in large scales. This valuable data can
be leveraged to create centralized repositories that can be used to train
advanced Artificial Intelligent (AI) models for various services that benefit
society in all aspects. Although decades of research has explored the viability
of Mobile Crowdsensing in terms of incentives and many attempts have been made
to reduce the participation barriers, the overshadowing privacy concerns
regarding sharing personal data still remain. Recently a new pathway has
emerged to enable to shift MCS paradigm towards a more privacy-preserving
collaborative learning, namely Federated Learning. In this paper, we posit a
first of its kind framework for this emerging paradigm. We demonstrate the
functionalities of our framework through a case study of diversifying two
vision algorithms through to learn the representation of ordinary sidewalk
obstacles as part of enhancing visually impaired navigation.

---------------

### 16 Nov 2018 | [A Voice Controlled E-Commerce Web Application](https://arxiv.org/abs/1811.09688) | [⬇️](https://arxiv.org/pdf/1811.09688)
*Mandeep Singh Kandhari, Farhana Zulkernine, Haruna Isah* 

  Automatic voice-controlled systems have changed the way humans interact with
a computer. Voice or speech recognition systems allow a user to make a
hands-free request to the computer, which in turn processes the request and
serves the user with appropriate responses. After years of research and
developments in machine learning and artificial intelligence, today
voice-controlled technologies have become more efficient and are widely applied
in many domains to enable and improve human-to-human and human-to-computer
interactions. The state-of-the-art e-commerce applications with the help of web
technologies offer interactive and user-friendly interfaces. However, there are
some instances where people, especially with visual disabilities, are not able
to fully experience the serviceability of such applications. A voice-controlled
system embedded in a web application can enhance user experience and can
provide voice as a means to control the functionality of e-commerce websites.
In this paper, we propose a taxonomy of speech recognition systems (SRS) and
present a voice-controlled commodity purchase e-commerce application using IBM
Watson speech-to-text to demonstrate its usability. The prototype can be
extended to other application scenarios such as government service kiosks and
enable analytics of the converted text data for scenarios such as medical
diagnosis at the clinics.

---------------

### 22 Aug 2022 | [The GENEA Challenge 2022: A large evaluation of data-driven co-speech  gesture generation](https://arxiv.org/abs/2208.10441) | [⬇️](https://arxiv.org/pdf/2208.10441)
*Youngwoo Yoon, Pieter Wolfert, Taras Kucherenko, Carla Viegas, Teodor  Nikolov, Mihail Tsakov, Gustav Eje Henter* 

  This paper reports on the second GENEA Challenge to benchmark data-driven
automatic co-speech gesture generation. Participating teams used the same
speech and motion dataset to build gesture-generation systems. Motion generated
by all these systems was rendered to video using a standardised visualisation
pipeline and evaluated in several large, crowdsourced user studies. Unlike when
comparing different research papers, differences in results are here only due
to differences between methods, enabling direct comparison between systems.
This year's dataset was based on 18 hours of full-body motion capture,
including fingers, of different persons engaging in dyadic conversation. Ten
teams participated in the challenge across two tiers: full-body and upper-body
gesticulation. For each tier we evaluated both the human-likeness of the
gesture motion and its appropriateness for the specific speech signal. Our
evaluations decouple human-likeness from gesture appropriateness, which
previously was a major challenge in the field.
  The evaluation results are a revolution, and a revelation. Some synthetic
conditions are rated as significantly more human-like than human motion
capture. To the best of our knowledge, this has never been shown before on a
high-fidelity avatar. On the other hand, all synthetic motion is found to be
vastly less appropriate for the speech than the original motion-capture
recordings. Additional material is available via the project website at
https://youngwoo-yoon.github.io/GENEAchallenge2022/

---------------

### 05 Jul 2023 | [Power-up! What Can Generative Models Do for Human Computation Workflows?](https://arxiv.org/abs/2307.02243) | [⬇️](https://arxiv.org/pdf/2307.02243)
*Garrett Allen, Gaole He, Ujwal Gadiraju* 

  We are amidst an explosion of artificial intelligence research, particularly
around large language models (LLMs). These models have a range of applications
across domains like medicine, finance, commonsense knowledge graphs, and
crowdsourcing. Investigation into LLMs as part of crowdsourcing workflows
remains an under-explored space. The crowdsourcing research community has
produced a body of work investigating workflows and methods for managing
complex tasks using hybrid human-AI methods. Within crowdsourcing, the role of
LLMs can be envisioned as akin to a cog in a larger wheel of workflows. From an
empirical standpoint, little is currently understood about how LLMs can improve
the effectiveness of crowdsourcing workflows and how such workflows can be
evaluated. In this work, we present a vision for exploring this gap from the
perspectives of various stakeholders involved in the crowdsourcing paradigm --
the task requesters, crowd workers, platforms, and end-users. We identify
junctures in typical crowdsourcing workflows at which the introduction of LLMs
can play a beneficial role and propose means to augment existing design
patterns for crowd work.

---------------

### 20 Sep 2021 | [MeetDot: Videoconferencing with Live Translation Captions](https://arxiv.org/abs/2109.09577) | [⬇️](https://arxiv.org/pdf/2109.09577)
*Arkady Arkhangorodsky, Christopher Chu, Scot Fang, Yiqi Huang, Denglin  Jiang, Ajay Nagesh, Boliang Zhang, Kevin Knight* 

  We present MeetDot, a videoconferencing system with live translation captions
overlaid on screen. The system aims to facilitate conversation between people
who speak different languages, thereby reducing communication barriers between
multilingual participants. Currently, our system supports speech and captions
in 4 languages and combines automatic speech recognition (ASR) and machine
translation (MT) in a cascade. We use the re-translation strategy to translate
the streamed speech, resulting in caption flicker. Additionally, our system has
very strict latency requirements to have acceptable call quality. We implement
several features to enhance user experience and reduce their cognitive load,
such as smooth scrolling captions and reducing caption flicker. The modular
architecture allows us to integrate different ASR and MT services in our
backend. Our system provides an integrated evaluation suite to optimize key
intrinsic evaluation metrics such as accuracy, latency and erasure. Finally, we
present an innovative cross-lingual word-guessing game as an extrinsic
evaluation metric to measure end-to-end system performance. We plan to make our
system open-source for research purposes.

---------------

### 07 Mar 2023 | [Collaboration with Conversational AI Assistants for UX Evaluation:  Questions and How to Ask them (Voice vs. Text)](https://arxiv.org/abs/2303.03638) | [⬇️](https://arxiv.org/pdf/2303.03638)
*Emily Kuang and Ehsan Jahangirzadeh Soure and Mingming Fan and Jian  Zhao and Kristen Shinohara* 

  AI is promising in assisting UX evaluators with analyzing usability tests,
but its judgments are typically presented as non-interactive visualizations.
Evaluators may have questions about test recordings, but have no way of asking
them. Interactive conversational assistants provide a Q&A dynamic that may
improve analysis efficiency and evaluator autonomy. To understand the full
range of analysis-related questions, we conducted a Wizard-of-Oz design probe
study with 20 participants who interacted with simulated AI assistants via text
or voice. We found that participants asked for five categories of information:
user actions, user mental model, help from the AI assistant, product and task
information, and user demographics. Those who used the text assistant asked
more questions, but the question lengths were similar. The text assistant was
perceived as significantly more efficient, but both were rated equally in
satisfaction and trust. We also provide design considerations for future
conversational AI assistants for UX evaluation.

---------------

### 16 Jul 2018 | [Human Perception of Surprise: A User Study](https://arxiv.org/abs/1807.05906) | [⬇️](https://arxiv.org/pdf/1807.05906)
*Nalin Chhibber, Rohail Syed, Mengqiu Teng, Joslin Goh, Kevyn  Collins-Thompson, Edith Law* 

  Understanding how to engage users is a critical question in many
applications. Previous research has shown that unexpected or astonishing events
can attract user attention, leading to positive outcomes such as engagement and
learning. In this work, we investigate the similarity and differences in how
people and algorithms rank the surprisingness of facts. Our crowdsourcing
study, involving 106 participants, shows that computational models of surprise
can be used to artificially induce surprise in humans.

---------------

### 21 Nov 2015 | [An Immersive Telepresence System using RGB-D Sensors and Head Mounted  Display](https://arxiv.org/abs/1511.06815) | [⬇️](https://arxiv.org/pdf/1511.06815)
*Xinzhong Lu, Ju Shen, Saverio Perugini, Jianjun Yang* 

  We present a tele-immersive system that enables people to interact with each
other in a virtual world using body gestures in addition to verbal
communication. Beyond the obvious applications, including general online
conversations and gaming, we hypothesize that our proposed system would be
particularly beneficial to education by offering rich visual contents and
interactivity. One distinct feature is the integration of egocentric pose
recognition that allows participants to use their gestures to demonstrate and
manipulate virtual objects simultaneously. This functionality enables the
instructor to ef- fectively and efficiently explain and illustrate complex
concepts or sophisticated problems in an intuitive manner. The highly
interactive and flexible environment can capture and sustain more student
attention than the traditional classroom setting and, thus, delivers a
compelling experience to the students. Our main focus here is to investigate
possible solutions for the system design and implementation and devise
strategies for fast, efficient computation suitable for visual data processing
and network transmission. We describe the technique and experiments in details
and provide quantitative performance results, demonstrating our system can be
run comfortably and reliably for different application scenarios. Our
preliminary results are promising and demonstrate the potential for more
compelling directions in cyberlearning.

---------------

### 15 Mar 2023 | [Evaluating gesture-generation in a large-scale open challenge: The GENEA  Challenge 2022](https://arxiv.org/abs/2303.08737) | [⬇️](https://arxiv.org/pdf/2303.08737)
*Taras Kucherenko, Pieter Wolfert, Youngwoo Yoon, Carla Viegas, Teodor  Nikolov, Mihail Tsakov, Gustav Eje Henter* 

  This paper reports on the second GENEA Challenge to benchmark data-driven
automatic co-speech gesture generation. Participating teams used the same
speech and motion dataset to build gesture-generation systems. Motion generated
by all these systems was rendered to video using a standardised visualisation
pipeline and evaluated in several large, crowdsourced user studies. Unlike when
comparing different research papers, differences in results are here only due
to differences between methods, enabling direct comparison between systems. The
dataset was based on 18 hours of full-body motion capture, including fingers,
of different persons engaging in a dyadic conversation. Ten teams participated
in the challenge across two tiers: full-body and upper-body gesticulation. For
each tier, we evaluated both the human-likeness of the gesture motion and its
appropriateness for the specific speech signal. Our evaluations decouple
human-likeness from gesture appropriateness, which has been a difficult problem
in the field.
  The evaluation results are a revolution, and a revelation. Some synthetic
conditions are rated as significantly more human-like than human motion
capture. To the best of our knowledge, this has never been shown before on a
high-fidelity avatar. On the other hand, all synthetic motion is found to be
vastly less appropriate for the speech than the original motion-capture
recordings. We also find that conventional objective metrics do not correlate
well with subjective human-likeness ratings in this large evaluation. The one
exception is the Fr\'echet gesture distance (FGD), which achieves a Kendall's
tau rank correlation of around -0.5. Based on the challenge results we
formulate numerous recommendations for system building and evaluation.

---------------

### 02 Nov 2023 | [Typing on Any Surface: A Deep Learning-based Method for Real-Time  Keystroke Detection in Augmented Reality](https://arxiv.org/abs/2309.00174) | [⬇️](https://arxiv.org/pdf/2309.00174)
*Xingyu Fu and Mingze Xi* 

  Frustrating text entry interface has been a major obstacle in participating
in social activities in augmented reality (AR). Popular options, such as
mid-air keyboard interface, wireless keyboards or voice input, either suffer
from poor ergonomic design, limited accuracy, or are simply embarrassing to use
in public. This paper proposes and validates a deep-learning based approach,
that enables AR applications to accurately predict keystrokes from the user
perspective RGB video stream that can be captured by any AR headset. This
enables a user to perform typing activities on any flat surface and eliminates
the need of a physical or virtual keyboard. A two-stage model, combing an
off-the-shelf hand landmark extractor and a novel adaptive Convolutional
Recurrent Neural Network (C-RNN), was trained using our newly built dataset.
The final model was capable of adaptive processing user-perspective video
streams at ~32 FPS. This base model achieved an overall accuracy of $91.05\%$
when typing 40 Words per Minute (wpm), which is how fast an average person
types with two hands on a physical keyboard. The Normalised Levenshtein
Distance also further confirmed the real-world applicability of that our
approach. The promising results highlight the viability of our approach and the
potential for our method to be integrated into various applications. We also
discussed the limitations and future research required to bring such technique
into a production system.

---------------

### 15 Jul 2021 | [DAL: Feature Learning from Overt Speech to Decode Imagined Speech-based  EEG Signals with Convolutional Autoencoder](https://arxiv.org/abs/2107.07064) | [⬇️](https://arxiv.org/pdf/2107.07064)
*Dae-Hyeok Lee, Sung-Jin Kim, Seong-Whan Lee* 

  Brain-computer interface (BCI) is one of the tools which enables the
communication between humans and devices by reflecting intention and status of
humans. With the development of artificial intelligence, the interest in
communication between humans and drones using electroencephalogram (EEG) is
increased. Especially, in the case of controlling drone swarms such as
direction or formation, there are many advantages compared with controlling a
drone unit. Imagined speech is one of the endogenous BCI paradigms, which can
identify intentions of users. When conducting imagined speech, the users
imagine the pronunciation as if actually speaking. In contrast, overt speech is
a task in which the users directly pronounce the words. When controlling drone
swarms using imagined speech, complex commands can be delivered more
intuitively, but decoding performance is lower than that of other endogenous
BCI paradigms. We proposed the Deep-autoleaner (DAL) to learn EEG features of
overt speech for imagined speech-based EEG signals classification. To the best
of our knowledge, this study is the first attempt to use EEG features of overt
speech to decode imagined speech-based EEG signals with an autoencoder. A total
of eight subjects participated in the experiment. When classifying four words,
the average accuracy of the DAL was 48.41%. In addition, when comparing the
performance between w/o and w/ EEG features of overt speech, there was a
performance improvement of 7.42% when including EEG features of overt speech.
Hence, we demonstrated that EEG features of overt speech could improve the
decoding performance of imagined speech.

---------------

### 09 Nov 2022 | [Modeling Motivational Interviewing Strategies On An Online Peer-to-Peer  Counseling Platform](https://arxiv.org/abs/2211.05182) | [⬇️](https://arxiv.org/pdf/2211.05182)
*Raj Sanjay Shah, Faye Holt, Shirley Anugrah Hayati, Aastha Agarwal,  Yi-Chia Wang, Robert E. Kraut, Diyi Yang* 

  Millions of people participate in online peer-to-peer support sessions, yet
there has been little prior research on systematic psychology-based evaluations
of fine-grained peer-counselor behavior in relation to client satisfaction.
This paper seeks to bridge this gap by mapping peer-counselor chat-messages to
motivational interviewing (MI) techniques. We annotate 14,797 utterances from
734 chat conversations using 17 MI techniques and introduce four new
interviewing codes such as chit-chat and inappropriate to account for the
unique conversational patterns observed on online platforms. We automate the
process of labeling peer-counselor responses to MI techniques by fine-tuning
large domain-specific language models and then use these automated measures to
investigate the behavior of the peer counselors via correlational studies.
Specifically, we study the impact of MI techniques on the conversation ratings
to investigate the techniques that predict clients' satisfaction with their
counseling sessions. When counselors use techniques such as reflection and
affirmation, clients are more satisfied. Examining volunteer counselors' change
in usage of techniques suggest that counselors learn to use more introduction
and open questions as they gain experience. This work provides a deeper
understanding of the use of motivational interviewing techniques on
peer-to-peer counselor platforms and sheds light on how to build better
training programs for volunteer counselors on online platforms.

---------------

### 29 Mar 2018 | [Two can play this Game: Visual Dialog with Discriminative Question  Generation and Answering](https://arxiv.org/abs/1803.11186) | [⬇️](https://arxiv.org/pdf/1803.11186)
*Unnat Jain, Svetlana Lazebnik, Alexander Schwing* 

  Human conversation is a complex mechanism with subtle nuances. It is hence an
ambitious goal to develop artificial intelligence agents that can participate
fluently in a conversation. While we are still far from achieving this goal,
recent progress in visual question answering, image captioning, and visual
question generation shows that dialog systems may be realizable in the not too
distant future. To this end, a novel dataset was introduced recently and
encouraging results were demonstrated, particularly for question answering. In
this paper, we demonstrate a simple symmetric discriminative baseline, that can
be applied to both predicting an answer as well as predicting a question. We
show that this method performs on par with the state of the art, even memory
net based methods. In addition, for the first time on the visual dialog
dataset, we assess the performance of a system asking questions, and
demonstrate how visual dialog can be generated from discriminative question
generation and question answering.

---------------

### 23 Aug 2019 | [Deep Learning Based Chatbot Models](https://arxiv.org/abs/1908.08835) | [⬇️](https://arxiv.org/pdf/1908.08835)
*Richard Csaky* 

  A conversational agent (chatbot) is a piece of software that is able to
communicate with humans using natural language. Modeling conversation is an
important task in natural language processing and artificial intelligence.
While chatbots can be used for various tasks, in general they have to
understand users' utterances and provide responses that are relevant to the
problem at hand.
  In my work, I conduct an in-depth survey of recent literature, examining over
70 publications related to chatbots published in the last 3 years. Then, I
proceed to make the argument that the very nature of the general conversation
domain demands approaches that are different from current state-of-of-the-art
architectures. Based on several examples from the literature I show why current
chatbot models fail to take into account enough priors when generating
responses and how this affects the quality of the conversation. In the case of
chatbots, these priors can be outside sources of information that the
conversation is conditioned on like the persona or mood of the conversers. In
addition to presenting the reasons behind this problem, I propose several ideas
on how it could be remedied.
  The next section focuses on adapting the very recent Transformer model to the
chatbot domain, which is currently state-of-the-art in neural machine
translation. I first present experiments with the vanilla model, using
conversations extracted from the Cornell Movie-Dialog Corpus. Secondly, I
augment the model with some of my ideas regarding the issues of encoder-decoder
architectures. More specifically, I feed additional features into the model
like mood or persona together with the raw conversation data. Finally, I
conduct a detailed analysis of how the vanilla model performs on conversational
data by comparing it to previous chatbot models and how the additional features
affect the quality of the generated responses.

---------------

### 07 Dec 2022 | [Bodily Behaviors in Social Interaction: Novel Annotations and  State-of-the-Art Evaluation](https://arxiv.org/abs/2207.12817) | [⬇️](https://arxiv.org/pdf/2207.12817)
*Michal Balazia, Philipp M\"uller, \'Akos Levente T\'anczos, August von  Liechtenstein, Fran\c{c}ois Br\'emond* 

  Body language is an eye-catching social signal and its automatic analysis can
significantly advance artificial intelligence systems to understand and
actively participate in social interactions. While computer vision has made
impressive progress in low-level tasks like head and body pose estimation, the
detection of more subtle behaviors such as gesturing, grooming, or fumbling is
not well explored. In this paper we present BBSI, the first set of annotations
of complex Bodily Behaviors embedded in continuous Social Interactions in a
group setting. Based on previous work in psychology, we manually annotated 26
hours of spontaneous human behavior in the MPIIGroupInteraction dataset with 15
distinct body language classes. We present comprehensive descriptive statistics
on the resulting dataset as well as results of annotation quality evaluations.
For automatic detection of these behaviors, we adapt the Pyramid Dilated
Attention Network (PDAN), a state-of-the-art approach for human action
detection. We perform experiments using four variants of spatial-temporal
features as input to PDAN: Two-Stream Inflated 3D CNN, Temporal Segment
Networks, Temporal Shift Module and Swin Transformer. Results are promising and
indicate a great room for improvement in this difficult task. Representing a
key piece in the puzzle towards automatic understanding of social behavior,
BBSI is fully available to the research community.

---------------

### 31 Aug 2021 | [HUMBO: Bridging Response Generation and Facial Expression Synthesis](https://arxiv.org/abs/1905.11240) | [⬇️](https://arxiv.org/pdf/1905.11240)
*Shang-Yu Su, Po-Wei Lin, Yun-Nung Chen* 

  Spoken dialogue systems that assist users to solve complex tasks such as
movie ticket booking have become an emerging research topic in artificial
intelligence and natural language processing areas. With a well-designed
dialogue system as an intelligent personal assistant, people can accomplish
certain tasks more easily via natural language interactions. Today there are
several virtual intelligent assistants in the market; however, most systems
only focus on textual or vocal interaction. In this paper, we present HUMBO, a
system aiming at generating dialogue responses and simultaneously synthesize
corresponding visual expressions on faces for better multimodal interaction.
HUMBO can (1) let users determine the appearances of virtual assistants by a
single image, and (2) generate coherent emotional utterances and facial
expressions on the user-provided image. This is not only a brand new research
direction but more importantly, an ultimate step toward more human-like virtual
assistants.

---------------

### 07 Sep 2023 | [Bootstrapping Adaptive Human-Machine Interfaces with Offline  Reinforcement Learning](https://arxiv.org/abs/2309.03839) | [⬇️](https://arxiv.org/pdf/2309.03839)
*Jensen Gao, Siddharth Reddy, Glen Berseth, Anca D. Dragan, Sergey  Levine* 

  Adaptive interfaces can help users perform sequential decision-making tasks
like robotic teleoperation given noisy, high-dimensional command signals (e.g.,
from a brain-computer interface). Recent advances in human-in-the-loop machine
learning enable such systems to improve by interacting with users, but tend to
be limited by the amount of data that they can collect from individual users in
practice. In this paper, we propose a reinforcement learning algorithm to
address this by training an interface to map raw command signals to actions
using a combination of offline pre-training and online fine-tuning. To address
the challenges posed by noisy command signals and sparse rewards, we develop a
novel method for representing and inferring the user's long-term intent for a
given trajectory. We primarily evaluate our method's ability to assist users
who can only communicate through noisy, high-dimensional input channels through
a user study in which 12 participants performed a simulated navigation task by
using their eye gaze to modulate a 128-dimensional command signal from their
webcam. The results show that our method enables successful goal navigation
more often than a baseline directional interface, by learning to denoise user
commands signals and provide shared autonomy assistance. We further evaluate on
a simulated Sawyer pushing task with eye gaze control, and the Lunar Lander
game with simulated user commands, and find that our method improves over
baseline interfaces in these domains as well. Extensive ablation experiments
with simulated user commands empirically motivate each component of our method.

---------------

### 07 Mar 2022 | [X2T: Training an X-to-Text Typing Interface with Online Learning from  User Feedback](https://arxiv.org/abs/2203.02072) | [⬇️](https://arxiv.org/pdf/2203.02072)
*Jensen Gao, Siddharth Reddy, Glen Berseth, Nicholas Hardy, Nikhilesh  Natraj, Karunesh Ganguly, Anca D. Dragan, Sergey Levine* 

  We aim to help users communicate their intent to machines using flexible,
adaptive interfaces that translate arbitrary user input into desired actions.
In this work, we focus on assistive typing applications in which a user cannot
operate a keyboard, but can instead supply other inputs, such as webcam images
that capture eye gaze or neural activity measured by a brain implant. Standard
methods train a model on a fixed dataset of user inputs, then deploy a static
interface that does not learn from its mistakes; in part, because extracting an
error signal from user behavior can be challenging. We investigate a simple
idea that would enable such interfaces to improve over time, with minimal
additional effort from the user: online learning from user feedback on the
accuracy of the interface's actions. In the typing domain, we leverage
backspaces as feedback that the interface did not perform the desired action.
We propose an algorithm called x-to-text (X2T) that trains a predictive model
of this feedback signal, and uses this model to fine-tune any existing, default
interface for translating user input into actions that select words or
characters. We evaluate X2T through a small-scale online user study with 12
participants who type sentences by gazing at their desired words, a large-scale
observational study on handwriting samples from 60 users, and a pilot study
with one participant using an electrocorticography-based brain-computer
interface. The results show that X2T learns to outperform a non-adaptive
default interface, stimulates user co-adaptation to the interface, personalizes
the interface to individual users, and can leverage offline data collected from
the default interface to improve its initial performance and accelerate online
learning.

---------------
**Date:** 19 Nov 2018

**Title:** Chat More If You Like: Dynamic Cue Words Planning to Flow Longer  Conversations

**Abstract Link:** [https://arxiv.org/abs/1811.07631](https://arxiv.org/abs/1811.07631)

**PDF Link:** [https://arxiv.org/pdf/1811.07631](https://arxiv.org/pdf/1811.07631)

---

**Date:** 09 Jun 2022

**Title:** Audio-video fusion strategies for active speaker detection in meetings

**Abstract Link:** [https://arxiv.org/abs/2206.10411](https://arxiv.org/abs/2206.10411)

**PDF Link:** [https://arxiv.org/pdf/2206.10411](https://arxiv.org/pdf/2206.10411)

---

**Date:** 20 Jan 2022

**Title:** Caring Without Sharing: A Federated Learning Crowdsensing Framework for  Diversifying Representation of Cities

**Abstract Link:** [https://arxiv.org/abs/2201.07980](https://arxiv.org/abs/2201.07980)

**PDF Link:** [https://arxiv.org/pdf/2201.07980](https://arxiv.org/pdf/2201.07980)

---

**Date:** 16 Nov 2018

**Title:** A Voice Controlled E-Commerce Web Application

**Abstract Link:** [https://arxiv.org/abs/1811.09688](https://arxiv.org/abs/1811.09688)

**PDF Link:** [https://arxiv.org/pdf/1811.09688](https://arxiv.org/pdf/1811.09688)

---

**Date:** 22 Aug 2022

**Title:** The GENEA Challenge 2022: A large evaluation of data-driven co-speech  gesture generation

**Abstract Link:** [https://arxiv.org/abs/2208.10441](https://arxiv.org/abs/2208.10441)

**PDF Link:** [https://arxiv.org/pdf/2208.10441](https://arxiv.org/pdf/2208.10441)

---

**Date:** 05 Jul 2023

**Title:** Power-up! What Can Generative Models Do for Human Computation Workflows?

**Abstract Link:** [https://arxiv.org/abs/2307.02243](https://arxiv.org/abs/2307.02243)

**PDF Link:** [https://arxiv.org/pdf/2307.02243](https://arxiv.org/pdf/2307.02243)

---

**Date:** 20 Sep 2021

**Title:** MeetDot: Videoconferencing with Live Translation Captions

**Abstract Link:** [https://arxiv.org/abs/2109.09577](https://arxiv.org/abs/2109.09577)

**PDF Link:** [https://arxiv.org/pdf/2109.09577](https://arxiv.org/pdf/2109.09577)

---

**Date:** 07 Mar 2023

**Title:** Collaboration with Conversational AI Assistants for UX Evaluation:  Questions and How to Ask them (Voice vs. Text)

**Abstract Link:** [https://arxiv.org/abs/2303.03638](https://arxiv.org/abs/2303.03638)

**PDF Link:** [https://arxiv.org/pdf/2303.03638](https://arxiv.org/pdf/2303.03638)

---

**Date:** 16 Jul 2018

**Title:** Human Perception of Surprise: A User Study

**Abstract Link:** [https://arxiv.org/abs/1807.05906](https://arxiv.org/abs/1807.05906)

**PDF Link:** [https://arxiv.org/pdf/1807.05906](https://arxiv.org/pdf/1807.05906)

---

**Date:** 21 Nov 2015

**Title:** An Immersive Telepresence System using RGB-D Sensors and Head Mounted  Display

**Abstract Link:** [https://arxiv.org/abs/1511.06815](https://arxiv.org/abs/1511.06815)

**PDF Link:** [https://arxiv.org/pdf/1511.06815](https://arxiv.org/pdf/1511.06815)

---

**Date:** 15 Mar 2023

**Title:** Evaluating gesture-generation in a large-scale open challenge: The GENEA  Challenge 2022

**Abstract Link:** [https://arxiv.org/abs/2303.08737](https://arxiv.org/abs/2303.08737)

**PDF Link:** [https://arxiv.org/pdf/2303.08737](https://arxiv.org/pdf/2303.08737)

---

**Date:** 02 Nov 2023

**Title:** Typing on Any Surface: A Deep Learning-based Method for Real-Time  Keystroke Detection in Augmented Reality

**Abstract Link:** [https://arxiv.org/abs/2309.00174](https://arxiv.org/abs/2309.00174)

**PDF Link:** [https://arxiv.org/pdf/2309.00174](https://arxiv.org/pdf/2309.00174)

---

**Date:** 15 Jul 2021

**Title:** DAL: Feature Learning from Overt Speech to Decode Imagined Speech-based  EEG Signals with Convolutional Autoencoder

**Abstract Link:** [https://arxiv.org/abs/2107.07064](https://arxiv.org/abs/2107.07064)

**PDF Link:** [https://arxiv.org/pdf/2107.07064](https://arxiv.org/pdf/2107.07064)

---

**Date:** 09 Nov 2022

**Title:** Modeling Motivational Interviewing Strategies On An Online Peer-to-Peer  Counseling Platform

**Abstract Link:** [https://arxiv.org/abs/2211.05182](https://arxiv.org/abs/2211.05182)

**PDF Link:** [https://arxiv.org/pdf/2211.05182](https://arxiv.org/pdf/2211.05182)

---

**Date:** 29 Mar 2018

**Title:** Two can play this Game: Visual Dialog with Discriminative Question  Generation and Answering

**Abstract Link:** [https://arxiv.org/abs/1803.11186](https://arxiv.org/abs/1803.11186)

**PDF Link:** [https://arxiv.org/pdf/1803.11186](https://arxiv.org/pdf/1803.11186)

---

**Date:** 23 Aug 2019

**Title:** Deep Learning Based Chatbot Models

**Abstract Link:** [https://arxiv.org/abs/1908.08835](https://arxiv.org/abs/1908.08835)

**PDF Link:** [https://arxiv.org/pdf/1908.08835](https://arxiv.org/pdf/1908.08835)

---

**Date:** 07 Dec 2022

**Title:** Bodily Behaviors in Social Interaction: Novel Annotations and  State-of-the-Art Evaluation

**Abstract Link:** [https://arxiv.org/abs/2207.12817](https://arxiv.org/abs/2207.12817)

**PDF Link:** [https://arxiv.org/pdf/2207.12817](https://arxiv.org/pdf/2207.12817)

---

**Date:** 31 Aug 2021

**Title:** HUMBO: Bridging Response Generation and Facial Expression Synthesis

**Abstract Link:** [https://arxiv.org/abs/1905.11240](https://arxiv.org/abs/1905.11240)

**PDF Link:** [https://arxiv.org/pdf/1905.11240](https://arxiv.org/pdf/1905.11240)

---

**Date:** 07 Sep 2023

**Title:** Bootstrapping Adaptive Human-Machine Interfaces with Offline  Reinforcement Learning

**Abstract Link:** [https://arxiv.org/abs/2309.03839](https://arxiv.org/abs/2309.03839)

**PDF Link:** [https://arxiv.org/pdf/2309.03839](https://arxiv.org/pdf/2309.03839)

---

**Date:** 07 Mar 2022

**Title:** X2T: Training an X-to-Text Typing Interface with Online Learning from  User Feedback

**Abstract Link:** [https://arxiv.org/abs/2203.02072](https://arxiv.org/abs/2203.02072)

**PDF Link:** [https://arxiv.org/pdf/2203.02072](https://arxiv.org/pdf/2203.02072)

---

