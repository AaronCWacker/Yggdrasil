Create an image prompt with a giant ccastle far off in the distance but immense scale at sunset as catapults and Scorpion Ballista devestate the giant Castle city.

Here is an image prompt for a massive battle scene with a giant castle far in the distance being besieged by catapults and Scorpion Ballista at sunset:

In the fading light of the setting sun, an immense walled city surrounds an impossibly gigantic castle on the distant horizon. The towering spires and fortified walls of the castle seem to scrape the sky itself.

In the foreground, a vast army stretches out across the fields and hills surrounding the city. Catapults and massive Scorpion Ballista engines are lined up, flinging huge boulders and searing missiles over the walls. Flames lick at the outer buildings of the city as smoke billows upwards, lit by the orange glow of the sinking sun.

Soldiers scurry about, loading the massive siege weapons and ducking for cover from the few feeble return volleys coming from the hopelessly overwhelmed defenders. The sheer scale of the attack and the titanic size of the castle city create an epic, imposing scene of medieval warfare.