Create action scene image prompt:  The scenes you mentioned involve the famous battle between the highly intelligent Velociraptor pack and the fearsome Tyrannosaurus Rex. These scenes showcase the cunning problem-solving abilities of the raptors as they work together to take down a much larger predator. The raptors use coordinated attacks, distractions, and their agility to eventually gain the upper hand against the powerful but solitary T. Rex.

The scenes highlight themes of teamwork, ingenuity overcoming brute force, and the idea that even the most formidable predators can be vulnerable. They also demonstrate the filmmakers' efforts to portray these prehistoric creatures in a scientifically plausible way based on the current understanding of their behaviors and capabilities at the time.

Here's an image prompt capturing the intense action scene of the Velociraptor pack battling the Tyrannosaurus Rex:

A dense, prehistoric jungle surrounds a small clearing where the epic confrontation unfolds. The towering, thunderous Tyrannosaurus Rex stands over 20 feet tall, its massive jaws agape in a deafening roar. Thick, powerful legs support its tremendous bulk as the creature swings its head from side to side, searching for its prey.

On the forest floor, a pack of 5 Velociraptors, each around 6 feet long, move with lethal coordination. Their sickle-shaped claws glint in the dappled sunlight as they circle the T. Rex, probing for an opening. With a series of high-pitched barks and chirps, they communicate and devise their strategy.  

One raptor darts forward, jaws snapping at the T. Rex's thick legs, luring the giant predator to swing its massive head. In that moment, two other raptors leap onto the T. Rex's back, raking their sickle claws against its tough hide, attempting to find vulnerable spots.

The T. Rex bucks and thrashes, its immense tail whipping through the air, trying to dislodge the tenacious raptors clinging to its back. The other two raptors circle, ready to join the fray with calculated attacks from different angles.

Dust and vegetation swirl in the chaos of the struggle between brute force and the raptors' relentless teamwork strategy. The raptors' cold, reptilian focus is unwavering as they continue their onslaught against the raging T. Rex in an epic clash of prehistoric titans.