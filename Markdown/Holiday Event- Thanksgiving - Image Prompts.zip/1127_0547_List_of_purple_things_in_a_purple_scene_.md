List of purple things in a purple scene 


### 🔎 List of purple things in a purple scene 



1. Purple flowers
2. Purple grapes
3. Purple eggplant
4. Purple cabbage
5. Purple carrots
6. Purple potatoes
7. Purple onions
8. Purple kale
9. Purple beets
10. Purple radishes
11. Purple cauliflower
12. Purple broccoli
13. Purple asparagus
14. Purple bell peppers
15. Purple tomatoes
16. Purple corn
17. Purple kale
18. Purple lettuce
19. Purple spinach
20. Purple arugula
21. Purple basil
22. Purple mint
23. Purple thyme
24. Purple rosemary
25. Purple sage
26. Purple lavender
27. Purple hyacinth
28. Purple iris
29. Purple tulips
30. Purple lilies
31. Purple orchids
32. Purple daisies
33. Purple sunflowers
34. Purple roses
35. Purple peonies
36. Purple carnations
37. Purple gladiolus
38. Purple delphiniums
39. Purple foxgloves
40. Purple columbines
41. Purple pansies
42. Purple violets
43. Purple clematis
44. Purple morning glories
45. Purple passionflowers
46. Purple hibiscus
47. Purple bougainvillea
48. Purple wisteria
49. Purple plums
50. Purple grapes
51. Purple figs
52. Purple berries
53. Purple cherries
54. Purple plums
55. Purple apricots
56. Purple peaches
57. Purple nectarines
58. Purple mangoes
59. Purple grapes
60. Purple wine
61. Purple juice

# 🩺🔍 Search Results
### 09 Aug 2019 | [Counterfactual Critic Multi-Agent Training for Scene Graph Generation](https://arxiv.org/abs/1812.02347) | [⬇️](https://arxiv.org/pdf/1812.02347)
*Long Chen, Hanwang Zhang, Jun Xiao, Xiangnan He, Shiliang Pu, Shih-Fu  Chang* 

  Scene graphs -- objects as nodes and visual relationships as edges --
describe the whereabouts and interactions of the things and stuff in an image
for comprehensive scene understanding. To generate coherent scene graphs,
almost all existing methods exploit the fruitful visual context by modeling
message passing among objects, fitting the dynamic nature of reasoning with
visual context, eg, "person" on "bike" can help to determine the relationship
"ride", which in turn contributes to the category confidence of the two
objects. However, we argue that the scene dynamics is not properly learned by
using the prevailing cross-entropy based supervised learning paradigm, which is
not sensitive to graph inconsistency: errors at the hub or non-hub nodes are
unfortunately penalized equally. To this end, we propose a Counterfactual
critic Multi-Agent Training (CMAT) approach to resolve the mismatch. CMAT is a
multi-agent policy gradient method that frames objects as cooperative agents,
and then directly maximizes a graph-level metric as the reward. In particular,
to assign the reward properly to each agent, CMAT uses a counterfactual
baseline that disentangles the agent-specific reward by fixing the dynamics of
other agents. Extensive validations on the challenging Visual Genome benchmark
show that CMAT achieves a state-of-the-art by significant performance gains
under various settings and metrics.

---------------

### 22 Jun 2022 | [HSC4D: Human-centered 4D Scene Capture in Large-scale Indoor-outdoor  Space Using Wearable IMUs and LiDAR](https://arxiv.org/abs/2203.09215) | [⬇️](https://arxiv.org/pdf/2203.09215)
*Yudi Dai (1), Yitai Lin (1), Chenglu Wen (1), Siqi Shen (1), Lan Xu  (2), Jingyi Yu (2), Yuexin Ma (2), Cheng Wang (1) ((1) Xiamen University,  China, (2) ShanghaiTech University, China)* 

  We propose Human-centered 4D Scene Capture (HSC4D) to accurately and
efficiently create a dynamic digital world, containing large-scale
indoor-outdoor scenes, diverse human motions, and rich interactions between
humans and environments. Using only body-mounted IMUs and LiDAR, HSC4D is
space-free without any external devices' constraints and map-free without
pre-built maps. Considering that IMUs can capture human poses but always drift
for long-period use, while LiDAR is stable for global localization but rough
for local positions and orientations, HSC4D makes both sensors complement each
other by a joint optimization and achieves promising results for long-term
capture. Relationships between humans and environments are also explored to
make their interaction more realistic. To facilitate many down-stream tasks,
like AR, VR, robots, autonomous driving, etc., we propose a dataset containing
three large scenes (1k-5k $m^2$) with accurate dynamic human motions and
locations. Diverse scenarios (climbing gym, multi-story building, slope, etc.)
and challenging human activities (exercising, walking up/down stairs, climbing,
etc.) demonstrate the effectiveness and the generalization ability of HSC4D.
The dataset and code are available at http://www.lidarhumanmotion.net/hsc4d/.

---------------

### 26 Jun 2020 | [Acoustic Scene Classification with Squeeze-Excitation Residual Networks](https://arxiv.org/abs/2003.09284) | [⬇️](https://arxiv.org/pdf/2003.09284)
*Javier Naranjo-Alcazar, Sergi Perez-Castanos, Pedro Zuccarello and  Maximo Cobos* 

  Acoustic scene classification (ASC) is a problem related to the field of
machine listening whose objective is to classify/tag an audio clip in a
predefined label describing a scene location (e. g. park, airport, etc.). Many
state-of-the-art solutions to ASC incorporate data augmentation techniques and
model ensembles. However, considerable improvements can also be achieved only
by modifying the architecture of convolutional neural networks (CNNs). In this
work we propose two novel squeeze-excitation blocks to improve the accuracy of
a CNN-based ASC framework based on residual learning. The main idea of
squeeze-excitation blocks is to learn spatial and channel-wise feature maps
independently instead of jointly as standard CNNs do. This is usually achieved
by some global grouping operators, linear operators and a final calibration
between the input of the block and its obtained relationships. The behavior of
the block that implements such operators and, therefore, the entire neural
network, can be modified depending on the input to the block, the established
residual configurations and the selected non-linear activations. The analysis
has been carried out using the TAU Urban Acoustic Scenes 2019 dataset
(https://zenodo.org/record/2589280) presented in the 2019 edition of the DCASE
challenge. All configurations discussed in this document exceed the performance
of the baseline proposed by the DCASE organization by 13\% percentage points.
In turn, the novel configurations proposed in this paper outperform the
residual configurations proposed in previous works.

---------------

### 06 Jul 2023 | [PSDR-Room: Single Photo to Scene using Differentiable Rendering](https://arxiv.org/abs/2307.03244) | [⬇️](https://arxiv.org/pdf/2307.03244)
*Kai Yan, Fujun Luan, Milo\v{S} Ha\v{S}An, Thibault Groueix, Valentin  Deschaintre, Shuang Zhao* 

  A 3D digital scene contains many components: lights, materials and
geometries, interacting to reach the desired appearance. Staging such a scene
is time-consuming and requires both artistic and technical skills. In this
work, we propose PSDR-Room, a system allowing to optimize lighting as well as
the pose and materials of individual objects to match a target image of a room
scene, with minimal user input. To this end, we leverage a recent path-space
differentiable rendering approach that provides unbiased gradients of the
rendering with respect to geometry, lighting, and procedural materials,
allowing us to optimize all of these components using gradient descent to
visually match the input photo appearance. We use recent single-image scene
understanding methods to initialize the optimization and search for appropriate
3D models and materials. We evaluate our method on real photographs of indoor
scenes and demonstrate the editability of the resulting scene components.

---------------

### 16 Feb 2023 | [SceneHGN: Hierarchical Graph Networks for 3D Indoor Scene Generation  with Fine-Grained Geometry](https://arxiv.org/abs/2302.10237) | [⬇️](https://arxiv.org/pdf/2302.10237)
*Lin Gao, Jia-Mu Sun, Kaichun Mo, Yu-Kun Lai, Leonidas J. Guibas, Jie  Yang* 

  3D indoor scenes are widely used in computer graphics, with applications
ranging from interior design to gaming to virtual and augmented reality. They
also contain rich information, including room layout, as well as furniture
type, geometry, and placement. High-quality 3D indoor scenes are highly
demanded while it requires expertise and is time-consuming to design
high-quality 3D indoor scenes manually. Existing research only addresses
partial problems: some works learn to generate room layout, and other works
focus on generating detailed structure and geometry of individual furniture
objects. However, these partial steps are related and should be addressed
together for optimal synthesis. We propose SCENEHGN, a hierarchical graph
network for 3D indoor scenes that takes into account the full hierarchy from
the room level to the object level, then finally to the object part level.
Therefore for the first time, our method is able to directly generate plausible
3D room content, including furniture objects with fine-grained geometry, and
their layout. To address the challenge, we introduce functional regions as
intermediate proxies between the room and object levels to make learning more
manageable. To ensure plausibility, our graph-based representation incorporates
both vertical edges connecting child nodes with parent nodes from different
levels, and horizontal edges encoding relationships between nodes at the same
level. Extensive experiments demonstrate that our method produces superior
generation results, even when comparing results of partial steps with
alternative methods that can only achieve these. We also demonstrate that our
method is effective for various applications such as part-level room editing,
room interpolation, and room generation by arbitrary room boundaries.

---------------

### 10 Apr 2019 | [Hierarchy Denoising Recursive Autoencoders for 3D Scene Layout  Prediction](https://arxiv.org/abs/1903.03757) | [⬇️](https://arxiv.org/pdf/1903.03757)
*Yifei Shi, Angel Xuan Chang, Zhelun Wu, Manolis Savva, Kai Xu* 

  Indoor scenes exhibit rich hierarchical structure in 3D object layouts. Many
tasks in 3D scene understanding can benefit from reasoning jointly about the
hierarchical context of a scene, and the identities of objects. We present a
variational denoising recursive autoencoder (VDRAE) that generates and
iteratively refines a hierarchical representation of 3D object layouts,
interleaving bottom-up encoding for context aggregation and top-down decoding
for propagation. We train our VDRAE on large-scale 3D scene datasets to predict
both instance-level segmentations and a 3D object detections from an
over-segmentation of an input point cloud. We show that our VDRAE improves
object detection performance on real-world 3D point cloud datasets compared to
baselines from prior work.

---------------

### 23 Jul 2019 | [U4D: Unsupervised 4D Dynamic Scene Understanding](https://arxiv.org/abs/1907.09905) | [⬇️](https://arxiv.org/pdf/1907.09905)
*Armin Mustafa, Chris Russell and Adrian Hilton* 

  We introduce the first approach to solve the challenging problem of
unsupervised 4D visual scene understanding for complex dynamic scenes with
multiple interacting people from multi-view video. Our approach simultaneously
estimates a detailed model that includes a per-pixel semantically and
temporally coherent reconstruction, together with instance-level segmentation
exploiting photo-consistency, semantic and motion information. We further
leverage recent advances in 3D pose estimation to constrain the joint semantic
instance segmentation and 4D temporally coherent reconstruction. This enables
per person semantic instance segmentation of multiple interacting people in
complex dynamic scenes. Extensive evaluation of the joint visual scene
understanding framework against state-of-the-art methods on challenging indoor
and outdoor sequences demonstrates a significant (approx 40%) improvement in
semantic segmentation, reconstruction and scene flow accuracy.

---------------

### 22 Aug 2023 | [Faster Optimization in S-Graphs Exploiting Hierarchy](https://arxiv.org/abs/2308.11242) | [⬇️](https://arxiv.org/pdf/2308.11242)
*Hriday Bavle, Jose Luis Sanchez-Lopez, Javier Civera, Holger Voos* 

  3D scene graphs hierarchically represent the environment appropriately
organizing different environmental entities in various layers. Our previous
work on situational graphs extends the concept of 3D scene graph to SLAM by
tightly coupling the robot poses with the scene graph entities, achieving
state-of-the-art results. Though, one of the limitations of S-Graphs is
scalability in really large environments due to the increased graph size over
time, increasing the computational complexity.
  To overcome this limitation in this work we present an initial research of an
improved version of S-Graphs exploiting the hierarchy to reduce the graph size
by marginalizing redundant robot poses and their connections to the
observations of the same structural entities. Firstly, we propose the
generation and optimization of room-local graphs encompassing all graph
entities within a room-like structure. These room-local graphs are used to
compress the S-Graphs marginalizing the redundant robot keyframes within the
given room. We then perform windowed local optimization of the compressed graph
at regular time-distance intervals. A global optimization of the compressed
graph is performed every time a loop closure is detected. We show similar
accuracy compared to the baseline while showing a 39.81% reduction in the
computation time with respect to the baseline.

---------------

### 20 Feb 2021 | [Deep Learning for Scene Classification: A Survey](https://arxiv.org/abs/2101.10531) | [⬇️](https://arxiv.org/pdf/2101.10531)
*Delu Zeng, Minyu Liao, Mohammad Tavakolian, Yulan Guo, Bolei Zhou,  Dewen Hu, Matti Pietik\"ainen, Li Liu* 

  Scene classification, aiming at classifying a scene image to one of the
predefined scene categories by comprehending the entire image, is a
longstanding, fundamental and challenging problem in computer vision. The rise
of large-scale datasets, which constitute the corresponding dense sampling of
diverse real-world scenes, and the renaissance of deep learning techniques,
which learn powerful feature representations directly from big raw data, have
been bringing remarkable progress in the field of scene representation and
classification. To help researchers master needed advances in this field, the
goal of this paper is to provide a comprehensive survey of recent achievements
in scene classification using deep learning. More than 200 major publications
are included in this survey covering different aspects of scene classification,
including challenges, benchmark datasets, taxonomy, and quantitative
performance comparisons of the reviewed methods. In retrospect of what has been
achieved so far, this paper is also concluded with a list of promising research
opportunities.

---------------

### 07 Jan 2022 | [A Comprehensive Survey of Scene Graphs: Generation and Application](https://arxiv.org/abs/2104.01111) | [⬇️](https://arxiv.org/pdf/2104.01111)
*Xiaojun Chang, Pengzhen Ren, Pengfei Xu, Zhihui Li, Xiaojiang Chen,  and Alex Hauptmann* 

  Scene graph is a structured representation of a scene that can clearly
express the objects, attributes, and relationships between objects in the
scene. As computer vision technology continues to develop, people are no longer
satisfied with simply detecting and recognizing objects in images; instead,
people look forward to a higher level of understanding and reasoning about
visual scenes. For example, given an image, we want to not only detect and
recognize objects in the image, but also know the relationship between objects
(visual relationship detection), and generate a text description (image
captioning) based on the image content. Alternatively, we might want the
machine to tell us what the little girl in the image is doing (Visual Question
Answering (VQA)), or even remove the dog from the image and find similar images
(image editing and retrieval), etc. These tasks require a higher level of
understanding and reasoning for image vision tasks. The scene graph is just
such a powerful tool for scene understanding. Therefore, scene graphs have
attracted the attention of a large number of researchers, and related research
is often cross-modal, complex, and rapidly developing. However, no relatively
systematic survey of scene graphs exists at present. To this end, this survey
conducts a comprehensive investigation of the current scene graph research.
More specifically, we first summarized the general definition of the scene
graph, then conducted a comprehensive and systematic discussion on the
generation method of the scene graph (SGG) and the SGG with the aid of prior
knowledge. We then investigated the main applications of scene graphs and
summarized the most commonly used datasets. Finally, we provide some insights
into the future development of scene graphs. We believe this will be a very
helpful foundation for future research on scene graphs.

---------------

### 19 Aug 2020 | [Blur-Attention: A boosting mechanism for non-uniform blurred image  restoration](https://arxiv.org/abs/2008.08526) | [⬇️](https://arxiv.org/pdf/2008.08526)
*Xiaoguang Li, Feifan Yang, Kin Man Lam, Li Zhuo, Jiafeng Li* 

  Dynamic scene deblurring is a challenging problem in computer vision. It is
difficult to accurately estimate the spatially varying blur kernel by
traditional methods. Data-driven-based methods usually employ kernel-free
end-to-end mapping schemes, which are apt to overlook the kernel estimation. To
address this issue, we propose a blur-attention module to dynamically capture
the spatially varying features of non-uniform blurred images. The module
consists of a DenseBlock unit and a spatial attention unit with multi-pooling
feature fusion, which can effectively extract complex spatially varying blur
features. We design a multi-level residual connection structure to connect
multiple blur-attention modules to form a blur-attention network. By
introducing the blur-attention network into a conditional generation
adversarial framework, we propose an end-to-end blind motion deblurring method,
namely Blur-Attention-GAN (BAG), for a single image. Our method can adaptively
select the weights of the extracted features according to the spatially varying
blur features, and dynamically restore the images. Experimental results show
that the deblurring capability of our method achieved outstanding objective
performance in terms of PSNR, SSIM, and subjective visual quality. Furthermore,
by visualizing the features extracted by the blur-attention module,
comprehensive discussions are provided on its effectiveness.

---------------

### 22 Jul 2020 | [Finding Your (3D) Center: 3D Object Detection Using a Learned Loss](https://arxiv.org/abs/2004.02693) | [⬇️](https://arxiv.org/pdf/2004.02693)
*David Griffiths, Jan Boehm, Tobias Ritschel* 

  Massive semantically labeled datasets are readily available for 2D images,
however, are much harder to achieve for 3D scenes. Objects in 3D repositories
like ShapeNet are labeled, but regrettably only in isolation, so without
context. 3D scenes can be acquired by range scanners on city-level scale, but
much fewer with semantic labels. Addressing this disparity, we introduce a new
optimization procedure, which allows training for 3D detection with raw 3D
scans while using as little as 5% of the object labels and still achieve
comparable performance. Our optimization uses two networks. A scene network
maps an entire 3D scene to a set of 3D object centers. As we assume the scene
not to be labeled by centers, no classic loss, such as Chamfer can be used to
train it. Instead, we use another network to emulate the loss. This loss
network is trained on a small labeled subset and maps a non centered 3D object
in the presence of distractions to its own center. This function is very
similar - and hence can be used instead of - the gradient the supervised loss
would provide. Our evaluation documents competitive fidelity at a much lower
level of supervision, respectively higher quality at comparable supervision.
Supplementary material can be found at: https://dgriffiths3.github.io.

---------------

### 26 Oct 2022 | [Fast and Efficient Scene Categorization for Autonomous Driving using  VAEs](https://arxiv.org/abs/2210.14981) | [⬇️](https://arxiv.org/pdf/2210.14981)
*Saravanabalagi Ramachandran, Jonathan Horgan, Ganesh Sistu, and John  McDonald* 

  Scene categorization is a useful precursor task that provides prior knowledge
for many advanced computer vision tasks with a broad range of applications in
content-based image indexing and retrieval systems. Despite the success of data
driven approaches in the field of computer vision such as object detection,
semantic segmentation, etc., their application in learning high-level features
for scene recognition has not achieved the same level of success. We propose to
generate a fast and efficient intermediate interpretable generalized global
descriptor that captures coarse features from the image and use a
classification head to map the descriptors to 3 scene categories: Rural, Urban
and Suburban. We train a Variational Autoencoder in an unsupervised manner and
map images to a constrained multi-dimensional latent space and use the latent
vectors as compact embeddings that serve as global descriptors for images. The
experimental results evidence that the VAE latent vectors capture coarse
information from the image, supporting their usage as global descriptors. The
proposed global descriptor is very compact with an embedding length of 128,
significantly faster to compute, and is robust to seasonal and illuminational
changes, while capturing sufficient scene information required for scene
categorization.

---------------

### 20 Jun 2022 | [Hydra: A Real-time Spatial Perception System for 3D Scene Graph  Construction and Optimization](https://arxiv.org/abs/2201.13360) | [⬇️](https://arxiv.org/pdf/2201.13360)
*Nathan Hughes, Yun Chang, Luca Carlone* 

  3D scene graphs have recently emerged as a powerful high-level representation
of 3D environments. A 3D scene graph describes the environment as a layered
graph where nodes represent spatial concepts at multiple levels of abstraction
and edges represent relations between concepts. While 3D scene graphs can serve
as an advanced "mental model" for robots, how to build such a rich
representation in real-time is still uncharted territory. This paper describes
a real-time Spatial Perception System, a suite of algorithms to build a 3D
scene graph from sensor data in real-time. Our first contribution is to develop
real-time algorithms to incrementally construct the layers of a scene graph as
the robot explores the environment; these algorithms build a local Euclidean
Signed Distance Function (ESDF) around the current robot location, extract a
topological map of places from the ESDF, and then segment the places into rooms
using an approach inspired by community-detection techniques. Our second
contribution is to investigate loop closure detection and optimization in 3D
scene graphs. We show that 3D scene graphs allow defining hierarchical
descriptors for loop closure detection; our descriptors capture statistics
across layers in the scene graph, ranging from low-level visual appearance to
summary statistics about objects and places. We then propose the first
algorithm to optimize a 3D scene graph in response to loop closures; our
approach relies on embedded deformation graphs to simultaneously correct all
layers of the scene graph. We implement the proposed Spatial Perception System
into a architecture named Hydra, that combines fast early and mid-level
perception processes with slower high-level perception. We evaluate Hydra on
simulated and real data and show it is able to reconstruct 3D scene graphs with
an accuracy comparable with batch offline methods despite running online.

---------------

### 15 Dec 2023 | [Spatial-Temporal Knowledge-Embedded Transformer for Video Scene Graph  Generation](https://arxiv.org/abs/2309.13237) | [⬇️](https://arxiv.org/pdf/2309.13237)
*Tao Pu, Tianshui Chen, Hefeng Wu, Yongyi Lu, Liang Lin* 

  Video scene graph generation (VidSGG) aims to identify objects in visual
scenes and infer their relationships for a given video. It requires not only a
comprehensive understanding of each object scattered on the whole scene but
also a deep dive into their temporal motions and interactions. Inherently,
object pairs and their relationships enjoy spatial co-occurrence correlations
within each image and temporal consistency/transition correlations across
different images, which can serve as prior knowledge to facilitate VidSGG model
learning and inference. In this work, we propose a spatial-temporal
knowledge-embedded transformer (STKET) that incorporates the prior
spatial-temporal knowledge into the multi-head cross-attention mechanism to
learn more representative relationship representations. Specifically, we first
learn spatial co-occurrence and temporal transition correlations in a
statistical manner. Then, we design spatial and temporal knowledge-embedded
layers that introduce the multi-head cross-attention mechanism to fully explore
the interaction between visual representation and the knowledge to generate
spatial- and temporal-embedded representations, respectively. Finally, we
aggregate these representations for each subject-object pair to predict the
final semantic labels and their relationships. Extensive experiments show that
STKET outperforms current competing algorithms by a large margin, e.g.,
improving the mR@50 by 8.1%, 4.7%, and 2.1% on different settings over current
algorithms.

---------------

### 12 Jan 2019 | [NRMVS: Non-Rigid Multi-View Stereo](https://arxiv.org/abs/1901.03910) | [⬇️](https://arxiv.org/pdf/1901.03910)
*Matthias Innmann, Kihwan Kim, Jinwei Gu, Matthias Niessner, Charles  Loop, Marc Stamminger, Jan Kautz* 

  Scene reconstruction from unorganized RGB images is an important task in many
computer vision applications. Multi-view Stereo (MVS) is a common solution in
photogrammetry applications for the dense reconstruction of a static scene. The
static scene assumption, however, limits the general applicability of MVS
algorithms, as many day-to-day scenes undergo non-rigid motion, e.g., clothes,
faces, or human bodies. In this paper, we open up a new challenging direction:
dense 3D reconstruction of scenes with non-rigid changes observed from
arbitrary, sparse, and wide-baseline views. We formulate the problem as a joint
optimization of deformation and depth estimation, using deformation graphs as
the underlying representation. We propose a new sparse 3D to 2D matching
technique, together with a dense patch-match evaluation scheme to estimate
deformation and depth with photometric consistency. We show that creating a
dense 4D structure from a few RGB images with non-rigid changes is possible,
and demonstrate that our method can be used to interpolate novel deformed
scenes from various combinations of these deformation estimates derived from
the sparse views.

---------------

### 06 Oct 2019 | [Joint Stereo Video Deblurring, Scene Flow Estimation and Moving Object  Segmentation](https://arxiv.org/abs/1910.02442) | [⬇️](https://arxiv.org/pdf/1910.02442)
*Liyuan Pan, Yuchao Dai, Miaomiao Liu, Fatih Porikli, Quan Pan* 

  Stereo videos for the dynamic scenes often show unpleasant blurred effects
due to the camera motion and the multiple moving objects with large depth
variations. Given consecutive blurred stereo video frames, we aim to recover
the latent clean images, estimate the 3D scene flow and segment the multiple
moving objects. These three tasks have been previously addressed separately,
which fail to exploit the internal connections among these tasks and cannot
achieve optimality. In this paper, we propose to jointly solve these three
tasks in a unified framework by exploiting their intrinsic connections. To this
end, we represent the dynamic scenes with the piece-wise planar model, which
exploits the local structure of the scene and expresses various dynamic scenes.
Under our model, these three tasks are naturally connected and expressed as the
parameter estimation of 3D scene structure and camera motion (structure and
motion for the dynamic scenes). By exploiting the blur model constraint, the
moving objects and the 3D scene structure, we reach an energy minimization
formulation for joint deblurring, scene flow and segmentation. We evaluate our
approach extensively on both synthetic datasets and publicly available real
datasets with fast-moving objects, camera motion, uncontrolled lighting
conditions and shadows. Experimental results demonstrate that our method can
achieve significant improvement in stereo video deblurring, scene flow
estimation and moving object segmentation, over state-of-the-art methods.

---------------

### 04 Aug 2020 | [Tracking Emerges by Looking Around Static Scenes, with Neural 3D Mapping](https://arxiv.org/abs/2008.01295) | [⬇️](https://arxiv.org/pdf/2008.01295)
*Adam W. Harley, Shrinidhi K. Lakshmikanth, Paul Schydlo, Katerina  Fragkiadaki* 

  We hypothesize that an agent that can look around in static scenes can learn
rich visual representations applicable to 3D object tracking in complex dynamic
scenes. We are motivated in this pursuit by the fact that the physical world
itself is mostly static, and multiview correspondence labels are relatively
cheap to collect in static scenes, e.g., by triangulation. We propose to
leverage multiview data of \textit{static points} in arbitrary scenes (static
or dynamic), to learn a neural 3D mapping module which produces features that
are correspondable across time. The neural 3D mapper consumes RGB-D data as
input, and produces a 3D voxel grid of deep features as output. We train the
voxel features to be correspondable across viewpoints, using a contrastive
loss, and correspondability across time emerges automatically. At test time,
given an RGB-D video with approximate camera poses, and given the 3D box of an
object to track, we track the target object by generating a map of each
timestep and locating the object's features within each map. In contrast to
models that represent video streams in 2D or 2.5D, our model's 3D scene
representation is disentangled from projection artifacts, is stable under
camera motion, and is robust to partial occlusions. We test the proposed
architectures in challenging simulated and real data, and show that our
unsupervised 3D object trackers outperform prior unsupervised 2D and 2.5D
trackers, and approach the accuracy of supervised trackers. This work
demonstrates that 3D object trackers can emerge without tracking labels,
through multiview self-supervision on static data.

---------------

### 01 Sep 2023 | [Clutter Detection and Removal in 3D Scenes with View-Consistent  Inpainting](https://arxiv.org/abs/2304.03763) | [⬇️](https://arxiv.org/pdf/2304.03763)
*Fangyin Wei, Thomas Funkhouser, Szymon Rusinkiewicz* 

  Removing clutter from scenes is essential in many applications, ranging from
privacy-concerned content filtering to data augmentation. In this work, we
present an automatic system that removes clutter from 3D scenes and inpaints
with coherent geometry and texture. We propose techniques for its two key
components: 3D segmentation from shared properties and 3D inpainting, both of
which are important problems. The definition of 3D scene clutter
(frequently-moving objects) is not well captured by commonly-studied object
categories in computer vision. To tackle the lack of well-defined clutter
annotations, we group noisy fine-grained labels, leverage virtual rendering,
and impose an instance-level area-sensitive loss. Once clutter is removed, we
inpaint geometry and texture in the resulting holes by merging inpainted RGB-D
images. This requires novel voting and pruning strategies that guarantee
multi-view consistency across individually inpainted images for mesh
reconstruction. Experiments on ScanNet and Matterport dataset show that our
method outperforms baselines for clutter segmentation and 3D inpainting, both
visually and quantitatively.

---------------

### 26 Apr 2023 | [Hydra-Multi: Collaborative Online Construction of 3D Scene Graphs with  Multi-Robot Teams](https://arxiv.org/abs/2304.13487) | [⬇️](https://arxiv.org/pdf/2304.13487)
*Yun Chang, Nathan Hughes, Aaron Ray, Luca Carlone* 

  3D scene graphs have recently emerged as an expressive high-level map
representation that describes a 3D environment as a layered graph where nodes
represent spatial concepts at multiple levels of abstraction (e.g., objects,
rooms, buildings) and edges represent relations between concepts (e.g.,
inclusion, adjacency). This paper describes Hydra-Multi, the first multi-robot
spatial perception system capable of constructing a multi-robot 3D scene graph
online from sensor data collected by robots in a team. In particular, we
develop a centralized system capable of constructing a joint 3D scene graph by
taking incremental inputs from multiple robots, effectively finding the
relative transforms between the robots' frames, and incorporating loop closure
detections to correctly reconcile the scene graph nodes from different robots.
We evaluate Hydra-Multi on simulated and real scenarios and show it is able to
reconstruct accurate 3D scene graphs online. We also demonstrate Hydra-Multi's
capability of supporting heterogeneous teams by fusing different map
representations built by robots with different sensor suites.

---------------
**Date:** 09 Aug 2019

**Title:** Counterfactual Critic Multi-Agent Training for Scene Graph Generation

**Abstract Link:** [https://arxiv.org/abs/1812.02347](https://arxiv.org/abs/1812.02347)

**PDF Link:** [https://arxiv.org/pdf/1812.02347](https://arxiv.org/pdf/1812.02347)

---

**Date:** 22 Jun 2022

**Title:** HSC4D: Human-centered 4D Scene Capture in Large-scale Indoor-outdoor  Space Using Wearable IMUs and LiDAR

**Abstract Link:** [https://arxiv.org/abs/2203.09215](https://arxiv.org/abs/2203.09215)

**PDF Link:** [https://arxiv.org/pdf/2203.09215](https://arxiv.org/pdf/2203.09215)

---

**Date:** 26 Jun 2020

**Title:** Acoustic Scene Classification with Squeeze-Excitation Residual Networks

**Abstract Link:** [https://arxiv.org/abs/2003.09284](https://arxiv.org/abs/2003.09284)

**PDF Link:** [https://arxiv.org/pdf/2003.09284](https://arxiv.org/pdf/2003.09284)

---

**Date:** 06 Jul 2023

**Title:** PSDR-Room: Single Photo to Scene using Differentiable Rendering

**Abstract Link:** [https://arxiv.org/abs/2307.03244](https://arxiv.org/abs/2307.03244)

**PDF Link:** [https://arxiv.org/pdf/2307.03244](https://arxiv.org/pdf/2307.03244)

---

**Date:** 16 Feb 2023

**Title:** SceneHGN: Hierarchical Graph Networks for 3D Indoor Scene Generation  with Fine-Grained Geometry

**Abstract Link:** [https://arxiv.org/abs/2302.10237](https://arxiv.org/abs/2302.10237)

**PDF Link:** [https://arxiv.org/pdf/2302.10237](https://arxiv.org/pdf/2302.10237)

---

**Date:** 10 Apr 2019

**Title:** Hierarchy Denoising Recursive Autoencoders for 3D Scene Layout  Prediction

**Abstract Link:** [https://arxiv.org/abs/1903.03757](https://arxiv.org/abs/1903.03757)

**PDF Link:** [https://arxiv.org/pdf/1903.03757](https://arxiv.org/pdf/1903.03757)

---

**Date:** 23 Jul 2019

**Title:** U4D: Unsupervised 4D Dynamic Scene Understanding

**Abstract Link:** [https://arxiv.org/abs/1907.09905](https://arxiv.org/abs/1907.09905)

**PDF Link:** [https://arxiv.org/pdf/1907.09905](https://arxiv.org/pdf/1907.09905)

---

**Date:** 22 Aug 2023

**Title:** Faster Optimization in S-Graphs Exploiting Hierarchy

**Abstract Link:** [https://arxiv.org/abs/2308.11242](https://arxiv.org/abs/2308.11242)

**PDF Link:** [https://arxiv.org/pdf/2308.11242](https://arxiv.org/pdf/2308.11242)

---

**Date:** 20 Feb 2021

**Title:** Deep Learning for Scene Classification: A Survey

**Abstract Link:** [https://arxiv.org/abs/2101.10531](https://arxiv.org/abs/2101.10531)

**PDF Link:** [https://arxiv.org/pdf/2101.10531](https://arxiv.org/pdf/2101.10531)

---

**Date:** 07 Jan 2022

**Title:** A Comprehensive Survey of Scene Graphs: Generation and Application

**Abstract Link:** [https://arxiv.org/abs/2104.01111](https://arxiv.org/abs/2104.01111)

**PDF Link:** [https://arxiv.org/pdf/2104.01111](https://arxiv.org/pdf/2104.01111)

---

**Date:** 19 Aug 2020

**Title:** Blur-Attention: A boosting mechanism for non-uniform blurred image  restoration

**Abstract Link:** [https://arxiv.org/abs/2008.08526](https://arxiv.org/abs/2008.08526)

**PDF Link:** [https://arxiv.org/pdf/2008.08526](https://arxiv.org/pdf/2008.08526)

---

**Date:** 22 Jul 2020

**Title:** Finding Your (3D) Center: 3D Object Detection Using a Learned Loss

**Abstract Link:** [https://arxiv.org/abs/2004.02693](https://arxiv.org/abs/2004.02693)

**PDF Link:** [https://arxiv.org/pdf/2004.02693](https://arxiv.org/pdf/2004.02693)

---

**Date:** 26 Oct 2022

**Title:** Fast and Efficient Scene Categorization for Autonomous Driving using  VAEs

**Abstract Link:** [https://arxiv.org/abs/2210.14981](https://arxiv.org/abs/2210.14981)

**PDF Link:** [https://arxiv.org/pdf/2210.14981](https://arxiv.org/pdf/2210.14981)

---

**Date:** 20 Jun 2022

**Title:** Hydra: A Real-time Spatial Perception System for 3D Scene Graph  Construction and Optimization

**Abstract Link:** [https://arxiv.org/abs/2201.13360](https://arxiv.org/abs/2201.13360)

**PDF Link:** [https://arxiv.org/pdf/2201.13360](https://arxiv.org/pdf/2201.13360)

---

**Date:** 15 Dec 2023

**Title:** Spatial-Temporal Knowledge-Embedded Transformer for Video Scene Graph  Generation

**Abstract Link:** [https://arxiv.org/abs/2309.13237](https://arxiv.org/abs/2309.13237)

**PDF Link:** [https://arxiv.org/pdf/2309.13237](https://arxiv.org/pdf/2309.13237)

---

**Date:** 12 Jan 2019

**Title:** NRMVS: Non-Rigid Multi-View Stereo

**Abstract Link:** [https://arxiv.org/abs/1901.03910](https://arxiv.org/abs/1901.03910)

**PDF Link:** [https://arxiv.org/pdf/1901.03910](https://arxiv.org/pdf/1901.03910)

---

**Date:** 06 Oct 2019

**Title:** Joint Stereo Video Deblurring, Scene Flow Estimation and Moving Object  Segmentation

**Abstract Link:** [https://arxiv.org/abs/1910.02442](https://arxiv.org/abs/1910.02442)

**PDF Link:** [https://arxiv.org/pdf/1910.02442](https://arxiv.org/pdf/1910.02442)

---

**Date:** 04 Aug 2020

**Title:** Tracking Emerges by Looking Around Static Scenes, with Neural 3D Mapping

**Abstract Link:** [https://arxiv.org/abs/2008.01295](https://arxiv.org/abs/2008.01295)

**PDF Link:** [https://arxiv.org/pdf/2008.01295](https://arxiv.org/pdf/2008.01295)

---

**Date:** 01 Sep 2023

**Title:** Clutter Detection and Removal in 3D Scenes with View-Consistent  Inpainting

**Abstract Link:** [https://arxiv.org/abs/2304.03763](https://arxiv.org/abs/2304.03763)

**PDF Link:** [https://arxiv.org/pdf/2304.03763](https://arxiv.org/pdf/2304.03763)

---

**Date:** 26 Apr 2023

**Title:** Hydra-Multi: Collaborative Online Construction of 3D Scene Graphs with  Multi-Robot Teams

**Abstract Link:** [https://arxiv.org/abs/2304.13487](https://arxiv.org/abs/2304.13487)

**PDF Link:** [https://arxiv.org/pdf/2304.13487](https://arxiv.org/pdf/2304.13487)

---

