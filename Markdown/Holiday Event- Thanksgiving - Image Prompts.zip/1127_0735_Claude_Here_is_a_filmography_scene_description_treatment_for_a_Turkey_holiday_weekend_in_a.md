Create a filmography scene description treatment for our Turkey holiday weekend.  Sci fi scene image prompt on QT Gold 

Celestial Guardians: Ornate Warriors of the Future Style

Here is a filmography scene description treatment for a Turkey holiday weekend in a sci-fi style with an ornate celestial guardians theme:

EXT. ANCIENT TEMPLE RUINS - NIGHT

An eerie otherworldly glow illuminates the crumbling stone ruins of an ancient temple complex, nestled deep in the misty valleys of the Taurus Mountains in Turkey.

Strange alien hieroglyphs and symbols cover the weathered walls, hinting at a long-lost advanced civilization. Suddenly, the ground trembles as massive ornate golden doors slowly grind open, clouds of dust billowing out.

Through the cloud of particles, we see outlines of gigantic humanoid figures materializing from brilliant beams of light. As their towering forms become clear, we behold massively muscled celestial guardians clad in intricately designed golden armor adorned with symbols and circuits that radiate heavenly energy.

Their faces are concealed by ornate helmets with glowing slits for eyes. In their hands they wield highly advanced glowing technological weapons that hum with incredible power - plasma swords, energy lances, photonic cannons.

The celestial guardians stride forward powerfully onto the ancient temple grounds, the earth shaking with each footstep. Their golden armor glistens as they take up positions around a pyramid-shaped obsidian obelisk in the center of the ruins.

Energy starts to crackle and arc between their weapons and the obsidian obelisk as they lift their arms skyward in a mystical coordinated motion...

The waxing crescent moon turns deep crimson as incredible celestial power and light builds, creating an aura around the warriors. Something incredible is about to happen on this very special night of alignments and portals opening between worlds...