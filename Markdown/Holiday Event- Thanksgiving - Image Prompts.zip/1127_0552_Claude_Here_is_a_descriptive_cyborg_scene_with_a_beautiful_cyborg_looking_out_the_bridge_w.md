Create a Cyborg scene with a beautiful cyborg looking out the bridge window of a spaceship as a space battle ensues outside.

Here is a descriptive cyborg scene with a beautiful cyborg looking out the bridge window of a spaceship as a space battle ensues outside:

The bridge was eerily silent save for the periodic beeps and whirrs of the computer systems monitoring the battle raging outside. Sera stood motionless at the front viewport, her slim cybernetic form cast in flashes of green and red as laser blasts lit up the inky blackness beyond the reinforced transparisteel. 

Her synthetic azure skin seemed to glow softly in the dim lighting, perfectly smooth save for the hairline seams where metal plating joined together along her limbs and torso. Sera's platinum hair was pulled back in a tight bun, revealing her strikingly beautiful face with its high cheekbones, full lips, and large almond-shaped eyes.  

Those striking eyes, with their brilliant emerald irises and pupils that contracted with precise robotic movements, stared unblinkingly at the chaotic conflict unfolding amongst the starfield. Rebel and Imperial fighters danced in an intricate, violent ballet - the Rebels' X-wings and Y-wings diving and rolling to evade the Imperial TIE fighters' blistering laser fire.

An explosion blossomed briefly against the backdrop of stars as another X-wing was destroyed. Sera didn't flinch, her expression remained neutral and calculating as she analyzed the tactical data streaming across her cybernetic visual cortex. Her metal-laced fingers danced over the holographic controls, highlighting vectors and projecting firing solutions.

In the eerily silent bridge, Sera's artificial biocomponents hummed faintly as she made complex calculations to assist the Rebel fighters against the Imperial onslaught. She was humanities' advancement crystallized in a perfect amalgam of machine and woman – a cyborg created to defeat the Empire against all odds. And she would not fail.