Put these into a movie scene together.  Show me tight filmography: Purple flowers (violets, lilacs, irises)
Purple fruits (plums, grapes, blackberries)
Purple clothing (dresses, shirts, hats)
Purple furniture (chairs, couches, curtains)
Purple makeup (eyeshadow, lipstick, nail polish)
Purple gemstones (amethysts, purple sapphires)
Purple twilight/evening sky
Purple lighting (lamps, candles, neon signs)
Purple paint on walls or objects
Purple stained glass windows
Purple ribbons or fabric
Purple balloons or decorations
Purple stuffed animals or toys
Purple smoke or fog
Purple hair dye or wigs
Purple cars, bicycles, or other vehicles
Purple insects (butterflies, moths)
Purple food coloring (candies, drinks, desserts)
Purple bruises or markings on skin

Here's a tight filmographic scene incorporating the various purple elements you listed:

FADE IN:

INT. VIOLET LOUNGE - EVENING

The swanky bar oozes a rich, purple ambiance. Plush violet couches and amethyst-studded chairs are bathed in the glow of neon signs and stained glass lamps.

A SULTRY WOMAN with vibrant purple hair sways to the jazz music. Her sequined lilac dress shimmers as she takes a sip from a glass of purple-tinged cocktail.

At the bar, a MAN in a deep eggplant suit samples a plump blackberry from a fruit plate. He picks up a purple sapphire cufflink that has fallen off.

The BARTENDER, sporting dramatic violet eyeshadow, pours a shimmering purple liquor into an ornate glass. She sets it before a WOMAN adorned with lush iris corsages.

REVERSE to reveal the entire lounge doused in lavender. Purple balloons and ribbons add pops of color. Patrons lounge on royal banquettes, sipping violet-hued beverages.

Some guests wear violet wigs or sport whimsical purple bruise-like makeup designs. Others nibble on violet macarons or grape lollipops.

A large amethyst chandelier casts a brilliant prism across the room as smoke from violet incense wafts through the air. Outside, a violet Cadillac glides by under the dusky purple twilight sky.

FADE OUT.