# Query: Empire Strikes Back Scenes with Millenium Falcon as Image Prompts with Emojis

## AI Response


This is a fun way to practice reading and writing emojis.

1. Show the students the image prompt of the Millenium Falcon.
2. Ask the students to write a sentence or two about the image prompt using emojis.
3. Show the students the image prompt of the Millenium Falcon in the snow.
4. Ask the students to write a sentence or two about the image prompt using emojis.
5. Show the students the image prompt of the Millenium Falcon flying through space.
6. Ask the students to write a sentence or two about the image prompt using emojis.
7. Show the students the image prompt of the Millenium Falcon in the asteroid field.
8. Ask the students to write a sentence or two about the image prompt using emojis.
9. Show the students the image prompt of the Millenium Falcon on the landing platform.
10. Ask the students to write a sentence or two about the image prompt using emojis.
11. Show the students the image prompt of the Millenium Falcon in the docking bay.
12. Ask the students to write a sentence or two about the image prompt using emojis.
13. Show the students the image prompt of the Millenium Falcon in the hangar.
14. Ask the students to write a sentence or two about the image prompt using emojis.
15. Show the students the image prompt of the Millenium Falcon in the clouds.
16. Ask the students to write a sentence or two about the image prompt using emojis.
17. Show the students the image prompt of the Millenium Falcon in the sunset.
18. Ask the students to write a sentence or two about the image prompt using emojis.
19. Show the students the image prompt of the Millenium Falcon in the storm.
20. Ask the students to write a sentence or two about the image prompt using emojis.
21. Show the students the image prompt of the Millenium Falcon in the galaxy.
22. Ask the students to write a sentence or two about the image prompt using emojis.
23. Show the students the image prompt of the Millenium Falcon in the nebula.
24.



The Millennium Falcon is one of the most iconic spaceships in the Star Wars universe. In this activity, students will use emojis to describe and retell scenes from The Empire Strikes Back that feature the Millennium Falcon.

Materials:
- Access to images of Millennium Falcon scenes from The Empire Strikes Back
- Emoji keyboard or chart

Instructions:
1. Show students images of Millennium Falcon scenes from The Empire Strikes Back.
2. Have students work in pairs or small groups to describe each scene using only emojis.
3. Encourage students to use a variety of emojis to convey different emotions, actions, and settings.
4. Once students have finished describing each scene, have them share their emoji sequences with the class and explain what each sequence represents.
5. As a class, discuss how effectively each group was able to convey the meaning of the scene using only emojis.
6. Extension: Have students create their own Millennium Falcon scenes using emojis and share them with the class.

Assessment:
Observe students as they work in pairs or small groups to describe each scene using only emojis. Evaluate their use of a variety of emojis to convey different emotions, actions, and settings. Evaluate their ability to effectively convey the meaning of the scene using only emojis during the class discussion.

Modification:
For students who may struggle with using emojis to describe scenes, provide them with a list of common emojis and their meanings. Encourage them to use these emojis to describe the scenes.

Extension:
Have students create their own Millennium Falcon scenes using emojis and share them with the class. Encourage them to use a variety of emojis to convey different emotions, actions, and settings. Have the class vote on the best scene and discuss why they think it is the best.

Differentiation:
Provide students with images of different Millennium Falcon scenes from The Empire Strikes Back to describe. Encourage students to use a variety of emojis to convey different emotions, actions, and settings. Provide students with a list of common emojis and their meanings for those who may struggle with using emojis to describe scenes. Encourage
