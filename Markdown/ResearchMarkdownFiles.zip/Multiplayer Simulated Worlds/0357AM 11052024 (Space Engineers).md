# Query: Space Engineers

## AI Response
 is a sandbox game about engineering, construction, exploration and survival in space and on planets. Players build space ships, space stations, planetary outposts of various sizes and uses (civil and military), pilot ships and travel through space to explore planets and gather resources to survive. Featuring both creative and survival modes, there is no limit to what can be built, utilized and explored.

Space Engineers concentrates on construction and exploration aspects, but can be played as a survival shooter as well. We expect players will avoid engaging in direct man-to-man combat and instead use their creativity and engineering skills to build war machines and fortifications to survive in space and on planets. Space Engineers is inspired by reality and by how things work. Thrusters, assemblers, reactors, drills and other blocks require power and fuel, just like in reality.

Space Engineers is developed as a one-man project by Marek Rosa. Marek is responsible for programming, game design, graphics, website, trailer, social media, networking, press, business and marketing.

## Key Features

- Planets and moons - Inspired by real celestial bodies, you can explore the solar system, starting with our home planet, Earth.
- Game modes - Creative and survival modes are available. Survival mode includes two sub-modes: realistic and simplified.
- Creative mode - An unlimited number of voxels can be added/removed to your heart's content. A perfect testing ground for your latest designs.
- Survival mode - You must build your structures carefully, because you need to mind not only the material cost but also the energy income. In this mode, voxels can be removed only by explosives.
- Single-player - All game modes can be played offline.
- Multiplayer - You can build with your friends and enemies both online and offline. Multiplayer is peer-to-peer, with optional PvP and mod support.
- Customizable block - You will be able to modify your blocks' basic functions by writing scripts in the LUA language.
- Scripting - Use the LUA scripting language to create mods from basic blocks to complex factories.
- Modding - You will be able to create your own blocks, ships, stations and even weapons. Space Engineers uses the FCS (Fractured Crystal Studio)

 is a sandbox game about engineering, construction, exploration and survival in space and on planets. Players build space structures, vehicles and machines from various parts, launch into space, and explore planets while gathering resources to survive. Space Engineers is currently under development by Keen Software House.

Space Engineers is a sandbox game about engineering, construction, exploration and survival in space and on planets. Players build space structures, vehicles and machines from various parts, launch into space, and explore planets while gathering resources to survive. Space Engineers is currently under development by Keen Software House.

Space Engineers is a sandbox game about engineering, construction, exploration and survival in space and on planets. Players build space structures, vehicles and machines from various parts, launch into space, and explore planets while gathering resources to survive. Space Engineers is currently under development by Keen Software House.

Space Engineers is a sandbox game about engineering, construction, exploration and survival in space and on planets. Players build space structures, vehicles and machines from various parts, launch into space, and explore planets while gathering resources to survive. Space Engineers is currently under development by Keen Software House.

Space Engineers is a sandbox game about engineering, construction, exploration and survival in space and on planets. Players build space structures, vehicles and machines from various parts, launch into space, and explore planets while gathering resources to survive. Space Engineers is currently under development by Keen Software House.

Space Engineers is a sandbox game about engineering, construction, exploration and survival in space and on planets. Players build space structures, vehicles and machines from various parts, launch into space, and explore planets while gathering resources to survive. Space Engineers is currently under development by Keen Software House.

Space Engineers is a sandbox game about engineering, construction, exploration and survival in space and on planets. Players build space structures, vehicles and machines from various parts, launch into space, and explore planets while gathering resources to survive. Space Engineers is currently under development by Keen Software House.

Space Engineers is a sandbox game about engineering, construction, exploration and survival in space and on planets. Players build space structures, vehicles and machines from various parts, launch into space, and explore planets while gathering resources to survive. Space Engineers is currently under development by Keen Software House.

Space Engineers is a sandbox game about engineering, construction, exploration and survival in space and
