# Query: Terraria (tShock & Vanilla) PC

## AI Response
 Server Hosting

Terraria is a 2D sandbox game with gameplay that revolves around exploration, building, crafting, combat, and survival. The game has a procedurally generated 2D world with elements similar to Minecraft and Metroid.

Terraria is a 2D sandbox game with gameplay that revolves around exploration, building, crafting, combat, and survival. The game has a procedurally generated 2D world with elements similar to Minecraft and Metroid.

Terraria is a 2D sandbox game with gameplay that revolves around exploration, building, crafting, combat, and survival. The game has a procedurally generated 2D world with elements similar to Minecraft and Metroid.

Terraria is a 2D sandbox game with gameplay that revolves around exploration, building, crafting, combat, and survival. The game has a procedurally generated 2D world with elements similar to Minecraft and Metroid.

Terraria is a 2D sandbox game with gameplay that revolves around exploration, building, crafting, combat, and survival. The game has a procedurally generated 2D world with elements similar to Minecraft and Metroid.

Terraria is a 2D sandbox game with gameplay that revolves around exploration, building, crafting, combat, and survival. The game has a procedurally generated 2D world with elements similar to Minecraft and Metroid.

Terraria is a 2D sandbox game with gameplay that revolves around exploration, building, crafting, combat, and survival. The game has a procedurally generated 2D world with elements similar to Minecraft and Metroid.

Terraria is a 2D sandbox game with gameplay that revolves around exploration, building, crafting, combat, and survival. The game has a procedurally generated 2D world with elements similar to Minecraft and Metroid.

Terraria is a 2D sandbox game with gameplay that revolves around exploration, building, crafting, combat, and survival. The game has a procedurally generated 2D world with elements similar to Minecraft and Metroid.

Terraria is a 2D sandbox game with gameplay that revolves around exploration, building

 Server

Hello, I'm looking for a few more players to join my Terraria server. It's a PC server running on TShock and Vanilla. I've got a few rules, but they're pretty simple:

1. No griefing
2. No hacking
3. No spamming
4. No racism or hate speech
5. No stealing from other players unless they've given you permission

The server is currently on the latest version of Terraria, and I've got a few mods installed to make the game a little more interesting. I've got a few players already, but I'd like to add a few more. If you're interested, please send me a message with your Steam ID and I'll add you to the whitelist.

The server is located in the US, and I've got it set up to allow players from all over the world to join. I've also got a Discord server set up for players to chat and coordinate events.

Let me know if you're interested, and I'll look forward to playing with you!

Server IP: 192.168.1.1:7777
Discord: https://discord.gg/J8Q3jKj

Note: I'm not looking for any donations or anything like that. This is just a fun server for people to play on.</s>
