# Query: Empyrion - Galactic Survival PC

## AI Response
 Game Free Download

Empyrion - Galactic Survival PC Game Free Download for Mac/Win. Empyrion - Galactic Survival Game Download Full version highly compressed via direct link available. Empyrion - Galactic Survival Free Download PC Game Cracked in Direct Link and Torrent. Empyrion - Galactic Survival It Is a Full And Complete Game. Just Download, Run Setup, And Install.

## Empyrion - Galactic Survival PC Game Download Overview

Empyrion – Galactic Survival is a 3D open world space sandbox survival adventure. Build mighty ships, menacing space stations and vast planetary settlements to explore, conquer or exploit a variety of different planets and the allegedly empty space! Fight human, alien and biological hazards and survive in a hostile galaxy full of hidden dangers and opportunities that will challenge your survival, crafting and building skills to the limit.

Empyrion uniquely combines elements from space simulations, construction games, survival games and ego-shooters. In Empyrion, you can explore the galaxy and many different planets with their unique environments and creatures, gather resources, build and customize a variety of ships, space stations and planetary settlements, and fight against various enemies using a wide range of weapons and tactics.

Empyrion is currently under development by Eleon Game Studios. We have been working full-time on this project since 01/2014 and we will continue to do so until the game is finished. Our goal is to release the full version of Empyrion – Galactic Survival in Q2 2020.

## Game Features

- Open World: Explore a seamless universe of different planets with unique environments and creatures.
- Solar System: The solar system is procedurally generated and features several planets and interesting POIs.
- Space and Planet Exploration: Explore space and planets with your jetpack, walker, rover or spaceship.
- Building and Construction: Build your own spaceships, space stations, planetary settlements or mining outposts using different building materials.
- Survival: Survive in a hostile galaxy full of biological hazards, radiation and oxygen-less environments.
- Space and Planet Battles: Fight against alien and human enemies in space and on various planets.

 Game Free Download

Empyrion - Galactic Survival PC Game Free Download Full Version RG Mechanics Repack PC Game In Direct Download Links. This Game Is Crack And Highly Compress Game.

## Overview

Empyrion – Galactic Survival is a 3D open world survival sandbox adventure game set in space and on planets and moons. Build your own space ships and design your own space stations, explore procedurally generated solar systems and planets, and survive in a hostile universe full of challenges and opportunities.

Empyrion – Galactic Survival is a 3D open world survival sandbox adventure game set in space and on planets and moons. Build your own space ships and design your own space stations, explore procedurally generated solar systems and planets, and survive in a hostile universe full of challenges and opportunities.

Key Features:

- Procedurally generated solar systems and planets
- Realistic space physics and atmospheric flight model
- Fully destructible environments and voxel based building system
- Dynamic day and night cycles, weather systems and event driven emergencies
- Advanced crafting and resource management
- Multiplayer mode with cooperative and competitive gameplay options
- Modding support with Steam Workshop integration

## MATURE CONTENT DESCRIPTION

The developers describe the content like this:

Empyrion – Galactic Survival contains some violence and gore, as well as some suggestive themes. Players can fight hostile creatures and other players, and can destroy structures and vehicles. There are also some suggestive themes, such as the depiction of humanoid characters in various stages of undress.

## SYSTEM REQUIREMENTS

MINIMUM:

- OS: Windows 7, 8, 10 (64-bit)
- Processor: Intel Core i5-2500K 3.3GHz or AMD FX-6300 3.5GHz
- Memory: 8 GB RAM
- Graphics: NVIDIA GeForce GTX 560 or AMD Radeon HD 7770 (2GB VRAM)
- DirectX: Version 11
- Storage: 15 GB available space
- Additional Notes: Requires a 64-bit
