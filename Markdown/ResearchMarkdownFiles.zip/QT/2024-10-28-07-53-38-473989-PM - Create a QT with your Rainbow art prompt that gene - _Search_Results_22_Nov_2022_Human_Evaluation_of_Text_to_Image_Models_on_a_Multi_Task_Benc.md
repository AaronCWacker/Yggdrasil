Create a QT with your Rainbow art prompt that generates both brilliant colors but also a top ten list of things inside the picture per color! and known for being representative.  That is 100 different objects, with ten for each color and the remainder beautiful creatures of each color of the rainbow. Then also talk through the AI required like ASR, Agential tech etc to pass ai singularity level agential knowledge as a newly creative chord sheet and music for a   A Techno Trance Industrial Song about the top ten most popular national parks, and ten most popular inventors in AI and papers they wrote.

# 🩺🔍 Search Results
### 22 Nov 2022 | [Human Evaluation of Text-to-Image Models on a Multi-Task Benchmark](https://arxiv.org/abs/2211.12112) | [⬇️](https://arxiv.org/pdf/2211.12112)
*Vitali Petsiuk, Alexander E. Siemenn, Saisamrit Surbehera, Zad Chin,  Keith Tyser, Gregory Hunter, Arvind Raghavan, Yann Hicke, Bryan A. Plummer,  Ori Kerret, Tonio Buonassisi, Kate Saenko, Armando Solar-Lezama, Iddo Drori* 

  We provide a new multi-task benchmark for evaluating text-to-image models. We
perform a human evaluation comparing the most common open-source (Stable
Diffusion) and commercial (DALL-E 2) models. Twenty computer science AI
graduate students evaluated the two models, on three tasks, at three difficulty
levels, across ten prompts each, providing 3,600 ratings. Text-to-image
generation has seen rapid progress to the point that many recent models have
demonstrated their ability to create realistic high-resolution images for
various prompts. However, current text-to-image methods and the broader body of
research in vision-language understanding still struggle with intricate text
prompts that contain many objects with multiple attributes and relationships.
We introduce a new text-to-image benchmark that contains a suite of thirty-two
tasks over multiple applications that capture a model's ability to handle
different features of a text prompt. For example, asking a model to generate a
varying number of the same object to measure its ability to count or providing
a text prompt with several objects that each have a different attribute to
identify its ability to match objects and attributes correctly. Rather than
subjectively evaluating text-to-image results on a set of prompts, our new
multi-task benchmark consists of challenge tasks at three difficulty levels
(easy, medium, and hard) and human ratings for each generated image.

---------------

### 13 Sep 2023 | [Pathway to Future Symbiotic Creativity](https://arxiv.org/abs/2209.02388) | [⬇️](https://arxiv.org/pdf/2209.02388)
*Yike Guo, Qifeng Liu, Jie Chen, Wei Xue, Jie Fu, Henrik Jensen,  Fernando Rosas, Jeffrey Shaw, Xing Wu, Jiji Zhang, Jianliang Xu* 

  This report presents a comprehensive view of our vision on the development
path of the human-machine symbiotic art creation. We propose a classification
of the creative system with a hierarchy of 5 classes, showing the pathway of
creativity evolving from a mimic-human artist (Turing Artists) to a Machine
artist in its own right. We begin with an overview of the limitations of the
Turing Artists then focus on the top two-level systems, Machine Artists,
emphasizing machine-human communication in art creation. In art creation, it is
necessary for machines to understand humans' mental states, including desires,
appreciation, and emotions, humans also need to understand machines' creative
capabilities and limitations. The rapid development of immersive environment
and further evolution into the new concept of metaverse enable symbiotic art
creation through unprecedented flexibility of bi-directional communication
between artists and art manifestation environments. By examining the latest
sensor and XR technologies, we illustrate the novel way for art data collection
to constitute the base of a new form of human-machine bidirectional
communication and understanding in art creation. Based on such communication
and understanding mechanisms, we propose a novel framework for building future
Machine artists, which comes with the philosophy that a human-compatible AI
system should be based on the "human-in-the-loop" principle rather than the
traditional "end-to-end" dogma. By proposing a new form of inverse
reinforcement learning model, we outline the platform design of machine
artists, demonstrate its functions and showcase some examples of technologies
we have developed. We also provide a systematic exposition of the ecosystem for
AI-based symbiotic art form and community with an economic model built on NFT
technology. Ethical issues for the development of machine artists are also
discussed.

---------------

### 22 Apr 2023 | [Medium. Permeation: SARS-COV-2 Painting Creation by Generative Model](https://arxiv.org/abs/2304.11354) | [⬇️](https://arxiv.org/pdf/2304.11354)
*Yuan-Fu Yang, Iuan-Kai Fang, Min Sun, Su-Chu Hsu* 

  Airborne particles are the medium for SARS-CoV-2 to invade the human body.
Light also reflects through suspended particles in the air, allowing people to
see a colorful world. Impressionism is the most prominent art school that
explores the spectrum of color created through color reflection of light. We
find similarities of color structure and color stacking in the Impressionist
paintings and the illustrations of the novel coronavirus by artists around the
world. With computerized data analysis through the main tones, the way of color
layout, and the way of color stacking in the paintings of the Impressionists,
we train computers to draw the novel coronavirus in an Impressionist style
using a Generative Adversarial Network to create our artwork "Medium.
Permeation". This artwork is composed of 196 randomly generated viral pictures
arranged in a 14 by 14 matrix to form a large-scale painting. In addition, we
have developed an extended work: Gradual Change, which is presented as video
art. We use Graph Neural Network to present 196 paintings of the new
coronavirus to the audience one by one in a gradual manner. In front of LED TV
screen, audience will find 196 virus paintings whose colors will change
continuously. This large video painting symbolizes that worldwide 196 countries
have been invaded by the epidemic, and every nation continuously pops up mutant
viruses. The speed of vaccine development cannot keep up with the speed of
virus mutation. This is also the first generative art in the world based on the
common features and a metaphorical symbiosis between Impressionist art and the
novel coronavirus. This work warns us of the unprecedented challenges posed by
the SARS-CoV-2, implying that the world should not ignore the invisible enemy
who uses air as a medium.

---------------

### 10 Aug 2023 | [Classification of Human- and AI-Generated Texts: Investigating Features  for ChatGPT](https://arxiv.org/abs/2308.05341) | [⬇️](https://arxiv.org/pdf/2308.05341)
*Lorenz Mindner, Tim Schlippe, Kristina Schaaff* 

  Recently, generative AIs like ChatGPT have become available to the wide
public. These tools can for instance be used by students to generate essays or
whole theses. But how does a teacher know whether a text is written by a
student or an AI? In our work, we explore traditional and new features to (1)
detect text generated by AI from scratch and (2) text rephrased by AI. Since we
found that classification is more difficult when the AI has been instructed to
create the text in a way that a human would not recognize that it was generated
by an AI, we also investigate this more advanced case. For our experiments, we
produced a new text corpus covering 10 school topics. Our best systems to
classify basic and advanced human-generated/AI-generated texts have F1-scores
of over 96%. Our best systems for classifying basic and advanced
human-generated/AI-rephrased texts have F1-scores of more than 78%. The systems
use a combination of perplexity, semantic, list lookup, error-based,
readability, AI feedback, and text vector features. Our results show that the
new features substantially help to improve the performance of many classifiers.
Our best basic text rephrasing detection system even outperforms GPTZero by
183.8% relative in F1-score.

---------------

### 18 Aug 2021 | [Hypersim: A Photorealistic Synthetic Dataset for Holistic Indoor Scene  Understanding](https://arxiv.org/abs/2011.02523) | [⬇️](https://arxiv.org/pdf/2011.02523)
*Mike Roberts, Jason Ramapuram, Anurag Ranjan, Atulit Kumar, Miguel  Angel Bautista, Nathan Paczan, Russ Webb, Joshua M. Susskind* 

  For many fundamental scene understanding tasks, it is difficult or impossible
to obtain per-pixel ground truth labels from real images. We address this
challenge by introducing Hypersim, a photorealistic synthetic dataset for
holistic indoor scene understanding. To create our dataset, we leverage a large
repository of synthetic scenes created by professional artists, and we generate
77,400 images of 461 indoor scenes with detailed per-pixel labels and
corresponding ground truth geometry. Our dataset: (1) relies exclusively on
publicly available 3D assets; (2) includes complete scene geometry, material
information, and lighting information for every scene; (3) includes dense
per-pixel semantic instance segmentations and complete camera information for
every image; and (4) factors every image into diffuse reflectance, diffuse
illumination, and a non-diffuse residual term that captures view-dependent
lighting effects.
  We analyze our dataset at the level of scenes, objects, and pixels, and we
analyze costs in terms of money, computation time, and annotation effort.
Remarkably, we find that it is possible to generate our entire dataset from
scratch, for roughly half the cost of training a popular open-source natural
language processing model. We also evaluate sim-to-real transfer performance on
two real-world scene understanding tasks - semantic segmentation and 3D shape
prediction - where we find that pre-training on our dataset significantly
improves performance on both tasks, and achieves state-of-the-art performance
on the most challenging Pix3D test set. All of our rendered image data, as well
as all the code we used to generate our dataset and perform our experiments, is
available online.

---------------

### 20 Mar 2023 | [The Multimodal And Modular Ai Chef: Complex Recipe Generation From  Imagery](https://arxiv.org/abs/2304.02016) | [⬇️](https://arxiv.org/pdf/2304.02016)
*David Noever and Samantha Elizabeth Miller Noever* 

  The AI community has embraced multi-sensory or multi-modal approaches to
advance this generation of AI models to resemble expected intelligent
understanding. Combining language and imagery represents a familiar method for
specific tasks like image captioning or generation from descriptions. This
paper compares these monolithic approaches to a lightweight and specialized
method based on employing image models to label objects, then serially
submitting this resulting object list to a large language model (LLM). This use
of multiple Application Programming Interfaces (APIs) enables better than 95%
mean average precision for correct object lists, which serve as input to the
latest Open AI text generator (GPT-4). To demonstrate the API as a modular
alternative, we solve the problem of a user taking a picture of ingredients
available in a refrigerator, then generating novel recipe cards tailored to
complex constraints on cost, preparation time, dietary restrictions, portion
sizes, and multiple meal plans. The research concludes that monolithic
multimodal models currently lack the coherent memory to maintain context and
format for this task and that until recently, the language models like GPT-2/3
struggled to format similar problems without degenerating into repetitive or
non-sensical combinations of ingredients. For the first time, an AI chef or
cook seems not only possible but offers some enhanced capabilities to augment
human recipe libraries in pragmatic ways. The work generates a 100-page recipe
book featuring the thirty top ingredients using over 2000 refrigerator images
as initializing lists.

---------------

### 24 Jan 2024 | [No Longer Trending on Artstation: Prompt Analysis of Generative AI Art](https://arxiv.org/abs/2401.14425) | [⬇️](https://arxiv.org/pdf/2401.14425)
*Jon McCormack, Maria Teresa Llano, Stephen James Krol, Nina Rajcic* 

  Image generation using generative AI is rapidly becoming a major new source
of visual media, with billions of AI generated images created using diffusion
models such as Stable Diffusion and Midjourney over the last few years. In this
paper we collect and analyse over 3 million prompts and the images they
generate. Using natural language processing, topic analysis and visualisation
methods we aim to understand collectively how people are using text prompts,
the impact of these systems on artists, and more broadly on the visual cultures
they promote. Our study shows that prompting focuses largely on surface
aesthetics, reinforcing cultural norms, popular conventional representations
and imagery. We also find that many users focus on popular topics (such as
making colouring books, fantasy art, or Christmas cards), suggesting that the
dominant use for the systems analysed is recreational rather than artistic.

---------------

### 04 Dec 2023 | [Skill Reinforcement Learning and Planning for Open-World Long-Horizon  Tasks](https://arxiv.org/abs/2303.16563) | [⬇️](https://arxiv.org/pdf/2303.16563)
*Haoqi Yuan, Chi Zhang, Hongcheng Wang, Feiyang Xie, Penglin Cai, Hao  Dong, Zongqing Lu* 

  We study building multi-task agents in open-world environments. Without human
demonstrations, learning to accomplish long-horizon tasks in a large open-world
environment with reinforcement learning (RL) is extremely inefficient. To
tackle this challenge, we convert the multi-task learning problem into learning
basic skills and planning over the skills. Using the popular open-world game
Minecraft as the testbed, we propose three types of fine-grained basic skills,
and use RL with intrinsic rewards to acquire skills. A novel Finding-skill that
performs exploration to find diverse items provides better initialization for
other skills, improving the sample efficiency for skill learning. In skill
planning, we leverage the prior knowledge in Large Language Models to find the
relationships between skills and build a skill graph. When the agent is solving
a task, our skill search algorithm walks on the skill graph and generates the
proper skill plans for the agent. In experiments, our method accomplishes 40
diverse Minecraft tasks, where many tasks require sequentially executing for
more than 10 skills. Our method outperforms baselines by a large margin and is
the most sample-efficient demonstration-free RL method to solve Minecraft Tech
Tree tasks. The project's website and code can be found at
https://sites.google.com/view/plan4mc.

---------------

### 23 Nov 2023 | [PortfolioMentor: Multimodal Generative AI Companion for Learning and  Crafting Interactive Digital Art Portfolios](https://arxiv.org/abs/2311.14091) | [⬇️](https://arxiv.org/pdf/2311.14091)
*Tao Long, Weirui Peng* 

  Digital art portfolios serve as impactful mediums for artists to convey their
visions, weaving together visuals, audio, interactions, and narratives.
However, without technical backgrounds, design students often find it
challenging to translate creative ideas into tangible codes and designs, given
the lack of tailored resources for the non-technical, academic support in art
schools, and a comprehensive guiding tool throughout the mentally demanding
process. Recognizing the role of companionship in code learning and leveraging
generative AI models' capabilities in supporting creative tasks, we present
PortfolioMentor, a coding companion chatbot for IDEs. This tool guides and
collaborates with students through proactive suggestions and responsible Q&As
for learning, inspiration, and support. In detail, the system starts with the
understanding of the task and artist's visions, follows the co-creation of
visual illustrations, audio or music suggestions and files, click-scroll
effects for interactions, and creative vision conceptualization, and finally
synthesizes these facets into a polished interactive digital portfolio.

---------------

### 19 Nov 2021 | [ClevrTex: A Texture-Rich Benchmark for Unsupervised Multi-Object  Segmentation](https://arxiv.org/abs/2111.10265) | [⬇️](https://arxiv.org/pdf/2111.10265)
*Laurynas Karazija, Iro Laina, Christian Rupprecht* 

  There has been a recent surge in methods that aim to decompose and segment
scenes into multiple objects in an unsupervised manner, i.e., unsupervised
multi-object segmentation. Performing such a task is a long-standing goal of
computer vision, offering to unlock object-level reasoning without requiring
dense annotations to train segmentation models. Despite significant progress,
current models are developed and trained on visually simple scenes depicting
mono-colored objects on plain backgrounds. The natural world, however, is
visually complex with confounding aspects such as diverse textures and
complicated lighting effects. In this study, we present a new benchmark called
ClevrTex, designed as the next challenge to compare, evaluate and analyze
algorithms. ClevrTex features synthetic scenes with diverse shapes, textures
and photo-mapped materials, created using physically based rendering
techniques. It includes 50k examples depicting 3-10 objects arranged on a
background, created using a catalog of 60 materials, and a further test set
featuring 10k images created using 25 different materials. We benchmark a large
set of recent unsupervised multi-object segmentation models on ClevrTex and
find all state-of-the-art approaches fail to learn good representations in the
textured setting, despite impressive performance on simpler data. We also
create variants of the ClevrTex dataset, controlling for different aspects of
scene complexity, and probe current approaches for individual shortcomings.
Dataset and code are available at
https://www.robots.ox.ac.uk/~vgg/research/clevrtex.

---------------

### 14 Jul 2022 | [Audio-guided Album Cover Art Generation with Genetic Algorithms](https://arxiv.org/abs/2207.07162) | [⬇️](https://arxiv.org/pdf/2207.07162)
*James Marien, Sam Leroux, Bart Dhoedt, Cedric De Boom* 

  Over 60,000 songs are released on Spotify every day, and the competition for
the listener's attention is immense. In that regard, the importance of
captivating and inviting cover art cannot be underestimated, because it is
deeply entangled with a song's character and the artist's identity, and remains
one of the most important gateways to lead people to discover music. However,
designing cover art is a highly creative, lengthy and sometimes expensive
process that can be daunting, especially for non-professional artists. For this
reason, we propose a novel deep-learning framework to generate cover art guided
by audio features. Inspired by VQGAN-CLIP, our approach is highly flexible
because individual components can easily be replaced without the need for any
retraining. This paper outlines the architectural details of our models and
discusses the optimization challenges that emerge from them. More specifically,
we will exploit genetic algorithms to overcome bad local minima and adversarial
examples. We find that our framework can generate suitable cover art for most
genres, and that the visual features adapt themselves to audio feature changes.
Given these results, we believe that our framework paves the road for
extensions and more advanced applications in audio-guided visual generation
tasks.

---------------

### 23 Oct 2018 | [LoGAN: Generating Logos with a Generative Adversarial Neural Network  Conditioned on color](https://arxiv.org/abs/1810.10395) | [⬇️](https://arxiv.org/pdf/1810.10395)
*Ajkel Mino, Gerasimos Spanakis* 

  Designing a logo is a long, complicated, and expensive process for any
designer. However, recent advancements in generative algorithms provide models
that could offer a possible solution. Logos are multi-modal, have very few
categorical properties, and do not have a continuous latent space. Yet,
conditional generative adversarial networks can be used to generate logos that
could help designers in their creative process. We propose LoGAN: an improved
auxiliary classifier Wasserstein generative adversarial neural network (with
gradient penalty) that is able to generate logos conditioned on twelve
different colors. In 768 generated instances (12 classes and 64 logos per
class), when looking at the most prominent color, the conditional generation
part of the model has an overall precision and recall of 0.8 and 0.7
respectively. LoGAN's results offer a first glance at how artificial
intelligence can be used to assist designers in their creative process and open
promising future directions, such as including more descriptive labels which
will provide a more exhaustive and easy-to-use system.

---------------

### 04 Feb 2024 | [AI Art Neural Constellation: Revealing the Collective and Contrastive  State of AI-Generated and Human Art](https://arxiv.org/abs/2402.02453) | [⬇️](https://arxiv.org/pdf/2402.02453)
*Faizan Farooq Khan, Diana Kim, Divyansh Jha, Youssef Mohamed, Hanna H  Chang, Ahmed Elgammal, Luba Elliott, Mohamed Elhoseiny* 

  Discovering the creative potentials of a random signal to various artistic
expressions in aesthetic and conceptual richness is a ground for the recent
success of generative machine learning as a way of art creation. To understand
the new artistic medium better, we conduct a comprehensive analysis to position
AI-generated art within the context of human art heritage. Our comparative
analysis is based on an extensive dataset, dubbed ``ArtConstellation,''
consisting of annotations about art principles, likability, and emotions for
6,000 WikiArt and 3,200 AI-generated artworks. After training various
state-of-the-art generative models, art samples are produced and compared with
WikiArt data on the last hidden layer of a deep-CNN trained for style
classification. We actively examined the various art principles to interpret
the neural representations and used them to drive the comparative knowledge
about human and AI-generated art. A key finding in the semantic analysis is
that AI-generated artworks are visually related to the principle concepts for
modern period art made in 1800-2000. In addition, through Out-Of-Distribution
(OOD) and In-Distribution (ID) detection in CLIP space, we find that
AI-generated artworks are ID to human art when they depict landscapes and
geometric abstract figures, while detected as OOD when the machine art consists
of deformed and twisted figures. We observe that machine-generated art is
uniquely characterized by incomplete and reduced figuration. Lastly, we
conducted a human survey about emotional experience. Color composition and
familiar subjects are the key factors of likability and emotions in art
appreciation. We propose our whole methodologies and collected dataset as our
analytical framework to contrast human and AI-generated art, which we refer to
as ``ArtNeuralConstellation''. Code is available at:
https://github.com/faixan-khan/ArtNeuralConstellation

---------------

### 21 May 2023 | [PaCaNet: A Study on CycleGAN with Transfer Learning for Diversifying  Fused Chinese Painting and Calligraphy](https://arxiv.org/abs/2301.13082) | [⬇️](https://arxiv.org/pdf/2301.13082)
*Zuhao Yang, Huajun Bai, Zhang Luo, Yang Xu, Wei Pang, Yue Wang,  Yisheng Yuan, Yingfang Yuan* 

  AI-Generated Content (AIGC) has recently gained a surge in popularity,
powered by its high efficiency and consistency in production, and its
capability of being customized and diversified. The cross-modality nature of
the representation learning mechanism in most AIGC technology allows for more
freedom and flexibility in exploring new types of art that would be impossible
in the past. Inspired by the pictogram subset of Chinese characters, we
proposed PaCaNet, a CycleGAN-based pipeline for producing novel artworks that
fuse two different art types, traditional Chinese painting and calligraphy. In
an effort to produce stable and diversified output, we adopted three main
technical innovations: 1. Using one-shot learning to increase the creativity of
pre-trained models and diversify the content of the fused images. 2.
Controlling the preference over generated Chinese calligraphy by freezing
randomly sampled parameters in pre-trained models. 3. Using a regularization
method to encourage the models to produce images similar to Chinese paintings.
Furthermore, we conducted a systematic study to explore the performance of
PaCaNet in diversifying fused Chinese painting and calligraphy, which showed
satisfying results. In conclusion, we provide a new direction of creating arts
by fusing the visual information in paintings and the stroke features in
Chinese calligraphy. Our approach creates a unique aesthetic experience rooted
in the origination of Chinese hieroglyph characters. It is also a unique
opportunity to delve deeper into traditional artwork and, in doing so, to
create a meaningful impact on preserving and revitalizing traditional heritage.

---------------

### 17 Jan 2024 | [A New Creative Generation Pipeline for Click-Through Rate with Stable  Diffusion Model](https://arxiv.org/abs/2401.10934) | [⬇️](https://arxiv.org/pdf/2401.10934)
*Hao Yang, Jianxin Yuan, Shuai Yang, Linhe Xu, Shuo Yuan, Yifan Zeng* 

  In online advertising scenario, sellers often create multiple creatives to
provide comprehensive demonstrations, making it essential to present the most
appealing design to maximize the Click-Through Rate (CTR). However, sellers
generally struggle to consider users preferences for creative design, leading
to the relatively lower aesthetics and quantities compared to Artificial
Intelligence (AI)-based approaches. Traditional AI-based approaches still face
the same problem of not considering user information while having limited
aesthetic knowledge from designers. In fact that fusing the user information,
the generated creatives can be more attractive because different users may have
different preferences. To optimize the results, the generated creatives in
traditional methods are then ranked by another module named creative ranking
model. The ranking model can predict the CTR score for each creative
considering user features. However, the two above stages are regarded as two
different tasks and are optimized separately. In this paper, we proposed a new
automated Creative Generation pipeline for Click-Through Rate (CG4CTR) with the
goal of improving CTR during the creative generation stage. Our contributions
have 4 parts: 1) The inpainting mode in stable diffusion is firstly applied to
creative generation task in online advertising scene. A self-cyclic generation
pipeline is proposed to ensure the convergence of training. 2) Prompt model is
designed to generate individualized creatives for different user groups, which
can further improve the diversity and quality. 3) Reward model comprehensively
considers the multimodal features of image and text to improve the
effectiveness of creative ranking task, and it is also critical in self-cyclic
pipeline. 4) The significant benefits obtained in online and offline
experiments verify the significance of our proposed method.

---------------

### 31 Jan 2024 | [Image Anything: Towards Reasoning-coherent and Training-free Multi-modal  Image Generation](https://arxiv.org/abs/2401.17664) | [⬇️](https://arxiv.org/pdf/2401.17664)
*Yuanhuiyi Lyu, Xu Zheng, Lin Wang* 

  The multifaceted nature of human perception and comprehension indicates that,
when we think, our body can naturally take any combination of senses, a.k.a.,
modalities and form a beautiful picture in our brain. For example, when we see
a cattery and simultaneously perceive the cat's purring sound, our brain can
construct a picture of a cat in the cattery. Intuitively, generative AI models
should hold the versatility of humans and be capable of generating images from
any combination of modalities efficiently and collaboratively. This paper
presents ImgAny, a novel end-to-end multi-modal generative model that can mimic
human reasoning and generate high-quality images. Our method serves as the
first attempt in its capacity of efficiently and flexibly taking any
combination of seven modalities, ranging from language, audio to vision
modalities, including image, point cloud, thermal, depth, and event data. Our
key idea is inspired by human-level cognitive processes and involves the
integration and harmonization of multiple input modalities at both the entity
and attribute levels without specific tuning across modalities. Accordingly,
our method brings two novel training-free technical branches: 1) Entity Fusion
Branch ensures the coherence between inputs and outputs. It extracts entity
features from the multi-modal representations powered by our specially
constructed entity knowledge graph; 2) Attribute Fusion Branch adeptly
preserves and processes the attributes. It efficiently amalgamates distinct
attributes from diverse input modalities via our proposed attribute knowledge
graph. Lastly, the entity and attribute features are adaptively fused as the
conditional inputs to the pre-trained Stable Diffusion model for image
generation. Extensive experiments under diverse modality combinations
demonstrate its exceptional capability for visual content creation.

---------------

### 28 May 2022 | [Looks Like Magic: Transfer Learning in GANs to Generate New Card  Illustrations](https://arxiv.org/abs/2205.14442) | [⬇️](https://arxiv.org/pdf/2205.14442)
*Matheus K. Venturelli, Pedro H. Gomes, J\^onatas Wehrmann* 

  In this paper, we propose MAGICSTYLEGAN and MAGICSTYLEGAN-ADA - both
incarnations of the state-of-the-art models StyleGan2 and StyleGan2 ADA - to
experiment with their capacity of transfer learning into a rather different
domain: creating new illustrations for the vast universe of the game "Magic:
The Gathering" cards. This is a challenging task especially due to the variety
of elements present in these illustrations, such as humans, creatures,
artifacts, and landscapes - not to mention the plethora of art styles of the
images made by various artists throughout the years. To solve the task at hand,
we introduced a novel dataset, named MTG, with thousands of illustration from
diverse card types and rich in metadata. The resulting set is a dataset
composed by a myriad of both realistic and fantasy-like illustrations.
Although, to investigate effects of diversity we also introduced subsets that
contain specific types of concepts, such as forests, islands, faces, and
humans. We show that simpler models, such as DCGANs, are not able to learn to
generate proper illustrations in any setting. On the other side, we train
instances of MAGICSTYLEGAN using all proposed subsets, being able to generate
high quality illustrations. We perform experiments to understand how well
pre-trained features from StyleGan2 can be transferred towards the target
domain. We show that in well trained models we can find particular instances of
noise vector that realistically represent real images from the dataset.
Moreover, we provide both quantitative and qualitative studies to support our
claims, and that demonstrate that MAGICSTYLEGAN is the state-of-the-art
approach for generating Magic illustrations. Finally, this paper highlights
some emerging properties regarding transfer learning in GANs, which is still a
somehow under-explored field in generative learning research.

---------------

### 31 Dec 2023 | [Generation Of Colors using Bidirectional Long Short Term Memory Networks](https://arxiv.org/abs/2311.06542) | [⬇️](https://arxiv.org/pdf/2311.06542)
*A. Sinha* 

  Human vision can distinguish between a vast spectrum of colours, estimated to
be between 2 to 7 million discernible shades. However, this impressive range
does not inherently imply that all these colours have been precisely named and
described within our lexicon. We often associate colours with familiar objects
and concepts in our daily lives. This research endeavors to bridge the gap
between our visual perception of countless shades and our ability to articulate
and name them accurately. A novel model has been developed to achieve this
goal, leveraging Bidirectional Long Short-Term Memory (BiLSTM) networks with
Active learning. This model operates on a proprietary dataset meticulously
curated for this study. The primary objective of this research is to create a
versatile tool for categorizing and naming previously unnamed colours or
identifying intermediate shades that elude traditional colour terminology. The
findings underscore the potential of this innovative approach in
revolutionizing our understanding of colour perception and language. Through
rigorous experimentation and analysis, this study illuminates a promising
avenue for Natural Language Processing (NLP) applications in diverse
industries. By facilitating the exploration of the vast colour spectrum the
potential applications of NLP are extended beyond conventional boundaries.

---------------

### 15 Oct 2021 | [Few-Shot Bot: Prompt-Based Learning for Dialogue Systems](https://arxiv.org/abs/2110.08118) | [⬇️](https://arxiv.org/pdf/2110.08118)
*Andrea Madotto, Zhaojiang Lin, Genta Indra Winata, Pascale Fung* 

  Learning to converse using only a few examples is a great challenge in
conversational AI. The current best conversational models, which are either
good chit-chatters (e.g., BlenderBot) or goal-oriented systems (e.g., MinTL),
are language models (LMs) fine-tuned on large conversational datasets. Training
these models is expensive, both in terms of computational resources and time,
and it is hard to keep them up to date with new conversational skills. A simple
yet unexplored solution is prompt-based few-shot learning (Brown et al. 2020)
which does not require gradient-based fine-tuning but instead uses a few
examples in the LM context as the only source of learning. In this paper, we
explore prompt-based few-shot learning in dialogue tasks. We benchmark LMs of
different sizes in nine response generation tasks, which include four
knowledge-grounded tasks, a task-oriented generations task, three open-chat
tasks, and controlled stylistic generation, and five conversational parsing
tasks, which include dialogue state tracking, graph path generation, persona
information extraction, document retrieval, and internet query generation. The
current largest released LM (GPT-J-6B) using prompt-based few-shot learning,
and thus requiring no training, achieves competitive performance to fully
trained state-of-the-art models. Moreover, we propose a novel prompt-based
few-shot classifier, that also does not require any fine-tuning, to select the
most appropriate prompt given a dialogue history. Finally, by combining the
power of prompt-based few-shot learning and a Skill Selector, we create an
end-to-end chatbot named the Few-Shot Bot (FSB), which automatically selects
the most appropriate conversational skill, queries different knowledge bases or
the internet, and uses the retrieved knowledge to generate a human-like
response, all using only few dialogue examples per skill.

---------------

### 03 Mar 2024 | [CCC: Color Classified Colorization](https://arxiv.org/abs/2403.01476) | [⬇️](https://arxiv.org/pdf/2403.01476)
*Mrityunjoy Gain, Avi Deb Raha and Rameswar Debnath* 

  Automatic colorization of gray images with objects of different colors and
sizes is challenging due to inter- and intra-object color variation and the
small area of the main objects due to extensive backgrounds. The learning
process often favors dominant features, resulting in a biased model. In this
paper, we formulate the colorization problem into a multinomial classification
problem and then apply a weighted function to classes. We propose a set of
formulas to transform color values into color classes and vice versa. Class
optimization and balancing feature distribution are the keys for good
performance. Observing class appearance on various extremely large-scale
real-time images in practice, we propose 215 color classes for our colorization
task. During training, we propose a class-weighted function based on true class
appearance in each batch to ensure proper color saturation of individual
objects. We establish a trade-off between major and minor classes to provide
orthodox class prediction by eliminating major classes' dominance over minor
classes. As we apply regularization to enhance the stability of the minor
class, occasional minor noise may appear at the object's edges. We propose a
novel object-selective color harmonization method empowered by the SAM to
refine and enhance these edges. We propose a new color image evaluation metric,
the Chromatic Number Ratio (CNR), to quantify the richness of color components.
We compare our proposed model with state-of-the-art models using five different
datasets: ADE, Celeba, COCO, Oxford 102 Flower, and ImageNet, in both
qualitative and quantitative approaches. The experimental results show that our
proposed model outstrips other models in visualization and CNR measurement
criteria while maintaining satisfactory performance in regression (MSE, PSNR),
similarity (SSIM, LPIPS, UIQI), and generative criteria (FID).

---------------