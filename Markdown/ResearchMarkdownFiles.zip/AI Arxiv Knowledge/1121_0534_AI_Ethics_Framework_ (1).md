AI Ethics Framework ⛑️

### 🔎 AI Ethics Framework ⛑️



# AI Ethics Framework

## Introduction

Artificial Intelligence (AI) is a powerful technology that has the potential to transform our world. However, with this power comes responsibility. It is crucial that AI is developed and used in a way that is ethical, fair, transparent, and respects human rights.

The AI Ethics Framework is a set of principles and guidelines that aim to ensure that AI is developed and used in a responsible and ethical manner. It is intended to be a living document that evolves as the technology and its applications change over time.

The framework is based on the following core principles:

1. Respect for human rights and freedoms
2. Transparency and explainability
3. Fairness and non-discrimination
4. Privacy and data protection
5. Accountability and responsibility
6. Professionalism and ethical behavior
7. Social and environmental well-being

These principles are further elaborated in the following sections.

## Respect for Human Rights and Freedoms

AI systems should respect and uphold human rights and fundamental freedoms, as set out in international human rights law. This includes the right to privacy, freedom of expression, freedom of thought, conscience and religion, and the prohibition of discrimination.

AI systems should not be used to violate human rights or to discriminate against individuals or groups based on their race, color, sex, language, religion, political or other opinion, national or social origin, property, birth, or other status.

AI systems should be designed and used in a way that promotes human dignity, autonomy, and self-determination. They should not be used to manipulate, coerce, or deceive individuals or groups.

## Transparency and Explainability

AI systems should be transparent and explainable, so that individuals and groups can understand how they work, what data they use, and how they make decisions. This is important for building trust and ensuring that AI systems are accountable and responsible.

AI systems should provide clear and understandable explanations of their decisions, including the factors that were taken into account and the reasoning behind them. They should also provide users with the ability to challenge and appeal decisions that they consider to be unfair or incorrect.

AI systems should be designed and used in a way that promotes transparency and explainability, rather than obscurity and opacity. This includes making
# 🩺🔍 Search Results
### 09 May 2022 | [A Transparency Index Framework for AI in Education](https://arxiv.org/abs/2206.03220) | [⬇️](https://arxiv.org/pdf/2206.03220)
*Muhammad Ali Chaudhry, Mutlu Cukurova, Rose Luckin* 

  Numerous AI ethics checklists and frameworks have been proposed focusing on
different dimensions of ethical AI such as fairness, explainability, and
safety. Yet, no such work has been done on developing transparent AI systems
for real-world educational scenarios. This paper presents a Transparency Index
framework that has been iteratively co-designed with different stakeholders of
AI in education, including educators, ed-tech experts, and AI practitioners. We
map the requirements of transparency for different categories of stakeholders
of AI in education and demonstrate that transparency considerations are
embedded in the entire AI development process from the data collection stage
until the AI system is deployed in the real world and iteratively improved. We
also demonstrate how transparency enables the implementation of other ethical
AI dimensions in Education like interpretability, accountability, and safety.
In conclusion, we discuss the directions for future research in this newly
emerging field. The main contribution of this study is that it highlights the
importance of transparency in developing AI-powered educational technologies
and proposes an index framework for its conceptualization for AI in education.

---------------

### 07 Jun 2023 | [Responsible Design Patterns for Machine Learning Pipelines](https://arxiv.org/abs/2306.01788) | [⬇️](https://arxiv.org/pdf/2306.01788)
*Saud Hakem Al Harbi, Lionel Nganyewou Tidjon and Foutse Khomh* 

  Integrating ethical practices into the AI development process for artificial
intelligence (AI) is essential to ensure safe, fair, and responsible operation.
AI ethics involves applying ethical principles to the entire life cycle of AI
systems. This is essential to mitigate potential risks and harms associated
with AI, such as algorithm biases. To achieve this goal, responsible design
patterns (RDPs) are critical for Machine Learning (ML) pipelines to guarantee
ethical and fair outcomes. In this paper, we propose a comprehensive framework
incorporating RDPs into ML pipelines to mitigate risks and ensure the ethical
development of AI systems. Our framework comprises new responsible AI design
patterns for ML pipelines identified through a survey of AI ethics and data
management experts and validated through real-world scenarios with expert
feedback. The framework guides AI developers, data scientists, and
policy-makers to implement ethical practices in AI development and deploy
responsible AI systems in production.

---------------

### 09 Apr 2021 | [A Framework for Ethical AI at the United Nations](https://arxiv.org/abs/2104.12547) | [⬇️](https://arxiv.org/pdf/2104.12547)
*Lambert Hogenhout* 

  This paper aims to provide an overview of the ethical concerns in artificial
intelligence (AI) and the framework that is needed to mitigate those risks, and
to suggest a practical path to ensure the development and use of AI at the
United Nations (UN) aligns with our ethical values. The overview discusses how
AI is an increasingly powerful tool with potential for good, albeit one with a
high risk of negative side-effects that go against fundamental human rights and
UN values. It explains the need for ethical principles for AI aligned with
principles for data governance, as data and AI are tightly interwoven. It
explores different ethical frameworks that exist and tools such as assessment
lists. It recommends that the UN develop a framework consisting of ethical
principles, architectural standards, assessment methods, tools and
methodologies, and a policy to govern the implementation and adherence to this
framework, accompanied by an education program for staff.

---------------

### 31 Aug 2023 | [Ethical Framework for Harnessing the Power of AI in Healthcare and  Beyond](https://arxiv.org/abs/2309.00064) | [⬇️](https://arxiv.org/pdf/2309.00064)
*Sidra Nasir, Rizwan Ahmed Khan, Samita Bai* 

  In the past decade, the deployment of deep learning (Artificial Intelligence
(AI)) methods has become pervasive across a spectrum of real-world
applications, often in safety-critical contexts. This comprehensive research
article rigorously investigates the ethical dimensions intricately linked to
the rapid evolution of AI technologies, with a particular focus on the
healthcare domain. Delving deeply, it explores a multitude of facets including
transparency, adept data management, human oversight, educational imperatives,
and international collaboration within the realm of AI advancement. Central to
this article is the proposition of a conscientious AI framework, meticulously
crafted to accentuate values of transparency, equity, answerability, and a
human-centric orientation. The second contribution of the article is the
in-depth and thorough discussion of the limitations inherent to AI systems. It
astutely identifies potential biases and the intricate challenges of navigating
multifaceted contexts. Lastly, the article unequivocally accentuates the
pressing need for globally standardized AI ethics principles and frameworks.
Simultaneously, it aptly illustrates the adaptability of the ethical framework
proposed herein, positioned skillfully to surmount emergent challenges.

---------------

### 26 Jul 2022 | [Let it RAIN for Social Good](https://arxiv.org/abs/2208.04697) | [⬇️](https://arxiv.org/pdf/2208.04697)
*Mattias Br\"annstr\"om, Andreas Theodorou, Virginia Dignum* 

  Artificial Intelligence (AI) as a highly transformative technology take on a
special role as both an enabler and a threat to UN Sustainable Development
Goals (SDGs). AI Ethics and emerging high-level policy efforts stand at the
pivot point between these outcomes but is barred from effect due the
abstraction gap between high-level values and responsible action. In this paper
the Responsible Norms (RAIN) framework is presented, bridging this gap thereby
enabling effective high-level control of AI impact. With effective and
operationalized AI Ethics, AI technologies can be directed towards global
sustainable development.

---------------

### 07 Sep 2023 | [Beneficent Intelligence: A Capability Approach to Modeling Benefit,  Assistance, and Associated Moral Failures through AI Systems](https://arxiv.org/abs/2308.00868) | [⬇️](https://arxiv.org/pdf/2308.00868)
*Alex John London, Hoda Heidari* 

  The prevailing discourse around AI ethics lacks the language and formalism
necessary to capture the diverse ethical concerns that emerge when AI systems
interact with individuals. Drawing on Sen and Nussbaum's capability approach,
we present a framework formalizing a network of ethical concepts and
entitlements necessary for AI systems to confer meaningful benefit or
assistance to stakeholders. Such systems enhance stakeholders' ability to
advance their life plans and well-being while upholding their fundamental
rights. We characterize two necessary conditions for morally permissible
interactions between AI systems and those impacted by their functioning, and
two sufficient conditions for realizing the ideal of meaningful benefit. We
then contrast this ideal with several salient failure modes, namely, forms of
social interactions that constitute unjustified paternalism, coercion,
deception, exploitation and domination. The proliferation of incidents
involving AI in high-stakes domains underscores the gravity of these issues and
the imperative to take an ethics-led approach to AI systems from their
inception.

---------------

### 28 Sep 2022 | [Breaking Bad News in the Era of Artificial Intelligence and Algorithmic  Medicine: An Exploration of Disclosure and its Ethical Justification using  the Hedonic Calculus](https://arxiv.org/abs/2207.01431) | [⬇️](https://arxiv.org/pdf/2207.01431)
*Benjamin Post, Cosmin Badea, Aldo Faisal, Stephen J. Brett* 

  An appropriate ethical framework around the use of Artificial Intelligence
(AI) in healthcare has become a key desirable with the increasingly widespread
deployment of this technology. Advances in AI hold the promise of improving the
precision of outcome prediction at the level of the individual. However, the
addition of these technologies to patient-clinician interactions, as with any
complex human interaction, has potential pitfalls. While physicians have always
had to carefully consider the ethical background and implications of their
actions, detailed deliberations around fast-moving technological progress may
not have kept up. We use a common but key challenge in healthcare interactions,
the disclosure of bad news (likely imminent death), to illustrate how the
philosophical framework of the 'Felicific Calculus' developed in the 18th
century by Jeremy Bentham, may have a timely quasi-quantitative application in
the age of AI. We show how this ethical algorithm can be used to assess, across
seven mutually exclusive and exhaustive domains, whether an AI-supported action
can be morally justified.

---------------

### 07 Sep 2021 | [Readying Medical Students for Medical AI: The Need to Embed AI Ethics  Education](https://arxiv.org/abs/2109.02866) | [⬇️](https://arxiv.org/pdf/2109.02866)
*Thomas P Quinn, Simon Coghlan* 

  Medical students will almost inevitably encounter powerful medical AI systems
early in their careers. Yet, contemporary medical education does not adequately
equip students with the basic clinical proficiency in medical AI needed to use
these tools safely and effectively. Education reform is urgently needed, but
not easily implemented, largely due to an already jam-packed medical curricula.
In this article, we propose an education reform framework as an effective and
efficient solution, which we call the Embedded AI Ethics Education Framework.
Unlike other calls for education reform to accommodate AI teaching that are
more radical in scope, our framework is modest and incremental. It leverages
existing bioethics or medical ethics curricula to develop and deliver content
on the ethical issues associated with medical AI, especially the harms of
technology misuse, disuse, and abuse that affect the risk-benefit analyses at
the heart of healthcare. In doing so, the framework provides a simple tool for
going beyond the "What?" and the "Why?" of medical AI ethics education, to
answer the "How?", giving universities, course directors, and/or professors a
broad road-map for equipping their students with the necessary clinical
proficiency in medical AI.

---------------

### 13 Jul 2023 | [A multilevel framework for AI governance](https://arxiv.org/abs/2307.03198) | [⬇️](https://arxiv.org/pdf/2307.03198)
*Hyesun Choung, Prabu David, John S. Seberger* 

  To realize the potential benefits and mitigate potential risks of AI, it is
necessary to develop a framework of governance that conforms to ethics and
fundamental human values. Although several organizations have issued guidelines
and ethical frameworks for trustworthy AI, without a mediating governance
structure, these ethical principles will not translate into practice. In this
paper, we propose a multilevel governance approach that involves three groups
of interdependent stakeholders: governments, corporations, and citizens. We
examine their interrelationships through dimensions of trust, such as
competence, integrity, and benevolence. The levels of governance combined with
the dimensions of trust in AI provide practical insights that can be used to
further enhance user experiences and inform public policy related to AI.

---------------

### 29 Sep 2023 | [Compromise in Multilateral Negotiations and the Global Regulation of  Artificial Intelligence](https://arxiv.org/abs/2309.17158) | [⬇️](https://arxiv.org/pdf/2309.17158)
*Michal Natorski* 

  As artificial intelligence (AI) technologies spread worldwide, international
discussions have increasingly focused on their consequences for democracy,
human rights, fundamental freedoms, security, and economic and social
development. In this context, UNESCO's Recommendation on the Ethics of
Artificial Intelligence, adopted in November 2021, has emerged as the first
global normative framework for AI development and deployment. The intense
negotiations of every detail of the document brought forth numerous
controversies among UNESCO member states. Drawing on a unique set of primary
sources, including written positions and recorded deliberations, this paper
explains the achievement of global compromise on AI regulation despite the
multiplicity of UNESCO member-state positions representing a variety of liberal
and sovereignist preferences. Building upon Boltanski's pragmatic sociology, it
conceptualises the practice of multilateral negotiations and attributes the
multilateral compromise to two embedded therein mechanisms: Structural
normative hybridity and situated normative ambiguity allowed to accomplish a
compromise by linking macro-normative structures with situated debates of
multilateral negotiations.

---------------

### 28 Sep 2023 | [Responsible AI Pattern Catalogue: A Collection of Best Practices for AI  Governance and Engineering](https://arxiv.org/abs/2209.04963) | [⬇️](https://arxiv.org/pdf/2209.04963)
*Qinghua Lu, Liming Zhu, Xiwei Xu, Jon Whittle, Didar Zowghi, Aurelie  Jacquet* 

  Responsible AI is widely considered as one of the greatest scientific
challenges of our time and is key to increase the adoption of AI. Recently, a
number of AI ethics principles frameworks have been published. However, without
further guidance on best practices, practitioners are left with nothing much
beyond truisms. Also, significant efforts have been placed at algorithm-level
rather than system-level, mainly focusing on a subset of mathematics-amenable
ethical principles, such as fairness. Nevertheless, ethical issues can arise at
any step of the development lifecycle, cutting across many AI and non-AI
components of systems beyond AI algorithms and models. To operationalize
responsible AI from a system perspective, in this paper, we present a
Responsible AI Pattern Catalogue based on the results of a Multivocal
Literature Review (MLR). Rather than staying at the principle or algorithm
level, we focus on patterns that AI system stakeholders can undertake in
practice to ensure that the developed AI systems are responsible throughout the
entire governance and engineering lifecycle. The Responsible AI Pattern
Catalogue classifies the patterns into three groups: multi-level governance
patterns, trustworthy process patterns, and responsible-AI-by-design product
patterns. These patterns provide systematic and actionable guidance for
stakeholders to implement responsible AI.

---------------

### 31 Jan 2021 | [Making Responsible AI the Norm rather than the Exception](https://arxiv.org/abs/2101.11832) | [⬇️](https://arxiv.org/pdf/2101.11832)
*Abhishek Gupta (Montreal AI Ethics Institute and Microsoft)* 

  This report prepared by the Montreal AI Ethics Institute provides
recommendations in response to the National Security Commission on Artificial
Intelligence (NSCAI) Key Considerations for Responsible Development and
Fielding of Artificial Intelligence document. The report centres on the idea
that Responsible AI should be made the Norm rather than an Exception. It does
so by utilizing the guiding principles of: (1) alleviating friction in existing
workflows, (2) empowering stakeholders to get buy-in, and (3) conducting an
effective translation of abstract standards into actionable engineering
practices. After providing some overarching comments on the document from the
NSCAI, the report dives into the primary contribution of an actionable
framework to help operationalize the ideas presented in the document from the
NSCAI. The framework consists of: (1) a learning, knowledge, and information
exchange (LKIE), (2) the Three Ways of Responsible AI, (3) an
empirically-driven risk-prioritization matrix, and (4) achieving the right
level of complexity. All components reinforce each other to move from
principles to practice in service of making Responsible AI the norm rather than
the exception.

---------------

### 08 Sep 2022 | [Contextualizing Artificially Intelligent Morality: A Meta-Ethnography of  Top-Down, Bottom-Up, and Hybrid Models for Theoretical and Applied Ethics in  Artificial Intelligence](https://arxiv.org/abs/2204.07612) | [⬇️](https://arxiv.org/pdf/2204.07612)
*Jennafer S. Roberts and Laura N. Montoya* 

  In this meta-ethnography, we explore three different angles of ethical
artificial intelligence (AI) design implementation including the philosophical
ethical viewpoint, the technical perspective, and framing through a political
lens. Our qualitative research includes a literature review that highlights the
cross-referencing of these angles by discussing the value and drawbacks of
contrastive top-down, bottom-up, and hybrid approaches previously published.
The novel contribution to this framework is the political angle, which
constitutes ethics in AI either being determined by corporations and
governments and imposed through policies or law (coming from the top), or
ethics being called for by the people (coming from the bottom), as well as
top-down, bottom-up, and hybrid technicalities of how AI is developed within a
moral construct and in consideration of its users, with expected and unexpected
consequences and long-term impact in the world. There is a focus on
reinforcement learning as an example of a bottom-up applied technical approach
and AI ethics principles as a practical top-down approach. This investigation
includes real-world case studies to impart a global perspective, as well as
philosophical debate on the ethics of AI and theoretical future thought
experimentation based on historical facts, current world circumstances, and
possible ensuing realities.

---------------

### 05 Nov 2023 | [Does Explainable AI Have Moral Value?](https://arxiv.org/abs/2311.14687) | [⬇️](https://arxiv.org/pdf/2311.14687)
*Joshua L.M. Brand, Luca Nannini* 

  Explainable AI (XAI) aims to bridge the gap between complex algorithmic
systems and human stakeholders. Current discourse often examines XAI in
isolation as either a technological tool, user interface, or policy mechanism.
This paper proposes a unifying ethical framework grounded in moral duties and
the concept of reciprocity. We argue that XAI should be appreciated not merely
as a right, but as part of our moral duties that helps sustain a reciprocal
relationship between humans affected by AI systems. This is because, we argue,
explanations help sustain constitutive symmetry and agency in AI-led
decision-making processes. We then assess leading XAI communities and reveal
gaps between the ideal of reciprocity and practical feasibility. Machine
learning offers useful techniques but overlooks evaluation and adoption
challenges. Human-computer interaction provides preliminary insights but
oversimplifies organizational contexts. Policies espouse accountability but
lack technical nuance. Synthesizing these views exposes barriers to
implementable, ethical XAI. Still, positioning XAI as a moral duty transcends
rights-based discourse to capture a more robust and complete moral picture.
This paper provides an accessible, detailed analysis elucidating the moral
value of explainability.

---------------

### 17 Nov 2021 | [Sustainable Artificial Intelligence through Continual Learning](https://arxiv.org/abs/2111.09437) | [⬇️](https://arxiv.org/pdf/2111.09437)
*Andrea Cossu, Marta Ziosi, Vincenzo Lomonaco* 

  The increasing attention on Artificial Intelligence (AI) regulation has led
to the definition of a set of ethical principles grouped into the Sustainable
AI framework. In this article, we identify Continual Learning, an active area
of AI research, as a promising approach towards the design of systems compliant
with the Sustainable AI principles. While Sustainable AI outlines general
desiderata for ethical applications, Continual Learning provides means to put
such desiderata into practice.

---------------

### 26 Jun 2022 | [AI Governance for Businesses](https://arxiv.org/abs/2011.10672) | [⬇️](https://arxiv.org/pdf/2011.10672)
*Johannes Schneider and Rene Abraham and Christian Meske and Jan vom  Brocke* 

  Artificial Intelligence (AI) governance regulates the exercise of authority
and control over the management of AI. It aims at leveraging AI through
effective use of data and minimization of AI-related cost and risk. While
topics such as AI governance and AI ethics are thoroughly discussed on a
theoretical, philosophical, societal and regulatory level, there is limited
work on AI governance targeted to companies and corporations. This work views
AI products as systems, where key functionality is delivered by machine
learning (ML) models leveraging (training) data. We derive a conceptual
framework by synthesizing literature on AI and related fields such as ML. Our
framework decomposes AI governance into governance of data, (ML) models and
(AI) systems along four dimensions. It relates to existing IT and data
governance frameworks and practices. It can be adopted by practitioners and
academics alike. For practitioners the synthesis of mainly research papers, but
also practitioner publications and publications of regulatory bodies provides a
valuable starting point to implement AI governance, while for academics the
paper highlights a number of areas of AI governance that deserve more
attention.

---------------

### 08 Oct 2019 | [Designing Trustworthy AI: A Human-Machine Teaming Framework to Guide  Development](https://arxiv.org/abs/1910.03515) | [⬇️](https://arxiv.org/pdf/1910.03515)
*Carol J. Smith* 

  Artificial intelligence (AI) holds great promise to empower us with knowledge
and augment our effectiveness. We can -- and must -- ensure that we keep humans
safe and in control, particularly with regard to government and public sector
applications that affect broad populations. How can AI development teams
harness the power of AI systems and design them to be valuable to humans?
Diverse teams are needed to build trustworthy artificial intelligent systems,
and those teams need to coalesce around a shared set of ethics. There are many
discussions in the AI field about ethics and trust, but there are few
frameworks available for people to use as guidance when creating these systems.
The Human-Machine Teaming (HMT) Framework for Designing Ethical AI Experiences
described in this paper, when used with a set of technical ethics, will guide
AI development teams to create AI systems that are accountable, de-risked,
respectful, secure, honest, and usable. To support the team's efforts,
activities to understand people's needs and concerns will be introduced along
with the themes to support the team's efforts. For example, usability testing
can help determine if the audience understands how the AI system works and
complies with the HMT Framework. The HMT Framework is based on reviews of
existing ethical codes and best practices in human-computer interaction and
software development. Human-machine teams are strongest when human users can
trust AI systems to behave as expected, safely, securely, and understandably.
Using the HMT Framework to design trustworthy AI systems will provide support
to teams in identifying potential issues ahead of time and making great
experiences for humans.

---------------

### 02 Aug 2023 | [Dual Governance: The intersection of centralized regulation and  crowdsourced safety mechanisms for Generative AI](https://arxiv.org/abs/2308.04448) | [⬇️](https://arxiv.org/pdf/2308.04448)
*Avijit Ghosh, Dhanya Lakshmi* 

  Generative Artificial Intelligence (AI) has seen mainstream adoption lately,
especially in the form of consumer-facing, open-ended, text and image
generating models. However, the use of such systems raises significant ethical
and safety concerns, including privacy violations, misinformation and
intellectual property theft. The potential for generative AI to displace human
creativity and livelihoods has also been under intense scrutiny. To mitigate
these risks, there is an urgent need of policies and regulations responsible
and ethical development in the field of generative AI. Existing and proposed
centralized regulations by governments to rein in AI face criticisms such as
not having sufficient clarity or uniformity, lack of interoperability across
lines of jurisdictions, restricting innovation, and hindering free market
competition. Decentralized protections via crowdsourced safety tools and
mechanisms are a potential alternative. However, they have clear deficiencies
in terms of lack of adequacy of oversight and difficulty of enforcement of
ethical and safety standards, and are thus not enough by themselves as a
regulation mechanism. We propose a marriage of these two strategies via a
framework we call Dual Governance. This framework proposes a cooperative
synergy between centralized government regulations in a U.S. specific context
and safety mechanisms developed by the community to protect stakeholders from
the harms of generative AI. By implementing the Dual Governance framework, we
posit that innovation and creativity can be promoted while ensuring safe and
ethical deployment of generative AI.

---------------

### 15 Dec 2023 | [Investigating Responsible AI for Scientific Research: An Empirical Study](https://arxiv.org/abs/2312.09561) | [⬇️](https://arxiv.org/pdf/2312.09561)
*Muneera Bano, Didar Zowghi, Pip Shea, Georgina Ibarra* 

  Scientific research organizations that are developing and deploying
Artificial Intelligence (AI) systems are at the intersection of technological
progress and ethical considerations. The push for Responsible AI (RAI) in such
institutions underscores the increasing emphasis on integrating ethical
considerations within AI design and development, championing core values like
fairness, accountability, and transparency. For scientific research
organizations, prioritizing these practices is paramount not just for
mitigating biases and ensuring inclusivity, but also for fostering trust in AI
systems among both users and broader stakeholders. In this paper, we explore
the practices at a research organization concerning RAI practices, aiming to
assess the awareness and preparedness regarding the ethical risks inherent in
AI design and development. We have adopted a mixed-method research approach,
utilising a comprehensive survey combined with follow-up in-depth interviews
with selected participants from AI-related projects. Our results have revealed
certain knowledge gaps concerning ethical, responsible, and inclusive AI, with
limitations in awareness of the available AI ethics frameworks. This revealed
an overarching underestimation of the ethical risks that AI technologies can
present, especially when implemented without proper guidelines and governance.
Our findings reveal the need for a holistic and multi-tiered strategy to uplift
capabilities and better support science research teams for responsible,
ethical, and inclusive AI development and deployment.

---------------

### 25 Apr 2023 | [An Audit Framework for Adopting AI-Nudging on Children](https://arxiv.org/abs/2304.14338) | [⬇️](https://arxiv.org/pdf/2304.14338)
*Marianna Ganapini and Enrico Panai* 

  This is an audit framework for AI-nudging. Unlike the static form of nudging
usually discussed in the literature, we focus here on a type of nudging that
uses large amounts of data to provide personalized, dynamic feedback and
interfaces. We call this AI-nudging (Lanzing, 2019, p. 549; Yeung, 2017). The
ultimate goal of the audit outlined here is to ensure that an AI system that
uses nudges will maintain a level of moral inertia and neutrality by complying
with the recommendations, requirements, or suggestions of the audit (in other
words, the criteria of the audit). In the case of unintended negative
consequences, the audit suggests risk mitigation mechanisms that can be put in
place. In the case of unintended positive consequences, it suggests some
reinforcement mechanisms. Sponsored by the IBM-Notre Dame Tech Ethics Lab

---------------
**Date:** 09 May 2022

**Title:** A Transparency Index Framework for AI in Education

**Abstract Link:** [https://arxiv.org/abs/2206.03220](https://arxiv.org/abs/2206.03220)

**PDF Link:** [https://arxiv.org/pdf/2206.03220](https://arxiv.org/pdf/2206.03220)

---

**Date:** 07 Jun 2023

**Title:** Responsible Design Patterns for Machine Learning Pipelines

**Abstract Link:** [https://arxiv.org/abs/2306.01788](https://arxiv.org/abs/2306.01788)

**PDF Link:** [https://arxiv.org/pdf/2306.01788](https://arxiv.org/pdf/2306.01788)

---

**Date:** 09 Apr 2021

**Title:** A Framework for Ethical AI at the United Nations

**Abstract Link:** [https://arxiv.org/abs/2104.12547](https://arxiv.org/abs/2104.12547)

**PDF Link:** [https://arxiv.org/pdf/2104.12547](https://arxiv.org/pdf/2104.12547)

---

**Date:** 31 Aug 2023

**Title:** Ethical Framework for Harnessing the Power of AI in Healthcare and  Beyond

**Abstract Link:** [https://arxiv.org/abs/2309.00064](https://arxiv.org/abs/2309.00064)

**PDF Link:** [https://arxiv.org/pdf/2309.00064](https://arxiv.org/pdf/2309.00064)

---

**Date:** 26 Jul 2022

**Title:** Let it RAIN for Social Good

**Abstract Link:** [https://arxiv.org/abs/2208.04697](https://arxiv.org/abs/2208.04697)

**PDF Link:** [https://arxiv.org/pdf/2208.04697](https://arxiv.org/pdf/2208.04697)

---

**Date:** 07 Sep 2023

**Title:** Beneficent Intelligence: A Capability Approach to Modeling Benefit,  Assistance, and Associated Moral Failures through AI Systems

**Abstract Link:** [https://arxiv.org/abs/2308.00868](https://arxiv.org/abs/2308.00868)

**PDF Link:** [https://arxiv.org/pdf/2308.00868](https://arxiv.org/pdf/2308.00868)

---

**Date:** 28 Sep 2022

**Title:** Breaking Bad News in the Era of Artificial Intelligence and Algorithmic  Medicine: An Exploration of Disclosure and its Ethical Justification using  the Hedonic Calculus

**Abstract Link:** [https://arxiv.org/abs/2207.01431](https://arxiv.org/abs/2207.01431)

**PDF Link:** [https://arxiv.org/pdf/2207.01431](https://arxiv.org/pdf/2207.01431)

---

**Date:** 07 Sep 2021

**Title:** Readying Medical Students for Medical AI: The Need to Embed AI Ethics  Education

**Abstract Link:** [https://arxiv.org/abs/2109.02866](https://arxiv.org/abs/2109.02866)

**PDF Link:** [https://arxiv.org/pdf/2109.02866](https://arxiv.org/pdf/2109.02866)

---

**Date:** 13 Jul 2023

**Title:** A multilevel framework for AI governance

**Abstract Link:** [https://arxiv.org/abs/2307.03198](https://arxiv.org/abs/2307.03198)

**PDF Link:** [https://arxiv.org/pdf/2307.03198](https://arxiv.org/pdf/2307.03198)

---

**Date:** 29 Sep 2023

**Title:** Compromise in Multilateral Negotiations and the Global Regulation of  Artificial Intelligence

**Abstract Link:** [https://arxiv.org/abs/2309.17158](https://arxiv.org/abs/2309.17158)

**PDF Link:** [https://arxiv.org/pdf/2309.17158](https://arxiv.org/pdf/2309.17158)

---

**Date:** 28 Sep 2023

**Title:** Responsible AI Pattern Catalogue: A Collection of Best Practices for AI  Governance and Engineering

**Abstract Link:** [https://arxiv.org/abs/2209.04963](https://arxiv.org/abs/2209.04963)

**PDF Link:** [https://arxiv.org/pdf/2209.04963](https://arxiv.org/pdf/2209.04963)

---

**Date:** 31 Jan 2021

**Title:** Making Responsible AI the Norm rather than the Exception

**Abstract Link:** [https://arxiv.org/abs/2101.11832](https://arxiv.org/abs/2101.11832)

**PDF Link:** [https://arxiv.org/pdf/2101.11832](https://arxiv.org/pdf/2101.11832)

---

**Date:** 08 Sep 2022

**Title:** Contextualizing Artificially Intelligent Morality: A Meta-Ethnography of  Top-Down, Bottom-Up, and Hybrid Models for Theoretical and Applied Ethics in  Artificial Intelligence

**Abstract Link:** [https://arxiv.org/abs/2204.07612](https://arxiv.org/abs/2204.07612)

**PDF Link:** [https://arxiv.org/pdf/2204.07612](https://arxiv.org/pdf/2204.07612)

---

**Date:** 05 Nov 2023

**Title:** Does Explainable AI Have Moral Value?

**Abstract Link:** [https://arxiv.org/abs/2311.14687](https://arxiv.org/abs/2311.14687)

**PDF Link:** [https://arxiv.org/pdf/2311.14687](https://arxiv.org/pdf/2311.14687)

---

**Date:** 17 Nov 2021

**Title:** Sustainable Artificial Intelligence through Continual Learning

**Abstract Link:** [https://arxiv.org/abs/2111.09437](https://arxiv.org/abs/2111.09437)

**PDF Link:** [https://arxiv.org/pdf/2111.09437](https://arxiv.org/pdf/2111.09437)

---

**Date:** 26 Jun 2022

**Title:** AI Governance for Businesses

**Abstract Link:** [https://arxiv.org/abs/2011.10672](https://arxiv.org/abs/2011.10672)

**PDF Link:** [https://arxiv.org/pdf/2011.10672](https://arxiv.org/pdf/2011.10672)

---

**Date:** 08 Oct 2019

**Title:** Designing Trustworthy AI: A Human-Machine Teaming Framework to Guide  Development

**Abstract Link:** [https://arxiv.org/abs/1910.03515](https://arxiv.org/abs/1910.03515)

**PDF Link:** [https://arxiv.org/pdf/1910.03515](https://arxiv.org/pdf/1910.03515)

---

**Date:** 02 Aug 2023

**Title:** Dual Governance: The intersection of centralized regulation and  crowdsourced safety mechanisms for Generative AI

**Abstract Link:** [https://arxiv.org/abs/2308.04448](https://arxiv.org/abs/2308.04448)

**PDF Link:** [https://arxiv.org/pdf/2308.04448](https://arxiv.org/pdf/2308.04448)

---

**Date:** 15 Dec 2023

**Title:** Investigating Responsible AI for Scientific Research: An Empirical Study

**Abstract Link:** [https://arxiv.org/abs/2312.09561](https://arxiv.org/abs/2312.09561)

**PDF Link:** [https://arxiv.org/pdf/2312.09561](https://arxiv.org/pdf/2312.09561)

---

**Date:** 25 Apr 2023

**Title:** An Audit Framework for Adopting AI-Nudging on Children

**Abstract Link:** [https://arxiv.org/abs/2304.14338](https://arxiv.org/abs/2304.14338)

**PDF Link:** [https://arxiv.org/pdf/2304.14338](https://arxiv.org/pdf/2304.14338)

---

