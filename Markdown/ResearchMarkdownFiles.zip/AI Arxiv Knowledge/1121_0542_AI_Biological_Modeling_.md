AI Biological Modeling 🧯

### 🔎 AI Biological Modeling 🧯



# AIological Modeling

- Started 2021-03-01
- Last Updated 2021-03-01

AIological Modeling is a method for creating models of human behavior using AI. It is a combination of AI and psychology.

## Overview

AIological Modeling is a method for creating models of human behavior using AI. It is a combination of AI and psychology.

The goal of AIological Modeling is to create models that can predict human behavior with a high degree of accuracy. This is done by using AI to analyze data about human behavior and then using that data to create models that can predict future behavior.

AIological Modeling is a powerful tool that can be used in a variety of fields, including marketing, sales, human resources, and education. It can be used to predict how people will react to different stimuli, how they will make decisions, and how they will behave in different situations.

AIological Modeling is a relatively new field, but it is already being used by some of the world's leading companies to gain a competitive edge.

## Methodology

The methodology of AIological Modeling involves several steps:

1. Data Collection: The first step in AIological Modeling is to collect data about human behavior. This data can come from a variety of sources, including surveys, interviews, observations, and experiments.
2. Data Analysis: Once the data has been collected, it is analyzed using AI techniques such as machine learning, natural language processing, and computer vision.
3. Model Creation: Based on the analysis of the data, AIological Models are created. These models are designed to predict human behavior based on various factors such as age, gender, education, and personality traits.
4. Model Validation: The models are then validated by testing them against new data to see how accurately they can predict human behavior.
5. Model Deployment: Once the models have been validated, they can be deployed in real-world situations to predict human behavior.

## Applications

AIological Modeling has a wide range of applications, including:

1. Marketing: AIological Modeling can be used to predict how consumers will react to different marketing messages, products, and promotions.
2. Sales: AIological Modeling can be used to predict which sales strategies are most likely to be
# 🩺🔍 Search Results
### 16 May 2021 | [Curiosity-driven Intuitive Physics Learning](https://arxiv.org/abs/2105.07426) | [⬇️](https://arxiv.org/pdf/2105.07426)
*Tejas Gaikwad, Romi Banerjee* 

  Biological infants are naturally curious and try to comprehend their physical
surroundings by interacting, in myriad multisensory ways, with different
objects - primarily macroscopic solid objects - around them. Through their
various interactions, they build hypotheses and predictions, and eventually
learn, infer and understand the nature of the physical characteristics and
behavior of these objects. Inspired thus, we propose a model for
curiosity-driven learning and inference for real-world AI agents. This model is
based on the arousal of curiosity, deriving from observations along
discontinuities in the fundamental macroscopic solid-body physics parameters,
i.e., shape constancy, spatial-temporal continuity, and object permanence. We
use the term body-budget to represent the perceived fundamental properties of
solid objects. The model aims to support the emulation of learning from scratch
followed by substantiation through experience, irrespective of domain, in
real-world AI agents.

---------------

### 09 Jun 2023 | [EfficientBioAI: Making Bioimaging AI Models Efficient in Energy, Latency  and Representation](https://arxiv.org/abs/2306.06152) | [⬇️](https://arxiv.org/pdf/2306.06152)
*Yu Zhou, Justin Sonneck, Sweta Banerjee, Stefanie D\"orr, Anika  Gr\"uneboom, Kristina Lorenz, Jianxu Chen* 

  Artificial intelligence (AI) has been widely used in bioimage image analysis
nowadays, but the efficiency of AI models, like the energy consumption and
latency is not ignorable due to the growing model size and complexity, as well
as the fast-growing analysis needs in modern biomedical studies. Like we can
compress large images for efficient storage and sharing, we can also compress
the AI models for efficient applications and deployment. In this work, we
present EfficientBioAI, a plug-and-play toolbox that can compress given
bioimaging AI models for them to run with significantly reduced energy cost and
inference time on both CPU and GPU, without compromise on accuracy. In some
cases, the prediction accuracy could even increase after compression, since the
compression procedure could remove redundant information in the model
representation and therefore reduce over-fitting. From four different bioimage
analysis applications, we observed around 2-5 times speed-up during inference
and 30-80$\%$ saving in energy. Cutting the runtime of large scale bioimage
analysis from days to hours or getting a two-minutes bioimaging AI model
inference done in near real-time will open new doors for method development and
biomedical discoveries. We hope our toolbox will facilitate
resource-constrained bioimaging AI and accelerate large-scale AI-based
quantitative biological studies in an eco-friendly way, as well as stimulate
further research on the efficiency of bioimaging AI.

---------------

### 11 Dec 2023 | [XAI meets Biology: A Comprehensive Review of Explainable AI in  Bioinformatics Applications](https://arxiv.org/abs/2312.06082) | [⬇️](https://arxiv.org/pdf/2312.06082)
*Zhongliang Zhou, Mengxuan Hu, Mariah Salcedo, Nathan Gravel, Wayland  Yeung, Aarya Venkat, Dongliang Guo, Jielu Zhang, Natarajan Kannan, Sheng Li* 

  Artificial intelligence (AI), particularly machine learning and deep learning
models, has significantly impacted bioinformatics research by offering powerful
tools for analyzing complex biological data. However, the lack of
interpretability and transparency of these models presents challenges in
leveraging these models for deeper biological insights and for generating
testable hypotheses. Explainable AI (XAI) has emerged as a promising solution
to enhance the transparency and interpretability of AI models in
bioinformatics. This review provides a comprehensive analysis of various XAI
techniques and their applications across various bioinformatics domains
including DNA, RNA, and protein sequence analysis, structural analysis, gene
expression and genome analysis, and bioimaging analysis. We introduce the most
pertinent machine learning and XAI methods, then discuss their diverse
applications and address the current limitations of available XAI tools. By
offering insights into XAI's potential and challenges, this review aims to
facilitate its practical implementation in bioinformatics research and help
researchers navigate the landscape of XAI tools.

---------------

### 10 Aug 2023 | [AI-GOMS: Large AI-Driven Global Ocean Modeling System](https://arxiv.org/abs/2308.03152) | [⬇️](https://arxiv.org/pdf/2308.03152)
*Wei Xiong, Yanfei Xiang, Hao Wu, Shuyi Zhou, Yuze Sun, Muyuan Ma,  Xiaomeng Huang* 

  Ocean modeling is a powerful tool for simulating the physical, chemical, and
biological processes of the ocean, which is the foundation for marine science
research and operational oceanography. Modern numerical ocean modeling mainly
consists of governing equations and numerical algorithms. Nonlinear
instability, computational expense, low reusability efficiency and high
coupling costs have gradually become the main bottlenecks for the further
development of numerical ocean modeling. Recently, artificial
intelligence-based modeling in scientific computing has shown revolutionary
potential for digital twins and scientific simulations, but the bottlenecks of
numerical ocean modeling have not been further solved. Here, we present
AI-GOMS, a large AI-driven global ocean modeling system, for accurate and
efficient global ocean daily prediction. AI-GOMS consists of a backbone model
with the Fourier-based Masked Autoencoder structure for basic ocean variable
prediction and lightweight fine-tuning models incorporating regional
downscaling, wave decoding, and biochemistry coupling modules. AI-GOMS has
achieved the best performance in 30 days of prediction for the global ocean
basic variables with 15 depth layers at 1/4{\deg} spatial resolution. Beyond
the good performance in statistical metrics, AI-GOMS realizes the simulation of
mesoscale eddies in the Kuroshio region at 1/12{\deg} spatial resolution and
ocean stratification in the tropical Pacific Ocean. AI-GOMS provides a new
backbone-downstream paradigm for Earth system modeling, which makes the system
transferable, scalable and reusable.

---------------

### 13 Feb 2024 | [A Survey of Generative AI for De Novo Drug Design: New Frontiers in  Molecule and Protein Generation](https://arxiv.org/abs/2402.08703) | [⬇️](https://arxiv.org/pdf/2402.08703)
*Xiangru Tang, Howard Dai, Elizabeth Knight, Fang Wu, Yunyang Li,  Tianxiao Li, Mark Gerstein* 

  Artificial intelligence (AI)-driven methods can vastly improve the
historically costly drug design process, with various generative models already
in widespread use. Generative models for de novo drug design, in particular,
focus on the creation of novel biological compounds entirely from scratch,
representing a promising future direction. Rapid development in the field,
combined with the inherent complexity of the drug design process, creates a
difficult landscape for new researchers to enter. In this survey, we organize
de novo drug design into two overarching themes: small molecule and protein
generation. Within each theme, we identify a variety of subtasks and
applications, highlighting important datasets, benchmarks, and model
architectures and comparing the performance of top models. We take a broad
approach to AI-driven drug design, allowing for both micro-level comparisons of
various methods within each subtask and macro-level observations across
different fields. We discuss parallel challenges and approaches between the two
applications and highlight future directions for AI-driven de novo drug design
as a whole. An organized repository of all covered sources is available at
https://github.com/gersteinlab/GenAI4Drug.

---------------

### 15 Jun 2021 | [Optimality of short-term synaptic plasticity in modelling certain  dynamic environments](https://arxiv.org/abs/2009.06808) | [⬇️](https://arxiv.org/pdf/2009.06808)
*Timoleon Moraitis, Abu Sebastian, Evangelos Eleftheriou (IBM Research  - Zurich)* 

  Biological neurons and their in-silico emulations for neuromorphic artificial
intelligence (AI) use extraordinarily energy-efficient mechanisms, such as
spike-based communication and local synaptic plasticity. It remains unclear
whether these neuronal mechanisms only offer efficiency or also underlie the
superiority of biological intelligence. Here, we prove rigorously that, indeed,
the Bayes-optimal prediction and inference of randomly but continuously
transforming environments, a common natural setting, relies on short-term
spike-timing-dependent plasticity, a hallmark of biological synapses. Further,
this dynamic Bayesian inference through plasticity enables circuits of the
cerebral cortex in simulations to recognize previously unseen, highly distorted
dynamic stimuli. Strikingly, this also introduces a biologically-modelled AI,
the first to overcome multiple limitations of deep learning and outperform
artificial neural networks in a visual task. The cortical-like network is
spiking and event-based, trained only with unsupervised and local plasticity,
on a small, narrow, and static training dataset, but achieves recognition of
unseen, transformed, and dynamic data better than deep neural networks with
continuous activations, trained with supervised backpropagation on the
transforming data. These results link short-term plasticity to high-level
cortical function, suggest optimality of natural intelligence for natural
environments, and repurpose neuromorphic AI from mere efficiency to
computational supremacy altogether.

---------------

### 09 Mar 2010 | [Biological Inspiration for Artificial Immune Systems](https://arxiv.org/abs/1001.2208) | [⬇️](https://arxiv.org/pdf/1001.2208)
*Jamie Twycross, Uwe Aickelin* 

  Artificial immune systems (AISs) to date have generally been inspired by
naive biological metaphors. This has limited the effectiveness of these
systems. In this position paper two ways in which AISs could be made more
biologically realistic are discussed. We propose that AISs should draw their
inspiration from organisms which possess only innate immune systems, and that
AISs should employ systemic models of the immune system to structure their
overall design. An outline of plant and invertebrate immune systems is
presented, and a number of contemporary research that more
biologically-realistic AISs could have is also discussed.

---------------

### 11 Apr 2023 | [Habits and goals in synergy: a variational Bayesian framework for  behavior](https://arxiv.org/abs/2304.05008) | [⬇️](https://arxiv.org/pdf/2304.05008)
*Dongqi Han, Kenji Doya, Dongsheng Li, Jun Tani* 

  How to behave efficiently and flexibly is a central problem for understanding
biological agents and creating intelligent embodied AI. It has been well known
that behavior can be classified as two types: reward-maximizing habitual
behavior, which is fast while inflexible; and goal-directed behavior, which is
flexible while slow. Conventionally, habitual and goal-directed behaviors are
considered handled by two distinct systems in the brain. Here, we propose to
bridge the gap between the two behaviors, drawing on the principles of
variational Bayesian theory. We incorporate both behaviors in one framework by
introducing a Bayesian latent variable called "intention". The habitual
behavior is generated by using prior distribution of intention, which is
goal-less; and the goal-directed behavior is generated by the posterior
distribution of intention, which is conditioned on the goal. Building on this
idea, we present a novel Bayesian framework for modeling behaviors. Our
proposed framework enables skill sharing between the two kinds of behaviors,
and by leveraging the idea of predictive coding, it enables an agent to
seamlessly generalize from habitual to goal-directed behavior without requiring
additional training. The proposed framework suggests a fresh perspective for
cognitive science and embodied AI, highlighting the potential for greater
integration between habitual and goal-directed behaviors.

---------------

### 12 Dec 2023 | [Complex Recurrent Spectral Network](https://arxiv.org/abs/2312.07296) | [⬇️](https://arxiv.org/pdf/2312.07296)
*Lorenzo Chicchi, Lorenzo Giambagli, Lorenzo Buffoni, Raffaele Marino,  Duccio Fanelli* 

  This paper presents a novel approach to advancing artificial intelligence
(AI) through the development of the Complex Recurrent Spectral Network
($\mathbb{C}$-RSN), an innovative variant of the Recurrent Spectral Network
(RSN) model. The $\mathbb{C}$-RSN is designed to address a critical limitation
in existing neural network models: their inability to emulate the complex
processes of biological neural networks dynamically and accurately. By
integrating key concepts from dynamical systems theory and leveraging
principles from statistical mechanics, the $\mathbb{C}$-RSN model introduces
localized non-linearity, complex fixed eigenvalues, and a distinct separation
of memory and input processing functionalities. These features collectively
enable the $\mathbb{C}$-RSN evolving towards a dynamic, oscillating final state
that more closely mirrors biological cognition. Central to this work is the
exploration of how the $\mathbb{C}$-RSN manages to capture the rhythmic,
oscillatory dynamics intrinsic to biological systems, thanks to its complex
eigenvalue structure and the innovative segregation of its linear and
non-linear components. The model's ability to classify data through a
time-dependent function, and the localization of information processing, is
demonstrated with an empirical evaluation using the MNIST dataset. Remarkably,
distinct items supplied as a sequential input yield patterns in time which bear
the indirect imprint of the insertion order (and of the time of separation
between contiguous insertions).

---------------

### 16 Jun 2022 | [Meta-brain Models: biologically-inspired cognitive agents](https://arxiv.org/abs/2109.11938) | [⬇️](https://arxiv.org/pdf/2109.11938)
*Bradly Alicea, Jesse Parent* 

  Artificial Intelligence (AI) systems based solely on neural networks or
symbolic computation present a representational complexity challenge. While
minimal representations can produce behavioral outputs like locomotion or
simple decision-making, more elaborate internal representations might offer a
richer variety of behaviors. We propose that these issues can be addressed with
a computational approach we call meta-brain models. Meta-brain models are
embodied hybrid models that include layered components featuring varying
degrees of representational complexity. We will propose combinations of layers
composed using specialized types of models. Rather than using a generic black
box approach to unify each component, this relationship mimics systems like the
neocortical-thalamic system relationship of the mammalian brain, which utilizes
both feedforward and feedback connectivity to facilitate functional
communication. Importantly, the relationship between layers can be made
anatomically explicit. This allows for structural specificity that can be
incorporated into the model's function in interesting ways. We will propose
several types of layers that might be functionally integrated into agents that
perform unique types of tasks, from agents that simultaneously perform
morphogenesis and perception, to agents that undergo morphogenesis and the
acquisition of conceptual representations simultaneously. Our approach to
meta-brain models involves creating models with different degrees of
representational complexity, creating a layered meta-architecture that mimics
the structural and functional heterogeneity of biological brains, and an
input/output methodology flexible enough to accommodate cognitive functions,
social interactions, and adaptive behaviors more generally. We will conclude by
proposing next steps in the development of this flexible and open-source
approach.

---------------

### 16 Jan 2024 | [BiomedCLIP: a multimodal biomedical foundation model pretrained from  fifteen million scientific image-text pairs](https://arxiv.org/abs/2303.00915) | [⬇️](https://arxiv.org/pdf/2303.00915)
*Sheng Zhang, Yanbo Xu, Naoto Usuyama, Hanwen Xu, Jaspreet Bagga,  Robert Tinn, Sam Preston, Rajesh Rao, Mu Wei, Naveen Valluri, Cliff Wong,  Andrea Tupini, Yu Wang, Matt Mazzola, Swadheen Shukla, Lars Liden, Jianfeng  Gao, Matthew P. Lungren, Tristan Naumann, Sheng Wang, and Hoifung Poon* 

  Biomedical data is inherently multimodal, comprising physical measurements
and natural language narratives. A generalist biomedical AI model needs to
simultaneously process different modalities of data, including text and images.
Therefore, training an effective generalist biomedical model requires
high-quality multimodal data, such as parallel image-text pairs. Here, we
present PMC-15M, a novel dataset that is two orders of magnitude larger than
existing biomedical multimodal datasets such as MIMIC-CXR, and spans a diverse
range of biomedical image types. PMC-15M contains 15 million biomedical
image-text pairs collected from 4.4 million scientific articles. Based on
PMC-15M, we have pretrained BiomedCLIP, a multimodal foundation model, with
domain-specific adaptations tailored to biomedical vision-language processing.
We conducted extensive experiments and ablation studies on standard biomedical
imaging tasks from retrieval to classification to visual question-answering
(VQA). BiomedCLIP achieved new state-of-the-art results in a wide range of
standard datasets, substantially outperforming prior approaches. Intriguingly,
by large-scale pretraining on diverse biomedical image types, BiomedCLIP even
outperforms state-of-the-art radiology-specific models such as BioViL in
radiology-specific tasks such as RSNA pneumonia detection. In summary,
BiomedCLIP is a fully open-access foundation model that achieves
state-of-the-art performance on various biomedical tasks, paving the way for
transformative multimodal biomedical discovery and applications. We release our
models at https://aka.ms/biomedclip to facilitate future research in multimodal
biomedical AI.

---------------

### 06 Feb 2024 | [Progress and Opportunities of Foundation Models in Bioinformatics](https://arxiv.org/abs/2402.04286) | [⬇️](https://arxiv.org/pdf/2402.04286)
*Qing Li, Zhihang Hu, Yixuan Wang, Lei Li, Yimin Fan, Irwin King, Le  Song, Yu Li* 

  Bioinformatics has witnessed a paradigm shift with the increasing integration
of artificial intelligence (AI), particularly through the adoption of
foundation models (FMs). These AI techniques have rapidly advanced, addressing
historical challenges in bioinformatics such as the scarcity of annotated data
and the presence of data noise. FMs are particularly adept at handling
large-scale, unlabeled data, a common scenario in biological contexts due to
the time-consuming and costly nature of experimentally determining labeled
data. This characteristic has allowed FMs to excel and achieve notable results
in various downstream validation tasks, demonstrating their ability to
represent diverse biological entities effectively. Undoubtedly, FMs have
ushered in a new era in computational biology, especially in the realm of deep
learning. The primary goal of this survey is to conduct a systematic
investigation and summary of FMs in bioinformatics, tracing their evolution,
current research status, and the methodologies employed. Central to our focus
is the application of FMs to specific biological problems, aiming to guide the
research community in choosing appropriate FMs for their research needs. We
delve into the specifics of the problem at hand including sequence analysis,
structure prediction, function annotation, and multimodal integration,
comparing the structures and advancements against traditional methods.
Furthermore, the review analyses challenges and limitations faced by FMs in
biology, such as data noise, model explainability, and potential biases.
Finally, we outline potential development paths and strategies for FMs in
future biological research, setting the stage for continued innovation and
application in this rapidly evolving field. This comprehensive review serves
not only as an academic resource but also as a roadmap for future explorations
and applications of FMs in biology.

---------------

### 21 Jun 2023 | [AIGenC: An AI generalisation model via creativity](https://arxiv.org/abs/2205.09738) | [⬇️](https://arxiv.org/pdf/2205.09738)
*Corina Catarau-Cotutiu, Esther Mondragon, Eduardo Alonso* 

  Inspired by cognitive theories of creativity, this paper introduces a
computational model (AIGenC) that lays down the necessary components to enable
artificial agents to learn, use and generate transferable representations.
Unlike machine representation learning, which relies exclusively on raw sensory
data, biological representations incorporate relational and associative
information that embeds rich and structured concept spaces. The AIGenC model
poses a hierarchical graph architecture with various levels and types of
representations procured by different components. The first component, Concept
Processing, extracts objects and affordances from sensory input and encodes
them into a concept space. The resulting representations are stored in a dual
memory system and enriched with goal-directed and temporal information acquired
through reinforcement learning, creating a higher-level of abstraction. Two
additional components work in parallel to detect and recover relevant concepts
and create new ones, respectively, in a process akin to cognitive Reflective
Reasoning and Blending. The Reflective Reasoning unit detects and recovers from
memory concepts relevant to the task by means of a matching process that
calculates a similarity value between the current state and memory graph
structures. Once the matching interaction ends, rewards and temporal
information are added to the graph, building further abstractions. If the
reflective reasoning processing fails to offer a suitable solution, a blending
operation comes into place, creating new concepts by combining past
information. We discuss the model's capability to yield better
out-of-distribution generalisation in artificial agents, thus advancing toward
Artificial General Intelligence.

---------------

### 24 Sep 2023 | [Large AI Models in Health Informatics: Applications, Challenges, and the  Future](https://arxiv.org/abs/2303.11568) | [⬇️](https://arxiv.org/pdf/2303.11568)
*Jianing Qiu, Lin Li, Jiankai Sun, Jiachuan Peng, Peilun Shi, Ruiyang  Zhang, Yinzhao Dong, Kyle Lam, Frank P.-W. Lo, Bo Xiao, Wu Yuan, Ningli Wang,  Dong Xu, Benny Lo* 

  Large AI models, or foundation models, are models recently emerging with
massive scales both parameter-wise and data-wise, the magnitudes of which can
reach beyond billions. Once pretrained, large AI models demonstrate impressive
performance in various downstream tasks. A prime example is ChatGPT, whose
capability has compelled people's imagination about the far-reaching influence
that large AI models can have and their potential to transform different
domains of our lives. In health informatics, the advent of large AI models has
brought new paradigms for the design of methodologies. The scale of multi-modal
data in the biomedical and health domain has been ever-expanding especially
since the community embraced the era of deep learning, which provides the
ground to develop, validate, and advance large AI models for breakthroughs in
health-related areas. This article presents a comprehensive review of large AI
models, from background to their applications. We identify seven key sectors in
which large AI models are applicable and might have substantial influence,
including 1) bioinformatics; 2) medical diagnosis; 3) medical imaging; 4)
medical informatics; 5) medical education; 6) public health; and 7) medical
robotics. We examine their challenges, followed by a critical discussion about
potential future directions and pitfalls of large AI models in transforming the
field of health informatics.

---------------

### 18 May 2023 | [A method for the ethical analysis of brain-inspired AI](https://arxiv.org/abs/2305.10938) | [⬇️](https://arxiv.org/pdf/2305.10938)
*Michele Farisco, Gianluca Baldassarre, Emilio Cartoni, Antonia Leach,  Mihai A. Petrovici, Achim Rosemann, Arleen Salles, Bernd Stahl, Sacha J. van  Albada* 

  Despite its successes, to date Artificial Intelligence (AI) is still
characterized by a number of shortcomings with regards to different application
domains and goals. These limitations are arguably both conceptual (e.g.,
related to underlying theoretical models, such as symbolic vs. connectionist),
and operational (e.g., related to robustness and ability to generalize).
Biologically inspired AI, and more specifically brain-inspired AI, promises to
provide further biological aspects beyond those that are already traditionally
included in AI, making it possible to assess and possibly overcome some of its
present shortcomings. This article examines some conceptual, technical, and
ethical issues raised by the development and use of brain-inspired AI. Against
this background, the paper asks whether there is anything ethically unique
about brain-inspired AI. The aim of the paper is to introduce a method that has
a heuristic nature and that can be applied to identify and address the ethical
issues arising from brain-inspired AI. The conclusion resulting from the
application of this method is that, compared to traditional AI, brain-inspired
AI raises new foundational ethical issues and some new practical ethical
issues, and exacerbates some of the issues raised by traditional AI.

---------------

### 12 Sep 2022 | [A Molecular Multimodal Foundation Model Associating Molecule Graphs with  Natural Language](https://arxiv.org/abs/2209.05481) | [⬇️](https://arxiv.org/pdf/2209.05481)
*Bing Su, Dazhao Du, Zhao Yang, Yujie Zhou, Jiangmeng Li, Anyi Rao, Hao  Sun, Zhiwu Lu, Ji-Rong Wen* 

  Although artificial intelligence (AI) has made significant progress in
understanding molecules in a wide range of fields, existing models generally
acquire the single cognitive ability from the single molecular modality. Since
the hierarchy of molecular knowledge is profound, even humans learn from
different modalities including both intuitive diagrams and professional texts
to assist their understanding. Inspired by this, we propose a molecular
multimodal foundation model which is pretrained from molecular graphs and their
semantically related textual data (crawled from published Scientific Citation
Index papers) via contrastive learning. This AI model represents a critical
attempt that directly bridges molecular graphs and natural language.
Importantly, through capturing the specific and complementary information of
the two modalities, our proposed model can better grasp molecular expertise.
Experimental results show that our model not only exhibits promising
performance in cross-modal tasks such as cross-modal retrieval and molecule
caption, but also enhances molecular property prediction and possesses
capability to generate meaningful molecular graphs from natural language
descriptions. We believe that our model would have a broad impact on
AI-empowered fields across disciplines such as biology, chemistry, materials,
environment, and medicine, among others.

---------------

### 09 Jan 2024 | [BiomedGPT: A Unified and Generalist Biomedical Generative Pre-trained  Transformer for Vision, Language, and Multimodal Tasks](https://arxiv.org/abs/2305.17100) | [⬇️](https://arxiv.org/pdf/2305.17100)
*Kai Zhang, Jun Yu, Eashan Adhikarla, Rong Zhou, Zhiling Yan, Yixin  Liu, Zhengliang Liu, Lifang He, Brian Davison, Xiang Li, Hui Ren, Sunyang Fu,  James Zou, Wei Liu, Jing Huang, Chen Chen, Yuyin Zhou, Tianming Liu, Xun  Chen, Yong Chen, Quanzheng Li, Hongfang Liu, Lichao Sun* 

  Conventional task- and modality-specific artificial intelligence (AI) models
are inflexible in real-world deployment and maintenance for biomedicine. At the
same time, the growing availability of biomedical data, coupled with the
advancements in modern multi-modal multi-task AI techniques, has paved the way
for the emergence of generalist biomedical AI solutions. These solutions hold
the potential to interpret different medical modalities and produce expressive
outputs such as free-text reports or disease diagnosis. Here, we propose
BiomedGPT, the first open-source and generalist visual language AI for diverse
biomedical tasks. BiomedGPT achieved 16 state-of-the-art results across five
clinically significant tasks on 26 datasets. Notably, it outperformed OpenAI's
GPT-4 with vision (GPT-4V) in radiology human evaluation and surpassed Google's
Med-PaLM M (12B) in breast cancer diagnosis and medical visual question
answering. Moreover, BiomedGPT facilitates zero-shot transfer learning, greatly
enhancing its utility as a biomedical assistant, similar to ChatGPT. Our method
demonstrates effective training with diverse datasets can lead to more
practical biomedical AI.

---------------

### 09 Sep 2020 | [ToyArchitecture: Unsupervised Learning of Interpretable Models of the  World](https://arxiv.org/abs/1903.08772) | [⬇️](https://arxiv.org/pdf/1903.08772)
*Jaroslav V\'itk\r{u}, Petr Dluho\v{s}, Joseph Davidson, Mat\v{e}j  Nikl, Simon Andersson, P\v{r}emysl Pa\v{s}ka, Jan \v{S}inkora, Petr  Hlubu\v{c}ek, Martin Str\'ansk\'y, Martin Hyben, Martin Poliak, Jan  Feyereisl, Marek Rosa* 

  Research in Artificial Intelligence (AI) has focused mostly on two extremes:
either on small improvements in narrow AI domains, or on universal theoretical
frameworks which are usually uncomputable, incompatible with theories of
biological intelligence, or lack practical implementations. The goal of this
work is to combine the main advantages of the two: to follow a big picture
view, while providing a particular theory and its implementation. In contrast
with purely theoretical approaches, the resulting architecture should be usable
in realistic settings, but also form the core of a framework containing all the
basic mechanisms, into which it should be easier to integrate additional
required functionality.
  In this paper, we present a novel, purposely simple, and interpretable
hierarchical architecture which combines multiple different mechanisms into one
system: unsupervised learning of a model of the world, learning the influence
of one's own actions on the world, model-based reinforcement learning,
hierarchical planning and plan execution, and symbolic/sub-symbolic integration
in general. The learned model is stored in the form of hierarchical
representations with the following properties: 1) they are increasingly more
abstract, but can retain details when needed, and 2) they are easy to
manipulate in their local and symbolic-like form, thus also allowing one to
observe the learning process at each level of abstraction. On all levels of the
system, the representation of the data can be interpreted in both a symbolic
and a sub-symbolic manner. This enables the architecture to learn efficiently
using sub-symbolic methods and to employ symbolic inference.

---------------

### 30 Jul 2023 | [Spiking Neural Networks and Bio-Inspired Supervised Deep Learning: A  Survey](https://arxiv.org/abs/2307.16235) | [⬇️](https://arxiv.org/pdf/2307.16235)
*Gabriele Lagani, Fabrizio Falchi, Claudio Gennaro, Giuseppe Amato* 

  For a long time, biology and neuroscience fields have been a great source of
inspiration for computer scientists, towards the development of Artificial
Intelligence (AI) technologies. This survey aims at providing a comprehensive
review of recent biologically-inspired approaches for AI. After introducing the
main principles of computation and synaptic plasticity in biological neurons,
we provide a thorough presentation of Spiking Neural Network (SNN) models, and
we highlight the main challenges related to SNN training, where traditional
backprop-based optimization is not directly applicable. Therefore, we discuss
recent bio-inspired training methods, which pose themselves as alternatives to
backprop, both for traditional and spiking networks. Bio-Inspired Deep Learning
(BIDL) approaches towards advancing the computational capabilities and
biological plausibility of current models.

---------------

### 12 Sep 2022 | [Predicting microsatellite instability and key biomarkers in colorectal  cancer from H&E-stained images: Achieving SOTA predictive performance with  fewer data using Swin Transformer](https://arxiv.org/abs/2208.10495) | [⬇️](https://arxiv.org/pdf/2208.10495)
*Bangwei Guo, Xingyu Li, Jitendra Jonnagaddala, Hong Zhang, Xu Steven  Xu* 

  Artificial intelligence (AI) models have been developed for predicting
clinically relevant biomarkers, including microsatellite instability (MSI), for
colorectal cancers (CRC). However, the current deep-learning networks are
data-hungry and require large training datasets, which are often lacking in the
medical domain. In this study, based on the latest Hierarchical Vision
Transformer using Shifted Windows (Swin-T), we developed an efficient workflow
for biomarkers in CRC (MSI, hypermutation, chromosomal instability, CpG island
methylator phenotype, BRAF, and TP53 mutation) that only required relatively
small datasets, but achieved the state-of-the-art (SOTA) predictive
performance. Our Swin-T workflow not only substantially outperformed published
models in an intra-study cross-validation experiment using TCGA-CRC-DX dataset
(N = 462), but also showed excellent generalizability in cross-study external
validation and delivered a SOTA AUROC of 0.90 for MSI using the MCO dataset for
training (N = 1065) and the same TCGA-CRC-DX for testing. Similar performance
(AUROC=0.91) was achieved by Echle and colleagues using approximately 8000
training samples (ResNet18) on the same testing dataset. Swin-T was extremely
efficient using small training datasets and exhibits robust predictive
performance with only 200-500 training samples. These data indicate that Swin-T
may be 5-10 times more efficient than the current state-of-the-art algorithms
for MSI based on ResNet18 and ShuffleNet. Furthermore, the Swin-T models showed
promise as pre-screening tests for MSI status and BRAF mutation status, which
could exclude and reduce the samples before the subsequent standard testing in
a cascading diagnostic workflow to allow turnaround time reduction and cost
saving.

---------------
**Date:** 16 May 2021

**Title:** Curiosity-driven Intuitive Physics Learning

**Abstract Link:** [https://arxiv.org/abs/2105.07426](https://arxiv.org/abs/2105.07426)

**PDF Link:** [https://arxiv.org/pdf/2105.07426](https://arxiv.org/pdf/2105.07426)

---

**Date:** 09 Jun 2023

**Title:** EfficientBioAI: Making Bioimaging AI Models Efficient in Energy, Latency  and Representation

**Abstract Link:** [https://arxiv.org/abs/2306.06152](https://arxiv.org/abs/2306.06152)

**PDF Link:** [https://arxiv.org/pdf/2306.06152](https://arxiv.org/pdf/2306.06152)

---

**Date:** 11 Dec 2023

**Title:** XAI meets Biology: A Comprehensive Review of Explainable AI in  Bioinformatics Applications

**Abstract Link:** [https://arxiv.org/abs/2312.06082](https://arxiv.org/abs/2312.06082)

**PDF Link:** [https://arxiv.org/pdf/2312.06082](https://arxiv.org/pdf/2312.06082)

---

**Date:** 10 Aug 2023

**Title:** AI-GOMS: Large AI-Driven Global Ocean Modeling System

**Abstract Link:** [https://arxiv.org/abs/2308.03152](https://arxiv.org/abs/2308.03152)

**PDF Link:** [https://arxiv.org/pdf/2308.03152](https://arxiv.org/pdf/2308.03152)

---

**Date:** 13 Feb 2024

**Title:** A Survey of Generative AI for De Novo Drug Design: New Frontiers in  Molecule and Protein Generation

**Abstract Link:** [https://arxiv.org/abs/2402.08703](https://arxiv.org/abs/2402.08703)

**PDF Link:** [https://arxiv.org/pdf/2402.08703](https://arxiv.org/pdf/2402.08703)

---

**Date:** 15 Jun 2021

**Title:** Optimality of short-term synaptic plasticity in modelling certain  dynamic environments

**Abstract Link:** [https://arxiv.org/abs/2009.06808](https://arxiv.org/abs/2009.06808)

**PDF Link:** [https://arxiv.org/pdf/2009.06808](https://arxiv.org/pdf/2009.06808)

---

**Date:** 09 Mar 2010

**Title:** Biological Inspiration for Artificial Immune Systems

**Abstract Link:** [https://arxiv.org/abs/1001.2208](https://arxiv.org/abs/1001.2208)

**PDF Link:** [https://arxiv.org/pdf/1001.2208](https://arxiv.org/pdf/1001.2208)

---

**Date:** 11 Apr 2023

**Title:** Habits and goals in synergy: a variational Bayesian framework for  behavior

**Abstract Link:** [https://arxiv.org/abs/2304.05008](https://arxiv.org/abs/2304.05008)

**PDF Link:** [https://arxiv.org/pdf/2304.05008](https://arxiv.org/pdf/2304.05008)

---

**Date:** 12 Dec 2023

**Title:** Complex Recurrent Spectral Network

**Abstract Link:** [https://arxiv.org/abs/2312.07296](https://arxiv.org/abs/2312.07296)

**PDF Link:** [https://arxiv.org/pdf/2312.07296](https://arxiv.org/pdf/2312.07296)

---

**Date:** 16 Jun 2022

**Title:** Meta-brain Models: biologically-inspired cognitive agents

**Abstract Link:** [https://arxiv.org/abs/2109.11938](https://arxiv.org/abs/2109.11938)

**PDF Link:** [https://arxiv.org/pdf/2109.11938](https://arxiv.org/pdf/2109.11938)

---

**Date:** 16 Jan 2024

**Title:** BiomedCLIP: a multimodal biomedical foundation model pretrained from  fifteen million scientific image-text pairs

**Abstract Link:** [https://arxiv.org/abs/2303.00915](https://arxiv.org/abs/2303.00915)

**PDF Link:** [https://arxiv.org/pdf/2303.00915](https://arxiv.org/pdf/2303.00915)

---

**Date:** 06 Feb 2024

**Title:** Progress and Opportunities of Foundation Models in Bioinformatics

**Abstract Link:** [https://arxiv.org/abs/2402.04286](https://arxiv.org/abs/2402.04286)

**PDF Link:** [https://arxiv.org/pdf/2402.04286](https://arxiv.org/pdf/2402.04286)

---

**Date:** 21 Jun 2023

**Title:** AIGenC: An AI generalisation model via creativity

**Abstract Link:** [https://arxiv.org/abs/2205.09738](https://arxiv.org/abs/2205.09738)

**PDF Link:** [https://arxiv.org/pdf/2205.09738](https://arxiv.org/pdf/2205.09738)

---

**Date:** 24 Sep 2023

**Title:** Large AI Models in Health Informatics: Applications, Challenges, and the  Future

**Abstract Link:** [https://arxiv.org/abs/2303.11568](https://arxiv.org/abs/2303.11568)

**PDF Link:** [https://arxiv.org/pdf/2303.11568](https://arxiv.org/pdf/2303.11568)

---

**Date:** 18 May 2023

**Title:** A method for the ethical analysis of brain-inspired AI

**Abstract Link:** [https://arxiv.org/abs/2305.10938](https://arxiv.org/abs/2305.10938)

**PDF Link:** [https://arxiv.org/pdf/2305.10938](https://arxiv.org/pdf/2305.10938)

---

**Date:** 12 Sep 2022

**Title:** A Molecular Multimodal Foundation Model Associating Molecule Graphs with  Natural Language

**Abstract Link:** [https://arxiv.org/abs/2209.05481](https://arxiv.org/abs/2209.05481)

**PDF Link:** [https://arxiv.org/pdf/2209.05481](https://arxiv.org/pdf/2209.05481)

---

**Date:** 09 Jan 2024

**Title:** BiomedGPT: A Unified and Generalist Biomedical Generative Pre-trained  Transformer for Vision, Language, and Multimodal Tasks

**Abstract Link:** [https://arxiv.org/abs/2305.17100](https://arxiv.org/abs/2305.17100)

**PDF Link:** [https://arxiv.org/pdf/2305.17100](https://arxiv.org/pdf/2305.17100)

---

**Date:** 09 Sep 2020

**Title:** ToyArchitecture: Unsupervised Learning of Interpretable Models of the  World

**Abstract Link:** [https://arxiv.org/abs/1903.08772](https://arxiv.org/abs/1903.08772)

**PDF Link:** [https://arxiv.org/pdf/1903.08772](https://arxiv.org/pdf/1903.08772)

---

**Date:** 30 Jul 2023

**Title:** Spiking Neural Networks and Bio-Inspired Supervised Deep Learning: A  Survey

**Abstract Link:** [https://arxiv.org/abs/2307.16235](https://arxiv.org/abs/2307.16235)

**PDF Link:** [https://arxiv.org/pdf/2307.16235](https://arxiv.org/pdf/2307.16235)

---

**Date:** 12 Sep 2022

**Title:** Predicting microsatellite instability and key biomarkers in colorectal  cancer from H&E-stained images: Achieving SOTA predictive performance with  fewer data using Swin Transformer

**Abstract Link:** [https://arxiv.org/abs/2208.10495](https://arxiv.org/abs/2208.10495)

**PDF Link:** [https://arxiv.org/pdf/2208.10495](https://arxiv.org/pdf/2208.10495)

---

