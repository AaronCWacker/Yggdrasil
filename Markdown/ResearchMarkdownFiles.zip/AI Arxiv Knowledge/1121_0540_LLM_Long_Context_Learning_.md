LLM Long Context Learning ⏳

### 🔎 LLM Long Context Learning ⏳


================================

This is a PyTorch implementation of the paper [Long Context Learning for Transformers](https://arxiv.org/abs/2101.03961) by Jonathan Frankle, Mike Lewis, and Sarah Hooper.

The code is based on the [Transformers](https://github.com/huggingface/transformers) library.

## Installation

To install the required packages, run:

```bash
pip install -r requirements.txt
```

## Usage

To train a model, run:

```bash
python train.py --model_name_or_path t5-base --dataset_name wmt16 --dataset_config ro-en --per_device_train_batch_size 1 --gradient_accumulation_steps 16 --learning_rate 1e-4 --num_train_epochs 10 --output_dir output --logging_steps 100 --save_steps 1000 --eval_steps 1000 --overwrite_output_dir --fp16 --fp16_opt_level O1 --max_seq_length 512 --max_target_length 128 --gradient_checkpointing --longformer_length 4096 --longformer_every_n_blocks 8 --longformer_gradient_checkpointing
```

To evaluate a model, run:

```bash
python eval.py --model_name_or_path output/checkpoint-best.pt --dataset_name wmt16 --dataset_config ro-en --per_device_eval_batch_size 1 --max_seq_length 512 --max_target_length 128 --gradient_checkpointing --longformer_length 4096 --longformer_every_n_blocks 8 --longformer_gradient_checkpointing
```

## Results

The following table shows the results of the models trained with this code on the WMT16 Romanian-English dataset.

| Model | BLEU |
| --- | --- |
| T5-base | 27.5 |
|
# 🩺🔍 Search Results
### 12 Jun 2023 | [Augmenting Language Models with Long-Term Memory](https://arxiv.org/abs/2306.07174) | [⬇️](https://arxiv.org/pdf/2306.07174)
*Weizhi Wang, Li Dong, Hao Cheng, Xiaodong Liu, Xifeng Yan, Jianfeng  Gao, Furu Wei* 

  Existing large language models (LLMs) can only afford fix-sized inputs due to
the input length limit, preventing them from utilizing rich long-context
information from past inputs. To address this, we propose a framework, Language
Models Augmented with Long-Term Memory (LongMem), which enables LLMs to
memorize long history. We design a novel decoupled network architecture with
the original backbone LLM frozen as a memory encoder and an adaptive residual
side-network as a memory retriever and reader. Such a decoupled memory design
can easily cache and update long-term past contexts for memory retrieval
without suffering from memory staleness. Enhanced with memory-augmented
adaptation training, LongMem can thus memorize long past context and use
long-term memory for language modeling. The proposed memory retrieval module
can handle unlimited-length context in its memory bank to benefit various
downstream tasks. Typically, LongMem can enlarge the long-form memory to 65k
tokens and thus cache many-shot extra demonstration examples as long-form
memory for in-context learning. Experiments show that our method outperforms
strong long-context models on ChapterBreak, a challenging long-context modeling
benchmark, and achieves remarkable improvements on memory-augmented in-context
learning over LLMs. The results demonstrate that the proposed method is
effective in helping language models to memorize and utilize long-form
contents. Our code is open-sourced at https://aka.ms/LongMem.

---------------

### 28 Aug 2023 | [LongBench: A Bilingual, Multitask Benchmark for Long Context  Understanding](https://arxiv.org/abs/2308.14508) | [⬇️](https://arxiv.org/pdf/2308.14508)
*Yushi Bai, Xin Lv, Jiajie Zhang, Hongchang Lyu, Jiankai Tang, Zhidian  Huang, Zhengxiao Du, Xiao Liu, Aohan Zeng, Lei Hou, Yuxiao Dong, Jie Tang,  Juanzi Li* 

  Although large language models (LLMs) demonstrate impressive performance for
many language tasks, most of them can only handle texts a few thousand tokens
long, limiting their applications on longer sequence inputs, such as books,
reports, and codebases. Recent works have proposed methods to improve LLMs'
long context capabilities by extending context windows and more sophisticated
memory mechanisms. However, comprehensive benchmarks tailored for evaluating
long context understanding are lacking. In this paper, we introduce LongBench,
the first bilingual, multi-task benchmark for long context understanding,
enabling a more rigorous evaluation of long context understanding. LongBench
comprises 21 datasets across 6 task categories in both English and Chinese,
with an average length of 6,711 words (English) and 13,386 characters
(Chinese). These tasks cover key long-text application areas including
single-doc QA, multi-doc QA, summarization, few-shot learning, synthetic tasks,
and code completion. All datasets in LongBench are standardized into a unified
format, allowing for effortless automatic evaluation of LLMs. Upon
comprehensive evaluation of 8 LLMs on LongBench, we find that: (1) Commercial
model (GPT-3.5-Turbo-16k) outperforms other open-sourced models, but still
struggles on longer contexts. (2) Scaled position embedding and fine-tuning on
longer sequences lead to substantial improvement on long context understanding.
(3) Context compression technique such as retrieval brings improvement for
model with weak ability on long contexts, but the performance still lags behind
models that have strong long context understanding capability. The code and
datasets are available at https://github.com/THUDM/LongBench.

---------------

### 01 Aug 2023 | [Parallel Context Windows for Large Language Models](https://arxiv.org/abs/2212.10947) | [⬇️](https://arxiv.org/pdf/2212.10947)
*Nir Ratner, Yoav Levine, Yonatan Belinkov, Ori Ram, Inbal Magar, Omri  Abend, Ehud Karpas, Amnon Shashua, Kevin Leyton-Brown, Yoav Shoham* 

  When applied to processing long text, Large Language Models (LLMs) are
limited by their context window. Existing efforts to address this limitation
involve training specialized architectures, and cannot be easily applied to
off-the-shelf LLMs. We present Parallel Context Windows (PCW), a method that
alleviates the context window restriction for any off-the-shelf LLM without
further training. The key to the approach is to carve a long context into
chunks (``windows''), restrict the attention mechanism to apply only within
each window, and re-use the positional embeddings across the windows. Our main
results test the PCW approach on in-context learning with models that range in
size between 750 million and 178 billion parameters, and show substantial
improvements for tasks with diverse input and output spaces. We show additional
benefits in other settings where long context windows may be beneficial:
multi-hop questions and retrieval-augmented question answering with multiple
retrieved documents. Our results highlight Parallel Context Windows as a
promising method for applying off-the-shelf LLMs in a range of settings that
require long text sequences. We make our code publicly available at
https://github.com/ai21labs/parallel-context-windows.

---------------

### 10 Oct 2023 | [LongLLMLingua: Accelerating and Enhancing LLMs in Long Context Scenarios  via Prompt Compression](https://arxiv.org/abs/2310.06839) | [⬇️](https://arxiv.org/pdf/2310.06839)
*Huiqiang Jiang, Qianhui Wu, Xufang Luo, Dongsheng Li, Chin-Yew Lin,  Yuqing Yang, Lili Qiu* 

  In long context scenarios, large language models (LLMs) face three main
challenges: higher computational/financial cost, longer latency, and inferior
performance. Some studies reveal that the performance of LLMs depends on both
the density and the position of the key information (question relevant) in the
input prompt. Inspired by these findings, we propose LongLLMLingua for prompt
compression towards improving LLMs' perception of the key information to
simultaneously address the three challenges. We conduct evaluation on a wide
range of long context scenarios including single-/multi-document QA, few-shot
learning, summarization, synthetic tasks, and code completion. The experimental
results show that LongLLMLingua compressed prompt can derive higher performance
with much less cost. The latency of the end-to-end system is also reduced. For
example, on NaturalQuestions benchmark, LongLLMLingua gains a performance boost
of up to 17.1% over the original prompt with ~4x fewer tokens as input to
GPT-3.5-Turbo. It can derive cost savings of \$28.5 and \$27.4 per 1,000
samples from the LongBench and ZeroScrolls benchmark, respectively.
Additionally, when compressing prompts of ~10k tokens at a compression rate of
2x-10x, LongLLMLingua can speed up the end-to-end latency by 1.4x-3.8x. Our
code is available at https://aka.ms/LLMLingua.

---------------

### 16 Nov 2023 | [Take One Step at a Time to Know Incremental Utility of Demonstration: An  Analysis on Reranking for Few-Shot In-Context Learning](https://arxiv.org/abs/2311.09619) | [⬇️](https://arxiv.org/pdf/2311.09619)
*Kazuma Hashimoto, Karthik Raman, Michael Bendersky* 

  In-Context Learning (ICL) is an emergent capability of Large Language Models
(LLMs). Only a few demonstrations enable LLMs to be used as blackbox for new
tasks. Previous studies have shown that using LLMs' outputs as labels is
effective in training models to select demonstrations. Such a label is expected
to estimate utility of a demonstration in ICL; however, it has not been well
understood how different labeling strategies affect results on target tasks.
This paper presents an analysis on different utility functions by focusing on
LLMs' output probability given ground-truth output, and task-specific reward
given LLMs' prediction. Unlike the previous work, we introduce a novel labeling
method, incremental utility, which estimates how much incremental knowledge is
brought into the LLMs by a demonstration. We conduct experiments with
instruction-tuned LLMs on binary/multi-class classification, segmentation, and
translation across Arabic, English, Finnish, Japanese, and Spanish. Our results
show that (1) the probability is effective when the probability values are
distributed across the whole value range (on the classification tasks), and (2)
the downstream metric is more robust when nuanced reward values are provided
with long outputs (on the segmentation and translation tasks). We then show
that the proposed incremental utility further helps ICL by contrasting how the
LLMs perform with and without the demonstrations.

---------------

### 08 Nov 2023 | [LooGLE: Can Long-Context Language Models Understand Long Contexts?](https://arxiv.org/abs/2311.04939) | [⬇️](https://arxiv.org/pdf/2311.04939)
*Jiaqi Li, Mengmeng Wang, Zilong Zheng, Muhan Zhang* 

  Large language models (LLMs), despite their impressive performance in various
language tasks, are typically limited to processing texts within context-window
size. This limitation has spurred significant research efforts to enhance LLMs'
long-context understanding with high-quality long-sequence benchmarks. However,
prior datasets in this regard suffer from shortcomings, such as short context
length compared to the context window of modern LLMs; outdated documents that
have data leakage problems; and an emphasis on short dependency tasks rather
than long dependency tasks. In this paper, we present LooGLE, a Long Context
Generic Language Evaluation benchmark for LLMs' long context understanding.
LooGLE features relatively new documents post-2022, with over 24,000 tokens per
document and 6,000 newly generated questions spanning diverse domains. Human
annotators meticulously crafted more than 1,100 high-quality question-answer
pairs to meet the long dependency requirements. These pairs underwent thorough
cross-validation, yielding the most precise assessment of LLMs' long dependency
capabilities. The evaluation of eight state-of-the-art LLMs on LooGLE revealed
key findings: (i) commercial models outperformed open-sourced models; (ii) LLMs
excelled in short dependency tasks like short question-answering and cloze
tasks but struggled with more intricate long dependency tasks; (iii) in-context
learning and chaining thoughts offered only marginal improvements; (iv)
retrieval-based techniques demonstrated substantial benefits for short
question-answering, while strategies for extending context window length had
limited impact on long context understanding. As such, LooGLE not only provides
a systematic and comprehensive evaluation schema on long-context LLMs, but also
sheds light on future development of enhanced models towards "true long-context
understanding".

---------------

### 21 Feb 2024 | [CAMELoT: Towards Large Language Models with Training-Free Consolidated  Associative Memory](https://arxiv.org/abs/2402.13449) | [⬇️](https://arxiv.org/pdf/2402.13449)
*Zexue He, Leonid Karlinsky, Donghyun Kim, Julian McAuley, Dmitry  Krotov, Rogerio Feris* 

  Large Language Models (LLMs) struggle to handle long input sequences due to
high memory and runtime costs. Memory-augmented models have emerged as a
promising solution to this problem, but current methods are hindered by limited
memory capacity and require costly re-training to integrate with a new LLM. In
this work, we introduce an associative memory module which can be coupled to
any pre-trained (frozen) attention-based LLM without re-training, enabling it
to handle arbitrarily long input sequences. Unlike previous methods, our
associative memory module consolidates representations of individual tokens
into a non-parametric distribution model, dynamically managed by properly
balancing the novelty and recency of the incoming data. By retrieving
information from this consolidated associative memory, the base LLM can achieve
significant (up to 29.7% on Arxiv) perplexity reduction in long-context
modeling compared to other baselines evaluated on standard benchmarks. This
architecture, which we call CAMELoT (Consolidated Associative Memory Enhanced
Long Transformer), demonstrates superior performance even with a tiny context
window of 128 tokens, and also enables improved in-context learning with a much
larger set of demonstrations.

---------------

### 15 Nov 2023 | [When does In-context Learning Fall Short and Why? A Study on  Specification-Heavy Tasks](https://arxiv.org/abs/2311.08993) | [⬇️](https://arxiv.org/pdf/2311.08993)
*Hao Peng, Xiaozhi Wang, Jianhui Chen, Weikai Li, Yunjia Qi, Zimu Wang,  Zhili Wu, Kaisheng Zeng, Bin Xu, Lei Hou, Juanzi Li* 

  In-context learning (ICL) has become the default method for using large
language models (LLMs), making the exploration of its limitations and
understanding the underlying causes crucial. In this paper, we find that ICL
falls short of handling specification-heavy tasks, which are tasks with
complicated and extensive task specifications, requiring several hours for
ordinary humans to master, such as traditional information extraction tasks.
The performance of ICL on these tasks mostly cannot reach half of the
state-of-the-art results. To explore the reasons behind this failure, we
conduct comprehensive experiments on 18 specification-heavy tasks with various
LLMs and identify three primary reasons: inability to specifically understand
context, misalignment in task schema comprehension with humans, and inadequate
long-text understanding ability. Furthermore, we demonstrate that through
fine-tuning, LLMs can achieve decent performance on these tasks, indicating
that the failure of ICL is not an inherent flaw of LLMs, but rather a drawback
of existing alignment methods that renders LLMs incapable of handling
complicated specification-heavy tasks via ICL. To substantiate this, we perform
dedicated instruction tuning on LLMs for these tasks and observe a notable
improvement. We hope the analyses in this paper could facilitate advancements
in alignment methods enabling LLMs to meet more sophisticated human demands.

---------------

### 02 Feb 2024 | [Soaring from 4K to 400K: Extending LLM's Context with Activation Beacon](https://arxiv.org/abs/2401.03462) | [⬇️](https://arxiv.org/pdf/2401.03462)
*Peitian Zhang, Zheng Liu, Shitao Xiao, Ninglu Shao, Qiwei Ye, Zhicheng  Dou* 

  The utilization of long contexts poses a big challenge for LLMs due to their
limited context window size. Although the context window can be extended
through fine-tuning, it will result in a considerable cost at both training and
inference time, and exert an unfavorable impact to the LLM's original
capabilities. In this work, we propose a new method called Activation Beacon,
which condenses LLM's raw activations into compact forms such that the LLM can
perceive a longer context with a limited context window. Activation Beacon is
introduced as a plug-in module, which fully preserves the LLM's original
capability in short contexts. It works with the sliding window to streamingly
process the long context, which leads to a competitive memory and time
efficiency in both training and inference. Activation Beacon is trained with
short-sequence data of diversified condensing ratios. Thanks to such a
treatment, it can be effectively learned to support different context lengths
with a small training cost. Our experiment verifies Activation Beacon's
effectiveness of context extension: it can remarkably accomplish high-quality
extension of Llama-2-7B's context by $\times100$ times (from 4K to 400K);
meanwhile, it can also achieve superior performances across a variety of
long-context language modeling and understanding tasks. The source code and
model checkpoint are available at
\url{https://github.com/FlagOpen/FlagEmbedding}.

---------------

### 02 Oct 2023 | [In-context Autoencoder for Context Compression in a Large Language Model](https://arxiv.org/abs/2307.06945) | [⬇️](https://arxiv.org/pdf/2307.06945)
*Tao Ge, Jing Hu, Lei Wang, Xun Wang, Si-Qing Chen, Furu Wei* 

  We propose the In-context Autoencoder (ICAE), leveraging the power of a large
language models (LLM) to compress a long context into short compact memory
slots that can be directly conditioned on by the LLM for various purposes. ICAE
is first pretrained using both autoencoding and language modeling objectives on
massive text data, enabling it to generate memory slots that accurately and
comprehensively represent the original context; Then, it is fine-tuned on
instruction data for producing desirable responses to various prompts.
Experiments demonstrate that our lightweight ICAE, introducing fewer than 1%
additional parameters, effectively achieves 4X context compression based on
Llama, offering advantages in both improved latency and GPU memory cost during
inference, and showing an interesting insight in memorization as well as
potential for scalability. These promising results imply a novel perspective on
the connection between working memory in cognitive science and representation
learning in LLMs, revealing ICAE's significant implications in addressing the
long context problem and suggesting further research in LLM context management.
Our data, code and model are released at https://github.com/getao/icae.

---------------

### 26 Sep 2023 | [Boosting In-Context Learning with Factual Knowledge](https://arxiv.org/abs/2309.14771) | [⬇️](https://arxiv.org/pdf/2309.14771)
*Jianing Wang, Chengyu Wang, Chuanqi Tan, Jun Huang, Ming Gao* 

  In-Context Learning (ICL) over Large language models (LLMs) aims at solving
previously unseen tasks by conditioning on a few training examples, eliminating
the need for parameter updates and achieving competitive performance. In this
paper, we demonstrate that factual knowledge is imperative for the performance
of ICL in three core facets, i.e., the inherent knowledge learned in LLMs, the
factual knowledge derived from the selected in-context examples, and the
knowledge biases in LLMs for output generation. To unleash the power of LLMs in
few-shot learning scenarios, we introduce a novel Knowledgeable In-Context
Tuning (KICT) framework to further improve the performance of ICL: 1) injecting
factual knowledge to LLMs during continual self-supervised pre-training, 2)
judiciously selecting the examples with high knowledge relevance, and 3)
calibrating the prediction results based on prior knowledge. We evaluate the
proposed approaches on auto-regressive LLMs (e.g., GPT-style models) over
multiple text classification and question answering tasks. Experimental results
demonstrate that KICT substantially outperforms strong baselines, and improves
by more than 13% and 7% of accuracy on text classification and question
answering tasks, respectively.

---------------

### 05 Dec 2023 | [LongLoRA: Efficient Fine-tuning of Long-Context Large Language Models](https://arxiv.org/abs/2309.12307) | [⬇️](https://arxiv.org/pdf/2309.12307)
*Yukang Chen, Shengju Qian, Haotian Tang, Xin Lai, Zhijian Liu, Song  Han, Jiaya Jia* 

  We present LongLoRA, an efficient fine-tuning approach that extends the
context sizes of pre-trained large language models (LLMs), with limited
computation cost. Typically, training LLMs with long context sizes is
computationally expensive, requiring extensive training hours and GPU
resources. For example, training on the context length of 8192 needs 16x
computational costs in self-attention layers as that of 2048. In this paper, we
speed up the context extension of LLMs in two aspects. On the one hand,
although dense global attention is needed during inference, fine-tuning the
model can be effectively and efficiently done by sparse local attention. The
proposed shifted sparse attention (S$^2$-Attn) effectively enables context
extension, leading to non-trivial computation saving with similar performance
to fine-tuning with vanilla attention. Particularly, it can be implemented with
only two lines of code in training, while being optional in inference. On the
other hand, we revisit the parameter-efficient fine-tuning regime for context
expansion. Notably, we find that LoRA for context extension works well under
the premise of trainable embedding and normalization. LongLoRA combines this
improved LoRA with S$^2$-Attn. LongLoRA demonstrates strong empirical results
on various tasks on Llama2 models from 7B/13B to 70B. LongLoRA adopts Llama2 7B
from 4k context to 100k, or Llama2 70B to 32k on a single 8x A100 machine.
LongLoRA extends models' context while retaining their original architectures,
and is compatible with most existing techniques, like Flash-Attention2. In
addition, we further conduct supervised fine-tuning with LongLoRA and our long
instruction-following LongAlpaca dataset.

---------------

### 07 Jun 2023 | [Enhancing In-Context Learning with Answer Feedback for Multi-Span  Question Answering](https://arxiv.org/abs/2306.04508) | [⬇️](https://arxiv.org/pdf/2306.04508)
*Zixian Huang, Jiaying Zhou, Gengyang Xiao, Gong Cheng* 

  Whereas the recent emergence of large language models (LLMs) like ChatGPT has
exhibited impressive general performance, it still has a large gap with
fully-supervised models on specific tasks such as multi-span question
answering. Previous researches found that in-context learning is an effective
approach to exploiting LLM, by using a few task-related labeled data as
demonstration examples to construct a few-shot prompt for answering new
questions. A popular implementation is to concatenate a few questions and their
correct answers through simple templates, informing LLM of the desired output.
In this paper, we propose a novel way of employing labeled data such that it
also informs LLM of some undesired output, by extending demonstration examples
with feedback about answers predicted by an off-the-shelf model, e.g., correct,
incorrect, or incomplete. Experiments on three multi-span question answering
datasets as well as a keyphrase extraction dataset show that our new prompting
strategy consistently improves LLM's in-context learning performance.

---------------

### 30 Sep 2023 | [Privacy-Preserving In-Context Learning for Large Language Models](https://arxiv.org/abs/2305.01639) | [⬇️](https://arxiv.org/pdf/2305.01639)
*Tong Wu, Ashwinee Panda, Jiachen T. Wang, Prateek Mittal* 

  In-context learning (ICL) is an important capability of Large Language Models
(LLMs), enabling these models to dynamically adapt based on specific,
in-context exemplars, thereby improving accuracy and relevance. However, LLM's
responses may leak the sensitive private information contained in in-context
exemplars. To address this challenge, we propose Differentially Private
In-context Learning (DP-ICL), a general paradigm for privatizing ICL tasks. The
key idea for DP-ICL paradigm is generating differentially private responses
through a noisy consensus among an ensemble of LLM's responses based on
disjoint exemplar sets. Based on the general paradigm of DP-ICL, we instantiate
several techniques showing how to privatize ICL for text classification and
language generation. We evaluate DP-ICL on four text classification benchmarks
and two language generation tasks, and our empirical results show that DP-ICL
achieves a strong utility-privacy tradeoff.

---------------

### 15 Jan 2024 | [Flexibly Scaling Large Language Models Contexts Through Extensible  Tokenization](https://arxiv.org/abs/2401.07793) | [⬇️](https://arxiv.org/pdf/2401.07793)
*Ninglu Shao and Shitao Xiao and Zheng Liu and Peitian Zhang* 

  Large language models (LLMs) are in need of sufficient contexts to handle
many critical applications, such as retrieval augmented generation and few-shot
learning. However, due to the constrained window size, the LLMs can only access
to the information within a limited context. Although the size of context
window can be extended by fine-tuning, it will result in a substantial cost in
both training and inference stage. In this paper, we present Extensible
Tokenization as an alternative method which realizes the flexible scaling of
LLMs' context. Extensible Tokenization stands as a midware in between of the
tokenized context and the LLM, which transforms the raw token embeddings into
the extensible embeddings. Such embeddings provide a more compact
representation for the long context, on top of which the LLM is able to
perceive more information with the same context window. Extensible Tokenization
is also featured by its flexibility: the scaling factor can be flexibly
determined within a feasible scope, leading to the extension of an arbitrary
context length at the inference time. Besides, Extensible Tokenization is
introduced as a drop-in component, which can be seamlessly plugged into not
only the LLM itself and but also its fine-tuned derivatives, bringing in the
extended contextual information while fully preserving the LLM's existing
capabilities. We perform comprehensive experiments on long-context language
modeling and understanding tasks, which verify Extensible Tokenization as an
effective, efficient, flexible, and compatible method to extend LLM's context.
Our model and source code will be made publicly available.

---------------

### 21 May 2023 | [Enhancing Few-shot Text-to-SQL Capabilities of Large Language Models: A  Study on Prompt Design Strategies](https://arxiv.org/abs/2305.12586) | [⬇️](https://arxiv.org/pdf/2305.12586)
*Linyong Nan, Yilun Zhao, Weijin Zou, Narutatsu Ri, Jaesung Tae, Ellen  Zhang, Arman Cohan, Dragomir Radev* 

  In-context learning (ICL) has emerged as a new approach to various natural
language processing tasks, utilizing large language models (LLMs) to make
predictions based on context that has been supplemented with a few examples or
task-specific instructions. In this paper, we aim to extend this method to
question answering tasks that utilize structured knowledge sources, and improve
Text-to-SQL systems by exploring various prompt design strategies for employing
LLMs. We conduct a systematic investigation into different demonstration
selection methods and optimal instruction formats for prompting LLMs in the
Text-to-SQL task. Our approach involves leveraging the syntactic structure of
an example's SQL query to retrieve demonstrations, and we demonstrate that
pursuing both diversity and similarity in demonstration selection leads to
enhanced performance. Furthermore, we show that LLMs benefit from
database-related knowledge augmentations. Our most effective strategy
outperforms the state-of-the-art system by 2.5 points (Execution Accuracy) and
the best fine-tuned system by 5.1 points on the Spider dataset. These results
highlight the effectiveness of our approach in adapting LLMs to the Text-to-SQL
task, and we present an analysis of the factors contributing to the success of
our strategy.

---------------

### 23 Jan 2024 | [Retrieval meets Long Context Large Language Models](https://arxiv.org/abs/2310.03025) | [⬇️](https://arxiv.org/pdf/2310.03025)
*Peng Xu, Wei Ping, Xianchao Wu, Lawrence McAfee, Chen Zhu, Zihan Liu,  Sandeep Subramanian, Evelina Bakhturina, Mohammad Shoeybi, Bryan Catanzaro* 

  Extending the context window of large language models (LLMs) is getting
popular recently, while the solution of augmenting LLMs with retrieval has
existed for years. The natural questions are: i) Retrieval-augmentation versus
long context window, which one is better for downstream tasks? ii) Can both
methods be combined to get the best of both worlds? In this work, we answer
these questions by studying both solutions using two state-of-the-art
pretrained LLMs, i.e., a proprietary 43B GPT and Llama2-70B. Perhaps
surprisingly, we find that LLM with 4K context window using simple
retrieval-augmentation at generation can achieve comparable performance to
finetuned LLM with 16K context window via positional interpolation on long
context tasks, while taking much less computation. More importantly, we
demonstrate that retrieval can significantly improve the performance of LLMs
regardless of their extended context window sizes. Our best model,
retrieval-augmented Llama2-70B with 32K context window, outperforms
GPT-3.5-turbo-16k and Davinci003 in terms of average score on nine long context
tasks including question answering, query-based summarization, and in-context
few-shot learning tasks. It also outperforms its non-retrieval Llama2-70B-32k
baseline by a margin, while being much faster at generation. Our study provides
general insights on the choice of retrieval-augmentation versus long context
extension of LLM for practitioners.

---------------

### 22 Feb 2024 | [E^2-LLM: Efficient and Extreme Length Extension of Large Language Models](https://arxiv.org/abs/2401.06951) | [⬇️](https://arxiv.org/pdf/2401.06951)
*Jiaheng Liu, Zhiqi Bai, Yuanxing Zhang, Chenchen Zhang, Yu Zhang, Ge  Zhang, Jiakai Wang, Haoran Que, Yukang Chen, Wenbo Su, Tiezheng Ge, Jie Fu,  Wenhu Chen, Bo Zheng* 

  Typically, training LLMs with long context sizes is computationally
expensive, requiring extensive training hours and GPU resources. Existing
long-context extension methods usually need additional training procedures to
support corresponding long-context windows, where the long-context training
data (e.g., 32k) is needed, and high GPU training costs are assumed. To address
the aforementioned issues, we propose an Efficient and Extreme length extension
method for Large Language Models, called E 2 -LLM, with only one training
procedure and dramatically reduced computation cost, which also removes the
need to collect long-context data. Concretely, first, the training data of our
E 2 -LLM only requires a short length (e.g., 4k), which reduces the tuning cost
greatly. Second, the training procedure on the short training context window is
performed only once time, and we can support different evaluation context
windows at inference. Third, in E 2 - LLM, based on RoPE position embeddings,
we introduce two different augmentation methods on the scale and position index
parameters for different samples in training. It aims to make the model more
robust to the different relative differences when directly interpolating the
arbitrary context length at inference. Comprehensive experimental results on
multiple benchmark datasets demonstrate the effectiveness of our E 2 -LLM on
challenging long-context tasks.

---------------

### 30 Sep 2023 | [Dynamic Demonstrations Controller for In-Context Learning](https://arxiv.org/abs/2310.00385) | [⬇️](https://arxiv.org/pdf/2310.00385)
*Fei Zhao, Taotian Pang, Zhen Wu, Zheng Ma, Shujian Huang, Xinyu Dai* 

  In-Context Learning (ICL) is a new paradigm for natural language processing
(NLP), where a large language model (LLM) observes a small number of
demonstrations and a test instance as its input, and directly makes predictions
without updating model parameters. Previous studies have revealed that ICL is
sensitive to the selection and the ordering of demonstrations. However, there
are few studies regarding the impact of the demonstration number on the ICL
performance within a limited input length of LLM, because it is commonly
believed that the number of demonstrations is positively correlated with model
performance. In this paper, we found this conclusion does not always hold true.
Through pilot experiments, we discover that increasing the number of
demonstrations does not necessarily lead to improved performance. Building upon
this insight, we propose a Dynamic Demonstrations Controller (D$^2$Controller),
which can improve the ICL performance by adjusting the number of demonstrations
dynamically. The experimental results show that D$^2$Controller yields a 5.4%
relative improvement on eight different sizes of LLMs across ten datasets.
Moreover, we also extend our method to previous ICL models and achieve
competitive results.

---------------

### 13 Nov 2023 | [In-context Learning Generalizes, But Not Always Robustly: The Case of  Syntax](https://arxiv.org/abs/2311.07811) | [⬇️](https://arxiv.org/pdf/2311.07811)
*Aaron Mueller, Albert Webson, Jackson Petty, Tal Linzen* 

  In-context learning (ICL) is now a common method for supervising large
language models (LLMs): given labeled examples in the input context, the LLM
learns to perform the task without weight updates. Despite ICL's prevalence and
utility, we understand little about whether models supervised in this manner
represent the underlying structure of their tasks, rather than superficial
heuristics that only generalize to identically distributed examples. In this
study, we investigate the robustness of LLMs supervised via ICL using the test
case of sensitivity to syntax, which is a prerequisite for robust language
understanding. Our experiments are based on two simple and well-controlled
syntactic transformations tasks, where correct out-of-distribution
generalization requires an accurate syntactic analysis of the input. We further
investigate whether out-of-distribution generalization can be improved via
chain-of-thought prompting, where the model is provided with a sequence of
intermediate computation steps that illustrate how the task ought to be
performed. In experiments with models from the GPT, PaLM, and Llama 2 families,
we find large variance across LMs on this fundamental linguistic phenomenon,
and that the variance is explained more by the composition of the pre-training
corpus and supervision methods than by model size. In particular, we find
evidence that models pre-trained on code generalize better, and benefit to a
greater extent from chain-of-thought prompting.

---------------
**Date:** 12 Jun 2023

**Title:** Augmenting Language Models with Long-Term Memory

**Abstract Link:** [https://arxiv.org/abs/2306.07174](https://arxiv.org/abs/2306.07174)

**PDF Link:** [https://arxiv.org/pdf/2306.07174](https://arxiv.org/pdf/2306.07174)

---

**Date:** 28 Aug 2023

**Title:** LongBench: A Bilingual, Multitask Benchmark for Long Context  Understanding

**Abstract Link:** [https://arxiv.org/abs/2308.14508](https://arxiv.org/abs/2308.14508)

**PDF Link:** [https://arxiv.org/pdf/2308.14508](https://arxiv.org/pdf/2308.14508)

---

**Date:** 01 Aug 2023

**Title:** Parallel Context Windows for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2212.10947](https://arxiv.org/abs/2212.10947)

**PDF Link:** [https://arxiv.org/pdf/2212.10947](https://arxiv.org/pdf/2212.10947)

---

**Date:** 10 Oct 2023

**Title:** LongLLMLingua: Accelerating and Enhancing LLMs in Long Context Scenarios  via Prompt Compression

**Abstract Link:** [https://arxiv.org/abs/2310.06839](https://arxiv.org/abs/2310.06839)

**PDF Link:** [https://arxiv.org/pdf/2310.06839](https://arxiv.org/pdf/2310.06839)

---

**Date:** 16 Nov 2023

**Title:** Take One Step at a Time to Know Incremental Utility of Demonstration: An  Analysis on Reranking for Few-Shot In-Context Learning

**Abstract Link:** [https://arxiv.org/abs/2311.09619](https://arxiv.org/abs/2311.09619)

**PDF Link:** [https://arxiv.org/pdf/2311.09619](https://arxiv.org/pdf/2311.09619)

---

**Date:** 08 Nov 2023

**Title:** LooGLE: Can Long-Context Language Models Understand Long Contexts?

**Abstract Link:** [https://arxiv.org/abs/2311.04939](https://arxiv.org/abs/2311.04939)

**PDF Link:** [https://arxiv.org/pdf/2311.04939](https://arxiv.org/pdf/2311.04939)

---

**Date:** 21 Feb 2024

**Title:** CAMELoT: Towards Large Language Models with Training-Free Consolidated  Associative Memory

**Abstract Link:** [https://arxiv.org/abs/2402.13449](https://arxiv.org/abs/2402.13449)

**PDF Link:** [https://arxiv.org/pdf/2402.13449](https://arxiv.org/pdf/2402.13449)

---

**Date:** 15 Nov 2023

**Title:** When does In-context Learning Fall Short and Why? A Study on  Specification-Heavy Tasks

**Abstract Link:** [https://arxiv.org/abs/2311.08993](https://arxiv.org/abs/2311.08993)

**PDF Link:** [https://arxiv.org/pdf/2311.08993](https://arxiv.org/pdf/2311.08993)

---

**Date:** 02 Feb 2024

**Title:** Soaring from 4K to 400K: Extending LLM's Context with Activation Beacon

**Abstract Link:** [https://arxiv.org/abs/2401.03462](https://arxiv.org/abs/2401.03462)

**PDF Link:** [https://arxiv.org/pdf/2401.03462](https://arxiv.org/pdf/2401.03462)

---

**Date:** 02 Oct 2023

**Title:** In-context Autoencoder for Context Compression in a Large Language Model

**Abstract Link:** [https://arxiv.org/abs/2307.06945](https://arxiv.org/abs/2307.06945)

**PDF Link:** [https://arxiv.org/pdf/2307.06945](https://arxiv.org/pdf/2307.06945)

---

**Date:** 26 Sep 2023

**Title:** Boosting In-Context Learning with Factual Knowledge

**Abstract Link:** [https://arxiv.org/abs/2309.14771](https://arxiv.org/abs/2309.14771)

**PDF Link:** [https://arxiv.org/pdf/2309.14771](https://arxiv.org/pdf/2309.14771)

---

**Date:** 05 Dec 2023

**Title:** LongLoRA: Efficient Fine-tuning of Long-Context Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2309.12307](https://arxiv.org/abs/2309.12307)

**PDF Link:** [https://arxiv.org/pdf/2309.12307](https://arxiv.org/pdf/2309.12307)

---

**Date:** 07 Jun 2023

**Title:** Enhancing In-Context Learning with Answer Feedback for Multi-Span  Question Answering

**Abstract Link:** [https://arxiv.org/abs/2306.04508](https://arxiv.org/abs/2306.04508)

**PDF Link:** [https://arxiv.org/pdf/2306.04508](https://arxiv.org/pdf/2306.04508)

---

**Date:** 30 Sep 2023

**Title:** Privacy-Preserving In-Context Learning for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2305.01639](https://arxiv.org/abs/2305.01639)

**PDF Link:** [https://arxiv.org/pdf/2305.01639](https://arxiv.org/pdf/2305.01639)

---

**Date:** 15 Jan 2024

**Title:** Flexibly Scaling Large Language Models Contexts Through Extensible  Tokenization

**Abstract Link:** [https://arxiv.org/abs/2401.07793](https://arxiv.org/abs/2401.07793)

**PDF Link:** [https://arxiv.org/pdf/2401.07793](https://arxiv.org/pdf/2401.07793)

---

**Date:** 21 May 2023

**Title:** Enhancing Few-shot Text-to-SQL Capabilities of Large Language Models: A  Study on Prompt Design Strategies

**Abstract Link:** [https://arxiv.org/abs/2305.12586](https://arxiv.org/abs/2305.12586)

**PDF Link:** [https://arxiv.org/pdf/2305.12586](https://arxiv.org/pdf/2305.12586)

---

**Date:** 23 Jan 2024

**Title:** Retrieval meets Long Context Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.03025](https://arxiv.org/abs/2310.03025)

**PDF Link:** [https://arxiv.org/pdf/2310.03025](https://arxiv.org/pdf/2310.03025)

---

**Date:** 22 Feb 2024

**Title:** E^2-LLM: Efficient and Extreme Length Extension of Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.06951](https://arxiv.org/abs/2401.06951)

**PDF Link:** [https://arxiv.org/pdf/2401.06951](https://arxiv.org/pdf/2401.06951)

---

**Date:** 30 Sep 2023

**Title:** Dynamic Demonstrations Controller for In-Context Learning

**Abstract Link:** [https://arxiv.org/abs/2310.00385](https://arxiv.org/abs/2310.00385)

**PDF Link:** [https://arxiv.org/pdf/2310.00385](https://arxiv.org/pdf/2310.00385)

---

**Date:** 13 Nov 2023

**Title:** In-context Learning Generalizes, But Not Always Robustly: The Case of  Syntax

**Abstract Link:** [https://arxiv.org/abs/2311.07811](https://arxiv.org/abs/2311.07811)

**PDF Link:** [https://arxiv.org/pdf/2311.07811](https://arxiv.org/pdf/2311.07811)

---

