LLM Safety Boundaries 🔒

### 🔎 LLM Safety Boundaries 🔒



- No sharing of personal information (address, phone number, etc.)
- No sharing of inappropriate content (sexual, violent, etc.)
- No sharing of content that discriminates against any person or group
- No sharing of content that encourages self-harm or suicide
- No sharing of content that promotes illegal activities
- No sharing of content that violates copyright laws
- No sharing of content that violates the terms of service of the platform
- No sharing of content that violates the privacy of others
- No sharing of content that is misleading or false
- No sharing of content that is intended to harass or bully others
- No sharing of content that is intended to cause harm or distress to others
- No sharing of content that is intended to incite violence or hatred
- No sharing of content that is intended to disrupt the community or the platform
- No sharing of content that is intended to manipulate or deceive others
- No sharing of content that is intended to exploit or take advantage of others
- No sharing of content that is intended to invade the privacy of others
- No sharing of content that is intended to intimidate or threaten others
- No sharing of content that is intended to impersonate or misrepresent oneself or others
- No sharing of content that is intended to violate the terms of service of the platform
- No sharing of content that is intended to violate the privacy of others
- No sharing of content that is intended to violate the rights of others
- No sharing of content that is intended to violate the law
- No sharing of content that is intended to violate the rules of the community
- No sharing of content that is intended to violate the values of the community
- No sharing of content that is intended to violate the trust of the community
- No sharing of content that is intended to violate the safety of the community
- No sharing of content that is intended to violate the integrity of the community
- No sharing of content that is intended to violate the respect of the community
- No sharing of content that is intended to violate the dignity of the community
- No sharing of content that is intended to violate the decency of the community
- No sharing of content that is intended to violate the harmony of the community
- No sharing of content that is intended to violate the peace of the community
- No sharing
# 🩺🔍 Search Results
### 17 Feb 2024 | [Open the Pandora's Box of LLMs: Jailbreaking LLMs through Representation  Engineering](https://arxiv.org/abs/2401.06824) | [⬇️](https://arxiv.org/pdf/2401.06824)
*Tianlong Li, Shihan Dou, Wenhao Liu, Muling Wu, Changze Lv, Xiaoqing  Zheng, Xuanjing Huang* 

  Jailbreaking techniques aim to probe the boundaries of safety in large
language models (LLMs) by inducing them to generate toxic responses to
malicious queries, a significant concern within the LLM community. While
existing jailbreaking methods primarily rely on prompt engineering, altering
inputs to evade LLM safety mechanisms, they suffer from low attack success
rates and significant time overheads, rendering them inflexible. To overcome
these limitations, we propose a novel jailbreaking approach, named Jailbreaking
LLMs through Representation Engineering (JRE). Our method requires only a small
number of query pairs to extract ``safety patterns'' that can be used to
circumvent the target model's defenses, achieving unprecedented jailbreaking
performance. Building upon these findings, we also introduce a novel defense
framework inspired by JRE principles, which demonstrates notable effectiveness.
Extensive experimentation confirms the superior performance of the JRE attacks
and the robustness of the JRE defense framework. We hope this study contributes
to advancing the understanding of model safety issues through the lens of
representation engineering.

---------------

### 02 Oct 2023 | [All Languages Matter: On the Multilingual Safety of Large Language  Models](https://arxiv.org/abs/2310.00905) | [⬇️](https://arxiv.org/pdf/2310.00905)
*Wenxuan Wang, Zhaopeng Tu, Chang Chen, Youliang Yuan, Jen-tse Huang,  Wenxiang Jiao, Michael R. Lyu* 

  Safety lies at the core of developing and deploying large language models
(LLMs). However, previous safety benchmarks only concern the safety in one
language, e.g. the majority language in the pretraining data such as English.
In this work, we build the first multilingual safety benchmark for LLMs,
XSafety, in response to the global deployment of LLMs in practice. XSafety
covers 14 kinds of commonly used safety issues across 10 languages that span
several language families. We utilize XSafety to empirically study the
multilingual safety for 4 widely-used LLMs, including both close-API and
open-source models. Experimental results show that all LLMs produce
significantly more unsafe responses for non-English queries than English ones,
indicating the necessity of developing safety alignment for non-English
languages. In addition, we propose several simple and effective prompting
methods to improve the multilingual safety of ChatGPT by evoking safety
knowledge and improving cross-lingual generalization of safety alignment. Our
prompting method can significantly reduce the ratio of unsafe responses from
19.1% to 9.7% for non-English queries. We release our data at
https://github.com/Jarviswang94/Multilingual_safety_benchmark.

---------------

### 13 Sep 2023 | [SafetyBench: Evaluating the Safety of Large Language Models with  Multiple Choice Questions](https://arxiv.org/abs/2309.07045) | [⬇️](https://arxiv.org/pdf/2309.07045)
*Zhexin Zhang, Leqi Lei, Lindong Wu, Rui Sun, Yongkang Huang, Chong  Long, Xiao Liu, Xuanyu Lei, Jie Tang, Minlie Huang* 

  With the rapid development of Large Language Models (LLMs), increasing
attention has been paid to their safety concerns. Consequently, evaluating the
safety of LLMs has become an essential task for facilitating the broad
applications of LLMs. Nevertheless, the absence of comprehensive safety
evaluation benchmarks poses a significant impediment to effectively assess and
enhance the safety of LLMs. In this work, we present SafetyBench, a
comprehensive benchmark for evaluating the safety of LLMs, which comprises
11,435 diverse multiple choice questions spanning across 7 distinct categories
of safety concerns. Notably, SafetyBench also incorporates both Chinese and
English data, facilitating the evaluation in both languages. Our extensive
tests over 25 popular Chinese and English LLMs in both zero-shot and few-shot
settings reveal a substantial performance advantage for GPT-4 over its
counterparts, and there is still significant room for improving the safety of
current LLMs. We believe SafetyBench will enable fast and comprehensive
evaluation of LLMs' safety, and foster the development of safer LLMs. Data and
evaluation guidelines are available at https://github.com/thu-coai/SafetyBench.
Submission entrance and leaderboard are available at
https://llmbench.ai/safety.

---------------

### 04 Mar 2024 | [SALAD-Bench: A Hierarchical and Comprehensive Safety Benchmark for Large  Language Models](https://arxiv.org/abs/2402.05044) | [⬇️](https://arxiv.org/pdf/2402.05044)
*Lijun Li, Bowen Dong, Ruohui Wang, Xuhao Hu, Wangmeng Zuo, Dahua Lin,  Yu Qiao, Jing Shao* 

  In the rapidly evolving landscape of Large Language Models (LLMs), ensuring
robust safety measures is paramount. To meet this crucial need, we propose
\emph{SALAD-Bench}, a safety benchmark specifically designed for evaluating
LLMs, attack, and defense methods. Distinguished by its breadth, SALAD-Bench
transcends conventional benchmarks through its large scale, rich diversity,
intricate taxonomy spanning three levels, and versatile
functionalities.SALAD-Bench is crafted with a meticulous array of questions,
from standard queries to complex ones enriched with attack, defense
modifications and multiple-choice. To effectively manage the inherent
complexity, we introduce an innovative evaluators: the LLM-based MD-Judge for
QA pairs with a particular focus on attack-enhanced queries, ensuring a
seamless, and reliable evaluation. Above components extend SALAD-Bench from
standard LLM safety evaluation to both LLM attack and defense methods
evaluation, ensuring the joint-purpose utility. Our extensive experiments shed
light on the resilience of LLMs against emerging threats and the efficacy of
contemporary defense tactics. Data and evaluator are released under
https://github.com/OpenSafetyLab/SALAD-BENCH.

---------------

### 09 Oct 2023 | [SC-Safety: A Multi-round Open-ended Question Adversarial Safety  Benchmark for Large Language Models in Chinese](https://arxiv.org/abs/2310.05818) | [⬇️](https://arxiv.org/pdf/2310.05818)
*Liang Xu, Kangkang Zhao, Lei Zhu, Hang Xue* 

  Large language models (LLMs), like ChatGPT and GPT-4, have demonstrated
remarkable abilities in natural language understanding and generation. However,
alongside their positive impact on our daily tasks, they can also produce
harmful content that negatively affects societal perceptions. To systematically
assess the safety of Chinese LLMs, we introduce SuperCLUE-Safety (SC-Safety) -
a multi-round adversarial benchmark with 4912 open-ended questions covering
more than 20 safety sub-dimensions. Adversarial human-model interactions and
conversations significantly increase the challenges compared to existing
methods. Experiments on 13 major LLMs supporting Chinese yield the following
insights: 1) Closed-source models outperform open-sourced ones in terms of
safety; 2) Models released from China demonstrate comparable safety levels to
LLMs like GPT-3.5-turbo; 3) Some smaller models with 6B-13B parameters can
compete effectively in terms of safety. By introducing SC-Safety, we aim to
promote collaborative efforts to create safer and more trustworthy LLMs. The
benchmark and findings provide guidance on model selection. Our benchmark can
be found at https://www.CLUEbenchmarks.com

---------------

### 27 Jan 2024 | [Low-Resource Languages Jailbreak GPT-4](https://arxiv.org/abs/2310.02446) | [⬇️](https://arxiv.org/pdf/2310.02446)
*Zheng-Xin Yong, Cristina Menghini and Stephen H. Bach* 

  AI safety training and red-teaming of large language models (LLMs) are
measures to mitigate the generation of unsafe content. Our work exposes the
inherent cross-lingual vulnerability of these safety mechanisms, resulting from
the linguistic inequality of safety training data, by successfully
circumventing GPT-4's safeguard through translating unsafe English inputs into
low-resource languages. On the AdvBenchmark, GPT-4 engages with the unsafe
translated inputs and provides actionable items that can get the users towards
their harmful goals 79% of the time, which is on par with or even surpassing
state-of-the-art jailbreaking attacks. Other high-/mid-resource languages have
significantly lower attack success rate, which suggests that the cross-lingual
vulnerability mainly applies to low-resource languages. Previously, limited
training on low-resource languages primarily affects speakers of those
languages, causing technological disparities. However, our work highlights a
crucial shift: this deficiency now poses a risk to all LLMs users. Publicly
available translation APIs enable anyone to exploit LLMs' safety
vulnerabilities. Therefore, our work calls for a more holistic red-teaming
efforts to develop robust multilingual safeguards with wide language coverage.

---------------

### 03 Dec 2023 | [Testing Language Model Agents Safely in the Wild](https://arxiv.org/abs/2311.10538) | [⬇️](https://arxiv.org/pdf/2311.10538)
*Silen Naihin, David Atkinson, Marc Green, Merwane Hamadi, Craig Swift,  Douglas Schonholtz, Adam Tauman Kalai, David Bau* 

  A prerequisite for safe autonomy-in-the-wild is safe testing-in-the-wild. Yet
real-world autonomous tests face several unique safety challenges, both due to
the possibility of causing harm during a test, as well as the risk of
encountering new unsafe agent behavior through interactions with real-world and
potentially malicious actors. We propose a framework for conducting safe
autonomous agent tests on the open internet: agent actions are audited by a
context-sensitive monitor that enforces a stringent safety boundary to stop an
unsafe test, with suspect behavior ranked and logged to be examined by humans.
We design a basic safety monitor (AgentMonitor) that is flexible enough to
monitor existing LLM agents, and, using an adversarial simulated agent, we
measure its ability to identify and stop unsafe situations. Then we apply the
AgentMonitor on a battery of real-world tests of AutoGPT, and we identify
several limitations and challenges that will face the creation of safe
in-the-wild tests as autonomous agents grow more capable.

---------------

### 26 Feb 2024 | [ShieldLM: Empowering LLMs as Aligned, Customizable and Explainable  Safety Detectors](https://arxiv.org/abs/2402.16444) | [⬇️](https://arxiv.org/pdf/2402.16444)
*Zhexin Zhang, Yida Lu, Jingyuan Ma, Di Zhang, Rui Li, Pei Ke, Hao Sun,  Lei Sha, Zhifang Sui, Hongning Wang, Minlie Huang* 

  The safety of Large Language Models (LLMs) has gained increasing attention in
recent years, but there still lacks a comprehensive approach for detecting
safety issues within LLMs' responses in an aligned, customizable and
explainable manner. In this paper, we propose ShieldLM, an LLM-based safety
detector, which aligns with general human safety standards, supports
customizable detection rules, and provides explanations for its decisions. To
train ShieldLM, we compile a large bilingual dataset comprising 14,387
query-response pairs, annotating the safety of responses based on various
safety standards. Through extensive experiments, we demonstrate that ShieldLM
surpasses strong baselines across four test sets, showcasing remarkable
customizability and explainability. Besides performing well on standard
detection datasets, ShieldLM has also been shown to be effective in real-world
situations as a safety evaluator for advanced LLMs. We release ShieldLM at
\url{https://github.com/thu-coai/ShieldLM} to support accurate and explainable
safety detection under various safety standards, contributing to the ongoing
efforts to enhance the safety of LLMs.

---------------

### 25 Aug 2023 | [Large Language Models in Analyzing Crash Narratives -- A Comparative  Study of ChatGPT, BARD and GPT-4](https://arxiv.org/abs/2308.13563) | [⬇️](https://arxiv.org/pdf/2308.13563)
*Maroa Mumtarin, Md Samiullah Chowdhury, Jonathan Wood* 

  In traffic safety research, extracting information from crash narratives
using text analysis is a common practice. With recent advancements of large
language models (LLM), it would be useful to know how the popular LLM
interfaces perform in classifying or extracting information from crash
narratives. To explore this, our study has used the three most popular publicly
available LLM interfaces- ChatGPT, BARD and GPT4. This study investigated their
usefulness and boundaries in extracting information and answering queries
related to accidents from 100 crash narratives from Iowa and Kansas. During the
investigation, their capabilities and limitations were assessed and their
responses to the queries were compared. Five questions were asked related to
the narratives: 1) Who is at-fault? 2) What is the manner of collision? 3) Has
the crash occurred in a work-zone? 4) Did the crash involve pedestrians? and 5)
What are the sequence of harmful events in the crash? For questions 1 through
4, the overall similarity among the LLMs were 70%, 35%, 96% and 89%,
respectively. The similarities were higher while answering direct questions
requiring binary responses and significantly lower for complex questions. To
compare the responses to question 5, network diagram and centrality measures
were analyzed. The network diagram from the three LLMs were not always similar
although they sometimes have the same influencing events with high in-degree,
out-degree and betweenness centrality. This study suggests using multiple
models to extract viable information from narratives. Also, caution must be
practiced while using these interfaces to obtain crucial safety related
information.

---------------

### 14 Nov 2023 | [Fake Alignment: Are LLMs Really Aligned Well?](https://arxiv.org/abs/2311.05915) | [⬇️](https://arxiv.org/pdf/2311.05915)
*Yixu Wang, Yan Teng, Kexin Huang, Chengqi Lyu, Songyang Zhang, Wenwei  Zhang, Xingjun Ma, Yu-Gang Jiang, Yu Qiao, Yingchun Wang* 

  The growing awareness of safety concerns in large language models (LLMs) has
sparked considerable interest in the evaluation of safety within current
research endeavors. This study investigates an interesting issue pertaining to
the evaluation of LLMs, namely the substantial discrepancy in performance
between multiple-choice questions and open-ended questions. Inspired by
research on jailbreak attack patterns, we argue this is caused by mismatched
generalization. That is, the LLM does not have a comprehensive understanding of
the complex concept of safety. Instead, it only remembers what to answer for
open-ended safety questions, which makes it unable to solve other forms of
safety tests. We refer to this phenomenon as fake alignment and construct a
comparative benchmark to empirically verify its existence in LLMs. Such fake
alignment renders previous evaluation protocols unreliable. To address this, we
introduce the Fake alIgNment Evaluation (FINE) framework and two novel
metrics--Consistency Score (CS) and Consistent Safety Score (CSS), which
jointly assess two complementary forms of evaluation to quantify fake alignment
and obtain corrected performance estimates. Applying FINE to 14 widely-used
LLMs reveals several models with purported safety are poorly aligned in
practice. Our work highlights potential limitations in prevailing alignment
methodologies.

---------------

### 20 Apr 2023 | [Safety Assessment of Chinese Large Language Models](https://arxiv.org/abs/2304.10436) | [⬇️](https://arxiv.org/pdf/2304.10436)
*Hao Sun, Zhexin Zhang, Jiawen Deng, Jiale Cheng, Minlie Huang* 

  With the rapid popularity of large language models such as ChatGPT and GPT-4,
a growing amount of attention is paid to their safety concerns. These models
may generate insulting and discriminatory content, reflect incorrect social
values, and may be used for malicious purposes such as fraud and dissemination
of misleading information. Evaluating and enhancing their safety is
particularly essential for the wide application of large language models
(LLMs). To further promote the safe deployment of LLMs, we develop a Chinese
LLM safety assessment benchmark. Our benchmark explores the comprehensive
safety performance of LLMs from two perspectives: 8 kinds of typical safety
scenarios and 6 types of more challenging instruction attacks. Our benchmark is
based on a straightforward process in which it provides the test prompts and
evaluates the safety of the generated responses from the evaluated model. In
evaluation, we utilize the LLM's strong evaluation ability and develop it as a
safety evaluator by prompting. On top of this benchmark, we conduct safety
assessments and analyze 15 LLMs including the OpenAI GPT series and other
well-known Chinese LLMs, where we observe some interesting findings. For
example, we find that instruction attacks are more likely to expose safety
issues of all LLMs. Moreover, to promote the development and deployment of
safe, responsible, and ethical AI, we publicly release SafetyPrompts including
100k augmented prompts and responses by LLMs.

---------------

### 27 Feb 2024 | [Speak Out of Turn: Safety Vulnerability of Large Language Models in  Multi-turn Dialogue](https://arxiv.org/abs/2402.17262) | [⬇️](https://arxiv.org/pdf/2402.17262)
*Zhenhong Zhou, Jiuyang Xiang, Haopeng Chen, Quan Liu, Zherui Li, Sen  Su* 

  Large Language Models (LLMs) have been demonstrated to generate illegal or
unethical responses, particularly when subjected to "jailbreak." Research on
jailbreak has highlighted the safety issues of LLMs. However, prior studies
have predominantly focused on single-turn dialogue, ignoring the potential
complexities and risks presented by multi-turn dialogue, a crucial mode through
which humans derive information from LLMs. In this paper, we argue that humans
could exploit multi-turn dialogue to induce LLMs into generating harmful
information. LLMs may not intend to reject cautionary or borderline unsafe
queries, even if each turn is closely served for one malicious purpose in a
multi-turn dialogue. Therefore, by decomposing an unsafe query into several
sub-queries for multi-turn dialogue, we induced LLMs to answer harmful
sub-questions incrementally, culminating in an overall harmful response. Our
experiments, conducted across a wide range of LLMs, indicate current
inadequacies in the safety mechanisms of LLMs in multi-turn dialogue. Our
findings expose vulnerabilities of LLMs in complex scenarios involving
multi-turn dialogue, presenting new challenges for the safety of LLMs.

---------------

### 12 Aug 2023 | [GPT-4 Is Too Smart To Be Safe: Stealthy Chat with LLMs via Cipher](https://arxiv.org/abs/2308.06463) | [⬇️](https://arxiv.org/pdf/2308.06463)
*Youliang Yuan, Wenxiang Jiao, Wenxuan Wang, Jen-tse Huang, Pinjia He,  Shuming Shi and Zhaopeng Tu* 

  Safety lies at the core of the development of Large Language Models (LLMs).
There is ample work on aligning LLMs with human ethics and preferences,
including data filtering in pretraining, supervised fine-tuning, reinforcement
learning from human feedback, and red teaming, etc. In this study, we discover
that chat in cipher can bypass the safety alignment techniques of LLMs, which
are mainly conducted in natural languages. We propose a novel framework
CipherChat to systematically examine the generalizability of safety alignment
to non-natural languages -- ciphers. CipherChat enables humans to chat with
LLMs through cipher prompts topped with system role descriptions and few-shot
enciphered demonstrations. We use CipherChat to assess state-of-the-art LLMs,
including ChatGPT and GPT-4 for different representative human ciphers across
11 safety domains in both English and Chinese. Experimental results show that
certain ciphers succeed almost 100% of the time to bypass the safety alignment
of GPT-4 in several safety domains, demonstrating the necessity of developing
safety alignment for non-natural languages. Notably, we identify that LLMs seem
to have a ''secret cipher'', and propose a novel SelfCipher that uses only role
play and several demonstrations in natural language to evoke this capability.
SelfCipher surprisingly outperforms existing human ciphers in almost all cases.
Our code and data will be released at https://github.com/RobustNLP/CipherChat.

---------------

### 24 Oct 2023 | [Self-Guard: Empower the LLM to Safeguard Itself](https://arxiv.org/abs/2310.15851) | [⬇️](https://arxiv.org/pdf/2310.15851)
*Zezhong Wang, Fangkai Yang, Lu Wang, Pu Zhao, Hongru Wang, Liang Chen,  Qingwei Lin, Kam-Fai Wong* 

  The jailbreak attack can bypass the safety measures of a Large Language Model
(LLM), generating harmful content. This misuse of LLM has led to negative
societal consequences. Currently, there are two main approaches to address
jailbreak attacks: safety training and safeguards. Safety training focuses on
further training LLM to enhance its safety. On the other hand, safeguards
involve implementing external models or filters to prevent harmful outputs.
However, safety training has constraints in its ability to adapt to new attack
types and often leads to a drop in model performance. Safeguards have proven to
be of limited help. To tackle these issues, we propose a novel approach called
Self-Guard, which combines the strengths of both safety methods. Self-Guard
includes two stages. In the first stage, we enhance the model's ability to
assess harmful content, and in the second stage, we instruct the model to
consistently perform harmful content detection on its own responses. The
experiment has demonstrated that Self-Guard is robust against jailbreak
attacks. In the bad case analysis, we find that LLM occasionally provides
harmless responses to harmful queries. Additionally, we evaluated the general
capabilities of the LLM before and after safety training, providing evidence
that Self-Guard does not result in the LLM's performance degradation. In
sensitivity tests, Self-Guard not only avoids inducing over-sensitivity in LLM
but also can even mitigate this issue.

---------------

### 30 Dec 2023 | [The Art of Defending: A Systematic Evaluation and Analysis of LLM  Defense Strategies on Safety and Over-Defensiveness](https://arxiv.org/abs/2401.00287) | [⬇️](https://arxiv.org/pdf/2401.00287)
*Neeraj Varshney, Pavel Dolin, Agastya Seth, Chitta Baral* 

  As Large Language Models (LLMs) play an increasingly pivotal role in natural
language processing applications, their safety concerns become critical areas
of NLP research. This paper presents Safety and Over-Defensiveness Evaluation
(SODE) benchmark: a collection of diverse safe and unsafe prompts with
carefully designed evaluation methods that facilitate systematic evaluation,
comparison, and analysis over 'safety' and 'over-defensiveness.' With SODE, we
study a variety of LLM defense strategies over multiple state-of-the-art LLMs,
which reveals several interesting and important findings, such as (a) the
widely popular 'self-checking' techniques indeed improve the safety against
unsafe inputs, but this comes at the cost of extreme over-defensiveness on the
safe inputs, (b) providing a safety instruction along with in-context exemplars
(of both safe and unsafe inputs) consistently improves safety and also
mitigates undue over-defensiveness of the models, (c) providing contextual
knowledge easily breaks the safety guardrails and makes the models more
vulnerable to generating unsafe responses. Overall, our work reveals numerous
such critical findings that we believe will pave the way and facilitate further
research in improving the safety of LLMs.

---------------

### 18 Feb 2024 | [R-Judge: Benchmarking Safety Risk Awareness for LLM Agents](https://arxiv.org/abs/2401.10019) | [⬇️](https://arxiv.org/pdf/2401.10019)
*Tongxin Yuan, Zhiwei He, Lingzhong Dong, Yiming Wang, Ruijie Zhao,  Tian Xia, Lizhen Xu, Binglin Zhou, Fangqi Li, Zhuosheng Zhang, Rui Wang,  Gongshen Liu* 

  Large language models (LLMs) have exhibited great potential in autonomously
completing tasks across real-world applications. Despite this, these LLM agents
introduce unexpected safety risks when operating in interactive environments.
Instead of centering on LLM-generated content safety in most prior studies,
this work addresses the imperative need for benchmarking the behavioral safety
of LLM agents within diverse environments. We introduce R-Judge, a benchmark
crafted to evaluate the proficiency of LLMs in judging and identifying safety
risks given agent interaction records. R-Judge comprises 162 records of
multi-turn agent interaction, encompassing 27 key risk scenarios among 7
application categories and 10 risk types. It incorporates human consensus on
safety with annotated safety labels and high-quality risk descriptions.
Evaluation of 9 LLMs on R-Judge shows considerable room for enhancing the risk
awareness of LLMs: The best-performing model, GPT-4, achieves 72.52% in
contrast to the human score of 89.07%, while all other models score less than
the random. Moreover, further experiments demonstrate that leveraging risk
descriptions as environment feedback achieves substantial performance gains.
With case studies, we reveal that correlated to parameter amount, risk
awareness in open agent scenarios is a multi-dimensional capability involving
knowledge and reasoning, thus challenging for current LLMs. R-Judge is publicly
available at https://github.com/Lordog/R-Judge.

---------------

### 04 Mar 2024 | [On Prompt-Driven Safeguarding for Large Language Models](https://arxiv.org/abs/2401.18018) | [⬇️](https://arxiv.org/pdf/2401.18018)
*Chujie Zheng, Fan Yin, Hao Zhou, Fandong Meng, Jie Zhou, Kai-Wei  Chang, Minlie Huang, Nanyun Peng* 

  Prepending model inputs with safety prompts is a common practice for
safeguarding large language models (LLMs) from complying with queries that
contain harmful intents. However, the working mechanisms of safety prompts have
not been revealed yet, which hinders the potential for automatically optimizing
them to improve LLM safety. To this end, we investigate the impact of safety
prompts from the perspective of model representations. We find that in models'
representation space, harmful and harmless queries can be largely
distinguished, but this is not noticeably enhanced by safety prompts. Instead,
the queries' representations are moved by safety prompts in similar directions
where models become more prone to refusal (i.e., refusing to provide
assistance) even when the queries are harmless. Inspired by these findings, we
propose a method called DRO (Directed Representation Optimization) for
automatic safety prompt optimization. It treats safety prompts as continuous,
trainable embeddings and learns to move the representations of harmful/harmless
queries along/opposite the direction in which the model's refusal probability
increases. Experiments with eight LLMs on out-of-domain benchmarks demonstrate
that DRO remarkably improves the safeguarding performance of human-crafted
safety prompts and outperforms strong baselines, without compromising the
general model capability.

---------------

### 27 Aug 2023 | [A Survey of Safety and Trustworthiness of Large Language Models through  the Lens of Verification and Validation](https://arxiv.org/abs/2305.11391) | [⬇️](https://arxiv.org/pdf/2305.11391)
*Xiaowei Huang, Wenjie Ruan, Wei Huang, Gaojie Jin, Yi Dong, Changshun  Wu, Saddek Bensalem, Ronghui Mu, Yi Qi, Xingyu Zhao, Kaiwen Cai, Yanghao  Zhang, Sihao Wu, Peipei Xu, Dengyu Wu, Andre Freitas, Mustafa A. Mustafa* 

  Large Language Models (LLMs) have exploded a new heatwave of AI for their
ability to engage end-users in human-level conversations with detailed and
articulate answers across many knowledge domains. In response to their fast
adoption in many industrial applications, this survey concerns their safety and
trustworthiness. First, we review known vulnerabilities and limitations of the
LLMs, categorising them into inherent issues, attacks, and unintended bugs.
Then, we consider if and how the Verification and Validation (V&V) techniques,
which have been widely developed for traditional software and deep learning
models such as convolutional neural networks as independent processes to check
the alignment of their implementations against the specifications, can be
integrated and further extended throughout the lifecycle of the LLMs to provide
rigorous analysis to the safety and trustworthiness of LLMs and their
applications. Specifically, we consider four complementary techniques:
falsification and evaluation, verification, runtime monitoring, and regulations
and ethical use. In total, 370+ references are considered to support the quick
understanding of the safety and trustworthiness issues from the perspective of
V&V. While intensive research has been conducted to identify the safety and
trustworthiness issues, rigorous yet practical methods are called for to ensure
the alignment of LLMs with safety and trustworthiness requirements.

---------------

### 29 Nov 2023 | [Query-Relevant Images Jailbreak Large Multi-Modal Models](https://arxiv.org/abs/2311.17600) | [⬇️](https://arxiv.org/pdf/2311.17600)
*Xin Liu, Yichen Zhu, Yunshi Lan, Chao Yang, Yu Qiao* 

  Warning: This paper contains examples of harmful language and images, and
reader discretion is recommended. The security concerns surrounding Large
Language Models (LLMs) have been extensively explored, yet the safety of Large
Multi-Modal Models (LMMs) remains understudied. In our study, we present a
novel visual prompt attack that exploits query-relevant images to jailbreak the
open-source LMMs. Our method creates a composite image from one image generated
by diffusion models and another that displays the text as typography, based on
keywords extracted from a malicious query. We show LLMs can be easily attacked
by our approach, even if the employed Large Language Models are safely aligned.
To evaluate the extent of this vulnerability in open-source LMMs, we have
compiled a substantial dataset encompassing 13 scenarios with a total of 5,040
text-image pairs, using our presented attack technique. Our evaluation of 12
cutting-edge LMMs using this dataset shows the vulnerability of existing
multi-modal models on adversarial attacks. This finding underscores the need
for a concerted effort to strengthen and enhance the safety measures of
open-source LMMs against potential malicious exploits. The resource is
available at \href{this https URL}{https://github.com/isXinLiu/MM-SafetyBench}.

---------------

### 07 Dec 2023 | [Purple Llama CyberSecEval: A Secure Coding Benchmark for Language Models](https://arxiv.org/abs/2312.04724) | [⬇️](https://arxiv.org/pdf/2312.04724)
*Manish Bhatt, Sahana Chennabasappa, Cyrus Nikolaidis, Shengye Wan,  Ivan Evtimov, Dominik Gabi, Daniel Song, Faizan Ahmad, Cornelius Aschermann,  Lorenzo Fontana, Sasha Frolov, Ravi Prakash Giri, Dhaval Kapil, Yiannis  Kozyrakis, David LeBlanc, James Milazzo, Aleksandar Straumann, Gabriel  Synnaeve, Varun Vontimitta, Spencer Whitman, Joshua Saxe* 

  This paper presents CyberSecEval, a comprehensive benchmark developed to help
bolster the cybersecurity of Large Language Models (LLMs) employed as coding
assistants. As what we believe to be the most extensive unified cybersecurity
safety benchmark to date, CyberSecEval provides a thorough evaluation of LLMs
in two crucial security domains: their propensity to generate insecure code and
their level of compliance when asked to assist in cyberattacks. Through a case
study involving seven models from the Llama 2, Code Llama, and OpenAI GPT large
language model families, CyberSecEval effectively pinpointed key cybersecurity
risks. More importantly, it offered practical insights for refining these
models. A significant observation from the study was the tendency of more
advanced models to suggest insecure code, highlighting the critical need for
integrating security considerations in the development of sophisticated LLMs.
CyberSecEval, with its automated test case generation and evaluation pipeline
covers a broad scope and equips LLM designers and researchers with a tool to
broadly measure and enhance the cybersecurity safety properties of LLMs,
contributing to the development of more secure AI systems.

---------------
**Date:** 17 Feb 2024

**Title:** Open the Pandora's Box of LLMs: Jailbreaking LLMs through Representation  Engineering

**Abstract Link:** [https://arxiv.org/abs/2401.06824](https://arxiv.org/abs/2401.06824)

**PDF Link:** [https://arxiv.org/pdf/2401.06824](https://arxiv.org/pdf/2401.06824)

---

**Date:** 02 Oct 2023

**Title:** All Languages Matter: On the Multilingual Safety of Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2310.00905](https://arxiv.org/abs/2310.00905)

**PDF Link:** [https://arxiv.org/pdf/2310.00905](https://arxiv.org/pdf/2310.00905)

---

**Date:** 13 Sep 2023

**Title:** SafetyBench: Evaluating the Safety of Large Language Models with  Multiple Choice Questions

**Abstract Link:** [https://arxiv.org/abs/2309.07045](https://arxiv.org/abs/2309.07045)

**PDF Link:** [https://arxiv.org/pdf/2309.07045](https://arxiv.org/pdf/2309.07045)

---

**Date:** 04 Mar 2024

**Title:** SALAD-Bench: A Hierarchical and Comprehensive Safety Benchmark for Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.05044](https://arxiv.org/abs/2402.05044)

**PDF Link:** [https://arxiv.org/pdf/2402.05044](https://arxiv.org/pdf/2402.05044)

---

**Date:** 09 Oct 2023

**Title:** SC-Safety: A Multi-round Open-ended Question Adversarial Safety  Benchmark for Large Language Models in Chinese

**Abstract Link:** [https://arxiv.org/abs/2310.05818](https://arxiv.org/abs/2310.05818)

**PDF Link:** [https://arxiv.org/pdf/2310.05818](https://arxiv.org/pdf/2310.05818)

---

**Date:** 27 Jan 2024

**Title:** Low-Resource Languages Jailbreak GPT-4

**Abstract Link:** [https://arxiv.org/abs/2310.02446](https://arxiv.org/abs/2310.02446)

**PDF Link:** [https://arxiv.org/pdf/2310.02446](https://arxiv.org/pdf/2310.02446)

---

**Date:** 03 Dec 2023

**Title:** Testing Language Model Agents Safely in the Wild

**Abstract Link:** [https://arxiv.org/abs/2311.10538](https://arxiv.org/abs/2311.10538)

**PDF Link:** [https://arxiv.org/pdf/2311.10538](https://arxiv.org/pdf/2311.10538)

---

**Date:** 26 Feb 2024

**Title:** ShieldLM: Empowering LLMs as Aligned, Customizable and Explainable  Safety Detectors

**Abstract Link:** [https://arxiv.org/abs/2402.16444](https://arxiv.org/abs/2402.16444)

**PDF Link:** [https://arxiv.org/pdf/2402.16444](https://arxiv.org/pdf/2402.16444)

---

**Date:** 25 Aug 2023

**Title:** Large Language Models in Analyzing Crash Narratives -- A Comparative  Study of ChatGPT, BARD and GPT-4

**Abstract Link:** [https://arxiv.org/abs/2308.13563](https://arxiv.org/abs/2308.13563)

**PDF Link:** [https://arxiv.org/pdf/2308.13563](https://arxiv.org/pdf/2308.13563)

---

**Date:** 14 Nov 2023

**Title:** Fake Alignment: Are LLMs Really Aligned Well?

**Abstract Link:** [https://arxiv.org/abs/2311.05915](https://arxiv.org/abs/2311.05915)

**PDF Link:** [https://arxiv.org/pdf/2311.05915](https://arxiv.org/pdf/2311.05915)

---

**Date:** 20 Apr 2023

**Title:** Safety Assessment of Chinese Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2304.10436](https://arxiv.org/abs/2304.10436)

**PDF Link:** [https://arxiv.org/pdf/2304.10436](https://arxiv.org/pdf/2304.10436)

---

**Date:** 27 Feb 2024

**Title:** Speak Out of Turn: Safety Vulnerability of Large Language Models in  Multi-turn Dialogue

**Abstract Link:** [https://arxiv.org/abs/2402.17262](https://arxiv.org/abs/2402.17262)

**PDF Link:** [https://arxiv.org/pdf/2402.17262](https://arxiv.org/pdf/2402.17262)

---

**Date:** 12 Aug 2023

**Title:** GPT-4 Is Too Smart To Be Safe: Stealthy Chat with LLMs via Cipher

**Abstract Link:** [https://arxiv.org/abs/2308.06463](https://arxiv.org/abs/2308.06463)

**PDF Link:** [https://arxiv.org/pdf/2308.06463](https://arxiv.org/pdf/2308.06463)

---

**Date:** 24 Oct 2023

**Title:** Self-Guard: Empower the LLM to Safeguard Itself

**Abstract Link:** [https://arxiv.org/abs/2310.15851](https://arxiv.org/abs/2310.15851)

**PDF Link:** [https://arxiv.org/pdf/2310.15851](https://arxiv.org/pdf/2310.15851)

---

**Date:** 30 Dec 2023

**Title:** The Art of Defending: A Systematic Evaluation and Analysis of LLM  Defense Strategies on Safety and Over-Defensiveness

**Abstract Link:** [https://arxiv.org/abs/2401.00287](https://arxiv.org/abs/2401.00287)

**PDF Link:** [https://arxiv.org/pdf/2401.00287](https://arxiv.org/pdf/2401.00287)

---

**Date:** 18 Feb 2024

**Title:** R-Judge: Benchmarking Safety Risk Awareness for LLM Agents

**Abstract Link:** [https://arxiv.org/abs/2401.10019](https://arxiv.org/abs/2401.10019)

**PDF Link:** [https://arxiv.org/pdf/2401.10019](https://arxiv.org/pdf/2401.10019)

---

**Date:** 04 Mar 2024

**Title:** On Prompt-Driven Safeguarding for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.18018](https://arxiv.org/abs/2401.18018)

**PDF Link:** [https://arxiv.org/pdf/2401.18018](https://arxiv.org/pdf/2401.18018)

---

**Date:** 27 Aug 2023

**Title:** A Survey of Safety and Trustworthiness of Large Language Models through  the Lens of Verification and Validation

**Abstract Link:** [https://arxiv.org/abs/2305.11391](https://arxiv.org/abs/2305.11391)

**PDF Link:** [https://arxiv.org/pdf/2305.11391](https://arxiv.org/pdf/2305.11391)

---

**Date:** 29 Nov 2023

**Title:** Query-Relevant Images Jailbreak Large Multi-Modal Models

**Abstract Link:** [https://arxiv.org/abs/2311.17600](https://arxiv.org/abs/2311.17600)

**PDF Link:** [https://arxiv.org/pdf/2311.17600](https://arxiv.org/pdf/2311.17600)

---

**Date:** 07 Dec 2023

**Title:** Purple Llama CyberSecEval: A Secure Coding Benchmark for Language Models

**Abstract Link:** [https://arxiv.org/abs/2312.04724](https://arxiv.org/abs/2312.04724)

**PDF Link:** [https://arxiv.org/pdf/2312.04724](https://arxiv.org/pdf/2312.04724)

---

