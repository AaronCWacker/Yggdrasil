Neural Activation Patterns 🌊

### 🔎 Neural Activation Patterns 🌊


================================

This repository contains the code and data for the paper:

> **Neural Activation Patterns in the Human Brain Reveal the Structure of Conceptual Knowledge**
>
> *Jonas K. Kaiser, Anna C. Nobre, and Kai-Min Chang*
>
> *Neuron, 2019*

The code is written in Python 3 and uses the [nilearn](http://nilearn.github.io/) library for fMRI data analysis.

The data is stored in the [OpenNeuro](https://openneuro.org/) database and can be downloaded using the [OpenfMRI](https://openfmri.org/) interface.


























































































































































































































































































































































# 🩺🔍 Search Results
### 14 Jul 2020 | [Plateau Phenomenon in Gradient Descent Training of ReLU networks:  Explanation, Quantification and Avoidance](https://arxiv.org/abs/2007.07213) | [⬇️](https://arxiv.org/pdf/2007.07213)
*Mark Ainsworth and Yeonjong Shin* 

  The ability of neural networks to provide `best in class' approximation
across a wide range of applications is well-documented. Nevertheless, the
powerful expressivity of neural networks comes to naught if one is unable to
effectively train (choose) the parameters defining the network. In general,
neural networks are trained by gradient descent type optimization methods, or a
stochastic variant thereof. In practice, such methods result in the loss
function decreases rapidly at the beginning of training but then, after a
relatively small number of steps, significantly slow down. The loss may even
appear to stagnate over the period of a large number of epochs, only to then
suddenly start to decrease fast again for no apparent reason. This so-called
plateau phenomenon manifests itself in many learning tasks.
  The present work aims to identify and quantify the root causes of plateau
phenomenon. No assumptions are made on the number of neurons relative to the
number of training data, and our results hold for both the lazy and adaptive
regimes. The main findings are: plateaux correspond to periods during which
activation patterns remain constant, where activation pattern refers to the
number of data points that activate a given neuron; quantification of
convergence of the gradient flow dynamics; and, characterization of stationary
points in terms solutions of local least squares regression lines over subsets
of the training data. Based on these conclusions, we propose a new iterative
training method, the Active Neuron Least Squares (ANLS), characterised by the
explicit adjustment of the activation pattern at each step, which is designed
to enable a quick exit from a plateau. Illustrative numerical examples are
included throughout.

---------------

### 08 Feb 2024 | [Mildly Overparameterized ReLU Networks Have a Favorable Loss Landscape](https://arxiv.org/abs/2305.19510) | [⬇️](https://arxiv.org/pdf/2305.19510)
*Kedar Karhadkar, Michael Murray, Hanna Tseran, Guido Mont\'ufar* 

  We study the loss landscape of both shallow and deep, mildly
overparameterized ReLU neural networks on a generic finite input dataset for
the squared error loss. We show both by count and volume that most activation
patterns correspond to parameter regions with no bad local minima. Furthermore,
for one-dimensional input data, we show most activation regions realizable by
the network contain a high dimensional set of global minima and no bad local
minima. We experimentally confirm these results by finding a phase transition
from most regions having full rank Jacobian to many regions having deficient
rank depending on the amount of overparameterization.

---------------

### 19 Sep 2018 | [Runtime Monitoring Neuron Activation Patterns](https://arxiv.org/abs/1809.06573) | [⬇️](https://arxiv.org/pdf/1809.06573)
*Chih-Hong Cheng, Georg N\"uhrenberg, Hirotoshi Yasuoka* 

  For using neural networks in safety critical domains, it is important to know
if a decision made by a neural network is supported by prior similarities in
training. We propose runtime neuron activation pattern monitoring - after the
standard training process, one creates a monitor by feeding the training data
to the network again in order to store the neuron activation patterns in
abstract form. In operation, a classification decision over an input is further
supplemented by examining if a pattern similar (measured by Hamming distance)
to the generated pattern is contained in the monitor. If the monitor does not
contain any pattern similar to the generated pattern, it raises a warning that
the decision is not based on the training data. Our experiments show that, by
adjusting the similarity-threshold for activation patterns, the monitors can
report a significant portion of misclassfications to be not supported by
training with a small false-positive rate, when evaluated on a test set.

---------------

### 14 Jan 2021 | [Neural networks behave as hash encoders: An empirical study](https://arxiv.org/abs/2101.05490) | [⬇️](https://arxiv.org/pdf/2101.05490)
*Fengxiang He, Shiye Lei, Jianmin Ji, Dacheng Tao* 

  The input space of a neural network with ReLU-like activations is partitioned
into multiple linear regions, each corresponding to a specific activation
pattern of the included ReLU-like activations. We demonstrate that this
partition exhibits the following encoding properties across a variety of deep
learning models: (1) {\it determinism}: almost every linear region contains at
most one training example. We can therefore represent almost every training
example by a unique activation pattern, which is parameterized by a {\it neural
code}; and (2) {\it categorization}: according to the neural code, simple
algorithms, such as $K$-Means, $K$-NN, and logistic regression, can achieve
fairly good performance on both training and test data. These encoding
properties surprisingly suggest that {\it normal neural networks well-trained
for classification behave as hash encoders without any extra efforts.} In
addition, the encoding properties exhibit variability in different scenarios.
{Further experiments demonstrate that {\it model size}, {\it training time},
{\it training sample size}, {\it regularization}, and {\it label noise}
contribute in shaping the encoding properties, while the impacts of the first
three are dominant.} We then define an {\it activation hash phase chart} to
represent the space expanded by {model size}, training time, training sample
size, and the encoding properties, which is divided into three canonical
regions: {\it under-expressive regime}, {\it critically-expressive regime}, and
{\it sufficiently-expressive regime}. The source code package is available at
\url{https://github.com/LeavesLei/activation-code}.

---------------

### 05 Jul 2019 | [Prior Activation Distribution (PAD): A Versatile Representation to  Utilize DNN Hidden Units](https://arxiv.org/abs/1907.02711) | [⬇️](https://arxiv.org/pdf/1907.02711)
*Lakmal Meegahapola, Vengateswaran Subramaniam, Lance Kaplan, Archan  Misra* 

  In this paper, we introduce the concept of Prior Activation Distribution
(PAD) as a versatile and general technique to capture the typical activation
patterns of hidden layer units of a Deep Neural Network used for classification
tasks. We show that the combined neural activations of such a hidden layer have
class-specific distributional properties, and then define multiple statistical
measures to compute how far a test sample's activations deviate from such
distributions. Using a variety of benchmark datasets (including MNIST, CIFAR10,
Fashion-MNIST & notMNIST), we show how such PAD-based measures can be used,
independent of any training technique, to (a) derive fine-grained uncertainty
estimates for inferences; (b) provide inferencing accuracy competitive with
alternatives that require execution of the full pipeline, and (c) reliably
isolate out-of-distribution test samples.

---------------

### 10 Jan 2016 | [Identifying Stable Patterns over Time for Emotion Recognition from EEG](https://arxiv.org/abs/1601.02197) | [⬇️](https://arxiv.org/pdf/1601.02197)
*Wei-Long Zheng, Jia-Yi Zhu, Bao-Liang Lu* 

  In this paper, we investigate stable patterns of electroencephalogram (EEG)
over time for emotion recognition using a machine learning approach. Up to now,
various findings of activated patterns associated with different emotions have
been reported. However, their stability over time has not been fully
investigated yet. In this paper, we focus on identifying EEG stability in
emotion recognition. To validate the efficiency of the machine learning
algorithms used in this study, we systematically evaluate the performance of
various popular feature extraction, feature selection, feature smoothing and
pattern classification methods with the DEAP dataset and a newly developed
dataset for this study. The experimental results indicate that stable patterns
exhibit consistency across sessions; the lateral temporal areas activate more
for positive emotion than negative one in beta and gamma bands; the neural
patterns of neutral emotion have higher alpha responses at parietal and
occipital sites; and for negative emotion, the neural patterns have significant
higher delta responses at parietal and occipital sites and higher gamma
responses at prefrontal sites. The performance of our emotion recognition
system shows that the neural patterns are relatively stable within and between
sessions.

---------------

### 26 May 2022 | [Emergent organization of receptive fields in networks of excitatory and  inhibitory neurons](https://arxiv.org/abs/2205.13614) | [⬇️](https://arxiv.org/pdf/2205.13614)
*Leon Lufkin, Ashish Puri, Ganlin Song, Xinyi Zhong, John Lafferty* 

  Local patterns of excitation and inhibition that can generate neural waves
are studied as a computational mechanism underlying the organization of
neuronal tunings. Sparse coding algorithms based on networks of excitatory and
inhibitory neurons are proposed that exhibit topographic maps as the receptive
fields are adapted to input stimuli. Motivated by a leaky integrate-and-fire
model of neural waves, we propose an activation model that is more typical of
artificial neural networks. Computational experiments with the activation model
using both natural images and natural language text are presented. In the case
of images, familiar "pinwheel" patterns of oriented edge detectors emerge; in
the case of text, the resulting topographic maps exhibit a 2-dimensional
representation of granular word semantics. Experiments with a synthetic model
of somatosensory input are used to investigate how the network dynamics may
affect plasticity of neuronal maps under changes to the inputs.

---------------

### 07 Dec 2021 | [Unsupervised Representation Learning via Neural Activation Coding](https://arxiv.org/abs/2112.04014) | [⬇️](https://arxiv.org/pdf/2112.04014)
*Yookoon Park, Sangho Lee, Gunhee Kim, David M. Blei* 

  We present neural activation coding (NAC) as a novel approach for learning
deep representations from unlabeled data for downstream applications. We argue
that the deep encoder should maximize its nonlinear expressivity on the data
for downstream predictors to take full advantage of its representation power.
To this end, NAC maximizes the mutual information between activation patterns
of the encoder and the data over a noisy communication channel. We show that
learning for a noise-robust activation code increases the number of distinct
linear regions of ReLU encoders, hence the maximum nonlinear expressivity. More
interestingly, NAC learns both continuous and discrete representations of data,
which we respectively evaluate on two downstream tasks: (i) linear
classification on CIFAR-10 and ImageNet-1K and (ii) nearest neighbor retrieval
on CIFAR-10 and FLICKR-25K. Empirical results show that NAC attains better or
comparable performance on both tasks over recent baselines including SimCLR and
DistillHash. In addition, NAC pretraining provides significant benefits to the
training of deep generative models. Our code is available at
https://github.com/yookoon/nac.

---------------

### 14 Dec 2019 | [Empirical Bounds on Linear Regions of Deep Rectifier Networks](https://arxiv.org/abs/1810.03370) | [⬇️](https://arxiv.org/pdf/1810.03370)
*Thiago Serra, Srikumar Ramalingam* 

  We can compare the expressiveness of neural networks that use rectified
linear units (ReLUs) by the number of linear regions, which reflect the number
of pieces of the piecewise linear functions modeled by such networks. However,
enumerating these regions is prohibitive and the known analytical bounds are
identical for networks with same dimensions. In this work, we approximate the
number of linear regions through empirical bounds based on features of the
trained network and probabilistic inference. Our first contribution is a method
to sample the activation patterns defined by ReLUs using universal hash
functions. This method is based on a Mixed-Integer Linear Programming (MILP)
formulation of the network and an algorithm for probabilistic lower bounds of
MILP solution sets that we call MIPBound, which is considerably faster than
exact counting and reaches values in similar orders of magnitude. Our second
contribution is a tighter activation-based bound for the maximum number of
linear regions, which is particularly stronger in networks with narrow layers.
Combined, these bounds yield a fast proxy for the number of linear regions of a
deep neural network.

---------------

### 25 Sep 2021 | [Provably-Robust Runtime Monitoring of Neuron Activation Patterns](https://arxiv.org/abs/2011.11959) | [⬇️](https://arxiv.org/pdf/2011.11959)
*Chih-Hong Cheng* 

  For deep neural networks (DNNs) to be used in safety-critical autonomous
driving tasks, it is desirable to monitor in operation time if the input for
the DNN is similar to the data used in DNN training. While recent results in
monitoring DNN activation patterns provide a sound guarantee due to building an
abstraction out of the training data set, reducing false positives due to
slight input perturbation has been an issue towards successfully adapting the
techniques. We address this challenge by integrating formal symbolic reasoning
inside the monitor construction process. The algorithm performs a sound
worst-case estimate of neuron values with inputs (or features) subject to
perturbation, before the abstraction function is applied to build the monitor.
The provable robustness is further generalized to cases where monitoring a
single neuron can use more than one bit, implying that one can record
activation patterns with a fine-grained decision on the neuron value interval.

---------------

### 05 Nov 2019 | [Neurons Activation Visualization and Information Theoretic Analysis](https://arxiv.org/abs/1905.08618) | [⬇️](https://arxiv.org/pdf/1905.08618)
*Longwei Wang, Peijie Chen* 

  Understanding the inner working mechanism of deep neural networks (DNNs) is
essential and important for researchers to design and improve the performance
of DNNs. In this work, the entropy analysis is leveraged to study the neurons
activation behavior of the fully connected layers of DNNs. The entropy of the
activation patterns of each layer can provide a performance metric for the
evaluation of the network model accuracy. The study is conducted based on a
well trained network model. The activation patterns of shallow and deep layers
of the fully connected layers are analyzed by inputting the images of a single
class. It is found that for the well trained deep neural networks model, the
entropy of the neuron activation pattern is monotonically reduced with the
depth of the layers. That is, the neuron activation patterns become more and
more stable with the depth of the fully connected layers. The entropy pattern
of the fully connected layers can also provide guidelines as to how many fully
connected layers are needed to guarantee the accuracy of the model. The study
in this work provides a new perspective on the analysis of DNN, which shows
some interesting results.

---------------

### 28 Sep 2021 | [Text2Brain: Synthesis of Brain Activation Maps from Free-form Text Query](https://arxiv.org/abs/2109.13814) | [⬇️](https://arxiv.org/pdf/2109.13814)
*Gia H. Ngo and Minh Nguyen and Nancy F. Chen and Mert R. Sabuncu* 

  Most neuroimaging experiments are under-powered, limited by the number of
subjects and cognitive processes that an individual study can investigate.
Nonetheless, over decades of research, neuroscience has accumulated an
extensive wealth of results. It remains a challenge to digest this growing
knowledge base and obtain new insights since existing meta-analytic tools are
limited to keyword queries. In this work, we propose Text2Brain, a neural
network approach for coordinate-based meta-analysis of neuroimaging studies to
synthesize brain activation maps from open-ended text queries. Combining a
transformer-based text encoder and a 3D image generator, Text2Brain was trained
on variable-length text snippets and their corresponding activation maps
sampled from 13,000 published neuroimaging studies. We demonstrate that
Text2Brain can synthesize anatomically-plausible neural activation patterns
from free-form textual descriptions of cognitive concepts. Text2Brain is
available at https://braininterpreter.com as a web-based tool for retrieving
established priors and generating new hypotheses for neuroscience research.

---------------

### 19 Dec 2023 | [Improving the Expressive Power of Deep Neural Networks through Integral  Activation Transform](https://arxiv.org/abs/2312.12578) | [⬇️](https://arxiv.org/pdf/2312.12578)
*Zezhong Zhang, Feng Bao, Guannan Zhang* 

  The impressive expressive power of deep neural networks (DNNs) underlies
their widespread applicability. However, while the theoretical capacity of deep
architectures is high, the practical expressive power achieved through
successful training often falls short. Building on the insights gained from
Neural ODEs, which explore the depth of DNNs as a continuous variable, in this
work, we generalize the traditional fully connected DNN through the concept of
continuous width. In the Generalized Deep Neural Network (GDNN), the
traditional notion of neurons in each layer is replaced by a continuous state
function. Using the finite rank parameterization of the weight integral kernel,
we establish that GDNN can be obtained by employing the Integral Activation
Transform (IAT) as activation layers within the traditional DNN framework. The
IAT maps the input vector to a function space using some basis functions,
followed by nonlinear activation in the function space, and then extracts
information through the integration with another collection of basis functions.
A specific variant, IAT-ReLU, featuring the ReLU nonlinearity, serves as a
smooth generalization of the scalar ReLU activation. Notably, IAT-ReLU exhibits
a continuous activation pattern when continuous basis functions are employed,
making it smooth and enhancing the trainability of the DNN. Our numerical
experiments demonstrate that IAT-ReLU outperforms regular ReLU in terms of
trainability and better smoothness.

---------------

### 01 Dec 2023 | [Linear Oscillation: A Novel Activation Function for Vision Transformer](https://arxiv.org/abs/2308.13670) | [⬇️](https://arxiv.org/pdf/2308.13670)
*Juyoung Yun* 

  Activation functions are the linchpins of deep learning, profoundly
influencing both the representational capacity and training dynamics of neural
networks. They shape not only the nature of representations but also optimize
convergence rates and enhance generalization potential. Appreciating this
critical role, we present the Linear Oscillation (LoC) activation function,
defined as $f(x) = x \times \sin(\alpha x + \beta)$. Distinct from conventional
activation functions which primarily introduce non-linearity, LoC seamlessly
blends linear trajectories with oscillatory deviations. The nomenclature
"Linear Oscillation" is a nod to its unique attribute of infusing linear
activations with harmonious oscillations, capturing the essence of the
"Importance of Confusion". This concept of "controlled confusion" within
network activations is posited to foster more robust learning, particularly in
contexts that necessitate discerning subtle patterns. Our empirical studies
reveal that, when integrated into diverse neural architectures, the LoC
activation function consistently outperforms established counterparts like ReLU
and Sigmoid. The stellar performance exhibited by the avant-garde Vision
Transformer model using LoC further validates its efficacy. This study
illuminates the remarkable benefits of the LoC over other prominent activation
functions. It champions the notion that intermittently introducing deliberate
complexity or "confusion" during training can spur more profound and nuanced
learning. This accentuates the pivotal role of judiciously selected activation
functions in shaping the future of neural network training.

---------------

### 06 May 2023 | [Hamming Similarity and Graph Laplacians for Class Partitioning and  Adversarial Image Detection](https://arxiv.org/abs/2305.01808) | [⬇️](https://arxiv.org/pdf/2305.01808)
*Huma Jamil, Yajing Liu, Turgay Caglar, Christina M. Cole, Nathaniel  Blanchard, Christopher Peterson, Michael Kirby* 

  Researchers typically investigate neural network representations by examining
activation outputs for one or more layers of a network. Here, we investigate
the potential for ReLU activation patterns (encoded as bit vectors) to aid in
understanding and interpreting the behavior of neural networks. We utilize
Representational Dissimilarity Matrices (RDMs) to investigate the coherence of
data within the embedding spaces of a deep neural network. From each layer of a
network, we extract and utilize bit vectors to construct similarity scores
between images. From these similarity scores, we build a similarity matrix for
a collection of images drawn from 2 classes. We then apply Fiedler partitioning
to the associated Laplacian matrix to separate the classes. Our results
indicate, through bit vector representations, that the network continues to
refine class detectability with the last ReLU layer achieving better than 95\%
separation accuracy. Additionally, we demonstrate that bit vectors aid in
adversarial image detection, again achieving over 95\% accuracy in separating
adversarial and non-adversarial images using a simple classifier.

---------------

### 19 Apr 2023 | [Constraining Representations Yields Models That Know What They Don't  Know](https://arxiv.org/abs/2208.14488) | [⬇️](https://arxiv.org/pdf/2208.14488)
*Joao Monteiro, Pau Rodriguez, Pierre-Andre Noel, Issam Laradji, David  Vazquez* 

  A well-known failure mode of neural networks is that they may confidently
return erroneous predictions. Such unsafe behaviour is particularly frequent
when the use case slightly differs from the training context, and/or in the
presence of an adversary. This work presents a novel direction to address these
issues in a broad, general manner: imposing class-aware constraints on a
model's internal activation patterns. Specifically, we assign to each class a
unique, fixed, randomly-generated binary vector - hereafter called class code -
and train the model so that its cross-depths activation patterns predict the
appropriate class code according to the input sample's class. The resulting
predictors are dubbed Total Activation Classifiers (TAC), and TACs may either
be trained from scratch, or used with negligible cost as a thin add-on on top
of a frozen, pre-trained neural network. The distance between a TAC's
activation pattern and the closest valid code acts as an additional confidence
score, besides the default unTAC'ed prediction head's. In the add-on case, the
original neural network's inference head is completely unaffected (so its
accuracy remains the same) but we now have the option to use TAC's own
confidence and prediction when determining which course of action to take in an
hypothetical production workflow. In particular, we show that TAC strictly
improves the value derived from models allowed to reject/defer. We provide
further empirical evidence that TAC works well on multiple types of
architectures and data modalities and that it is at least as good as
state-of-the-art alternative confidence scores derived from existing models.

---------------

### 16 Oct 2023 | [A Non-monotonic Smooth Activation Function](https://arxiv.org/abs/2310.10126) | [⬇️](https://arxiv.org/pdf/2310.10126)
*Koushik Biswas, Meghana Karri, Ula\c{s} Ba\u{g}c{\i}* 

  Activation functions are crucial in deep learning models since they introduce
non-linearity into the networks, allowing them to learn from errors and make
adjustments, which is essential for learning complex patterns. The essential
purpose of activation functions is to transform unprocessed input signals into
significant output activations, promoting information transmission throughout
the neural network. In this study, we propose a new activation function called
Sqish, which is a non-monotonic and smooth function and an alternative to
existing ones. We showed its superiority in classification, object detection,
segmentation tasks, and adversarial robustness experiments. We got an 8.21%
improvement over ReLU on the CIFAR100 dataset with the ShuffleNet V2 model in
the FGSM adversarial attack. We also got a 5.87% improvement over ReLU on image
classification on the CIFAR100 dataset with the ShuffleNet V2 model.

---------------

### 28 Oct 2021 | [Counterfactual Explanation of Brain Activity Classifiers using  Image-to-Image Transfer by Generative Adversarial Network](https://arxiv.org/abs/2110.14927) | [⬇️](https://arxiv.org/pdf/2110.14927)
*Teppei Matsui, Masato Taki, Trung Quang Pham, Junichi Chikazoe, Koji  Jimura* 

  Deep neural networks (DNNs) can accurately decode task-related information
from brain activations. However, because of the nonlinearity of the DNN, the
decisions made by DNNs are hardly interpretable. One of the promising
approaches for explaining such a black-box system is counterfactual
explanation. In this framework, the behavior of a black-box system is explained
by comparing real data and realistic synthetic data that are specifically
generated such that the black-box system outputs an unreal outcome. Here we
introduce a novel generative DNN (counterfactual activation generator, CAG)
that can provide counterfactual explanations for DNN-based classifiers of brain
activations. Importantly, CAG can simultaneously handle image transformation
among multiple classes associated with different behavioral tasks. Using CAG,
we demonstrated counterfactual explanation of DNN-based classifiers that
learned to discriminate brain activations of seven behavioral tasks.
Furthermore, by iterative applications of CAG, we were able to enhance and
extract subtle spatial brain activity patterns that affected the classifier's
decisions. Together, these results demonstrate that the counterfactual
explanation based on image-to-image transformation would be a promising
approach to understand and extend the current application of DNNs in fMRI
analyses.

---------------

### 13 Jun 2018 | [fMRI Semantic Category Decoding using Linguistic Encoding of Word  Embeddings](https://arxiv.org/abs/1806.05177) | [⬇️](https://arxiv.org/pdf/1806.05177)
*Subba Reddy Oota, Naresh Manwani, and Bapi Raju S* 

  The dispute of how the human brain represents conceptual knowledge has been
argued in many scientific fields. Brain imaging studies have shown that the
spatial patterns of neural activation in the brain are correlated with thinking
about different semantic categories of words (for example, tools, animals, and
buildings) or when viewing the related pictures. In this paper, we present a
computational model that learns to predict the neural activation captured in
functional magnetic resonance imaging (fMRI) data of test words. Unlike the
models with hand-crafted features that have been used in the literature, in
this paper we propose a novel approach wherein decoding models are built with
features extracted from popular linguistic encodings of Word2Vec, GloVe,
Meta-Embeddings in conjunction with the empirical fMRI data associated with
viewing several dozen concrete nouns. We compared these models with several
other models that use word features extracted from FastText, Randomly-generated
features, Mitchell's 25 features [1]. The experimental results show that the
predicted fMRI images using Meta-Embeddings meet the state-of-the-art
performance. Although models with features from GloVe and Word2Vec predict fMRI
images similar to the state-of-the-art model, model with features from
Meta-Embeddings predicts significantly better. The proposed scheme that uses
popular linguistic encoding offers a simple and easy approach for semantic
decoding from fMRI experiments.

---------------

### 21 Apr 2022 | [Improving Differentiable Neural Computers Through Memory Masking,  De-allocation, and Link Distribution Sharpness Control](https://arxiv.org/abs/1904.10278) | [⬇️](https://arxiv.org/pdf/1904.10278)
*R\'obert Csord\'as, J\"urgen Schmidhuber* 

  The Differentiable Neural Computer (DNC) can learn algorithmic and question
answering tasks. An analysis of its internal activation patterns reveals three
problems: Most importantly, the lack of key-value separation makes the address
distribution resulting from content-based look-up noisy and flat, since the
value influences the score calculation, although only the key should. Second,
DNC's de-allocation of memory results in aliasing, which is a problem for
content-based look-up. Thirdly, chaining memory reads with the temporal linkage
matrix exponentially degrades the quality of the address distribution. Our
proposed fixes of these problems yield improved performance on arithmetic
tasks, and also improve the mean error rate on the bAbI question answering
dataset by 43%.

---------------
**Date:** 14 Jul 2020

**Title:** Plateau Phenomenon in Gradient Descent Training of ReLU networks:  Explanation, Quantification and Avoidance

**Abstract Link:** [https://arxiv.org/abs/2007.07213](https://arxiv.org/abs/2007.07213)

**PDF Link:** [https://arxiv.org/pdf/2007.07213](https://arxiv.org/pdf/2007.07213)

---

**Date:** 08 Feb 2024

**Title:** Mildly Overparameterized ReLU Networks Have a Favorable Loss Landscape

**Abstract Link:** [https://arxiv.org/abs/2305.19510](https://arxiv.org/abs/2305.19510)

**PDF Link:** [https://arxiv.org/pdf/2305.19510](https://arxiv.org/pdf/2305.19510)

---

**Date:** 19 Sep 2018

**Title:** Runtime Monitoring Neuron Activation Patterns

**Abstract Link:** [https://arxiv.org/abs/1809.06573](https://arxiv.org/abs/1809.06573)

**PDF Link:** [https://arxiv.org/pdf/1809.06573](https://arxiv.org/pdf/1809.06573)

---

**Date:** 14 Jan 2021

**Title:** Neural networks behave as hash encoders: An empirical study

**Abstract Link:** [https://arxiv.org/abs/2101.05490](https://arxiv.org/abs/2101.05490)

**PDF Link:** [https://arxiv.org/pdf/2101.05490](https://arxiv.org/pdf/2101.05490)

---

**Date:** 05 Jul 2019

**Title:** Prior Activation Distribution (PAD): A Versatile Representation to  Utilize DNN Hidden Units

**Abstract Link:** [https://arxiv.org/abs/1907.02711](https://arxiv.org/abs/1907.02711)

**PDF Link:** [https://arxiv.org/pdf/1907.02711](https://arxiv.org/pdf/1907.02711)

---

**Date:** 10 Jan 2016

**Title:** Identifying Stable Patterns over Time for Emotion Recognition from EEG

**Abstract Link:** [https://arxiv.org/abs/1601.02197](https://arxiv.org/abs/1601.02197)

**PDF Link:** [https://arxiv.org/pdf/1601.02197](https://arxiv.org/pdf/1601.02197)

---

**Date:** 26 May 2022

**Title:** Emergent organization of receptive fields in networks of excitatory and  inhibitory neurons

**Abstract Link:** [https://arxiv.org/abs/2205.13614](https://arxiv.org/abs/2205.13614)

**PDF Link:** [https://arxiv.org/pdf/2205.13614](https://arxiv.org/pdf/2205.13614)

---

**Date:** 07 Dec 2021

**Title:** Unsupervised Representation Learning via Neural Activation Coding

**Abstract Link:** [https://arxiv.org/abs/2112.04014](https://arxiv.org/abs/2112.04014)

**PDF Link:** [https://arxiv.org/pdf/2112.04014](https://arxiv.org/pdf/2112.04014)

---

**Date:** 14 Dec 2019

**Title:** Empirical Bounds on Linear Regions of Deep Rectifier Networks

**Abstract Link:** [https://arxiv.org/abs/1810.03370](https://arxiv.org/abs/1810.03370)

**PDF Link:** [https://arxiv.org/pdf/1810.03370](https://arxiv.org/pdf/1810.03370)

---

**Date:** 25 Sep 2021

**Title:** Provably-Robust Runtime Monitoring of Neuron Activation Patterns

**Abstract Link:** [https://arxiv.org/abs/2011.11959](https://arxiv.org/abs/2011.11959)

**PDF Link:** [https://arxiv.org/pdf/2011.11959](https://arxiv.org/pdf/2011.11959)

---

**Date:** 05 Nov 2019

**Title:** Neurons Activation Visualization and Information Theoretic Analysis

**Abstract Link:** [https://arxiv.org/abs/1905.08618](https://arxiv.org/abs/1905.08618)

**PDF Link:** [https://arxiv.org/pdf/1905.08618](https://arxiv.org/pdf/1905.08618)

---

**Date:** 28 Sep 2021

**Title:** Text2Brain: Synthesis of Brain Activation Maps from Free-form Text Query

**Abstract Link:** [https://arxiv.org/abs/2109.13814](https://arxiv.org/abs/2109.13814)

**PDF Link:** [https://arxiv.org/pdf/2109.13814](https://arxiv.org/pdf/2109.13814)

---

**Date:** 19 Dec 2023

**Title:** Improving the Expressive Power of Deep Neural Networks through Integral  Activation Transform

**Abstract Link:** [https://arxiv.org/abs/2312.12578](https://arxiv.org/abs/2312.12578)

**PDF Link:** [https://arxiv.org/pdf/2312.12578](https://arxiv.org/pdf/2312.12578)

---

**Date:** 01 Dec 2023

**Title:** Linear Oscillation: A Novel Activation Function for Vision Transformer

**Abstract Link:** [https://arxiv.org/abs/2308.13670](https://arxiv.org/abs/2308.13670)

**PDF Link:** [https://arxiv.org/pdf/2308.13670](https://arxiv.org/pdf/2308.13670)

---

**Date:** 06 May 2023

**Title:** Hamming Similarity and Graph Laplacians for Class Partitioning and  Adversarial Image Detection

**Abstract Link:** [https://arxiv.org/abs/2305.01808](https://arxiv.org/abs/2305.01808)

**PDF Link:** [https://arxiv.org/pdf/2305.01808](https://arxiv.org/pdf/2305.01808)

---

**Date:** 19 Apr 2023

**Title:** Constraining Representations Yields Models That Know What They Don't  Know

**Abstract Link:** [https://arxiv.org/abs/2208.14488](https://arxiv.org/abs/2208.14488)

**PDF Link:** [https://arxiv.org/pdf/2208.14488](https://arxiv.org/pdf/2208.14488)

---

**Date:** 16 Oct 2023

**Title:** A Non-monotonic Smooth Activation Function

**Abstract Link:** [https://arxiv.org/abs/2310.10126](https://arxiv.org/abs/2310.10126)

**PDF Link:** [https://arxiv.org/pdf/2310.10126](https://arxiv.org/pdf/2310.10126)

---

**Date:** 28 Oct 2021

**Title:** Counterfactual Explanation of Brain Activity Classifiers using  Image-to-Image Transfer by Generative Adversarial Network

**Abstract Link:** [https://arxiv.org/abs/2110.14927](https://arxiv.org/abs/2110.14927)

**PDF Link:** [https://arxiv.org/pdf/2110.14927](https://arxiv.org/pdf/2110.14927)

---

**Date:** 13 Jun 2018

**Title:** fMRI Semantic Category Decoding using Linguistic Encoding of Word  Embeddings

**Abstract Link:** [https://arxiv.org/abs/1806.05177](https://arxiv.org/abs/1806.05177)

**PDF Link:** [https://arxiv.org/pdf/1806.05177](https://arxiv.org/pdf/1806.05177)

---

**Date:** 21 Apr 2022

**Title:** Improving Differentiable Neural Computers Through Memory Masking,  De-allocation, and Link Distribution Sharpness Control

**Abstract Link:** [https://arxiv.org/abs/1904.10278](https://arxiv.org/abs/1904.10278)

**PDF Link:** [https://arxiv.org/pdf/1904.10278](https://arxiv.org/pdf/1904.10278)

---

