RLAIF Feedback Models 🔄

### 🔎 RLAIF Feedback Models 🔄


========================

This repository contains the code for the feedback models used in the RLAIF project.

The feedback models are used to generate feedback for the agents in the RLAIF project.

The feedback models are implemented in Python and use the TensorFlow library for machine learning.

The feedback models are trained on a dataset of human feedback.

The feedback models are used to generate feedback for the agents in the RLAIF project.

The feedback models are implemented in Python and use the TensorFlow library for machine learning.

The feedback models are trained on a dataset of human feedback.

The feedback models are used to generate feedback for the agents in the RLAIF project.

The feedback models are implemented in Python and use the TensorFlow library for machine learning.

The feedback models are trained on a dataset of human feedback.

The feedback models are used to generate feedback for the agents in the RLAIF project.

The feedback models are implemented in Python and use the TensorFlow library for machine learning.

The feedback models are trained on a dataset of human feedback.

The feedback models are used to generate feedback for the agents in the RLAIF project.

The feedback models are implemented in Python and use the TensorFlow library for machine learning.

The feedback models are trained on a dataset of human feedback.

The feedback models are used to generate feedback for the agents in the RLAIF project.

The feedback models are implemented in Python and use the TensorFlow library for machine learning.

The feedback models are trained on a dataset of human feedback.

The feedback models are used to generate feedback for the agents in the RLAIF project.

The feedback models are implemented in Python and use the TensorFlow library for machine learning.

The feedback models are trained on a dataset of human feedback.

The feedback models are used to generate feedback for the agents in the RLAIF project.

The feedback models are implemented in Python and use the TensorFlow library for machine learning.

The feedback models are trained on a dataset of human feedback.

The feedback models are used to generate feedback for the agents in the RLAIF project.

The feedback models are implemented in Python and use the TensorFlow library for machine learning.

The feedback models are trained on a dataset of human feedback.

The feedback models are used to generate feedback for the agents
# 🩺🔍 Search Results
### 19 Feb 2024 | [A Critical Evaluation of AI Feedback for Aligning Large Language Models](https://arxiv.org/abs/2402.12366) | [⬇️](https://arxiv.org/pdf/2402.12366)
*Archit Sharma, Sedrick Keh, Eric Mitchell, Chelsea Finn, Kushal Arora,  Thomas Kollar* 

  Reinforcement learning with AI feedback (RLAIF) is a popular paradigm for
improving the instruction-following abilities of powerful pre-trained language
models. RLAIF first performs supervised fine-tuning (SFT) using demonstrations
from a teacher model and then further fine-tunes the model with reinforcement
learning (RL), using feedback from a critic model. While recent popular
open-source models have demonstrated substantial improvements in performance
from the RL step, in this paper we question whether the complexity of this RL
step is truly warranted for AI feedback. We show that the improvements of the
RL step are virtually entirely due to the widespread practice of using a weaker
teacher model (e.g. GPT-3.5) for SFT data collection than the critic (e.g.,
GPT-4) used for AI feedback generation. Specifically, we show that simple
supervised fine-tuning with GPT-4 as the teacher outperforms existing RLAIF
pipelines. More generally, we find that the gains from RLAIF vary substantially
across base model families, test-time evaluation protocols, and critic models.
Finally, we provide a mechanistic explanation for when SFT may outperform the
full two-step RLAIF pipeline as well as suggestions for making RLAIF maximally
useful in practice.

---------------

### 01 Dec 2023 | [RLAIF: Scaling Reinforcement Learning from Human Feedback with AI  Feedback](https://arxiv.org/abs/2309.00267) | [⬇️](https://arxiv.org/pdf/2309.00267)
*Harrison Lee, Samrat Phatale, Hassan Mansoor, Thomas Mesnard, Johan  Ferret, Kellie Lu, Colton Bishop, Ethan Hall, Victor Carbune, Abhinav  Rastogi, Sushant Prakash* 

  Reinforcement learning from human feedback (RLHF) has proven effective in
aligning large language models (LLMs) with human preferences. However,
gathering high-quality human preference labels can be a time-consuming and
expensive endeavor. RL from AI Feedback (RLAIF), introduced by Bai et al.,
offers a promising alternative that leverages a powerful off-the-shelf LLM to
generate preferences in lieu of human annotators. Across the tasks of
summarization, helpful dialogue generation, and harmless dialogue generation,
RLAIF achieves comparable or superior performance to RLHF, as rated by human
evaluators. Furthermore, RLAIF demonstrates the ability to outperform a
supervised fine-tuned baseline even when the LLM preference labeler is the same
size as the policy. In another experiment, directly prompting the LLM for
reward scores achieves superior performance to the canonical RLAIF setup, where
LLM preference labels are first distilled into a reward model. Finally, we
conduct extensive studies on techniques for generating aligned AI preferences.
Our results suggest that RLAIF can achieve human-level performance, offering a
potential solution to the scalability limitations of RLHF.

---------------

### 18 Aug 2023 | [RLCD: Reinforcement Learning from Contrast Distillation for Language  Model Alignment](https://arxiv.org/abs/2307.12950) | [⬇️](https://arxiv.org/pdf/2307.12950)
*Kevin Yang, Dan Klein, Asli Celikyilmaz, Nanyun Peng, Yuandong Tian* 

  We propose Reinforcement Learning from Contrast Distillation (RLCD), a method
for aligning language models to follow natural language principles without
using human feedback. RLCD trains a preference model using simulated preference
pairs that contain both a high-quality and low-quality example, generated using
contrasting positive and negative prompts. The preference model is then used to
improve a base unaligned language model via reinforcement learning.
Empirically, RLCD outperforms RLAIF (Bai et al., 2022b) and context
distillation (Huang et al., 2022) baselines across three diverse alignment
tasks--harmlessness, helpfulness, and story outline generation--and on both 7B
and 30B model scales for preference data simulation.

---------------

### 16 Feb 2024 | [Tuning Large Multimodal Models for Videos using Reinforcement Learning  from AI Feedback](https://arxiv.org/abs/2402.03746) | [⬇️](https://arxiv.org/pdf/2402.03746)
*Daechul Ahn, Yura Choi, Youngjae Yu, Dongyeop Kang and Jonghyun Choi* 

  Recent advancements in large language models have influenced the development
of video large multimodal models (VLMMs). The previous approaches for VLMMs
involved Supervised Fine-Tuning (SFT) with instruction-tuned datasets,
integrating LLM with visual encoders, and adding additional learnable modules.
Video and text multimodal alignment remains challenging, primarily due to the
deficient volume and quality of multimodal instruction-tune data compared to
text-only data. We present a novel alignment strategy that employs multimodal
AI system to oversee itself called Reinforcement Learning from AI Feedback
(RLAIF), providing self-preference feedback to refine itself and facilitating
the alignment of video and text modalities. In specific, we propose
context-aware reward modeling by providing detailed video descriptions as
context during the generation of preference feedback in order to enrich the
understanding of video content. Demonstrating enhanced performance across
diverse video benchmarks, our multimodal RLAIF approach, VLM-RLAIF, outperforms
existing approaches, including the SFT model. We commit to open-sourcing our
code, models, and datasets to foster further research in this area.

---------------

### 16 Oct 2023 | [Verbosity Bias in Preference Labeling by Large Language Models](https://arxiv.org/abs/2310.10076) | [⬇️](https://arxiv.org/pdf/2310.10076)
*Keita Saito, Akifumi Wachi, Koki Wataoka, Youhei Akimoto* 

  In recent years, Large Language Models (LLMs) have witnessed a remarkable
surge in prevalence, altering the landscape of natural language processing and
machine learning. One key factor in improving the performance of LLMs is
alignment with humans achieved with Reinforcement Learning from Human Feedback
(RLHF), as for many LLMs such as GPT-4, Bard, etc. In addition, recent studies
are investigating the replacement of human feedback with feedback from other
LLMs named Reinforcement Learning from AI Feedback (RLAIF). We examine the
biases that come along with evaluating LLMs with other LLMs and take a closer
look into verbosity bias -- a bias where LLMs sometimes prefer more verbose
answers even if they have similar qualities. We see that in our problem
setting, GPT-4 prefers longer answers more than humans. We also propose a
metric to measure this bias.

---------------

### 15 Dec 2022 | [Constitutional AI: Harmlessness from AI Feedback](https://arxiv.org/abs/2212.08073) | [⬇️](https://arxiv.org/pdf/2212.08073)
*Yuntao Bai, Saurav Kadavath, Sandipan Kundu, Amanda Askell, Jackson  Kernion, Andy Jones, Anna Chen, Anna Goldie, Azalia Mirhoseini, Cameron  McKinnon, Carol Chen, Catherine Olsson, Christopher Olah, Danny Hernandez,  Dawn Drain, Deep Ganguli, Dustin Li, Eli Tran-Johnson, Ethan Perez, Jamie  Kerr, Jared Mueller, Jeffrey Ladish, Joshua Landau, Kamal Ndousse, Kamile  Lukosuite, Liane Lovitt, Michael Sellitto, Nelson Elhage, Nicholas Schiefer,  Noemi Mercado, Nova DasSarma, Robert Lasenby, Robin Larson, Sam Ringer, Scott  Johnston, Shauna Kravec, Sheer El Showk, Stanislav Fort, Tamera Lanham,  Timothy Telleen-Lawton, Tom Conerly, Tom Henighan, Tristan Hume, Samuel R.  Bowman, Zac Hatfield-Dodds, Ben Mann, Dario Amodei, Nicholas Joseph, Sam  McCandlish, Tom Brown, Jared Kaplan* 

  As AI systems become more capable, we would like to enlist their help to
supervise other AIs. We experiment with methods for training a harmless AI
assistant through self-improvement, without any human labels identifying
harmful outputs. The only human oversight is provided through a list of rules
or principles, and so we refer to the method as 'Constitutional AI'. The
process involves both a supervised learning and a reinforcement learning phase.
In the supervised phase we sample from an initial model, then generate
self-critiques and revisions, and then finetune the original model on revised
responses. In the RL phase, we sample from the finetuned model, use a model to
evaluate which of the two samples is better, and then train a preference model
from this dataset of AI preferences. We then train with RL using the preference
model as the reward signal, i.e. we use 'RL from AI Feedback' (RLAIF). As a
result we are able to train a harmless but non-evasive AI assistant that
engages with harmful queries by explaining its objections to them. Both the SL
and RL methods can leverage chain-of-thought style reasoning to improve the
human-judged performance and transparency of AI decision making. These methods
make it possible to control AI behavior more precisely and with far fewer human
labels.

---------------

### 29 Jan 2024 | [Iterative Data Smoothing: Mitigating Reward Overfitting and  Overoptimization in RLHF](https://arxiv.org/abs/2401.16335) | [⬇️](https://arxiv.org/pdf/2401.16335)
*Banghua Zhu, Michael I. Jordan and Jiantao Jiao* 

  Reinforcement Learning from Human Feedback (RLHF) is a pivotal technique that
aligns language models closely with human-centric values. The initial phase of
RLHF involves learning human values using a reward model from ranking data. It
is observed that the performance of the reward model degrades after one epoch
of training, and optimizing too much against the learned reward model
eventually hinders the true objective. This paper delves into these issues,
leveraging the theoretical insights to design improved reward learning
algorithm termed 'Iterative Data Smoothing' (IDS). The core idea is that during
each training epoch, we not only update the model with the data, but also
update the date using the model, replacing hard labels with soft labels. Our
empirical findings highlight the superior performance of this approach over the
traditional methods.

---------------

### 11 Sep 2023 | [Open Problems and Fundamental Limitations of Reinforcement Learning from  Human Feedback](https://arxiv.org/abs/2307.15217) | [⬇️](https://arxiv.org/pdf/2307.15217)
*Stephen Casper, Xander Davies, Claudia Shi, Thomas Krendl Gilbert,  J\'er\'emy Scheurer, Javier Rando, Rachel Freedman, Tomasz Korbak, David  Lindner, Pedro Freire, Tony Wang, Samuel Marks, Charbel-Rapha\"el Segerie,  Micah Carroll, Andi Peng, Phillip Christoffersen, Mehul Damani, Stewart  Slocum, Usman Anwar, Anand Siththaranjan, Max Nadeau, Eric J. Michaud, Jacob  Pfau, Dmitrii Krasheninnikov, Xin Chen, Lauro Langosco, Peter Hase, Erdem  B{\i}y{\i}k, Anca Dragan, David Krueger, Dorsa Sadigh, Dylan Hadfield-Menell* 

  Reinforcement learning from human feedback (RLHF) is a technique for training
AI systems to align with human goals. RLHF has emerged as the central method
used to finetune state-of-the-art large language models (LLMs). Despite this
popularity, there has been relatively little public work systematizing its
flaws. In this paper, we (1) survey open problems and fundamental limitations
of RLHF and related methods; (2) overview techniques to understand, improve,
and complement RLHF in practice; and (3) propose auditing and disclosure
standards to improve societal oversight of RLHF systems. Our work emphasizes
the limitations of RLHF and highlights the importance of a multi-faceted
approach to the development of safer AI systems.

---------------

### 30 Jan 2024 | [Improving Reinforcement Learning from Human Feedback with Efficient  Reward Model Ensemble](https://arxiv.org/abs/2401.16635) | [⬇️](https://arxiv.org/pdf/2401.16635)
*Shun Zhang, Zhenfang Chen, Sunli Chen, Yikang Shen, Zhiqing Sun,  Chuang Gan* 

  Reinforcement Learning from Human Feedback (RLHF) is a widely adopted
approach for aligning large language models with human values. However, RLHF
relies on a reward model that is trained with a limited amount of human
preference data, which could lead to inaccurate predictions. As a result, RLHF
may produce outputs that are misaligned with human values. To mitigate this
issue, we contribute a reward ensemble method that allows the reward model to
make more accurate predictions. As using an ensemble of large language
model-based reward models can be computationally and resource-expensive, we
explore efficient ensemble methods including linear-layer ensemble and
LoRA-based ensemble. Empirically, we run Best-of-$n$ and Proximal Policy
Optimization with our ensembled reward models, and verify that our ensemble
methods help improve the alignment performance of RLHF outputs.

---------------

### 16 Nov 2023 | [On the Exploitability of Reinforcement Learning with Human Feedback for  Large Language Models](https://arxiv.org/abs/2311.09641) | [⬇️](https://arxiv.org/pdf/2311.09641)
*Jiongxiao Wang, Junlin Wu, Muhao Chen, Yevgeniy Vorobeychik, Chaowei  Xiao* 

  Reinforcement Learning with Human Feedback (RLHF) is a methodology designed
to align Large Language Models (LLMs) with human preferences, playing an
important role in LLMs alignment. Despite its advantages, RLHF relies on human
annotators to rank the text, which can introduce potential security
vulnerabilities if any adversarial annotator (i.e., attackers) manipulates the
ranking score by up-ranking any malicious text to steer the LLM adversarially.
To assess the red-teaming of RLHF against human preference data poisoning, we
propose RankPoison, a poisoning attack method on candidates' selection of
preference rank flipping to reach certain malicious behaviors (e.g., generating
longer sequences, which can increase the computational cost). With poisoned
dataset generated by RankPoison, we can perform poisoning attacks on LLMs to
generate longer tokens without hurting the original safety alignment
performance. Moreover, applying RankPoison, we also successfully implement a
backdoor attack where LLMs can generate longer answers under questions with the
trigger word. Our findings highlight critical security challenges in RLHF,
underscoring the necessity for more robust alignment methods for LLMs.

---------------

### 06 Feb 2024 | [Personalized Language Modeling from Personalized Human Feedback](https://arxiv.org/abs/2402.05133) | [⬇️](https://arxiv.org/pdf/2402.05133)
*Xinyu Li, Zachary C. Lipton, Liu Leqi* 

  Reinforcement Learning from Human Feedback (RLHF) is the current dominating
framework to fine-tune large language models to better align with human
preferences. However, the underlying premise of algorithms developed under this
framework can be problematic when user preferences encoded in human feedback
are diverse. In this work, we aim to address this problem by developing methods
for building personalized language models. We first formally introduce the task
of learning from personalized human feedback and explain why vanilla RLHF can
be problematic in this context. We then propose a general Personalized-RLHF
(P-RLHF) framework, which requires one to jointly learn a user model and a
language (or reward) model. The user model takes in user information and
outputs user representations. Its structure encodes our assumptions about user
preferences underlying the feedback data. We develop new learning objectives
for personalized reward modeling and personalized Direct Preference
Optimization. To demonstrate the efficacy of our method, we test it on
real-world text summarization data with annotated preferences and annotator
information. We fine-tune GPT-J 6B to obtain personalized language (and reward)
models, which outperform non-personalized models in terms of aligning with
individual preferences.

---------------

### 15 Nov 2023 | [Aligning Neural Machine Translation Models: Human Feedback in Training  and Inference](https://arxiv.org/abs/2311.09132) | [⬇️](https://arxiv.org/pdf/2311.09132)
*Miguel Moura Ramos, Patrick Fernandes, Ant\'onio Farinhas, Andr\'e F.  T. Martins* 

  Reinforcement learning from human feedback (RLHF) is a recent technique to
improve the quality of the text generated by a language model, making it closer
to what humans would generate. A core ingredient in RLHF's success in aligning
and improving large language models (LLMs) is its reward model, trained using
human feedback on model outputs. In machine translation (MT), where metrics
trained from human annotations can readily be used as reward models, recent
methods using minimum Bayes risk decoding and reranking have succeeded in
improving the final quality of translation. In this study, we comprehensively
explore and compare techniques for integrating quality metrics as reward models
into the MT pipeline. This includes using the reward model for data filtering,
during the training phase through RL, and at inference time by employing
reranking techniques, and we assess the effects of combining these in a unified
approach. Our experimental results, conducted across multiple translation
tasks, underscore the crucial role of effective data filtering, based on
estimated quality, in harnessing the full potential of RL in enhancing MT
quality. Furthermore, our findings demonstrate the effectiveness of combining
RL training with reranking techniques, showcasing substantial improvements in
translation quality.

---------------

### 02 Oct 2023 | [UltraFeedback: Boosting Language Models with High-quality Feedback](https://arxiv.org/abs/2310.01377) | [⬇️](https://arxiv.org/pdf/2310.01377)
*Ganqu Cui, Lifan Yuan, Ning Ding, Guanming Yao, Wei Zhu, Yuan Ni,  Guotong Xie, Zhiyuan Liu, Maosong Sun* 

  Reinforcement learning from human feedback (RLHF) has become a pivot
technique in aligning large language models (LLMs) with human preferences. In
RLHF practice, preference data plays a crucial role in bridging human
proclivity and LLMs. However, the scarcity of diverse, naturalistic datasets of
human preferences on LLM outputs at scale poses a great challenge to RLHF as
well as feedback learning research within the open-source community. Current
preference datasets, either proprietary or limited in size and prompt variety,
result in limited RLHF adoption in open-source models and hinder further
exploration. In this study, we propose ULTRAFEEDBACK, a large-scale,
high-quality, and diversified preference dataset designed to overcome these
limitations and foster RLHF development. To create ULTRAFEEDBACK, we compile a
diverse array of instructions and models from multiple sources to produce
comparative data. We meticulously devise annotation instructions and employ
GPT-4 to offer detailed feedback in both numerical and textual forms.
ULTRAFEEDBACK establishes a reproducible and expandable preference data
construction pipeline, serving as a solid foundation for future RLHF and
feedback learning research. Utilizing ULTRAFEEDBACK, we train various models to
demonstrate its effectiveness, including the reward model UltraRM, chat
language model UltraLM-13B-PPO, and critique model UltraCM. Experimental
results indicate that our models outperform existing open-source models,
achieving top performance across multiple benchmarks. Our data and models are
available at https://github.com/thunlp/UltraFeedback.

---------------

### 12 Feb 2024 | [Universal Jailbreak Backdoors from Poisoned Human Feedback](https://arxiv.org/abs/2311.14455) | [⬇️](https://arxiv.org/pdf/2311.14455)
*Javier Rando and Florian Tram\`er* 

  Reinforcement Learning from Human Feedback (RLHF) is used to align large
language models to produce helpful and harmless responses. Yet, prior work
showed these models can be jailbroken by finding adversarial prompts that
revert the model to its unaligned behavior. In this paper, we consider a new
threat where an attacker poisons the RLHF training data to embed a "jailbreak
backdoor" into the model. The backdoor embeds a trigger word into the model
that acts like a universal "sudo command": adding the trigger word to any
prompt enables harmful responses without the need to search for an adversarial
prompt. Universal jailbreak backdoors are much more powerful than previously
studied backdoors on language models, and we find they are significantly harder
to plant using common backdoor attack techniques. We investigate the design
decisions in RLHF that contribute to its purported robustness, and release a
benchmark of poisoned models to stimulate future research on universal
jailbreak backdoors.

---------------

### 24 May 2023 | [HuatuoGPT, towards Taming Language Model to Be a Doctor](https://arxiv.org/abs/2305.15075) | [⬇️](https://arxiv.org/pdf/2305.15075)
*Hongbo Zhang and Junying Chen and Feng Jiang and Fei Yu and Zhihong  Chen and Jianquan Li and Guiming Chen and Xiangbo Wu and Zhiyi Zhang and  Qingying Xiao and Xiang Wan and Benyou Wang and Haizhou Li* 

  In this paper, we present HuatuoGPT, a large language model (LLM) for medical
consultation. The core recipe of HuatuoGPT is to leverage both
\textit{distilled data from ChatGPT} and \textit{real-world data from doctors}
in the supervised fine-tuned stage. The responses of ChatGPT are usually
detailed, well-presented and informative while it cannot perform like a doctor
in many aspects, e.g. for integrative diagnosis. We argue that real-world data
from doctors would be complementary to distilled data in the sense the former
could tame a distilled language model to perform like doctors. To better
leverage the strengths of both data, we train a reward model to align the
language model with the merits that both data bring, following an RLAIF
(reinforced learning from AI feedback) fashion. To evaluate and benchmark the
models, we propose a comprehensive evaluation scheme (including automatic and
manual metrics). Experimental results demonstrate that HuatuoGPT achieves
state-of-the-art results in performing medical consultation among open-source
LLMs in GPT-4 evaluation, human evaluation, and medical benchmark datasets. It
is worth noting that by using additional real-world data and RLAIF, the
distilled language model (i.e., HuatuoGPT) outperforms its teacher model
ChatGPT in most cases. Our code, data, and models are publicly available at
\url{https://github.com/FreedomIntelligence/HuatuoGPT}. The online demo is
available at \url{https://www.HuatuoGPT.cn/}.

---------------

### 02 Feb 2024 | [The Alignment Ceiling: Objective Mismatch in Reinforcement Learning from  Human Feedback](https://arxiv.org/abs/2311.00168) | [⬇️](https://arxiv.org/pdf/2311.00168)
*Nathan Lambert and Roberto Calandra* 

  Reinforcement learning from human feedback (RLHF) has emerged as a powerful
technique to make large language models (LLMs) more capable in complex
settings. RLHF proceeds as collecting human preference data, training a reward
model on said data, and optimizing a base ML model with respect to said reward
for extrinsic evaluation metrics (e.g. MMLU, GSM8k). RLHF relies on many
assumptions about how the various pieces fit together, such as a reward model
capturing human preferences and an RL optimizer extracting the right signal
from a reward model. As the RLHF process involves many distinct design
decisions, it is easy to assume that multiple processes are correlated and
therefore numerically linked. This apparent correlation is often not true,
where reward models are easily overoptimized or RL optimizers can reduce
performance on tasks not modeled in the data. Notable manifestations of models
trained with imperfect RLHF systems are those that are prone to refusing basic
requests for safety reasons or appearing lazy in generations. As chat model
evaluation becomes increasingly nuanced, the reliance on a perceived link
between reward model training, RL scores, and downstream performance drives
these issues, which we describe as an objective mismatch. In this paper, we
illustrate the causes of this issue, reviewing relevant literature from
model-based reinforcement learning, and argue for solutions. By solving
objective mismatch in RLHF, the ML models of the future will be more precisely
aligned to user instructions for both safety and helpfulness.

---------------

### 19 Feb 2024 | [Safer-Instruct: Aligning Language Models with Automated Preference Data](https://arxiv.org/abs/2311.08685) | [⬇️](https://arxiv.org/pdf/2311.08685)
*Taiwei Shi, Kai Chen, Jieyu Zhao* 

  Reinforcement learning from human feedback (RLHF) is a vital strategy for
enhancing model capability in language models. However, annotating preference
data for RLHF is a resource-intensive and creativity-demanding process, while
existing automatic generation methods face limitations in data diversity and
quality. In response, we present Safer-Instruct, a novel pipeline for
automatically constructing large-scale preference data. Our approach leverages
reversed instruction tuning, instruction induction, and expert model evaluation
to efficiently generate high-quality preference data without human annotators.
To verify the effectiveness of Safer-Instruct, we apply the pipeline to
construct a safety preference dataset as a case study. Finetuning an Alpaca
model on this synthetic dataset not only demonstrates improved harmlessness but
also outperforms models fine-tuned on human-annotated safety preference data,
all the while maintaining a competitive edge in downstream tasks. Importantly,
our Safer-Instruct framework is versatile and can be applied to generate
preference data across various domains, extending its utility beyond safety
preferences. It addresses the challenges in preference data acquisition and
advances the development of more capable and responsible AI systems. For
dataset and code implementation, see
https://github.com/uscnlp-lime/safer-instruct

---------------

### 10 Feb 2023 | [The Wisdom of Hindsight Makes Language Models Better Instruction  Followers](https://arxiv.org/abs/2302.05206) | [⬇️](https://arxiv.org/pdf/2302.05206)
*Tianjun Zhang, Fangchen Liu, Justin Wong, Pieter Abbeel, Joseph E.  Gonzalez* 

  Reinforcement learning has seen wide success in finetuning large language
models to better align with instructions via human feedback. The so-called
algorithm, Reinforcement Learning with Human Feedback (RLHF) demonstrates
impressive performance on the GPT series models. However, the underlying
Reinforcement Learning (RL) algorithm is complex and requires an additional
training pipeline for reward and value networks. In this paper, we consider an
alternative approach: converting feedback to instruction by relabeling the
original one and training the model for better alignment in a supervised
manner. Such an algorithm doesn't require any additional parameters except for
the original language model and maximally reuses the pretraining pipeline. To
achieve this, we formulate instruction alignment problem for language models as
a goal-reaching problem in decision making. We propose Hindsight Instruction
Relabeling (HIR), a novel algorithm for aligning language models with
instructions. The resulting two-stage algorithm shed light to a family of
reward-free approaches that utilize the hindsightly relabeled instructions
based on feedback. We evaluate the performance of HIR extensively on 12
challenging BigBench reasoning tasks and show that HIR outperforms the baseline
algorithms and is comparable to or even surpasses supervised finetuning.

---------------

### 04 Oct 2023 | [Reward Model Ensembles Help Mitigate Overoptimization](https://arxiv.org/abs/2310.02743) | [⬇️](https://arxiv.org/pdf/2310.02743)
*Thomas Coste, Usman Anwar, Robert Kirk, David Krueger* 

  Reinforcement learning from human feedback (RLHF) is a standard approach for
fine-tuning large language models to follow instructions. As part of this
process, learned reward models are used to approximately model human
preferences. However, as imperfect representations of the "true" reward, these
learned reward models are susceptible to \textit{overoptimization}. Gao et al.
(2023) studied this phenomenon in a synthetic human feedback setup with a
significantly larger "gold" reward model acting as the true reward (instead of
humans) and showed that overoptimization remains a persistent problem
regardless of the size of the proxy reward model and training data used. Using
a similar setup, we conduct a systematic study to evaluate the efficacy of
using ensemble-based conservative optimization objectives, specifically
worst-case optimization (WCO) and uncertainty-weighted optimization (UWO), for
mitigating reward model overoptimization when using two optimization methods:
(a) best-of-n sampling (BoN) (b) proximal policy optimization (PPO). We
additionally extend the setup of Gao et al. (2023) to include 25% label noise
to better mirror real-world conditions. Both with and without label noise, we
find that conservative optimization practically eliminates overoptimization and
improves performance by up to 70% for BoN sampling. For PPO, ensemble-based
conservative optimization always reduces overoptimization and outperforms
single reward model optimization. Moreover, combining it with a small KL
penalty successfully prevents overoptimization at no performance cost. Overall,
our results demonstrate that ensemble-based conservative optimization can
effectively counter overoptimization.

---------------

### 16 Feb 2024 | [Provably Sample Efficient RLHF via Active Preference Optimization](https://arxiv.org/abs/2402.10500) | [⬇️](https://arxiv.org/pdf/2402.10500)
*Nirjhar Das, Souradip Chakraborty, Aldo Pacchiano, Sayak Ray Chowdhury* 

  Reinforcement Learning from Human Feedback (RLHF) is pivotal in aligning
Large Language Models (LLMs) with human preferences. While these aligned
generative models have demonstrated impressive capabilities across various
tasks, the dependence on high-quality human preference data poses a costly
bottleneck in practical implementation of RLHF. Hence better and adaptive
strategies for data collection is needed. To this end, we frame RLHF as a
contextual preference bandit problem with prompts as contexts and show that the
naive way of collecting preference data by choosing prompts uniformly at random
leads to a policy that suffers an $\Omega(1)$ suboptimality gap in rewards.
Then we propose $\textit{Active Preference Optimization}$ ($\texttt{APO}$), an
algorithm that actively selects prompts to collect preference data. Under the
Bradley-Terry-Luce (BTL) preference model, \texttt{APO} achieves sample
efficiency without compromising on policy performance. We show that given a
sample budget of $T$, the suboptimality gap of a policy learned via
$\texttt{APO}$ scales as $O(1/\sqrt{T})$. Next, we propose a compute-efficient
batch version of $\texttt{APO}$ with minor modification and evaluate its
performance in practice. Experimental evaluations on a human preference dataset
validate \texttt{APO}'s efficacy as a sample-efficient and practical solution
to data collection for RLHF, facilitating alignment of LLMs with human
preferences in a cost-effective and scalable manner.

---------------
**Date:** 19 Feb 2024

**Title:** A Critical Evaluation of AI Feedback for Aligning Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.12366](https://arxiv.org/abs/2402.12366)

**PDF Link:** [https://arxiv.org/pdf/2402.12366](https://arxiv.org/pdf/2402.12366)

---

**Date:** 01 Dec 2023

**Title:** RLAIF: Scaling Reinforcement Learning from Human Feedback with AI  Feedback

**Abstract Link:** [https://arxiv.org/abs/2309.00267](https://arxiv.org/abs/2309.00267)

**PDF Link:** [https://arxiv.org/pdf/2309.00267](https://arxiv.org/pdf/2309.00267)

---

**Date:** 18 Aug 2023

**Title:** RLCD: Reinforcement Learning from Contrast Distillation for Language  Model Alignment

**Abstract Link:** [https://arxiv.org/abs/2307.12950](https://arxiv.org/abs/2307.12950)

**PDF Link:** [https://arxiv.org/pdf/2307.12950](https://arxiv.org/pdf/2307.12950)

---

**Date:** 16 Feb 2024

**Title:** Tuning Large Multimodal Models for Videos using Reinforcement Learning  from AI Feedback

**Abstract Link:** [https://arxiv.org/abs/2402.03746](https://arxiv.org/abs/2402.03746)

**PDF Link:** [https://arxiv.org/pdf/2402.03746](https://arxiv.org/pdf/2402.03746)

---

**Date:** 16 Oct 2023

**Title:** Verbosity Bias in Preference Labeling by Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.10076](https://arxiv.org/abs/2310.10076)

**PDF Link:** [https://arxiv.org/pdf/2310.10076](https://arxiv.org/pdf/2310.10076)

---

**Date:** 15 Dec 2022

**Title:** Constitutional AI: Harmlessness from AI Feedback

**Abstract Link:** [https://arxiv.org/abs/2212.08073](https://arxiv.org/abs/2212.08073)

**PDF Link:** [https://arxiv.org/pdf/2212.08073](https://arxiv.org/pdf/2212.08073)

---

**Date:** 29 Jan 2024

**Title:** Iterative Data Smoothing: Mitigating Reward Overfitting and  Overoptimization in RLHF

**Abstract Link:** [https://arxiv.org/abs/2401.16335](https://arxiv.org/abs/2401.16335)

**PDF Link:** [https://arxiv.org/pdf/2401.16335](https://arxiv.org/pdf/2401.16335)

---

**Date:** 11 Sep 2023

**Title:** Open Problems and Fundamental Limitations of Reinforcement Learning from  Human Feedback

**Abstract Link:** [https://arxiv.org/abs/2307.15217](https://arxiv.org/abs/2307.15217)

**PDF Link:** [https://arxiv.org/pdf/2307.15217](https://arxiv.org/pdf/2307.15217)

---

**Date:** 30 Jan 2024

**Title:** Improving Reinforcement Learning from Human Feedback with Efficient  Reward Model Ensemble

**Abstract Link:** [https://arxiv.org/abs/2401.16635](https://arxiv.org/abs/2401.16635)

**PDF Link:** [https://arxiv.org/pdf/2401.16635](https://arxiv.org/pdf/2401.16635)

---

**Date:** 16 Nov 2023

**Title:** On the Exploitability of Reinforcement Learning with Human Feedback for  Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2311.09641](https://arxiv.org/abs/2311.09641)

**PDF Link:** [https://arxiv.org/pdf/2311.09641](https://arxiv.org/pdf/2311.09641)

---

**Date:** 06 Feb 2024

**Title:** Personalized Language Modeling from Personalized Human Feedback

**Abstract Link:** [https://arxiv.org/abs/2402.05133](https://arxiv.org/abs/2402.05133)

**PDF Link:** [https://arxiv.org/pdf/2402.05133](https://arxiv.org/pdf/2402.05133)

---

**Date:** 15 Nov 2023

**Title:** Aligning Neural Machine Translation Models: Human Feedback in Training  and Inference

**Abstract Link:** [https://arxiv.org/abs/2311.09132](https://arxiv.org/abs/2311.09132)

**PDF Link:** [https://arxiv.org/pdf/2311.09132](https://arxiv.org/pdf/2311.09132)

---

**Date:** 02 Oct 2023

**Title:** UltraFeedback: Boosting Language Models with High-quality Feedback

**Abstract Link:** [https://arxiv.org/abs/2310.01377](https://arxiv.org/abs/2310.01377)

**PDF Link:** [https://arxiv.org/pdf/2310.01377](https://arxiv.org/pdf/2310.01377)

---

**Date:** 12 Feb 2024

**Title:** Universal Jailbreak Backdoors from Poisoned Human Feedback

**Abstract Link:** [https://arxiv.org/abs/2311.14455](https://arxiv.org/abs/2311.14455)

**PDF Link:** [https://arxiv.org/pdf/2311.14455](https://arxiv.org/pdf/2311.14455)

---

**Date:** 24 May 2023

**Title:** HuatuoGPT, towards Taming Language Model to Be a Doctor

**Abstract Link:** [https://arxiv.org/abs/2305.15075](https://arxiv.org/abs/2305.15075)

**PDF Link:** [https://arxiv.org/pdf/2305.15075](https://arxiv.org/pdf/2305.15075)

---

**Date:** 02 Feb 2024

**Title:** The Alignment Ceiling: Objective Mismatch in Reinforcement Learning from  Human Feedback

**Abstract Link:** [https://arxiv.org/abs/2311.00168](https://arxiv.org/abs/2311.00168)

**PDF Link:** [https://arxiv.org/pdf/2311.00168](https://arxiv.org/pdf/2311.00168)

---

**Date:** 19 Feb 2024

**Title:** Safer-Instruct: Aligning Language Models with Automated Preference Data

**Abstract Link:** [https://arxiv.org/abs/2311.08685](https://arxiv.org/abs/2311.08685)

**PDF Link:** [https://arxiv.org/pdf/2311.08685](https://arxiv.org/pdf/2311.08685)

---

**Date:** 10 Feb 2023

**Title:** The Wisdom of Hindsight Makes Language Models Better Instruction  Followers

**Abstract Link:** [https://arxiv.org/abs/2302.05206](https://arxiv.org/abs/2302.05206)

**PDF Link:** [https://arxiv.org/pdf/2302.05206](https://arxiv.org/pdf/2302.05206)

---

**Date:** 04 Oct 2023

**Title:** Reward Model Ensembles Help Mitigate Overoptimization

**Abstract Link:** [https://arxiv.org/abs/2310.02743](https://arxiv.org/abs/2310.02743)

**PDF Link:** [https://arxiv.org/pdf/2310.02743](https://arxiv.org/pdf/2310.02743)

---

**Date:** 16 Feb 2024

**Title:** Provably Sample Efficient RLHF via Active Preference Optimization

**Abstract Link:** [https://arxiv.org/abs/2402.10500](https://arxiv.org/abs/2402.10500)

**PDF Link:** [https://arxiv.org/pdf/2402.10500](https://arxiv.org/pdf/2402.10500)

---

