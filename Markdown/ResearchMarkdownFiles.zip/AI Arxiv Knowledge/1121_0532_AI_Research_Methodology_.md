AI Research Methodology 🧭

### 🔎 AI Research Methodology 🧭



# AI Research Methodology

## Introduction

Artificial Intelligence (AI) is a rapidly evolving field that has the potential to revolutionize many aspects of our lives. However, conducting research in this area can be challenging due to the complexity of the technology and the rapidly changing landscape. In this guide, we will provide an overview of the key steps involved in conducting AI research, including defining the research question, selecting the appropriate methodology, collecting and analyzing data, and communicating the results.

## Defining the Research Question

The first step in conducting AI research is to define the research question. This question should be specific, relevant, and feasible. It should also be grounded in existing literature and theory. When defining the research question, it is important to consider the following:

* What is the problem or issue that you are trying to address?
* Why is this problem or issue important?
* Who is affected by this problem or issue?
* What is the scope of the research question?
* What are the key variables or concepts that need to be considered?

## Selecting the Appropriate Methodology

Once the research question has been defined, the next step is to select the appropriate methodology. There are a variety of research designs and methods that can be used in AI research, including:

* Experimental designs: These involve manipulating one or more variables and measuring the effect on a dependent variable. Experimental designs are often used in AI research to evaluate the effectiveness of different algorithms or techniques.
* Survey research: This involves collecting data from a sample of participants using a standardized questionnaire. Surveys can be used to gather information about user preferences, attitudes, and behaviors.
* Case studies: These involve in-depth analysis of a single case or a small number of cases. Case studies can be used to gain a deeper understanding of a particular phenomenon or to explore the context in which AI is being used.
* Literature reviews: These involve systematically reviewing and synthesizing existing research on a particular topic. Literature reviews can be used to identify gaps in the literature, to develop new theories or frameworks, or to provide a foundation for future research.

When selecting the appropriate methodology, it is important to consider the research question, the research context, the available resources, and the ethical implications of the research.

## Collecting and Analyzing Data

Once the research
# 🩺🔍 Search Results
### 11 Aug 2023 | [Does AI for science need another ImageNet Or totally different  benchmarks? A case study of machine learning force fields](https://arxiv.org/abs/2308.05999) | [⬇️](https://arxiv.org/pdf/2308.05999)
*Yatao Li, Wanling Gao, Lei Wang, Lixin Sun, Zun Wang, Jianfeng Zhan* 

  AI for science (AI4S) is an emerging research field that aims to enhance the
accuracy and speed of scientific computing tasks using machine learning
methods. Traditional AI benchmarking methods struggle to adapt to the unique
challenges posed by AI4S because they assume data in training, testing, and
future real-world queries are independent and identically distributed, while
AI4S workloads anticipate out-of-distribution problem instances. This paper
investigates the need for a novel approach to effectively benchmark AI for
science, using the machine learning force field (MLFF) as a case study. MLFF is
a method to accelerate molecular dynamics (MD) simulation with low
computational cost and high accuracy. We identify various missed opportunities
in scientifically meaningful benchmarking and propose solutions to evaluate
MLFF models, specifically in the aspects of sample efficiency, time domain
sensitivity, and cross-dataset generalization capabilities. By setting up the
problem instantiation similar to the actual scientific applications, more
meaningful performance metrics from the benchmark can be achieved. This suite
of metrics has demonstrated a better ability to assess a model's performance in
real-world scientific applications, in contrast to traditional AI benchmarking
methodologies. This work is a component of the SAIBench project, an AI4S
benchmarking suite. The project homepage is
https://www.computercouncil.org/SAIBench.

---------------

### 27 Sep 2023 | [Collect, Measure, Repeat: Reliability Factors for Responsible AI Data  Collection](https://arxiv.org/abs/2308.12885) | [⬇️](https://arxiv.org/pdf/2308.12885)
*Oana Inel, Tim Draws and Lora Aroyo* 

  The rapid entry of machine learning approaches in our daily activities and
high-stakes domains demands transparency and scrutiny of their fairness and
reliability. To help gauge machine learning models' robustness, research
typically focuses on the massive datasets used for their deployment, e.g.,
creating and maintaining documentation for understanding their origin, process
of development, and ethical considerations. However, data collection for AI is
still typically a one-off practice, and oftentimes datasets collected for a
certain purpose or application are reused for a different problem.
Additionally, dataset annotations may not be representative over time, contain
ambiguous or erroneous annotations, or be unable to generalize across issues or
domains. Recent research has shown these practices might lead to unfair,
biased, or inaccurate outcomes. We argue that data collection for AI should be
performed in a responsible manner where the quality of the data is thoroughly
scrutinized and measured through a systematic set of appropriate metrics. In
this paper, we propose a Responsible AI (RAI) methodology designed to guide the
data collection with a set of metrics for an iterative in-depth analysis of the
factors influencing the quality and reliability} of the generated data. We
propose a granular set of measurements to inform on the internal reliability of
a dataset and its external stability over time. We validate our approach across
nine existing datasets and annotation tasks and four content modalities. This
approach impacts the assessment of data robustness used for AI applied in the
real world, where diversity of users and content is eminent. Furthermore, it
deals with fairness and accountability aspects in data collection by providing
systematic and transparent quality analysis for data collections.

---------------

### 13 Feb 2024 | [Artificial Intelligence for Literature Reviews: Opportunities and  Challenges](https://arxiv.org/abs/2402.08565) | [⬇️](https://arxiv.org/pdf/2402.08565)
*Francisco Bolanos, Angelo Salatino, Francesco Osborne, Enrico Motta* 

  This manuscript presents a comprehensive review of the use of Artificial
Intelligence (AI) in Systematic Literature Reviews (SLRs). A SLR is a rigorous
and organised methodology that assesses and integrates previous research on a
given topic. Numerous tools have been developed to assist and partially
automate the SLR process. The increasing role of AI in this field shows great
potential in providing more effective support for researchers, moving towards
the semi-automatic creation of literature reviews. Our study focuses on how AI
techniques are applied in the semi-automation of SLRs, specifically in the
screening and extraction phases. We examine 21 leading SLR tools using a
framework that combines 23 traditional features with 11 AI features. We also
analyse 11 recent tools that leverage large language models for searching the
literature and assisting academic writing. Finally, the paper discusses current
trends in the field, outlines key research challenges, and suggests directions
for future research.

---------------

### 22 Jun 2018 | [The Foundations of Deep Learning with a Path Towards General  Intelligence](https://arxiv.org/abs/1806.08874) | [⬇️](https://arxiv.org/pdf/1806.08874)
*Eray \"Ozkural* 

  Like any field of empirical science, AI may be approached axiomatically. We
formulate requirements for a general-purpose, human-level AI system in terms of
postulates. We review the methodology of deep learning, examining the explicit
and tacit assumptions in deep learning research. Deep Learning methodology
seeks to overcome limitations in traditional machine learning research as it
combines facets of model richness, generality, and practical applicability. The
methodology so far has produced outstanding results due to a productive synergy
of function approximation, under plausible assumptions of irreducibility and
the efficiency of back-propagation family of algorithms. We examine these
winning traits of deep learning, and also observe the various known failure
modes of deep learning. We conclude by giving recommendations on how to extend
deep learning methodology to cover the postulates of general-purpose AI
including modularity, and cognitive architecture. We also relate deep learning
to advances in theoretical neuroscience research.

---------------

### 06 Oct 2021 | [A curated, ontology-based, large-scale knowledge graph of artificial  intelligence tasks and benchmarks](https://arxiv.org/abs/2110.01434) | [⬇️](https://arxiv.org/pdf/2110.01434)
*Kathrin Blagec, Adriano Barbosa-Silva, Simon Ott, Matthias Samwald* 

  Research in artificial intelligence (AI) is addressing a growing number of
tasks through a rapidly growing number of models and methodologies. This makes
it difficult to keep track of where novel AI methods are successfully -- or
still unsuccessfully -- applied, how progress is measured, how different
advances might synergize with each other, and how future research should be
prioritized.
  To help address these issues, we created the Intelligence Task Ontology and
Knowledge Graph (ITO), a comprehensive, richly structured and manually curated
resource on artificial intelligence tasks, benchmark results and performance
metrics. The current version of ITO contain 685,560 edges, 1,100 classes
representing AI processes and 1,995 properties representing performance
metrics.
  The goal of ITO is to enable precise and network-based analyses of the global
landscape of AI tasks and capabilities. ITO is based on technologies that allow
for easy integration and enrichment with external data, automated inference and
continuous, collaborative expert curation of underlying ontological models. We
make the ITO dataset and a collection of Jupyter notebooks utilising ITO openly
available.

---------------

### 18 Nov 2023 | [Best uses of ChatGPT and Generative AI for computer science research](https://arxiv.org/abs/2311.11175) | [⬇️](https://arxiv.org/pdf/2311.11175)
*Eduardo C. Garrido-Merchan* 

  Generative Artificial Intelligence (AI), particularly tools like OpenAI's
popular ChatGPT, is reshaping the landscape of computer science research. Used
wisely, these tools can boost the productivity of a computer research
scientist. This paper provides an exploration of the diverse applications of
ChatGPT and other generative AI technologies in computer science academic
research, making recommendations about the use of Generative AI to make more
productive the role of the computer research scientist, with the focus of
writing new research papers. We highlight innovative uses such as brainstorming
research ideas, aiding in the drafting and styling of academic papers and
assisting in the synthesis of state-of-the-art section. Further, we delve into
using these technologies in understanding interdisciplinary approaches, making
complex texts simpler, and recommending suitable academic journals for
publication. Significant focus is placed on generative AI's contributions to
synthetic data creation, research methodology, and mentorship, as well as in
task organization and article quality assessment. The paper also addresses the
utility of AI in article review, adapting texts to length constraints,
constructing counterarguments, and survey development. Moreover, we explore the
capabilities of these tools in disseminating ideas, generating images and
audio, text transcription, and engaging with editors. We also describe some
non-recommended uses of generative AI for computer science research, mainly
because of the limitations of this technology.

---------------

### 27 Jan 2023 | [Exploring External Knowledge for Accurate modeling of Visual and  Language Problems](https://arxiv.org/abs/2302.08901) | [⬇️](https://arxiv.org/pdf/2302.08901)
*Xuewen Yang* 

  The interest in Artificial Intelligence (AI) and its applications has seen
unprecedented growth in the last few years. The success can be partly
attributed to the advancements of deep neural networks made in the sub-fields
of AI such as Computer Vision (CV) and Natural Language Processing (NLP). The
promising research area that this dissertation focuses on is visual and
language understanding which involves many challenging tasks, i.e.,
classification, detection, segmentation, machine translation and captioning,
etc. The state-of-the-art methods for solving these problems usually involves
only two parts: source data and target labels, which is rather insufficient
especially when the dataset is small. Meanwhile, many external tools or sources
can provide extra useful information (external knowledge) that can help improve
the performance of these methods. For example, a detection model has been
applied to provide better object features than state-of-the-art ResNet for
image captioning models. Inspired by this observation, we developed a
methodology that we can first extract external knowledge and then integrate it
with the original models. The external knowledge has to be extracted from the
dataset, or can directly come from external, e.g., grammar rules or scene
graphs. We apply this methodology to different AI tasks, including machine
translation and image captioning and improve the original state-of-the-art
models by a large margin.

---------------

### 02 Feb 2022 | [AI Research Associate for Early-Stage Scientific Discovery](https://arxiv.org/abs/2202.03199) | [⬇️](https://arxiv.org/pdf/2202.03199)
*Morad Behandish, John Maxwell III, Johan de Kleer* 

  Artificial intelligence (AI) has been increasingly applied in scientific
activities for decades; however, it is still far from an insightful and
trustworthy collaborator in the scientific process. Most existing AI methods
are either too simplistic to be useful in real problems faced by scientists or
too domain-specialized (even dogmatized), stifling transformative discoveries
or paradigm shifts. We present an AI research associate for early-stage
scientific discovery based on (a) a novel minimally-biased ontology for
physics-based modeling that is context-aware, interpretable, and generalizable
across classical and relativistic physics; (b) automatic search for viable and
parsimonious hypotheses, represented at a high-level (via domain-agnostic
constructs) with built-in invariants, e.g., postulated forms of conservation
principles implied by a presupposed spacetime topology; and (c) automatic
compilation of the enumerated hypotheses to domain-specific, interpretable, and
trainable/testable tensor-based computation graphs to learn phenomenological
relations, e.g., constitutive or material laws, from sparse (and possibly
noisy) data sets.

---------------

### 23 Jul 2022 | [A Historical Interaction between Artificial Intelligence and Philosophy](https://arxiv.org/abs/2208.04148) | [⬇️](https://arxiv.org/pdf/2208.04148)
*Youheng Zhang* 

  This paper reviews the historical development of AI and representative
philosophical thinking from the perspective of the research paradigm.
Additionally, it considers the methodology and applications of AI from a
philosophical perspective and anticipates its continued advancement. In the
history of AI, Symbolism and connectionism are the two main paradigms in AI
research. Symbolism holds that the world can be explained by symbols and dealt
with through precise, logical processes, but connectionism believes this
process should be implemented through artificial neural networks. Regardless of
how intelligent machines or programs should achieve their smart goals, the
historical development of AI demonstrates the best answer at this time. Still,
it is not the final answer of AI research.

---------------

### 14 Dec 2022 | [Explainable Artificial Intelligence in Retinal Imaging for the detection  of Systemic Diseases](https://arxiv.org/abs/2212.07058) | [⬇️](https://arxiv.org/pdf/2212.07058)
*Ayushi Raj Bhatt, Rajkumar Vaghashiya, Meghna Kulkarni, Dr Prakash  Kamaraj* 

  Explainable Artificial Intelligence (AI) in the form of an interpretable and
semiautomatic approach to stage grading ocular pathologies such as Diabetic
retinopathy, Hypertensive retinopathy, and other retinopathies on the backdrop
of major systemic diseases. The experimental study aims to evaluate an
explainable staged grading process without using deep Convolutional Neural
Networks (CNNs) directly. Many current CNN-based deep neural networks used for
diagnosing retinal disorders might have appreciable performance but fail to
pinpoint the basis driving their decisions. To improve these decisions'
transparency, we have proposed a clinician-in-the-loop assisted intelligent
workflow that performs a retinal vascular assessment on the fundus images to
derive quantifiable and descriptive parameters. The retinal vessel parameters
meta-data serve as hyper-parameters for better interpretation and
explainability of decisions. The semiautomatic methodology aims to have a
federated approach to AI in healthcare applications with more inputs and
interpretations from clinicians. The baseline process involved in the machine
learning pipeline through image processing techniques for optic disc detection,
vessel segmentation, and arteriole/venule identification.

---------------

### 08 May 2022 | [A Survey on AI Sustainability: Emerging Trends on Learning Algorithms  and Research Challenges](https://arxiv.org/abs/2205.03824) | [⬇️](https://arxiv.org/pdf/2205.03824)
*Zhenghua Chen, Min Wu, Alvin Chan, Xiaoli Li, Yew-Soon Ong* 

  Artificial Intelligence (AI) is a fast-growing research and development (R&D)
discipline which is attracting increasing attention because of its promises to
bring vast benefits for consumers and businesses, with considerable benefits
promised in productivity growth and innovation. To date it has reported
significant accomplishments in many areas that have been deemed as challenging
for machines, ranging from computer vision, natural language processing, audio
analysis to smart sensing and many others. The technical trend in realizing the
successes has been towards increasing complex and large size AI models so as to
solve more complex problems at superior performance and robustness. This rapid
progress, however, has taken place at the expense of substantial environmental
costs and resources. Besides, debates on the societal impacts of AI, such as
fairness, safety and privacy, have continued to grow in intensity. These issues
have presented major concerns pertaining to the sustainable development of AI.
In this work, we review major trends in machine learning approaches that can
address the sustainability problem of AI. Specifically, we examine emerging AI
methodologies and algorithms for addressing the sustainability issue of AI in
two major aspects, i.e., environmental sustainability and social sustainability
of AI. We will also highlight the major limitations of existing studies and
propose potential research challenges and directions for the development of
next generation of sustainable AI techniques. We believe that this technical
review can help to promote a sustainable development of AI R&D activities for
the research community.

---------------

### 05 Jan 2024 | [Application of federated learning techniques for arrhythmia  classification using 12-lead ECG signals](https://arxiv.org/abs/2208.10993) | [⬇️](https://arxiv.org/pdf/2208.10993)
*Daniel Mauricio Jimenez Gutierrez, Hafiz Muuhammad Hassan, Lorella  Landi, Andrea Vitaletti and Ioannis Chatzigiannakis* 

  Artificial Intelligence-based (AI) analysis of large, curated medical
datasets is promising for providing early detection, faster diagnosis, and more
effective treatment using low-power Electrocardiography (ECG) monitoring
devices information. However, accessing sensitive medical data from diverse
sources is highly restricted since improper use, unsafe storage, or data
leakage could violate a person's privacy. This work uses a Federated Learning
(FL) privacy-preserving methodology to train AI models over heterogeneous sets
of high-definition ECG from 12-lead sensor arrays collected from six
heterogeneous sources. We evaluated the capacity of the resulting models to
achieve equivalent performance compared to state-of-the-art models trained in a
Centralized Learning (CL) fashion. Moreover, we assessed the performance of our
solution over Independent and Identical distributed (IID) and non-IID federated
data. Our methodology involves machine learning techniques based on Deep Neural
Networks and Long-Short-Term Memory models. It has a robust data preprocessing
pipeline with feature engineering, selection, and data balancing techniques.
Our AI models demonstrated comparable performance to models trained using CL,
IID, and non-IID approaches. They showcased advantages in reduced complexity
and faster training time, making them well-suited for cloud-edge architectures.

---------------

### 13 Apr 2021 | [LioNets: A Neural-Specific Local Interpretation Technique Exploiting  Penultimate Layer Information](https://arxiv.org/abs/2104.06057) | [⬇️](https://arxiv.org/pdf/2104.06057)
*Ioannis Mollas, Nick Bassiliades, Grigorios Tsoumakas* 

  Artificial Intelligence (AI) has a tremendous impact on the unexpected growth
of technology in almost every aspect. AI-powered systems are monitoring and
deciding about sensitive economic and societal issues. The future is towards
automation, and it must not be prevented. However, this is a conflicting
viewpoint for a lot of people, due to the fear of uncontrollable AI systems.
This concern could be reasonable if it was originating from considerations
associated with social issues, like gender-biased, or obscure decision-making
systems. Explainable AI (XAI) is recently treated as a huge step towards
reliable systems, enhancing the trust of people to AI. Interpretable machine
learning (IML), a subfield of XAI, is also an urgent topic of research. This
paper presents a small but significant contribution to the IML community,
focusing on a local-based, neural-specific interpretation process applied to
textual and time-series data. The proposed methodology introduces new
approaches to the presentation of feature importance based interpretations, as
well as the production of counterfactual words on textual datasets. Eventually,
an improved evaluation metric is introduced for the assessment of
interpretation techniques, which supports an extensive set of qualitative and
quantitative experiments.

---------------

### 12 Jan 2024 | [MERA: A Comprehensive LLM Evaluation in Russian](https://arxiv.org/abs/2401.04531) | [⬇️](https://arxiv.org/pdf/2401.04531)
*Alena Fenogenova, Artem Chervyakov, Nikita Martynov, Anastasia  Kozlova, Maria Tikhonova, Albina Akhmetgareeva, Anton Emelyanov, Denis  Shevelev, Pavel Lebedev, Leonid Sinev, Ulyana Isaeva, Katerina Kolomeytseva,  Daniil Moskovskiy, Elizaveta Goncharova, Nikita Savushkin, Polina Mikhailova,  Denis Dimitrov, Alexander Panchenko, Sergei Markov* 

  Over the past few years, one of the most notable advancements in AI research
has been in foundation models (FMs), headlined by the rise of language models
(LMs). As the models' size increases, LMs demonstrate enhancements in
measurable aspects and the development of new qualitative features. However,
despite researchers' attention and the rapid growth in LM application, the
capabilities, limitations, and associated risks still need to be better
understood. To address these issues, we introduce an open Multimodal Evaluation
of Russian-language Architectures (MERA), a new instruction benchmark for
evaluating foundation models oriented towards the Russian language. The
benchmark encompasses 21 evaluation tasks for generative models in 11 skill
domains and is designed as a black-box test to ensure the exclusion of data
leakage. The paper introduces a methodology to evaluate FMs and LMs in zero-
and few-shot fixed instruction settings that can be extended to other
modalities. We propose an evaluation methodology, an open-source code base for
the MERA assessment, and a leaderboard with a submission system. We evaluate
open LMs as baselines and find that they are still far behind the human level.
We publicly release MERA to guide forthcoming research, anticipate
groundbreaking model features, standardize the evaluation procedure, and
address potential societal drawbacks.

---------------

### 14 Feb 2023 | [Using Artificial Intelligence to aid Scientific Discovery of Climate  Tipping Points](https://arxiv.org/abs/2302.06852) | [⬇️](https://arxiv.org/pdf/2302.06852)
*Jennifer Sleeman, David Chung, Chace Ashcraft, Jay Brett, Anand  Gnanadesikan, Yannis Kevrekidis, Marisa Hughes, Thomas Haine, Marie-Aude  Pradal, Renske Gelderloos, Caroline Tang, Anshu Saksena, Larry White* 

  We propose a hybrid Artificial Intelligence (AI) climate modeling approach
that enables climate modelers in scientific discovery using a climate-targeted
simulation methodology based on a novel combination of deep neural networks and
mathematical methods for modeling dynamical systems. The simulations are
grounded by a neuro-symbolic language that both enables question answering of
what is learned by the AI methods and provides a means of explainability. We
describe how this methodology can be applied to the discovery of climate
tipping points and, in particular, the collapse of the Atlantic Meridional
Overturning Circulation (AMOC). We show how this methodology is able to predict
AMOC collapse with a high degree of accuracy using a surrogate climate model
for ocean interaction. We also show preliminary results of neuro-symbolic
method performance when translating between natural language questions and
symbolically learned representations. Our AI methodology shows promising early
results, potentially enabling faster climate tipping point related research
that would otherwise be computationally infeasible.

---------------

### 07 Dec 2022 | [SAIH: A Scalable Evaluation Methodology for Understanding AI Performance  Trend on HPC Systems](https://arxiv.org/abs/2212.03410) | [⬇️](https://arxiv.org/pdf/2212.03410)
*Jiangsu Du, Dongsheng Li, Yingpeng Wen, Jiazhi Jiang, Dan Huang,  Xiangke Liao, and Yutong Lu* 

  Novel artificial intelligence (AI) technology has expedited various
scientific research, e.g., cosmology, physics and bioinformatics, inevitably
becoming a significant category of workload on high performance computing (HPC)
systems. Existing AI benchmarks tend to customize well-recognized AI
applications, so as to evaluate the AI performance of HPC systems under
predefined problem size, in terms of datasets and AI models. Due to lack of
scalability on the problem size, static AI benchmarks might be under competent
to help understand the performance trend of evolving AI applications on HPC
systems, in particular, the scientific AI applications on large-scale systems.
  In this paper, we propose a scalable evaluation methodology (SAIH) for
analyzing the AI performance trend of HPC systems with scaling the problem
sizes of customized AI applications. To enable scalability, SAIH builds a set
of novel mechanisms for augmenting problem sizes. As the data and model
constantly scale, we can investigate the trend and range of AI performance on
HPC systems, and further diagnose system bottlenecks. To verify our
methodology, we augment a cosmological AI application to evaluate a real HPC
system equipped with GPUs as a case study of SAIH.

---------------

### 20 Dec 2023 | [Mini-GPTs: Efficient Large Language Models through Contextual Pruning](https://arxiv.org/abs/2312.12682) | [⬇️](https://arxiv.org/pdf/2312.12682)
*Tim Valicenti, Justice Vidal, Ritik Patnaik* 

  In AI research, the optimization of Large Language Models (LLMs) remains a
significant challenge, crucial for advancing the field's practical applications
and sustainability. Building upon the foundational work of Professor Song Han's
lab at MIT, this paper introduces a novel approach in developing Mini-GPTs via
contextual pruning. Our methodology strategically prunes the computational
architecture of traditional LLMs, like Phi-1.5, focusing on retaining core
functionalities while drastically reducing model sizes. We employ the technique
across diverse and complex datasets, including US law, Medical Q&A, Skyrim
dialogue, English-Taiwanese translation, and Economics articles. The results
underscore the efficiency and effectiveness of contextual pruning, not merely
as a theoretical concept but as a practical tool in developing domain-specific,
resource-efficient LLMs. Contextual pruning is a promising method for building
domain-specific LLMs, and this research is a building block towards future
development with more hardware compute, refined fine-tuning, and quantization.

---------------

### 27 Mar 2023 | [Artificial intelligence approaches for materials-by-design of energetic  materials: state-of-the-art, challenges, and future directions](https://arxiv.org/abs/2211.08179) | [⬇️](https://arxiv.org/pdf/2211.08179)
*Joseph B. Choi, Phong C. H. Nguyen, Oishik Sen, H. S. Udaykumar,  Stephen Baek* 

  Artificial intelligence (AI) is rapidly emerging as an enabling tool for
solving various complex materials design problems. This paper aims to review
recent advances in AI-driven materials-by-design and their applications to
energetic materials (EM). Trained with data from numerical simulations and/or
physical experiments, AI models can assimilate trends and patterns within the
design parameter space, identify optimal material designs (micro-morphologies,
combinations of materials in composites, etc.), and point to designs with
superior/targeted property and performance metrics. We review approaches
focusing on such capabilities with respect to the three main stages of
materials-by-design, namely representation learning of microstructure
morphology (i.e., shape descriptors), structure-property-performance (S-P-P)
linkage estimation, and optimization/design exploration. We provide a
perspective view of these methods in terms of their potential, practicality,
and efficacy towards the realization of materials-by-design. Specifically,
methods in the literature are evaluated in terms of their capacity to learn
from a small/limited number of data, computational complexity,
generalizability/scalability to other material species and operating
conditions, interpretability of the model predictions, and the burden of
supervision/data annotation. Finally, we suggest a few promising future
research directions for EM materials-by-design, such as meta-learning, active
learning, Bayesian learning, and semi-/weakly-supervised learning, to bridge
the gap between machine learning research and EM research.

---------------

### 23 Sep 2022 | [Predicting the Future of AI with AI: High-quality link prediction in an  exponentially growing knowledge network](https://arxiv.org/abs/2210.00881) | [⬇️](https://arxiv.org/pdf/2210.00881)
*Mario Krenn, Lorenzo Buffoni, Bruno Coutinho, Sagi Eppel, Jacob Gates  Foster, Andrew Gritsevskiy, Harlin Lee, Yichao Lu, Joao P. Moutinho, Nima  Sanjabi, Rishi Sonthalia, Ngoc Mai Tran, Francisco Valente, Yangxinyu Xie,  Rose Yu, Michael Kopp* 

  A tool that could suggest new personalized research directions and ideas by
taking insights from the scientific literature could significantly accelerate
the progress of science. A field that might benefit from such an approach is
artificial intelligence (AI) research, where the number of scientific
publications has been growing exponentially over the last years, making it
challenging for human researchers to keep track of the progress. Here, we use
AI techniques to predict the future research directions of AI itself. We
develop a new graph-based benchmark based on real-world data -- the
Science4Cast benchmark, which aims to predict the future state of an evolving
semantic network of AI. For that, we use more than 100,000 research papers and
build up a knowledge network with more than 64,000 concept nodes. We then
present ten diverse methods to tackle this task, ranging from pure statistical
to pure learning methods. Surprisingly, the most powerful methods use a
carefully curated set of network features, rather than an end-to-end AI
approach. It indicates a great potential that can be unleashed for purely ML
approaches without human knowledge. Ultimately, better predictions of new
future research directions will be a crucial component of more advanced
research suggestion tools.

---------------

### 20 Mar 2018 | [Closing the AI Knowledge Gap](https://arxiv.org/abs/1803.07233) | [⬇️](https://arxiv.org/pdf/1803.07233)
*Ziv Epstein, Blakeley H. Payne, Judy Hanwen Shen, Abhimanyu Dubey,  Bjarke Felbo, Matthew Groh, Nick Obradovich, Manuel Cebrian and Iyad Rahwan* 

  AI researchers employ not only the scientific method, but also methodology
from mathematics and engineering. However, the use of the scientific method -
specifically hypothesis testing - in AI is typically conducted in service of
engineering objectives. Growing interest in topics such as fairness and
algorithmic bias show that engineering-focused questions only comprise a subset
of the important questions about AI systems. This results in the AI Knowledge
Gap: the number of unique AI systems grows faster than the number of studies
that characterize these systems' behavior. To close this gap, we argue that the
study of AI could benefit from the greater inclusion of researchers who are
well positioned to formulate and test hypotheses about the behavior of AI
systems. We examine the barriers preventing social and behavioral scientists
from conducting such studies. Our diagnosis suggests that accelerating the
scientific study of AI systems requires new incentives for academia and
industry, mediated by new tools and institutions. To address these needs, we
propose a two-sided marketplace called TuringBox. On one side, AI contributors
upload existing and novel algorithms to be studied scientifically by others. On
the other side, AI examiners develop and post machine intelligence tasks
designed to evaluate and characterize algorithmic behavior. We discuss this
market's potential to democratize the scientific study of AI behavior, and thus
narrow the AI Knowledge Gap.

---------------
**Date:** 11 Aug 2023

**Title:** Does AI for science need another ImageNet Or totally different  benchmarks? A case study of machine learning force fields

**Abstract Link:** [https://arxiv.org/abs/2308.05999](https://arxiv.org/abs/2308.05999)

**PDF Link:** [https://arxiv.org/pdf/2308.05999](https://arxiv.org/pdf/2308.05999)

---

**Date:** 27 Sep 2023

**Title:** Collect, Measure, Repeat: Reliability Factors for Responsible AI Data  Collection

**Abstract Link:** [https://arxiv.org/abs/2308.12885](https://arxiv.org/abs/2308.12885)

**PDF Link:** [https://arxiv.org/pdf/2308.12885](https://arxiv.org/pdf/2308.12885)

---

**Date:** 13 Feb 2024

**Title:** Artificial Intelligence for Literature Reviews: Opportunities and  Challenges

**Abstract Link:** [https://arxiv.org/abs/2402.08565](https://arxiv.org/abs/2402.08565)

**PDF Link:** [https://arxiv.org/pdf/2402.08565](https://arxiv.org/pdf/2402.08565)

---

**Date:** 22 Jun 2018

**Title:** The Foundations of Deep Learning with a Path Towards General  Intelligence

**Abstract Link:** [https://arxiv.org/abs/1806.08874](https://arxiv.org/abs/1806.08874)

**PDF Link:** [https://arxiv.org/pdf/1806.08874](https://arxiv.org/pdf/1806.08874)

---

**Date:** 06 Oct 2021

**Title:** A curated, ontology-based, large-scale knowledge graph of artificial  intelligence tasks and benchmarks

**Abstract Link:** [https://arxiv.org/abs/2110.01434](https://arxiv.org/abs/2110.01434)

**PDF Link:** [https://arxiv.org/pdf/2110.01434](https://arxiv.org/pdf/2110.01434)

---

**Date:** 18 Nov 2023

**Title:** Best uses of ChatGPT and Generative AI for computer science research

**Abstract Link:** [https://arxiv.org/abs/2311.11175](https://arxiv.org/abs/2311.11175)

**PDF Link:** [https://arxiv.org/pdf/2311.11175](https://arxiv.org/pdf/2311.11175)

---

**Date:** 27 Jan 2023

**Title:** Exploring External Knowledge for Accurate modeling of Visual and  Language Problems

**Abstract Link:** [https://arxiv.org/abs/2302.08901](https://arxiv.org/abs/2302.08901)

**PDF Link:** [https://arxiv.org/pdf/2302.08901](https://arxiv.org/pdf/2302.08901)

---

**Date:** 02 Feb 2022

**Title:** AI Research Associate for Early-Stage Scientific Discovery

**Abstract Link:** [https://arxiv.org/abs/2202.03199](https://arxiv.org/abs/2202.03199)

**PDF Link:** [https://arxiv.org/pdf/2202.03199](https://arxiv.org/pdf/2202.03199)

---

**Date:** 23 Jul 2022

**Title:** A Historical Interaction between Artificial Intelligence and Philosophy

**Abstract Link:** [https://arxiv.org/abs/2208.04148](https://arxiv.org/abs/2208.04148)

**PDF Link:** [https://arxiv.org/pdf/2208.04148](https://arxiv.org/pdf/2208.04148)

---

**Date:** 14 Dec 2022

**Title:** Explainable Artificial Intelligence in Retinal Imaging for the detection  of Systemic Diseases

**Abstract Link:** [https://arxiv.org/abs/2212.07058](https://arxiv.org/abs/2212.07058)

**PDF Link:** [https://arxiv.org/pdf/2212.07058](https://arxiv.org/pdf/2212.07058)

---

**Date:** 08 May 2022

**Title:** A Survey on AI Sustainability: Emerging Trends on Learning Algorithms  and Research Challenges

**Abstract Link:** [https://arxiv.org/abs/2205.03824](https://arxiv.org/abs/2205.03824)

**PDF Link:** [https://arxiv.org/pdf/2205.03824](https://arxiv.org/pdf/2205.03824)

---

**Date:** 05 Jan 2024

**Title:** Application of federated learning techniques for arrhythmia  classification using 12-lead ECG signals

**Abstract Link:** [https://arxiv.org/abs/2208.10993](https://arxiv.org/abs/2208.10993)

**PDF Link:** [https://arxiv.org/pdf/2208.10993](https://arxiv.org/pdf/2208.10993)

---

**Date:** 13 Apr 2021

**Title:** LioNets: A Neural-Specific Local Interpretation Technique Exploiting  Penultimate Layer Information

**Abstract Link:** [https://arxiv.org/abs/2104.06057](https://arxiv.org/abs/2104.06057)

**PDF Link:** [https://arxiv.org/pdf/2104.06057](https://arxiv.org/pdf/2104.06057)

---

**Date:** 12 Jan 2024

**Title:** MERA: A Comprehensive LLM Evaluation in Russian

**Abstract Link:** [https://arxiv.org/abs/2401.04531](https://arxiv.org/abs/2401.04531)

**PDF Link:** [https://arxiv.org/pdf/2401.04531](https://arxiv.org/pdf/2401.04531)

---

**Date:** 14 Feb 2023

**Title:** Using Artificial Intelligence to aid Scientific Discovery of Climate  Tipping Points

**Abstract Link:** [https://arxiv.org/abs/2302.06852](https://arxiv.org/abs/2302.06852)

**PDF Link:** [https://arxiv.org/pdf/2302.06852](https://arxiv.org/pdf/2302.06852)

---

**Date:** 07 Dec 2022

**Title:** SAIH: A Scalable Evaluation Methodology for Understanding AI Performance  Trend on HPC Systems

**Abstract Link:** [https://arxiv.org/abs/2212.03410](https://arxiv.org/abs/2212.03410)

**PDF Link:** [https://arxiv.org/pdf/2212.03410](https://arxiv.org/pdf/2212.03410)

---

**Date:** 20 Dec 2023

**Title:** Mini-GPTs: Efficient Large Language Models through Contextual Pruning

**Abstract Link:** [https://arxiv.org/abs/2312.12682](https://arxiv.org/abs/2312.12682)

**PDF Link:** [https://arxiv.org/pdf/2312.12682](https://arxiv.org/pdf/2312.12682)

---

**Date:** 27 Mar 2023

**Title:** Artificial intelligence approaches for materials-by-design of energetic  materials: state-of-the-art, challenges, and future directions

**Abstract Link:** [https://arxiv.org/abs/2211.08179](https://arxiv.org/abs/2211.08179)

**PDF Link:** [https://arxiv.org/pdf/2211.08179](https://arxiv.org/pdf/2211.08179)

---

**Date:** 23 Sep 2022

**Title:** Predicting the Future of AI with AI: High-quality link prediction in an  exponentially growing knowledge network

**Abstract Link:** [https://arxiv.org/abs/2210.00881](https://arxiv.org/abs/2210.00881)

**PDF Link:** [https://arxiv.org/pdf/2210.00881](https://arxiv.org/pdf/2210.00881)

---

**Date:** 20 Mar 2018

**Title:** Closing the AI Knowledge Gap

**Abstract Link:** [https://arxiv.org/abs/1803.07233](https://arxiv.org/abs/1803.07233)

**PDF Link:** [https://arxiv.org/pdf/1803.07233](https://arxiv.org/pdf/1803.07233)

---

