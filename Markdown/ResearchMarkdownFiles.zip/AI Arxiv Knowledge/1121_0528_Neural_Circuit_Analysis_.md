Neural Circuit Analysis 🔌

### 🔎 Neural Circuit Analysis 🔌


===========================

This repository contains code for the analysis of neural circuits.














































































































































































































































































































































































































































































































# 🩺🔍 Search Results
### 22 Feb 2023 | [An Operator Theoretic Approach for Analyzing Sequence Neural Networks](https://arxiv.org/abs/2102.07824) | [⬇️](https://arxiv.org/pdf/2102.07824)
*Ilan Naiman and Omri Azencot* 

  Analyzing the inner mechanisms of deep neural networks is a fundamental task
in machine learning. Existing work provides limited analysis or it depends on
local theories, such as fixed-point analysis. In contrast, we propose to
analyze trained neural networks using an operator theoretic approach which is
rooted in Koopman theory, the Koopman Analysis of Neural Networks (KANN). Key
to our method is the Koopman operator, which is a linear object that globally
represents the dominant behavior of the network dynamics. The linearity of the
Koopman operator facilitates analysis via its eigenvectors and eigenvalues. Our
method reveals that the latter eigendecomposition holds semantic information
related to the neural network inner workings. For instance, the eigenvectors
highlight positive and negative n-grams in the sentiments analysis task;
similarly, the eigenvectors capture the salient features of healthy heart beat
signals in the ECG classification problem.

---------------

### 22 Dec 2023 | [Joint Learning Neuronal Skeleton and Brain Circuit Topology with  Permutation Invariant Encoders for Neuron Classification](https://arxiv.org/abs/2312.14518) | [⬇️](https://arxiv.org/pdf/2312.14518)
*Minghui Liao, Guojia Wan, Bo Du* 

  Determining the types of neurons within a nervous system plays a significant
role in the analysis of brain connectomics and the investigation of
neurological diseases. However, the efficiency of utilizing anatomical,
physiological, or molecular characteristics of neurons is relatively low and
costly. With the advancements in electron microscopy imaging and analysis
techniques for brain tissue, we are able to obtain whole-brain connectome
consisting neuronal high-resolution morphology and connectivity information.
However, few models are built based on such data for automated neuron
classification. In this paper, we propose NeuNet, a framework that combines
morphological information of neurons obtained from skeleton and topological
information between neurons obtained from neural circuit. Specifically, NeuNet
consists of three components, namely Skeleton Encoder, Connectome Encoder, and
Readout Layer. Skeleton Encoder integrates the local information of neurons in
a bottom-up manner, with a one-dimensional convolution in neural skeleton's
point data; Connectome Encoder uses a graph neural network to capture the
topological information of neural circuit; finally, Readout Layer fuses the
above two information and outputs classification results. We reprocess and
release two new datasets for neuron classification task from volume electron
microscopy(VEM) images of human brain cortex and Drosophila brain. Experiments
on these two datasets demonstrated the effectiveness of our model with accuracy
of 0.9169 and 0.9363, respectively. Code and data are available at:
https://github.com/WHUminghui/NeuNet.

---------------

### 29 Apr 2019 | [Convolutional nets for reconstructing neural circuits from brain images  acquired by serial section electron microscopy](https://arxiv.org/abs/1904.12966) | [⬇️](https://arxiv.org/pdf/1904.12966)
*Kisuk Lee, Nicholas Turner, Thomas Macrina, Jingpeng Wu, Ran Lu, H.  Sebastian Seung* 

  Neural circuits can be reconstructed from brain images acquired by serial
section electron microscopy. Image analysis has been performed by manual labor
for half a century, and efforts at automation date back almost as far.
Convolutional nets were first applied to neuronal boundary detection a dozen
years ago, and have now achieved impressive accuracy on clean images. Robust
handling of image defects is a major outstanding challenge. Convolutional nets
are also being employed for other tasks in neural circuit reconstruction:
finding synapses and identifying synaptic partners, extending or pruning
neuronal reconstructions, and aligning serial section images to create a 3D
image stack. Computational systems are being engineered to handle petavoxel
images of cubic millimeter brain volumes.

---------------

### 05 Sep 2023 | [Dynamic Brain Transformer with Multi-level Attention for Functional  Brain Network Analysis](https://arxiv.org/abs/2309.01941) | [⬇️](https://arxiv.org/pdf/2309.01941)
*Xuan Kan, Antonio Aodong Chen Gu, Hejie Cui, Ying Guo, Carl Yang* 

  Recent neuroimaging studies have highlighted the importance of
network-centric brain analysis, particularly with functional magnetic resonance
imaging. The emergence of Deep Neural Networks has fostered a substantial
interest in predicting clinical outcomes and categorizing individuals based on
brain networks. However, the conventional approach involving static brain
network analysis offers limited potential in capturing the dynamism of brain
function. Although recent studies have attempted to harness dynamic brain
networks, their high dimensionality and complexity present substantial
challenges. This paper proposes a novel methodology, Dynamic bRAin Transformer
(DART), which combines static and dynamic brain networks for more effective and
nuanced brain function analysis. Our model uses the static brain network as a
baseline, integrating dynamic brain networks to enhance performance against
traditional methods. We innovatively employ attention mechanisms, enhancing
model explainability and exploiting the dynamic brain network's temporal
variations. The proposed approach offers a robust solution to the low
signal-to-noise ratio of blood-oxygen-level-dependent signals, a recurring
issue in direct DNN modeling. It also provides valuable insights into which
brain circuits or dynamic networks contribute more to final predictions. As
such, DRAT shows a promising direction in neuroimaging studies, contributing to
the comprehensive understanding of brain organization and the role of neural
circuits.

---------------

### 17 Nov 2023 | [Uncovering Intermediate Variables in Transformers using Circuit Probing](https://arxiv.org/abs/2311.04354) | [⬇️](https://arxiv.org/pdf/2311.04354)
*Michael A. Lepori, Thomas Serre, Ellie Pavlick* 

  Neural network models have achieved high performance on a wide variety of
complex tasks, but the algorithms that they implement are notoriously difficult
to interpret. In order to understand these algorithms, it is often necessary to
hypothesize intermediate variables involved in the network's computation. For
example, does a language model depend on particular syntactic properties when
generating a sentence? However, existing analysis tools make it difficult to
test hypotheses of this type. We propose a new analysis technique -- circuit
probing -- that automatically uncovers low-level circuits that compute
hypothesized intermediate variables. This enables causal analysis through
targeted ablation at the level of model parameters. We apply this method to
models trained on simple arithmetic tasks, demonstrating its effectiveness at
(1) deciphering the algorithms that models have learned, (2) revealing modular
structure within a model, and (3) tracking the development of circuits over
training. We compare circuit probing to other methods across these three
experiments, and find it on par or more effective than existing analysis
methods. Finally, we demonstrate circuit probing on a real-world use case,
uncovering circuits that are responsible for subject-verb agreement and
reflexive anaphora in GPT2-Small and Medium.

---------------

### 21 Oct 2020 | [Deep Neural Networks Are Congestion Games: From Loss Landscape to  Wardrop Equilibrium and Beyond](https://arxiv.org/abs/2010.11024) | [⬇️](https://arxiv.org/pdf/2010.11024)
*Nina Vesseron, Ievgen Redko, Charlotte Laclau* 

  The theoretical analysis of deep neural networks (DNN) is arguably among the
most challenging research directions in machine learning (ML) right now, as it
requires from scientists to lay novel statistical learning foundations to
explain their behaviour in practice. While some success has been achieved
recently in this endeavour, the question on whether DNNs can be analyzed using
the tools from other scientific fields outside the ML community has not
received the attention it may well have deserved. In this paper, we explore the
interplay between DNNs and game theory (GT), and show how one can benefit from
the classic readily available results from the latter when analyzing the
former. In particular, we consider the widely studied class of congestion
games, and illustrate their intrinsic relatedness to both linear and non-linear
DNNs and to the properties of their loss surface. Beyond retrieving the
state-of-the-art results from the literature, we argue that our work provides a
very promising novel tool for analyzing the DNNs and support this claim by
proposing concrete open problems that can advance significantly our
understanding of DNNs when solved.

---------------

### 14 Jan 2023 | [First Three Years of the International Verification of Neural Networks  Competition (VNN-COMP)](https://arxiv.org/abs/2301.05815) | [⬇️](https://arxiv.org/pdf/2301.05815)
*Christopher Brix, Mark Niklas M\"uller, Stanley Bak, Taylor T.  Johnson, Changliu Liu* 

  This paper presents a summary and meta-analysis of the first three iterations
of the annual International Verification of Neural Networks Competition
(VNN-COMP) held in 2020, 2021, and 2022. In the VNN-COMP, participants submit
software tools that analyze whether given neural networks satisfy
specifications describing their input-output behavior. These neural networks
and specifications cover a variety of problem classes and tasks, corresponding
to safety and robustness properties in image classification, neural control,
reinforcement learning, and autonomous systems. We summarize the key processes,
rules, and results, present trends observed over the last three years, and
provide an outlook into possible future developments.

---------------

### 03 Sep 2014 | [Focused Proofreading: Efficiently Extracting Connectomes from Segmented  EM Images](https://arxiv.org/abs/1409.1199) | [⬇️](https://arxiv.org/pdf/1409.1199)
*Stephen M. Plaza* 

  Identifying complex neural circuitry from electron microscopic (EM) images
may help unlock the mysteries of the brain. However, identifying this circuitry
requires time-consuming, manual tracing (proofreading) due to the size and
intricacy of these image datasets, thus limiting state-of-the-art analysis to
very small brain regions. Potential avenues to improve scalability include
automatic image segmentation and crowd sourcing, but current efforts have had
limited success. In this paper, we propose a new strategy, focused
proofreading, that works with automatic segmentation and aims to limit
proofreading to the regions of a dataset that are most impactful to the
resulting circuit. We then introduce a novel workflow, which exploits
biological information such as synapses, and apply it to a large dataset in the
fly optic lobe. With our techniques, we achieve significant tracing speedups of
3-5x without sacrificing the quality of the resulting circuit. Furthermore, our
methodology makes the task of proofreading much more accessible and hence
potentially enhances the effectiveness of crowd sourcing.

---------------

### 01 Dec 2022 | [Experimental Observations of the Topology of Convolutional Neural  Network Activations](https://arxiv.org/abs/2212.00222) | [⬇️](https://arxiv.org/pdf/2212.00222)
*Emilie Purvine, Davis Brown, Brett Jefferson, Cliff Joslyn, Brenda  Praggastis, Archit Rathore, Madelyn Shapiro, Bei Wang, Youjia Zhou* 

  Topological data analysis (TDA) is a branch of computational mathematics,
bridging algebraic topology and data science, that provides compact,
noise-robust representations of complex structures. Deep neural networks (DNNs)
learn millions of parameters associated with a series of transformations
defined by the model architecture, resulting in high-dimensional,
difficult-to-interpret internal representations of input data. As DNNs become
more ubiquitous across multiple sectors of our society, there is increasing
recognition that mathematical methods are needed to aid analysts, researchers,
and practitioners in understanding and interpreting how these models' internal
representations relate to the final classification. In this paper, we apply
cutting edge techniques from TDA with the goal of gaining insight into the
interpretability of convolutional neural networks used for image
classification. We use two common TDA approaches to explore several methods for
modeling hidden-layer activations as high-dimensional point clouds, and provide
experimental evidence that these point clouds capture valuable structural
information about the model's process. First, we demonstrate that a distance
metric based on persistent homology can be used to quantify meaningful
differences between layers, and we discuss these distances in the broader
context of existing representational similarity metrics for neural network
interpretability. Second, we show that a mapper graph can provide semantic
insight into how these models organize hierarchical class knowledge at each
layer. These observations demonstrate that TDA is a useful tool to help deep
learning practitioners unlock the hidden structures of their models.

---------------

### 16 Oct 2022 | [Extrapolation and Spectral Bias of Neural Nets with Hadamard Product: a  Polynomial Net Study](https://arxiv.org/abs/2209.07736) | [⬇️](https://arxiv.org/pdf/2209.07736)
*Yongtao Wu, Zhenyu Zhu, Fanghui Liu, Grigorios G Chrysos, Volkan  Cevher* 

  Neural tangent kernel (NTK) is a powerful tool to analyze training dynamics
of neural networks and their generalization bounds. The study on NTK has been
devoted to typical neural network architectures, but it is incomplete for
neural networks with Hadamard products (NNs-Hp), e.g., StyleGAN and polynomial
neural networks (PNNs). In this work, we derive the finite-width NTK
formulation for a special class of NNs-Hp, i.e., polynomial neural networks. We
prove their equivalence to the kernel regression predictor with the associated
NTK, which expands the application scope of NTK. Based on our results, we
elucidate the separation of PNNs over standard neural networks with respect to
extrapolation and spectral bias. Our two key insights are that when compared to
standard neural networks, PNNs can fit more complicated functions in the
extrapolation regime and admit a slower eigenvalue decay of the respective NTK,
leading to a faster learning towards high-frequency functions. Besides, our
theoretical results can be extended to other types of NNs-Hp, which expand the
scope of our work. Our empirical results validate the separations in broader
classes of NNs-Hp, which provide a good justification for a deeper
understanding of neural architectures.

---------------

### 08 Dec 2023 | [On the Performance of Temporal Difference Learning With Neural Networks](https://arxiv.org/abs/2312.05397) | [⬇️](https://arxiv.org/pdf/2312.05397)
*Haoxing Tian, Ioannis Ch. Paschalidis, Alex Olshevsky* 

  Neural Temporal Difference (TD) Learning is an approximate temporal
difference method for policy evaluation that uses a neural network for function
approximation. Analysis of Neural TD Learning has proven to be challenging. In
this paper we provide a convergence analysis of Neural TD Learning with a
projection onto $B(\theta_0, \omega)$, a ball of fixed radius $\omega$ around
the initial point $\theta_0$. We show an approximation bound of $O(\epsilon) +
\tilde{O} (1/\sqrt{m})$ where $\epsilon$ is the approximation quality of the
best neural network in $B(\theta_0, \omega)$ and $m$ is the width of all hidden
layers in the network.

---------------

### 09 Dec 2021 | [The Fundamental Limits of Interval Arithmetic for Neural Networks](https://arxiv.org/abs/2112.05235) | [⬇️](https://arxiv.org/pdf/2112.05235)
*Matthew Mirman, Maximilian Baader, Martin Vechev* 

  Interval analysis (or interval bound propagation, IBP) is a popular technique
for verifying and training provably robust deep neural networks, a fundamental
challenge in the area of reliable machine learning. However, despite
substantial efforts, progress on addressing this key challenge has stagnated,
calling into question whether interval arithmetic is a viable path forward.
  In this paper we present two fundamental results on the limitations of
interval arithmetic for analyzing neural networks. Our main impossibility
theorem states that for any neural network classifying just three points, there
is a valid specification over these points that interval analysis can not
prove. Further, in the restricted case of one-hidden-layer neural networks we
show a stronger impossibility result: given any radius $\alpha < 1$, there is a
set of $O(\alpha^{-1})$ points with robust radius $\alpha$, separated by
distance $2$, that no one-hidden-layer network can be proven to classify
robustly via interval analysis.

---------------

### 08 Feb 2021 | [NeuralSens: Sensitivity Analysis of Neural Networks](https://arxiv.org/abs/2002.11423) | [⬇️](https://arxiv.org/pdf/2002.11423)
*J. Pizarroso, J. Portela and A. Mu\~noz* 

  Neural networks are important tools for data-intensive analysis and are
commonly applied to model non-linear relationships between dependent and
independent variables. However, neural networks are usually seen as "black
boxes" that offer minimal information about how the input variables are used to
predict the response in a fitted model. This article describes the
\pkg{NeuralSens} package that can be used to perform sensitivity analysis of
neural networks using the partial derivatives method. Functions in the package
can be used to obtain the sensitivities of the output with respect to the input
variables, evaluate variable importance based on sensitivity measures and
characterize relationships between input and output variables. Methods to
calculate sensitivities are provided for objects from common neural network
packages in \proglang{R}, including \pkg{neuralnet}, \pkg{nnet}, \pkg{RSNNS},
\pkg{h2o}, \pkg{neural}, \pkg{forecast} and \pkg{caret}. The article presents
an overview of the techniques for obtaining information from neural network
models, a theoretical foundation of how are calculated the partial derivatives
of the output with respect to the inputs of a multi-layer perceptron model, a
description of the package structure and functions, and applied examples to
compare \pkg{NeuralSens} functions with analogous functions from other
available \proglang{R} packages.

---------------

### 06 Dec 2023 | [What Planning Problems Can A Relational Neural Network Solve?](https://arxiv.org/abs/2312.03682) | [⬇️](https://arxiv.org/pdf/2312.03682)
*Jiayuan Mao, Tom\'as Lozano-P\'erez, Joshua B. Tenenbaum, Leslie Pack  Kaelbling* 

  Goal-conditioned policies are generally understood to be "feed-forward"
circuits, in the form of neural networks that map from the current state and
the goal specification to the next action to take. However, under what
circumstances such a policy can be learned and how efficient the policy will be
are not well understood. In this paper, we present a circuit complexity
analysis for relational neural networks (such as graph neural networks and
transformers) representing policies for planning problems, by drawing
connections with serialized goal regression search (S-GRS). We show that there
are three general classes of planning problems, in terms of the growth of
circuit width and depth as a function of the number of objects and planning
horizon, providing constructive proofs. We also illustrate the utility of this
analysis for designing neural networks for policy learning.

---------------

### 24 May 2019 | [Graph Warp Module: an Auxiliary Module for Boosting the Power of Graph  Neural Networks in Molecular Graph Analysis](https://arxiv.org/abs/1902.01020) | [⬇️](https://arxiv.org/pdf/1902.01020)
*Katsuhiko Ishiguro, Shin-ichi Maeda, and Masanori Koyama* 

  Graph Neural Network (GNN) is a popular architecture for the analysis of
chemical molecules, and it has numerous applications in material and medicinal
science. Current lines of GNNs developed for molecular analysis, however, do
not fit well on the training set, and their performance does not scale well
with the complexity of the network. In this paper, we propose an auxiliary
module to be attached to a GNN that can boost the representation power of the
model without hindering with the original GNN architecture. Our auxiliary
module can be attached to a wide variety of GNNs, including those that are used
commonly in biochemical applications. With our auxiliary architecture, the
performances of many GNNs used in practice improve more consistently, achieving
the state-of-the-art performance on popular molecular graph datasets.

---------------

### 12 Apr 2020 | [NNV: The Neural Network Verification Tool for Deep Neural Networks and  Learning-Enabled Cyber-Physical Systems](https://arxiv.org/abs/2004.05519) | [⬇️](https://arxiv.org/pdf/2004.05519)
*Hoang-Dung Tran, Xiaodong Yang, Diego Manzanas Lopez, Patrick Musau,  Luan Viet Nguyen, Weiming Xiang, Stanley Bak and Taylor T. Johnson* 

  This paper presents the Neural Network Verification (NNV) software tool, a
set-based verification framework for deep neural networks (DNNs) and
learning-enabled cyber-physical systems (CPS). The crux of NNV is a collection
of reachability algorithms that make use of a variety of set representations,
such as polyhedra, star sets, zonotopes, and abstract-domain representations.
NNV supports both exact (sound and complete) and over-approximate (sound)
reachability algorithms for verifying safety and robustness properties of
feed-forward neural networks (FFNNs) with various activation functions. For
learning-enabled CPS, such as closed-loop control systems incorporating neural
networks, NNV provides exact and over-approximate reachability analysis schemes
for linear plant models and FFNN controllers with piecewise-linear activation
functions, such as ReLUs. For similar neural network control systems (NNCS)
that instead have nonlinear plant models, NNV supports over-approximate
analysis by combining the star set analysis used for FFNN controllers with
zonotope-based analysis for nonlinear plant dynamics building on CORA. We
evaluate NNV using two real-world case studies: the first is safety
verification of ACAS Xu networks and the second deals with the safety
verification of a deep learning-based adaptive cruise control system.

---------------

### 08 Feb 2024 | [Neural Circuit Diagrams: Robust Diagrams for the Communication,  Implementation, and Analysis of Deep Learning Architectures](https://arxiv.org/abs/2402.05424) | [⬇️](https://arxiv.org/pdf/2402.05424)
*Vincent Abbott* 

  Diagrams matter. Unfortunately, the deep learning community has no standard
method for diagramming architectures. The current combination of linear algebra
notation and ad-hoc diagrams fails to offer the necessary precision to
understand architectures in all their detail. However, this detail is critical
for faithful implementation, mathematical analysis, further innovation, and
ethical assurances. I present neural circuit diagrams, a graphical language
tailored to the needs of communicating deep learning architectures. Neural
circuit diagrams naturally keep track of the changing arrangement of data,
precisely show how operations are broadcast over axes, and display the critical
parallel behavior of linear operations. A lingering issue with existing
diagramming methods is the inability to simultaneously express the detail of
axes and the free arrangement of data, which neural circuit diagrams solve.
Their compositional structure is analogous to code, creating a close
correspondence between diagrams and implementation.
  In this work, I introduce neural circuit diagrams for an audience of machine
learning researchers. After introducing neural circuit diagrams, I cover a host
of architectures to show their utility and breed familiarity. This includes the
transformer architecture, convolution (and its difficult-to-explain
extensions), residual networks, the U-Net, and the vision transformer. I
include a Jupyter notebook that provides evidence for the close correspondence
between diagrams and code. Finally, I examine backpropagation using neural
circuit diagrams. I show their utility in providing mathematical insight and
analyzing algorithms' time and space complexities.

---------------

### 25 Sep 2019 | [Information Plane Analysis of Deep Neural Networks via Matrix-Based  Renyi's Entropy and Tensor Kernels](https://arxiv.org/abs/1909.11396) | [⬇️](https://arxiv.org/pdf/1909.11396)
*Kristoffer Wickstr{\o}m, Sigurd L{\o}kse, Michael Kampffmeyer, Shujian  Yu, Jose Principe, Robert Jenssen* 

  Analyzing deep neural networks (DNNs) via information plane (IP) theory has
gained tremendous attention recently as a tool to gain insight into, among
others, their generalization ability. However, it is by no means obvious how to
estimate mutual information (MI) between each hidden layer and the
input/desired output, to construct the IP. For instance, hidden layers with
many neurons require MI estimators with robustness towards the high
dimensionality associated with such layers. MI estimators should also be able
to naturally handle convolutional layers, while at the same time being
computationally tractable to scale to large networks. None of the existing IP
methods to date have been able to study truly deep Convolutional Neural
Networks (CNNs), such as the e.g.\ VGG-16. In this paper, we propose an IP
analysis using the new matrix--based R\'enyi's entropy coupled with tensor
kernels over convolutional layers, leveraging the power of kernel methods to
represent properties of the probability distribution independently of the
dimensionality of the data. The obtained results shed new light on the previous
literature concerning small-scale DNNs, however using a completely new
approach. Importantly, the new framework enables us to provide the first
comprehensive IP analysis of contemporary large-scale DNNs and CNNs,
investigating the different training phases and providing new insights into the
training dynamics of large-scale neural networks.

---------------

### 29 Oct 2018 | [Mean-field theory of graph neural networks in graph partitioning](https://arxiv.org/abs/1810.11908) | [⬇️](https://arxiv.org/pdf/1810.11908)
*Tatsuro Kawamoto, Masashi Tsubaki, Tomoyuki Obuchi* 

  A theoretical performance analysis of the graph neural network (GNN) is
presented. For classification tasks, the neural network approach has the
advantage in terms of flexibility that it can be employed in a data-driven
manner, whereas Bayesian inference requires the assumption of a specific model.
A fundamental question is then whether GNN has a high accuracy in addition to
this flexibility. Moreover, whether the achieved performance is predominately a
result of the backpropagation or the architecture itself is a matter of
considerable interest. To gain a better insight into these questions, a
mean-field theory of a minimal GNN architecture is developed for the graph
partitioning problem. This demonstrates a good agreement with numerical
experiments.

---------------

### 14 Mar 2023 | [Reachability Analysis of Neural Networks with Uncertain Parameters](https://arxiv.org/abs/2303.07917) | [⬇️](https://arxiv.org/pdf/2303.07917)
*Pierre-Jean Meyer* 

  The literature on reachability analysis methods for neural networks currently
only focuses on uncertainties on the network's inputs. In this paper, we
introduce two new approaches for the reachability analysis of neural networks
with additional uncertainties on their internal parameters (weight matrices and
bias vectors of each layer), which may open the field of formal methods on
neural networks to new topics, such as safe training or network repair. The
first and main method that we propose relies on existing reachability analysis
approach based on mixed monotonicity (initially introduced for dynamical
systems). The second proposed approach extends the ESIP (Error-based Symbolic
Interval Propagation) approach which was first implemented in the verification
tool Neurify, and first mentioned in the publication of the tool VeriNet.
Although the ESIP approach has been shown to often outperform the
mixed-monotonicity reachability analysis in the classical case with
uncertainties only on the network's inputs, we show in this paper through
numerical simulations that the situation is greatly reversed (in terms of
precision, computation time, memory usage, and broader applicability) when
dealing with uncertainties on the weights and biases.

---------------
**Date:** 22 Feb 2023

**Title:** An Operator Theoretic Approach for Analyzing Sequence Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2102.07824](https://arxiv.org/abs/2102.07824)

**PDF Link:** [https://arxiv.org/pdf/2102.07824](https://arxiv.org/pdf/2102.07824)

---

**Date:** 22 Dec 2023

**Title:** Joint Learning Neuronal Skeleton and Brain Circuit Topology with  Permutation Invariant Encoders for Neuron Classification

**Abstract Link:** [https://arxiv.org/abs/2312.14518](https://arxiv.org/abs/2312.14518)

**PDF Link:** [https://arxiv.org/pdf/2312.14518](https://arxiv.org/pdf/2312.14518)

---

**Date:** 29 Apr 2019

**Title:** Convolutional nets for reconstructing neural circuits from brain images  acquired by serial section electron microscopy

**Abstract Link:** [https://arxiv.org/abs/1904.12966](https://arxiv.org/abs/1904.12966)

**PDF Link:** [https://arxiv.org/pdf/1904.12966](https://arxiv.org/pdf/1904.12966)

---

**Date:** 05 Sep 2023

**Title:** Dynamic Brain Transformer with Multi-level Attention for Functional  Brain Network Analysis

**Abstract Link:** [https://arxiv.org/abs/2309.01941](https://arxiv.org/abs/2309.01941)

**PDF Link:** [https://arxiv.org/pdf/2309.01941](https://arxiv.org/pdf/2309.01941)

---

**Date:** 17 Nov 2023

**Title:** Uncovering Intermediate Variables in Transformers using Circuit Probing

**Abstract Link:** [https://arxiv.org/abs/2311.04354](https://arxiv.org/abs/2311.04354)

**PDF Link:** [https://arxiv.org/pdf/2311.04354](https://arxiv.org/pdf/2311.04354)

---

**Date:** 21 Oct 2020

**Title:** Deep Neural Networks Are Congestion Games: From Loss Landscape to  Wardrop Equilibrium and Beyond

**Abstract Link:** [https://arxiv.org/abs/2010.11024](https://arxiv.org/abs/2010.11024)

**PDF Link:** [https://arxiv.org/pdf/2010.11024](https://arxiv.org/pdf/2010.11024)

---

**Date:** 14 Jan 2023

**Title:** First Three Years of the International Verification of Neural Networks  Competition (VNN-COMP)

**Abstract Link:** [https://arxiv.org/abs/2301.05815](https://arxiv.org/abs/2301.05815)

**PDF Link:** [https://arxiv.org/pdf/2301.05815](https://arxiv.org/pdf/2301.05815)

---

**Date:** 03 Sep 2014

**Title:** Focused Proofreading: Efficiently Extracting Connectomes from Segmented  EM Images

**Abstract Link:** [https://arxiv.org/abs/1409.1199](https://arxiv.org/abs/1409.1199)

**PDF Link:** [https://arxiv.org/pdf/1409.1199](https://arxiv.org/pdf/1409.1199)

---

**Date:** 01 Dec 2022

**Title:** Experimental Observations of the Topology of Convolutional Neural  Network Activations

**Abstract Link:** [https://arxiv.org/abs/2212.00222](https://arxiv.org/abs/2212.00222)

**PDF Link:** [https://arxiv.org/pdf/2212.00222](https://arxiv.org/pdf/2212.00222)

---

**Date:** 16 Oct 2022

**Title:** Extrapolation and Spectral Bias of Neural Nets with Hadamard Product: a  Polynomial Net Study

**Abstract Link:** [https://arxiv.org/abs/2209.07736](https://arxiv.org/abs/2209.07736)

**PDF Link:** [https://arxiv.org/pdf/2209.07736](https://arxiv.org/pdf/2209.07736)

---

**Date:** 08 Dec 2023

**Title:** On the Performance of Temporal Difference Learning With Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2312.05397](https://arxiv.org/abs/2312.05397)

**PDF Link:** [https://arxiv.org/pdf/2312.05397](https://arxiv.org/pdf/2312.05397)

---

**Date:** 09 Dec 2021

**Title:** The Fundamental Limits of Interval Arithmetic for Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2112.05235](https://arxiv.org/abs/2112.05235)

**PDF Link:** [https://arxiv.org/pdf/2112.05235](https://arxiv.org/pdf/2112.05235)

---

**Date:** 08 Feb 2021

**Title:** NeuralSens: Sensitivity Analysis of Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2002.11423](https://arxiv.org/abs/2002.11423)

**PDF Link:** [https://arxiv.org/pdf/2002.11423](https://arxiv.org/pdf/2002.11423)

---

**Date:** 06 Dec 2023

**Title:** What Planning Problems Can A Relational Neural Network Solve?

**Abstract Link:** [https://arxiv.org/abs/2312.03682](https://arxiv.org/abs/2312.03682)

**PDF Link:** [https://arxiv.org/pdf/2312.03682](https://arxiv.org/pdf/2312.03682)

---

**Date:** 24 May 2019

**Title:** Graph Warp Module: an Auxiliary Module for Boosting the Power of Graph  Neural Networks in Molecular Graph Analysis

**Abstract Link:** [https://arxiv.org/abs/1902.01020](https://arxiv.org/abs/1902.01020)

**PDF Link:** [https://arxiv.org/pdf/1902.01020](https://arxiv.org/pdf/1902.01020)

---

**Date:** 12 Apr 2020

**Title:** NNV: The Neural Network Verification Tool for Deep Neural Networks and  Learning-Enabled Cyber-Physical Systems

**Abstract Link:** [https://arxiv.org/abs/2004.05519](https://arxiv.org/abs/2004.05519)

**PDF Link:** [https://arxiv.org/pdf/2004.05519](https://arxiv.org/pdf/2004.05519)

---

**Date:** 08 Feb 2024

**Title:** Neural Circuit Diagrams: Robust Diagrams for the Communication,  Implementation, and Analysis of Deep Learning Architectures

**Abstract Link:** [https://arxiv.org/abs/2402.05424](https://arxiv.org/abs/2402.05424)

**PDF Link:** [https://arxiv.org/pdf/2402.05424](https://arxiv.org/pdf/2402.05424)

---

**Date:** 25 Sep 2019

**Title:** Information Plane Analysis of Deep Neural Networks via Matrix-Based  Renyi's Entropy and Tensor Kernels

**Abstract Link:** [https://arxiv.org/abs/1909.11396](https://arxiv.org/abs/1909.11396)

**PDF Link:** [https://arxiv.org/pdf/1909.11396](https://arxiv.org/pdf/1909.11396)

---

**Date:** 29 Oct 2018

**Title:** Mean-field theory of graph neural networks in graph partitioning

**Abstract Link:** [https://arxiv.org/abs/1810.11908](https://arxiv.org/abs/1810.11908)

**PDF Link:** [https://arxiv.org/pdf/1810.11908](https://arxiv.org/pdf/1810.11908)

---

**Date:** 14 Mar 2023

**Title:** Reachability Analysis of Neural Networks with Uncertain Parameters

**Abstract Link:** [https://arxiv.org/abs/2303.07917](https://arxiv.org/abs/2303.07917)

**PDF Link:** [https://arxiv.org/pdf/2303.07917](https://arxiv.org/pdf/2303.07917)

---

