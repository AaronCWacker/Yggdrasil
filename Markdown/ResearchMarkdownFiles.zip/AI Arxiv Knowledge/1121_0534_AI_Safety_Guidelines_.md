AI Safety Guidelines 🎮

### 🔎 AI Safety Guidelines 🎮



# AI Safety Guidelines 🎮

## AI Safety Guidelines 🎮

AI Safety Guidelines 🎮 - https://arxiv.org/abs/2107.03037

> We present a set of guidelines for the safe development and deployment of AI systems. These guidelines are intended to be applicable to a wide range of AI systems, including those that are not safety-critical. They are based on a review of existing literature on AI safety, as well as on our own experience in developing and deploying AI systems.

> The guidelines are organized into three categories:

> 1. Preventing unintended consequences: This category includes guidelines for ensuring that AI systems do not cause harm unintentionally. It includes guidelines for avoiding negative side effects, for ensuring that AI systems do not cause harm through their interactions with other systems, and for ensuring that AI systems do not cause harm through their interactions with humans.

> 2. Ensuring that AI systems are aligned with human values: This category includes guidelines for ensuring that AI systems do not act in ways that are contrary to human values. It includes guidelines for ensuring that AI systems do not discriminate, for ensuring that AI systems do not manipulate or deceive humans, and for ensuring that AI systems do not violate human rights.

> 3. Ensuring that AI systems are transparent and explainable: This category includes guidelines for ensuring that AI systems are transparent, so that humans can understand how they are making decisions. It includes guidelines for ensuring that AI systems are explainable, so that humans can understand why they are making certain decisions.

> We believe that these guidelines can help to ensure that AI systems are developed and deployed in a safe and responsible manner. We hope that they will be useful to AI developers, AI deployers, and AI regulators.

> The guidelines are not intended to be a comprehensive guide to AI safety. Instead, they are intended to be a starting point for thinking about AI safety. We encourage AI developers, AI deployers, and AI regulators to consider these guidelines in the context of their own work, and to adapt them as necessary to fit their specific needs and circumstances.

> We also encourage AI developers, AI deployers, and AI regulators to continue to engage with the AI safety community, and to contribute to the ongoing development of AI safety guidelines
# 🩺🔍 Search Results
### 07 Dec 2020 | [Transdisciplinary AI Observatory -- Retrospective Analyses and  Future-Oriented Contradistinctions](https://arxiv.org/abs/2012.02592) | [⬇️](https://arxiv.org/pdf/2012.02592)
*Nadisha-Marie Aliman, Leon Kester, and Roman Yampolskiy* 

  In the last years, AI safety gained international recognition in the light of
heterogeneous safety-critical and ethical issues that risk overshadowing the
broad beneficial impacts of AI. In this context, the implementation of AI
observatory endeavors represents one key research direction. This paper
motivates the need for an inherently transdisciplinary AI observatory approach
integrating diverse retrospective and counterfactual views. We delineate aims
and limitations while providing hands-on-advice utilizing concrete practical
examples. Distinguishing between unintentionally and intentionally triggered AI
risks with diverse socio-psycho-technological impacts, we exemplify a
retrospective descriptive analysis followed by a retrospective counterfactual
risk analysis. Building on these AI observatory tools, we present near-term
transdisciplinary guidelines for AI safety. As further contribution, we discuss
differentiated and tailored long-term directions through the lens of two
disparate modern AI safety paradigms. For simplicity, we refer to these two
different paradigms with the terms artificial stupidity (AS) and eternal
creativity (EC) respectively. While both AS and EC acknowledge the need for a
hybrid cognitive-affective approach to AI safety and overlap with regard to
many short-term considerations, they differ fundamentally in the nature of
multiple envisaged long-term solution patterns. By compiling relevant
underlying contradistinctions, we aim to provide future-oriented incentives for
constructive dialectics in practical and theoretical AI safety research.

---------------

### 06 Aug 2023 | [Building Safe and Reliable AI systems for Safety Critical Tasks with  Vision-Language Processing](https://arxiv.org/abs/2308.03176) | [⬇️](https://arxiv.org/pdf/2308.03176)
*Shuang Ao* 

  Although AI systems have been applied in various fields and achieved
impressive performance, their safety and reliability are still a big concern.
This is especially important for safety-critical tasks. One shared
characteristic of these critical tasks is their risk sensitivity, where small
mistakes can cause big consequences and even endanger life. There are several
factors that could be guidelines for the successful deployment of AI systems in
sensitive tasks: (i) failure detection and out-of-distribution (OOD) detection;
(ii) overfitting identification; (iii) uncertainty quantification for
predictions; (iv) robustness to data perturbations. These factors are also
challenges of current AI systems, which are major blocks for building safe and
reliable AI. Specifically, the current AI algorithms are unable to identify
common causes for failure detection. Furthermore, additional techniques are
required to quantify the quality of predictions. All these contribute to
inaccurate uncertainty quantification, which lowers trust in predictions. Hence
obtaining accurate model uncertainty quantification and its further improvement
are challenging. To address these issues, many techniques have been proposed,
such as regularization methods and learning strategies. As vision and language
are the most typical data type and have many open source benchmark datasets,
this thesis will focus on vision-language data processing for tasks like
classification, image captioning, and vision question answering. In this
thesis, we aim to build a safeguard by further developing current techniques to
ensure the accurate model uncertainty for safety-critical tasks.

---------------

### 21 Jul 2023 | [Model Reporting for Certifiable AI: A Proposal from Merging EU  Regulation into AI Development](https://arxiv.org/abs/2307.11525) | [⬇️](https://arxiv.org/pdf/2307.11525)
*Danilo Brajovic, Niclas Renner, Vincent Philipp Goebels, Philipp  Wagner, Benjamin Fresz, Martin Biller, Mara Klaeb, Janika Kutz, Jens  Neuhuettler, Marco F. Huber* 

  Despite large progress in Explainable and Safe AI, practitioners suffer from
a lack of regulation and standards for AI safety. In this work we merge recent
regulation efforts by the European Union and first proposals for AI guidelines
with recent trends in research: data and model cards. We propose the use of
standardized cards to document AI applications throughout the development
process. Our main contribution is the introduction of use-case and operation
cards, along with updates for data and model cards to cope with regulatory
requirements. We reference both recent research as well as the source of the
regulation in our cards and provide references to additional support material
and toolboxes whenever possible. The goal is to design cards that help
practitioners develop safe AI systems throughout the development process, while
enabling efficient third-party auditing of AI applications, being easy to
understand, and building trust in the system. Our work incorporates insights
from interviews with certification experts as well as developers and
individuals working with the developed AI applications.

---------------

### 27 Oct 2022 | [On the Efficiency of Ethics as a Governing Tool for Artificial  Intelligence](https://arxiv.org/abs/2210.15289) | [⬇️](https://arxiv.org/pdf/2210.15289)
*Nicholas Kluge Corr\^ea and Nythamar De Oliveira and Diogo Massmann* 

  The 4th Industrial Revolution is the culmination of the digital age.
Nowadays, technologies such as robotics, nanotechnology, genetics, and
artificial intelligence promise to transform our world and the way we live.
Artificial Intelligence Ethics and Safety is an emerging research field that
has been gaining popularity in recent years. Several private, public and
non-governmental organizations have published guidelines proposing ethical
principles for regulating the use and development of autonomous intelligent
systems. Meta-analyses of the AI Ethics research field point to convergence on
certain principles that supposedly govern the AI industry. However, little is
known about the effectiveness of this form of Ethics. In this paper, we would
like to conduct a critical analysis of the current state of AI Ethics and
suggest that this form of governance based on principled ethical guidelines is
not sufficient to norm the AI industry and its developers. We believe that
drastic changes are necessary, both in the training processes of professionals
in the fields related to the development of software and intelligent systems
and in the increased regulation of these professionals and their industry. To
this end, we suggest that law should benefit from recent contributions from
bioethics, to make the contributions of AI ethics to governance explicit in
legal terms.

---------------

### 24 Jul 2017 | [Guidelines for Artificial Intelligence Containment](https://arxiv.org/abs/1707.08476) | [⬇️](https://arxiv.org/pdf/1707.08476)
*James Babcock, Janos Kramar, Roman V. Yampolskiy* 

  With almost daily improvements in capabilities of artificial intelligence it
is more important than ever to develop safety software for use by the AI
research community. Building on our previous work on AI Containment Problem we
propose a number of guidelines which should help AI safety researchers to
develop reliable sandboxing software for intelligent programs of all levels.
Such safety container software will make it possible to study and analyze
intelligent artificial agent while maintaining certain level of safety against
information leakage, social engineering attacks and cyberattacks from within
the container.

---------------

### 19 Feb 2022 | [Impossibility Results in AI: A Survey](https://arxiv.org/abs/2109.00484) | [⬇️](https://arxiv.org/pdf/2109.00484)
*Mario Brcic and Roman V. Yampolskiy* 

  An impossibility theorem demonstrates that a particular problem or set of
problems cannot be solved as described in the claim. Such theorems put limits
on what is possible to do concerning artificial intelligence, especially the
super-intelligent one. As such, these results serve as guidelines, reminders,
and warnings to AI safety, AI policy, and governance researchers. These might
enable solutions to some long-standing questions in the form of formalizing
theories in the framework of constraint satisfaction without committing to one
option. We strongly believe this to be the most prudent approach to long-term
AI safety initiatives. In this paper, we have categorized impossibility
theorems applicable to AI into five mechanism-based categories: deduction,
indistinguishability, induction, tradeoffs, and intractability. We found that
certain theorems are too specific or have implicit assumptions that limit
application. Also, we added new results (theorems) such as the unfairness of
explainability, the first explainability-related result in the induction
category. The remaining results deal with misalignment between the clones and
put a limit to the self-awareness of agents. We concluded that deductive
impossibilities deny 100%-guarantees for security. In the end, we give some
ideas that hold potential in explainability, controllability, value alignment,
ethics, and group decision-making. They can be deepened by further
investigation.

---------------

### 30 Oct 2023 | [FUTURE-AI: Guiding Principles and Consensus Recommendations for  Trustworthy Artificial Intelligence in Medical Imaging](https://arxiv.org/abs/2109.09658) | [⬇️](https://arxiv.org/pdf/2109.09658)
*Karim Lekadir, Richard Osuala, Catherine Gallin, Noussair Lazrak,  Kaisar Kushibar, Gianna Tsakou, Susanna Auss\'o, Leonor Cerd\'a Alberich,  Kostas Marias, Manolis Tsiknakis, Sara Colantonio, Nickolas Papanikolaou,  Zohaib Salahuddin, Henry C Woodruff, Philippe Lambin, Luis Mart\'i-Bonmat\'i* 

  The recent advancements in artificial intelligence (AI) combined with the
extensive amount of data generated by today's clinical systems, has led to the
development of imaging AI solutions across the whole value chain of medical
imaging, including image reconstruction, medical image segmentation,
image-based diagnosis and treatment planning. Notwithstanding the successes and
future potential of AI in medical imaging, many stakeholders are concerned of
the potential risks and ethical implications of imaging AI solutions, which are
perceived as complex, opaque, and difficult to comprehend, utilise, and trust
in critical clinical applications. Despite these concerns and risks, there are
currently no concrete guidelines and best practices for guiding future AI
developments in medical imaging towards increased trust, safety and adoption.
To bridge this gap, this paper introduces a careful selection of guiding
principles drawn from the accumulated experiences, consensus, and best
practices from five large European projects on AI in Health Imaging. These
guiding principles are named FUTURE-AI and its building blocks consist of (i)
Fairness, (ii) Universality, (iii) Traceability, (iv) Usability, (v) Robustness
and (vi) Explainability. In a step-by-step approach, these guidelines are
further translated into a framework of concrete recommendations for specifying,
developing, evaluating, and deploying technically, clinically and ethically
trustworthy AI solutions into clinical practice.

---------------

### 14 Mar 2023 | [Artificial Intelligence Ethics and Safety: practical tools for creating  "good" models](https://arxiv.org/abs/2112.11208) | [⬇️](https://arxiv.org/pdf/2112.11208)
*Nicholas Kluge Corr\^ea* 

  The AI Robotics Ethics Society (AIRES) is a non-profit organization founded
in 2018 by Aaron Hui to promote awareness and the importance of ethical
implementation and regulation of AI. AIRES is now an organization with chapters
at universities such as UCLA (Los Angeles), USC (University of Southern
California), Caltech (California Institute of Technology), Stanford University,
Cornell University, Brown University, and the Pontifical Catholic University of
Rio Grande do Sul (Brazil). AIRES at PUCRS is the first international chapter
of AIRES, and as such, we are committed to promoting and enhancing the AIRES
Mission. Our mission is to focus on educating the AI leaders of tomorrow in
ethical principles to ensure that AI is created ethically and responsibly. As
there are still few proposals for how we should implement ethical principles
and normative guidelines in the practice of AI system development, the goal of
this work is to try to bridge this gap between discourse and praxis. Between
abstract principles and technical implementation. In this work, we seek to
introduce the reader to the topic of AI Ethics and Safety. At the same time, we
present several tools to help developers of intelligent systems develop "good"
models. This work is a developing guide published in English and Portuguese.
Contributions and suggestions are welcome.

---------------

### 18 Aug 2022 | [AI Ethics Issues in Real World: Evidence from AI Incident Database](https://arxiv.org/abs/2206.07635) | [⬇️](https://arxiv.org/pdf/2206.07635)
*Mengyi Wei and Zhixuan Zhou* 

  With the powerful performance of Artificial Intelligence (AI) also comes
prevalent ethical issues. Though governments and corporations have curated
multiple AI ethics guidelines to curb unethical behavior of AI, the effect has
been limited, probably due to the vagueness of the guidelines. In this paper,
we take a closer look at how AI ethics issues take place in real world, in
order to have a more in-depth and nuanced understanding of different ethical
issues as well as their social impact. With a content analysis of AI Incident
Database, which is an effort to prevent repeated real world AI failures by
cataloging incidents, we identified 13 application areas which often see
unethical use of AI, with intelligent service robots, language/vision models
and autonomous driving taking the lead. Ethical issues appear in 8 different
forms, from inappropriate use and racial discrimination, to physical safety and
unfair algorithm. With this taxonomy of AI ethics issues, we aim to provide AI
practitioners with a practical guideline when trying to deploy AI applications
ethically.

---------------

### 05 Oct 2023 | [Unpacking Human-AI Interaction in Safety-Critical Industries: A  Systematic Literature Review](https://arxiv.org/abs/2310.03392) | [⬇️](https://arxiv.org/pdf/2310.03392)
*Tita A. Bach, Jenny K. Kristiansen, Aleksandar Babic, and Alon Jacovi* 

  Ensuring quality human-AI interaction (HAII) in safety-critical industries is
essential. Failure to do so can lead to catastrophic and deadly consequences.
Despite this urgency, what little research there is on HAII is fragmented and
inconsistent. We present here a survey of that literature and recommendations
for research best practices that will improve the field. We divided our
investigation into the following research areas: (1) terms used to describe
HAII, (2) primary roles of AI-enabled systems, (3) factors that influence HAII,
and (4) how HAII is measured. Additionally, we described the capabilities and
maturity of the AI-enabled systems used in safety-critical industries discussed
in these articles. We found that no single term is used across the literature
to describe HAII and some terms have multiple meanings. According to our
literature, five factors influence HAII: user characteristics and background
(e.g., user personality, perceptions), AI interface and features (e.g.,
interactive UI design), AI output (e.g., accuracy, actionable recommendations),
explainability and interpretability (e.g., level of detail, user
understanding), and usage of AI (e.g., heterogeneity of environments and user
needs). HAII is most commonly measured with user-related subjective metrics
(e.g., user perception, trust, and attitudes), and AI-assisted decision-making
is the most common primary role of AI-enabled systems. Based on this review, we
conclude that there are substantial research gaps in HAII. Researchers and
developers need to codify HAII terminology, involve users throughout the AI
lifecycle (especially during development), and tailor HAII in safety-critical
industries to the users and environments.

---------------

### 30 Jun 2019 | [Requisite Variety in Ethical Utility Functions for AI Value Alignment](https://arxiv.org/abs/1907.00430) | [⬇️](https://arxiv.org/pdf/1907.00430)
*Nadisha-Marie Aliman and Leon Kester* 

  Being a complex subject of major importance in AI Safety research, value
alignment has been studied from various perspectives in the last years.
However, no final consensus on the design of ethical utility functions
facilitating AI value alignment has been achieved yet. Given the urgency to
identify systematic solutions, we postulate that it might be useful to start
with the simple fact that for the utility function of an AI not to violate
human ethical intuitions, it trivially has to be a model of these intuitions
and reflect their variety $ - $ whereby the most accurate models pertaining to
human entities being biological organisms equipped with a brain constructing
concepts like moral judgements, are scientific models. Thus, in order to better
assess the variety of human morality, we perform a transdisciplinary analysis
applying a security mindset to the issue and summarizing variety-relevant
background knowledge from neuroscience and psychology. We complement this
information by linking it to augmented utilitarianism as a suitable ethical
framework. Based on that, we propose first practical guidelines for the design
of approximate ethical goal functions that might better capture the variety of
human moral judgements. Finally, we conclude and address future possible
challenges.

---------------

### 28 Nov 2023 | [Survey on AI Ethics: A Socio-technical Perspective](https://arxiv.org/abs/2311.17228) | [⬇️](https://arxiv.org/pdf/2311.17228)
*Dave Mbiazi, Meghana Bhange, Maryam Babaei, Ivaxi Sheth, Patrik Joslin  Kenfack* 

  The past decade has observed a great advancement in AI with deep
learning-based models being deployed in diverse scenarios including
safety-critical applications. As these AI systems become deeply embedded in our
societal infrastructure, the repercussions of their decisions and actions have
significant consequences, making the ethical implications of AI deployment
highly relevant and important. The ethical concerns associated with AI are
multifaceted, including challenging issues of fairness, privacy and data
protection, responsibility and accountability, safety and robustness,
transparency and explainability, and environmental impact. These principles
together form the foundations of ethical AI considerations that concern every
stakeholder in the AI system lifecycle. In light of the present ethical and
future x-risk concerns, governments have shown increasing interest in
establishing guidelines for the ethical deployment of AI. This work unifies the
current and future ethical concerns of deploying AI into society. While we
acknowledge and appreciate the technical surveys for each of the ethical
principles concerned, in this paper, we aim to provide a comprehensive overview
that not only addresses each principle from a technical point of view but also
discusses them from a social perspective.

---------------

### 18 Nov 2021 | [Software Engineering for Responsible AI: An Empirical Study and  Operationalised Patterns](https://arxiv.org/abs/2111.09478) | [⬇️](https://arxiv.org/pdf/2111.09478)
*Qinghua Lu, Liming Zhu, Xiwei Xu, Jon Whittle, David Douglas, Conrad  Sanderson* 

  Although artificial intelligence (AI) is solving real-world challenges and
transforming industries, there are serious concerns about its ability to behave
and make decisions in a responsible way. Many AI ethics principles and
guidelines for responsible AI have been recently issued by governments,
organisations, and enterprises. However, these AI ethics principles and
guidelines are typically high-level and do not provide concrete guidance on how
to design and develop responsible AI systems. To address this shortcoming, we
first present an empirical study where we interviewed 21 scientists and
engineers to understand the practitioners' perceptions on AI ethics principles
and their implementation. We then propose a template that enables AI ethics
principles to be operationalised in the form of concrete patterns and suggest a
list of patterns using the newly created template. These patterns provide
concrete, operationalised guidance that facilitate the development of
responsible AI systems.

---------------

### 11 Oct 2019 | [The Ethics of AI Ethics -- An Evaluation of Guidelines](https://arxiv.org/abs/1903.03425) | [⬇️](https://arxiv.org/pdf/1903.03425)
*Thilo Hagendorff* 

  Current advances in research, development and application of artificial
intelligence (AI) systems have yielded a far-reaching discourse on AI ethics.
In consequence, a number of ethics guidelines have been released in recent
years. These guidelines comprise normative principles and recommendations aimed
to harness the "disruptive" potentials of new AI technologies. Designed as a
comprehensive evaluation, this paper analyzes and compares these guidelines
highlighting overlaps but also omissions. As a result, I give a detailed
overview of the field of AI ethics. Finally, I also examine to what extent the
respective ethical principles and values are implemented in the practice of
research, development and application of AI systems - and how the effectiveness
in the demands of AI ethics can be improved.

---------------

### 29 Feb 2024 | [NewsBench: Systematic Evaluation of LLMs for Writing Proficiency and  Safety Adherence in Chinese Journalistic Editorial Applications](https://arxiv.org/abs/2403.00862) | [⬇️](https://arxiv.org/pdf/2403.00862)
*Miao Li and Ming-Bin Chen and Bo Tang and Shengbin Hou and Pengyu Wang  and Haiying Deng and Zhiyu Li and Feiyu Xiong and Keming Mao and Peng Cheng  and Yi Luo* 

  This study presents NewsBench, a novel benchmark framework developed to
evaluate the capability of Large Language Models (LLMs) in Chinese Journalistic
Writing Proficiency (JWP) and their Safety Adherence (SA), addressing the gap
between journalistic ethics and the risks associated with AI utilization.
Comprising 1,267 tasks across 5 editorial applications, 7 aspects (including
safety and journalistic writing with 4 detailed facets), and spanning 24 news
topics domains, NewsBench employs two GPT-4 based automatic evaluation
protocols validated by human assessment. Our comprehensive analysis of 11 LLMs
highlighted GPT-4 and ERNIE Bot as top performers, yet revealed a relative
deficiency in journalistic ethic adherence during creative writing tasks. These
findings underscore the need for enhanced ethical guidance in AI-generated
journalistic content, marking a step forward in aligning AI capabilities with
journalistic standards and safety considerations.

---------------

### 09 Jul 2020 | [AI safety: state of the field through quantitative lens](https://arxiv.org/abs/2002.05671) | [⬇️](https://arxiv.org/pdf/2002.05671)
*Mislav Juric, Agneza Sandic, Mario Brcic* 

  Last decade has seen major improvements in the performance of artificial
intelligence which has driven wide-spread applications. Unforeseen effects of
such mass-adoption has put the notion of AI safety into the public eye. AI
safety is a relatively new field of research focused on techniques for building
AI beneficial for humans. While there exist survey papers for the field of AI
safety, there is a lack of a quantitative look at the research being conducted.
The quantitative aspect gives a data-driven insight about the emerging trends,
knowledge gaps and potential areas for future research. In this paper,
bibliometric analysis of the literature finds significant increase in research
activity since 2015. Also, the field is so new that most of the technical
issues are open, including: explainability with its long-term utility, and
value alignment which we have identified as the most important long-term
research topic. Equally, there is a severe lack of research into concrete
policies regarding AI. As we expect AI to be the one of the main driving forces
of changes in society, AI safety is the field under which we need to decide the
direction of humanity's future.

---------------

### 23 Jan 2024 | [Considering Fundamental Rights in the European Standardisation of  Artificial Intelligence: Nonsense or Strategic Alliance?](https://arxiv.org/abs/2402.16869) | [⬇️](https://arxiv.org/pdf/2402.16869)
*Marion Ho-Dac (UA)* 

  In the European context, both the EU AI Act proposal and the draft
Standardisation Request on safe and trustworthy AI link standardisation to
fundamental rights. However, these texts do not provide any guidelines that
specify and detail the relationship between AI standards and fundamental
rights, its meaning or implication. This chapter aims to clarify this critical
regulatory blind spot. The main issue tackled is whether the adoption of AI
harmonised standards, based on the future AI Act, should take into account
fundamental rights. In our view, the response is yes. The high risks posed by
certain AI systems relate in particular to infringements of fundamental rights.
Therefore, mitigating such risks involves fundamental rights considerations and
this is what future harmonised standards should reflect. At the same time,
valid criticisms of the European standardisation process have to be addressed.
Finally, the practical incorporation of fundamental rights considerations in
the ongoing European standardisation of AI systems is discussed.

---------------

### 01 Jan 2021 | [Deep Verifier Networks: Verification of Deep Discriminative Models with  Deep Generative Models](https://arxiv.org/abs/1911.07421) | [⬇️](https://arxiv.org/pdf/1911.07421)
*Tong Che, Xiaofeng Liu, Site Li, Yubin Ge, Ruixiang Zhang, Caiming  Xiong, Yoshua Bengio* 

  AI Safety is a major concern in many deep learning applications such as
autonomous driving. Given a trained deep learning model, an important natural
problem is how to reliably verify the model's prediction. In this paper, we
propose a novel framework -- deep verifier networks (DVN) to verify the inputs
and outputs of deep discriminative models with deep generative models. Our
proposed model is based on conditional variational auto-encoders with
disentanglement constraints. We give both intuitive and theoretical
justifications of the model. Our verifier network is trained independently with
the prediction model, which eliminates the need of retraining the verifier
network for a new model. We test the verifier network on out-of-distribution
detection and adversarial example detection problems, as well as anomaly
detection problems in structured prediction tasks such as image caption
generation. We achieve state-of-the-art results in all of these problems.

---------------

### 23 Feb 2023 | [Actionable Guidance for High-Consequence AI Risk Management: Towards  Standards Addressing AI Catastrophic Risks](https://arxiv.org/abs/2206.08966) | [⬇️](https://arxiv.org/pdf/2206.08966)
*Anthony M. Barrett, Dan Hendrycks, Jessica Newman, Brandie Nonnecke* 

  Artificial intelligence (AI) systems can provide many beneficial capabilities
but also risks of adverse events. Some AI systems could present risks of events
with very high or catastrophic consequences at societal scale. The US National
Institute of Standards and Technology (NIST) has been developing the NIST
Artificial Intelligence Risk Management Framework (AI RMF) as voluntary
guidance on AI risk assessment and management for AI developers and others. For
addressing risks of events with catastrophic consequences, NIST indicated a
need to translate from high level principles to actionable risk management
guidance.
  In this document, we provide detailed actionable-guidance recommendations
focused on identifying and managing risks of events with very high or
catastrophic consequences, intended as a risk management practices resource for
NIST for AI RMF version 1.0 (released in January 2023), or for AI RMF users, or
for other AI risk management guidance and standards as appropriate. We also
provide our methodology for our recommendations.
  We provide actionable-guidance recommendations for AI RMF 1.0 on: identifying
risks from potential unintended uses and misuses of AI systems; including
catastrophic-risk factors within the scope of risk assessments and impact
assessments; identifying and mitigating human rights harms; and reporting
information on AI risk factors including catastrophic-risk factors.
  In addition, we provide recommendations on additional issues for a roadmap
for later versions of the AI RMF or supplementary publications. These include:
providing an AI RMF Profile with supplementary guidance for cutting-edge
increasingly multi-purpose or general-purpose AI.
  We aim for this work to be a concrete risk-management practices contribution,
and to stimulate constructive dialogue on how to address catastrophic risks and
associated issues in AI standards.

---------------

### 09 Jun 2022 | [Process Knowledge-Infused AI: Towards User-level Explainability,  Interpretability, and Safety](https://arxiv.org/abs/2206.13349) | [⬇️](https://arxiv.org/pdf/2206.13349)
*Amit Sheth, Manas Gaur, Kaushik Roy, Revathy Venkataraman, Vedant  Khandelwal* 

  AI systems have been widely adopted across various domains in the real world.
However, in high-value, sensitive, or safety-critical applications such as
self-management for personalized health or food recommendation with a specific
purpose (e.g., allergy-aware recipe recommendations), their adoption is
unlikely. Firstly, the AI system needs to follow guidelines or well-defined
processes set by experts; the data alone will not be adequate. For example, to
diagnose the severity of depression, mental healthcare providers use Patient
Health Questionnaire (PHQ-9). So if an AI system were to be used for diagnosis,
the medical guideline implied by the PHQ-9 needs to be used. Likewise, a
nutritionist's knowledge and steps would need to be used for an AI system that
guides a diabetic patient in developing a food plan. Second, the BlackBox
nature typical of many current AI systems will not work; the user of an AI
system will need to be able to give user-understandable explanations,
explanations constructed using concepts that humans can understand and are
familiar with. This is the key to eliciting confidence and trust in the AI
system. For such applications, in addition to data and domain knowledge, the AI
systems need to have access to and use the Process Knowledge, an ordered set of
steps that the AI system needs to use or adhere to.

---------------
**Date:** 07 Dec 2020

**Title:** Transdisciplinary AI Observatory -- Retrospective Analyses and  Future-Oriented Contradistinctions

**Abstract Link:** [https://arxiv.org/abs/2012.02592](https://arxiv.org/abs/2012.02592)

**PDF Link:** [https://arxiv.org/pdf/2012.02592](https://arxiv.org/pdf/2012.02592)

---

**Date:** 06 Aug 2023

**Title:** Building Safe and Reliable AI systems for Safety Critical Tasks with  Vision-Language Processing

**Abstract Link:** [https://arxiv.org/abs/2308.03176](https://arxiv.org/abs/2308.03176)

**PDF Link:** [https://arxiv.org/pdf/2308.03176](https://arxiv.org/pdf/2308.03176)

---

**Date:** 21 Jul 2023

**Title:** Model Reporting for Certifiable AI: A Proposal from Merging EU  Regulation into AI Development

**Abstract Link:** [https://arxiv.org/abs/2307.11525](https://arxiv.org/abs/2307.11525)

**PDF Link:** [https://arxiv.org/pdf/2307.11525](https://arxiv.org/pdf/2307.11525)

---

**Date:** 27 Oct 2022

**Title:** On the Efficiency of Ethics as a Governing Tool for Artificial  Intelligence

**Abstract Link:** [https://arxiv.org/abs/2210.15289](https://arxiv.org/abs/2210.15289)

**PDF Link:** [https://arxiv.org/pdf/2210.15289](https://arxiv.org/pdf/2210.15289)

---

**Date:** 24 Jul 2017

**Title:** Guidelines for Artificial Intelligence Containment

**Abstract Link:** [https://arxiv.org/abs/1707.08476](https://arxiv.org/abs/1707.08476)

**PDF Link:** [https://arxiv.org/pdf/1707.08476](https://arxiv.org/pdf/1707.08476)

---

**Date:** 19 Feb 2022

**Title:** Impossibility Results in AI: A Survey

**Abstract Link:** [https://arxiv.org/abs/2109.00484](https://arxiv.org/abs/2109.00484)

**PDF Link:** [https://arxiv.org/pdf/2109.00484](https://arxiv.org/pdf/2109.00484)

---

**Date:** 30 Oct 2023

**Title:** FUTURE-AI: Guiding Principles and Consensus Recommendations for  Trustworthy Artificial Intelligence in Medical Imaging

**Abstract Link:** [https://arxiv.org/abs/2109.09658](https://arxiv.org/abs/2109.09658)

**PDF Link:** [https://arxiv.org/pdf/2109.09658](https://arxiv.org/pdf/2109.09658)

---

**Date:** 14 Mar 2023

**Title:** Artificial Intelligence Ethics and Safety: practical tools for creating  "good" models

**Abstract Link:** [https://arxiv.org/abs/2112.11208](https://arxiv.org/abs/2112.11208)

**PDF Link:** [https://arxiv.org/pdf/2112.11208](https://arxiv.org/pdf/2112.11208)

---

**Date:** 18 Aug 2022

**Title:** AI Ethics Issues in Real World: Evidence from AI Incident Database

**Abstract Link:** [https://arxiv.org/abs/2206.07635](https://arxiv.org/abs/2206.07635)

**PDF Link:** [https://arxiv.org/pdf/2206.07635](https://arxiv.org/pdf/2206.07635)

---

**Date:** 05 Oct 2023

**Title:** Unpacking Human-AI Interaction in Safety-Critical Industries: A  Systematic Literature Review

**Abstract Link:** [https://arxiv.org/abs/2310.03392](https://arxiv.org/abs/2310.03392)

**PDF Link:** [https://arxiv.org/pdf/2310.03392](https://arxiv.org/pdf/2310.03392)

---

**Date:** 30 Jun 2019

**Title:** Requisite Variety in Ethical Utility Functions for AI Value Alignment

**Abstract Link:** [https://arxiv.org/abs/1907.00430](https://arxiv.org/abs/1907.00430)

**PDF Link:** [https://arxiv.org/pdf/1907.00430](https://arxiv.org/pdf/1907.00430)

---

**Date:** 28 Nov 2023

**Title:** Survey on AI Ethics: A Socio-technical Perspective

**Abstract Link:** [https://arxiv.org/abs/2311.17228](https://arxiv.org/abs/2311.17228)

**PDF Link:** [https://arxiv.org/pdf/2311.17228](https://arxiv.org/pdf/2311.17228)

---

**Date:** 18 Nov 2021

**Title:** Software Engineering for Responsible AI: An Empirical Study and  Operationalised Patterns

**Abstract Link:** [https://arxiv.org/abs/2111.09478](https://arxiv.org/abs/2111.09478)

**PDF Link:** [https://arxiv.org/pdf/2111.09478](https://arxiv.org/pdf/2111.09478)

---

**Date:** 11 Oct 2019

**Title:** The Ethics of AI Ethics -- An Evaluation of Guidelines

**Abstract Link:** [https://arxiv.org/abs/1903.03425](https://arxiv.org/abs/1903.03425)

**PDF Link:** [https://arxiv.org/pdf/1903.03425](https://arxiv.org/pdf/1903.03425)

---

**Date:** 29 Feb 2024

**Title:** NewsBench: Systematic Evaluation of LLMs for Writing Proficiency and  Safety Adherence in Chinese Journalistic Editorial Applications

**Abstract Link:** [https://arxiv.org/abs/2403.00862](https://arxiv.org/abs/2403.00862)

**PDF Link:** [https://arxiv.org/pdf/2403.00862](https://arxiv.org/pdf/2403.00862)

---

**Date:** 09 Jul 2020

**Title:** AI safety: state of the field through quantitative lens

**Abstract Link:** [https://arxiv.org/abs/2002.05671](https://arxiv.org/abs/2002.05671)

**PDF Link:** [https://arxiv.org/pdf/2002.05671](https://arxiv.org/pdf/2002.05671)

---

**Date:** 23 Jan 2024

**Title:** Considering Fundamental Rights in the European Standardisation of  Artificial Intelligence: Nonsense or Strategic Alliance?

**Abstract Link:** [https://arxiv.org/abs/2402.16869](https://arxiv.org/abs/2402.16869)

**PDF Link:** [https://arxiv.org/pdf/2402.16869](https://arxiv.org/pdf/2402.16869)

---

**Date:** 01 Jan 2021

**Title:** Deep Verifier Networks: Verification of Deep Discriminative Models with  Deep Generative Models

**Abstract Link:** [https://arxiv.org/abs/1911.07421](https://arxiv.org/abs/1911.07421)

**PDF Link:** [https://arxiv.org/pdf/1911.07421](https://arxiv.org/pdf/1911.07421)

---

**Date:** 23 Feb 2023

**Title:** Actionable Guidance for High-Consequence AI Risk Management: Towards  Standards Addressing AI Catastrophic Risks

**Abstract Link:** [https://arxiv.org/abs/2206.08966](https://arxiv.org/abs/2206.08966)

**PDF Link:** [https://arxiv.org/pdf/2206.08966](https://arxiv.org/pdf/2206.08966)

---

**Date:** 09 Jun 2022

**Title:** Process Knowledge-Infused AI: Towards User-level Explainability,  Interpretability, and Safety

**Abstract Link:** [https://arxiv.org/abs/2206.13349](https://arxiv.org/abs/2206.13349)

**PDF Link:** [https://arxiv.org/pdf/2206.13349](https://arxiv.org/pdf/2206.13349)

---

