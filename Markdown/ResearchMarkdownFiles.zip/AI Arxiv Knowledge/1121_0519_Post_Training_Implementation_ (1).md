Post-Training Implementation 🔧

### 🔎 Post-Training Implementation 🔧



# Post-Training Implementation 🔧

After training your model, you will want to deploy it in a production environment. This process is called post-training implementation.

There are two main ways to deploy a model:

- Inference on CPU
- Inference on GPU

Inference on CPU is the simplest way to deploy a model, but it can be slow for large models or for models that need to process a lot of data. Inference on GPU is faster, but it requires a GPU and can be more complex to set up.

There are many libraries and frameworks that can help you with post-training implementation. Some of the most popular ones are TensorFlow Serving, ONNX Runtime, and OpenVINO.

TensorFlow Serving is a library for deploying TensorFlow models. It allows you to serve models as a REST API, which makes it easy to integrate with other applications. TensorFlow Serving also supports gRPC, a high-performance remote procedure call (RPC) framework.

ONNX Runtime is a library for running ONNX models. ONNX is an open format for representing machine learning models, and it is supported by many different frameworks, including TensorFlow, PyTorch, and Microsoft Cognitive Toolkit. ONNX Runtime allows you to run ONNX models on a variety of platforms, including Windows, Linux, and macOS.

OpenVINO is a toolkit for deploying deep learning models on Intel hardware. It includes a model optimizer that can convert models from various frameworks, including TensorFlow and PyTorch, to the Intermediate Representation (IR) format used by OpenVINO. OpenVINO also includes an inference engine that can run models on Intel CPUs, GPUs, and FPGAs.

When deploying a model, it is important to consider the following factors:

- Latency: The time it takes to make a single prediction.
- Throughput: The number of predictions that can be made per second.
- Memory footprint: The amount of memory required to run the model.
- Power consumption: The amount of power required to run the model.

These factors are important because they can affect the user experience and the cost of running the model. For example, a model with a high latency may be frustrating for users,
# 🩺🔍 Search Results
### 30 Jun 2020 | [EasyQuant: Post-training Quantization via Scale Optimization](https://arxiv.org/abs/2006.16669) | [⬇️](https://arxiv.org/pdf/2006.16669)
*Di Wu, Qi Tang, Yongle Zhao, Ming Zhang, Ying Fu and Debing Zhang* 

  The 8 bits quantization has been widely applied to accelerate network
inference in various deep learning applications. There are two kinds of
quantization methods, training-based quantization and post-training
quantization. Training-based approach suffers from a cumbersome training
process, while post-training quantization may lead to unacceptable accuracy
drop. In this paper, we present an efficient and simple post-training method
via scale optimization, named EasyQuant (EQ),that could obtain comparable
accuracy with the training-based method.Specifically, we first alternately
optimize scales of weights and activations for all layers target at
convolutional outputs to further obtain the high quantization precision. Then,
we lower down bit width to INT7 both for weights and activations, and adopt
INT16 intermediate storage and integer Winograd convolution implementation to
accelerate inference.Experimental results on various computer vision tasks show
that EQ outperforms the TensorRT method and can achieve near INT8 accuracy in 7
bits width post-training.

---------------

### 28 Oct 2021 | [Post-Training Sparsity-Aware Quantization](https://arxiv.org/abs/2105.11010) | [⬇️](https://arxiv.org/pdf/2105.11010)
*Gil Shomron, Freddy Gabbay, Samer Kurzum, Uri Weiser* 

  Quantization is a technique used in deep neural networks (DNNs) to increase
execution performance and hardware efficiency. Uniform post-training
quantization (PTQ) methods are common, since they can be implemented
efficiently in hardware and do not require extensive hardware resources or a
training set. Mapping FP32 models to INT8 using uniform PTQ yields models with
negligible accuracy degradation; however, reducing precision below 8 bits with
PTQ is challenging, as accuracy degradation becomes noticeable, due to the
increase in quantization noise. In this paper, we propose a sparsity-aware
quantization (SPARQ) method, in which the unstructured and dynamic activation
sparsity is leveraged in different representation granularities. 4-bit
quantization, for example, is employed by dynamically examining the bits of
8-bit values and choosing a window of 4 bits, while first skipping zero-value
bits. Moreover, instead of quantizing activation-by-activation to 4 bits, we
focus on pairs of 8-bit activations and examine whether one of the two is equal
to zero. If one is equal to zero, the second can opportunistically use the
other's 4-bit budget; if both do not equal zero, then each is dynamically
quantized to 4 bits, as described. SPARQ achieves minor accuracy degradation
and a practical hardware implementation. The code is available at
https://github.com/gilshm/sparq.

---------------

### 23 Mar 2023 | [Benchmarking the Reliability of Post-training Quantization: a Particular  Focus on Worst-case Performance](https://arxiv.org/abs/2303.13003) | [⬇️](https://arxiv.org/pdf/2303.13003)
*Zhihang Yuan, Jiawei Liu, Jiaxiang Wu, Dawei Yang, Qiang Wu, Guangyu  Sun, Wenyu Liu, Xinggang Wang, Bingzhe Wu* 

  Post-training quantization (PTQ) is a popular method for compressing deep
neural networks (DNNs) without modifying their original architecture or
training procedures. Despite its effectiveness and convenience, the reliability
of PTQ methods in the presence of some extrem cases such as distribution shift
and data noise remains largely unexplored. This paper first investigates this
problem on various commonly-used PTQ methods. We aim to answer several research
questions related to the influence of calibration set distribution variations,
calibration paradigm selection, and data augmentation or sampling strategies on
PTQ reliability. A systematic evaluation process is conducted across a wide
range of tasks and commonly-used PTQ paradigms. The results show that most
existing PTQ methods are not reliable enough in term of the worst-case group
performance, highlighting the need for more robust methods. Our findings
provide insights for developing PTQ methods that can effectively handle
distribution shift scenarios and enable the deployment of quantized DNNs in
real-world applications.

---------------

### 21 Jan 2023 | [Adapting a Language Model While Preserving its General Knowledge](https://arxiv.org/abs/2301.08986) | [⬇️](https://arxiv.org/pdf/2301.08986)
*Zixuan Ke, Yijia Shao, Haowei Lin, Hu Xu, Lei Shu and Bing Liu* 

  Domain-adaptive pre-training (or DA-training for short), also known as
post-training, aims to train a pre-trained general-purpose language model (LM)
using an unlabeled corpus of a particular domain to adapt the LM so that
end-tasks in the domain can give improved performances. However, existing
DA-training methods are in some sense blind as they do not explicitly identify
what knowledge in the LM should be preserved and what should be changed by the
domain corpus. This paper shows that the existing methods are suboptimal and
proposes a novel method to perform a more informed adaptation of the knowledge
in the LM by (1) soft-masking the attention heads based on their importance to
best preserve the general knowledge in the LM and (2) contrasting the
representations of the general and the full (both general and domain knowledge)
to learn an integrated representation with both general and domain-specific
knowledge. Experimental results will demonstrate the effectiveness of the
proposed approach.

---------------

### 16 Sep 2023 | [Distributionally Robust Post-hoc Classifiers under Prior Shifts](https://arxiv.org/abs/2309.08825) | [⬇️](https://arxiv.org/pdf/2309.08825)
*Jiaheng Wei, Harikrishna Narasimhan, Ehsan Amid, Wen-Sheng Chu, Yang  Liu, and Abhishek Kumar* 

  The generalization ability of machine learning models degrades significantly
when the test distribution shifts away from the training distribution. We
investigate the problem of training models that are robust to shifts caused by
changes in the distribution of class-priors or group-priors. The presence of
skewed training priors can often lead to the models overfitting to spurious
features. Unlike existing methods, which optimize for either the worst or the
average performance over classes or groups, our work is motivated by the need
for finer control over the robustness properties of the model. We present an
extremely lightweight post-hoc approach that performs scaling adjustments to
predictions from a pre-trained model, with the goal of minimizing a
distributionally robust loss around a chosen target distribution. These
adjustments are computed by solving a constrained optimization problem on a
validation set and applied to the model during test time. Our constrained
optimization objective is inspired by a natural notion of robustness to
controlled distribution shifts. Our method comes with provable guarantees and
empirically makes a strong case for distributional robust post-hoc classifiers.
An empirical implementation is available at
https://github.com/weijiaheng/Drops.

---------------

### 19 Aug 2023 | [Q-HyViT: Post-Training Quantization for Hybrid Vision Transformer with  Bridge Block Reconstruction](https://arxiv.org/abs/2303.12557) | [⬇️](https://arxiv.org/pdf/2303.12557)
*Jemin Lee, Yongin Kwon, Jeman Park, Misun Yu, Sihyeong Park, Hwanjun  Song* 

  Recently, vision transformers (ViTs) have superseded convolutional neural
networks in numerous applications, including classification, detection, and
segmentation. However, the high computational requirements of ViTs hinder their
widespread implementation. To address this issue, researchers have proposed
efficient hybrid transformer architectures that combine convolutional and
transformer layers with optimized attention computation of linear complexity.
Additionally, post-training quantization has been proposed as a means of
mitigating computational demands. For mobile devices, achieving optimal
acceleration for ViTs necessitates the strategic integration of quantization
techniques and efficient hybrid transformer structures. However, no prior
investigation has applied quantization to efficient hybrid transformers. In
this paper, we discover that applying existing PTQ methods for ViTs to
efficient hybrid transformers leads to a drastic accuracy drop, attributed to
the four following challenges: (i) highly dynamic ranges, (ii) zero-point
overflow, (iii) diverse normalization, and (iv) limited model parameters
($<$5M). To overcome these challenges, we propose a new post-training
quantization method, which is the first to quantize efficient hybrid ViTs
(MobileViTv1, MobileViTv2, Mobile-Former, EfficientFormerV1, EfficientFormerV2)
with a significant margin (an average improvement of 8.32\% for 8-bit and
26.02\% for 6-bit) compared to existing PTQ methods (EasyQuant, FQ-ViT, and
PTQ4ViT). We plan to release our code at \url{https://github.com/Q-HyViT}.

---------------

### 22 Oct 2020 | [Posterior Re-calibration for Imbalanced Datasets](https://arxiv.org/abs/2010.11820) | [⬇️](https://arxiv.org/pdf/2010.11820)
*Junjiao Tian, Yen-Cheng Liu, Nathan Glaser, Yen-Chang Hsu, Zsolt Kira* 

  Neural Networks can perform poorly when the training label distribution is
heavily imbalanced, as well as when the testing data differs from the training
distribution. In order to deal with shift in the testing label distribution,
which imbalance causes, we motivate the problem from the perspective of an
optimal Bayes classifier and derive a post-training prior rebalancing technique
that can be solved through a KL-divergence based optimization. This method
allows a flexible post-training hyper-parameter to be efficiently tuned on a
validation set and effectively modify the classifier margin to deal with this
imbalance. We further combine this method with existing likelihood shift
methods, re-interpreting them from the same Bayesian perspective, and
demonstrating that our method can deal with both problems in a unified way. The
resulting algorithm can be conveniently used on probabilistic classification
problems agnostic to underlying architectures. Our results on six different
datasets and five different architectures show state of art accuracy, including
on large-scale imbalanced datasets such as iNaturalist for classification and
Synthia for semantic segmentation. Please see
https://github.com/GT-RIPL/UNO-IC.git for implementation.

---------------

### 21 Nov 2023 | [Post-Training Quantization with Low-precision Minifloats and Integers on  FPGAs](https://arxiv.org/abs/2311.12359) | [⬇️](https://arxiv.org/pdf/2311.12359)
*Shivam Aggarwal, Alessandro Pappalardo, Hans Jakob Damsgaard, Giuseppe  Franco, Thomas B. Preu{\ss}er, Michaela Blott, Tulika Mitra* 

  Post-Training Quantization (PTQ) is a powerful technique for model
compression, reducing the precision of neural networks without additional
training overhead. Recent works have investigated adopting 8-bit floating-point
quantization (FP8) in the context of PTQ for model inference. However, the
exploration of floating-point formats smaller than 8 bits and their comparison
with integer quantization remains relatively limited. In this work, we present
minifloats, which are reduced-precision floating-point formats capable of
further reducing the memory footprint, latency, and energy cost of a model
while approaching full-precision model accuracy. Our work presents a novel PTQ
design-space exploration, comparing minifloat and integer quantization schemes
across a range of 3 to 8 bits for both weights and activations. We examine the
applicability of various PTQ techniques to minifloats, including weight
equalization, bias correction, SmoothQuant, gradient-based learned rounding,
and the GPTQ method. Our experiments validate the effectiveness of
low-precision minifloats when compared to their integer counterparts across a
spectrum of accuracy-precision trade-offs on a set of reference deep learning
vision workloads. Finally, we evaluate our results against an FPGA-based
hardware cost model, showing that integer quantization often remains the
Pareto-optimal option, given its relatively smaller hardware resource
footprint.

---------------

### 04 Sep 2023 | [Softmax Bias Correction for Quantized Generative Models](https://arxiv.org/abs/2309.01729) | [⬇️](https://arxiv.org/pdf/2309.01729)
*Nilesh Prasad Pandey, Marios Fournarakis, Chirag Patel, Markus Nagel* 

  Post-training quantization (PTQ) is the go-to compression technique for large
generative models, such as stable diffusion or large language models. PTQ
methods commonly keep the softmax activation in higher precision as it has been
shown to be very sensitive to quantization noise. However, this can lead to a
significant runtime and power overhead during inference on resource-constraint
edge devices. In this work, we investigate the source of the softmax
sensitivity to quantization and show that the quantization operation leads to a
large bias in the softmax output, causing accuracy degradation. To overcome
this issue, we propose an offline bias correction technique that improves the
quantizability of softmax without additional compute during deployment, as it
can be readily absorbed into the quantization parameters. We demonstrate the
effectiveness of our method on stable diffusion v1.5 and 125M-size OPT language
model, achieving significant accuracy improvement for 8-bit quantized softmax.

---------------

### 18 Mar 2021 | [Data-free mixed-precision quantization using novel sensitivity metric](https://arxiv.org/abs/2103.10051) | [⬇️](https://arxiv.org/pdf/2103.10051)
*Donghyun Lee, Minkyoung Cho, Seungwon Lee, Joonho Song and Changkyu  Choi* 

  Post-training quantization is a representative technique for compressing
neural networks, making them smaller and more efficient for deployment on edge
devices. However, an inaccessible user dataset often makes it difficult to
ensure the quality of the quantized neural network in practice. In addition,
existing approaches may use a single uniform bit-width across the network,
resulting in significant accuracy degradation at extremely low bit-widths. To
utilize multiple bit-width, sensitivity metric plays a key role in balancing
accuracy and compression. In this paper, we propose a novel sensitivity metric
that considers the effect of quantization error on task loss and interaction
with other layers. Moreover, we develop labeled data generation methods that
are not dependent on a specific operation of the neural network. Our
experiments show that the proposed metric better represents quantization
sensitivity, and generated data are more feasible to be applied to
mixed-precision quantization.

---------------

### 16 Mar 2020 | [Loss Aware Post-training Quantization](https://arxiv.org/abs/1911.07190) | [⬇️](https://arxiv.org/pdf/1911.07190)
*Yury Nahshan, Brian Chmiel, Chaim Baskin, Evgenii Zheltonozhskii, Ron  Banner, Alex M. Bronstein, Avi Mendelson* 

  Neural network quantization enables the deployment of large models on
resource-constrained devices. Current post-training quantization methods fall
short in terms of accuracy for INT4 (or lower) but provide reasonable accuracy
for INT8 (or above). In this work, we study the effect of quantization on the
structure of the loss landscape. Additionally, we show that the structure is
flat and separable for mild quantization, enabling straightforward
post-training quantization methods to achieve good results. We show that with
more aggressive quantization, the loss landscape becomes highly non-separable
with steep curvature, making the selection of quantization parameters more
challenging. Armed with this understanding, we design a method that quantizes
the layer parameters jointly, enabling significant accuracy improvement over
current post-training quantization methods. Reference implementation is
available at
https://github.com/ynahshan/nn-quantization-pytorch/tree/master/lapq

---------------

### 27 Mar 2023 | [PD-Quant: Post-Training Quantization based on Prediction Difference  Metric](https://arxiv.org/abs/2212.07048) | [⬇️](https://arxiv.org/pdf/2212.07048)
*Jiawei Liu, Lin Niu, Zhihang Yuan, Dawei Yang, Xinggang Wang, Wenyu  Liu* 

  Post-training quantization (PTQ) is a neural network compression technique
that converts a full-precision model into a quantized model using
lower-precision data types. Although it can help reduce the size and
computational cost of deep neural networks, it can also introduce quantization
noise and reduce prediction accuracy, especially in extremely low-bit settings.
How to determine the appropriate quantization parameters (e.g., scaling factors
and rounding of weights) is the main problem facing now. Existing methods
attempt to determine these parameters by minimize the distance between features
before and after quantization, but such an approach only considers local
information and may not result in the most optimal quantization parameters. We
analyze this issue and ropose PD-Quant, a method that addresses this limitation
by considering global information. It determines the quantization parameters by
using the information of differences between network prediction before and
after quantization. In addition, PD-Quant can alleviate the overfitting problem
in PTQ caused by the small number of calibration sets by adjusting the
distribution of activations. Experiments show that PD-Quant leads to better
quantization parameters and improves the prediction accuracy of quantized
models, especially in low-bit settings. For example, PD-Quant pushes the
accuracy of ResNet-18 up to 53.14% and RegNetX-600MF up to 40.67% in weight
2-bit activation 2-bit. The code is released at
https://github.com/hustvl/PD-Quant.

---------------

### 28 Feb 2024 | [Evaluating Quantized Large Language Models](https://arxiv.org/abs/2402.18158) | [⬇️](https://arxiv.org/pdf/2402.18158)
*Shiyao Li, Xuefei Ning, Luning Wang, Tengxuan Liu, Xiangsheng Shi,  Shengen Yan, Guohao Dai, Huazhong Yang, Yu Wang* 

  Post-training quantization (PTQ) has emerged as a promising technique to
reduce the cost of large language models (LLMs). Specifically, PTQ can
effectively mitigate memory consumption and reduce computational overhead in
LLMs. To meet the requirements of both high efficiency and performance across
diverse scenarios, a comprehensive evaluation of quantized LLMs is essential to
guide the selection of quantization methods. This paper presents a thorough
evaluation of these factors by evaluating the effect of PTQ on Weight,
Activation, and KV Cache on 11 model families, including OPT, LLaMA2, Falcon,
Bloomz, Mistral, ChatGLM, Vicuna, LongChat, StableLM, Gemma, and Mamba, with
parameters ranging from 125M to 180B. The evaluation encompasses five types of
tasks: basic NLP, emergent ability, trustworthiness, dialogue, and long-context
tasks. Moreover, we also evaluate the state-of-the-art (SOTA) quantization
methods to demonstrate their applicability. Based on the extensive experiments,
we systematically summarize the effect of quantization, provide recommendations
to apply quantization techniques, and point out future directions.

---------------

### 26 May 2023 | [ZeroQuant-V2: Exploring Post-training Quantization in LLMs from  Comprehensive Study to Low Rank Compensation](https://arxiv.org/abs/2303.08302) | [⬇️](https://arxiv.org/pdf/2303.08302)
*Zhewei Yao, Xiaoxia Wu, Cheng Li, Stephen Youn, Yuxiong He* 

  Post-training quantization (PTQ) has emerged as a promising technique for
mitigating memory consumption and computational costs in large language models
(LLMs). However, a systematic examination of various quantization schemes,
model families, and quantization bit precision has been absent from the
literature. In this paper, we conduct a comprehensive analysis of these factors
by investigating the effects of PTQ on weight-only, activation-only, and
weight-and-activation quantization using diverse methods such as
round-to-nearest (RTN), GPTQ, ZeroQuant, and their variants. We apply these
methods to two distinct model families with parameters ranging from 125M to
176B. Our contributions include: (1) a sensitivity analysis revealing that
activation quantization is generally more susceptible to weight quantization,
with smaller models often outperforming larger models in terms of activation
quantization; (2) an evaluation and comparison of existing PTQ methods to
optimize model size reduction while minimizing the impact on accuracy,
revealing that none of the current methods can achieve the original model
quality for quantization with either INT4-weight or
INT4-weight-and-INT8-activation; (3) based on these insights, we propose an
optimized method called Low-Rank Compensation (LoRC), which employs low-rank
matrices to enhance model quality recovery with a minimal increase in model
size.

---------------

### 08 May 2023 | [Understanding the Tricks of Deep Learning in Medical Image Segmentation:  Challenges and Future Directions](https://arxiv.org/abs/2209.10307) | [⬇️](https://arxiv.org/pdf/2209.10307)
*Dong Zhang, Yi Lin, Hao Chen, Zhuotao Tian, Xin Yang, Jinhui Tang,  Kwang Ting Cheng* 

  Over the past few years, the rapid development of deep learning technologies
for computer vision has significantly improved the performance of medical image
segmentation (MedISeg). However, the diverse implementation strategies of
various models have led to an extremely complex MedISeg system, resulting in a
potential problem of unfair result comparisons. In this paper, we collect a
series of MedISeg tricks for different model implementation phases (i.e.,
pre-training model, data pre-processing, data augmentation, model
implementation, model inference, and result post-processing), and
experimentally explore the effectiveness of these tricks on consistent
baselines. With the extensive experimental results on both the representative
2D and 3D medical image datasets, we explicitly clarify the effect of these
tricks. Moreover, based on the surveyed tricks, we also open-sourced a strong
MedISeg repository, where each component has the advantage of plug-and-play. We
believe that this milestone work not only completes a comprehensive and
complementary survey of the state-of-the-art MedISeg approaches, but also
offers a practical guide for addressing the future medical image processing
challenges including but not limited to small dataset, class imbalance
learning, multi-modality learning, and domain adaptation. The code and training
weights have been released at: https://github.com/hust-linyi/seg_trick.

---------------

### 02 Feb 2024 | [CBQ: Cross-Block Quantization for Large Language Models](https://arxiv.org/abs/2312.07950) | [⬇️](https://arxiv.org/pdf/2312.07950)
*Xin Ding, Xiaoyu Liu, Zhijun Tu, Yun Zhang, Wei Li, Jie Hu, Hanting  Chen, Yehui Tang, Zhiwei Xiong, Baoqun Yin, Yunhe Wang* 

  Post-training quantization (PTQ) has played a key role in compressing large
language models (LLMs) with ultra-low costs. However, existing PTQ methods only
focus on handling the outliers within one layer or one block, which ignores the
dependency of blocks and leads to severe performance degradation in low-bit
settings. In this paper, we propose CBQ, a cross-block reconstruction-based PTQ
method for LLMs. CBQ employs a cross-block dependency using a homologous
reconstruction scheme, establishing long-range dependencies across multiple
blocks to minimize error accumulation. Furthermore, CBQ incorporates a
coarse-to-fine preprocessing (CFP) strategy for suppressing weight and
activation outliers, coupled with an adaptive LoRA-Rounding technique for
precise weight quantization. These innovations enable CBQ to not only handle
extreme outliers effectively but also improve overall quantization accuracy.
Extensive experiments show that CBQ achieves superior low-bit quantization
(W4A4, W4A8, W2A16) and outperforms existing state-of-the-art methods across
various LLMs and datasets. Notably, CBQ quantizes the 4-bit LLAMA1-65B model
within only 4.3 hours on a single GPU, achieving a commendable tradeoff between
performance and quantization efficiency.

---------------

### 06 Sep 2022 | [What to Prune and What Not to Prune at Initialization](https://arxiv.org/abs/2209.02201) | [⬇️](https://arxiv.org/pdf/2209.02201)
*Maham Haroon* 

  Post-training dropout based approaches achieve high sparsity and are well
established means of deciphering problems relating to computational cost and
overfitting in Neural Network architectures. Contrastingly, pruning at
initialization is still far behind. Initialization pruning is more efficacious
when it comes to scaling computation cost of the network. Furthermore, it
handles overfitting just as well as post training dropout.
  In approbation of the above reasons, the paper presents two approaches to
prune at initialization. The goal is to achieve higher sparsity while
preserving performance. 1) K-starts, begins with k random p-sparse matrices at
initialization. In the first couple of epochs the network then determines the
"fittest" of these p-sparse matrices in an attempt to find the "lottery ticket"
p-sparse network. The approach is adopted from how evolutionary algorithms find
the best individual. Depending on the Neural Network architecture, fitness
criteria can be based on magnitude of network weights, magnitude of gradient
accumulation over an epoch or a combination of both. 2) Dissipating gradients
approach, aims at eliminating weights that remain within a fraction of their
initial value during the first couple of epochs. Removing weights in this
manner despite their magnitude best preserves performance of the network.
Contrarily, the approach also takes the most epochs to achieve higher sparsity.
3) Combination of dissipating gradients and kstarts outperforms either methods
and random dropout consistently.
  The benefits of using the provided pertaining approaches are: 1) They do not
require specific knowledge of the classification task, fixing of dropout
threshold or regularization parameters 2) Retraining of the model is neither
necessary nor affects the performance of the p-sparse network.

---------------

### 04 Apr 2023 | [Solving Oscillation Problem in Post-Training Quantization Through a  Theoretical Perspective](https://arxiv.org/abs/2303.11906) | [⬇️](https://arxiv.org/pdf/2303.11906)
*Yuexiao Ma, Huixia Li, Xiawu Zheng, Xuefeng Xiao, Rui Wang, Shilei  Wen, Xin Pan, Fei Chao, Rongrong Ji* 

  Post-training quantization (PTQ) is widely regarded as one of the most
efficient compression methods practically, benefitting from its data privacy
and low computation costs. We argue that an overlooked problem of oscillation
is in the PTQ methods. In this paper, we take the initiative to explore and
present a theoretical proof to explain why such a problem is essential in PTQ.
And then, we try to solve this problem by introducing a principled and
generalized framework theoretically. In particular, we first formulate the
oscillation in PTQ and prove the problem is caused by the difference in module
capacity. To this end, we define the module capacity (ModCap) under
data-dependent and data-free scenarios, where the differentials between
adjacent modules are used to measure the degree of oscillation. The problem is
then solved by selecting top-k differentials, in which the corresponding
modules are jointly optimized and quantized. Extensive experiments demonstrate
that our method successfully reduces the performance drop and is generalized to
different neural networks and PTQ methods. For example, with 2/4 bit ResNet-50
quantization, our method surpasses the previous state-of-the-art method by
1.9%. It becomes more significant on small model quantization, e.g. surpasses
BRECQ method by 6.61% on MobileNetV2*0.5.

---------------

### 09 Dec 2023 | [Efficient Quantization Strategies for Latent Diffusion Models](https://arxiv.org/abs/2312.05431) | [⬇️](https://arxiv.org/pdf/2312.05431)
*Yuewei Yang, Xiaoliang Dai, Jialiang Wang, Peizhao Zhang, Hongbo Zhang* 

  Latent Diffusion Models (LDMs) capture the dynamic evolution of latent
variables over time, blending patterns and multimodality in a generative
system. Despite the proficiency of LDM in various applications, such as
text-to-image generation, facilitated by robust text encoders and a variational
autoencoder, the critical need to deploy large generative models on edge
devices compels a search for more compact yet effective alternatives. Post
Training Quantization (PTQ), a method to compress the operational size of deep
learning models, encounters challenges when applied to LDM due to temporal and
structural complexities. This study proposes a quantization strategy that
efficiently quantize LDMs, leveraging Signal-to-Quantization-Noise Ratio (SQNR)
as a pivotal metric for evaluation. By treating the quantization discrepancy as
relative noise and identifying sensitive part(s) of a model, we propose an
efficient quantization approach encompassing both global and local strategies.
The global quantization process mitigates relative quantization noise by
initiating higher-precision quantization on sensitive blocks, while local
treatments address specific challenges in quantization-sensitive and
time-sensitive modules. The outcomes of our experiments reveal that the
implementation of both global and local treatments yields a highly efficient
and effective Post Training Quantization (PTQ) of LDMs.

---------------

### 27 Mar 2021 | [Automated Backend-Aware Post-Training Quantization](https://arxiv.org/abs/2103.14949) | [⬇️](https://arxiv.org/pdf/2103.14949)
*Ziheng Jiang, Animesh Jain, Andrew Liu, Josh Fromm, Chengqian Ma,  Tianqi Chen, Luis Ceze* 

  Quantization is a key technique to reduce the resource requirement and
improve the performance of neural network deployment. However, different
hardware backends such as x86 CPU, NVIDIA GPU, ARM CPU, and accelerators may
demand different implementations for quantized networks. This diversity calls
for specialized post-training quantization pipelines to built for each hardware
target, an engineering effort that is often too large for developers to keep up
with. We tackle this problem with an automated post-training quantization
framework called HAGO. HAGO provides a set of general quantization graph
transformations based on a user-defined hardware specification and implements a
search mechanism to find the optimal quantization strategy while satisfying
hardware constraints for any model. We observe that HAGO achieves speedups of
2.09x, 1.97x, and 2.48x on Intel Xeon Cascade Lake CPUs, NVIDIA Tesla T4 GPUs,
ARM Cortex-A CPUs on Raspberry Pi4 relative to full precision respectively,
while maintaining the highest reported post-training quantization accuracy in
each case.

---------------
**Date:** 30 Jun 2020

**Title:** EasyQuant: Post-training Quantization via Scale Optimization

**Abstract Link:** [https://arxiv.org/abs/2006.16669](https://arxiv.org/abs/2006.16669)

**PDF Link:** [https://arxiv.org/pdf/2006.16669](https://arxiv.org/pdf/2006.16669)

---

**Date:** 28 Oct 2021

**Title:** Post-Training Sparsity-Aware Quantization

**Abstract Link:** [https://arxiv.org/abs/2105.11010](https://arxiv.org/abs/2105.11010)

**PDF Link:** [https://arxiv.org/pdf/2105.11010](https://arxiv.org/pdf/2105.11010)

---

**Date:** 23 Mar 2023

**Title:** Benchmarking the Reliability of Post-training Quantization: a Particular  Focus on Worst-case Performance

**Abstract Link:** [https://arxiv.org/abs/2303.13003](https://arxiv.org/abs/2303.13003)

**PDF Link:** [https://arxiv.org/pdf/2303.13003](https://arxiv.org/pdf/2303.13003)

---

**Date:** 21 Jan 2023

**Title:** Adapting a Language Model While Preserving its General Knowledge

**Abstract Link:** [https://arxiv.org/abs/2301.08986](https://arxiv.org/abs/2301.08986)

**PDF Link:** [https://arxiv.org/pdf/2301.08986](https://arxiv.org/pdf/2301.08986)

---

**Date:** 16 Sep 2023

**Title:** Distributionally Robust Post-hoc Classifiers under Prior Shifts

**Abstract Link:** [https://arxiv.org/abs/2309.08825](https://arxiv.org/abs/2309.08825)

**PDF Link:** [https://arxiv.org/pdf/2309.08825](https://arxiv.org/pdf/2309.08825)

---

**Date:** 19 Aug 2023

**Title:** Q-HyViT: Post-Training Quantization for Hybrid Vision Transformer with  Bridge Block Reconstruction

**Abstract Link:** [https://arxiv.org/abs/2303.12557](https://arxiv.org/abs/2303.12557)

**PDF Link:** [https://arxiv.org/pdf/2303.12557](https://arxiv.org/pdf/2303.12557)

---

**Date:** 22 Oct 2020

**Title:** Posterior Re-calibration for Imbalanced Datasets

**Abstract Link:** [https://arxiv.org/abs/2010.11820](https://arxiv.org/abs/2010.11820)

**PDF Link:** [https://arxiv.org/pdf/2010.11820](https://arxiv.org/pdf/2010.11820)

---

**Date:** 21 Nov 2023

**Title:** Post-Training Quantization with Low-precision Minifloats and Integers on  FPGAs

**Abstract Link:** [https://arxiv.org/abs/2311.12359](https://arxiv.org/abs/2311.12359)

**PDF Link:** [https://arxiv.org/pdf/2311.12359](https://arxiv.org/pdf/2311.12359)

---

**Date:** 04 Sep 2023

**Title:** Softmax Bias Correction for Quantized Generative Models

**Abstract Link:** [https://arxiv.org/abs/2309.01729](https://arxiv.org/abs/2309.01729)

**PDF Link:** [https://arxiv.org/pdf/2309.01729](https://arxiv.org/pdf/2309.01729)

---

**Date:** 18 Mar 2021

**Title:** Data-free mixed-precision quantization using novel sensitivity metric

**Abstract Link:** [https://arxiv.org/abs/2103.10051](https://arxiv.org/abs/2103.10051)

**PDF Link:** [https://arxiv.org/pdf/2103.10051](https://arxiv.org/pdf/2103.10051)

---

**Date:** 16 Mar 2020

**Title:** Loss Aware Post-training Quantization

**Abstract Link:** [https://arxiv.org/abs/1911.07190](https://arxiv.org/abs/1911.07190)

**PDF Link:** [https://arxiv.org/pdf/1911.07190](https://arxiv.org/pdf/1911.07190)

---

**Date:** 27 Mar 2023

**Title:** PD-Quant: Post-Training Quantization based on Prediction Difference  Metric

**Abstract Link:** [https://arxiv.org/abs/2212.07048](https://arxiv.org/abs/2212.07048)

**PDF Link:** [https://arxiv.org/pdf/2212.07048](https://arxiv.org/pdf/2212.07048)

---

**Date:** 28 Feb 2024

**Title:** Evaluating Quantized Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.18158](https://arxiv.org/abs/2402.18158)

**PDF Link:** [https://arxiv.org/pdf/2402.18158](https://arxiv.org/pdf/2402.18158)

---

**Date:** 26 May 2023

**Title:** ZeroQuant-V2: Exploring Post-training Quantization in LLMs from  Comprehensive Study to Low Rank Compensation

**Abstract Link:** [https://arxiv.org/abs/2303.08302](https://arxiv.org/abs/2303.08302)

**PDF Link:** [https://arxiv.org/pdf/2303.08302](https://arxiv.org/pdf/2303.08302)

---

**Date:** 08 May 2023

**Title:** Understanding the Tricks of Deep Learning in Medical Image Segmentation:  Challenges and Future Directions

**Abstract Link:** [https://arxiv.org/abs/2209.10307](https://arxiv.org/abs/2209.10307)

**PDF Link:** [https://arxiv.org/pdf/2209.10307](https://arxiv.org/pdf/2209.10307)

---

**Date:** 02 Feb 2024

**Title:** CBQ: Cross-Block Quantization for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2312.07950](https://arxiv.org/abs/2312.07950)

**PDF Link:** [https://arxiv.org/pdf/2312.07950](https://arxiv.org/pdf/2312.07950)

---

**Date:** 06 Sep 2022

**Title:** What to Prune and What Not to Prune at Initialization

**Abstract Link:** [https://arxiv.org/abs/2209.02201](https://arxiv.org/abs/2209.02201)

**PDF Link:** [https://arxiv.org/pdf/2209.02201](https://arxiv.org/pdf/2209.02201)

---

**Date:** 04 Apr 2023

**Title:** Solving Oscillation Problem in Post-Training Quantization Through a  Theoretical Perspective

**Abstract Link:** [https://arxiv.org/abs/2303.11906](https://arxiv.org/abs/2303.11906)

**PDF Link:** [https://arxiv.org/pdf/2303.11906](https://arxiv.org/pdf/2303.11906)

---

**Date:** 09 Dec 2023

**Title:** Efficient Quantization Strategies for Latent Diffusion Models

**Abstract Link:** [https://arxiv.org/abs/2312.05431](https://arxiv.org/abs/2312.05431)

**PDF Link:** [https://arxiv.org/pdf/2312.05431](https://arxiv.org/pdf/2312.05431)

---

**Date:** 27 Mar 2021

**Title:** Automated Backend-Aware Post-Training Quantization

**Abstract Link:** [https://arxiv.org/abs/2103.14949](https://arxiv.org/abs/2103.14949)

**PDF Link:** [https://arxiv.org/pdf/2103.14949](https://arxiv.org/pdf/2103.14949)

---

