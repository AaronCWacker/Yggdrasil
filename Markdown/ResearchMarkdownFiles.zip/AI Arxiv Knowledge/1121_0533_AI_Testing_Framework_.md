AI Testing Framework ⚖️

### 🔎 AI Testing Framework ⚖️


========================

[![Build Status](https://travis-ci.org/microsoft/AI-Testing-Framework.svg?branch=master)](https://travis-ci.org/microsoft/AI-Testing-Framework)
[![codecov](https://codecov.io/gh/microsoft/AI-Testing-Framework/branch/master/graph/badge.svg)](https://codecov.io/gh/microsoft/AI-Testing-Framework)
[![PyPI version](https://badge.fury.io/py/aitesting.svg)](https://badge.fury.io/py/aitesting)
[![Python 3.6](https://img.shields.io/badge/python-3.6-blue.svg)](https://www.python.org/downloads/release/python-360/)
[![Python 3.7](https://img.shields.io/badge/python-3.7-blue.svg)](https://www.python.org/downloads/release/python-370/)
[![Python 3.8](https://img.shields.io/badge/python-3.8-blue.svg)](https://www.python.org/downloads/release/python-380/)
[![Python 3.9](https://img.shields.io/badge/python-3.9-blue.svg)](https://www.python.org/downloads/release/python-390/)


This is a testing framework for AI models. It is designed to be used with [pytest](https://docs.pytest.org/en/latest/).


## Installation

Install the package from [PyPI](https://pypi.org/project/aitesting/) using pip:

```
pip install aitesting
```


## Usage

The framework provides a set of fixtures that can be used to test AI models.


### Testing a model

To test a model, you can use the `model` fixture. This fixture provides a `Model` object that can be used to make predictions.

# 🩺🔍 Search Results
### 07 Oct 2021 | [Automated Testing of AI Models](https://arxiv.org/abs/2110.03320) | [⬇️](https://arxiv.org/pdf/2110.03320)
*Swagatam Haldar, Deepak Vijaykeerthy, Diptikalyan Saha* 

  The last decade has seen tremendous progress in AI technology and
applications. With such widespread adoption, ensuring the reliability of the AI
models is crucial. In past, we took the first step of creating a testing
framework called AITEST for metamorphic properties such as fairness, robustness
properties for tabular, time-series, and text classification models. In this
paper, we extend the capability of the AITEST tool to include the testing
techniques for Image and Speech-to-text models along with interpretability
testing for tabular models. These novel extensions make AITEST a comprehensive
framework for testing AI models.

---------------

### 11 Feb 2021 | [Testing Framework for Black-box AI Models](https://arxiv.org/abs/2102.06166) | [⬇️](https://arxiv.org/pdf/2102.06166)
*Aniya Aggarwal, Samiulla Shaikh, Sandeep Hans, Swastik Haldar, Rema  Ananthanarayanan, Diptikalyan Saha* 

  With widespread adoption of AI models for important decision making, ensuring
reliability of such models remains an important challenge. In this paper, we
present an end-to-end generic framework for testing AI Models which performs
automated test generation for different modalities such as text, tabular, and
time-series data and across various properties such as accuracy, fairness, and
robustness. Our tool has been used for testing industrial AI models and was
very effective to uncover issues present in those models. Demo video link:
https://youtu.be/984UCU17YZI

---------------

### 06 Dec 2023 | [OMNIINPUT: A Model-centric Evaluation Framework through Output  Distribution](https://arxiv.org/abs/2312.03291) | [⬇️](https://arxiv.org/pdf/2312.03291)
*Weitang Liu, Ying Wai Li, Tianle Wang, Yi-Zhuang You, Jingbo Shang* 

  We propose a novel model-centric evaluation framework, OmniInput, to evaluate
the quality of an AI/ML model's predictions on all possible inputs (including
human-unrecognizable ones), which is crucial for AI safety and reliability.
Unlike traditional data-centric evaluation based on pre-defined test sets, the
test set in OmniInput is self-constructed by the model itself and the model
quality is evaluated by investigating its output distribution. We employ an
efficient sampler to obtain representative inputs and the output distribution
of the trained model, which, after selective annotation, can be used to
estimate the model's precision and recall at different output values and a
comprehensive precision-recall curve. Our experiments demonstrate that
OmniInput enables a more fine-grained comparison between models, especially
when their performance is almost the same on pre-defined datasets, leading to
new findings and insights for how to train more robust, generalizable models.

---------------

### 16 Nov 2022 | [A Neural Active Inference Model of Perceptual-Motor Learning](https://arxiv.org/abs/2211.10419) | [⬇️](https://arxiv.org/pdf/2211.10419)
*Zhizhuo Yang, Gabriel J. Diaz, Brett R. Fajen, Reynold Bailey,  Alexander Ororbia* 

  The active inference framework (AIF) is a promising new computational
framework grounded in contemporary neuroscience that can produce human-like
behavior through reward-based learning. In this study, we test the ability for
the AIF to capture the role of anticipation in the visual guidance of action in
humans through the systematic investigation of a visual-motor task that has
been well-explored -- that of intercepting a target moving over a ground plane.
Previous research demonstrated that humans performing this task resorted to
anticipatory changes in speed intended to compensate for semi-predictable
changes in target speed later in the approach. To capture this behavior, our
proposed "neural" AIF agent uses artificial neural networks to select actions
on the basis of a very short term prediction of the information about the task
environment that these actions would reveal along with a long-term estimate of
the resulting cumulative expected free energy. Systematic variation revealed
that anticipatory behavior emerged only when required by limitations on the
agent's movement capabilities, and only when the agent was able to estimate
accumulated free energy over sufficiently long durations into the future. In
addition, we present a novel formulation of the prior function that maps a
multi-dimensional world-state to a uni-dimensional distribution of free-energy.
Together, these results demonstrate the use of AIF as a plausible model of
anticipatory visually guided behavior in humans.

---------------

### 20 Dec 2021 | [Asymmetric Shapley values: incorporating causal knowledge into  model-agnostic explainability](https://arxiv.org/abs/1910.06358) | [⬇️](https://arxiv.org/pdf/1910.06358)
*Christopher Frye, Colin Rowat, Ilya Feige* 

  Explaining AI systems is fundamental both to the development of high
performing models and to the trust placed in them by their users. The Shapley
framework for explainability has strength in its general applicability combined
with its precise, rigorous foundation: it provides a common, model-agnostic
language for AI explainability and uniquely satisfies a set of intuitive
mathematical axioms. However, Shapley values are too restrictive in one
significant regard: they ignore all causal structure in the data. We introduce
a less restrictive framework, Asymmetric Shapley values (ASVs), which are
rigorously founded on a set of axioms, applicable to any AI system, and
flexible enough to incorporate any causal structure known to be respected by
the data. We demonstrate that ASVs can (i) improve model explanations by
incorporating causal information, (ii) provide an unambiguous test for unfair
discrimination in model predictions, (iii) enable sequentially incremental
explanations in time-series models, and (iv) support feature-selection studies
without the need for model retraining.

---------------

### 26 Jan 2022 | [Discovering Boundary Values of Feature-based Machine Learning  Classifiers through Exploratory Datamorphic Testing](https://arxiv.org/abs/2110.00330) | [⬇️](https://arxiv.org/pdf/2110.00330)
*Hong Zhu and Ian Bayley* 

  Testing has been widely recognised as difficult for AI applications. This
paper proposes a set of testing strategies for testing machine learning
applications in the framework of the datamorphism testing methodology. In these
strategies, testing aims at exploring the data space of a classification or
clustering application to discover the boundaries between classes that the
machine learning application defines. This enables the tester to understand
precisely the behaviour and function of the software under test. In the paper,
three variants of exploratory strategies are presented with the algorithms
implemented in the automated datamorphic testing tool Morphy. The correctness
of these algorithms are formally proved. Their capability and cost of
discovering borders between classes are evaluated via a set of controlled
experiments with manually designed subjects and a set of case studies with real
machine learning models.

---------------

### 22 Feb 2019 | [General Video Game AI: a Multi-Track Framework for Evaluating Agents,  Games and Content Generation Algorithms](https://arxiv.org/abs/1802.10363) | [⬇️](https://arxiv.org/pdf/1802.10363)
*Diego Perez-Liebana, Jialin Liu, Ahmed Khalifa, Raluca D. Gaina,  Julian Togelius, Simon M. Lucas* 

  General Video Game Playing (GVGP) aims at designing an agent that is capable
of playing multiple video games with no human intervention. In 2014, The
General Video Game AI (GVGAI) competition framework was created and released
with the purpose of providing researchers a common open-source and easy to use
platform for testing their AI methods with potentially infinity of games
created using Video Game Description Language (VGDL). The framework has been
expanded into several tracks during the last few years to meet the demand of
different research directions. The agents are required either to play multiple
unknown games with or without access to game simulations, or to design new game
levels or rules. This survey paper presents the VGDL, the GVGAI framework,
existing tracks, and reviews the wide use of GVGAI framework in research,
education and competitions five years after its birth. A future plan of
framework improvements is also described.

---------------

### 07 Sep 2021 | [ViSTA: a Framework for Virtual Scenario-based Testing of Autonomous  Vehicles](https://arxiv.org/abs/2109.02529) | [⬇️](https://arxiv.org/pdf/2109.02529)
*Andrea Piazzoni, Jim Cherian, Mohamed Azhar, Jing Yew Yap, James Lee  Wei Shung, Roshan Vijay* 

  In this paper, we present ViSTA, a framework for Virtual Scenario-based
Testing of Autonomous Vehicles (AV), developed as part of the 2021 IEEE
Autonomous Test Driving AI Test Challenge. Scenario-based virtual testing aims
to construct specific challenges posed for the AV to overcome, albeit in
virtual test environments that may not necessarily resemble the real world.
This approach is aimed at identifying specific issues that arise safety
concerns before an actual deployment of the AV on the road. In this paper, we
describe a comprehensive test case generation approach that facilitates the
design of special-purpose scenarios with meaningful parameters to form test
cases, both in automated and manual ways, leveraging the strength and
weaknesses of either. Furthermore, we describe how to automate the execution of
test cases, and analyze the performance of the AV under these test cases.

---------------

### 08 Oct 2019 | [Designing Trustworthy AI: A Human-Machine Teaming Framework to Guide  Development](https://arxiv.org/abs/1910.03515) | [⬇️](https://arxiv.org/pdf/1910.03515)
*Carol J. Smith* 

  Artificial intelligence (AI) holds great promise to empower us with knowledge
and augment our effectiveness. We can -- and must -- ensure that we keep humans
safe and in control, particularly with regard to government and public sector
applications that affect broad populations. How can AI development teams
harness the power of AI systems and design them to be valuable to humans?
Diverse teams are needed to build trustworthy artificial intelligent systems,
and those teams need to coalesce around a shared set of ethics. There are many
discussions in the AI field about ethics and trust, but there are few
frameworks available for people to use as guidance when creating these systems.
The Human-Machine Teaming (HMT) Framework for Designing Ethical AI Experiences
described in this paper, when used with a set of technical ethics, will guide
AI development teams to create AI systems that are accountable, de-risked,
respectful, secure, honest, and usable. To support the team's efforts,
activities to understand people's needs and concerns will be introduced along
with the themes to support the team's efforts. For example, usability testing
can help determine if the audience understands how the AI system works and
complies with the HMT Framework. The HMT Framework is based on reviews of
existing ethical codes and best practices in human-computer interaction and
software development. Human-machine teams are strongest when human users can
trust AI systems to behave as expected, safely, securely, and understandably.
Using the HMT Framework to design trustworthy AI systems will provide support
to teams in identifying potential issues ahead of time and making great
experiences for humans.

---------------

### 26 Oct 2021 | [Automated Support for Unit Test Generation: A Tutorial Book Chapter](https://arxiv.org/abs/2110.13575) | [⬇️](https://arxiv.org/pdf/2110.13575)
*Afonso Fontes, Gregory Gay, Francisco Gomes de Oliveira Neto, Robert  Feldt* 

  Unit testing is a stage of testing where the smallest segment of code that
can be tested in isolation from the rest of the system - often a class - is
tested. Unit tests are typically written as executable code, often in a format
provided by a unit testing framework such as pytest for Python.
  Creating unit tests is a time and effort-intensive process with many
repetitive, manual elements. To illustrate how AI can support unit testing,
this chapter introduces the concept of search-based unit test generation. This
technique frames the selection of test input as an optimization problem - we
seek a set of test cases that meet some measurable goal of a tester - and
unleashes powerful metaheuristic search algorithms to identify the best
possible test cases within a restricted timeframe. This chapter introduces two
algorithms that can generate pytest-formatted unit tests, tuned towards
coverage of source code statements. The chapter concludes by discussing more
advanced concepts and gives pointers to further reading for how artificial
intelligence can support developers and testers when unit testing software.

---------------

### 21 Dec 2022 | [FAIR principles for AI models with a practical application for  accelerated high energy diffraction microscopy](https://arxiv.org/abs/2207.00611) | [⬇️](https://arxiv.org/pdf/2207.00611)
*Nikil Ravi, Pranshu Chaturvedi, E. A. Huerta, Zhengchun Liu, Ryan  Chard, Aristana Scourtas, K.J. Schmidt, Kyle Chard, Ben Blaiszik and Ian  Foster* 

  A concise and measurable set of FAIR (Findable, Accessible, Interoperable and
Reusable) principles for scientific data is transforming the state-of-practice
for data management and stewardship, supporting and enabling discovery and
innovation. Learning from this initiative, and acknowledging the impact of
artificial intelligence (AI) in the practice of science and engineering, we
introduce a set of practical, concise, and measurable FAIR principles for AI
models. We showcase how to create and share FAIR data and AI models within a
unified computational framework combining the following elements: the Advanced
Photon Source at Argonne National Laboratory, the Materials Data Facility, the
Data and Learning Hub for Science, and funcX, and the Argonne Leadership
Computing Facility (ALCF), in particular the ThetaGPU supercomputer and the
SambaNova DataScale system at the ALCF AI Testbed. We describe how this
domain-agnostic computational framework may be harnessed to enable autonomous
AI-driven discovery.

---------------

### 26 Sep 2022 | [Integrated multimodal artificial intelligence framework for healthcare  applications](https://arxiv.org/abs/2202.12998) | [⬇️](https://arxiv.org/pdf/2202.12998)
*Luis R. Soenksen, Yu Ma, Cynthia Zeng, Leonard D.J. Boussioux,  Kimberly Villalobos Carballo, Liangyuan Na, Holly M. Wiberg, Michael L. Li,  Ignacio Fuentes, Dimitris Bertsimas* 

  Artificial intelligence (AI) systems hold great promise to improve healthcare
over the next decades. Specifically, AI systems leveraging multiple data
sources and input modalities are poised to become a viable method to deliver
more accurate results and deployable pipelines across a wide range of
applications. In this work, we propose and evaluate a unified Holistic AI in
Medicine (HAIM) framework to facilitate the generation and testing of AI
systems that leverage multimodal inputs. Our approach uses generalizable data
pre-processing and machine learning modeling stages that can be readily adapted
for research and deployment in healthcare environments. We evaluate our HAIM
framework by training and characterizing 14,324 independent models based on
HAIM-MIMIC-MM, a multimodal clinical database (N=34,537 samples) containing
7,279 unique hospitalizations and 6,485 patients, spanning all possible input
combinations of 4 data modalities (i.e., tabular, time-series, text, and
images), 11 unique data sources and 12 predictive tasks. We show that this
framework can consistently and robustly produce models that outperform similar
single-source approaches across various healthcare demonstrations (by 6-33%),
including 10 distinct chest pathology diagnoses, along with length-of-stay and
48-hour mortality predictions. We also quantify the contribution of each
modality and data source using Shapley values, which demonstrates the
heterogeneity in data modality importance and the necessity of multimodal
inputs across different healthcare-relevant tasks. The generalizable properties
and flexibility of our Holistic AI in Medicine (HAIM) framework could offer a
promising pathway for future multimodal predictive systems in clinical and
operational healthcare settings.

---------------

### 14 Jan 2022 | [Tools and Practices for Responsible AI Engineering](https://arxiv.org/abs/2201.05647) | [⬇️](https://arxiv.org/pdf/2201.05647)
*Ryan Soklaski, Justin Goodwin, Olivia Brown, Michael Yee and Jason  Matterer* 

  Responsible Artificial Intelligence (AI) - the practice of developing,
evaluating, and maintaining accurate AI systems that also exhibit essential
properties such as robustness and explainability - represents a multifaceted
challenge that often stretches standard machine learning tooling, frameworks,
and testing methods beyond their limits. In this paper, we present two new
software libraries - hydra-zen and the rAI-toolbox - that address critical
needs for responsible AI engineering. hydra-zen dramatically simplifies the
process of making complex AI applications configurable, and their behaviors
reproducible. The rAI-toolbox is designed to enable methods for evaluating and
enhancing the robustness of AI-models in a way that is scalable and that
composes naturally with other popular ML frameworks. We describe the design
principles and methodologies that make these tools effective, including the use
of property-based testing to bolster the reliability of the tools themselves.
Finally, we demonstrate the composability and flexibility of the tools by
showing how various use cases from adversarial robustness and explainable AI
can be concisely implemented with familiar APIs.

---------------

### 24 May 2023 | [Measuring Bias in AI Models: An Statistical Approach Introducing N-Sigma](https://arxiv.org/abs/2304.13680) | [⬇️](https://arxiv.org/pdf/2304.13680)
*Daniel DeAlcala, Ignacio Serna, Aythami Morales, Julian Fierrez,  Javier Ortega-Garcia* 

  The new regulatory framework proposal on Artificial Intelligence (AI)
published by the European Commission establishes a new risk-based legal
approach. The proposal highlights the need to develop adequate risk assessments
for the different uses of AI. This risk assessment should address, among
others, the detection and mitigation of bias in AI. In this work we analyze
statistical approaches to measure biases in automatic decision-making systems.
We focus our experiments in face recognition technologies. We propose a novel
way to measure the biases in machine learning models using a statistical
approach based on the N-Sigma method. N-Sigma is a popular statistical approach
used to validate hypotheses in general science such as physics and social areas
and its application to machine learning is yet unexplored. In this work we
study how to apply this methodology to develop new risk assessment frameworks
based on bias analysis and we discuss the main advantages and drawbacks with
respect to other popular statistical tests.

---------------

### 06 Oct 2021 | [Trustworthy Artificial Intelligence and Process Mining: Challenges and  Opportunities](https://arxiv.org/abs/2110.02707) | [⬇️](https://arxiv.org/pdf/2110.02707)
*Andrew Pery, Majid Rafiei, Michael Simon, Wil M.P. van der Aalst* 

  The premise of this paper is that compliance with Trustworthy AI governance
best practices and regulatory frameworks is an inherently fragmented process
spanning across diverse organizational units, external stakeholders, and
systems of record, resulting in process uncertainties and in compliance gaps
that may expose organizations to reputational and regulatory risks. Moreover,
there are complexities associated with meeting the specific dimensions of
Trustworthy AI best practices such as data governance, conformance testing,
quality assurance of AI model behaviors, transparency, accountability, and
confidentiality requirements. These processes involve multiple steps,
hand-offs, re-works, and human-in-the-loop oversight. In this paper, we
demonstrate that process mining can provide a useful framework for gaining
fact-based visibility to AI compliance process execution, surfacing compliance
bottlenecks, and providing for an automated approach to analyze, remediate and
monitor uncertainty in AI regulatory compliance processes.

---------------

### 27 Feb 2020 | [Clinical acceptance of software based on artificial intelligence  technologies (radiology)](https://arxiv.org/abs/1908.00381) | [⬇️](https://arxiv.org/pdf/1908.00381)
*S.P. Morozov, A.V. Vladzymyrskyy, V.G. Klyashtornyy, A.E.  Andreychenko, N.S. Kulberg, V.A. Gombolevsky, K.A. Sergunova* 

  Aim: provide a methodological framework for the process of clinical tests,
clinical acceptance, and scientific assessment of algorithms and software based
on the artificial intelligence (AI) technologies. Clinical tests are considered
as a preparation stage for the software registration as a medical product. The
authors propose approaches to evaluate accuracy and efficiency of the AI
algorithms for radiology.

---------------

### 15 Jun 2022 | [Deep Learning and Handheld Augmented Reality Based System for Optimal  Data Collection in Fault Diagnostics Domain](https://arxiv.org/abs/2206.07772) | [⬇️](https://arxiv.org/pdf/2206.07772)
*Ryan Nguyen and Rahul Rai* 

  Compared to current AI or robotic systems, humans navigate their environment
with ease, making tasks such as data collection trivial. However, humans find
it harder to model complex relationships hidden in the data. AI systems,
especially deep learning (DL) algorithms, impressively capture those complex
relationships. Symbiotically coupling humans and computational machines'
strengths can simultaneously minimize the collected data required and build
complex input-to-output mapping models. This paper enables this coupling by
presenting a novel human-machine interaction framework to perform fault
diagnostics with minimal data. Collecting data for diagnosing faults for
complex systems is difficult and time-consuming. Minimizing the required data
will increase the practicability of data-driven models in diagnosing faults.
The framework provides instructions to a human user to collect data that
mitigates the difference between the data used to train and test the fault
diagnostics model. The framework is composed of three components: (1) a
reinforcement learning algorithm for data collection to develop a training
dataset, (2) a deep learning algorithm for diagnosing faults, and (3) a
handheld augmented reality application for data collection for testing data.
The proposed framework has provided above 100\% precision and recall on a novel
dataset with only one instance of each fault condition. Additionally, a
usability study was conducted to gauge the user experience of the handheld
augmented reality application, and all users were able to follow the provided
steps.

---------------

### 18 May 2020 | [A Continuous Information Gain Measure to Find the Most Discriminatory  Problems for AI Benchmarking](https://arxiv.org/abs/1809.02904) | [⬇️](https://arxiv.org/pdf/1809.02904)
*Matthew Stephenson, Damien Anderson, Ahmed Khalifa, John Levine,  Jochen Renz, Julian Togelius, Christoph Salge* 

  This paper introduces an information-theoretic method for selecting a subset
of problems which gives the most information about a group of problem-solving
algorithms. This method was tested on the games in the General Video Game AI
(GVGAI) framework, allowing us to identify a smaller set of games that still
gives a large amount of information about the abilities of different
game-playing agents. This approach can be used to make agent testing more
efficient. We can achieve almost as good discriminatory accuracy when testing
on only a handful of games as when testing on more than a hundred games,
something which is often computationally infeasible. Furthermore, this method
can be extended to study the dimensions of the effective variance in game
design between these games, allowing us to identify which games differentiate
between agents in the most complementary ways.

---------------

### 06 Jun 2020 | [Efficient Black-box Assessment of Autonomous Vehicle Safety](https://arxiv.org/abs/1912.03618) | [⬇️](https://arxiv.org/pdf/1912.03618)
*Justin Norden, Matthew O'Kelly, Aman Sinha* 

  While autonomous vehicle (AV) technology has shown substantial progress, we
still lack tools for rigorous and scalable testing. Real-world testing, the
$\textit{de-facto}$ evaluation method, is dangerous to the public. Moreover,
due to the rare nature of failures, billions of miles of driving are needed to
statistically validate performance claims. Thus, the industry has largely
turned to simulation to evaluate AV systems. However, having a simulation stack
alone is not a solution. A simulation testing framework needs to prioritize
which scenarios to run, learn how the chosen scenarios provide coverage of
failure modes, and rank failure scenarios in order of importance. We implement
a simulation testing framework that evaluates an entire modern AV system as a
black box. This framework estimates the probability of accidents under a base
distribution governing standard traffic behavior. In order to accelerate
rare-event probability evaluation, we efficiently learn to identify and rank
failure scenarios via adaptive importance-sampling methods. Using this
framework, we conduct the first independent evaluation of a full-stack
commercial AV system, Comma AI's OpenPilot.

---------------

### 14 Oct 2023 | [Unjustified Sample Sizes and Generalizations in Explainable AI Research:  Principles for More Inclusive User Studies](https://arxiv.org/abs/2305.09477) | [⬇️](https://arxiv.org/pdf/2305.09477)
*Uwe Peters, Mary Carman* 

  Many ethical frameworks require artificial intelligence (AI) systems to be
explainable. Explainable AI (XAI) models are frequently tested for their
adequacy in user studies. Since different people may have different explanatory
needs, it is important that participant samples in user studies are large
enough to represent the target population to enable generalizations. However,
it is unclear to what extent XAI researchers reflect on and justify their
sample sizes or avoid broad generalizations across people. We analyzed XAI user
studies (n = 220) published between 2012 and 2022. Most studies did not offer
rationales for their sample sizes. Moreover, most papers generalized their
conclusions beyond their target population, and there was no evidence that
broader conclusions in quantitative studies were correlated with larger
samples. These methodological problems can impede evaluations of whether XAI
systems implement the explainability called for in ethical frameworks. We
outline principles for more inclusive XAI user studies.

---------------
**Date:** 07 Oct 2021

**Title:** Automated Testing of AI Models

**Abstract Link:** [https://arxiv.org/abs/2110.03320](https://arxiv.org/abs/2110.03320)

**PDF Link:** [https://arxiv.org/pdf/2110.03320](https://arxiv.org/pdf/2110.03320)

---

**Date:** 11 Feb 2021

**Title:** Testing Framework for Black-box AI Models

**Abstract Link:** [https://arxiv.org/abs/2102.06166](https://arxiv.org/abs/2102.06166)

**PDF Link:** [https://arxiv.org/pdf/2102.06166](https://arxiv.org/pdf/2102.06166)

---

**Date:** 06 Dec 2023

**Title:** OMNIINPUT: A Model-centric Evaluation Framework through Output  Distribution

**Abstract Link:** [https://arxiv.org/abs/2312.03291](https://arxiv.org/abs/2312.03291)

**PDF Link:** [https://arxiv.org/pdf/2312.03291](https://arxiv.org/pdf/2312.03291)

---

**Date:** 16 Nov 2022

**Title:** A Neural Active Inference Model of Perceptual-Motor Learning

**Abstract Link:** [https://arxiv.org/abs/2211.10419](https://arxiv.org/abs/2211.10419)

**PDF Link:** [https://arxiv.org/pdf/2211.10419](https://arxiv.org/pdf/2211.10419)

---

**Date:** 20 Dec 2021

**Title:** Asymmetric Shapley values: incorporating causal knowledge into  model-agnostic explainability

**Abstract Link:** [https://arxiv.org/abs/1910.06358](https://arxiv.org/abs/1910.06358)

**PDF Link:** [https://arxiv.org/pdf/1910.06358](https://arxiv.org/pdf/1910.06358)

---

**Date:** 26 Jan 2022

**Title:** Discovering Boundary Values of Feature-based Machine Learning  Classifiers through Exploratory Datamorphic Testing

**Abstract Link:** [https://arxiv.org/abs/2110.00330](https://arxiv.org/abs/2110.00330)

**PDF Link:** [https://arxiv.org/pdf/2110.00330](https://arxiv.org/pdf/2110.00330)

---

**Date:** 22 Feb 2019

**Title:** General Video Game AI: a Multi-Track Framework for Evaluating Agents,  Games and Content Generation Algorithms

**Abstract Link:** [https://arxiv.org/abs/1802.10363](https://arxiv.org/abs/1802.10363)

**PDF Link:** [https://arxiv.org/pdf/1802.10363](https://arxiv.org/pdf/1802.10363)

---

**Date:** 07 Sep 2021

**Title:** ViSTA: a Framework for Virtual Scenario-based Testing of Autonomous  Vehicles

**Abstract Link:** [https://arxiv.org/abs/2109.02529](https://arxiv.org/abs/2109.02529)

**PDF Link:** [https://arxiv.org/pdf/2109.02529](https://arxiv.org/pdf/2109.02529)

---

**Date:** 08 Oct 2019

**Title:** Designing Trustworthy AI: A Human-Machine Teaming Framework to Guide  Development

**Abstract Link:** [https://arxiv.org/abs/1910.03515](https://arxiv.org/abs/1910.03515)

**PDF Link:** [https://arxiv.org/pdf/1910.03515](https://arxiv.org/pdf/1910.03515)

---

**Date:** 26 Oct 2021

**Title:** Automated Support for Unit Test Generation: A Tutorial Book Chapter

**Abstract Link:** [https://arxiv.org/abs/2110.13575](https://arxiv.org/abs/2110.13575)

**PDF Link:** [https://arxiv.org/pdf/2110.13575](https://arxiv.org/pdf/2110.13575)

---

**Date:** 21 Dec 2022

**Title:** FAIR principles for AI models with a practical application for  accelerated high energy diffraction microscopy

**Abstract Link:** [https://arxiv.org/abs/2207.00611](https://arxiv.org/abs/2207.00611)

**PDF Link:** [https://arxiv.org/pdf/2207.00611](https://arxiv.org/pdf/2207.00611)

---

**Date:** 26 Sep 2022

**Title:** Integrated multimodal artificial intelligence framework for healthcare  applications

**Abstract Link:** [https://arxiv.org/abs/2202.12998](https://arxiv.org/abs/2202.12998)

**PDF Link:** [https://arxiv.org/pdf/2202.12998](https://arxiv.org/pdf/2202.12998)

---

**Date:** 14 Jan 2022

**Title:** Tools and Practices for Responsible AI Engineering

**Abstract Link:** [https://arxiv.org/abs/2201.05647](https://arxiv.org/abs/2201.05647)

**PDF Link:** [https://arxiv.org/pdf/2201.05647](https://arxiv.org/pdf/2201.05647)

---

**Date:** 24 May 2023

**Title:** Measuring Bias in AI Models: An Statistical Approach Introducing N-Sigma

**Abstract Link:** [https://arxiv.org/abs/2304.13680](https://arxiv.org/abs/2304.13680)

**PDF Link:** [https://arxiv.org/pdf/2304.13680](https://arxiv.org/pdf/2304.13680)

---

**Date:** 06 Oct 2021

**Title:** Trustworthy Artificial Intelligence and Process Mining: Challenges and  Opportunities

**Abstract Link:** [https://arxiv.org/abs/2110.02707](https://arxiv.org/abs/2110.02707)

**PDF Link:** [https://arxiv.org/pdf/2110.02707](https://arxiv.org/pdf/2110.02707)

---

**Date:** 27 Feb 2020

**Title:** Clinical acceptance of software based on artificial intelligence  technologies (radiology)

**Abstract Link:** [https://arxiv.org/abs/1908.00381](https://arxiv.org/abs/1908.00381)

**PDF Link:** [https://arxiv.org/pdf/1908.00381](https://arxiv.org/pdf/1908.00381)

---

**Date:** 15 Jun 2022

**Title:** Deep Learning and Handheld Augmented Reality Based System for Optimal  Data Collection in Fault Diagnostics Domain

**Abstract Link:** [https://arxiv.org/abs/2206.07772](https://arxiv.org/abs/2206.07772)

**PDF Link:** [https://arxiv.org/pdf/2206.07772](https://arxiv.org/pdf/2206.07772)

---

**Date:** 18 May 2020

**Title:** A Continuous Information Gain Measure to Find the Most Discriminatory  Problems for AI Benchmarking

**Abstract Link:** [https://arxiv.org/abs/1809.02904](https://arxiv.org/abs/1809.02904)

**PDF Link:** [https://arxiv.org/pdf/1809.02904](https://arxiv.org/pdf/1809.02904)

---

**Date:** 06 Jun 2020

**Title:** Efficient Black-box Assessment of Autonomous Vehicle Safety

**Abstract Link:** [https://arxiv.org/abs/1912.03618](https://arxiv.org/abs/1912.03618)

**PDF Link:** [https://arxiv.org/pdf/1912.03618](https://arxiv.org/pdf/1912.03618)

---

**Date:** 14 Oct 2023

**Title:** Unjustified Sample Sizes and Generalizations in Explainable AI Research:  Principles for More Inclusive User Studies

**Abstract Link:** [https://arxiv.org/abs/2305.09477](https://arxiv.org/abs/2305.09477)

**PDF Link:** [https://arxiv.org/pdf/2305.09477](https://arxiv.org/pdf/2305.09477)

---

