Mixture of Experts MoE Architecture 🎪

### 🔎 Mixture of Experts MoE Architecture 🎪



Mixture of Experts (MoE) is a type of neural network architecture that combines multiple “expert” models to make predictions. The idea is to have each expert model specialize in a different part of the input space, and then use a gating network to decide which expert to use for a given input. This allows the model to scale better with the number of parameters, as each expert can be trained independently and then combined at inference time.

MoE models have been shown to be effective in a variety of tasks, including language translation, speech recognition, and image recognition. They have also been used to build large-scale models with billions of parameters, such as the T5 transformer model from Google.

One of the key benefits of MoE models is that they allow for more efficient use of computational resources. By having each expert model specialize in a different part of the input space, the model can avoid computing unnecessary features for a given input. This can lead to significant speedups and reductions in memory usage, especially for large models.

Another benefit of MoE models is that they can be more robust to out-of-distribution inputs. By having multiple expert models, the model is less likely to make confident but incorrect predictions when it encounters inputs that are significantly different from the training data.

However, MoE models can be more difficult to train than traditional neural networks. The gating network needs to be carefully designed to ensure that each expert model is used appropriately, and the model can be sensitive to the choice of hyperparameters such as the number of experts and the capacity of each expert.

Overall, MoE models are a powerful tool for building large-scale neural networks that can scale efficiently and make accurate predictions. They are an active area of research, and new variants and applications are being developed regularly.</s>
# 🩺🔍 Search Results
### 11 Sep 2023 | [Pushing Mixture of Experts to the Limit: Extremely Parameter Efficient  MoE for Instruction Tuning](https://arxiv.org/abs/2309.05444) | [⬇️](https://arxiv.org/pdf/2309.05444)
*Ted Zadouri, Ahmet \"Ust\"un, Arash Ahmadian, Beyza Ermi\c{s}, Acyr  Locatelli, Sara Hooker* 

  The Mixture of Experts (MoE) is a widely known neural architecture where an
ensemble of specialized sub-models optimizes overall performance with a
constant computational cost. However, conventional MoEs pose challenges at
scale due to the need to store all experts in memory. In this paper, we push
MoE to the limit. We propose extremely parameter-efficient MoE by uniquely
combining MoE architecture with lightweight experts.Our MoE architecture
outperforms standard parameter-efficient fine-tuning (PEFT) methods and is on
par with full fine-tuning by only updating the lightweight experts -- less than
1% of an 11B parameters model. Furthermore, our method generalizes to unseen
tasks as it does not depend on any prior task knowledge. Our research
underscores the versatility of the mixture of experts architecture, showcasing
its ability to deliver robust performance even when subjected to rigorous
parameter constraints. Our code used in all the experiments is publicly
available here: https://github.com/for-ai/parameter-efficient-moe.

---------------

### 28 Feb 2023 | [Improving Expert Specialization in Mixture of Experts](https://arxiv.org/abs/2302.14703) | [⬇️](https://arxiv.org/pdf/2302.14703)
*Yamuna Krishnamurthy and Chris Watkins and Thomas Gaertner* 

  Mixture of experts (MoE), introduced over 20 years ago, is the simplest gated
modular neural network architecture. There is renewed interest in MoE because
the conditional computation allows only parts of the network to be used during
each inference, as was recently demonstrated in large scale natural language
processing models. MoE is also of potential interest for continual learning, as
experts may be reused for new tasks, and new experts introduced. The gate in
the MoE architecture learns task decompositions and individual experts learn
simpler functions appropriate to the gate's decomposition. In this paper: (1)
we show that the original MoE architecture and its training method do not
guarantee intuitive task decompositions and good expert utilization, indeed
they can fail spectacularly even for simple data such as MNIST and
FashionMNIST; (2) we introduce a novel gating architecture, similar to
attention, that improves performance and results in a lower entropy task
decomposition; and (3) we introduce a novel data-driven regularization that
improves expert specialization. We empirically validate our methods on MNIST,
FashionMNIST and CIFAR-100 datasets.

---------------

### 01 Feb 2024 | [Efficient Fine-tuning of Audio Spectrogram Transformers via Soft Mixture  of Adapters](https://arxiv.org/abs/2402.00828) | [⬇️](https://arxiv.org/pdf/2402.00828)
*Umberto Cappellazzo, Daniele Falavigna, Alessio Brutti* 

  Mixture of Experts (MoE) architectures have recently started burgeoning due
to their ability to scale model's capacity while maintaining the computational
cost affordable. Furthermore, they can be applied to both Transformers and
State Space Models, the current state-of-the-art models in numerous fields.
While MoE has been mostly investigated for the pre-training stage, its use in
parameter-efficient transfer learning settings is under-explored. To narrow
this gap, this paper attempts to demystify the use of MoE for
parameter-efficient fine-tuning of Audio Spectrogram Transformers to audio and
speech downstream tasks. Specifically, we propose Soft Mixture of Adapters
(Soft-MoA). It exploits adapters as the experts and, leveraging the recent Soft
MoE method, it relies on a soft assignment between the input tokens and experts
to keep the computational time limited. Extensive experiments across 4
benchmarks demonstrate that Soft-MoA outperforms the single adapter method and
performs on par with the dense MoA counterpart. We finally present ablation
studies on key elements of Soft-MoA, showing for example that Soft-MoA achieves
better scaling with more experts, as well as ensuring that all experts
contribute to the computation of the output tokens, thus dispensing with the
expert imbalance issue.

---------------

### 11 Jan 2024 | [DeepSeekMoE: Towards Ultimate Expert Specialization in  Mixture-of-Experts Language Models](https://arxiv.org/abs/2401.06066) | [⬇️](https://arxiv.org/pdf/2401.06066)
*Damai Dai, Chengqi Deng, Chenggang Zhao, R.X. Xu, Huazuo Gao, Deli  Chen, Jiashi Li, Wangding Zeng, Xingkai Yu, Y. Wu, Zhenda Xie, Y.K. Li,  Panpan Huang, Fuli Luo, Chong Ruan, Zhifang Sui, Wenfeng Liang* 

  In the era of large language models, Mixture-of-Experts (MoE) is a promising
architecture for managing computational costs when scaling up model parameters.
However, conventional MoE architectures like GShard, which activate the top-$K$
out of $N$ experts, face challenges in ensuring expert specialization, i.e.
each expert acquires non-overlapping and focused knowledge. In response, we
propose the DeepSeekMoE architecture towards ultimate expert specialization. It
involves two principal strategies: (1) finely segmenting the experts into $mN$
ones and activating $mK$ from them, allowing for a more flexible combination of
activated experts; (2) isolating $K_s$ experts as shared ones, aiming at
capturing common knowledge and mitigating redundancy in routed experts.
Starting from a modest scale with 2B parameters, we demonstrate that
DeepSeekMoE 2B achieves comparable performance with GShard 2.9B, which has 1.5
times the expert parameters and computation. In addition, DeepSeekMoE 2B nearly
approaches the performance of its dense counterpart with the same number of
total parameters, which set the upper bound of MoE models. Subsequently, we
scale up DeepSeekMoE to 16B parameters and show that it achieves comparable
performance with LLaMA2 7B, with only about 40% of computations. Further, our
preliminary efforts to scale up DeepSeekMoE to 145B parameters consistently
validate its substantial advantages over the GShard architecture, and show its
performance comparable with DeepSeek 67B, using only 28.5% (maybe even 18.2%)
of computations.

---------------

### 24 Oct 2023 | [Task-Based MoE for Multitask Multilingual Machine Translation](https://arxiv.org/abs/2308.15772) | [⬇️](https://arxiv.org/pdf/2308.15772)
*Hai Pham, Young Jin Kim, Subhabrata Mukherjee, David P. Woodruff,  Barnabas Poczos, Hany Hassan Awadalla* 

  Mixture-of-experts (MoE) architecture has been proven a powerful method for
diverse tasks in training deep models in many applications. However, current
MoE implementations are task agnostic, treating all tokens from different tasks
in the same manner. In this work, we instead design a novel method that
incorporates task information into MoE models at different granular levels with
shared dynamic task-based adapters. Our experiments and analysis show the
advantages of our approaches over the dense and canonical MoE models on
multi-task multilingual machine translations. With task-specific adapters, our
models can additionally generalize to new tasks efficiently.

---------------

### 10 Oct 2022 | [Parameter-Efficient Mixture-of-Experts Architecture for Pre-trained  Language Models](https://arxiv.org/abs/2203.01104) | [⬇️](https://arxiv.org/pdf/2203.01104)
*Ze-Feng Gao, Peiyu Liu, Wayne Xin Zhao, Zhong-Yi Lu, Ji-Rong Wen* 

  Recently, Mixture-of-Experts (short as MoE) architecture has achieved
remarkable success in increasing the model capacity of large-scale language
models. However, MoE requires incorporating significantly more parameters than
the base model being extended. In this paper, we propose building a
parameter-efficient MoE architecture by sharing information among experts. We
adopt the matrix product operator (MPO, a tensor decomposition from quantum
many-body physics) to reconstruct the parameter matrix in the expert layer and
increase model capacity for pre-trained language models by sharing parameters
of the central tensor (containing the core information) among different experts
while enabling the specificity through the auxiliary tensors (complementing the
central tensor) of different experts. To address the unbalanced optimization
issue, we further design the gradient mask strategy for the MPO-based MoE
architecture. Extensive experiments based on T5 and GPT-2 show improved
performance and efficiency of the pre-trained language model (27.2x reduction
in total parameters for the superior model performance, compared with the
Switch Transformers). Our code is publicly available at
https://github.com/RUCAIBox/MPOE.

---------------

### 31 Dec 2021 | [DSelect-k: Differentiable Selection in the Mixture of Experts with  Applications to Multi-Task Learning](https://arxiv.org/abs/2106.03760) | [⬇️](https://arxiv.org/pdf/2106.03760)
*Hussein Hazimeh, Zhe Zhao, Aakanksha Chowdhery, Maheswaran  Sathiamoorthy, Yihua Chen, Rahul Mazumder, Lichan Hong, Ed H. Chi* 

  The Mixture-of-Experts (MoE) architecture is showing promising results in
improving parameter sharing in multi-task learning (MTL) and in scaling
high-capacity neural networks. State-of-the-art MoE models use a trainable
sparse gate to select a subset of the experts for each input example. While
conceptually appealing, existing sparse gates, such as Top-k, are not smooth.
The lack of smoothness can lead to convergence and statistical performance
issues when training with gradient-based methods. In this paper, we develop
DSelect-k: a continuously differentiable and sparse gate for MoE, based on a
novel binary encoding formulation. The gate can be trained using first-order
methods, such as stochastic gradient descent, and offers explicit control over
the number of experts to select. We demonstrate the effectiveness of DSelect-k
on both synthetic and real MTL datasets with up to $128$ tasks. Our experiments
indicate that DSelect-k can achieve statistically significant improvements in
prediction and expert selection over popular MoE gates. Notably, on a
real-world, large-scale recommender system, DSelect-k achieves over $22\%$
improvement in predictive performance compared to Top-k. We provide an
open-source implementation of DSelect-k.

---------------

### 22 Sep 2021 | [Scalable and Efficient MoE Training for Multitask Multilingual Models](https://arxiv.org/abs/2109.10465) | [⬇️](https://arxiv.org/pdf/2109.10465)
*Young Jin Kim, Ammar Ahmad Awan, Alexandre Muzio, Andres Felipe Cruz  Salinas, Liyang Lu, Amr Hendy, Samyam Rajbhandari, Yuxiong He and Hany Hassan  Awadalla* 

  The Mixture of Experts (MoE) models are an emerging class of sparsely
activated deep learning models that have sublinear compute costs with respect
to their parameters. In contrast with dense models, the sparse architecture of
MoE offers opportunities for drastically growing model size with significant
accuracy gain while consuming much lower compute budget. However, supporting
large scale MoE training also has its own set of system and modeling
challenges. To overcome the challenges and embrace the opportunities of MoE, we
first develop a system capable of scaling MoE models efficiently to trillions
of parameters. It combines multi-dimensional parallelism and heterogeneous
memory technologies harmoniously with MoE to empower 8x larger models on the
same hardware compared with existing work. Besides boosting system efficiency,
we also present new training methods to improve MoE sample efficiency and
leverage expert pruning strategy to improve inference time efficiency. By
combining the efficient system and training methods, we are able to
significantly scale up large multitask multilingual models for language
generation which results in a great improvement in model accuracy. A model
trained with 10 billion parameters on 50 languages can achieve state-of-the-art
performance in Machine Translation (MT) and multilingual natural language
generation tasks. The system support of efficient MoE training has been
implemented and open-sourced with the DeepSpeed library.

---------------

### 14 May 2023 | [A Hybrid Tensor-Expert-Data Parallelism Approach to Optimize  Mixture-of-Experts Training](https://arxiv.org/abs/2303.06318) | [⬇️](https://arxiv.org/pdf/2303.06318)
*Siddharth Singh, Olatunji Ruwase, Ammar Ahmad Awan, Samyam  Rajbhandari, Yuxiong He, Abhinav Bhatele* 

  Mixture-of-Experts (MoE) is a neural network architecture that adds sparsely
activated expert blocks to a base model, increasing the number of parameters
without impacting computational costs. However, current distributed deep
learning frameworks are limited in their ability to train high-quality MoE
models with large base models. In this work, we present DeepSpeed-TED, a novel,
three-dimensional, hybrid parallel algorithm that combines data, tensor, and
expert parallelism to enable the training of MoE models with 4 to 8x larger
base models than the current state-of-the-art. We also describe memory
optimizations in the optimizer step, and communication optimizations that
eliminate unnecessary data movement. We implement our approach in DeepSpeed and
achieve speedups of 26% over a baseline (i.e. without our communication
optimizations) when training a 40 billion parameter MoE model (6.7 billion base
model with 16 experts) on 128 V100 GPUs.

---------------

### 27 Dec 2023 | [Efficient Deweather Mixture-of-Experts with Uncertainty-aware  Feature-wise Linear Modulation](https://arxiv.org/abs/2312.16610) | [⬇️](https://arxiv.org/pdf/2312.16610)
*Rongyu Zhang, Yulin Luo, Jiaming Liu, Huanrui Yang, Zhen Dong, Denis  Gudovskiy, Tomoyuki Okuno, Yohei Nakata, Kurt Keutzer, Yuan Du, Shanghang  Zhang* 

  The Mixture-of-Experts (MoE) approach has demonstrated outstanding
scalability in multi-task learning including low-level upstream tasks such as
concurrent removal of multiple adverse weather effects. However, the
conventional MoE architecture with parallel Feed Forward Network (FFN) experts
leads to significant parameter and computational overheads that hinder its
efficient deployment. In addition, the naive MoE linear router is suboptimal in
assigning task-specific features to multiple experts which limits its further
scalability. In this work, we propose an efficient MoE architecture with weight
sharing across the experts. Inspired by the idea of linear feature modulation
(FM), our architecture implicitly instantiates multiple experts via learnable
activation modulations on a single shared expert block. The proposed Feature
Modulated Expert (FME) serves as a building block for the novel
Mixture-of-Feature-Modulation-Experts (MoFME) architecture, which can scale up
the number of experts with low overhead. We further propose an
Uncertainty-aware Router (UaR) to assign task-specific features to different FM
modules with well-calibrated weights. This enables MoFME to effectively learn
diverse expert functions for multiple tasks. The conducted experiments on the
multi-deweather task show that our MoFME outperforms the baselines in the image
restoration quality by 0.1-0.2 dB and achieves SOTA-compatible performance
while saving more than 72% of parameters and 39% inference time over the
conventional MoE counterpart. Experiments on the downstream segmentation and
classification tasks further demonstrate the generalizability of MoFME to real
open-world applications.

---------------

### 25 Oct 2022 | [One Student Knows All Experts Know: From Sparse to Dense](https://arxiv.org/abs/2201.10890) | [⬇️](https://arxiv.org/pdf/2201.10890)
*Fuzhao Xue, Xiaoxin He, Xiaozhe Ren, Yuxuan Lou, Yang You* 

  Human education system trains one student by multiple experts.
Mixture-of-experts (MoE) is a powerful sparse architecture including multiple
experts. However, sparse MoE model is easy to overfit, hard to deploy, and not
hardware-friendly for practitioners. In this work, inspired by the human
education model, we propose a novel task, knowledge integration, to obtain a
dense student model (OneS) as knowledgeable as one sparse MoE. We investigate
this task by proposing a general training framework including knowledge
gathering and knowledge distillation. Specifically, to gather key knowledge
from different pre-trained experts, we first investigate four different
possible knowledge gathering methods, \ie summation, averaging, Top-K Knowledge
Gathering (Top-KG), and Singular Value Decomposition Knowledge Gathering
(SVD-KG) proposed in this paper. We then refine the dense student model by
knowledge distillation to offset the noise from gathering. On ImageNet, our
OneS preserves $61.7\%$ benefits from MoE and achieves $78.4\%$ top-1 accuracy
ImageNet with only $15$M parameters. On four natural language processing
datasets, OneS obtains $88.2\%$ MoE benefits and outperforms the best baseline
by $51.7\%$ using the same architecture and training data. In addition,
compared with the MoE counterpart, OneS can achieve $3.7 \times$ inference
speedup due to less computation and hardware-friendly architecture.

---------------

### 05 Jul 2023 | [Mixture-of-Experts Meets Instruction Tuning:A Winning Combination for  Large Language Models](https://arxiv.org/abs/2305.14705) | [⬇️](https://arxiv.org/pdf/2305.14705)
*Sheng Shen, Le Hou, Yanqi Zhou, Nan Du, Shayne Longpre, Jason Wei,  Hyung Won Chung, Barret Zoph, William Fedus, Xinyun Chen, Tu Vu, Yuexin Wu,  Wuyang Chen, Albert Webson, Yunxuan Li, Vincent Zhao, Hongkun Yu, Kurt  Keutzer, Trevor Darrell, Denny Zhou* 

  Sparse Mixture-of-Experts (MoE) is a neural architecture design that can be
utilized to add learnable parameters to Large Language Models (LLMs) without
increasing inference cost. Instruction tuning is a technique for training LLMs
to follow instructions. We advocate combining these two approaches, as we find
that MoE models benefit more from instruction tuning than dense models. In
particular, we conduct empirical studies across three experimental setups: (i)
Direct finetuning on individual downstream tasks devoid of instruction tuning;
(ii) Instructiontuning followed by in-context few-shot or zero-shot
generalization on downstream tasks; and (iii) Instruction tuning supplemented
by further finetuning on individual downstream tasks. In the first scenario,
MoE models overall underperform dense models of identical computational
capacity. This narrative, however, dramatically changes with the introduction
of instruction tuning (second and third scenario), used independently or in
conjunction with task-specific finetuning. Our most powerful model,
FLAN-MOE-32B, surpasses the performance of FLAN-PALM-62B on four benchmark
tasks, while using only a third of the FLOPs. The advancements embodied
byFLAN-MOE inspire a reevaluation of the design principles of large-scale,
high-performance language models in the framework of task-agnostic learning.

---------------

### 22 Apr 2023 | [Pipeline MoE: A Flexible MoE Implementation with Pipeline Parallelism](https://arxiv.org/abs/2304.11414) | [⬇️](https://arxiv.org/pdf/2304.11414)
*Xin Chen, Hengheng Zhang, Xiaotao Gu, Kaifeng Bi, Lingxi Xie, Qi Tian* 

  The Mixture of Experts (MoE) model becomes an important choice of large
language models nowadays because of its scalability with sublinear
computational complexity for training and inference. However, existing MoE
models suffer from two critical drawbacks, 1) tremendous inner-node and
inter-node communication overhead introduced by all-to-all dispatching and
gathering, and 2) limited scalability for the backbone because of the bound
data parallel and expert parallel to scale in the expert dimension. In this
paper, we systematically analyze these drawbacks in terms of training
efficiency in the parallel framework view and propose a novel MoE architecture
called Pipeline MoE (PPMoE) to tackle them. PPMoE builds expert parallel
incorporating with tensor parallel and replaces communication-intensive
all-to-all dispatching and gathering with a simple tensor index slicing and
inner-node all-reduce. Besides, it is convenient for PPMoE to integrate
pipeline parallel to further scale the backbone due to its flexible parallel
architecture. Extensive experiments show that PPMoE not only achieves a more
than $1.75\times$ speed up compared to existing MoE architectures but also
reaches $90\%$ throughput of its corresponding backbone model that is
$20\times$ smaller.

---------------

### 04 Aug 2022 | [Towards Understanding Mixture of Experts in Deep Learning](https://arxiv.org/abs/2208.02813) | [⬇️](https://arxiv.org/pdf/2208.02813)
*Zixiang Chen and Yihe Deng and Yue Wu and Quanquan Gu and Yuanzhi Li* 

  The Mixture-of-Experts (MoE) layer, a sparsely-activated model controlled by
a router, has achieved great success in deep learning. However, the
understanding of such architecture remains elusive. In this paper, we formally
study how the MoE layer improves the performance of neural network learning and
why the mixture model will not collapse into a single model. Our empirical
results suggest that the cluster structure of the underlying problem and the
non-linearity of the expert are pivotal to the success of MoE. To further
understand this, we consider a challenging classification problem with
intrinsic cluster structures, which is hard to learn using a single expert. Yet
with the MoE layer, by choosing the experts as two-layer nonlinear
convolutional neural networks (CNNs), we show that the problem can be learned
successfully. Furthermore, our theory shows that the router can learn the
cluster-center features, which helps divide the input complex problem into
simpler linear classification sub-problems that individual experts can conquer.
To our knowledge, this is the first result towards formally understanding the
mechanism of the MoE layer for deep learning.

---------------

### 25 Oct 2023 | [QMoE: Practical Sub-1-Bit Compression of Trillion-Parameter Models](https://arxiv.org/abs/2310.16795) | [⬇️](https://arxiv.org/pdf/2310.16795)
*Elias Frantar and Dan Alistarh* 

  Mixture-of-Experts (MoE) architectures offer a general solution to the high
inference costs of large language models (LLMs) via sparse routing, bringing
faster and more accurate models, at the cost of massive parameter counts. For
example, the SwitchTransformer-c2048 model has 1.6 trillion parameters,
requiring 3.2TB of accelerator memory to run efficiently, which makes practical
deployment challenging and expensive. In this paper, we present a solution to
this memory problem, in form of a new compression and execution framework
called QMoE. Specifically, QMoE consists of a scalable algorithm which
accurately compresses trillion-parameter MoEs to less than 1 bit per parameter,
in a custom format co-designed with bespoke GPU decoding kernels to facilitate
efficient end-to-end compressed inference, with minor runtime overheads
relative to uncompressed execution. Concretely, QMoE can compress the 1.6
trillion parameter SwitchTransformer-c2048 model to less than 160GB (20x
compression, 0.8 bits per parameter) at only minor accuracy loss, in less than
a day on a single GPU. This enables, for the first time, the execution of a
trillion-parameter model on affordable commodity hardware, like a single server
with 4x NVIDIA A6000 or 8x NVIDIA 3090 GPUs, at less than 5% runtime overhead
relative to ideal uncompressed inference. The source code and compressed models
are available at github.com/IST-DASLab/qmoe.

---------------

### 02 Aug 2023 | [From Sparse to Soft Mixtures of Experts](https://arxiv.org/abs/2308.00951) | [⬇️](https://arxiv.org/pdf/2308.00951)
*Joan Puigcerver, Carlos Riquelme, Basil Mustafa, Neil Houlsby* 

  Sparse mixture of expert architectures (MoEs) scale model capacity without
large increases in training or inference costs. Despite their success, MoEs
suffer from a number of issues: training instability, token dropping, inability
to scale the number of experts, or ineffective finetuning. In this work, we
proposeSoft MoE, a fully-differentiable sparse Transformer that addresses these
challenges, while maintaining the benefits of MoEs. Soft MoE performs an
implicit soft assignment by passing different weighted combinations of all
input tokens to each expert. As in other MoE works, experts in Soft MoE only
process a subset of the (combined) tokens, enabling larger model capacity at
lower inference cost. In the context of visual recognition, Soft MoE greatly
outperforms standard Transformers (ViTs) and popular MoE variants (Tokens
Choice and Experts Choice). For example, Soft MoE-Base/16 requires 10.5x lower
inference cost (5.7x lower wall-clock time) than ViT-Huge/14 while matching its
performance after similar training. Soft MoE also scales well: Soft MoE Huge/14
with 128 experts in 16 MoE layers has over 40x more parameters than ViT
Huge/14, while inference time cost grows by only 2%, and it performs
substantially better.

---------------

### 14 Jan 2022 | [Cross-token Modeling with Conditional Computation](https://arxiv.org/abs/2109.02008) | [⬇️](https://arxiv.org/pdf/2109.02008)
*Yuxuan Lou, Fuzhao Xue, Zangwei Zheng, Yang You* 

  Mixture-of-Experts (MoE), a conditional computation architecture, achieved
promising performance by scaling local module (i.e. feed-forward network) of
transformer. However, scaling the cross-token module (i.e. self-attention) is
challenging due to the unstable training. This work proposes Sparse-MLP, an
all-MLP model which applies sparsely-activated MLPs to cross-token modeling.
Specifically, in each Sparse block of our all-MLP model, we apply two stages of
MoE layers: one with MLP experts mixing information within channels along image
patch dimension, the other with MLP experts mixing information within patches
along the channel dimension. In addition, by proposing importance-score routing
strategy for MoE and redesigning the image representation shape, we further
improve our model's computational efficiency. Experimentally, we are more
computation-efficient than Vision Transformers with comparable accuracy. Also,
our models can outperform MLP-Mixer by 2.5\% on ImageNet Top-1 accuracy with
fewer parameters and computational cost. On downstream tasks, i.e. Cifar10 and
Cifar100, our models can still achieve better performance than baselines.

---------------

### 29 Oct 2023 | [SiDA: Sparsity-Inspired Data-Aware Serving for Efficient and Scalable  Large Mixture-of-Experts Models](https://arxiv.org/abs/2310.18859) | [⬇️](https://arxiv.org/pdf/2310.18859)
*Zhixu Du, Shiyu Li, Yuhao Wu, Xiangyu Jiang, Jingwei Sun, Qilin Zheng,  Yongkai Wu, Ang Li, Hai "Helen" Li, Yiran Chen* 

  Mixture-of-Experts (MoE) has emerged as a favorable architecture in the era
of large models due to its inherent advantage, i.e., enlarging model capacity
without incurring notable computational overhead. Yet, the realization of such
benefits often results in ineffective GPU memory utilization, as large portions
of the model parameters remain dormant during inference. Moreover, the memory
demands of large models consistently outpace the memory capacity of
contemporary GPUs. Addressing this, we introduce SiDA (Sparsity-inspired
Data-Aware), an efficient inference approach tailored for large MoE models.
SiDA judiciously exploits both the system's main memory, which is now abundant
and readily scalable, and GPU memory by capitalizing on the inherent sparsity
on expert activation in MoE models. By adopting a data-aware perspective, SiDA
achieves enhanced model efficiency with a neglectable performance drop.
Specifically, SiDA attains a remarkable speedup in MoE inference with up to
3.93X throughput increasing, up to 75% latency reduction, and up to 80% GPU
memory saving with down to 1% performance drop. This work paves the way for
scalable and efficient deployment of large MoE models, even in
memory-constrained systems.

---------------

### 21 Jul 2022 | [DeepSpeed-MoE: Advancing Mixture-of-Experts Inference and Training to  Power Next-Generation AI Scale](https://arxiv.org/abs/2201.05596) | [⬇️](https://arxiv.org/pdf/2201.05596)
*Samyam Rajbhandari, Conglong Li, Zhewei Yao, Minjia Zhang, Reza  Yazdani Aminabadi, Ammar Ahmad Awan, Jeff Rasley, Yuxiong He* 

  As the training of giant dense models hits the boundary on the availability
and capability of the hardware resources today, Mixture-of-Experts (MoE) models
become one of the most promising model architectures due to their significant
training cost reduction compared to a quality-equivalent dense model. Its
training cost saving is demonstrated from encoder-decoder models (prior works)
to a 5x saving for auto-aggressive language models (this work along with
parallel explorations). However, due to the much larger model size and unique
architecture, how to provide fast MoE model inference remains challenging and
unsolved, limiting its practical usage. To tackle this, we present
DeepSpeed-MoE, an end-to-end MoE training and inference solution as part of the
DeepSpeed library, including novel MoE architecture designs and model
compression techniques that reduce MoE model size by up to 3.7x, and a highly
optimized inference system that provides 7.3x better latency and cost compared
to existing MoE inference solutions. DeepSpeed-MoE offers an unprecedented
scale and efficiency to serve massive MoE models with up to 4.5x faster and 9x
cheaper inference compared to quality-equivalent dense models. We hope our
innovations and systems help open a promising path to new directions in the
large model landscape, a shift from dense to sparse MoE models, where training
and deploying higher-quality models with fewer resources becomes more widely
possible.

---------------

### 11 Oct 2022 | [Mixture of Attention Heads: Selecting Attention Heads Per Token](https://arxiv.org/abs/2210.05144) | [⬇️](https://arxiv.org/pdf/2210.05144)
*Xiaofeng Zhang, Yikang Shen, Zeyu Huang, Jie Zhou, Wenge Rong, Zhang  Xiong* 

  Mixture-of-Experts (MoE) networks have been proposed as an efficient way to
scale up model capacity and implement conditional computing. However, the study
of MoE components mostly focused on the feedforward layer in Transformer
architecture. This paper proposes the Mixture of Attention Heads (MoA), a new
architecture that combines multi-head attention with the MoE mechanism. MoA
includes a set of attention heads that each has its own set of parameters.
Given an input, a router dynamically selects a subset of $k$ attention heads
per token. This conditional computation schema allows MoA to achieve stronger
performance than the standard multi-head attention layer. Furthermore, the
sparsely gated MoA can easily scale up the number of attention heads and the
number of parameters while preserving computational efficiency. In addition to
the performance improvements, MoA also automatically differentiates heads'
utilities, providing a new perspective to discuss the model's interpretability.
We conducted experiments on several important tasks, including Machine
Translation and Masked Language Modeling. Experiments have shown promising
results on several tasks against strong baselines that involve large and very
deep models.

---------------
**Date:** 11 Sep 2023

**Title:** Pushing Mixture of Experts to the Limit: Extremely Parameter Efficient  MoE for Instruction Tuning

**Abstract Link:** [https://arxiv.org/abs/2309.05444](https://arxiv.org/abs/2309.05444)

**PDF Link:** [https://arxiv.org/pdf/2309.05444](https://arxiv.org/pdf/2309.05444)

---

**Date:** 28 Feb 2023

**Title:** Improving Expert Specialization in Mixture of Experts

**Abstract Link:** [https://arxiv.org/abs/2302.14703](https://arxiv.org/abs/2302.14703)

**PDF Link:** [https://arxiv.org/pdf/2302.14703](https://arxiv.org/pdf/2302.14703)

---

**Date:** 01 Feb 2024

**Title:** Efficient Fine-tuning of Audio Spectrogram Transformers via Soft Mixture  of Adapters

**Abstract Link:** [https://arxiv.org/abs/2402.00828](https://arxiv.org/abs/2402.00828)

**PDF Link:** [https://arxiv.org/pdf/2402.00828](https://arxiv.org/pdf/2402.00828)

---

**Date:** 11 Jan 2024

**Title:** DeepSeekMoE: Towards Ultimate Expert Specialization in  Mixture-of-Experts Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.06066](https://arxiv.org/abs/2401.06066)

**PDF Link:** [https://arxiv.org/pdf/2401.06066](https://arxiv.org/pdf/2401.06066)

---

**Date:** 24 Oct 2023

**Title:** Task-Based MoE for Multitask Multilingual Machine Translation

**Abstract Link:** [https://arxiv.org/abs/2308.15772](https://arxiv.org/abs/2308.15772)

**PDF Link:** [https://arxiv.org/pdf/2308.15772](https://arxiv.org/pdf/2308.15772)

---

**Date:** 10 Oct 2022

**Title:** Parameter-Efficient Mixture-of-Experts Architecture for Pre-trained  Language Models

**Abstract Link:** [https://arxiv.org/abs/2203.01104](https://arxiv.org/abs/2203.01104)

**PDF Link:** [https://arxiv.org/pdf/2203.01104](https://arxiv.org/pdf/2203.01104)

---

**Date:** 31 Dec 2021

**Title:** DSelect-k: Differentiable Selection in the Mixture of Experts with  Applications to Multi-Task Learning

**Abstract Link:** [https://arxiv.org/abs/2106.03760](https://arxiv.org/abs/2106.03760)

**PDF Link:** [https://arxiv.org/pdf/2106.03760](https://arxiv.org/pdf/2106.03760)

---

**Date:** 22 Sep 2021

**Title:** Scalable and Efficient MoE Training for Multitask Multilingual Models

**Abstract Link:** [https://arxiv.org/abs/2109.10465](https://arxiv.org/abs/2109.10465)

**PDF Link:** [https://arxiv.org/pdf/2109.10465](https://arxiv.org/pdf/2109.10465)

---

**Date:** 14 May 2023

**Title:** A Hybrid Tensor-Expert-Data Parallelism Approach to Optimize  Mixture-of-Experts Training

**Abstract Link:** [https://arxiv.org/abs/2303.06318](https://arxiv.org/abs/2303.06318)

**PDF Link:** [https://arxiv.org/pdf/2303.06318](https://arxiv.org/pdf/2303.06318)

---

**Date:** 27 Dec 2023

**Title:** Efficient Deweather Mixture-of-Experts with Uncertainty-aware  Feature-wise Linear Modulation

**Abstract Link:** [https://arxiv.org/abs/2312.16610](https://arxiv.org/abs/2312.16610)

**PDF Link:** [https://arxiv.org/pdf/2312.16610](https://arxiv.org/pdf/2312.16610)

---

**Date:** 25 Oct 2022

**Title:** One Student Knows All Experts Know: From Sparse to Dense

**Abstract Link:** [https://arxiv.org/abs/2201.10890](https://arxiv.org/abs/2201.10890)

**PDF Link:** [https://arxiv.org/pdf/2201.10890](https://arxiv.org/pdf/2201.10890)

---

**Date:** 05 Jul 2023

**Title:** Mixture-of-Experts Meets Instruction Tuning:A Winning Combination for  Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2305.14705](https://arxiv.org/abs/2305.14705)

**PDF Link:** [https://arxiv.org/pdf/2305.14705](https://arxiv.org/pdf/2305.14705)

---

**Date:** 22 Apr 2023

**Title:** Pipeline MoE: A Flexible MoE Implementation with Pipeline Parallelism

**Abstract Link:** [https://arxiv.org/abs/2304.11414](https://arxiv.org/abs/2304.11414)

**PDF Link:** [https://arxiv.org/pdf/2304.11414](https://arxiv.org/pdf/2304.11414)

---

**Date:** 04 Aug 2022

**Title:** Towards Understanding Mixture of Experts in Deep Learning

**Abstract Link:** [https://arxiv.org/abs/2208.02813](https://arxiv.org/abs/2208.02813)

**PDF Link:** [https://arxiv.org/pdf/2208.02813](https://arxiv.org/pdf/2208.02813)

---

**Date:** 25 Oct 2023

**Title:** QMoE: Practical Sub-1-Bit Compression of Trillion-Parameter Models

**Abstract Link:** [https://arxiv.org/abs/2310.16795](https://arxiv.org/abs/2310.16795)

**PDF Link:** [https://arxiv.org/pdf/2310.16795](https://arxiv.org/pdf/2310.16795)

---

**Date:** 02 Aug 2023

**Title:** From Sparse to Soft Mixtures of Experts

**Abstract Link:** [https://arxiv.org/abs/2308.00951](https://arxiv.org/abs/2308.00951)

**PDF Link:** [https://arxiv.org/pdf/2308.00951](https://arxiv.org/pdf/2308.00951)

---

**Date:** 14 Jan 2022

**Title:** Cross-token Modeling with Conditional Computation

**Abstract Link:** [https://arxiv.org/abs/2109.02008](https://arxiv.org/abs/2109.02008)

**PDF Link:** [https://arxiv.org/pdf/2109.02008](https://arxiv.org/pdf/2109.02008)

---

**Date:** 29 Oct 2023

**Title:** SiDA: Sparsity-Inspired Data-Aware Serving for Efficient and Scalable  Large Mixture-of-Experts Models

**Abstract Link:** [https://arxiv.org/abs/2310.18859](https://arxiv.org/abs/2310.18859)

**PDF Link:** [https://arxiv.org/pdf/2310.18859](https://arxiv.org/pdf/2310.18859)

---

**Date:** 21 Jul 2022

**Title:** DeepSpeed-MoE: Advancing Mixture-of-Experts Inference and Training to  Power Next-Generation AI Scale

**Abstract Link:** [https://arxiv.org/abs/2201.05596](https://arxiv.org/abs/2201.05596)

**PDF Link:** [https://arxiv.org/pdf/2201.05596](https://arxiv.org/pdf/2201.05596)

---

**Date:** 11 Oct 2022

**Title:** Mixture of Attention Heads: Selecting Attention Heads Per Token

**Abstract Link:** [https://arxiv.org/abs/2210.05144](https://arxiv.org/abs/2210.05144)

**PDF Link:** [https://arxiv.org/pdf/2210.05144](https://arxiv.org/pdf/2210.05144)

---

