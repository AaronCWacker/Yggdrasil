AI Medical Diagnostics 💉

### 🔎 AI Medical Diagnostics 💉



# AI Medical Diagnostics 💉

AI is revolutionizing the medical field, and one of the most exciting areas is in medical diagnostics. AI algorithms can analyze medical images, such as X-rays, CT scans, and MRIs, to detect diseases and abnormalities faster and more accurately than human doctors.

One example of AI in medical diagnostics is in the detection of breast cancer. AI algorithms can analyze mammograms to identify early signs of breast cancer, potentially saving thousands of lives each year. In fact, a study published in the journal Radiology found that AI was able to detect breast cancer with 93% accuracy, compared to 91% accuracy for human radiologists.

AI is also being used in the detection of other types of cancer, such as lung and skin cancer. For example, researchers at Google developed an AI algorithm that can detect skin cancer with the same accuracy as dermatologists. The algorithm was trained on a dataset of over 100,000 images of skin lesions, and was able to accurately diagnose skin cancer in 95% of cases.

In addition to cancer detection, AI is also being used in the diagnosis of other diseases, such as diabetic retinopathy, a condition that can lead to blindness in people with diabetes. AI algorithms can analyze images of the retina to detect early signs of the disease, allowing for early intervention and treatment.

AI is also being used in the diagnosis of neurological disorders, such as Alzheimer's disease and Parkinson's disease. AI algorithms can analyze brain scans to detect early signs of these diseases, potentially leading to earlier diagnosis and treatment.

Overall, AI is revolutionizing the field of medical diagnostics, allowing for faster and more accurate diagnosis of diseases and conditions. While AI is not yet ready to replace human doctors, it is a valuable tool that can help doctors make more informed decisions and improve patient outcomes.</s>
# 🩺🔍 Search Results
### 13 Jun 2023 | [Multi-Task Training with In-Domain Language Models for Diagnostic  Reasoning](https://arxiv.org/abs/2306.04551) | [⬇️](https://arxiv.org/pdf/2306.04551)
*Brihat Sharma, Yanjun Gao, Timothy Miller, Matthew M. Churpek, Majid  Afshar and Dmitriy Dligach* 

  Generative artificial intelligence (AI) is a promising direction for
augmenting clinical diagnostic decision support and reducing diagnostic errors,
a leading contributor to medical errors. To further the development of clinical
AI systems, the Diagnostic Reasoning Benchmark (DR.BENCH) was introduced as a
comprehensive generative AI framework, comprised of six tasks representing key
components in clinical reasoning. We present a comparative analysis of
in-domain versus out-of-domain language models as well as multi-task versus
single task training with a focus on the problem summarization task in DR.BENCH
(Gao et al., 2023). We demonstrate that a multi-task, clinically trained
language model outperforms its general domain counterpart by a large margin,
establishing a new state-of-the-art performance, with a ROUGE-L score of 28.55.
This research underscores the value of domain-specific training for optimizing
clinical diagnostic reasoning tasks.

---------------

### 24 May 2022 | [Do it Like the Doctor: How We Can Design a Model That Uses Domain  Knowledge to Diagnose Pneumothorax](https://arxiv.org/abs/2205.12159) | [⬇️](https://arxiv.org/pdf/2205.12159)
*Glen Smith, Qiao Zhang, Christopher MacLellan* 

  Computer-aided diagnosis for medical imaging is a well-studied field that
aims to provide real-time decision support systems for physicians. These
systems attempt to detect and diagnose a plethora of medical conditions across
a variety of image diagnostic technologies including ultrasound, x-ray, MRI,
and CT. When designing AI models for these systems, we are often limited by
little training data, and for rare medical conditions, positive examples are
difficult to obtain. These issues often cause models to perform poorly, so we
needed a way to design an AI model in light of these limitations. Thus, our
approach was to incorporate expert domain knowledge into the design of an AI
model. We conducted two qualitative think-aloud studies with doctors trained in
the interpretation of lung ultrasound diagnosis to extract relevant domain
knowledge for the condition Pneumothorax. We extracted knowledge of key
features and procedures used to make a diagnosis. With this knowledge, we
employed knowledge engineering concepts to make recommendations for an AI model
design to automatically diagnose Pneumothorax.

---------------

### 18 Nov 2021 | [Advancing COVID-19 Diagnosis with Privacy-Preserving Collaboration in  Artificial Intelligence](https://arxiv.org/abs/2111.09461) | [⬇️](https://arxiv.org/pdf/2111.09461)
*Xiang Bai, Hanchen Wang, Liya Ma, Yongchao Xu, Jiefeng Gan, Ziwei Fan,  Fan Yang, Ke Ma, Jiehua Yang, Song Bai, Chang Shu, Xinyu Zou, Renhao Huang,  Changzheng Zhang, Xiaowu Liu, Dandan Tu, Chuou Xu, Wenqing Zhang, Xi Wang,  Anguo Chen, Yu Zeng, Dehua Yang, Ming-Wei Wang, Nagaraj Holalkere, Neil J.  Halin, Ihab R. Kamel, Jia Wu, Xuehua Peng, Xiang Wang, Jianbo Shao,  Pattanasak Mongkolwat, Jianjun Zhang, Weiyang Liu, Michael Roberts, Zhongzhao  Teng, Lucian Beer, Lorena Escudero Sanchez, Evis Sala, Daniel Rubin, Adrian  Weller, Joan Lasenby, Chuangsheng Zheng, Jianming Wang, Zhen Li,  Carola-Bibiane Sch\"onlieb, Tian Xia* 

  Artificial intelligence (AI) provides a promising substitution for
streamlining COVID-19 diagnoses. However, concerns surrounding security and
trustworthiness impede the collection of large-scale representative medical
data, posing a considerable challenge for training a well-generalised model in
clinical practices. To address this, we launch the Unified CT-COVID AI
Diagnostic Initiative (UCADI), where the AI model can be distributedly trained
and independently executed at each host institution under a federated learning
framework (FL) without data sharing. Here we show that our FL model
outperformed all the local models by a large yield (test sensitivity
/specificity in China: 0.973/0.951, in the UK: 0.730/0.942), achieving
comparable performance with a panel of professional radiologists. We further
evaluated the model on the hold-out (collected from another two hospitals
leaving out the FL) and heterogeneous (acquired with contrast materials) data,
provided visual explanations for decisions made by the model, and analysed the
trade-offs between the model performance and the communication costs in the
federated training process. Our study is based on 9,573 chest computed
tomography scans (CTs) from 3,336 patients collected from 23 hospitals located
in China and the UK. Collectively, our work advanced the prospects of utilising
federated learning for privacy-preserving AI in digital health.

---------------

### 14 Jan 2024 | [Enabling Collaborative Clinical Diagnosis of Infectious Keratitis by  Integrating Expert Knowledge and Interpretable Data-driven Intelligence](https://arxiv.org/abs/2401.08695) | [⬇️](https://arxiv.org/pdf/2401.08695)
*Zhengqing Fang, Shuowen Zhou, Zhouhang Yuan, Yuxuan Si, Mengze Li,  Jinxu Li, Yesheng Xu, Wenjia Xie, Kun Kuang, Yingming Li, Fei Wu, and Yu-Feng  Yao* 

  Although data-driven artificial intelligence (AI) in medical image diagnosis
has shown impressive performance in silico, the lack of interpretability makes
it difficult to incorporate the "black box" into clinicians' workflows. To make
the diagnostic patterns learned from data understandable by clinicians, we
develop an interpretable model, knowledge-guided diagnosis model (KGDM), that
provides a visualized reasoning process containing AI-based biomarkers and
retrieved cases that with the same diagnostic patterns. It embraces clinicians'
prompts into the interpreted reasoning through human-AI interaction, leading to
potentially enhanced safety and more accurate predictions. This study
investigates the performance, interpretability, and clinical utility of KGDM in
the diagnosis of infectious keratitis (IK), which is the leading cause of
corneal blindness. The classification performance of KGDM is evaluated on a
prospective validation dataset, an external testing dataset, and an publicly
available testing dataset. The diagnostic odds ratios (DOR) of the interpreted
AI-based biomarkers are effective, ranging from 3.011 to 35.233 and exhibit
consistent diagnostic patterns with clinic experience. Moreover, a human-AI
collaborative diagnosis test is conducted and the participants with
collaboration achieved a performance exceeding that of both humans and AI. By
synergistically integrating interpretability and interaction, this study
facilitates the convergence of clinicians' expertise and data-driven
intelligence. The promotion of inexperienced ophthalmologists with the aid of
AI-based biomarkers, as well as increased AI prediction by intervention from
experienced ones, demonstrate a promising diagnostic paradigm for infectious
keratitis using KGDM, which holds the potential for extension to other diseases
where experienced medical practitioners are limited and the safety of AI is
concerned.

---------------

### 14 Aug 2020 | [Survey of XAI in digital pathology](https://arxiv.org/abs/2008.06353) | [⬇️](https://arxiv.org/pdf/2008.06353)
*Milda Pocevi\v{c}i\=ut\.e and Gabriel Eilertsen and Claes Lundstr\"om* 

  Artificial intelligence (AI) has shown great promise for diagnostic imaging
assessments. However, the application of AI to support medical diagnostics in
clinical routine comes with many challenges. The algorithms should have high
prediction accuracy but also be transparent, understandable and reliable. Thus,
explainable artificial intelligence (XAI) is highly relevant for this domain.
We present a survey on XAI within digital pathology, a medical imaging
sub-discipline with particular characteristics and needs. The review includes
several contributions. Firstly, we give a thorough overview of current XAI
techniques of potential relevance for deep learning methods in pathology
imaging, and categorise them from three different aspects. In doing so, we
incorporate uncertainty estimation methods as an integral part of the XAI
landscape. We also connect the technical methods to the specific prerequisites
in digital pathology and present findings to guide future research efforts. The
survey is intended for both technical researchers and medical professionals,
one of the objectives being to establish a common ground for cross-disciplinary
discussions.

---------------

### 02 Mar 2023 | [Practical Statistical Considerations for the Clinical Validation of  AI/ML-enabled Medical Diagnostic Devices](https://arxiv.org/abs/2303.05399) | [⬇️](https://arxiv.org/pdf/2303.05399)
*Feiming Chen, Hong Laura Lu, Arianna Simonetti* 

  Artificial Intelligence (AI) and Machine-Learning (ML) models have been
increasingly used in medical products, such as medical device software. General
considerations on the statistical aspects for the evaluation of AI/ML-enabled
medical diagnostic devices are discussed in this paper. We also provide
relevant academic references and note good practices in addressing various
statistical challenges in the clinical validation of AI/ML-enabled medical
devices in the context of their intended use.

---------------

### 02 Jun 2023 | [XAI Renaissance: Redefining Interpretability in Medical Diagnostic  Models](https://arxiv.org/abs/2306.01668) | [⬇️](https://arxiv.org/pdf/2306.01668)
*Sujith K Mandala* 

  As machine learning models become increasingly prevalent in medical
diagnostics, the need for interpretability and transparency becomes paramount.
The XAI Renaissance signifies a significant shift in the field, aiming to
redefine the interpretability of medical diagnostic models. This paper explores
the innovative approaches and methodologies within the realm of Explainable AI
(XAI) that are revolutionizing the interpretability of medical diagnostic
models. By shedding light on the underlying decision-making process, XAI
techniques empower healthcare professionals to understand, trust, and
effectively utilize these models for accurate and reliable medical diagnoses.
This review highlights the key advancements in XAI for medical diagnostics and
their potential to transform the healthcare landscape, ultimately improving
patient outcomes and fostering trust in AI-driven diagnostic systems.

---------------

### 29 Jan 2024 | [Beyond Direct Diagnosis: LLM-based Multi-Specialist Agent Consultation  for Automatic Diagnosis](https://arxiv.org/abs/2401.16107) | [⬇️](https://arxiv.org/pdf/2401.16107)
*Haochun Wang, Sendong Zhao, Zewen Qiang, Nuwa Xi, Bing Qin, Ting Liu* 

  Automatic diagnosis is a significant application of AI in healthcare, where
diagnoses are generated based on the symptom description of patients. Previous
works have approached this task directly by modeling the relationship between
the normalized symptoms and all possible diseases. However, in the clinical
diagnostic process, patients are initially consulted by a general practitioner
and, if necessary, referred to specialists in specific domains for a more
comprehensive evaluation. The final diagnosis often emerges from a
collaborative consultation among medical specialist groups. Recently, large
language models have shown impressive capabilities in natural language
understanding. In this study, we adopt tuning-free LLM-based agents as medical
practitioners and propose the Agent-derived Multi-Specialist Consultation
(AMSC) framework to model the diagnosis process in the real world by adaptively
fusing probability distributions of agents over potential diseases.
Experimental results demonstrate the superiority of our approach compared with
baselines. Notably, our approach requires significantly less parameter updating
and training time, enhancing efficiency and practical utility. Furthermore, we
delve into a novel perspective on the role of implicit symptoms within the
context of automatic diagnosis.

---------------

### 11 Jan 2024 | [Towards Conversational Diagnostic AI](https://arxiv.org/abs/2401.05654) | [⬇️](https://arxiv.org/pdf/2401.05654)
*Tao Tu, Anil Palepu, Mike Schaekermann, Khaled Saab, Jan Freyberg,  Ryutaro Tanno, Amy Wang, Brenna Li, Mohamed Amin, Nenad Tomasev, Shekoofeh  Azizi, Karan Singhal, Yong Cheng, Le Hou, Albert Webson, Kavita Kulkarni, S  Sara Mahdavi, Christopher Semturs, Juraj Gottweis, Joelle Barral, Katherine  Chou, Greg S Corrado, Yossi Matias, Alan Karthikesalingam and Vivek Natarajan* 

  At the heart of medicine lies the physician-patient dialogue, where skillful
history-taking paves the way for accurate diagnosis, effective management, and
enduring trust. Artificial Intelligence (AI) systems capable of diagnostic
dialogue could increase accessibility, consistency, and quality of care.
However, approximating clinicians' expertise is an outstanding grand challenge.
Here, we introduce AMIE (Articulate Medical Intelligence Explorer), a Large
Language Model (LLM) based AI system optimized for diagnostic dialogue.
  AMIE uses a novel self-play based simulated environment with automated
feedback mechanisms for scaling learning across diverse disease conditions,
specialties, and contexts. We designed a framework for evaluating
clinically-meaningful axes of performance including history-taking, diagnostic
accuracy, management reasoning, communication skills, and empathy. We compared
AMIE's performance to that of primary care physicians (PCPs) in a randomized,
double-blind crossover study of text-based consultations with validated patient
actors in the style of an Objective Structured Clinical Examination (OSCE). The
study included 149 case scenarios from clinical providers in Canada, the UK,
and India, 20 PCPs for comparison with AMIE, and evaluations by specialist
physicians and patient actors. AMIE demonstrated greater diagnostic accuracy
and superior performance on 28 of 32 axes according to specialist physicians
and 24 of 26 axes according to patient actors. Our research has several
limitations and should be interpreted with appropriate caution. Clinicians were
limited to unfamiliar synchronous text-chat which permits large-scale
LLM-patient interactions but is not representative of usual clinical practice.
While further research is required before AMIE could be translated to
real-world settings, the results represent a milestone towards conversational
diagnostic AI.

---------------

### 14 Sep 2023 | [Preventing Unauthorized AI Over-Analysis by Medical Image Adversarial  Watermarking](https://arxiv.org/abs/2303.09858) | [⬇️](https://arxiv.org/pdf/2303.09858)
*Xingxing Wei, Bangzheng Pu, Shiji Zhao, Chen Chi and Huazhu Fu* 

  The advancement of deep learning has facilitated the integration of
Artificial Intelligence (AI) into clinical practices, particularly in
computer-aided diagnosis. Given the pivotal role of medical images in various
diagnostic procedures, it becomes imperative to ensure the responsible and
secure utilization of AI techniques. However, the unauthorized utilization of
AI for image analysis raises significant concerns regarding patient privacy and
potential infringement on the proprietary rights of data custodians.
Consequently, the development of pragmatic and cost-effective strategies that
safeguard patient privacy and uphold medical image copyrights emerges as a
critical necessity. In direct response to this pressing demand, we present a
pioneering solution named Medical Image Adversarial watermarking (MIAD-MARK).
Our approach introduces watermarks that strategically mislead unauthorized AI
diagnostic models, inducing erroneous predictions without compromising the
integrity of the visual content. Importantly, our method integrates an
authorization protocol tailored for legitimate users, enabling the removal of
the MIAD-MARK through encryption-generated keys. Through extensive experiments,
we validate the efficacy of MIAD-MARK across three prominent medical image
datasets. The empirical outcomes demonstrate the substantial impact of our
approach, notably reducing the accuracy of standard AI diagnostic models to a
mere 8.57% under white box conditions and 45.83% in the more challenging black
box scenario. Additionally, our solution effectively mitigates unauthorized
exploitation of medical images even in the presence of sophisticated watermark
removal networks. Notably, those AI diagnosis networks exhibit a meager average
accuracy of 38.59% when applied to images protected by MIAD-MARK, underscoring
the robustness of our safeguarding mechanism.

---------------

### 06 Apr 2021 | [In-Line Image Transformations for Imbalanced, Multiclass Computer Vision  Classification of Lung Chest X-Rays](https://arxiv.org/abs/2104.02238) | [⬇️](https://arxiv.org/pdf/2104.02238)
*Alexandrea K. Ramnarine* 

  Artificial intelligence (AI) is disrupting the medical field as advances in
modern technology allow common household computers to learn anatomical and
pathological features that distinguish between healthy and disease with the
accuracy of highly specialized, trained physicians. Computer vision AI
applications use medical imaging, such as lung chest X-Rays (LCXRs), to
facilitate diagnoses by providing second-opinions in addition to a physician's
or radiologist's interpretation. Considering the advent of the current
Coronavirus disease (COVID-19) pandemic, LCXRs may provide rapid insights to
indirectly aid in infection containment, however generating a reliably labeled
image dataset for a novel disease is not an easy feat, nor is it of highest
priority when combating a global pandemic. Deep learning techniques such as
convolutional neural networks (CNNs) are able to select features that
distinguish between healthy and disease states for other lung pathologies; this
study aims to leverage that body of literature in order to apply image
transformations that would serve to balance the lack of COVID-19 LCXR data.
Furthermore, this study utilizes a simple CNN architecture for high-performance
multiclass LCXR classification at 94 percent accuracy.

---------------

### 05 Jan 2024 | [Application of federated learning techniques for arrhythmia  classification using 12-lead ECG signals](https://arxiv.org/abs/2208.10993) | [⬇️](https://arxiv.org/pdf/2208.10993)
*Daniel Mauricio Jimenez Gutierrez, Hafiz Muuhammad Hassan, Lorella  Landi, Andrea Vitaletti and Ioannis Chatzigiannakis* 

  Artificial Intelligence-based (AI) analysis of large, curated medical
datasets is promising for providing early detection, faster diagnosis, and more
effective treatment using low-power Electrocardiography (ECG) monitoring
devices information. However, accessing sensitive medical data from diverse
sources is highly restricted since improper use, unsafe storage, or data
leakage could violate a person's privacy. This work uses a Federated Learning
(FL) privacy-preserving methodology to train AI models over heterogeneous sets
of high-definition ECG from 12-lead sensor arrays collected from six
heterogeneous sources. We evaluated the capacity of the resulting models to
achieve equivalent performance compared to state-of-the-art models trained in a
Centralized Learning (CL) fashion. Moreover, we assessed the performance of our
solution over Independent and Identical distributed (IID) and non-IID federated
data. Our methodology involves machine learning techniques based on Deep Neural
Networks and Long-Short-Term Memory models. It has a robust data preprocessing
pipeline with feature engineering, selection, and data balancing techniques.
Our AI models demonstrated comparable performance to models trained using CL,
IID, and non-IID approaches. They showcased advantages in reduced complexity
and faster training time, making them well-suited for cloud-edge architectures.

---------------

### 31 Aug 2022 | [Robustness of an Artificial Intelligence Solution for Diagnosis of  Normal Chest X-Rays](https://arxiv.org/abs/2209.09204) | [⬇️](https://arxiv.org/pdf/2209.09204)
*Tom Dyer, Jordan Smith, Gaetan Dissez, Nicole Tay, Qaiser Malik, Tom  Naunton Morgan, Paul Williams, Liliana Garcia-Mondragon, George Pearse, and  Simon Rasalingham* 

  Purpose: Artificial intelligence (AI) solutions for medical diagnosis require
thorough evaluation to demonstrate that performance is maintained for all
patient sub-groups and to ensure that proposed improvements in care will be
delivered equitably. This study evaluates the robustness of an AI solution for
the diagnosis of normal chest X-rays (CXRs) by comparing performance across
multiple patient and environmental subgroups, as well as comparing AI errors
with those made by human experts.
  Methods: A total of 4,060 CXRs were sampled to represent a diverse dataset of
NHS patients and care settings. Ground-truth labels were assigned by a
3-radiologist panel. AI performance was evaluated against assigned labels and
sub-groups analysis was conducted against patient age and sex, as well as CXR
view, modality, device manufacturer and hospital site.
  Results: The AI solution was able to remove 18.5% of the dataset by
classification as High Confidence Normal (HCN). This was associated with a
negative predictive value (NPV) of 96.0%, compared to 89.1% for diagnosis of
normal scans by radiologists. In all AI false negative (FN) cases, a
radiologist was found to have also made the same error when compared to final
ground-truth labels. Subgroup analysis showed no statistically significant
variations in AI performance, whilst reduced normal classification was observed
in data from some hospital sites.
  Conclusion: We show the AI solution could provide meaningful workload savings
by diagnosis of 18.5% of scans as HCN with a superior NPV to human readers. The
AI solution is shown to perform well across patient subgroups and error cases
were shown to be subjective or subtle in nature.

---------------

### 01 Dec 2023 | [Explainable AI in Diagnosing and Anticipating Leukemia Using Transfer  Learning Method](https://arxiv.org/abs/2312.00487) | [⬇️](https://arxiv.org/pdf/2312.00487)
*Wahidul Hasan Abir, Md. Fahim Uddin, Faria Rahman Khanam and Mohammad  Monirujjaman Khan* 

  This research paper focuses on Acute Lymphoblastic Leukemia (ALL), a form of
blood cancer prevalent in children and teenagers, characterized by the rapid
proliferation of immature white blood cells (WBCs). These atypical cells can
overwhelm healthy cells, leading to severe health consequences. Early and
accurate detection of ALL is vital for effective treatment and improving
survival rates. Traditional diagnostic methods are time-consuming, costly, and
prone to errors. The paper proposes an automated detection approach using
computer-aided diagnostic (CAD) models, leveraging deep learning techniques to
enhance the accuracy and efficiency of leukemia diagnosis. The study utilizes
various transfer learning models like ResNet101V2, VGG19, InceptionV3, and
InceptionResNetV2 for classifying ALL. The methodology includes using the Local
Interpretable Model-Agnostic Explanations (LIME) for ensuring the validity and
reliability of the AI system's predictions. This approach is critical for
overcoming the "black box" nature of AI, where decisions made by models are
often opaque and unaccountable. The paper highlights that the proposed method
using the InceptionV3 model achieved an impressive 98.38% accuracy,
outperforming other tested models. The results, verified by the LIME algorithm,
showcase the potential of this method in accurately identifying ALL, providing
a valuable tool for medical practitioners. The research underscores the impact
of explainable artificial intelligence (XAI) in medical diagnostics, paving the
way for more transparent and trustworthy AI applications in healthcare.

---------------

### 01 Feb 2024 | [VISION-MAE: A Foundation Model for Medical Image Segmentation and  Classification](https://arxiv.org/abs/2402.01034) | [⬇️](https://arxiv.org/pdf/2402.01034)
*Zelong Liu, Andrew Tieu, Nikhil Patel, Alexander Zhou, George  Soultanidis, Zahi A. Fayad, Timothy Deyer, Xueyan Mei* 

  Artificial Intelligence (AI) has the potential to revolutionize diagnosis and
segmentation in medical imaging. However, development and clinical
implementation face multiple challenges including limited data availability,
lack of generalizability, and the necessity to incorporate multi-modal data
effectively. A foundation model, which is a large-scale pre-trained AI model,
offers a versatile base that can be adapted to a variety of specific tasks and
contexts. Here, we present a novel foundation model, VISION-MAE, specifically
designed for medical imaging. Specifically, VISION-MAE is trained on a dataset
of 2.5 million unlabeled images from various modalities (CT, MR, PET, X-rays,
and ultrasound), using self-supervised learning techniques. It is then adapted
to classification and segmentation tasks using explicit labels. VISION-MAE has
high label efficiency, outperforming several benchmark models in both in-domain
and out-of-domain applications, and achieves high performance even with reduced
availability of labeled data. This model represents a significant advancement
in medical imaging AI, offering a generalizable and robust solution for
improving segmentation and classification tasks while reducing the data
annotation workload.

---------------

### 25 Feb 2024 | [Adversarial-Robust Transfer Learning for Medical Imaging via Domain  Assimilation](https://arxiv.org/abs/2402.16005) | [⬇️](https://arxiv.org/pdf/2402.16005)
*Xiaohui Chen and Tie Luo* 

  In the field of Medical Imaging, extensive research has been dedicated to
leveraging its potential in uncovering critical diagnostic features in
patients. Artificial Intelligence (AI)-driven medical diagnosis relies on
sophisticated machine learning and deep learning models to analyze, detect, and
identify diseases from medical images. Despite the remarkable performance of
these models, characterized by high accuracy, they grapple with trustworthiness
issues. The introduction of a subtle perturbation to the original image
empowers adversaries to manipulate the prediction output, redirecting it to
other targeted or untargeted classes. Furthermore, the scarcity of publicly
available medical images, constituting a bottleneck for reliable training, has
led contemporary algorithms to depend on pretrained models grounded on a large
set of natural images -- a practice referred to as transfer learning. However,
a significant {\em domain discrepancy} exists between natural and medical
images, which causes AI models resulting from transfer learning to exhibit
heightened {\em vulnerability} to adversarial attacks. This paper proposes a
{\em domain assimilation} approach that introduces texture and color adaptation
into transfer learning, followed by a texture preservation component to
suppress undesired distortion. We systematically analyze the performance of
transfer learning in the face of various adversarial attacks under different
data modalities, with the overarching goal of fortifying the model's robustness
and security in medical imaging tasks. The results demonstrate high
effectiveness in reducing attack efficacy, contributing toward more trustworthy
transfer learning in biomedical applications.

---------------

### 06 Apr 2020 | [Bridging the gap between AI and Healthcare sides: towards developing  clinically relevant AI-powered diagnosis systems](https://arxiv.org/abs/2001.03923) | [⬇️](https://arxiv.org/pdf/2001.03923)
*Changhee Han, Leonardo Rundo, Kohei Murao, Takafumi Nemoto, Hideki  Nakayama* 

  Despite the success of Convolutional Neural Network-based Computer-Aided
Diagnosis research, its clinical applications remain challenging. Accordingly,
developing medical Artificial Intelligence (AI) fitting into a clinical
environment requires identifying/bridging the gap between AI and Healthcare
sides. Since the biggest problem in Medical Imaging lies in data paucity,
confirming the clinical relevance for diagnosis of research-proven image
augmentation techniques is essential. Therefore, we hold a clinically valuable
AI-envisioning workshop among Japanese Medical Imaging experts, physicians, and
generalists in Healthcare/Informatics. Then, a questionnaire survey for
physicians evaluates our pathology-aware Generative Adversarial Network
(GAN)-based image augmentation projects in terms of Data Augmentation and
physician training. The workshop reveals the intrinsic gap between
AI/Healthcare sides and solutions on Why (i.e., clinical
significance/interpretation) and How (i.e., data acquisition, commercial
deployment, and safety/feeling safe). This analysis confirms our
pathology-aware GANs' clinical relevance as a clinical decision support system
and non-expert physician training tool. Our findings would play a key role in
connecting inter-disciplinary research and clinical applications, not limited
to the Japanese medical context and pathology-aware GANs.

---------------

### 29 Jun 2023 | [The State of Applying Artificial Intelligence to Tissue Imaging for  Cancer Research and Early Detection](https://arxiv.org/abs/2306.16989) | [⬇️](https://arxiv.org/pdf/2306.16989)
*Michael Robben, Amir Hajighasemi, Mohammad Sadegh Nasr, Jai Prakesh  Veerla, Anne M. Alsup, Biraaj Rout, Helen H. Shang, Kelli Fowlds, Parisa  Boodaghi Malidarreh, Paul Koomey, MD Jillur Rahman Saurav, Jacob M. Luber* 

  Artificial intelligence represents a new frontier in human medicine that
could save more lives and reduce the costs, thereby increasing accessibility.
As a consequence, the rate of advancement of AI in cancer medical imaging and
more particularly tissue pathology has exploded, opening it to ethical and
technical questions that could impede its adoption into existing systems. In
order to chart the path of AI in its application to cancer tissue imaging, we
review current work and identify how it can improve cancer pathology
diagnostics and research. In this review, we identify 5 core tasks that models
are developed for, including regression, classification, segmentation,
generation, and compression tasks. We address the benefits and challenges that
such methods face, and how they can be adapted for use in cancer prevention and
treatment. The studies looked at in this paper represent the beginning of this
field and future experiments will build on the foundations that we highlight.

---------------

### 20 Dec 2022 | [Local Differential Privacy Image Generation Using Flow-based Deep  Generative Models](https://arxiv.org/abs/2212.10688) | [⬇️](https://arxiv.org/pdf/2212.10688)
*Hisaichi Shibata, Shouhei Hanaoka, Yang Cao, Masatoshi Yoshikawa,  Tomomi Takenaga, Yukihiro Nomura, Naoto Hayashi, Osamu Abe* 

  Diagnostic radiologists need artificial intelligence (AI) for medical
imaging, but access to medical images required for training in AI has become
increasingly restrictive. To release and use medical images, we need an
algorithm that can simultaneously protect privacy and preserve pathologies in
medical images. To develop such an algorithm, here, we propose DP-GLOW, a
hybrid of a local differential privacy (LDP) algorithm and one of the
flow-based deep generative models (GLOW). By applying a GLOW model, we
disentangle the pixelwise correlation of images, which makes it difficult to
protect privacy with straightforward LDP algorithms for images. Specifically,
we map images onto the latent vector of the GLOW model, each element of which
follows an independent normal distribution, and we apply the Laplace mechanism
to the latent vector. Moreover, we applied DP-GLOW to chest X-ray images to
generate LDP images while preserving pathologies.

---------------

### 06 Feb 2024 | [Towards Deterministic End-to-end Latency for Medical AI Systems in  NVIDIA Holoscan](https://arxiv.org/abs/2402.04466) | [⬇️](https://arxiv.org/pdf/2402.04466)
*Soham Sinha, Shekhar Dwivedi, Mahdi Azizian* 

  The introduction of AI and ML technologies into medical devices has
revolutionized healthcare diagnostics and treatments. Medical device
manufacturers are keen to maximize the advantages afforded by AI and ML by
consolidating multiple applications onto a single platform. However, concurrent
execution of several AI applications, each with its own visualization
components, leads to unpredictable end-to-end latency, primarily due to GPU
resource contentions. To mitigate this, manufacturers typically deploy separate
workstations for distinct AI applications, thereby increasing financial,
energy, and maintenance costs. This paper addresses these challenges within the
context of NVIDIA's Holoscan platform, a real-time AI system for streaming
sensor data and images. We propose a system design optimized for heterogeneous
GPU workloads, encompassing both compute and graphics tasks. Our design
leverages CUDA MPS for spatial partitioning of compute workloads and isolates
compute and graphics processing onto separate GPUs. We demonstrate significant
performance improvements across various end-to-end latency determinism metrics
through empirical evaluation with real-world Holoscan medical device
applications. For instance, the proposed design reduces maximum latency by
21-30% and improves latency distribution flatness by 17-25% for up to five
concurrent endoscopy tool tracking AI applications, compared to a single-GPU
baseline. Against a default multi-GPU setup, our optimizations decrease maximum
latency by 35% for up to six concurrent applications by improving GPU
utilization by 42%. This paper provides clear design insights for AI
applications in the edge-computing domain including medical systems, where
performance predictability of concurrent and heterogeneous GPU workloads is a
critical requirement.

---------------
**Date:** 13 Jun 2023

**Title:** Multi-Task Training with In-Domain Language Models for Diagnostic  Reasoning

**Abstract Link:** [https://arxiv.org/abs/2306.04551](https://arxiv.org/abs/2306.04551)

**PDF Link:** [https://arxiv.org/pdf/2306.04551](https://arxiv.org/pdf/2306.04551)

---

**Date:** 24 May 2022

**Title:** Do it Like the Doctor: How We Can Design a Model That Uses Domain  Knowledge to Diagnose Pneumothorax

**Abstract Link:** [https://arxiv.org/abs/2205.12159](https://arxiv.org/abs/2205.12159)

**PDF Link:** [https://arxiv.org/pdf/2205.12159](https://arxiv.org/pdf/2205.12159)

---

**Date:** 18 Nov 2021

**Title:** Advancing COVID-19 Diagnosis with Privacy-Preserving Collaboration in  Artificial Intelligence

**Abstract Link:** [https://arxiv.org/abs/2111.09461](https://arxiv.org/abs/2111.09461)

**PDF Link:** [https://arxiv.org/pdf/2111.09461](https://arxiv.org/pdf/2111.09461)

---

**Date:** 14 Jan 2024

**Title:** Enabling Collaborative Clinical Diagnosis of Infectious Keratitis by  Integrating Expert Knowledge and Interpretable Data-driven Intelligence

**Abstract Link:** [https://arxiv.org/abs/2401.08695](https://arxiv.org/abs/2401.08695)

**PDF Link:** [https://arxiv.org/pdf/2401.08695](https://arxiv.org/pdf/2401.08695)

---

**Date:** 14 Aug 2020

**Title:** Survey of XAI in digital pathology

**Abstract Link:** [https://arxiv.org/abs/2008.06353](https://arxiv.org/abs/2008.06353)

**PDF Link:** [https://arxiv.org/pdf/2008.06353](https://arxiv.org/pdf/2008.06353)

---

**Date:** 02 Mar 2023

**Title:** Practical Statistical Considerations for the Clinical Validation of  AI/ML-enabled Medical Diagnostic Devices

**Abstract Link:** [https://arxiv.org/abs/2303.05399](https://arxiv.org/abs/2303.05399)

**PDF Link:** [https://arxiv.org/pdf/2303.05399](https://arxiv.org/pdf/2303.05399)

---

**Date:** 02 Jun 2023

**Title:** XAI Renaissance: Redefining Interpretability in Medical Diagnostic  Models

**Abstract Link:** [https://arxiv.org/abs/2306.01668](https://arxiv.org/abs/2306.01668)

**PDF Link:** [https://arxiv.org/pdf/2306.01668](https://arxiv.org/pdf/2306.01668)

---

**Date:** 29 Jan 2024

**Title:** Beyond Direct Diagnosis: LLM-based Multi-Specialist Agent Consultation  for Automatic Diagnosis

**Abstract Link:** [https://arxiv.org/abs/2401.16107](https://arxiv.org/abs/2401.16107)

**PDF Link:** [https://arxiv.org/pdf/2401.16107](https://arxiv.org/pdf/2401.16107)

---

**Date:** 11 Jan 2024

**Title:** Towards Conversational Diagnostic AI

**Abstract Link:** [https://arxiv.org/abs/2401.05654](https://arxiv.org/abs/2401.05654)

**PDF Link:** [https://arxiv.org/pdf/2401.05654](https://arxiv.org/pdf/2401.05654)

---

**Date:** 14 Sep 2023

**Title:** Preventing Unauthorized AI Over-Analysis by Medical Image Adversarial  Watermarking

**Abstract Link:** [https://arxiv.org/abs/2303.09858](https://arxiv.org/abs/2303.09858)

**PDF Link:** [https://arxiv.org/pdf/2303.09858](https://arxiv.org/pdf/2303.09858)

---

**Date:** 06 Apr 2021

**Title:** In-Line Image Transformations for Imbalanced, Multiclass Computer Vision  Classification of Lung Chest X-Rays

**Abstract Link:** [https://arxiv.org/abs/2104.02238](https://arxiv.org/abs/2104.02238)

**PDF Link:** [https://arxiv.org/pdf/2104.02238](https://arxiv.org/pdf/2104.02238)

---

**Date:** 05 Jan 2024

**Title:** Application of federated learning techniques for arrhythmia  classification using 12-lead ECG signals

**Abstract Link:** [https://arxiv.org/abs/2208.10993](https://arxiv.org/abs/2208.10993)

**PDF Link:** [https://arxiv.org/pdf/2208.10993](https://arxiv.org/pdf/2208.10993)

---

**Date:** 31 Aug 2022

**Title:** Robustness of an Artificial Intelligence Solution for Diagnosis of  Normal Chest X-Rays

**Abstract Link:** [https://arxiv.org/abs/2209.09204](https://arxiv.org/abs/2209.09204)

**PDF Link:** [https://arxiv.org/pdf/2209.09204](https://arxiv.org/pdf/2209.09204)

---

**Date:** 01 Dec 2023

**Title:** Explainable AI in Diagnosing and Anticipating Leukemia Using Transfer  Learning Method

**Abstract Link:** [https://arxiv.org/abs/2312.00487](https://arxiv.org/abs/2312.00487)

**PDF Link:** [https://arxiv.org/pdf/2312.00487](https://arxiv.org/pdf/2312.00487)

---

**Date:** 01 Feb 2024

**Title:** VISION-MAE: A Foundation Model for Medical Image Segmentation and  Classification

**Abstract Link:** [https://arxiv.org/abs/2402.01034](https://arxiv.org/abs/2402.01034)

**PDF Link:** [https://arxiv.org/pdf/2402.01034](https://arxiv.org/pdf/2402.01034)

---

**Date:** 25 Feb 2024

**Title:** Adversarial-Robust Transfer Learning for Medical Imaging via Domain  Assimilation

**Abstract Link:** [https://arxiv.org/abs/2402.16005](https://arxiv.org/abs/2402.16005)

**PDF Link:** [https://arxiv.org/pdf/2402.16005](https://arxiv.org/pdf/2402.16005)

---

**Date:** 06 Apr 2020

**Title:** Bridging the gap between AI and Healthcare sides: towards developing  clinically relevant AI-powered diagnosis systems

**Abstract Link:** [https://arxiv.org/abs/2001.03923](https://arxiv.org/abs/2001.03923)

**PDF Link:** [https://arxiv.org/pdf/2001.03923](https://arxiv.org/pdf/2001.03923)

---

**Date:** 29 Jun 2023

**Title:** The State of Applying Artificial Intelligence to Tissue Imaging for  Cancer Research and Early Detection

**Abstract Link:** [https://arxiv.org/abs/2306.16989](https://arxiv.org/abs/2306.16989)

**PDF Link:** [https://arxiv.org/pdf/2306.16989](https://arxiv.org/pdf/2306.16989)

---

**Date:** 20 Dec 2022

**Title:** Local Differential Privacy Image Generation Using Flow-based Deep  Generative Models

**Abstract Link:** [https://arxiv.org/abs/2212.10688](https://arxiv.org/abs/2212.10688)

**PDF Link:** [https://arxiv.org/pdf/2212.10688](https://arxiv.org/pdf/2212.10688)

---

**Date:** 06 Feb 2024

**Title:** Towards Deterministic End-to-end Latency for Medical AI Systems in  NVIDIA Holoscan

**Abstract Link:** [https://arxiv.org/abs/2402.04466](https://arxiv.org/abs/2402.04466)

**PDF Link:** [https://arxiv.org/pdf/2402.04466](https://arxiv.org/pdf/2402.04466)

---

