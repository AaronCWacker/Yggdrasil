AI Automated Research 🧫

### 🔎 AI Automated Research 🧫

🔬🔭

# AI Automated Research 🧫🔬🔭

## Outlines

* [AI Automated Research 🧫🔬🔭](#ai-automated-research-🧫🔬🔭)
	+ [Outlines](#outlines)
	+ [Introduction](#introduction)
	+ [AI Automated Research](#ai-automated-research)
		- [AI Automated Research](#ai-automated-research-1)
		- [AI Automated Research in Practice](#ai-automated-research-in-practice)
		- [AI Automated Research in the Future](#ai-automated-research-in-the-future)
	+ [Conclusion](#conclusion)
	+ [References](#references)

## Introduction

* AI Automated Research
	+ AI Automated Research is a new research method that uses AI to automate the research process.
	+ AI Automated Research can be used to conduct research in a variety of fields, including science, engineering, and business.
	+ AI Automated Research can help researchers to save time and money, and to conduct research more efficiently.

## AI Automated Research

### AI Automated Research

* AI Automated Research is a research method that uses AI to automate the research process.
* AI Automated Research can be used to conduct research in a variety of fields, including science, engineering, and business.
* AI Automated Research can help researchers to save time and money, and to conduct research more efficiently.

### AI Automated Research in Practice

* AI Automated Research is already being used in practice in a variety of fields.
* For example, AI Automated Research is being used to conduct research in the field of materials science.
* AI Automated Research is also being used to conduct research in the field of finance.

### AI Automated Research in the Future

* AI Automated Research is expected to become more widespread in the future.
* AI Automated Research is expected to become more sophisticated in the future.
* AI Automated Research is expected to become more accessible to researchers in the future.


# 🩺🔍 Search Results
### 16 Nov 2023 | [Towards Autonomous Hypothesis Verification via Language Models with  Minimal Guidance](https://arxiv.org/abs/2311.09706) | [⬇️](https://arxiv.org/pdf/2311.09706)
*Shiro Takagi, Ryutaro Yamauchi, Wataru Kumagai* 

  Research automation efforts usually employ AI as a tool to automate specific
tasks within the research process. To create an AI that truly conduct research
themselves, it must independently generate hypotheses, design verification
plans, and execute verification. Therefore, we investigated if an AI itself
could autonomously generate and verify hypothesis for a toy machine learning
research problem. We prompted GPT-4 to generate hypotheses and Python code for
hypothesis verification with limited methodological guidance. Our findings
suggest that, in some instances, GPT-4 can autonomously generate and validate
hypotheses without detailed guidance. While this is a promising result, we also
found that none of the verifications were flawless, and there remain
significant challenges in achieving autonomous, human-level research using only
generic instructions. These findings underscore the need for continued
exploration to develop a general and autonomous AI researcher.

---------------

### 21 Feb 2024 | [Social Environment Design](https://arxiv.org/abs/2402.14090) | [⬇️](https://arxiv.org/pdf/2402.14090)
*Edwin Zhang, Sadie Zhao, Tonghan Wang, Safwan Hossain, Henry  Gasztowtt, Stephan Zheng, David C. Parkes, Milind Tambe, Yiling Chen* 

  Artificial Intelligence (AI) holds promise as a technology that can be used
to improve government and economic policy-making. This paper proposes a new
research agenda towards this end by introducing Social Environment Design, a
general framework for the use of AI for automated policy-making that connects
with the Reinforcement Learning, EconCS, and Computational Social Choice
communities. The framework seeks to capture general economic environments,
includes voting on policy objectives, and gives a direction for the systematic
analysis of government and economic policy through AI simulation. We highlight
key open problems for future research in AI-based policy-making. By solving
these challenges, we hope to achieve various social welfare objectives, thereby
promoting more ethical and responsible decision making.

---------------

### 06 Oct 2021 | [A curated, ontology-based, large-scale knowledge graph of artificial  intelligence tasks and benchmarks](https://arxiv.org/abs/2110.01434) | [⬇️](https://arxiv.org/pdf/2110.01434)
*Kathrin Blagec, Adriano Barbosa-Silva, Simon Ott, Matthias Samwald* 

  Research in artificial intelligence (AI) is addressing a growing number of
tasks through a rapidly growing number of models and methodologies. This makes
it difficult to keep track of where novel AI methods are successfully -- or
still unsuccessfully -- applied, how progress is measured, how different
advances might synergize with each other, and how future research should be
prioritized.
  To help address these issues, we created the Intelligence Task Ontology and
Knowledge Graph (ITO), a comprehensive, richly structured and manually curated
resource on artificial intelligence tasks, benchmark results and performance
metrics. The current version of ITO contain 685,560 edges, 1,100 classes
representing AI processes and 1,995 properties representing performance
metrics.
  The goal of ITO is to enable precise and network-based analyses of the global
landscape of AI tasks and capabilities. ITO is based on technologies that allow
for easy integration and enrichment with external data, automated inference and
continuous, collaborative expert curation of underlying ontological models. We
make the ITO dataset and a collection of Jupyter notebooks utilising ITO openly
available.

---------------

### 22 Nov 2022 | [Automated, not Automatic: Needs and Practices in European Fact-checking  Organizations as a basis for Designing Human-centered AI Systems](https://arxiv.org/abs/2211.12143) | [⬇️](https://arxiv.org/pdf/2211.12143)
*Andrea Hrckova, Robert Moro, Ivan Srba, Jakub Simko, Maria Bielikova* 

  To mitigate the negative effects of false information more effectively, the
development of automated AI (artificial intelligence) tools assisting
fact-checkers is needed. Despite the existing research, there is still a gap
between the fact-checking practitioners' needs and pains and the current AI
research. We aspire to bridge this gap by employing methods of information
behavior research to identify implications for designing better human-centered
AI-based supporting tools.
  In this study, we conducted semi-structured in-depth interviews with Central
European fact-checkers. The information behavior and requirements on desired
supporting tools were analyzed using iterative bottom-up content analysis,
bringing the techniques from grounded theory. The most significant needs were
validated with a survey extended to fact-checkers from across Europe, in which
we collected 24 responses from 20 European countries, i.e., 62% active European
IFCN (International Fact-Checking Network) signatories.
  Our contributions are theoretical as well as practical. First, by being able
to map our findings about the needs of fact-checking organizations to the
relevant tasks for AI research, we have shown that the methods of information
behavior research are relevant for studying the processes in the organizations
and that these methods can be used to bridge the gap between the users and AI
researchers. Second, we have identified fact-checkers' needs and pains focusing
on so far unexplored dimensions and emphasizing the needs of fact-checkers from
Central and Eastern Europe as well as from low-resource language groups which
have implications for development of new resources (datasets) as well as for
the focus of AI research in this domain.

---------------

### 01 Nov 2023 | [Learning to optimize by multi-gradient for multi-objective optimization](https://arxiv.org/abs/2311.00559) | [⬇️](https://arxiv.org/pdf/2311.00559)
*Linxi Yang, Xinmin Yang, Liping Tang* 

  The development of artificial intelligence (AI) for science has led to the
emergence of learning-based research paradigms, necessitating a compelling
reevaluation of the design of multi-objective optimization (MOO) methods. The
new generation MOO methods should be rooted in automated learning rather than
manual design. In this paper, we introduce a new automatic learning paradigm
for optimizing MOO problems, and propose a multi-gradient learning to optimize
(ML2O) method, which automatically learns a generator (or mappings) from
multiple gradients to update directions. As a learning-based method, ML2O
acquires knowledge of local landscapes by leveraging information from the
current step and incorporates global experience extracted from historical
iteration trajectory data. By introducing a new guarding mechanism, we propose
a guarded multi-gradient learning to optimize (GML2O) method, and prove that
the iterative sequence generated by GML2O converges to a Pareto critical point.
The experimental results demonstrate that our learned optimizer outperforms
hand-designed competitors on training multi-task learning (MTL) neural network.

---------------

### 31 Oct 2023 | [Automated Parliaments: A Solution to Decision Uncertainty and  Misalignment in Language Models](https://arxiv.org/abs/2311.10098) | [⬇️](https://arxiv.org/pdf/2311.10098)
*Thomas Forster, Jonathan Ouwerx, Shak Ragoler* 

  As AI takes on a greater role in the modern world, it is essential to ensure
that AI models can overcome decision uncertainty and remain aligned with human
morality and interests. This research paper proposes a method for improving the
decision-making of language models (LMs) via Automated Parliaments (APs) -
constructs made of AI delegates each representing a certain perspective.
Delegates themselves consist of three AI models: generators, modifiers, and
evaluators. We specify two mechanisms for producing optimal solutions: the
Simultaneous Modification mechanism for response creation and an evaluation
mechanism for fairly assessing solutions. The overall process begins when each
generator creates a response aligned with its delegate's theory. The modifiers
alter all other responses to make them more self-aligned. The evaluators
collectively assess the best end response. Finally, the modifiers and
generators learn from feedback from the evaluators. In our research, we tested
the evaluation mechanism, comparing the use of single-value zero-shot prompting
and AP few-shot prompting in evaluating morally contentious scenarios. We found
that the AP architecture saw a 57.3% reduction in its loss value compared to
the baseline. We conclude by discussing some potential applications of APs and
specifically their potential impact when implemented as Automated Moral
Parliaments.

---------------

### 21 Oct 2019 | [Towards better healthcare: What could and should be automated?](https://arxiv.org/abs/1910.09444) | [⬇️](https://arxiv.org/pdf/1910.09444)
*Wolfgang Fr\"uhwirt and Paul Duckworth* 

  While artificial intelligence (AI) and other automation technologies might
lead to enormous progress in healthcare, they may also have undesired
consequences for people working in the field. In this interdisciplinary study,
we capture empirical evidence of not only what healthcare work could be
automated, but also what should be automated. We quantitatively investigate
these research questions by utilizing probabilistic machine learning models
trained on thousands of ratings, provided by both healthcare practitioners and
automation experts. Based on our findings, we present an analytical tool
(Automatability-Desirability Matrix) to support policymakers and organizational
leaders in developing practical strategies on how to harness the positive power
of automation technologies, while accompanying change and empowering
stakeholders in a participatory fashion.

---------------

### 21 Aug 2023 | [What's the Problem, Linda? The Conjunction Fallacy as a Fairness Problem](https://arxiv.org/abs/2305.09535) | [⬇️](https://arxiv.org/pdf/2305.09535)
*Jose Alvarez Colmenares* 

  The field of Artificial Intelligence (AI) is focusing on creating automated
decision-making (ADM) systems that operate as close as possible to human-like
intelligence. This effort has pushed AI researchers into exploring cognitive
fields like psychology. The work of Daniel Kahneman and the late Amos Tversky
on biased human decision-making, including the study of the conjunction
fallacy, has experienced a second revival because of this. Under the
conjunction fallacy a human decision-maker will go against basic probability
laws and rank as more likely a conjunction over one of its parts. It has been
proven overtime through a set of experiments with the Linda Problem being the
most famous one. Although this interdisciplinary effort is welcomed, we fear
that AI researchers ignore the driving force behind the conjunction fallacy as
captured by the Linda Problem: the fact that Linda must be stereotypically
described as a woman. In this paper we revisit the Linda Problem and formulate
it as a fairness problem. In doing so we introduce perception as a parameter of
interest through the structural causal perception framework. Using an
illustrative decision-making example, we showcase the proposed conceptual
framework and its potential impact for developing fair ADM systems.

---------------

### 03 Jun 2023 | [Anti-unification and Generalization: A Survey](https://arxiv.org/abs/2302.00277) | [⬇️](https://arxiv.org/pdf/2302.00277)
*David M. Cerna and Temur Kutsia* 

  Anti-unification (AU) is a fundamental operation for generalization
computation used for inductive inference. It is the dual operation to
unification, an operation at the foundation of automated theorem proving.
Interest in AU from the AI and related communities is growing, but without a
systematic study of the concept nor surveys of existing work, investigations
often resort to developing application-specific methods that existing
approaches may cover. We provide the first survey of AU research and its
applications and a general framework for categorizing existing and future
developments.

---------------

### 03 May 2019 | [Impact of Artificial Intelligence on Businesses: from Research,  Innovation, Market Deployment to Future Shifts in Business Models](https://arxiv.org/abs/1905.02092) | [⬇️](https://arxiv.org/pdf/1905.02092)
*Neha Soni, Enakshi Khular Sharma, Narotam Singh, Amita Kapoor* 

  The fast pace of artificial intelligence (AI) and automation is propelling
strategists to reshape their business models. This is fostering the integration
of AI in the business processes but the consequences of this adoption are
underexplored and need attention. This paper focuses on the overall impact of
AI on businesses - from research, innovation, market deployment to future
shifts in business models. To access this overall impact, we design a
three-dimensional research model, based upon the Neo-Schumpeterian economics
and its three forces viz. innovation, knowledge, and entrepreneurship. The
first dimension deals with research and innovation in AI. In the second
dimension, we explore the influence of AI on the global market and the
strategic objectives of the businesses and finally, the third dimension
examines how AI is shaping business contexts. Additionally, the paper explores
AI implications on actors and its dark sides.

---------------

### 05 May 2022 | [The scope for AI-augmented interpretation of building blueprints in  commercial and industrial property insurance](https://arxiv.org/abs/2205.01671) | [⬇️](https://arxiv.org/pdf/2205.01671)
*Long Chen, Mao Ye, Alistair Milne, John Hillier, Frances Oglesby* 

  This report, commissioned by the WTW research network, investigates the use
of AI in property risk assessment. It (i) reviews existing work on risk
assessment in commercial and industrial properties and automated information
extraction from building blueprints; and (ii) presents an exploratory 'proof-of
concept-solution' exploring the feasibility of using machine learning for the
automated extraction of information from building blueprints to support
insurance risk assessment.

---------------

### 22 Mar 2021 | [Automated and Autonomous Experiment in Electron and Scanning Probe  Microscopy](https://arxiv.org/abs/2103.12165) | [⬇️](https://arxiv.org/pdf/2103.12165)
*Sergei V. Kalinin, Maxim A. Ziatdinov, Jacob Hinkle, Stephen Jesse,  Ayana Ghosh, Kyle P. Kelley, Andrew R. Lupini, Bobby G. Sumpter, Rama K.  Vasudevan* 

  Machine learning and artificial intelligence (ML/AI) are rapidly becoming an
indispensable part of physics research, with domain applications ranging from
theory and materials prediction to high-throughput data analysis. In parallel,
the recent successes in applying ML/AI methods for autonomous systems from
robotics through self-driving cars to organic and inorganic synthesis are
generating enthusiasm for the potential of these techniques to enable automated
and autonomous experiment (AE) in imaging. Here, we aim to analyze the major
pathways towards AE in imaging methods with sequential image formation
mechanisms, focusing on scanning probe microscopy (SPM) and (scanning)
transmission electron microscopy ((S)TEM). We argue that automated experiments
should necessarily be discussed in a broader context of the general domain
knowledge that both informs the experiment and is increased as the result of
the experiment. As such, this analysis should explore the human and ML/AI roles
prior to and during the experiment, and consider the latencies, biases, and
knowledge priors of the decision-making process. Similarly, such discussion
should include the limitations of the existing imaging systems, including
intrinsic latencies, non-idealities and drifts comprising both correctable and
stochastic components. We further pose that the role of the AE in microscopy is
not the exclusion of human operators (as is the case for autonomous driving),
but rather automation of routine operations such as microscope tuning, etc.,
prior to the experiment, and conversion of low latency decision making
processes on the time scale spanning from image acquisition to human-level
high-order experiment planning.

---------------

### 09 Dec 2023 | [Artificial Intelligence in the automatic coding of interviews on  Landscape Quality Objectives. Comparison and case study](https://arxiv.org/abs/2312.05597) | [⬇️](https://arxiv.org/pdf/2312.05597)
*Mario Burgui-Burgui* 

  In this study, we conducted a comparative analysis of the automated coding
provided by three Artificial Intelligence functionalities (At-las.ti, ChatGPT
and Google Bard) in relation to the manual coding of 12 research interviews
focused on Landscape Quality Objectives for a small island in the north of Cuba
(Cayo Santa Mar\'ia). For this purpose, the following comparison criteria were
established: Accuracy, Comprehensiveness, Thematic Coherence, Redundancy,
Clarity, Detail and Regularity. The analysis showed the usefulness of AI for
the intended purpose, albeit with numerous flaws and shortcomings. In summary,
today the automatic coding of AIs can be considered useful as a guide towards a
subsequent in-depth and meticulous analysis of the information by the
researcher. However, as this is such a recently developed field, rapid
evolution is expected to bring the necessary improvements to these tools.

---------------

### 13 Feb 2024 | [Artificial Intelligence for Literature Reviews: Opportunities and  Challenges](https://arxiv.org/abs/2402.08565) | [⬇️](https://arxiv.org/pdf/2402.08565)
*Francisco Bolanos, Angelo Salatino, Francesco Osborne, Enrico Motta* 

  This manuscript presents a comprehensive review of the use of Artificial
Intelligence (AI) in Systematic Literature Reviews (SLRs). A SLR is a rigorous
and organised methodology that assesses and integrates previous research on a
given topic. Numerous tools have been developed to assist and partially
automate the SLR process. The increasing role of AI in this field shows great
potential in providing more effective support for researchers, moving towards
the semi-automatic creation of literature reviews. Our study focuses on how AI
techniques are applied in the semi-automation of SLRs, specifically in the
screening and extraction phases. We examine 21 leading SLR tools using a
framework that combines 23 traditional features with 11 AI features. We also
analyse 11 recent tools that leverage large language models for searching the
literature and assisting academic writing. Finally, the paper discusses current
trends in the field, outlines key research challenges, and suggests directions
for future research.

---------------

### 20 Sep 2016 | [Early Visual Concept Learning with Unsupervised Deep Learning](https://arxiv.org/abs/1606.05579) | [⬇️](https://arxiv.org/pdf/1606.05579)
*Irina Higgins, Loic Matthey, Xavier Glorot, Arka Pal, Benigno Uria,  Charles Blundell, Shakir Mohamed, Alexander Lerchner* 

  Automated discovery of early visual concepts from raw image data is a major
open challenge in AI research. Addressing this problem, we propose an
unsupervised approach for learning disentangled representations of the
underlying factors of variation. We draw inspiration from neuroscience, and
show how this can be achieved in an unsupervised generative model by applying
the same learning pressures as have been suggested to act in the ventral visual
stream in the brain. By enforcing redundancy reduction, encouraging statistical
independence, and exposure to data with transform continuities analogous to
those to which human infants are exposed, we obtain a variational autoencoder
(VAE) framework capable of learning disentangled factors. Our approach makes
few assumptions and works well across a wide variety of datasets. Furthermore,
our solution has useful emergent properties, such as zero-shot inference and an
intuitive understanding of "objectness".

---------------

### 03 Oct 2021 | [Artificial Intelligence For Breast Cancer Detection: Trends & Directions](https://arxiv.org/abs/2110.00942) | [⬇️](https://arxiv.org/pdf/2110.00942)
*Shahid Munir Shah, Rizwan Ahmed Khan, Sheeraz Arif and Unaiza Sajid* 

  In the last decade, researchers working in the domain of computer vision and
Artificial Intelligence (AI) have beefed up their efforts to come up with the
automated framework that not only detects but also identifies stage of breast
cancer. The reason for this surge in research activities in this direction are
mainly due to advent of robust AI algorithms (deep learning), availability of
hardware that can train those robust and complex AI algorithms and
accessibility of large enough dataset required for training AI algorithms.
Different imaging modalities that have been exploited by researchers to
automate the task of breast cancer detection are mammograms, ultrasound,
magnetic resonance imaging, histopathological images or any combination of
them. This article analyzes these imaging modalities and presents their
strengths, limitations and enlists resources from where their datasets can be
accessed for research purpose. This article then summarizes AI and computer
vision based state-of-the-art methods proposed in the last decade, to detect
breast cancer using various imaging modalities. Generally, in this article we
have focused on to review frameworks that have reported results using
mammograms as it is most widely used breast imaging modality that serves as
first test that medical practitioners usually prescribe for the detection of
breast cancer. Second reason of focusing on mammogram imaging modalities is the
availability of its labeled datasets. Datasets availability is one of the most
important aspect for the development of AI based frameworks as such algorithms
are data hungry and generally quality of dataset affects performance of AI
based algorithms. In a nutshell, this research article will act as a primary
resource for the research community working in the field of automated breast
imaging analysis.

---------------

### 06 May 2020 | [Towards Concise, Machine-discovered Proofs of G\"odel's Two  Incompleteness Theorems](https://arxiv.org/abs/2005.02576) | [⬇️](https://arxiv.org/pdf/2005.02576)
*Elijah Malaby, Bradley Dragun, John Licato* 

  There is an increasing interest in applying recent advances in AI to
automated reasoning, as it may provide useful heuristics in reasoning over
formalisms in first-order, second-order, or even meta-logics. To facilitate
this research, we present MATR, a new framework for automated theorem proving
explicitly designed to easily adapt to unusual logics or integrate new
reasoning processes. MATR is formalism-agnostic, highly modular, and
programmer-friendly. We explain the high-level design of MATR as well as some
details of its implementation. To demonstrate MATR's utility, we then describe
a formalized metalogic suitable for proofs of G\"odel's Incompleteness
Theorems, and report on our progress using our metalogic in MATR to
semi-autonomously generate proofs of both the First and Second Incompleteness
Theorems.

---------------

### 26 Apr 2022 | [A Review on Text-Based Emotion Detection -- Techniques, Applications,  Datasets, and Future Directions](https://arxiv.org/abs/2205.03235) | [⬇️](https://arxiv.org/pdf/2205.03235)
*Sheetal Kusal, Shruti Patil, Jyoti Choudrie, Ketan Kotecha, Deepali  Vora, Ilias Pappas* 

  Artificial Intelligence (AI) has been used for processing data to make
decisions, interact with humans, and understand their feelings and emotions.
With the advent of the internet, people share and express their thoughts on
day-to-day activities and global and local events through text messaging
applications. Hence, it is essential for machines to understand emotions in
opinions, feedback, and textual dialogues to provide emotionally aware
responses to users in today's online world. The field of text-based emotion
detection (TBED) is advancing to provide automated solutions to various
applications, such as businesses, and finances, to name a few. TBED has gained
a lot of attention in recent times. The paper presents a systematic literature
review of the existing literature published between 2005 to 2021 in TBED. This
review has meticulously examined 63 research papers from IEEE, Science Direct,
Scopus, and Web of Science databases to address four primary research
questions. It also reviews the different applications of TBED across various
research domains and highlights its use. An overview of various emotion models,
techniques, feature extraction methods, datasets, and research challenges with
future directions has also been represented.

---------------

### 13 Jan 2024 | [Artificial intelligence to automate the systematic review of scientific  literature](https://arxiv.org/abs/2401.10917) | [⬇️](https://arxiv.org/pdf/2401.10917)
*Jos\'e de la Torre-L\'opez and Aurora Ram\'irez and Jos\'e Ra\'ul  Romero* 

  Artificial intelligence (AI) has acquired notorious relevance in modern
computing as it effectively solves complex tasks traditionally done by humans.
AI provides methods to represent and infer knowledge, efficiently manipulate
texts and learn from vast amount of data. These characteristics are applicable
in many activities that human find laborious or repetitive, as is the case of
the analysis of scientific literature. Manually preparing and writing a
systematic literature review (SLR) takes considerable time and effort, since it
requires planning a strategy, conducting the literature search and analysis,
and reporting the findings. Depending on the area under study, the number of
papers retrieved can be of hundreds or thousands, meaning that filtering those
relevant ones and extracting the key information becomes a costly and
error-prone process. However, some of the involved tasks are repetitive and,
therefore, subject to automation by means of AI. In this paper, we present a
survey of AI techniques proposed in the last 15 years to help researchers
conduct systematic analyses of scientific literature. We describe the tasks
currently supported, the types of algorithms applied, and available tools
proposed in 34 primary studies. This survey also provides a historical
perspective of the evolution of the field and the role that humans can play in
an increasingly automated SLR process.

---------------

### 25 Oct 2023 | [math-PVS: A Large Language Model Framework to Map Scientific  Publications to PVS Theories](https://arxiv.org/abs/2310.17064) | [⬇️](https://arxiv.org/pdf/2310.17064)
*Hassen Saidi, Susmit Jha, Tuhin Sahai* 

  As artificial intelligence (AI) gains greater adoption in a wide variety of
applications, it has immense potential to contribute to mathematical discovery,
by guiding conjecture generation, constructing counterexamples, assisting in
formalizing mathematics, and discovering connections between different
mathematical areas, to name a few.
  While prior work has leveraged computers for exhaustive mathematical proof
search, recent efforts based on large language models (LLMs) aspire to position
computing platforms as co-contributors in the mathematical research process.
Despite their current limitations in logic and mathematical tasks, there is
growing interest in melding theorem proving systems with foundation models.
This work investigates the applicability of LLMs in formalizing advanced
mathematical concepts and proposes a framework that can critically review and
check mathematical reasoning in research papers. Given the noted reasoning
shortcomings of LLMs, our approach synergizes the capabilities of proof
assistants, specifically PVS, with LLMs, enabling a bridge between textual
descriptions in academic papers and formal specifications in PVS. By harnessing
the PVS environment, coupled with data ingestion and conversion mechanisms, we
envision an automated process, called \emph{math-PVS}, to extract and formalize
mathematical theorems from research papers, offering an innovative tool for
academic review and discovery.

---------------
**Date:** 16 Nov 2023

**Title:** Towards Autonomous Hypothesis Verification via Language Models with  Minimal Guidance

**Abstract Link:** [https://arxiv.org/abs/2311.09706](https://arxiv.org/abs/2311.09706)

**PDF Link:** [https://arxiv.org/pdf/2311.09706](https://arxiv.org/pdf/2311.09706)

---

**Date:** 21 Feb 2024

**Title:** Social Environment Design

**Abstract Link:** [https://arxiv.org/abs/2402.14090](https://arxiv.org/abs/2402.14090)

**PDF Link:** [https://arxiv.org/pdf/2402.14090](https://arxiv.org/pdf/2402.14090)

---

**Date:** 06 Oct 2021

**Title:** A curated, ontology-based, large-scale knowledge graph of artificial  intelligence tasks and benchmarks

**Abstract Link:** [https://arxiv.org/abs/2110.01434](https://arxiv.org/abs/2110.01434)

**PDF Link:** [https://arxiv.org/pdf/2110.01434](https://arxiv.org/pdf/2110.01434)

---

**Date:** 22 Nov 2022

**Title:** Automated, not Automatic: Needs and Practices in European Fact-checking  Organizations as a basis for Designing Human-centered AI Systems

**Abstract Link:** [https://arxiv.org/abs/2211.12143](https://arxiv.org/abs/2211.12143)

**PDF Link:** [https://arxiv.org/pdf/2211.12143](https://arxiv.org/pdf/2211.12143)

---

**Date:** 01 Nov 2023

**Title:** Learning to optimize by multi-gradient for multi-objective optimization

**Abstract Link:** [https://arxiv.org/abs/2311.00559](https://arxiv.org/abs/2311.00559)

**PDF Link:** [https://arxiv.org/pdf/2311.00559](https://arxiv.org/pdf/2311.00559)

---

**Date:** 31 Oct 2023

**Title:** Automated Parliaments: A Solution to Decision Uncertainty and  Misalignment in Language Models

**Abstract Link:** [https://arxiv.org/abs/2311.10098](https://arxiv.org/abs/2311.10098)

**PDF Link:** [https://arxiv.org/pdf/2311.10098](https://arxiv.org/pdf/2311.10098)

---

**Date:** 21 Oct 2019

**Title:** Towards better healthcare: What could and should be automated?

**Abstract Link:** [https://arxiv.org/abs/1910.09444](https://arxiv.org/abs/1910.09444)

**PDF Link:** [https://arxiv.org/pdf/1910.09444](https://arxiv.org/pdf/1910.09444)

---

**Date:** 21 Aug 2023

**Title:** What's the Problem, Linda? The Conjunction Fallacy as a Fairness Problem

**Abstract Link:** [https://arxiv.org/abs/2305.09535](https://arxiv.org/abs/2305.09535)

**PDF Link:** [https://arxiv.org/pdf/2305.09535](https://arxiv.org/pdf/2305.09535)

---

**Date:** 03 Jun 2023

**Title:** Anti-unification and Generalization: A Survey

**Abstract Link:** [https://arxiv.org/abs/2302.00277](https://arxiv.org/abs/2302.00277)

**PDF Link:** [https://arxiv.org/pdf/2302.00277](https://arxiv.org/pdf/2302.00277)

---

**Date:** 03 May 2019

**Title:** Impact of Artificial Intelligence on Businesses: from Research,  Innovation, Market Deployment to Future Shifts in Business Models

**Abstract Link:** [https://arxiv.org/abs/1905.02092](https://arxiv.org/abs/1905.02092)

**PDF Link:** [https://arxiv.org/pdf/1905.02092](https://arxiv.org/pdf/1905.02092)

---

**Date:** 05 May 2022

**Title:** The scope for AI-augmented interpretation of building blueprints in  commercial and industrial property insurance

**Abstract Link:** [https://arxiv.org/abs/2205.01671](https://arxiv.org/abs/2205.01671)

**PDF Link:** [https://arxiv.org/pdf/2205.01671](https://arxiv.org/pdf/2205.01671)

---

**Date:** 22 Mar 2021

**Title:** Automated and Autonomous Experiment in Electron and Scanning Probe  Microscopy

**Abstract Link:** [https://arxiv.org/abs/2103.12165](https://arxiv.org/abs/2103.12165)

**PDF Link:** [https://arxiv.org/pdf/2103.12165](https://arxiv.org/pdf/2103.12165)

---

**Date:** 09 Dec 2023

**Title:** Artificial Intelligence in the automatic coding of interviews on  Landscape Quality Objectives. Comparison and case study

**Abstract Link:** [https://arxiv.org/abs/2312.05597](https://arxiv.org/abs/2312.05597)

**PDF Link:** [https://arxiv.org/pdf/2312.05597](https://arxiv.org/pdf/2312.05597)

---

**Date:** 13 Feb 2024

**Title:** Artificial Intelligence for Literature Reviews: Opportunities and  Challenges

**Abstract Link:** [https://arxiv.org/abs/2402.08565](https://arxiv.org/abs/2402.08565)

**PDF Link:** [https://arxiv.org/pdf/2402.08565](https://arxiv.org/pdf/2402.08565)

---

**Date:** 20 Sep 2016

**Title:** Early Visual Concept Learning with Unsupervised Deep Learning

**Abstract Link:** [https://arxiv.org/abs/1606.05579](https://arxiv.org/abs/1606.05579)

**PDF Link:** [https://arxiv.org/pdf/1606.05579](https://arxiv.org/pdf/1606.05579)

---

**Date:** 03 Oct 2021

**Title:** Artificial Intelligence For Breast Cancer Detection: Trends & Directions

**Abstract Link:** [https://arxiv.org/abs/2110.00942](https://arxiv.org/abs/2110.00942)

**PDF Link:** [https://arxiv.org/pdf/2110.00942](https://arxiv.org/pdf/2110.00942)

---

**Date:** 06 May 2020

**Title:** Towards Concise, Machine-discovered Proofs of G\"odel's Two  Incompleteness Theorems

**Abstract Link:** [https://arxiv.org/abs/2005.02576](https://arxiv.org/abs/2005.02576)

**PDF Link:** [https://arxiv.org/pdf/2005.02576](https://arxiv.org/pdf/2005.02576)

---

**Date:** 26 Apr 2022

**Title:** A Review on Text-Based Emotion Detection -- Techniques, Applications,  Datasets, and Future Directions

**Abstract Link:** [https://arxiv.org/abs/2205.03235](https://arxiv.org/abs/2205.03235)

**PDF Link:** [https://arxiv.org/pdf/2205.03235](https://arxiv.org/pdf/2205.03235)

---

**Date:** 13 Jan 2024

**Title:** Artificial intelligence to automate the systematic review of scientific  literature

**Abstract Link:** [https://arxiv.org/abs/2401.10917](https://arxiv.org/abs/2401.10917)

**PDF Link:** [https://arxiv.org/pdf/2401.10917](https://arxiv.org/pdf/2401.10917)

---

**Date:** 25 Oct 2023

**Title:** math-PVS: A Large Language Model Framework to Map Scientific  Publications to PVS Theories

**Abstract Link:** [https://arxiv.org/abs/2310.17064](https://arxiv.org/abs/2310.17064)

**PDF Link:** [https://arxiv.org/pdf/2310.17064](https://arxiv.org/pdf/2310.17064)

---

