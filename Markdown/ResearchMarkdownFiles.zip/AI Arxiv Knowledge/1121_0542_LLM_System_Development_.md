LLM System Development 🎪

### 🔎 LLM System Development 🎪



# 🎪 System Development

System development is the process of creating, designing, implementing, and managing information systems. It involves various stages, including planning, analysis, design, implementation, testing, and maintenance. System development aims to provide organizations with efficient and effective information systems that meet their business needs and objectives.

There are different approaches to system development, including the waterfall model, the agile model, and the spiral model. The waterfall model is a linear approach where each stage is completed before moving on to the next. The agile model is an iterative approach where development is broken down into smaller parts, allowing for frequent feedback and adjustments. The spiral model is a risk-driven approach that involves multiple iterations, with each iteration focusing on a specific aspect of the system.

System development requires a team of professionals with different skills and expertise, including project managers, business analysts, system architects, developers, testers, and database administrators. Effective communication, collaboration, and project management are crucial to the success of system development projects.

System development can be complex and challenging, but it is essential for organizations to stay competitive and meet the changing needs of their customers and stakeholders. By investing in system development, organizations can improve their operations, reduce costs, and increase productivity, ultimately leading to better business outcomes.</s>
# 🩺🔍 Search Results
### 12 Sep 2023 | [Do Generative Large Language Models need billions of parameters?](https://arxiv.org/abs/2309.06589) | [⬇️](https://arxiv.org/pdf/2309.06589)
*Sia Gholami, Marwan Omar* 

  This paper presents novel systems and methodologies for the development of
efficient large language models (LLMs). It explores the trade-offs between
model size, performance, and computational resources, with the aim of
maximizing the efficiency of these AI systems. The research explores novel
methods that allow different parts of the model to share parameters, reducing
the total number of unique parameters required. This approach ensures that the
model remains compact without sacrificing its ability to learn and represent
complex language structures. This study provides valuable insights and tools
for creating more efficient and effective LLMs, contributing to a more
sustainable and accessible future for AI language modeling.

---------------

### 13 Dec 2023 | [Large Language Model Enhanced Multi-Agent Systems for 6G Communications](https://arxiv.org/abs/2312.07850) | [⬇️](https://arxiv.org/pdf/2312.07850)
*Feibo Jiang, Li Dong, Yubo Peng, Kezhi Wang, Kun Yang, Cunhua Pan,  Dusit Niyato, Octavia A. Dobre* 

  The rapid development of the Large Language Model (LLM) presents huge
opportunities for 6G communications, e.g., network optimization and management
by allowing users to input task requirements to LLMs by nature language.
However, directly applying native LLMs in 6G encounters various challenges,
such as a lack of private communication data and knowledge, limited logical
reasoning, evaluation, and refinement abilities. Integrating LLMs with the
capabilities of retrieval, planning, memory, evaluation and reflection in
agents can greatly enhance the potential of LLMs for 6G communications. To this
end, we propose a multi-agent system with customized communication knowledge
and tools for solving communication related tasks using natural language,
comprising three components: (1) Multi-agent Data Retrieval (MDR), which
employs the condensate and inference agents to refine and summarize
communication knowledge from the knowledge base, expanding the knowledge
boundaries of LLMs in 6G communications; (2) Multi-agent Collaborative Planning
(MCP), which utilizes multiple planning agents to generate feasible solutions
for the communication related task from different perspectives based on the
retrieved knowledge; (3) Multi-agent Evaluation and Reflecxion (MER), which
utilizes the evaluation agent to assess the solutions, and applies the
reflexion agent and refinement agent to provide improvement suggestions for
current solutions. Finally, we validate the effectiveness of the proposed
multi-agent system by designing a semantic communication system, as a case
study of 6G communications.

---------------

### 20 Aug 2023 | [LMTuner: An user-friendly and highly-integrable Training Framework for  fine-tuning Large Language Models](https://arxiv.org/abs/2308.10252) | [⬇️](https://arxiv.org/pdf/2308.10252)
*Yixuan Weng, Zhiqi Wang, Huanxuan Liao, Shizhu He, Shengping Liu, Kang  Liu, Jun Zhao* 

  With the burgeoning development in the realm of large language models (LLMs),
the demand for efficient incremental training tailored to specific industries
and domains continues to increase. Currently, the predominantly employed
frameworks lack modular design, it often takes a lot of coding work to
kickstart the training of LLM. To address this, we present "LMTuner", a highly
usable, integrable, and scalable system for training LLMs expeditiously and
with minimal user-input. LMTuner comprises three main modules - the
Interaction, Training, and Inference Modules. We advocate that LMTuner's
usability and integrality alleviate the complexities in training large language
models. Remarkably, even a novice user could commence training large language
models within five minutes. Furthermore, it integrates DeepSpeed frameworks and
supports Efficient Fine-Tuning methodologies like Low Rank Adaptation (LoRA),
Quantized LoRA (QLoRA), etc., enabling the training of language models scaling
from 300M to a whopping 130B parameters using a single server. The LMTuner's
homepage (https://wengsyx.github.io/LMTuner/)and screencast video
(https://youtu.be/nsXmWOmN3rE) are now publicly available.

---------------

### 08 Aug 2023 | [A Comparative Study of Code Generation using ChatGPT 3.5 across 10  Programming Languages](https://arxiv.org/abs/2308.04477) | [⬇️](https://arxiv.org/pdf/2308.04477)
*Alessio Buscemi* 

  Large Language Models (LLMs) are advanced Artificial Intelligence (AI)
systems that have undergone extensive training using large datasets in order to
understand and produce language that closely resembles that of humans. These
models have reached a level of proficiency where they are capable of
successfully completing university exams across several disciplines and
generating functional code to handle novel problems. This research investigates
the coding proficiency of ChatGPT 3.5, a LLM released by OpenAI in November
2022, which has gained significant recognition for its impressive text
generating and code creation capabilities. The skill of the model in creating
code snippets is evaluated across 10 various programming languages and 4
different software domains. Based on the findings derived from this research,
major unexpected behaviors and limitations of the model have been identified.
This study aims to identify potential areas for development and examine the
ramifications of automated code generation on the evolution of programming
languages and on the tech industry.

---------------

### 22 Feb 2024 | [Copilot Evaluation Harness: Evaluating LLM-Guided Software Programming](https://arxiv.org/abs/2402.14261) | [⬇️](https://arxiv.org/pdf/2402.14261)
*Anisha Agarwal, Aaron Chan, Shubham Chandel, Jinu Jang, Shaun Miller,  Roshanak Zilouchian Moghaddam, Yevhen Mohylevskyy, Neel Sundaresan, Michele  Tufano* 

  The integration of Large Language Models (LLMs) into Development Environments
(IDEs) has become a focal point in modern software development. LLMs such as
OpenAI GPT-3.5/4 and Code Llama offer the potential to significantly augment
developer productivity by serving as intelligent, chat-driven programming
assistants. However, utilizing LLMs out of the box is unlikely to be optimal
for any given scenario. Rather, each system requires the LLM to be honed to its
set of heuristics to ensure the best performance. In this paper, we introduce
the Copilot evaluation harness: a set of data and tools for evaluating
LLM-guided IDE interactions, covering various programming scenarios and
languages. We propose our metrics as a more robust and information-dense
evaluation than previous state of the art evaluation systems. We design and
compute both static and execution based success metrics for scenarios
encompassing a wide range of developer tasks, including code generation from
natural language (generate), documentation generation from code (doc), test
case generation (test), bug-fixing (fix), and workspace understanding and query
resolution (workspace). These success metrics are designed to evaluate the
performance of LLMs within a given IDE and its respective parameter space. Our
learnings from evaluating three common LLMs using these metrics can inform the
development and validation of future scenarios in LLM guided IDEs.

---------------

### 04 Feb 2024 | [Evaluating and Enhancing Large Language Models for Conversational  Reasoning on Knowledge Graphs](https://arxiv.org/abs/2312.11282) | [⬇️](https://arxiv.org/pdf/2312.11282)
*Yuxuan Huang, Lida Shi, Anqi Liu and Hao Xu* 

  The development of large language models (LLMs) has been catalyzed by
advancements in pre-training techniques. These models have demonstrated robust
reasoning capabilities through manually designed prompts. In this work, we
evaluate the conversational reasoning capabilities of the current
state-of-the-art LLM (GPT-4) on knowledge graphs (KGs). However, the
performance of LLMs is constrained due to a lack of KG environment awareness
and the difficulties in developing effective optimization mechanisms for
intermediary reasoning stages. We further introduce LLM-ARK, a LLM grounded KG
reasoning agent designed to deliver precise and adaptable predictions on KG
paths. LLM-ARK leverages Full Textual Environment (FTE) prompt to assimilate
state information within each reasoning step. We reframe the challenge of
multi-hop reasoning on the KG as a sequential decision-making task. Utilizing
the Proximal Policy Optimization (PPO) online policy gradient reinforcement
learning algorithm, our model is optimized to learn from rich reward signals.
Additionally, we conduct an evaluation of our model and GPT-4 on the OpenDialKG
dataset. The experimental results reveal that LLaMA-2-7B-ARK outperforms the
current state-of-the-art model by 5.28 percentage points, with a performance
rate of 36.39% on the target@1 evaluation metric. Meanwhile, GPT-4 scored
14.91%, further demonstrating the effectiveness of our method. Our code is
available on GitHub (https://github.com/Aipura/LLM-ARK) for further access.

---------------

### 07 Sep 2023 | [Enhancing Pipeline-Based Conversational Agents with Large Language  Models](https://arxiv.org/abs/2309.03748) | [⬇️](https://arxiv.org/pdf/2309.03748)
*Mina Foosherian, Hendrik Purwins, Purna Rathnayake, Touhidul Alam, Rui  Teimao, Klaus-Dieter Thoben* 

  The latest advancements in AI and deep learning have led to a breakthrough in
large language model (LLM)-based agents such as GPT-4. However, many commercial
conversational agent development tools are pipeline-based and have limitations
in holding a human-like conversation. This paper investigates the capabilities
of LLMs to enhance pipeline-based conversational agents during two phases: 1)
in the design and development phase and 2) during operations. In 1) LLMs can
aid in generating training data, extracting entities and synonyms,
localization, and persona design. In 2) LLMs can assist in contextualization,
intent classification to prevent conversational breakdown and handle
out-of-scope questions, auto-correcting utterances, rephrasing responses,
formulating disambiguation questions, summarization, and enabling closed
question-answering capabilities. We conducted informal experiments with GPT-4
in the private banking domain to demonstrate the scenarios above with a
practical example. Companies may be hesitant to replace their pipeline-based
agents with LLMs entirely due to privacy concerns and the need for deep
integration within their existing ecosystems. A hybrid approach in which LLMs'
are integrated into the pipeline-based agents allows them to save time and
costs of building and running agents by capitalizing on the capabilities of
LLMs while retaining the integration and privacy safeguards of their existing
systems.

---------------

### 12 Feb 2024 | [Large Language Models as Agents in Two-Player Games](https://arxiv.org/abs/2402.08078) | [⬇️](https://arxiv.org/pdf/2402.08078)
*Yang Liu, Peng Sun, Hang Li* 

  By formally defining the training processes of large language models (LLMs),
which usually encompasses pre-training, supervised fine-tuning, and
reinforcement learning with human feedback, within a single and unified machine
learning paradigm, we can glean pivotal insights for advancing LLM
technologies. This position paper delineates the parallels between the training
methods of LLMs and the strategies employed for the development of agents in
two-player games, as studied in game theory, reinforcement learning, and
multi-agent systems. We propose a re-conceptualization of LLM learning
processes in terms of agent learning in language-based games. This framework
unveils innovative perspectives on the successes and challenges in LLM
development, offering a fresh understanding of addressing alignment issues
among other strategic considerations. Furthermore, our two-player game approach
sheds light on novel data preparation and machine learning techniques for
training LLMs.

---------------

### 26 Feb 2024 | [Integrating Large Language Models with Graphical Session-Based  Recommendation](https://arxiv.org/abs/2402.16539) | [⬇️](https://arxiv.org/pdf/2402.16539)
*Naicheng Guo, Hongwei Cheng, Qianqiao Liang, Linxun Chen, Bing Han* 

  With the rapid development of Large Language Models (LLMs), various
explorations have arisen to utilize LLMs capability of context understanding on
recommender systems. While pioneering strategies have primarily transformed
traditional recommendation tasks into challenges of natural language
generation, there has been a relative scarcity of exploration in the domain of
session-based recommendation (SBR) due to its specificity. SBR has been
primarily dominated by Graph Neural Networks, which have achieved many
successful outcomes due to their ability to capture both the implicit and
explicit relationships between adjacent behaviors. The structural nature of
graphs contrasts with the essence of natural language, posing a significant
adaptation gap for LLMs. In this paper, we introduce large language models with
graphical Session-Based recommendation, named LLMGR, an effective framework
that bridges the aforementioned gap by harmoniously integrating LLMs with Graph
Neural Networks (GNNs) for SBR tasks. This integration seeks to leverage the
complementary strengths of LLMs in natural language understanding and GNNs in
relational data processing, leading to a more powerful session-based
recommender system that can understand and recommend items within a session.
Moreover, to endow the LLM with the capability to empower SBR tasks, we design
a series of prompts for both auxiliary and major instruction tuning tasks.
These prompts are crafted to assist the LLM in understanding graph-structured
data and align textual information with nodes, effectively translating nuanced
user interactions into a format that can be understood and utilized by LLM
architectures. Extensive experiments on three real-world datasets demonstrate
that LLMGR outperforms several competitive baselines, indicating its
effectiveness in enhancing SBR tasks and its potential as a research direction
for future exploration.

---------------

### 16 Sep 2023 | [Enhancing Large Language Model Induced Task-Oriented Dialogue Systems  Through Look-Forward Motivated Goals](https://arxiv.org/abs/2309.08949) | [⬇️](https://arxiv.org/pdf/2309.08949)
*Zhiyuan Hu, Yue Feng, Yang Deng, Zekun Li, See-Kiong Ng, Anh Tuan Luu,  Bryan Hooi* 

  Recently, the development of large language models (LLMs) has been
significantly enhanced the question answering and dialogue generation, and
makes them become increasingly popular in current practical scenarios. While
unlike the general dialogue system which emphasizes the semantic performance,
the task-oriented dialogue (ToD) systems aim to achieve the dialogue goal
efficiently and successfully in multiple turns. Unfortunately, existing
LLM-induced ToD systems lack the direct reward toward the final goal and do not
take account of the dialogue proactivity that can strengthen the dialogue
efficiency. To fill these gaps, we introduce the ProToD (Proactively
Goal-Driven LLM-Induced ToD) approach, which anticipates the future dialogue
actions and incorporates the goal-oriented reward signal to enhance ToD
systems. Additionally, we present a novel evaluation method that assesses ToD
systems based on goal-driven dialogue simulations. This method allows us to
gauge user satisfaction, system efficiency and successful rate while overcoming
the limitations of current Information and Success metrics. Empirical
experiments conducted on the MultiWoZ 2.1 dataset demonstrate that our model
can achieve superior performance using only 10% of the data compared to
previous end-to-end fully supervised models. This improvement is accompanied by
enhanced user satisfaction and efficiency.

---------------

### 03 Sep 2023 | [FusionAI: Decentralized Training and Deploying LLMs with Massive  Consumer-Level GPUs](https://arxiv.org/abs/2309.01172) | [⬇️](https://arxiv.org/pdf/2309.01172)
*Zhenheng Tang, Yuxin Wang, Xin He, Longteng Zhang, Xinglin Pan, Qiang  Wang, Rongfei Zeng, Kaiyong Zhao, Shaohuai Shi, Bingsheng He, Xiaowen Chu* 

  The rapid growth of memory and computation requirements of large language
models (LLMs) has outpaced the development of hardware, hindering people who
lack large-scale high-end GPUs from training or deploying LLMs. However,
consumer-level GPUs, which constitute a larger market share, are typically
overlooked in LLM due to their weaker computing performance, smaller storage
capacity, and lower communication bandwidth. Additionally, users may have
privacy concerns when interacting with remote LLMs. In this paper, we envision
a decentralized system unlocking the potential vast untapped consumer-level
GPUs in pre-training, inference and fine-tuning of LLMs with privacy
protection. However, this system faces critical challenges, including limited
CPU and GPU memory, low network bandwidth, the variability of peer and device
heterogeneity. To address these challenges, our system design incorporates: 1)
a broker with backup pool to implement dynamic join and quit of computing
providers; 2) task scheduling with hardware performance to improve system
efficiency; 3) abstracting ML procedures into directed acyclic graphs (DAGs) to
achieve model and task universality; 4) abstracting intermediate represention
and execution planes to ensure compatibility of various devices and deep
learning (DL) frameworks. Our performance analysis demonstrates that 50 RTX
3080 GPUs can achieve throughputs comparable to those of 4 H100 GPUs, which are
significantly more expensive.

---------------

### 02 Aug 2023 | [Okapi: Instruction-tuned Large Language Models in Multiple Languages  with Reinforcement Learning from Human Feedback](https://arxiv.org/abs/2307.16039) | [⬇️](https://arxiv.org/pdf/2307.16039)
*Viet Dac Lai, Chien Van Nguyen, Nghia Trung Ngo, Thuat Nguyen, Franck  Dernoncourt, Ryan A. Rossi, Thien Huu Nguyen* 

  A key technology for the development of large language models (LLMs) involves
instruction tuning that helps align the models' responses with human
expectations to realize impressive learning abilities. Two major approaches for
instruction tuning characterize supervised fine-tuning (SFT) and reinforcement
learning from human feedback (RLHF), which are currently applied to produce the
best commercial LLMs (e.g., ChatGPT). To improve the accessibility of LLMs for
research and development efforts, various instruction-tuned open-source LLMs
have also been introduced recently, e.g., Alpaca, Vicuna, to name a few.
However, existing open-source LLMs have only been instruction-tuned for English
and a few popular languages, thus hindering their impacts and accessibility to
many other languages in the world. Among a few very recent work to explore
instruction tuning for LLMs in multiple languages, SFT has been used as the
only approach to instruction-tune LLMs for multiple languages. This has left a
significant gap for fine-tuned LLMs based on RLHF in diverse languages and
raised important questions on how RLHF can boost the performance of
multilingual instruction tuning. To overcome this issue, we present Okapi, the
first system with instruction-tuned LLMs based on RLHF for multiple languages.
Okapi introduces instruction and response-ranked data in 26 diverse languages
to facilitate the experiments and development of future multilingual LLM
research. We also present benchmark datasets to enable the evaluation of
generative LLMs in multiple languages. Our experiments demonstrate the
advantages of RLHF for multilingual instruction over SFT for different base
models and datasets. Our framework and resources are released at
https://github.com/nlp-uoregon/Okapi.

---------------

### 22 Nov 2023 | [Exploring and Characterizing Large Language Models For Embedded System  Development and Debugging](https://arxiv.org/abs/2307.03817) | [⬇️](https://arxiv.org/pdf/2307.03817)
*Zachary Englhardt, Richard Li, Dilini Nissanka, Zhihan Zhang, Girish  Narayanswamy, Joseph Breda, Xin Liu, Shwetak Patel, Vikram Iyer* 

  Large language models (LLMs) have shown remarkable abilities to generate
code, however their ability to develop software for embedded systems, which
requires cross-domain knowledge of hardware and software has not been studied.
In this paper we develop an extensible, open source hardware-in-the-loop
framework to systematically evaluate leading LLMs (GPT-3.5, GPT-4, PaLM 2) to
assess their capabilities and limitations for embedded system development. We
observe through our study that even when these tools fail to produce working
code, they consistently generate helpful reasoning about embedded design tasks.
We leverage this finding to study how human programmers interact with these
tools, and develop an human-AI based software engineering workflow for building
embedded systems.
  Our evaluation platform for verifying LLM generated programs uses sensor
actuator pairs for physical evaluation. We compare all three models with N=450
experiments and find surprisingly that GPT-4 especially shows an exceptional
level of cross-domain understanding and reasoning, in some cases generating
fully correct programs from a single prompt. In N=50 trials, GPT-4 produces
functional I2C interfaces 66% of the time. GPT-4 also produces register-level
drivers, code for LoRa communication, and context-specific power optimizations
for an nRF52 program resulting in over 740x current reduction to 12.2uA. We
also characterize the models' limitations to develop a generalizable human-AI
workflow for using LLMs in embedded system development. We evaluate our
workflow with 15 users including novice and expert programmers. We find that
our workflow improves productivity for all users and increases the success rate
for building a LoRa environmental sensor from 25% to 100%, including for users
with zero hardware or C/C++ experience.

---------------

### 12 Oct 2023 | [GameGPT: Multi-agent Collaborative Framework for Game Development](https://arxiv.org/abs/2310.08067) | [⬇️](https://arxiv.org/pdf/2310.08067)
*Dake Chen, Hanbin Wang, Yunhao Huo, Yuzhao Li, Haoyang Zhang* 

  The large language model (LLM) based agents have demonstrated their capacity
to automate and expedite software development processes. In this paper, we
focus on game development and propose a multi-agent collaborative framework,
dubbed GameGPT, to automate game development. While many studies have
pinpointed hallucination as a primary roadblock for deploying LLMs in
production, we identify another concern: redundancy. Our framework presents a
series of methods to mitigate both concerns. These methods include dual
collaboration and layered approaches with several in-house lexicons, to
mitigate the hallucination and redundancy in the planning, task identification,
and implementation phases. Furthermore, a decoupling approach is also
introduced to achieve code generation with better precision.

---------------

### 25 May 2023 | [BookGPT: A General Framework for Book Recommendation Empowered by Large  Language Model](https://arxiv.org/abs/2305.15673) | [⬇️](https://arxiv.org/pdf/2305.15673)
*Aakas Zhiyuli, Yanfang Chen, Xuan Zhang, Xun Liang* 

  With the continuous development and change exhibited by large language model
(LLM) technology, represented by generative pretrained transformers (GPTs),
many classic scenarios in various fields have re-emerged with new
opportunities. This paper takes ChatGPT as the modeling object, incorporates
LLM technology into the typical book resource understanding and recommendation
scenario for the first time, and puts it into practice. By building a
ChatGPT-like book recommendation system (BookGPT) framework based on ChatGPT,
this paper attempts to apply ChatGPT to recommendation modeling for three
typical tasks, book rating recommendation, user rating recommendation, and book
summary recommendation, and explores the feasibility of LLM technology in book
recommendation scenarios. At the same time, based on different evaluation
schemes for book recommendation tasks and the existing classic recommendation
models, this paper discusses the advantages and disadvantages of the BookGPT in
book recommendation scenarios and analyzes the opportunities and improvement
directions for subsequent LLMs in these scenarios.

---------------

### 09 Feb 2024 | [Understanding the Effects of Iterative Prompting on Truthfulness](https://arxiv.org/abs/2402.06625) | [⬇️](https://arxiv.org/pdf/2402.06625)
*Satyapriya Krishna, Chirag Agarwal, Himabindu Lakkaraju* 

  The development of Large Language Models (LLMs) has notably transformed
numerous sectors, offering impressive text generation capabilities. Yet, the
reliability and truthfulness of these models remain pressing concerns. To this
end, we investigate iterative prompting, a strategy hypothesized to refine LLM
responses, assessing its impact on LLM truthfulness, an area which has not been
thoroughly explored. Our extensive experiments delve into the intricacies of
iterative prompting variants, examining their influence on the accuracy and
calibration of model responses. Our findings reveal that naive prompting
methods significantly undermine truthfulness, leading to exacerbated
calibration errors. In response to these challenges, we introduce several
prompting variants designed to address the identified issues. These variants
demonstrate marked improvements over existing baselines, signaling a promising
direction for future research. Our work provides a nuanced understanding of
iterative prompting and introduces novel approaches to enhance the truthfulness
of LLMs, thereby contributing to the development of more accurate and
trustworthy AI systems.

---------------

### 12 Dec 2023 | [Leveraging Large Language Models to Build and Execute Computational  Workflows](https://arxiv.org/abs/2312.07711) | [⬇️](https://arxiv.org/pdf/2312.07711)
*Alejandro Duque, Abdullah Syed, Kastan V. Day, Matthew J. Berry,  Daniel S. Katz, Volodymyr V. Kindratenko* 

  The recent development of large language models (LLMs) with multi-billion
parameters, coupled with the creation of user-friendly application programming
interfaces (APIs), has paved the way for automatically generating and executing
code in response to straightforward human queries. This paper explores how
these emerging capabilities can be harnessed to facilitate complex scientific
workflows, eliminating the need for traditional coding methods. We present
initial findings from our attempt to integrate Phyloflow with OpenAI's
function-calling API, and outline a strategy for developing a comprehensive
workflow management system based on these concepts.

---------------

### 28 Jan 2024 | [LLM4SecHW: Leveraging Domain Specific Large Language Model for Hardware  Debugging](https://arxiv.org/abs/2401.16448) | [⬇️](https://arxiv.org/pdf/2401.16448)
*Weimin Fu, Kaichen Yang, Raj Gautam Dutta, Xiaolong Guo, Gang Qu* 

  This paper presents LLM4SecHW, a novel framework for hardware debugging that
leverages domain specific Large Language Model (LLM). Despite the success of
LLMs in automating various software development tasks, their application in the
hardware security domain has been limited due to the constraints of commercial
LLMs and the scarcity of domain specific data. To address these challenges, we
propose a unique approach to compile a dataset of open source hardware design
defects and their remediation steps, utilizing version control data. This
dataset provides a substantial foundation for training machine learning models
for hardware. LLM4SecHW employs fine tuning of medium sized LLMs based on this
dataset, enabling the identification and rectification of bugs in hardware
designs. This pioneering approach offers a reference workflow for the
application of fine tuning domain specific LLMs in other research areas. We
evaluate the performance of our proposed system on various open source hardware
designs, demonstrating its efficacy in accurately identifying and correcting
defects. Our work brings a new perspective on automating the quality control
process in hardware design.

---------------

### 31 Dec 2023 | [Viz: A QLoRA-based Copyright Marketplace for Legally Compliant  Generative AI](https://arxiv.org/abs/2401.00503) | [⬇️](https://arxiv.org/pdf/2401.00503)
*Dipankar Sarkar* 

  This paper aims to introduce and analyze the Viz system in a comprehensive
way, a novel system architecture that integrates Quantized Low-Rank Adapters
(QLoRA) to fine-tune large language models (LLM) within a legally compliant and
resource efficient marketplace. Viz represents a significant contribution to
the field of artificial intelligence, particularly in addressing the challenges
of computational efficiency, legal compliance, and economic sustainability in
the utilization and monetization of LLMs. The paper delineates the scholarly
discourse and developments that have informed the creation of Viz, focusing
primarily on the advancements in LLM models, copyright issues in AI training
(NYT case, 2023), and the evolution of model fine-tuning techniques,
particularly low-rank adapters and quantized low-rank adapters, to create a
sustainable and economically compliant framework for LLM utilization. The
economic model it proposes benefits content creators, AI developers, and
end-users, delineating a harmonious integration of technology, economy, and
law, offering a comprehensive solution to the complex challenges of today's AI
landscape.

---------------

### 12 Jun 2023 | [LLM as A Robotic Brain: Unifying Egocentric Memory and Control](https://arxiv.org/abs/2304.09349) | [⬇️](https://arxiv.org/pdf/2304.09349)
*Jinjie Mai, Jun Chen, Bing Li, Guocheng Qian, Mohamed Elhoseiny,  Bernard Ghanem* 

  Embodied AI focuses on the study and development of intelligent systems that
possess a physical or virtual embodiment (i.e. robots) and are able to
dynamically interact with their environment. Memory and control are the two
essential parts of an embodied system and usually require separate frameworks
to model each of them. In this paper, we propose a novel and generalizable
framework called LLM-Brain: using Large-scale Language Model as a robotic brain
to unify egocentric memory and control. The LLM-Brain framework integrates
multiple multimodal language models for robotic tasks, utilizing a zero-shot
learning approach. All components within LLM-Brain communicate using natural
language in closed-loop multi-round dialogues that encompass perception,
planning, control, and memory. The core of the system is an embodied LLM to
maintain egocentric memory and control the robot. We demonstrate LLM-Brain by
examining two downstream tasks: active exploration and embodied question
answering. The active exploration tasks require the robot to extensively
explore an unknown environment within a limited number of actions. Meanwhile,
the embodied question answering tasks necessitate that the robot answers
questions based on observations acquired during prior explorations.

---------------
**Date:** 12 Sep 2023

**Title:** Do Generative Large Language Models need billions of parameters?

**Abstract Link:** [https://arxiv.org/abs/2309.06589](https://arxiv.org/abs/2309.06589)

**PDF Link:** [https://arxiv.org/pdf/2309.06589](https://arxiv.org/pdf/2309.06589)

---

**Date:** 13 Dec 2023

**Title:** Large Language Model Enhanced Multi-Agent Systems for 6G Communications

**Abstract Link:** [https://arxiv.org/abs/2312.07850](https://arxiv.org/abs/2312.07850)

**PDF Link:** [https://arxiv.org/pdf/2312.07850](https://arxiv.org/pdf/2312.07850)

---

**Date:** 20 Aug 2023

**Title:** LMTuner: An user-friendly and highly-integrable Training Framework for  fine-tuning Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2308.10252](https://arxiv.org/abs/2308.10252)

**PDF Link:** [https://arxiv.org/pdf/2308.10252](https://arxiv.org/pdf/2308.10252)

---

**Date:** 08 Aug 2023

**Title:** A Comparative Study of Code Generation using ChatGPT 3.5 across 10  Programming Languages

**Abstract Link:** [https://arxiv.org/abs/2308.04477](https://arxiv.org/abs/2308.04477)

**PDF Link:** [https://arxiv.org/pdf/2308.04477](https://arxiv.org/pdf/2308.04477)

---

**Date:** 22 Feb 2024

**Title:** Copilot Evaluation Harness: Evaluating LLM-Guided Software Programming

**Abstract Link:** [https://arxiv.org/abs/2402.14261](https://arxiv.org/abs/2402.14261)

**PDF Link:** [https://arxiv.org/pdf/2402.14261](https://arxiv.org/pdf/2402.14261)

---

**Date:** 04 Feb 2024

**Title:** Evaluating and Enhancing Large Language Models for Conversational  Reasoning on Knowledge Graphs

**Abstract Link:** [https://arxiv.org/abs/2312.11282](https://arxiv.org/abs/2312.11282)

**PDF Link:** [https://arxiv.org/pdf/2312.11282](https://arxiv.org/pdf/2312.11282)

---

**Date:** 07 Sep 2023

**Title:** Enhancing Pipeline-Based Conversational Agents with Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2309.03748](https://arxiv.org/abs/2309.03748)

**PDF Link:** [https://arxiv.org/pdf/2309.03748](https://arxiv.org/pdf/2309.03748)

---

**Date:** 12 Feb 2024

**Title:** Large Language Models as Agents in Two-Player Games

**Abstract Link:** [https://arxiv.org/abs/2402.08078](https://arxiv.org/abs/2402.08078)

**PDF Link:** [https://arxiv.org/pdf/2402.08078](https://arxiv.org/pdf/2402.08078)

---

**Date:** 26 Feb 2024

**Title:** Integrating Large Language Models with Graphical Session-Based  Recommendation

**Abstract Link:** [https://arxiv.org/abs/2402.16539](https://arxiv.org/abs/2402.16539)

**PDF Link:** [https://arxiv.org/pdf/2402.16539](https://arxiv.org/pdf/2402.16539)

---

**Date:** 16 Sep 2023

**Title:** Enhancing Large Language Model Induced Task-Oriented Dialogue Systems  Through Look-Forward Motivated Goals

**Abstract Link:** [https://arxiv.org/abs/2309.08949](https://arxiv.org/abs/2309.08949)

**PDF Link:** [https://arxiv.org/pdf/2309.08949](https://arxiv.org/pdf/2309.08949)

---

**Date:** 03 Sep 2023

**Title:** FusionAI: Decentralized Training and Deploying LLMs with Massive  Consumer-Level GPUs

**Abstract Link:** [https://arxiv.org/abs/2309.01172](https://arxiv.org/abs/2309.01172)

**PDF Link:** [https://arxiv.org/pdf/2309.01172](https://arxiv.org/pdf/2309.01172)

---

**Date:** 02 Aug 2023

**Title:** Okapi: Instruction-tuned Large Language Models in Multiple Languages  with Reinforcement Learning from Human Feedback

**Abstract Link:** [https://arxiv.org/abs/2307.16039](https://arxiv.org/abs/2307.16039)

**PDF Link:** [https://arxiv.org/pdf/2307.16039](https://arxiv.org/pdf/2307.16039)

---

**Date:** 22 Nov 2023

**Title:** Exploring and Characterizing Large Language Models For Embedded System  Development and Debugging

**Abstract Link:** [https://arxiv.org/abs/2307.03817](https://arxiv.org/abs/2307.03817)

**PDF Link:** [https://arxiv.org/pdf/2307.03817](https://arxiv.org/pdf/2307.03817)

---

**Date:** 12 Oct 2023

**Title:** GameGPT: Multi-agent Collaborative Framework for Game Development

**Abstract Link:** [https://arxiv.org/abs/2310.08067](https://arxiv.org/abs/2310.08067)

**PDF Link:** [https://arxiv.org/pdf/2310.08067](https://arxiv.org/pdf/2310.08067)

---

**Date:** 25 May 2023

**Title:** BookGPT: A General Framework for Book Recommendation Empowered by Large  Language Model

**Abstract Link:** [https://arxiv.org/abs/2305.15673](https://arxiv.org/abs/2305.15673)

**PDF Link:** [https://arxiv.org/pdf/2305.15673](https://arxiv.org/pdf/2305.15673)

---

**Date:** 09 Feb 2024

**Title:** Understanding the Effects of Iterative Prompting on Truthfulness

**Abstract Link:** [https://arxiv.org/abs/2402.06625](https://arxiv.org/abs/2402.06625)

**PDF Link:** [https://arxiv.org/pdf/2402.06625](https://arxiv.org/pdf/2402.06625)

---

**Date:** 12 Dec 2023

**Title:** Leveraging Large Language Models to Build and Execute Computational  Workflows

**Abstract Link:** [https://arxiv.org/abs/2312.07711](https://arxiv.org/abs/2312.07711)

**PDF Link:** [https://arxiv.org/pdf/2312.07711](https://arxiv.org/pdf/2312.07711)

---

**Date:** 28 Jan 2024

**Title:** LLM4SecHW: Leveraging Domain Specific Large Language Model for Hardware  Debugging

**Abstract Link:** [https://arxiv.org/abs/2401.16448](https://arxiv.org/abs/2401.16448)

**PDF Link:** [https://arxiv.org/pdf/2401.16448](https://arxiv.org/pdf/2401.16448)

---

**Date:** 31 Dec 2023

**Title:** Viz: A QLoRA-based Copyright Marketplace for Legally Compliant  Generative AI

**Abstract Link:** [https://arxiv.org/abs/2401.00503](https://arxiv.org/abs/2401.00503)

**PDF Link:** [https://arxiv.org/pdf/2401.00503](https://arxiv.org/pdf/2401.00503)

---

**Date:** 12 Jun 2023

**Title:** LLM as A Robotic Brain: Unifying Egocentric Memory and Control

**Abstract Link:** [https://arxiv.org/abs/2304.09349](https://arxiv.org/abs/2304.09349)

**PDF Link:** [https://arxiv.org/pdf/2304.09349](https://arxiv.org/pdf/2304.09349)

---

