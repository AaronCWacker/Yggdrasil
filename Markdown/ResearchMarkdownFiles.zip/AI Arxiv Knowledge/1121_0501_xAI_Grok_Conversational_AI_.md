xAI: Grok Conversational AI 🤖

### 🔎 xAI: Grok Conversational AI 🤖


=============================

[![Build Status](https://travis-ci.org/IBM/xai-conversational-ai.svg?branch=master)](https://travis-ci.org/IBM/xai-conversational-ai)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](http://makeapullrequest.com)

This project is part of the [IBM xAI](https://developer.ibm.com/xai/) initiative.

This project is a collection of tools and techniques to help you understand and explain conversational AI systems.

## Table of Contents

- [Table of Contents](#table-of-contents)
- [Getting Started](#getting-started)
  - [Prerequisites](#prerequisites)
  - [Installing](#installing)
  - [Running](#running)
- [Contributing](#contributing)
- [License](#license)
- [Contact](#contact)

## Getting Started

### Prerequisites

- [Python 3.6+](https://www.python.org/downloads/)
- [Docker](https://www.docker.com/community-edition)
- [Docker Compose](https://docs.docker.com/compose/install/)

### Installing

1. Clone the repository

```bash
git clone https://github.com/IBM/xai-conversational-ai.git
cd xai-conversational-ai
```

2. Create a virtual environment

```bash
python3 -m venv venv
source venv/bin/activate
```

3. Install the dependencies

```bash
pip install -r requirements.txt
```

4. Start the services

```bash
docker
# 🩺🔍 Search Results
### 28 Aug 2023 | [Explaining Machine Learning Models in Natural Conversations: Towards a  Conversational XAI Agent](https://arxiv.org/abs/2209.02552) | [⬇️](https://arxiv.org/pdf/2209.02552)
*Van Bach Nguyen, J\"org Schl\"otterer, Christin Seifert* 

  The goal of Explainable AI (XAI) is to design methods to provide insights
into the reasoning process of black-box models, such as deep neural networks,
in order to explain them to humans. Social science research states that such
explanations should be conversational, similar to human-to-human explanations.
In this work, we show how to incorporate XAI in a conversational agent, using a
standard design for the agent comprising natural language understanding and
generation components. We build upon an XAI question bank which we extend by
quality-controlled paraphrases to understand the user's information needs. We
further systematically survey the literature for suitable explanation methods
that provide the information to answer those questions, and present a
comprehensive list of suggestions. Our work is the first step towards truly
natural conversations about machine learning models with an explanation agent.
The comprehensive list of XAI questions and the corresponding explanation
methods may support other researchers in providing the necessary information to
address users' demands.

---------------

### 25 Sep 2023 | [May I Ask a Follow-up Question? Understanding the Benefits of  Conversations in Neural Network Explainability](https://arxiv.org/abs/2309.13965) | [⬇️](https://arxiv.org/pdf/2309.13965)
*Tong Zhang, X. Jessie Yang, Boyang Li* 

  Research in explainable AI (XAI) aims to provide insights into the
decision-making process of opaque AI models. To date, most XAI methods offer
one-off and static explanations, which cannot cater to the diverse backgrounds
and understanding levels of users. With this paper, we investigate if free-form
conversations can enhance users' comprehension of static explanations, improve
acceptance and trust in the explanation methods, and facilitate human-AI
collaboration. Participants are presented with static explanations, followed by
a conversation with a human expert regarding the explanations. We measure the
effect of the conversation on participants' ability to choose, from three
machine learning models, the most accurate one based on explanations and their
self-reported comprehension, acceptance, and trust. Empirical results show that
conversations significantly improve comprehension, acceptance, trust, and
collaboration. Our findings highlight the importance of customized model
explanations in the format of free-form conversations and provide insights for
the future design of conversational explanations.

---------------

### 27 Oct 2023 | [ConvXAI: Delivering Heterogeneous AI Explanations via Conversations to  Support Human-AI Scientific Writing](https://arxiv.org/abs/2305.09770) | [⬇️](https://arxiv.org/pdf/2305.09770)
*Hua Shen, Chieh-Yang Huang, Tongshuang Wu, Ting-Hao 'Kenneth' Huang* 

  Despite a surge collection of XAI methods, users still struggle to obtain
required AI explanations. Previous research suggests chatbots as dynamic
solutions, but the effective design of conversational XAI agents for practical
human needs remains under-explored. This paper focuses on Conversational XAI
for AI-assisted scientific writing tasks. Drawing from human linguistic
theories and formative studies, we identify four design rationales:
"multifaceted", "controllability", "mix-initiative", "context-aware
drill-down". We incorporate them into an interactive prototype, ConvXAI, which
facilitates heterogeneous AI explanations for scientific writing through
dialogue. In two studies with 21 users, ConvXAI outperforms a GUI-based
baseline on improving human-perceived understanding and writing improvement.
The paper further discusses the practical human usage patterns in interacting
with ConvXAI for scientific co-writing.

---------------

### 12 Jul 2021 | [Explainable AI: current status and future directions](https://arxiv.org/abs/2107.07045) | [⬇️](https://arxiv.org/pdf/2107.07045)
*Prashant Gohel, Priyanka Singh and Manoranjan Mohanty* 

  Explainable Artificial Intelligence (XAI) is an emerging area of research in
the field of Artificial Intelligence (AI). XAI can explain how AI obtained a
particular solution (e.g., classification or object detection) and can also
answer other "wh" questions. This explainability is not possible in traditional
AI. Explainability is essential for critical applications, such as defense,
health care, law and order, and autonomous driving vehicles, etc, where the
know-how is required for trust and transparency. A number of XAI techniques so
far have been purposed for such applications. This paper provides an overview
of these techniques from a multimedia (i.e., text, image, audio, and video)
point of view. The advantages and shortcomings of these techniques have been
discussed, and pointers to some future directions have also been provided.

---------------

### 04 Nov 2021 | [Characterizing Human Explanation Strategies to Inform the Design of  Explainable AI for Building Damage Assessment](https://arxiv.org/abs/2111.02626) | [⬇️](https://arxiv.org/pdf/2111.02626)
*Donghoon Shin, Sachin Grover, Kenneth Holstein, Adam Perer* 

  Explainable AI (XAI) is a promising means of supporting human-AI
collaborations for high-stakes visual detection tasks, such as damage detection
tasks from satellite imageries, as fully-automated approaches are unlikely to
be perfectly safe and reliable. However, most existing XAI techniques are not
informed by the understandings of task-specific needs of humans for
explanations. Thus, we took a first step toward understanding what forms of XAI
humans require in damage detection tasks. We conducted an online crowdsourced
study to understand how people explain their own assessments, when evaluating
the severity of building damage based on satellite imagery. Through the study
with 60 crowdworkers, we surfaced six major strategies that humans utilize to
explain their visual damage assessments. We present implications of our
findings for the design of XAI methods for such visual detection contexts, and
discuss opportunities for future research.

---------------

### 25 Nov 2023 | [Trainable Noise Model as an XAI evaluation method: application on Sobol  for remote sensing image segmentation](https://arxiv.org/abs/2310.01828) | [⬇️](https://arxiv.org/pdf/2310.01828)
*Hossein Shreim, Abdul Karim Gizzini and Ali J. Ghandour* 

  eXplainable Artificial Intelligence (XAI) has emerged as an essential
requirement when dealing with mission-critical applications, ensuring
transparency and interpretability of the employed black box AI models. The
significance of XAI spans various domains, from healthcare to finance, where
understanding the decision-making process of deep learning algorithms is
essential. Most AI-based computer vision models are often black boxes; hence,
providing explainability of deep neural networks in image processing is crucial
for their wide adoption and deployment in medical image analysis, autonomous
driving, and remote sensing applications. Recently, several XAI methods for
image classification tasks have been introduced. On the contrary, image
segmentation has received comparatively less attention in the context of
explainability, although it is a fundamental task in computer vision
applications, especially in remote sensing. Only some research proposes
gradient-based XAI algorithms for image segmentation. This paper adapts the
recent gradient-free Sobol XAI method for semantic segmentation. To measure the
performance of the Sobol method for segmentation, we propose a quantitative XAI
evaluation method based on a learnable noise model. The main objective of this
model is to induce noise on the explanation maps, where higher induced noise
signifies low accuracy and vice versa. A benchmark analysis is conducted to
evaluate and compare performance of three XAI methods, including Seg-Grad-CAM,
Seg-Grad-CAM++ and Seg-Sobol using the proposed noise-based evaluation
technique. This constitutes the first attempt to run and evaluate XAI methods
using high-resolution satellite images.

---------------

### 03 Feb 2021 | [Unbox the Black-box for the Medical Explainable AI via Multi-modal and  Multi-centre Data Fusion: A Mini-Review, Two Showcases and Beyond](https://arxiv.org/abs/2102.01998) | [⬇️](https://arxiv.org/pdf/2102.01998)
*Guang Yang, Qinghao Ye, Jun Xia* 

  Explainable Artificial Intelligence (XAI) is an emerging research topic of
machine learning aimed at unboxing how AI systems' black-box choices are made.
This research field inspects the measures and models involved in
decision-making and seeks solutions to explain them explicitly. Many of the
machine learning algorithms can not manifest how and why a decision has been
cast. This is particularly true of the most popular deep neural network
approaches currently in use. Consequently, our confidence in AI systems can be
hindered by the lack of explainability in these black-box models. The XAI
becomes more and more crucial for deep learning powered applications,
especially for medical and healthcare studies, although in general these deep
neural networks can return an arresting dividend in performance. The
insufficient explainability and transparency in most existing AI systems can be
one of the major reasons that successful implementation and integration of AI
tools into routine clinical practice are uncommon. In this study, we first
surveyed the current progress of XAI and in particular its advances in
healthcare applications. We then introduced our solutions for XAI leveraging
multi-modal and multi-centre data fusion, and subsequently validated in two
showcases following real clinical scenarios. Comprehensive quantitative and
qualitative analyses can prove the efficacy of our proposed XAI solutions, from
which we can envisage successful applications in a broader range of clinical
questions.

---------------

### 08 Nov 2021 | [Counterfactual Explanations as Interventions in Latent Space](https://arxiv.org/abs/2106.07754) | [⬇️](https://arxiv.org/pdf/2106.07754)
*Riccardo Crupi, Alessandro Castelnovo, Daniele Regoli, Beatriz San  Miguel Gonzalez* 

  Explainable Artificial Intelligence (XAI) is a set of techniques that allows
the understanding of both technical and non-technical aspects of Artificial
Intelligence (AI) systems. XAI is crucial to help satisfying the increasingly
important demand of \emph{trustworthy} Artificial Intelligence, characterized
by fundamental characteristics such as respect of human autonomy, prevention of
harm, transparency, accountability, etc. Within XAI techniques, counterfactual
explanations aim to provide to end users a set of features (and their
corresponding values) that need to be changed in order to achieve a desired
outcome. Current approaches rarely take into account the feasibility of actions
needed to achieve the proposed explanations, and in particular they fall short
of considering the causal impact of such actions. In this paper, we present
Counterfactual Explanations as Interventions in Latent Space (CEILS), a
methodology to generate counterfactual explanations capturing by design the
underlying causal relations from the data, and at the same time to provide
feasible recommendations to reach the proposed profile. Moreover, our
methodology has the advantage that it can be set on top of existing
counterfactuals generator algorithms, thus minimising the complexity of
imposing additional causal constrains. We demonstrate the effectiveness of our
approach with a set of different experiments using synthetic and real datasets
(including a proprietary dataset of the financial domain).

---------------

### 01 Aug 2023 | [Explaining and visualizing black-box models through counterfactual paths](https://arxiv.org/abs/2307.07764) | [⬇️](https://arxiv.org/pdf/2307.07764)
*Bastian Pfeifer, Mateusz Krzyzinski, Hubert Baniecki, Anna Saranti,  Andreas Holzinger, Przemyslaw Biecek* 

  Explainable AI (XAI) is an increasingly important area of machine learning
research, which aims to make black-box models transparent and interpretable. In
this paper, we propose a novel approach to XAI that uses the so-called
counterfactual paths generated by conditional permutations of features. The
algorithm measures feature importance by identifying sequential permutations of
features that most influence changes in model predictions. It is particularly
suitable for generating explanations based on counterfactual paths in knowledge
graphs incorporating domain knowledge. Counterfactual paths introduce an
additional graph dimension to current XAI methods in both explaining and
visualizing black-box models. Experiments with synthetic and medical data
demonstrate the practical applicability of our approach.

---------------

### 14 Oct 2023 | [Scene Text Recognition Models Explainability Using Local Features](https://arxiv.org/abs/2310.09549) | [⬇️](https://arxiv.org/pdf/2310.09549)
*Mark Vincent Ty, Rowel Atienza* 

  Explainable AI (XAI) is the study on how humans can be able to understand the
cause of a model's prediction. In this work, the problem of interest is Scene
Text Recognition (STR) Explainability, using XAI to understand the cause of an
STR model's prediction. Recent XAI literatures on STR only provide a simple
analysis and do not fully explore other XAI methods. In this study, we
specifically work on data explainability frameworks, called attribution-based
methods, that explain the important parts of an input data in deep learning
models. However, integrating them into STR produces inconsistent and
ineffective explanations, because they only explain the model in the global
context. To solve this problem, we propose a new method, STRExp, to take into
consideration the local explanations, i.e. the individual character prediction
explanations. This is then benchmarked across different attribution-based
methods on different STR datasets and evaluated across different STR models.

---------------

### 15 Feb 2021 | [Ada-SISE: Adaptive Semantic Input Sampling for Efficient Explanation of  Convolutional Neural Networks](https://arxiv.org/abs/2102.07799) | [⬇️](https://arxiv.org/pdf/2102.07799)
*Mahesh Sudhakar, Sam Sattarzadeh, Konstantinos N. Plataniotis,  Jongseong Jang, Yeonjeong Jeong, Hyunwoo Kim* 

  Explainable AI (XAI) is an active research area to interpret a neural
network's decision by ensuring transparency and trust in the task-specified
learned models. Recently, perturbation-based model analysis has shown better
interpretation, but backpropagation techniques are still prevailing because of
their computational efficiency. In this work, we combine both approaches as a
hybrid visual explanation algorithm and propose an efficient interpretation
method for convolutional neural networks. Our method adaptively selects the
most critical features that mainly contribute towards a prediction to probe the
model by finding the activated features. Experimental results show that the
proposed method can reduce the execution time up to 30% while enhancing
competitive interpretability without compromising the quality of explanation
generated.

---------------

### 17 May 2023 | [Explain Any Concept: Segment Anything Meets Concept-Based Explanation](https://arxiv.org/abs/2305.10289) | [⬇️](https://arxiv.org/pdf/2305.10289)
*Ao Sun, Pingchuan Ma, Yuanyuan Yuan, Shuai Wang* 

  EXplainable AI (XAI) is an essential topic to improve human understanding of
deep neural networks (DNNs) given their black-box internals. For computer
vision tasks, mainstream pixel-based XAI methods explain DNN decisions by
identifying important pixels, and emerging concept-based XAI explore forming
explanations with concepts (e.g., a head in an image). However, pixels are
generally hard to interpret and sensitive to the imprecision of XAI methods,
whereas "concepts" in prior works require human annotation or are limited to
pre-defined concept sets. On the other hand, driven by large-scale
pre-training, Segment Anything Model (SAM) has been demonstrated as a powerful
and promotable framework for performing precise and comprehensive instance
segmentation, enabling automatic preparation of concept sets from a given
image. This paper for the first time explores using SAM to augment
concept-based XAI. We offer an effective and flexible concept-based explanation
method, namely Explain Any Concept (EAC), which explains DNN decisions with any
concept. While SAM is highly effective and offers an "out-of-the-box" instance
segmentation, it is costly when being integrated into defacto XAI pipelines. We
thus propose a lightweight per-input equivalent (PIE) scheme, enabling
efficient explanation with a surrogate model. Our evaluation over two popular
datasets (ImageNet and COCO) illustrate the highly encouraging performance of
EAC over commonly-used XAI methods.

---------------

### 08 Feb 2022 | [Towards a Shapley Value Graph Framework for Medical peer-influence](https://arxiv.org/abs/2112.14624) | [⬇️](https://arxiv.org/pdf/2112.14624)
*Jamie Duell, Monika Seisenberger, Gert Aarts, Shangming Zhou and Xiuyi  Fan* 

  eXplainable Artificial Intelligence (XAI) is a sub-field of Artificial
Intelligence (AI) that is at the forefront of AI research. In XAI, feature
attribution methods produce explanations in the form of feature importance.
People often use feature importance as guidance for intervention. However, a
limitation of existing feature attribution methods is that there is a lack of
explanation towards the consequence of intervention. In other words, although
contribution towards a certain prediction is highlighted by feature attribution
methods, the relation between features and the consequence of intervention is
not studied. The aim of this paper is to introduce a new framework, called a
peer influence framework to look deeper into explanations using graph
representation for feature-to-feature interactions to improve the
interpretability of black-box Machine Learning models and inform intervention.

---------------

### 07 Nov 2023 | [Extracting human interpretable structure-property relationships in  chemistry using XAI and large language models](https://arxiv.org/abs/2311.04047) | [⬇️](https://arxiv.org/pdf/2311.04047)
*Geemi P. Wellawatte and Philippe Schwaller* 

  Explainable Artificial Intelligence (XAI) is an emerging field in AI that
aims to address the opaque nature of machine learning models. Furthermore, it
has been shown that XAI can be used to extract input-output relationships,
making them a useful tool in chemistry to understand structure-property
relationships. However, one of the main limitations of XAI methods is that they
are developed for technically oriented users. We propose the XpertAI framework
that integrates XAI methods with large language models (LLMs) accessing
scientific literature to generate accessible natural language explanations of
raw chemical data automatically. We conducted 5 case studies to evaluate the
performance of XpertAI. Our results show that XpertAI combines the strengths of
LLMs and XAI tools in generating specific, scientific, and interpretable
explanations.

---------------

### 07 Jul 2021 | [Levels of explainable artificial intelligence for human-aligned  conversational explanations](https://arxiv.org/abs/2107.03178) | [⬇️](https://arxiv.org/pdf/2107.03178)
*Richard Dazeley, Peter Vamplew, Cameron Foale, Charlotte Young, Sunil  Aryal, Francisco Cruz* 

  Over the last few years there has been rapid research growth into eXplainable
Artificial Intelligence (XAI) and the closely aligned Interpretable Machine
Learning (IML). Drivers for this growth include recent legislative changes and
increased investments by industry and governments, along with increased concern
from the general public. People are affected by autonomous decisions every day
and the public need to understand the decision-making process to accept the
outcomes. However, the vast majority of the applications of XAI/IML are focused
on providing low-level `narrow' explanations of how an individual decision was
reached based on a particular datum. While important, these explanations rarely
provide insights into an agent's: beliefs and motivations; hypotheses of other
(human, animal or AI) agents' intentions; interpretation of external cultural
expectations; or, processes used to generate its own explanation. Yet all of
these factors, we propose, are essential to providing the explanatory depth
that people require to accept and trust the AI's decision-making. This paper
aims to define levels of explanation and describe how they can be integrated to
create a human-aligned conversational explanation system. In so doing, this
paper will survey current approaches and discuss the integration of different
technologies to achieve these levels with Broad eXplainable Artificial
Intelligence (Broad-XAI), and thereby move towards high-level `strong'
explanations.

---------------

### 26 Jan 2022 | [SCAI-QReCC Shared Task on Conversational Question Answering](https://arxiv.org/abs/2201.11094) | [⬇️](https://arxiv.org/pdf/2201.11094)
*Svitlana Vakulenko, Johannes Kiesel, Maik Fr\"obe* 

  Search-Oriented Conversational AI (SCAI) is an established venue that
regularly puts a spotlight upon the recent work advancing the field of
conversational search. SCAI'21 was organised as an independent on-line event
and featured a shared task on conversational question answering. Since all of
the participant teams experimented with answer generation models for this task,
we identified evaluation of answer correctness in this settings as the major
challenge and a current research gap. Alongside the automatic evaluation, we
conducted two crowdsourcing experiments to collect annotations for answer
plausibility and faithfulness. As a result of this shared task, the original
conversational QA dataset used for evaluation was further extended with
alternative correct answers produced by the participant systems.

---------------

### 08 Mar 2021 | [A Comparative Approach to Explainable Artificial Intelligence Methods in  Application to High-Dimensional Electronic Health Records: Examining the  Usability of XAI](https://arxiv.org/abs/2103.04951) | [⬇️](https://arxiv.org/pdf/2103.04951)
*Jamie Andrew Duell* 

  Explainable Artificial Intelligence (XAI) is a rising field in AI. It aims to
produce a demonstrative factor of trust, which for human subjects is achieved
through communicative means, which Machine Learning (ML) algorithms cannot
solely produce, illustrating the necessity of an extra layer producing support
to the model output. When approaching the medical field, we can see challenges
arise when dealing with the involvement of human-subjects, the ideology behind
trusting a machine to tend towards the livelihood of a human poses an ethical
conundrum - leaving trust as the basis of the human-expert in acceptance to the
machines decision. The aim of this paper is to apply XAI methods to demonstrate
the usability of explainable architectures as a tertiary layer for the medical
domain supporting ML predictions and human-expert opinion, XAI methods produce
visualization of the feature contribution towards a given models output on both
a local and global level. The work in this paper uses XAI to determine feature
importance towards high-dimensional data-driven questions to inform
domain-experts of identifiable trends with a comparison of model-agnostic
methods in application to ML algorithms. The performance metrics for a
glass-box method is also provided as a comparison against black-box capability
for tabular data. Future work will aim to produce a user-study using metrics to
evaluate human-expert usability and opinion of the given models.

---------------

### 05 Feb 2024 | [SIDU-TXT: An XAI Algorithm for NLP with a Holistic Assessment Approach](https://arxiv.org/abs/2402.03043) | [⬇️](https://arxiv.org/pdf/2402.03043)
*Mohammad N.S. Jahromi, Satya. M. Muddamsetty, Asta Sofie Stage  Jarlner, Anna Murphy H{\o}genhaug, Thomas Gammeltoft-Hansen, Thomas B.  Moeslund* 

  Explainable AI (XAI) aids in deciphering 'black-box' models. While several
methods have been proposed and evaluated primarily in the image domain, the
exploration of explainability in the text domain remains a growing research
area. In this paper, we delve into the applicability of XAI methods for the
text domain. In this context, the 'Similarity Difference and Uniqueness' (SIDU)
XAI method, recognized for its superior capability in localizing entire salient
regions in image-based classification is extended to textual data. The extended
method, SIDU-TXT, utilizes feature activation maps from 'black-box' models to
generate heatmaps at a granular, word-based level, thereby providing
explanations that highlight contextually significant textual elements crucial
for model predictions. Given the absence of a unified standard for assessing
XAI methods, this study applies a holistic three-tiered comprehensive
evaluation framework: Functionally-Grounded, Human-Grounded and
Application-Grounded, to assess the effectiveness of the proposed SIDU-TXT
across various experiments. We find that, in sentiment analysis task of a movie
review dataset, SIDU-TXT excels in both functionally and human-grounded
evaluations, demonstrating superior performance through quantitative and
qualitative analyses compared to benchmarks like Grad-CAM and LIME. In the
application-grounded evaluation within the sensitive and complex legal domain
of asylum decision-making, SIDU-TXT and Grad-CAM demonstrate comparable
performances, each with its own set of strengths and weaknesses. However, both
methods fall short of entirely fulfilling the sophisticated criteria of expert
expectations, highlighting the imperative need for additional research in XAI
methods suitable for such domains.

---------------

### 07 Nov 2022 | [Explainable AI over the Internet of Things (IoT): Overview,  State-of-the-Art and Future Directions](https://arxiv.org/abs/2211.01036) | [⬇️](https://arxiv.org/pdf/2211.01036)
*Senthil Kumar Jagatheesaperumal, Quoc-Viet Pham, Rukhsana Ruby,  Zhaohui Yang, Chunmei Xu, and Zhaoyang Zhang* 

  Explainable Artificial Intelligence (XAI) is transforming the field of
Artificial Intelligence (AI) by enhancing the trust of end-users in machines.
As the number of connected devices keeps on growing, the Internet of Things
(IoT) market needs to be trustworthy for the end-users. However, existing
literature still lacks a systematic and comprehensive survey work on the use of
XAI for IoT. To bridge this lacking, in this paper, we address the XAI
frameworks with a focus on their characteristics and support for IoT. We
illustrate the widely-used XAI services for IoT applications, such as security
enhancement, Internet of Medical Things (IoMT), Industrial IoT (IIoT), and
Internet of City Things (IoCT). We also suggest the implementation choice of
XAI models over IoT systems in these applications with appropriate examples and
summarize the key inferences for future works. Moreover, we present the
cutting-edge development in edge XAI structures and the support of
sixth-generation (6G) communication services for IoT applications, along with
key inferences. In a nutshell, this paper constitutes the first holistic
compilation on the development of XAI-based frameworks tailored for the demands
of future IoT use cases.

---------------

### 09 Jun 2023 | [Strategies to exploit XAI to improve classification systems](https://arxiv.org/abs/2306.05801) | [⬇️](https://arxiv.org/pdf/2306.05801)
*Andrea Apicella, Luca Di Lorenzo, Francesco Isgr\`o, Andrea Pollastro,  Roberto Prevete* 

  Explainable Artificial Intelligence (XAI) aims to provide insights into the
decision-making process of AI models, allowing users to understand their
results beyond their decisions. A significant goal of XAI is to improve the
performance of AI models by providing explanations for their decision-making
processes. However, most XAI literature focuses on how to explain an AI system,
while less attention has been given to how XAI methods can be exploited to
improve an AI system. In this work, a set of well-known XAI methods typically
used with Machine Learning (ML) classification tasks are investigated to verify
if they can be exploited, not just to provide explanations but also to improve
the performance of the model itself. To this aim, two strategies to use the
explanation to improve a classification system are reported and empirically
evaluated on three datasets: Fashion-MNIST, CIFAR10, and STL10. Results suggest
that explanations built by Integrated Gradients highlight input features that
can be effectively used to improve classification performance.

---------------
**Date:** 28 Aug 2023

**Title:** Explaining Machine Learning Models in Natural Conversations: Towards a  Conversational XAI Agent

**Abstract Link:** [https://arxiv.org/abs/2209.02552](https://arxiv.org/abs/2209.02552)

**PDF Link:** [https://arxiv.org/pdf/2209.02552](https://arxiv.org/pdf/2209.02552)

---

**Date:** 25 Sep 2023

**Title:** May I Ask a Follow-up Question? Understanding the Benefits of  Conversations in Neural Network Explainability

**Abstract Link:** [https://arxiv.org/abs/2309.13965](https://arxiv.org/abs/2309.13965)

**PDF Link:** [https://arxiv.org/pdf/2309.13965](https://arxiv.org/pdf/2309.13965)

---

**Date:** 27 Oct 2023

**Title:** ConvXAI: Delivering Heterogeneous AI Explanations via Conversations to  Support Human-AI Scientific Writing

**Abstract Link:** [https://arxiv.org/abs/2305.09770](https://arxiv.org/abs/2305.09770)

**PDF Link:** [https://arxiv.org/pdf/2305.09770](https://arxiv.org/pdf/2305.09770)

---

**Date:** 12 Jul 2021

**Title:** Explainable AI: current status and future directions

**Abstract Link:** [https://arxiv.org/abs/2107.07045](https://arxiv.org/abs/2107.07045)

**PDF Link:** [https://arxiv.org/pdf/2107.07045](https://arxiv.org/pdf/2107.07045)

---

**Date:** 04 Nov 2021

**Title:** Characterizing Human Explanation Strategies to Inform the Design of  Explainable AI for Building Damage Assessment

**Abstract Link:** [https://arxiv.org/abs/2111.02626](https://arxiv.org/abs/2111.02626)

**PDF Link:** [https://arxiv.org/pdf/2111.02626](https://arxiv.org/pdf/2111.02626)

---

**Date:** 25 Nov 2023

**Title:** Trainable Noise Model as an XAI evaluation method: application on Sobol  for remote sensing image segmentation

**Abstract Link:** [https://arxiv.org/abs/2310.01828](https://arxiv.org/abs/2310.01828)

**PDF Link:** [https://arxiv.org/pdf/2310.01828](https://arxiv.org/pdf/2310.01828)

---

**Date:** 03 Feb 2021

**Title:** Unbox the Black-box for the Medical Explainable AI via Multi-modal and  Multi-centre Data Fusion: A Mini-Review, Two Showcases and Beyond

**Abstract Link:** [https://arxiv.org/abs/2102.01998](https://arxiv.org/abs/2102.01998)

**PDF Link:** [https://arxiv.org/pdf/2102.01998](https://arxiv.org/pdf/2102.01998)

---

**Date:** 08 Nov 2021

**Title:** Counterfactual Explanations as Interventions in Latent Space

**Abstract Link:** [https://arxiv.org/abs/2106.07754](https://arxiv.org/abs/2106.07754)

**PDF Link:** [https://arxiv.org/pdf/2106.07754](https://arxiv.org/pdf/2106.07754)

---

**Date:** 01 Aug 2023

**Title:** Explaining and visualizing black-box models through counterfactual paths

**Abstract Link:** [https://arxiv.org/abs/2307.07764](https://arxiv.org/abs/2307.07764)

**PDF Link:** [https://arxiv.org/pdf/2307.07764](https://arxiv.org/pdf/2307.07764)

---

**Date:** 14 Oct 2023

**Title:** Scene Text Recognition Models Explainability Using Local Features

**Abstract Link:** [https://arxiv.org/abs/2310.09549](https://arxiv.org/abs/2310.09549)

**PDF Link:** [https://arxiv.org/pdf/2310.09549](https://arxiv.org/pdf/2310.09549)

---

**Date:** 15 Feb 2021

**Title:** Ada-SISE: Adaptive Semantic Input Sampling for Efficient Explanation of  Convolutional Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2102.07799](https://arxiv.org/abs/2102.07799)

**PDF Link:** [https://arxiv.org/pdf/2102.07799](https://arxiv.org/pdf/2102.07799)

---

**Date:** 17 May 2023

**Title:** Explain Any Concept: Segment Anything Meets Concept-Based Explanation

**Abstract Link:** [https://arxiv.org/abs/2305.10289](https://arxiv.org/abs/2305.10289)

**PDF Link:** [https://arxiv.org/pdf/2305.10289](https://arxiv.org/pdf/2305.10289)

---

**Date:** 08 Feb 2022

**Title:** Towards a Shapley Value Graph Framework for Medical peer-influence

**Abstract Link:** [https://arxiv.org/abs/2112.14624](https://arxiv.org/abs/2112.14624)

**PDF Link:** [https://arxiv.org/pdf/2112.14624](https://arxiv.org/pdf/2112.14624)

---

**Date:** 07 Nov 2023

**Title:** Extracting human interpretable structure-property relationships in  chemistry using XAI and large language models

**Abstract Link:** [https://arxiv.org/abs/2311.04047](https://arxiv.org/abs/2311.04047)

**PDF Link:** [https://arxiv.org/pdf/2311.04047](https://arxiv.org/pdf/2311.04047)

---

**Date:** 07 Jul 2021

**Title:** Levels of explainable artificial intelligence for human-aligned  conversational explanations

**Abstract Link:** [https://arxiv.org/abs/2107.03178](https://arxiv.org/abs/2107.03178)

**PDF Link:** [https://arxiv.org/pdf/2107.03178](https://arxiv.org/pdf/2107.03178)

---

**Date:** 26 Jan 2022

**Title:** SCAI-QReCC Shared Task on Conversational Question Answering

**Abstract Link:** [https://arxiv.org/abs/2201.11094](https://arxiv.org/abs/2201.11094)

**PDF Link:** [https://arxiv.org/pdf/2201.11094](https://arxiv.org/pdf/2201.11094)

---

**Date:** 08 Mar 2021

**Title:** A Comparative Approach to Explainable Artificial Intelligence Methods in  Application to High-Dimensional Electronic Health Records: Examining the  Usability of XAI

**Abstract Link:** [https://arxiv.org/abs/2103.04951](https://arxiv.org/abs/2103.04951)

**PDF Link:** [https://arxiv.org/pdf/2103.04951](https://arxiv.org/pdf/2103.04951)

---

**Date:** 05 Feb 2024

**Title:** SIDU-TXT: An XAI Algorithm for NLP with a Holistic Assessment Approach

**Abstract Link:** [https://arxiv.org/abs/2402.03043](https://arxiv.org/abs/2402.03043)

**PDF Link:** [https://arxiv.org/pdf/2402.03043](https://arxiv.org/pdf/2402.03043)

---

**Date:** 07 Nov 2022

**Title:** Explainable AI over the Internet of Things (IoT): Overview,  State-of-the-Art and Future Directions

**Abstract Link:** [https://arxiv.org/abs/2211.01036](https://arxiv.org/abs/2211.01036)

**PDF Link:** [https://arxiv.org/pdf/2211.01036](https://arxiv.org/pdf/2211.01036)

---

**Date:** 09 Jun 2023

**Title:** Strategies to exploit XAI to improve classification systems

**Abstract Link:** [https://arxiv.org/abs/2306.05801](https://arxiv.org/abs/2306.05801)

**PDF Link:** [https://arxiv.org/pdf/2306.05801](https://arxiv.org/pdf/2306.05801)

---

