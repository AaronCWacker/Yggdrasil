Core Concepts 💡

### 🔎 Core Concepts 💡



# What is a Data Warehouse?

A data warehouse is a centralized repository of data that is designed for query and analysis rather than just storing raw data. It is a critical component of a business intelligence system.

Data warehouses store historical data from various sources, such as transactional databases, log files, and external feeds. This data is then transformed, cleaned, and integrated into a consistent format that can be used for reporting and analysis.

Data warehouses are designed to handle large volumes of data and provide fast query performance, even for complex queries that involve aggregating data from multiple sources. They are also designed to support ad-hoc queries, which allow users to explore the data in new and unexpected ways.

Data warehouses are used by businesses to gain insights into their operations, improve decision-making, and identify trends and patterns. They are often used in conjunction with business intelligence tools, such as reporting and visualization software, to create dashboards and reports that provide a clear picture of the business's performance.

There are several different types of data warehouses, including:

* **Enterprise data warehouses (EDWs)**: These are large, centralized data warehouses that serve the entire organization. They typically store data from multiple sources and are used to support enterprise-wide reporting and analysis.
* **Operational data stores (ODSs)**: These are smaller, more focused data warehouses that are used to support specific business processes or departments. They typically store data that is needed for day-to-day operations and are used to support operational reporting and analysis.
* **Data marts**: These are smaller, department-specific data warehouses that are used to support the reporting and analysis needs of a specific business unit or department. They typically store a subset of the data that is stored in the enterprise data warehouse.

Data warehouses are typically implemented using a combination of hardware, software, and data management techniques. The hardware typically includes a high-performance database server and a large amount of storage. The software typically includes a database management system (DBMS) and a set of tools for loading, transforming, and integrating data. The data management techniques include data modeling, data cleansing, and data governance.

Data warehouses are an essential part of a modern business intelligence system. They provide a centralized repository of data
# 🩺🔍 Search Results
### 29 Sep 2023 | [Human-like Few-Shot Learning via Bayesian Reasoning over Natural  Language](https://arxiv.org/abs/2306.02797) | [⬇️](https://arxiv.org/pdf/2306.02797)
*Kevin Ellis* 

  A core tension in models of concept learning is that the model must carefully
balance the tractability of inference against the expressivity of the
hypothesis class. Humans, however, can efficiently learn a broad range of
concepts. We introduce a model of inductive learning that seeks to be
human-like in that sense. It implements a Bayesian reasoning process where a
language model first proposes candidate hypotheses expressed in natural
language, which are then re-weighed by a prior and a likelihood. By estimating
the prior from human data, we can predict human judgments on learning problems
involving numbers and sets, spanning concepts that are generative,
discriminative, propositional, and higher-order.

---------------

### 15 Jan 2023 | [Automatic Generation of Product Concepts from Positive Examples, with an  Application to Music Streaming](https://arxiv.org/abs/2210.01515) | [⬇️](https://arxiv.org/pdf/2210.01515)
*Kshitij Goyal, Wannes Meert, Hendrik Blockeel, Elia Van Wolputte, Koen  Vanderstraeten, Wouter Pijpops, Kurt Jaspers* 

  Internet based businesses and products (e.g. e-commerce, music streaming) are
becoming more and more sophisticated every day with a lot of focus on improving
customer satisfaction. A core way they achieve this is by providing customers
with an easy access to their products by structuring them in catalogues using
navigation bars and providing recommendations. We refer to these catalogues as
product concepts, e.g. product categories on e-commerce websites, public
playlists on music streaming platforms. These product concepts typically
contain products that are linked with each other through some common features
(e.g. a playlist of songs by the same artist). How they are defined in the
backend of the system can be different for different products. In this work, we
represent product concepts using database queries and tackle two learning
problems. First, given sets of products that all belong to the same unknown
product concept, we learn a database query that is a representation of this
product concept. Second, we learn product concepts and their corresponding
queries when the given sets of products are associated with multiple product
concepts. To achieve these goals, we propose two approaches that combine the
concepts of PU learning with Decision Trees and Clustering. Our experiments
demonstrate, via a simulated setup for a music streaming service, that our
approach is effective in solving these problems.

---------------

### 07 Aug 2023 | [Counterfactual Monotonic Knowledge Tracing for Assessing Students'  Dynamic Mastery of Knowledge Concepts](https://arxiv.org/abs/2308.03377) | [⬇️](https://arxiv.org/pdf/2308.03377)
*Moyu Zhang, Xinning Zhu, Chunhong Zhang, Wenchen Qian, Feng Pan, Hui  Zhao* 

  As the core of the Knowledge Tracking (KT) task, assessing students' dynamic
mastery of knowledge concepts is crucial for both offline teaching and online
educational applications. Since students' mastery of knowledge concepts is
often unlabeled, existing KT methods rely on the implicit paradigm of
historical practice to mastery of knowledge concepts to students' responses to
practices to address the challenge of unlabeled concept mastery. However,
purely predicting student responses without imposing specific constraints on
hidden concept mastery values does not guarantee the accuracy of these
intermediate values as concept mastery values. To address this issue, we
propose a principled approach called Counterfactual Monotonic Knowledge Tracing
(CMKT), which builds on the implicit paradigm described above by using a
counterfactual assumption to constrain the evolution of students' mastery of
knowledge concepts.

---------------

### 25 Apr 2020 | [A Linguistically Driven Framework for Query Expansion via Grammatical  Constituent Highlighting and Role-Based Concept Weighting](https://arxiv.org/abs/2004.13481) | [⬇️](https://arxiv.org/pdf/2004.13481)
*Bhawani Selvaretnam, Mohammed Belkhatir* 

  In this paper, we propose a linguistically-motivated query expansion
framework that recognizes and en-codes significant query constituents that
characterize query intent in order to improve retrieval performance.
Concepts-of-Interest are recognized as the core concepts that represent the
gist of the search goal whilst the remaining query constituents which serve to
specify the search goal and complete the query structure are classified as
descriptive, relational or structural. Acknowledging the need to form
semantically-associated base pairs for the purpose of extracting related
potential expansion concepts, an algorithm which capitalizes on syntactical
dependencies to capture relationships between adjacent and non-adjacent query
concepts is proposed. Lastly, a robust weighting scheme that duly emphasizes
the importance of query constituents based on their linguistic role within the
expanded query is presented. We demonstrate improvements in retrieval
effectiveness in terms of increased mean average precision (MAP) garnered by
the proposed linguistic-based query expansion framework through experimentation
on the TREC ad hoc test collections.

---------------

### 20 Sep 2021 | [Feature Correlation Aggregation: on the Path to Better Graph Neural  Networks](https://arxiv.org/abs/2109.09300) | [⬇️](https://arxiv.org/pdf/2109.09300)
*Jieming Zhou, Tong Zhang, Pengfei Fang, Lars Petersson, Mehrtash  Harandi* 

  Prior to the introduction of Graph Neural Networks (GNNs), modeling and
analyzing irregular data, particularly graphs, was thought to be the Achilles'
heel of deep learning. The core concept of GNNs is to find a representation by
recursively aggregating the representations of a central node and those of its
neighbors. The core concept of GNNs is to find a representation by recursively
aggregating the representations of a central node and those of its neighbor,
and its success has been demonstrated by many GNNs' designs. However, most of
them only focus on using the first-order information between a node and its
neighbors. In this paper, we introduce a central node permutation variant
function through a frustratingly simple and innocent-looking modification to
the core operation of a GNN, namely the Feature cOrrelation aGgregation (FOG)
module which learns the second-order information from feature correlation
between a node and its neighbors in the pipeline. By adding FOG into existing
variants of GNNs, we empirically verify this second-order information
complements the features generated by original GNNs across a broad set of
benchmarks. A tangible boost in performance of the model is observed where the
model surpasses previous state-of-the-art results by a significant margin while
employing fewer parameters. (e.g., 33.116% improvement on a real-world
molecular dataset using graph convolutional networks).

---------------

### 06 Mar 2024 | [Learning 3D object-centric representation through prediction](https://arxiv.org/abs/2403.03730) | [⬇️](https://arxiv.org/pdf/2403.03730)
*John Day, Tushar Arora, Jirui Liu, Li Erran Li, and Ming Bo Cai* 

  As part of human core knowledge, the representation of objects is the
building block of mental representation that supports high-level concepts and
symbolic reasoning. While humans develop the ability of perceiving objects
situated in 3D environments without supervision, models that learn the same set
of abilities with similar constraints faced by human infants are lacking.
Towards this end, we developed a novel network architecture that simultaneously
learns to 1) segment objects from discrete images, 2) infer their 3D locations,
and 3) perceive depth, all while using only information directly available to
the brain as training data, namely: sequences of images and self-motion. The
core idea is treating objects as latent causes of visual input which the brain
uses to make efficient predictions of future scenes. This results in object
representations being learned as an essential byproduct of learning to predict.

---------------

### 30 Jan 2024 | [MolPLA: A Molecular Pretraining Framework for Learning Cores, R-Groups  and their Linker Joints](https://arxiv.org/abs/2401.16771) | [⬇️](https://arxiv.org/pdf/2401.16771)
*Mogan Gim, Jueon Park, Soyon Park, Sanghoon Lee, Seungheun Baek,  Junhyun Lee, Ngoc-Quang Nguyen, Jaewoo Kang* 

  Molecular core structures and R-groups are essential concepts in drug
development. Integration of these concepts with conventional graph pre-training
approaches can promote deeper understanding in molecules. We propose MolPLA, a
novel pre-training framework that employs masked graph contrastive learning in
understanding the underlying decomposable parts inmolecules that implicate
their core structure and peripheral R-groups. Furthermore, we formulate an
additional framework that grants MolPLA the ability to help chemists find
replaceable R-groups in lead optimization scenarios. Experimental results on
molecular property prediction show that MolPLA exhibits predictability
comparable to current state-of-the-art models. Qualitative analysis implicate
that MolPLA is capable of distinguishing core and R-group sub-structures,
identifying decomposable regions in molecules and contributing to lead
optimization scenarios by rationally suggesting R-group replacements given
various query core templates. The code implementation for MolPLA and its
pre-trained model checkpoint is available at https://github.com/dmis-lab/MolPLA

---------------

### 24 Jul 2019 | [Differentiable Disentanglement Filter: an Application Agnostic Core  Concept Discovery Probe](https://arxiv.org/abs/1907.07507) | [⬇️](https://arxiv.org/pdf/1907.07507)
*Guntis Barzdins and Eduards Sidorovics* 

  It has long been speculated that deep neural networks function by discovering
a hierarchical set of domain-specific core concepts or patterns, which are
further combined to recognize even more elaborate concepts for the
classification or other machine learning tasks. Meanwhile disentangling the
actual core concepts engrained in the word embeddings (like word2vec or BERT)
or deep convolutional image recognition neural networks (like PG-GAN) is
difficult and some success there has been achieved only recently. In this paper
we propose a novel neural network nonlinearity named Differentiable
Disentanglement Filter (DDF) which can be transparently inserted into any
existing neural network layer to automatically disentangle the core concepts
used by that layer. The DDF probe is inspired by the obscure properties of the
hyper-dimensional computing theory. The DDF proof-of-concept implementation is
shown to disentangle concepts within the neural 3D scene representation - a
task vital for visual grounding of natural language narratives.

---------------

### 29 Oct 2021 | [Concept and Attribute Reduction Based on Rectangle Theory of Formal  Concept](https://arxiv.org/abs/2111.00005) | [⬇️](https://arxiv.org/pdf/2111.00005)
*Jianqin Zhou, Sichun Yang, Xifeng Wang and Wanquan Liu* 

  Based on rectangle theory of formal concept and set covering theory, the
concept reduction preserving binary relations is investigated in this paper. It
is known that there are three types of formal concepts: core concepts, relative
necessary concepts and unnecessary concepts. First, we present the new judgment
results for relative necessary concepts and unnecessary concepts. Second, we
derive the bounds for both the maximum number of relative necessary concepts
and the maximum number of unnecessary concepts and it is a difficult problem as
either in concept reduction preserving binary relations or attribute reduction
of decision formal contexts, the computation of formal contexts from formal
concepts is a challenging problem. Third, based on rectangle theory of formal
concept, a fast algorithm for reducing attributes while preserving the
extensions for a set of formal concepts is proposed using the extension
bit-array technique, which allows multiple context cells to be processed by a
single 32-bit or 64-bit operator. Technically, the new algorithm could store
both formal context and extent of a concept as bit-arrays, and we can use
bit-operations to process set operations "or" as well as "and". One more merit
is that the new algorithm does not need to consider other concepts in the
concept lattice, thus the algorithm is explicit to understand and fast.
Experiments demonstrate that the new algorithm is effective in the computation
of attribute reductions.

---------------

### 27 Jun 2022 | [Analyzing Encoded Concepts in Transformer Language Models](https://arxiv.org/abs/2206.13289) | [⬇️](https://arxiv.org/pdf/2206.13289)
*Hassan Sajjad, Nadir Durrani, Fahim Dalvi, Firoj Alam, Abdul Rafae  Khan, Jia Xu* 

  We propose a novel framework ConceptX, to analyze how latent concepts are
encoded in representations learned within pre-trained language models. It uses
clustering to discover the encoded concepts and explains them by aligning with
a large set of human-defined concepts. Our analysis on seven transformer
language models reveal interesting insights: i) the latent space within the
learned representations overlap with different linguistic concepts to a varying
degree, ii) the lower layers in the model are dominated by lexical concepts
(e.g., affixation), whereas the core-linguistic concepts (e.g., morphological
or syntactic relations) are better represented in the middle and higher layers,
iii) some encoded concepts are multi-faceted and cannot be adequately explained
using the existing human-defined concepts.

---------------

### 27 Sep 2023 | [A Tutorial on Uniform B-Spline](https://arxiv.org/abs/2309.15477) | [⬇️](https://arxiv.org/pdf/2309.15477)
*Yi Zhou* 

  This document facilitates understanding of core concepts about uniform
B-spline and its matrix representation.

---------------

### 20 Nov 2022 | [Overcoming Concept Shift in Domain-Aware Settings through Consolidated  Internal Distributions](https://arxiv.org/abs/2007.00197) | [⬇️](https://arxiv.org/pdf/2007.00197)
*Mohammad Rostami, Aram Galstyan* 

  We develop an algorithm to improve the performance of a pre-trained model
under concept shift without retraining the model from scratch when only
unannotated samples of initial concepts are accessible. We model this problem
as a domain adaptation problem, where the source domain data is inaccessible
during model adaptation. The core idea is based on consolidating the
intermediate internal distribution, learned to represent the source domain
data, after adapting the model. We provide theoretical analysis and conduct
extensive experiments to demonstrate that the proposed method is effective.

---------------

### 09 Nov 2023 | [Window Attention is Bugged: How not to Interpolate Position Embeddings](https://arxiv.org/abs/2311.05613) | [⬇️](https://arxiv.org/pdf/2311.05613)
*Daniel Bolya, Chaitanya Ryali, Judy Hoffman, Christoph Feichtenhofer* 

  Window attention, position embeddings, and high resolution finetuning are
core concepts in the modern transformer era of computer vision. However, we
find that naively combining these near ubiquitous components can have a
detrimental effect on performance. The issue is simple: interpolating position
embeddings while using window attention is wrong. We study two state-of-the-art
methods that have these three components, namely Hiera and ViTDet, and find
that both do indeed suffer from this bug. To fix it, we introduce a simple
absolute window position embedding strategy, which solves the bug outright in
Hiera and allows us to increase both speed and performance of the model in
ViTDet. We finally combine the two to obtain HieraDet, which achieves 61.7 box
mAP on COCO, making it state-of-the-art for models that only use ImageNet-1k
pretraining. This all stems from what is essentially a 3 line bug fix, which we
name "absolute win".

---------------

### 01 Sep 2021 | [SciCo: Hierarchical Cross-Document Coreference for Scientific Concepts](https://arxiv.org/abs/2104.08809) | [⬇️](https://arxiv.org/pdf/2104.08809)
*Arie Cattan, Sophie Johnson, Daniel Weld, Ido Dagan, Iz Beltagy, Doug  Downey, Tom Hope* 

  Determining coreference of concept mentions across multiple documents is a
fundamental task in natural language understanding. Previous work on
cross-document coreference resolution (CDCR) typically considers mentions of
events in the news, which seldom involve abstract technical concepts that are
prevalent in science and technology. These complex concepts take diverse or
ambiguous forms and have many hierarchical levels of granularity (e.g., tasks
and subtasks), posing challenges for CDCR. We present a new task of
Hierarchical CDCR (H-CDCR) with the goal of jointly inferring coreference
clusters and hierarchy between them. We create SciCo, an expert-annotated
dataset for H-CDCR in scientific papers, 3X larger than the prominent ECB+
resource. We study strong baseline models that we customize for H-CDCR, and
highlight challenges for future work.

---------------

### 02 Feb 2022 | [Deep Learning for Epidemiologists: An Introduction to Neural Networks](https://arxiv.org/abs/2202.01319) | [⬇️](https://arxiv.org/pdf/2202.01319)
*Stylianos Serghiou, Kathryn Rough* 

  Deep learning methods are increasingly being applied to problems in medicine
and healthcare. However, few epidemiologists have received formal training in
these methods. To bridge this gap, this article introduces to the fundamentals
of deep learning from an epidemiological perspective. Specifically, this
article reviews core concepts in machine learning (overfitting, regularization,
hyperparameters), explains several fundamental deep learning architectures
(convolutional neural networks, recurrent neural networks), and summarizes
training, evaluation, and deployment of models. We aim to enable the reader to
engage with and critically evaluate medical applications of deep learning,
facilitating a dialogue between computer scientists and epidemiologists that
will improve the safety and efficacy of applications of this technology.

---------------

### 09 Apr 2023 | [Intrinsic Physical Concepts Discovery with Object-Centric Predictive  Models](https://arxiv.org/abs/2303.01869) | [⬇️](https://arxiv.org/pdf/2303.01869)
*Qu Tang, XiangYu Zhu, Zhen Lei, ZhaoXiang Zhang* 

  The ability to discover abstract physical concepts and understand how they
work in the world through observing lies at the core of human intelligence. The
acquisition of this ability is based on compositionally perceiving the
environment in terms of objects and relations in an unsupervised manner. Recent
approaches learn object-centric representations and capture visually observable
concepts of objects, e.g., shape, size, and location. In this paper, we take a
step forward and try to discover and represent intrinsic physical concepts such
as mass and charge. We introduce the PHYsical Concepts Inference NEtwork
(PHYCINE), a system that infers physical concepts in different abstract levels
without supervision. The key insights underlining PHYCINE are two-fold,
commonsense knowledge emerges with prediction, and physical concepts of
different abstract levels should be reasoned in a bottom-up fashion. Empirical
evaluation demonstrates that variables inferred by our system work in
accordance with the properties of the corresponding physical concepts. We also
show that object representations containing the discovered physical concepts
variables could help achieve better performance in causal reasoning tasks,
i.e., ComPhy.

---------------

### 19 Dec 2019 | [Spiking Networks for Improved Cognitive Abilities of Edge Computing  Devices](https://arxiv.org/abs/1912.09083) | [⬇️](https://arxiv.org/pdf/1912.09083)
*Anton Akusok, Kaj-Mikael Bj\"ork, Leonardo Espinosa Leal, Yoan Miche,  Renjie Hu and Amaury Lendasse* 

  This concept paper highlights a recently opened opportunity for large scale
analytical algorithms to be trained directly on edge devices. Such approach is
a response to the arising need of processing data generated by natural person
(a human being), also known as personal data. Spiking Neural networks are the
core method behind it: suitable for a low latency energy-constrained hardware,
enabling local training or re-training, while not taking advantage of
scalability available in the Cloud.

---------------

### 15 Nov 2019 | [Temporarily Unavailable: Memory Inhibition in Cognitive and Computer  Science](https://arxiv.org/abs/1912.00760) | [⬇️](https://arxiv.org/pdf/1912.00760)
*Tobias Tempel, Claudia Nieder\'ee, Christian Jilek, Andrea Ceroni,  Heiko Maus, Yannick Runge, Christian Frings* 

  Inhibition is one of the core concepts in Cognitive Psychology. The idea of
inhibitory mechanisms actively weakening representations in the human mind has
inspired a great number of studies in various research domains. In contrast,
Computer Science only recently has begun to consider inhibition as a second
basic processing quality beside activation. Here, we review psychological
research on inhibition in memory and link the gained insights with the current
efforts in Computer Science of incorporating inhibitory principles for
optimizing information retrieval in Personal Information Management. Four
common aspects guide this review in both domains: 1. The purpose of inhibition
to increase processing efficiency. 2. Its relation to activation. 3. Its links
to contexts. 4. Its temporariness. In summary, the concept of inhibition has
been used by Computer Science for enhancing software in various ways already.
Yet, we also identify areas for promising future developments of inhibitory
mechanisms, particularly context inhibition.

---------------

### 07 Sep 2011 | [Conceptual Knowledge Markup Language: The central core](https://arxiv.org/abs/1109.1525) | [⬇️](https://arxiv.org/pdf/1109.1525)
*Robert E. Kent* 

  The conceptual knowledge framework OML/CKML needs several components for a
successful design. One important, but previously overlooked, component is the
central core of OML/CKML. The central core provides a theoretical link between
the ontological specification in OML and the conceptual knowledge
representation in CKML. This paper discusses the formal semantics and syntactic
styles of the central core, and also the important role it plays in defining
interoperability between OML/CKML, RDF/S and Ontolingua.

---------------

### 09 Dec 2023 | [Do We Fully Understand Students' Knowledge States? Identifying and  Mitigating Answer Bias in Knowledge Tracing](https://arxiv.org/abs/2308.07779) | [⬇️](https://arxiv.org/pdf/2308.07779)
*Chaoran Cui, Hebo Ma, Chen Zhang, Chunyun Zhang, Yumo Yao, Meng Chen,  Yuling Ma* 

  Knowledge tracing (KT) aims to monitor students' evolving knowledge states
through their learning interactions with concept-related questions, and can be
indirectly evaluated by predicting how students will perform on future
questions. In this paper, we observe that there is a common phenomenon of
answer bias, i.e., a highly unbalanced distribution of correct and incorrect
answers for each question. Existing models tend to memorize the answer bias as
a shortcut for achieving high prediction performance in KT, thereby failing to
fully understand students' knowledge states. To address this issue, we approach
the KT task from a causality perspective. A causal graph of KT is first
established, from which we identify that the impact of answer bias lies in the
direct causal effect of questions on students' responses. A novel
COunterfactual REasoning (CORE) framework for KT is further proposed, which
separately captures the total causal effect and direct causal effect during
training, and mitigates answer bias by subtracting the latter from the former
in testing. The CORE framework is applicable to various existing KT models, and
we implement it based on the prevailing DKT, DKVMN, and AKT models,
respectively. Extensive experiments on three benchmark datasets demonstrate the
effectiveness of CORE in making the debiased inference for KT. We have released
our code at https://github.com/lucky7-code/CORE.

---------------
**Date:** 29 Sep 2023

**Title:** Human-like Few-Shot Learning via Bayesian Reasoning over Natural  Language

**Abstract Link:** [https://arxiv.org/abs/2306.02797](https://arxiv.org/abs/2306.02797)

**PDF Link:** [https://arxiv.org/pdf/2306.02797](https://arxiv.org/pdf/2306.02797)

---

**Date:** 15 Jan 2023

**Title:** Automatic Generation of Product Concepts from Positive Examples, with an  Application to Music Streaming

**Abstract Link:** [https://arxiv.org/abs/2210.01515](https://arxiv.org/abs/2210.01515)

**PDF Link:** [https://arxiv.org/pdf/2210.01515](https://arxiv.org/pdf/2210.01515)

---

**Date:** 07 Aug 2023

**Title:** Counterfactual Monotonic Knowledge Tracing for Assessing Students'  Dynamic Mastery of Knowledge Concepts

**Abstract Link:** [https://arxiv.org/abs/2308.03377](https://arxiv.org/abs/2308.03377)

**PDF Link:** [https://arxiv.org/pdf/2308.03377](https://arxiv.org/pdf/2308.03377)

---

**Date:** 25 Apr 2020

**Title:** A Linguistically Driven Framework for Query Expansion via Grammatical  Constituent Highlighting and Role-Based Concept Weighting

**Abstract Link:** [https://arxiv.org/abs/2004.13481](https://arxiv.org/abs/2004.13481)

**PDF Link:** [https://arxiv.org/pdf/2004.13481](https://arxiv.org/pdf/2004.13481)

---

**Date:** 20 Sep 2021

**Title:** Feature Correlation Aggregation: on the Path to Better Graph Neural  Networks

**Abstract Link:** [https://arxiv.org/abs/2109.09300](https://arxiv.org/abs/2109.09300)

**PDF Link:** [https://arxiv.org/pdf/2109.09300](https://arxiv.org/pdf/2109.09300)

---

**Date:** 06 Mar 2024

**Title:** Learning 3D object-centric representation through prediction

**Abstract Link:** [https://arxiv.org/abs/2403.03730](https://arxiv.org/abs/2403.03730)

**PDF Link:** [https://arxiv.org/pdf/2403.03730](https://arxiv.org/pdf/2403.03730)

---

**Date:** 30 Jan 2024

**Title:** MolPLA: A Molecular Pretraining Framework for Learning Cores, R-Groups  and their Linker Joints

**Abstract Link:** [https://arxiv.org/abs/2401.16771](https://arxiv.org/abs/2401.16771)

**PDF Link:** [https://arxiv.org/pdf/2401.16771](https://arxiv.org/pdf/2401.16771)

---

**Date:** 24 Jul 2019

**Title:** Differentiable Disentanglement Filter: an Application Agnostic Core  Concept Discovery Probe

**Abstract Link:** [https://arxiv.org/abs/1907.07507](https://arxiv.org/abs/1907.07507)

**PDF Link:** [https://arxiv.org/pdf/1907.07507](https://arxiv.org/pdf/1907.07507)

---

**Date:** 29 Oct 2021

**Title:** Concept and Attribute Reduction Based on Rectangle Theory of Formal  Concept

**Abstract Link:** [https://arxiv.org/abs/2111.00005](https://arxiv.org/abs/2111.00005)

**PDF Link:** [https://arxiv.org/pdf/2111.00005](https://arxiv.org/pdf/2111.00005)

---

**Date:** 27 Jun 2022

**Title:** Analyzing Encoded Concepts in Transformer Language Models

**Abstract Link:** [https://arxiv.org/abs/2206.13289](https://arxiv.org/abs/2206.13289)

**PDF Link:** [https://arxiv.org/pdf/2206.13289](https://arxiv.org/pdf/2206.13289)

---

**Date:** 27 Sep 2023

**Title:** A Tutorial on Uniform B-Spline

**Abstract Link:** [https://arxiv.org/abs/2309.15477](https://arxiv.org/abs/2309.15477)

**PDF Link:** [https://arxiv.org/pdf/2309.15477](https://arxiv.org/pdf/2309.15477)

---

**Date:** 20 Nov 2022

**Title:** Overcoming Concept Shift in Domain-Aware Settings through Consolidated  Internal Distributions

**Abstract Link:** [https://arxiv.org/abs/2007.00197](https://arxiv.org/abs/2007.00197)

**PDF Link:** [https://arxiv.org/pdf/2007.00197](https://arxiv.org/pdf/2007.00197)

---

**Date:** 09 Nov 2023

**Title:** Window Attention is Bugged: How not to Interpolate Position Embeddings

**Abstract Link:** [https://arxiv.org/abs/2311.05613](https://arxiv.org/abs/2311.05613)

**PDF Link:** [https://arxiv.org/pdf/2311.05613](https://arxiv.org/pdf/2311.05613)

---

**Date:** 01 Sep 2021

**Title:** SciCo: Hierarchical Cross-Document Coreference for Scientific Concepts

**Abstract Link:** [https://arxiv.org/abs/2104.08809](https://arxiv.org/abs/2104.08809)

**PDF Link:** [https://arxiv.org/pdf/2104.08809](https://arxiv.org/pdf/2104.08809)

---

**Date:** 02 Feb 2022

**Title:** Deep Learning for Epidemiologists: An Introduction to Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2202.01319](https://arxiv.org/abs/2202.01319)

**PDF Link:** [https://arxiv.org/pdf/2202.01319](https://arxiv.org/pdf/2202.01319)

---

**Date:** 09 Apr 2023

**Title:** Intrinsic Physical Concepts Discovery with Object-Centric Predictive  Models

**Abstract Link:** [https://arxiv.org/abs/2303.01869](https://arxiv.org/abs/2303.01869)

**PDF Link:** [https://arxiv.org/pdf/2303.01869](https://arxiv.org/pdf/2303.01869)

---

**Date:** 19 Dec 2019

**Title:** Spiking Networks for Improved Cognitive Abilities of Edge Computing  Devices

**Abstract Link:** [https://arxiv.org/abs/1912.09083](https://arxiv.org/abs/1912.09083)

**PDF Link:** [https://arxiv.org/pdf/1912.09083](https://arxiv.org/pdf/1912.09083)

---

**Date:** 15 Nov 2019

**Title:** Temporarily Unavailable: Memory Inhibition in Cognitive and Computer  Science

**Abstract Link:** [https://arxiv.org/abs/1912.00760](https://arxiv.org/abs/1912.00760)

**PDF Link:** [https://arxiv.org/pdf/1912.00760](https://arxiv.org/pdf/1912.00760)

---

**Date:** 07 Sep 2011

**Title:** Conceptual Knowledge Markup Language: The central core

**Abstract Link:** [https://arxiv.org/abs/1109.1525](https://arxiv.org/abs/1109.1525)

**PDF Link:** [https://arxiv.org/pdf/1109.1525](https://arxiv.org/pdf/1109.1525)

---

**Date:** 09 Dec 2023

**Title:** Do We Fully Understand Students' Knowledge States? Identifying and  Mitigating Answer Bias in Knowledge Tracing

**Abstract Link:** [https://arxiv.org/abs/2308.07779](https://arxiv.org/abs/2308.07779)

**PDF Link:** [https://arxiv.org/pdf/2308.07779](https://arxiv.org/pdf/2308.07779)

---

