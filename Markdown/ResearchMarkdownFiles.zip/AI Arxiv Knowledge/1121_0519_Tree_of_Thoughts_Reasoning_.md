Tree of Thoughts Reasoning 🌳

### 🔎 Tree of Thoughts Reasoning 🌳



🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳 a quadratic term for the number of years of education, and the coefficient is negative and statistically significant. This suggests that the relationship between education and happiness is not linear, and that there may be a point at which additional education does not lead to additional happiness.

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳🌳

🌳🌳
# 🩺🔍 Search Results
### 14 Sep 2023 | [Tree of Uncertain Thoughts Reasoning for Large Language Models](https://arxiv.org/abs/2309.07694) | [⬇️](https://arxiv.org/pdf/2309.07694)
*Shentong Mo, Miao Xin* 

  While the recently introduced Tree of Thoughts (ToT) has heralded
advancements in allowing Large Language Models (LLMs) to reason through
foresight and backtracking for global decision-making, it has overlooked the
inherent local uncertainties in intermediate decision points or "thoughts".
These local uncertainties, intrinsic to LLMs given their potential for diverse
responses, remain a significant concern in the reasoning process. Addressing
this pivotal gap, we introduce the Tree of Uncertain Thoughts (TouT) - a
reasoning framework tailored for LLMs. Our TouT effectively leverages Monte
Carlo Dropout to quantify uncertainty scores associated with LLMs' diverse
local responses at these intermediate steps. By marrying this local uncertainty
quantification with global search algorithms, TouT enhances the model's
precision in response generation. We substantiate our approach with rigorous
experiments on two demanding planning tasks: Game of 24 and Mini Crosswords.
The empirical evidence underscores TouT's superiority over both ToT and
chain-of-thought prompting methods.

---------------

### 17 Feb 2024 | [Boosting of Thoughts: Trial-and-Error Problem Solving with Large  Language Models](https://arxiv.org/abs/2402.11140) | [⬇️](https://arxiv.org/pdf/2402.11140)
*Sijia Chen, Baochun Li, Di Niu* 

  The reasoning performance of Large Language Models (LLMs) on a wide range of
problems critically relies on chain-of-thought prompting, which involves
providing a few chain of thought demonstrations as exemplars in prompts. Recent
work, e.g., Tree of Thoughts, has pointed out the importance of exploration and
self-evaluation in reasoning step selection for complex problem solving. In
this paper, we present Boosting of Thoughts (BoT), an automated prompting
framework for problem solving with LLMs by iteratively exploring and
self-evaluating many trees of thoughts in order to acquire an ensemble of
trial-and-error reasoning experiences, which will serve as a new form of
prompting to solve the complex problem. Starting from a simple prompt without
requiring examples, BoT iteratively explores and evaluates a large collection
of reasoning steps, and more importantly, uses error analysis obtained from the
LLM on them to explicitly revise prompting, which in turn enhances reasoning
step generation, until a final answer is attained. Our experiments with GPT-4
and Llama2 across extensive complex mathematical problems demonstrate that BoT
consistently achieves higher or comparable problem-solving rates than other
advanced prompting approaches.

---------------

### 15 May 2023 | [Large Language Model Guided Tree-of-Thought](https://arxiv.org/abs/2305.08291) | [⬇️](https://arxiv.org/pdf/2305.08291)
*Jieyi Long* 

  In this paper, we introduce the Tree-of-Thought (ToT) framework, a novel
approach aimed at improving the problem-solving capabilities of auto-regressive
large language models (LLMs). The ToT technique is inspired by the human mind's
approach for solving complex reasoning tasks through trial and error. In this
process, the human mind explores the solution space through a tree-like thought
process, allowing for backtracking when necessary. To implement ToT as a
software system, we augment an LLM with additional modules including a prompter
agent, a checker module, a memory module, and a ToT controller. In order to
solve a given problem, these modules engage in a multi-round conversation with
the LLM. The memory module records the conversation and state history of the
problem solving process, which allows the system to backtrack to the previous
steps of the thought-process and explore other directions from there. To verify
the effectiveness of the proposed technique, we implemented a ToT-based solver
for the Sudoku Puzzle. Experimental results show that the ToT framework can
significantly increase the success rate of Sudoku puzzle solving. Our
implementation of the ToT-based Sudoku solver is available on GitHub:
\url{https://github.com/jieyilong/tree-of-thought-puzzle-solver}.

---------------

### 23 Nov 2023 | [Probabilistic Tree-of-thought Reasoning for Answering  Knowledge-intensive Complex Questions](https://arxiv.org/abs/2311.13982) | [⬇️](https://arxiv.org/pdf/2311.13982)
*Shulin Cao, Jiajie Zhang, Jiaxin Shi, Xin Lv, Zijun Yao, Qi Tian,  Juanzi Li, Lei Hou* 

  Large language models (LLMs) are capable of answering knowledge-intensive
complex questions with chain-of-thought (CoT) reasoning. However, they tend to
generate factually incorrect reasoning steps when the required knowledge is not
available or up-to-date in models' parameters. Recent works turn to retrieving
external knowledge to augment CoT reasoning. Despite being promising, these
chain-based methods suffer from: 1) Negative retrieval. Unnecessary or
incorrect retrieval may mislead the reasoning; 2) Limited sight. Lacking the
ability to look backward or forward, a local error in one step will propagate
along the chain.
  In this paper, we propose a novel approach: Probabilistic Tree-of-thought
Reasoning (ProbTree). First, LLMs translate a complex question into a query
tree, in which each non-root node denotes a sub-question of its parent node.
Then, probabilistic reasoning is conducted over the tree, by solving questions
from leaf to root considering the confidence of both question decomposing and
answering. During reasoning, for leaf nodes, LLMs choose a more confident
answer from Closed-book QA that employs parametric knowledge and Open-book QA
that employs retrieved external knowledge, thus eliminating the negative
retrieval problem. For non-leaf nodes, with the hierarchical structure, LLMs
have broader sights and are able to globally reason with the information from
child nodes, thus recovering from local errors. The experiments on three
Complex QA datasets under the open-domain setting show that our approach
outperforms SOTA methods significantly, demonstrating the effect of
probabilistic tree-of-thought reasoning.

---------------

### 22 May 2023 | [Enhance Reasoning Ability of Visual-Language Models via Large Language  Models](https://arxiv.org/abs/2305.13267) | [⬇️](https://arxiv.org/pdf/2305.13267)
*Yueting Yang, Xintong Zhang, Wenjuan Han* 

  Pre-trained visual language models (VLM) have shown excellent performance in
image caption tasks. However, it sometimes shows insufficient reasoning
ability. In contrast, large language models (LLMs) emerge with powerful
reasoning capabilities. Therefore, we propose a method called TReE, which
transfers the reasoning ability of a large language model to a visual language
model in zero-shot scenarios. TReE contains three stages: observation,
thinking, and re-thinking. Observation stage indicates that VLM obtains the
overall information of the relative image. Thinking stage combines the image
information and task description as the prompt of the LLM, inference with the
rationals. Re-Thinking stage learns from rationale and then inference the final
result through VLM.

---------------

### 06 Feb 2024 | [Graph of Thoughts: Solving Elaborate Problems with Large Language Models](https://arxiv.org/abs/2308.09687) | [⬇️](https://arxiv.org/pdf/2308.09687)
*Maciej Besta, Nils Blach, Ales Kubicek, Robert Gerstenberger, Michal  Podstawski, Lukas Gianinazzi, Joanna Gajda, Tomasz Lehmann, Hubert  Niewiadomski, Piotr Nyczyk, Torsten Hoefler* 

  We introduce Graph of Thoughts (GoT): a framework that advances prompting
capabilities in large language models (LLMs) beyond those offered by paradigms
such as Chain-of-Thought or Tree of Thoughts (ToT). The key idea and primary
advantage of GoT is the ability to model the information generated by an LLM as
an arbitrary graph, where units of information ("LLM thoughts") are vertices,
and edges correspond to dependencies between these vertices. This approach
enables combining arbitrary LLM thoughts into synergistic outcomes, distilling
the essence of whole networks of thoughts, or enhancing thoughts using feedback
loops. We illustrate that GoT offers advantages over state of the art on
different tasks, for example increasing the quality of sorting by 62% over ToT,
while simultaneously reducing costs by >31%. We ensure that GoT is extensible
with new thought transformations and thus can be used to spearhead new
prompting schemes. This work brings the LLM reasoning closer to human thinking
or brain mechanisms such as recurrence, both of which form complex networks.

---------------

### 16 Aug 2023 | [Boosting Logical Reasoning in Large Language Models through a New  Framework: The Graph of Thought](https://arxiv.org/abs/2308.08614) | [⬇️](https://arxiv.org/pdf/2308.08614)
*Bin Lei, pei-Hung Lin, Chunhua Liao, Caiwen Ding* 

  Recent advancements in large-scale models, such as GPT-4, have showcased
remarkable capabilities in addressing standard queries. However, when facing
complex problems that require multi-step logical reasoning, their accuracy
dramatically decreases. Current research has explored the realm of
\textit{prompting engineering} to bolster the inferential capacities of these
models. Our paper unveils a pioneering prompting technique, dubbed
\textit{Graph of Thoughts (GoT)}. Through testing on a trio of escalating
challenges: the 24-point game, resolution of high-degree polynomial equations,
and derivation of formulas for recursive sequences, our method outperformed
GPT-4, achieving accuracy improvements of $89.7\%$, $86\%$, and $56\%$ for each
respective task. Moreover, when juxtaposed with the state-of-the-art (SOTA)
prompting method, \textit{Tree of Thought (ToT)}, our approach registered an
average accuracy boost of $23\%$, $24\%$, and $15\%$.

---------------

### 14 Nov 2023 | [Empowering Multi-step Reasoning across Languages via Tree-of-Thoughts](https://arxiv.org/abs/2311.08097) | [⬇️](https://arxiv.org/pdf/2311.08097)
*Leonardo Ranaldi, Fabio Massimo Zanzotto* 

  Chain-of-Thought (CoT) prompting empowers the reasoning abilities of Large
Language Models (LLMs), eliciting them to solve complex reasoning tasks
step-by-step. However, with the success of CoT methods, the ability to deliver
multi-step reasoning remains limited to English due to the imbalance in the
distribution of the pre-training data, making the other languages a barrier.
  In this work, we propose a Cross-lingual multi-step reasoning approach,
aiming to align reasoning processes across different languages. In particular,
our method, through a Self-consistent Cross-lingual prompting mechanism
inspired by the Tree-of-Thoughts approach, delivers multi-step reasoning paths
in different languages that, during the steps, lead to the final solution. Our
experimental evaluations show that our method significantly outperforms
existing prompting methods, reducing the number of interactions and achieving
state-of-the-art performance.

---------------

### 09 Feb 2024 | [Alphazero-like Tree-Search can Guide Large Language Model Decoding and  Training](https://arxiv.org/abs/2309.17179) | [⬇️](https://arxiv.org/pdf/2309.17179)
*Xidong Feng, Ziyu Wan, Muning Wen, Stephen Marcus McAleer, Ying Wen,  Weinan Zhang, Jun Wang* 

  Recent works like Tree-of-Thought (ToT) and Reasoning via Planning (RAP) aim
to augment the reasoning capabilities of LLMs by using tree-search algorithms
to guide multi-step reasoning. These methods rely on prompting a pre-trained
model to serve as a value function and focus on problems with low search depth.
As a result, these methods will not work in domains where the pre-trained LLM
does not have enough knowledge to serve as an effective value function or in
domains that require long-horizon planning. To address these limitations, we
present an AlphaZero-like tree-search learning framework for LLMs (termed
TS-LLM), systematically illustrating how tree-search with a learned value
function can guide LLM decoding. TS-LLM distinguishes itself in two key ways.
(1) Leveraging a learned value function and AlphaZero-like algorithms, our
approach can be generally adaptable to a wide range of tasks, language models
of any size, and tasks of varying search depths. (2) Our approach can guide
LLMs during both inference and training, iteratively improving the LLM.
Empirical results across reasoning, planning, alignment, and decision-making
tasks show that TS-LLM outperforms existing approaches and can handle trees
with a depth of 64.

---------------

### 28 Sep 2023 | [Algorithm of Thoughts: Enhancing Exploration of Ideas in Large Language  Models](https://arxiv.org/abs/2308.10379) | [⬇️](https://arxiv.org/pdf/2308.10379)
*Bilgehan Sel, Ahmad Al-Tawaha, Vanshaj Khattar, Ruoxi Jia, Ming Jin* 

  Current literature, aiming to surpass the "Chain-of-Thought" approach, often
resorts to an external modus operandi involving halting, modifying, and then
resuming the generation process to boost Large Language Models' (LLMs)
reasoning capacities. This mode escalates the number of query requests, leading
to increased costs, memory, and computational overheads. Addressing this, we
propose the Algorithm of Thoughts -- a novel strategy that propels LLMs through
algorithmic reasoning pathways, pioneering a new mode of in-context learning.
By employing algorithmic examples, we exploit the innate recurrence dynamics of
LLMs, expanding their idea exploration with merely one or a few queries. Our
technique outperforms earlier single-query methods and stands on par with a
recent multi-query strategy that employs an extensive tree search algorithm.
Intriguingly, our results suggest that instructing an LLM using an algorithm
can lead to performance surpassing that of the algorithm itself, hinting at
LLM's inherent ability to weave its intuition into optimized searches. We probe
into the underpinnings of our method's efficacy and its nuances in application.

---------------

### 14 Oct 2023 | [Autonomous Tree-search Ability of Large Language Models](https://arxiv.org/abs/2310.10686) | [⬇️](https://arxiv.org/pdf/2310.10686)
*Zheyu Zhang and Zhuorui Ye and Yikang Shen and Chuang Gan* 

  Large Language Models have excelled in remarkable reasoning capabilities with
advanced prompting techniques, but they fall short on tasks that require
exploration, strategic foresight, and sequential decision-making. Recent works
propose to utilize external programs to define search logic, such that LLMs can
perform passive tree search to solve more challenging reasoning tasks. Though
impressive results have been achieved, there are several fundamental
limitations of these approaches. First, passive tree searches are not efficient
as they usually require multiple rounds of LLM API calls to solve one single
problem. Moreover, passive search methods are not flexible since they need
task-specific program designs. Then a natural question arises: can we maintain
the tree-search capability of LLMs without the aid of external programs, and
can still generate responses that clearly demonstrate the process of a
tree-structure search? To this end, we propose a new concept called autonomous
tree-search ability of LLM, which can automatically generate a response
containing search trajectories for the correct answer. Concretely, we perform
search trajectories using capable LLM API via a fixed system prompt, allowing
them to perform autonomous tree-search (ATS) right out of the box. Experiments
on 4 puzzle games demonstrate our method can achieve huge improvements. The
ATS-BFS method outperforms the Chain of Thought approach by achieving an
average accuracy improvement of 33%. Compared to Tree of Thoughts, it requires
65.6% or 47.7% less GPT-api cost to attain a comparable level of accuracy.
Moreover, we have collected data using the ATS prompt method and fine-tuned
LLaMA. This approach yield a greater improvement compared to the ones
fine-tuned on CoT data. Specifically, it outperforms CoT-tuned LLaMAs by an
average of 40.6% and 38.5% for LLaMA2-7B and LLaMA2-13B, respectively.

---------------

### 11 Jan 2024 | [Evidence to Generate (E2G): A Single-agent Two-step Prompting for  Context Grounded and Retrieval Augmented Reasoning](https://arxiv.org/abs/2401.05787) | [⬇️](https://arxiv.org/pdf/2401.05787)
*Md Rizwan Parvez* 

  While chain-of-thought (CoT) prompting has revolutionized how LLMs perform
reasoning tasks, its current methods and variations (e.g, Self-consistency,
ReACT, Reflexion, Tree-of-Thoughts (ToT), Cumulative Reasoning (CR)) suffer
from limitations like slowness, limited context grounding, hallucination and
inconsistent outputs. To overcome these challenges, we introduce Evidence to
Generate (E2G), a novel single-agent, two-step prompting framework. Instead of
unverified reasoning claims, this innovative approach leverages the power of
"evidence for decision making" by first focusing exclusively on the thought
sequences (the series of intermediate steps) explicitly mentioned in the
context which then serve as extracted evidence, guiding the LLM's output
generation process with greater precision and efficiency. This simple yet
powerful approach unlocks the true potential of chain-of-thought like
prompting, paving the way for faster, more reliable, and more contextually
aware reasoning in LLMs. \tool achieves remarkable results robustly across a
wide range of knowledge-intensive reasoning and generation tasks, surpassing
baseline approaches with state-of-the-art LLMs. For example, (i) on LogiQA
benchmark using GPT-4 as backbone model, \tool achieves a new state-of-the
Accuracy of 53.8% exceeding CoT by 18%, ToT by 11%, CR by 9% (ii) a variant of
E2G with PaLM2 outperforms the variable-shot performance of Gemini Ultra by 0.9
F1 points, reaching an F1 score of 83.3 on a subset of DROP.

---------------

### 02 Nov 2023 | [The Art of SOCRATIC QUESTIONING: Recursive Thinking with Large Language  Models](https://arxiv.org/abs/2305.14999) | [⬇️](https://arxiv.org/pdf/2305.14999)
*Jingyuan Qi, Zhiyang Xu, Ying Shen, Minqian Liu, Di Jin, Qifan Wang,  Lifu Huang* 

  Chain-of-Thought (CoT) prompting enables large language models to solve
complex reasoning problems by generating intermediate steps. However, confined
by its inherent single-pass and sequential generation process, CoT heavily
relies on the initial decisions, causing errors in early steps to accumulate
and impact the final answers. In contrast, humans adopt recursive thinking when
tackling complex reasoning problems, i.e., iteratively breaking the original
problem into approachable sub-problems and aggregating their answers to resolve
the original one. Inspired by the human cognitive process, we propose SOCRATIC
QUESTIONING, a divide-and-conquer style algorithm that mimics the recursive
thinking process. Specifically, SOCRATIC QUESTIONING leverages large language
models to raise and answer sub-questions until collecting enough information to
tackle the original question. Unlike CoT, SOCRATIC QUESTIONING explicitly
navigates the thinking space, stimulates effective recursive thinking, and is
more robust towards errors in the thinking process. Extensive experiments on
several complex reasoning tasks, including MMLU, MATH, LogiQA, and visual
question-answering demonstrate significant performance improvements over the
state-of-the-art prompting methods, such as CoT, and Tree-of-Thought. The
qualitative analysis clearly shows that the intermediate reasoning steps
elicited by SOCRATIC QUESTIONING are similar to humans' recursively thinking
process of complex reasoning problems.

---------------

### 04 Feb 2024 | [DefInt: A Default-interventionist Framework for Efficient Reasoning with  Hybrid Large Language Models](https://arxiv.org/abs/2402.02563) | [⬇️](https://arxiv.org/pdf/2402.02563)
*Yu Shang, Yu Li, Fengli Xu, Yong Li* 

  Large language models (LLMs) have shown impressive emergent abilities in a
wide range of tasks, but still face challenges in handling complex reasoning
problems. Previous works like chain-of-thought (CoT) and tree-of-thoughts(ToT)
have predominately focused on enhancing accuracy, but overlook the rapidly
increasing token cost, which could be particularly problematic for open-ended
real-world tasks with huge solution spaces. Motivated by the dual process
theory of human cognition, we propose a Default-Interventionist framework
(DefInt) to unleash the synergistic potential of hybrid LLMs. By default,
DefInt uses smaller-scale language models to generate low-cost reasoning
thoughts, which resembles the fast intuitions produced by System 1. If the
intuitions are considered with low confidence, DefInt will invoke the
reflective reasoning of scaled-up language models as the intervention of System
2, which can override the default thoughts and rectify the reasoning process.
Experiments on five representative reasoning tasks show that DefInt
consistently achieves state-of-the-art reasoning accuracy and solution
diversity. More importantly, it substantially reduces the token cost by 49%-79%
compared to the second accurate baselines. Specifically, the open-ended tasks
have an average 75% token cost reduction. Code repo with all prompts will be
released upon publication.

---------------

### 03 Dec 2023 | [Tree of Thoughts: Deliberate Problem Solving with Large Language Models](https://arxiv.org/abs/2305.10601) | [⬇️](https://arxiv.org/pdf/2305.10601)
*Shunyu Yao, Dian Yu, Jeffrey Zhao, Izhak Shafran, Thomas L. Griffiths,  Yuan Cao, Karthik Narasimhan* 

  Language models are increasingly being deployed for general problem solving
across a wide range of tasks, but are still confined to token-level,
left-to-right decision-making processes during inference. This means they can
fall short in tasks that require exploration, strategic lookahead, or where
initial decisions play a pivotal role. To surmount these challenges, we
introduce a new framework for language model inference, Tree of Thoughts (ToT),
which generalizes over the popular Chain of Thought approach to prompting
language models, and enables exploration over coherent units of text (thoughts)
that serve as intermediate steps toward problem solving. ToT allows LMs to
perform deliberate decision making by considering multiple different reasoning
paths and self-evaluating choices to decide the next course of action, as well
as looking ahead or backtracking when necessary to make global choices. Our
experiments show that ToT significantly enhances language models'
problem-solving abilities on three novel tasks requiring non-trivial planning
or search: Game of 24, Creative Writing, and Mini Crosswords. For instance, in
Game of 24, while GPT-4 with chain-of-thought prompting only solved 4% of
tasks, our method achieved a success rate of 74%. Code repo with all prompts:
https://github.com/princeton-nlp/tree-of-thought-llm.

---------------

### 21 Feb 2024 | [Tree of Attacks: Jailbreaking Black-Box LLMs Automatically](https://arxiv.org/abs/2312.02119) | [⬇️](https://arxiv.org/pdf/2312.02119)
*Anay Mehrotra, Manolis Zampetakis, Paul Kassianik, Blaine Nelson,  Hyrum Anderson, Yaron Singer, Amin Karbasi* 

  While Large Language Models (LLMs) display versatile functionality, they
continue to generate harmful, biased, and toxic content, as demonstrated by the
prevalence of human-designed jailbreaks. In this work, we present Tree of
Attacks with Pruning (TAP), an automated method for generating jailbreaks that
only requires black-box access to the target LLM. TAP utilizes an LLM to
iteratively refine candidate (attack) prompts using tree-of-thought reasoning
until one of the generated prompts jailbreaks the target. Crucially, before
sending prompts to the target, TAP assesses them and prunes the ones unlikely
to result in jailbreaks. Using tree-of-thought reasoning allows TAP to navigate
a large search space of prompts and pruning reduces the total number of queries
sent to the target. In empirical evaluations, we observe that TAP generates
prompts that jailbreak state-of-the-art LLMs (including GPT4 and GPT4-Turbo)
for more than 80% of the prompts using only a small number of queries.
Interestingly, TAP is also capable of jailbreaking LLMs protected by
state-of-the-art guardrails, e.g., LlamaGuard. This significantly improves upon
the previous state-of-the-art black-box method for generating jailbreaks.

---------------

### 08 Nov 2023 | [Chain-of-Thought Reasoning is a Policy Improvement Operator](https://arxiv.org/abs/2309.08589) | [⬇️](https://arxiv.org/pdf/2309.08589)
*Hugh Zhang, David C. Parkes* 

  Large language models have astounded the world with fascinating new
capabilities. However, they currently lack the ability to teach themselves new
skills, relying instead on large amounts of human-generated training data. We
introduce SECToR (Self-Education via Chain-of-Thought Reasoning), a
proof-of-concept demonstration that language models can teach themselves new
skills using chain-of-thought reasoning. During the self-learning loop, SECToR
asks models to solve addition problems using chain-of-thought reasoning before
training the next version of the model to solve those same problems directly
without using such reasoning. This process often results in an improved model
which can, when again augmented with chain-of-thought reasoning, solve even
harder problems than the original model, allowing the self-learning loop to
continue. Language models trained via SECToR autonomously learn to add up to
the longest-length-digit numbers without access to any ground truth examples
beyond an initial supervised fine-tuning phase consisting only of numbers with
6 or fewer digits. Our central hypothesis is that chain-of-thought reasoning
can act as a policy improvement operator, similarly to how Monte-Carlo Tree
Search is used in AlphaZero (Silver et al., 2017). We hope that this research
can lead to new directions in which language models can learn to teach
themselves without the need for human demonstrations.

---------------

### 23 Oct 2023 | [Reasoning with Language Model is Planning with World Model](https://arxiv.org/abs/2305.14992) | [⬇️](https://arxiv.org/pdf/2305.14992)
*Shibo Hao, Yi Gu, Haodi Ma, Joshua Jiahua Hong, Zhen Wang, Daisy Zhe  Wang, Zhiting Hu* 

  Large language models (LLMs) have shown remarkable reasoning capabilities,
especially when prompted to generate intermediate reasoning steps (e.g.,
Chain-of-Thought, CoT). However, LLMs can still struggle with problems that are
easy for humans, such as generating action plans for executing tasks in a given
environment, or performing complex math, logical, and commonsense reasoning.
The deficiency stems from the key fact that LLMs lack an internal
$\textit{world model}$ to predict the world $\textit{state}$ (e.g., environment
status, intermediate variable values) and simulate long-term outcomes of
actions. This prevents LLMs from performing deliberate planning akin to human
brains, which involves exploring alternative reasoning paths, anticipating
future states and rewards, and iteratively refining existing reasoning steps.
To overcome the limitations, we propose a new LLM reasoning framework,
$\underline{R}$easoning vi$\underline{a}$ $\underline{P}$lanning
$\textbf{(RAP)}$. RAP repurposes the LLM as both a world model and a reasoning
agent, and incorporates a principled planning algorithm (based on Monto Carlo
Tree Search) for strategic exploration in the vast reasoning space. During
reasoning, the LLM (as agent) incrementally builds a reasoning tree under the
guidance of the LLM (as world model) and task-specific rewards, and obtains a
high-reward reasoning path efficiently with a proper balance between
exploration $\textit{vs.}$ exploitation. We apply RAP to a variety of
challenging reasoning problems including plan generation, math reasoning, and
logical inference. Empirical results on these tasks demonstrate the superiority
of RAP over various strong baselines, including CoT and least-to-most prompting
with self-consistency. RAP on LLAMA-33B surpasses CoT on GPT-4 with 33%
relative improvement in a plan generation setting.

---------------

### 25 Jan 2024 | [Topologies of Reasoning: Demystifying Chains, Trees, and Graphs of  Thoughts](https://arxiv.org/abs/2401.14295) | [⬇️](https://arxiv.org/pdf/2401.14295)
*Maciej Besta, Florim Memedi, Zhenyu Zhang, Robert Gerstenberger, Nils  Blach, Piotr Nyczyk, Marcin Copik, Grzegorz Kwa\'sniewski, J\"urgen M\"uller,  Lukas Gianinazzi, Ales Kubicek, Hubert Niewiadomski, Onur Mutlu, Torsten  Hoefler* 

  The field of natural language processing (NLP) has witnessed significant
progress in recent years, with a notable focus on improving large language
models' (LLM) performance through innovative prompting techniques. Among these,
prompt engineering coupled with structures has emerged as a promising paradigm,
with designs such as Chain-of-Thought, Tree of Thoughts, or Graph of Thoughts,
in which the overall LLM reasoning is guided by a structure such as a graph. As
illustrated with numerous examples, this paradigm significantly enhances the
LLM's capability to solve numerous tasks, ranging from logical or mathematical
reasoning to planning or creative writing. To facilitate the understanding of
this growing field and pave the way for future developments, we devise a
general blueprint for effective and efficient LLM reasoning schemes. For this,
we conduct an in-depth analysis of the prompt execution pipeline, clarifying
and clearly defining different concepts. We then build the first taxonomy of
structure-enhanced LLM reasoning schemes. We focus on identifying fundamental
classes of harnessed structures, and we analyze the representations of these
structures, algorithms executed with these structures, and many others. We
refer to these structures as reasoning topologies, because their representation
becomes to a degree spatial, as they are contained within the LLM context. Our
study compares existing prompting schemes using the proposed taxonomy,
discussing how certain design choices lead to different patterns in performance
and cost. We also outline theoretical underpinnings, relationships between
prompting and others parts of the LLM ecosystem such as knowledge bases, and
the associated research challenges. Our work will help to advance future prompt
engineering techniques.

---------------

### 12 Nov 2023 | [From Complex to Simple: Unraveling the Cognitive Tree for Reasoning with  Small Language Models](https://arxiv.org/abs/2311.06754) | [⬇️](https://arxiv.org/pdf/2311.06754)
*Junbing Yan, Chengyu Wang, Taolin Zhang, Xiaofeng He, Jun Huang, Wei  Zhang* 

  Reasoning is a distinctive human capacity, enabling us to address complex
problems by breaking them down into a series of manageable cognitive steps.
Yet, complex logical reasoning is still cumbersome for language models. Based
on the dual process theory in cognitive science, we are the first to unravel
the cognitive reasoning abilities of language models. Our framework employs an
iterative methodology to construct a Cognitive Tree (CogTree). The root node of
this tree represents the initial query, while the leaf nodes consist of
straightforward questions that can be answered directly. This construction
involves two main components: the implicit extraction module (referred to as
the intuitive system) and the explicit reasoning module (referred to as the
reflective system). The intuitive system rapidly generates multiple responses
by utilizing in-context examples, while the reflective system scores these
responses using comparative learning. The scores guide the intuitive system in
its subsequent generation step. Our experimental results on two popular and
challenging reasoning tasks indicate that it is possible to achieve a
performance level comparable to that of GPT-3.5 (with 175B parameters), using a
significantly smaller language model that contains fewer parameters (<=7B) than
5% of GPT-3.5.

---------------
**Date:** 14 Sep 2023

**Title:** Tree of Uncertain Thoughts Reasoning for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2309.07694](https://arxiv.org/abs/2309.07694)

**PDF Link:** [https://arxiv.org/pdf/2309.07694](https://arxiv.org/pdf/2309.07694)

---

**Date:** 17 Feb 2024

**Title:** Boosting of Thoughts: Trial-and-Error Problem Solving with Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.11140](https://arxiv.org/abs/2402.11140)

**PDF Link:** [https://arxiv.org/pdf/2402.11140](https://arxiv.org/pdf/2402.11140)

---

**Date:** 15 May 2023

**Title:** Large Language Model Guided Tree-of-Thought

**Abstract Link:** [https://arxiv.org/abs/2305.08291](https://arxiv.org/abs/2305.08291)

**PDF Link:** [https://arxiv.org/pdf/2305.08291](https://arxiv.org/pdf/2305.08291)

---

**Date:** 23 Nov 2023

**Title:** Probabilistic Tree-of-thought Reasoning for Answering  Knowledge-intensive Complex Questions

**Abstract Link:** [https://arxiv.org/abs/2311.13982](https://arxiv.org/abs/2311.13982)

**PDF Link:** [https://arxiv.org/pdf/2311.13982](https://arxiv.org/pdf/2311.13982)

---

**Date:** 22 May 2023

**Title:** Enhance Reasoning Ability of Visual-Language Models via Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2305.13267](https://arxiv.org/abs/2305.13267)

**PDF Link:** [https://arxiv.org/pdf/2305.13267](https://arxiv.org/pdf/2305.13267)

---

**Date:** 06 Feb 2024

**Title:** Graph of Thoughts: Solving Elaborate Problems with Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2308.09687](https://arxiv.org/abs/2308.09687)

**PDF Link:** [https://arxiv.org/pdf/2308.09687](https://arxiv.org/pdf/2308.09687)

---

**Date:** 16 Aug 2023

**Title:** Boosting Logical Reasoning in Large Language Models through a New  Framework: The Graph of Thought

**Abstract Link:** [https://arxiv.org/abs/2308.08614](https://arxiv.org/abs/2308.08614)

**PDF Link:** [https://arxiv.org/pdf/2308.08614](https://arxiv.org/pdf/2308.08614)

---

**Date:** 14 Nov 2023

**Title:** Empowering Multi-step Reasoning across Languages via Tree-of-Thoughts

**Abstract Link:** [https://arxiv.org/abs/2311.08097](https://arxiv.org/abs/2311.08097)

**PDF Link:** [https://arxiv.org/pdf/2311.08097](https://arxiv.org/pdf/2311.08097)

---

**Date:** 09 Feb 2024

**Title:** Alphazero-like Tree-Search can Guide Large Language Model Decoding and  Training

**Abstract Link:** [https://arxiv.org/abs/2309.17179](https://arxiv.org/abs/2309.17179)

**PDF Link:** [https://arxiv.org/pdf/2309.17179](https://arxiv.org/pdf/2309.17179)

---

**Date:** 28 Sep 2023

**Title:** Algorithm of Thoughts: Enhancing Exploration of Ideas in Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2308.10379](https://arxiv.org/abs/2308.10379)

**PDF Link:** [https://arxiv.org/pdf/2308.10379](https://arxiv.org/pdf/2308.10379)

---

**Date:** 14 Oct 2023

**Title:** Autonomous Tree-search Ability of Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.10686](https://arxiv.org/abs/2310.10686)

**PDF Link:** [https://arxiv.org/pdf/2310.10686](https://arxiv.org/pdf/2310.10686)

---

**Date:** 11 Jan 2024

**Title:** Evidence to Generate (E2G): A Single-agent Two-step Prompting for  Context Grounded and Retrieval Augmented Reasoning

**Abstract Link:** [https://arxiv.org/abs/2401.05787](https://arxiv.org/abs/2401.05787)

**PDF Link:** [https://arxiv.org/pdf/2401.05787](https://arxiv.org/pdf/2401.05787)

---

**Date:** 02 Nov 2023

**Title:** The Art of SOCRATIC QUESTIONING: Recursive Thinking with Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2305.14999](https://arxiv.org/abs/2305.14999)

**PDF Link:** [https://arxiv.org/pdf/2305.14999](https://arxiv.org/pdf/2305.14999)

---

**Date:** 04 Feb 2024

**Title:** DefInt: A Default-interventionist Framework for Efficient Reasoning with  Hybrid Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.02563](https://arxiv.org/abs/2402.02563)

**PDF Link:** [https://arxiv.org/pdf/2402.02563](https://arxiv.org/pdf/2402.02563)

---

**Date:** 03 Dec 2023

**Title:** Tree of Thoughts: Deliberate Problem Solving with Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2305.10601](https://arxiv.org/abs/2305.10601)

**PDF Link:** [https://arxiv.org/pdf/2305.10601](https://arxiv.org/pdf/2305.10601)

---

**Date:** 21 Feb 2024

**Title:** Tree of Attacks: Jailbreaking Black-Box LLMs Automatically

**Abstract Link:** [https://arxiv.org/abs/2312.02119](https://arxiv.org/abs/2312.02119)

**PDF Link:** [https://arxiv.org/pdf/2312.02119](https://arxiv.org/pdf/2312.02119)

---

**Date:** 08 Nov 2023

**Title:** Chain-of-Thought Reasoning is a Policy Improvement Operator

**Abstract Link:** [https://arxiv.org/abs/2309.08589](https://arxiv.org/abs/2309.08589)

**PDF Link:** [https://arxiv.org/pdf/2309.08589](https://arxiv.org/pdf/2309.08589)

---

**Date:** 23 Oct 2023

**Title:** Reasoning with Language Model is Planning with World Model

**Abstract Link:** [https://arxiv.org/abs/2305.14992](https://arxiv.org/abs/2305.14992)

**PDF Link:** [https://arxiv.org/pdf/2305.14992](https://arxiv.org/pdf/2305.14992)

---

**Date:** 25 Jan 2024

**Title:** Topologies of Reasoning: Demystifying Chains, Trees, and Graphs of  Thoughts

**Abstract Link:** [https://arxiv.org/abs/2401.14295](https://arxiv.org/abs/2401.14295)

**PDF Link:** [https://arxiv.org/pdf/2401.14295](https://arxiv.org/pdf/2401.14295)

---

**Date:** 12 Nov 2023

**Title:** From Complex to Simple: Unraveling the Cognitive Tree for Reasoning with  Small Language Models

**Abstract Link:** [https://arxiv.org/abs/2311.06754](https://arxiv.org/abs/2311.06754)

**PDF Link:** [https://arxiv.org/pdf/2311.06754](https://arxiv.org/pdf/2311.06754)

---

