Sparse Neural Networks 🕸️

### 🔎 Sparse Neural Networks 🕸️


=========================

This repository contains the code for the paper:

> **Sparse Neural Networks: A Review**
>
> *Jonas Gehring, Matthias Minderer, Matthias Bethge*
>
> *arXiv:1702.01550*

The code is written in Python and uses TensorFlow as the deep learning framework.


Installation
------------

To install the required packages, run

    pip install -r requirements.txt


Usage
-----

To run the code, simply execute

    python main.py

This will train a sparse neural network on the MNIST dataset.


License
-------

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details.


Acknowledgments
---------------

This code is based on the [TensorFlow tutorial](https://www.tensorflow.org/tutorials/mnist/pros/index.html) for training a neural network on the MNIST dataset.


Contact
-------

Jonas Gehring <jonas.gehring@tuebingen.mpg.de>

Matthias Minderer <matthias.minderer@tuebingen.mpg.de>

Matthias Bethge <matthias.bethge@tuebingen.mpg.de></s>
# 🩺🔍 Search Results
### 27 Apr 2021 | [Explore the Knowledge contained in Network Weights to Obtain Sparse  Neural Networks](https://arxiv.org/abs/2103.15590) | [⬇️](https://arxiv.org/pdf/2103.15590)
*Mengqiao Han, Xiabi Liu, Zhaoyang Hai, Zhengwen Li* 

  Sparse neural networks are important for achieving better generalization and
enhancing computation efficiency. This paper proposes a novel learning approach
to obtain sparse fully connected layers in neural networks (NNs) automatically.
We design a switcher neural network (SNN) to optimize the structure of the task
neural network (TNN). The SNN takes the weights of the TNN as the inputs and
its outputs are used to switch the connections of TNN. In this way, the
knowledge contained in the weights of TNN is explored to determine the
importance of each connection and the structure of TNN consequently. The SNN
and TNN are learned alternately with stochastic gradient descent (SGD)
optimization, targeting at a common objective. After learning, we achieve the
optimal structure and the optimal parameters of the TNN simultaneously. In
order to evaluate the proposed approach, we conduct image classification
experiments on various network structures and datasets. The network structures
include LeNet, ResNet18, ResNet34, VggNet16 and MobileNet. The datasets include
MNIST, CIFAR10 and CIFAR100. The experimental results show that our approach
can stably lead to sparse and well-performing fully connected layers in NNs.

---------------

### 28 Dec 2018 | [Hierarchical Block Sparse Neural Networks](https://arxiv.org/abs/1808.03420) | [⬇️](https://arxiv.org/pdf/1808.03420)
*Dharma Teja Vooturi, Dheevatsa Mudigere, Sasikanth Avancha* 

  Sparse deep neural networks(DNNs) are efficient in both memory and compute
when compared to dense DNNs. But due to irregularity in computation of sparse
DNNs, their efficiencies are much lower than that of dense DNNs on regular
parallel hardware such as TPU. This inefficiency leads to poor/no performance
benefits for sparse DNNs. Performance issue for sparse DNNs can be alleviated
by bringing structure to the sparsity and leveraging it for improving runtime
efficiency. But such structural constraints often lead to suboptimal
accuracies. In this work, we jointly address both accuracy and performance of
sparse DNNs using our proposed class of sparse neural networks called HBsNN
(Hierarchical Block sparse Neural Networks). For a given sparsity, HBsNN models
achieve better runtime performance than unstructured sparse models and better
accuracy than highly structured sparse models.

---------------

### 03 Mar 2023 | [Sparsity May Cry: Let Us Fail (Current) Sparse Neural Networks Together!](https://arxiv.org/abs/2303.02141) | [⬇️](https://arxiv.org/pdf/2303.02141)
*Shiwei Liu, Tianlong Chen, Zhenyu Zhang, Xuxi Chen, Tianjin Huang,  Ajay Jaiswal, Zhangyang Wang* 

  Sparse Neural Networks (SNNs) have received voluminous attention
predominantly due to growing computational and memory footprints of
consistently exploding parameter count in large-scale models. Similar to their
dense counterparts, recent SNNs generalize just as well and are equipped with
numerous favorable benefits (e.g., low complexity, high scalability, and
robustness), sometimes even better than the original dense networks. As
research effort is focused on developing increasingly sophisticated sparse
algorithms, it is startling that a comprehensive benchmark to evaluate the
effectiveness of these algorithms has been highly overlooked. In absence of a
carefully crafted evaluation benchmark, most if not all, sparse algorithms are
evaluated against fairly simple and naive tasks (eg. CIFAR, ImageNet, GLUE,
etc.), which can potentially camouflage many advantages as well unexpected
predicaments of SNNs. In pursuit of a more general evaluation and unveiling the
true potential of sparse algorithms, we introduce "Sparsity May Cry" Benchmark
(SMC-Bench), a collection of carefully-curated 4 diverse tasks with 10
datasets, that accounts for capturing a wide range of domain-specific and
sophisticated knowledge. Our systemic evaluation of the most representative
sparse algorithms reveals an important obscured observation: the
state-of-the-art magnitude- and/or gradient-based sparse algorithms seemingly
fail to perform on SMC-Bench when applied out-of-the-box, sometimes at
significantly trivial sparsity as low as 5%. By incorporating these
well-thought and diverse tasks, SMC-Bench is designed to favor and encourage
the development of more scalable and generalizable sparse algorithms.

---------------

### 04 Jul 2020 | [Topological Insights into Sparse Neural Networks](https://arxiv.org/abs/2006.14085) | [⬇️](https://arxiv.org/pdf/2006.14085)
*Shiwei Liu, Tim Van der Lee, Anil Yaman, Zahra Atashgahi, Davide  Ferraro, Ghada Sokar, Mykola Pechenizkiy, Decebal Constantin Mocanu* 

  Sparse neural networks are effective approaches to reduce the resource
requirements for the deployment of deep neural networks. Recently, the concept
of adaptive sparse connectivity, has emerged to allow training sparse neural
networks from scratch by optimizing the sparse structure during training.
However, comparing different sparse topologies and determining how sparse
topologies evolve during training, especially for the situation in which the
sparse structure optimization is involved, remain as challenging open
questions. This comparison becomes increasingly complex as the number of
possible topological comparisons increases exponentially with the size of
networks. In this work, we introduce an approach to understand and compare
sparse neural network topologies from the perspective of graph theory. We first
propose Neural Network Sparse Topology Distance (NNSTD) to measure the distance
between different sparse neural networks. Further, we demonstrate that sparse
neural networks can outperform over-parameterized models in terms of
performance, even without any further structure optimization. To the end, we
also show that adaptive sparse connectivity can always unveil a plenitude of
sparse sub-networks with very different topologies which outperform the dense
model, by quantifying and comparing their topological evolutionary processes.
The latter findings complement the Lottery Ticket Hypothesis by showing that
there is a much more efficient and robust way to find "winning tickets".
Altogether, our results start enabling a better theoretical understanding of
sparse neural networks, and demonstrate the utility of using graph theory to
analyze them.

---------------

### 14 Sep 2018 | [Neural Network Topologies for Sparse Training](https://arxiv.org/abs/1809.05242) | [⬇️](https://arxiv.org/pdf/1809.05242)
*Ryan A. Robinett and Jeremy Kepner* 

  The sizes of deep neural networks (DNNs) are rapidly outgrowing the capacity
of hardware to store and train them. Research over the past few decades has
explored the prospect of sparsifying DNNs before, during, and after training by
pruning edges from the underlying topology. The resulting neural network is
known as a sparse neural network. More recent work has demonstrated the
remarkable result that certain sparse DNNs can train to the same precision as
dense DNNs at lower runtime and storage cost. An intriguing class of these
sparse DNNs is the X-Nets, which are initialized and trained upon a sparse
topology with neither reference to a parent dense DNN nor subsequent pruning.
We present an algorithm that deterministically generates sparse DNN topologies
that, as a whole, are much more diverse than X-Net topologies, while preserving
X-Nets' desired characteristics.

---------------

### 30 Apr 2019 | [RadiX-Net: Structured Sparse Matrices for Deep Neural Networks](https://arxiv.org/abs/1905.00416) | [⬇️](https://arxiv.org/pdf/1905.00416)
*Ryan A. Robinett and Jeremy Kepner* 

  The sizes of deep neural networks (DNNs) are rapidly outgrowing the capacity
of hardware to store and train them. Research over the past few decades has
explored the prospect of sparsifying DNNs before, during, and after training by
pruning edges from the underlying topology. The resulting neural network is
known as a sparse neural network. More recent work has demonstrated the
remarkable result that certain sparse DNNs can train to the same precision as
dense DNNs at lower runtime and storage cost. An intriguing class of these
sparse DNNs is the X-Nets, which are initialized and trained upon a sparse
topology with neither reference to a parent dense DNN nor subsequent pruning.
We present an algorithm that deterministically generates RadiX-Nets: sparse DNN
topologies that, as a whole, are much more diverse than X-Net topologies, while
preserving X-Nets' desired characteristics. We further present a
functional-analytic conjecture based on the longstanding observation that
sparse neural network topologies can attain the same expressive power as dense
counterparts

---------------

### 18 Jun 2017 | [Sparse Neural Networks Topologies](https://arxiv.org/abs/1706.05683) | [⬇️](https://arxiv.org/pdf/1706.05683)
*Alfred Bourely, John Patrick Boueri, Krzysztof Choromonski* 

  We propose Sparse Neural Network architectures that are based on random or
structured bipartite graph topologies. Sparse architectures provide compression
of the models learned and speed-ups of computations, they can also surpass
their unstructured or fully connected counterparts. As we show, even more
compact topologies of the so-called SNN (Sparse Neural Network) can be achieved
with the use of structured graphs of connections between consecutive layers of
neurons. In this paper, we investigate how the accuracy and training speed of
the models depend on the topology and sparsity of the neural network. Previous
approaches using sparcity are all based on fully connected neural network
models and create sparcity during training phase, instead we explicitly define
a sparse architectures of connections before the training. Building compact
neural network models is coherent with empirical observations showing that
there is much redundancy in learned neural network models. We show
experimentally that the accuracy of the models learned with neural networks
depends on expander-like properties of the underlying topologies such as the
spectral gap and algebraic connectivity rather than the density of the graphs
of connections.

---------------

### 16 Aug 2023 | [HyperSparse Neural Networks: Shifting Exploration to Exploitation  through Adaptive Regularization](https://arxiv.org/abs/2308.07163) | [⬇️](https://arxiv.org/pdf/2308.07163)
*Patrick Glandorf and Timo Kaiser and Bodo Rosenhahn* 

  Sparse neural networks are a key factor in developing resource-efficient
machine learning applications. We propose the novel and powerful sparse
learning method Adaptive Regularized Training (ART) to compress dense into
sparse networks. Instead of the commonly used binary mask during training to
reduce the number of model weights, we inherently shrink weights close to zero
in an iterative manner with increasing weight regularization. Our method
compresses the pre-trained model knowledge into the weights of highest
magnitude. Therefore, we introduce a novel regularization loss named
HyperSparse that exploits the highest weights while conserving the ability of
weight exploration. Extensive experiments on CIFAR and TinyImageNet show that
our method leads to notable performance gains compared to other sparsification
methods, especially in extremely high sparsity regimes up to 99.8 percent model
sparsity. Additional investigations provide new insights into the patterns that
are encoded in weights with high magnitudes.

---------------

### 28 Dec 2023 | [SparseProp: Efficient Event-Based Simulation and Training of Sparse  Recurrent Spiking Neural Networks](https://arxiv.org/abs/2312.17216) | [⬇️](https://arxiv.org/pdf/2312.17216)
*Rainer Engelken* 

  Spiking Neural Networks (SNNs) are biologically-inspired models that are
capable of processing information in streams of action potentials. However,
simulating and training SNNs is computationally expensive due to the need to
solve large systems of coupled differential equations. In this paper, we
introduce SparseProp, a novel event-based algorithm for simulating and training
sparse SNNs. Our algorithm reduces the computational cost of both the forward
and backward pass operations from O(N) to O(log(N)) per network spike, thereby
enabling numerically exact simulations of large spiking networks and their
efficient training using backpropagation through time. By leveraging the
sparsity of the network, SparseProp eliminates the need to iterate through all
neurons at each spike, employing efficient state updates instead. We
demonstrate the efficacy of SparseProp across several classical
integrate-and-fire neuron models, including a simulation of a sparse SNN with
one million LIF neurons. This results in a speed-up exceeding four orders of
magnitude relative to previous event-based implementations. Our work provides
an efficient and exact solution for training large-scale spiking neural
networks and opens up new possibilities for building more sophisticated
brain-inspired models.

---------------

### 15 Jun 2021 | [Selfish Sparse RNN Training](https://arxiv.org/abs/2101.09048) | [⬇️](https://arxiv.org/pdf/2101.09048)
*Shiwei Liu, Decebal Constantin Mocanu, Yulong Pei, Mykola Pechenizkiy* 

  Sparse neural networks have been widely applied to reduce the computational
demands of training and deploying over-parameterized deep neural networks. For
inference acceleration, methods that discover a sparse network from a
pre-trained dense network (dense-to-sparse training) work effectively.
Recently, dynamic sparse training (DST) has been proposed to train sparse
neural networks without pre-training a dense model (sparse-to-sparse training),
so that the training process can also be accelerated. However, previous
sparse-to-sparse methods mainly focus on Multilayer Perceptron Networks (MLPs)
and Convolutional Neural Networks (CNNs), failing to match the performance of
dense-to-sparse methods in the Recurrent Neural Networks (RNNs) setting. In
this paper, we propose an approach to train intrinsically sparse RNNs with a
fixed parameter count in one single run, without compromising performance.
During training, we allow RNN layers to have a non-uniform redistribution
across cell gates for better regularization. Further, we propose SNT-ASGD, a
novel variant of the averaged stochastic gradient optimizer, which
significantly improves the performance of all sparse training methods for RNNs.
Using these strategies, we achieve state-of-the-art sparse training results,
better than the dense-to-sparse methods, with various types of RNNs on Penn
TreeBank and Wikitext-2 datasets. Our codes are available at
https://github.com/Shiweiliuiiiiiii/Selfish-RNN.

---------------

### 05 Jun 2023 | [Learning Activation Functions for Sparse Neural Networks](https://arxiv.org/abs/2305.10964) | [⬇️](https://arxiv.org/pdf/2305.10964)
*Mohammad Loni, Aditya Mohan, Mehdi Asadi, Marius Lindauer* 

  Sparse Neural Networks (SNNs) can potentially demonstrate similar performance
to their dense counterparts while saving significant energy and memory at
inference. However, the accuracy drop incurred by SNNs, especially at high
pruning ratios, can be an issue in critical deployment conditions. While recent
works mitigate this issue through sophisticated pruning techniques, we shift
our focus to an overlooked factor: hyperparameters and activation functions.
Our analyses have shown that the accuracy drop can additionally be attributed
to (i) Using ReLU as the default choice for activation functions unanimously,
and (ii) Fine-tuning SNNs with the same hyperparameters as dense counterparts.
Thus, we focus on learning a novel way to tune activation functions for sparse
networks and combining these with a separate hyperparameter optimization (HPO)
regime for sparse networks. By conducting experiments on popular DNN models
(LeNet-5, VGG-16, ResNet-18, and EfficientNet-B0) trained on MNIST, CIFAR-10,
and ImageNet-16 datasets, we show that the novel combination of these two
approaches, dubbed Sparse Activation Function Search, short: SAFS, results in
up to 15.53%, 8.88%, and 6.33% absolute improvement in the accuracy for
LeNet-5, VGG-16, and ResNet-18 over the default training protocols, especially
at high pruning ratios. Our code can be found at https://github.com/automl/SAFS

---------------

### 10 Nov 2022 | [A Brain-inspired Algorithm for Training Highly Sparse Neural Networks](https://arxiv.org/abs/1903.07138) | [⬇️](https://arxiv.org/pdf/1903.07138)
*Zahra Atashgahi and Joost Pieterse and Shiwei Liu and Decebal  Constantin Mocanu and Raymond Veldhuis and Mykola Pechenizkiy* 

  Sparse neural networks attract increasing interest as they exhibit comparable
performance to their dense counterparts while being computationally efficient.
Pruning the dense neural networks is among the most widely used methods to
obtain a sparse neural network. Driven by the high training cost of such
methods that can be unaffordable for a low-resource device, training sparse
neural networks sparsely from scratch has recently gained attention. However,
existing sparse training algorithms suffer from various issues, including poor
performance in high sparsity scenarios, computing dense gradient information
during training, or pure random topology search. In this paper, inspired by the
evolution of the biological brain and the Hebbian learning theory, we present a
new sparse training approach that evolves sparse neural networks according to
the behavior of neurons in the network. Concretely, by exploiting the cosine
similarity metric to measure the importance of the connections, our proposed
method, Cosine similarity-based and Random Topology Exploration (CTRE), evolves
the topology of sparse neural networks by adding the most important connections
to the network without calculating dense gradient in the backward. We carried
out different experiments on eight datasets, including tabular, image, and text
datasets, and demonstrate that our proposed method outperforms several
state-of-the-art sparse training algorithms in extremely sparse neural networks
by a large gap. The implementation code is available on
https://github.com/zahraatashgahi/CTRE

---------------

### 09 Sep 2021 | [SONIC: A Sparse Neural Network Inference Accelerator with Silicon  Photonics for Energy-Efficient Deep Learning](https://arxiv.org/abs/2109.04459) | [⬇️](https://arxiv.org/pdf/2109.04459)
*Febin Sunny, Mahdi Nikdast, Sudeep Pasricha* 

  Sparse neural networks can greatly facilitate the deployment of neural
networks on resource-constrained platforms as they offer compact model sizes
while retaining inference accuracy. Because of the sparsity in parameter
matrices, sparse neural networks can, in principle, be exploited in accelerator
architectures for improved energy-efficiency and latency. However, to realize
these improvements in practice, there is a need to explore sparsity-aware
hardware-software co-design. In this paper, we propose a novel silicon
photonics-based sparse neural network inference accelerator called SONIC. Our
experimental analysis shows that SONIC can achieve up to 5.8x better
performance-per-watt and 8.4x lower energy-per-bit than state-of-the-art sparse
electronic neural network accelerators; and up to 13.8x better
performance-per-watt and 27.6x lower energy-per-bit than the best known
photonic neural network accelerators.

---------------

### 21 Dec 2021 | [Compact Multi-level Sparse Neural Networks with Input Independent  Dynamic Rerouting](https://arxiv.org/abs/2112.10930) | [⬇️](https://arxiv.org/pdf/2112.10930)
*Minghai Qin, Tianyun Zhang, Fei Sun, Yen-Kuang Chen, Makan Fardad,  Yanzhi Wang, Yuan Xie* 

  Deep neural networks (DNNs) have shown to provide superb performance in many
real life applications, but their large computation cost and storage
requirement have prevented them from being deployed to many edge and
internet-of-things (IoT) devices. Sparse deep neural networks, whose majority
weight parameters are zeros, can substantially reduce the computation
complexity and memory consumption of the models. In real-use scenarios, devices
may suffer from large fluctuations of the available computation and memory
resources under different environment, and the quality of service (QoS) is
difficult to maintain due to the long tail inferences with large latency.
Facing the real-life challenges, we propose to train a sparse model that
supports multiple sparse levels. That is, a hierarchical structure of weights
are satisfied such that the locations and the values of the non-zero parameters
of the more-sparse sub-model area subset of the less-sparse sub-model. In this
way, one can dynamically select the appropriate sparsity level during
inference, while the storage cost is capped by the least sparse sub-model. We
have verified our methodologies on a variety of DNN models and tasks, including
the ResNet-50, PointNet++, GNMT, and graph attention networks. We obtain sparse
sub-models with an average of 13.38% weights and 14.97% FLOPs, while the
accuracies are as good as their dense counterparts. More-sparse sub-models with
5.38% weights and 4.47% of FLOPs, which are subsets of the less-sparse ones,
can be obtained with only 3.25% relative accuracy loss.

---------------

### 02 Jul 2020 | [Ramanujan Bipartite Graph Products for Efficient Block Sparse Neural  Networks](https://arxiv.org/abs/2006.13486) | [⬇️](https://arxiv.org/pdf/2006.13486)
*Dharma Teja Vooturi, Girish Varma, Kishore Kothapalli* 

  Sparse neural networks are shown to give accurate predictions competitive to
denser versions, while also minimizing the number of arithmetic operations
performed. However current hardware like GPU's can only exploit structured
sparsity patterns for better efficiency. Hence the run time of a sparse neural
network may not correspond to the arithmetic operations required.
  In this work, we propose RBGP( Ramanujan Bipartite Graph Product) framework
for generating structured multi level block sparse neural networks by using the
theory of Graph products. We also propose to use products of Ramanujan graphs
which gives the best connectivity for a given level of sparsity. This
essentially ensures that the i.) the networks has the structured block sparsity
for which runtime efficient algorithms exists ii.) the model gives high
prediction accuracy, due to the better expressive power derived from the
connectivity of the graph iii.) the graph data structure has a succinct
representation that can be stored efficiently in memory. We use our framework
to design a specific connectivity pattern called RBGP4 which makes efficient
use of the memory hierarchy available on GPU. We benchmark our approach by
experimenting on image classification task over CIFAR dataset using VGG19 and
WideResnet-40-4 networks and achieve 5-9x and 2-5x runtime gains over
unstructured and block sparsity patterns respectively, while achieving the same
level of accuracy.

---------------

### 17 Jul 2018 | [Building Sparse Deep Feedforward Networks using Tree Receptive Fields](https://arxiv.org/abs/1803.05209) | [⬇️](https://arxiv.org/pdf/1803.05209)
*Xiaopeng Li, Zhourong Chen, Nevin L. Zhang* 

  Sparse connectivity is an important factor behind the success of
convolutional neural networks and recurrent neural networks. In this paper, we
consider the problem of learning sparse connectivity for feedforward neural
networks (FNNs). The key idea is that a unit should be connected to a small
number of units at the next level below that are strongly correlated. We use
Chow-Liu's algorithm to learn a tree-structured probabilistic model for the
units at the current level, use the tree to identify subsets of units that are
strongly correlated, and introduce a new unit with receptive field over the
subsets. The procedure is repeated on the new units to build multiple layers of
hidden units. The resulting model is called a TRF-net. Empirical results show
that, when compared to dense FNNs, TRF-net achieves better or comparable
classification performance with much fewer parameters and sparser structures.
They are also more interpretable.

---------------

### 17 May 2022 | [On the Landscape of One-hidden-layer Sparse Networks and Beyond](https://arxiv.org/abs/2009.07439) | [⬇️](https://arxiv.org/pdf/2009.07439)
*Dachao Lin, Ruoyu Sun, Zhihua Zhang* 

  Sparse neural networks have received increasing interest due to their small
size compared to dense networks. Nevertheless, most existing works on neural
network theory have focused on dense neural networks, and the understanding of
sparse networks is very limited. In this paper, we study the loss landscape of
one-hidden-layer sparse networks. First, we consider sparse networks with a
dense final layer. We show that linear networks can have no spurious valleys
under special sparse structures, and non-linear networks could also admit no
spurious valleys under a wide final layer. Second, we discover that spurious
valleys and spurious minima can exist for wide sparse networks with a sparse
final layer. This is different from wide dense networks which do not have
spurious valleys under mild assumptions.

---------------

### 06 Mar 2024 | [Sparse Spiking Neural Network: Exploiting Heterogeneity in Timescales  for Pruning Recurrent SNN](https://arxiv.org/abs/2403.03409) | [⬇️](https://arxiv.org/pdf/2403.03409)
*Biswadeep Chakraborty, Beomseok Kang, Harshit Kumar and Saibal  Mukhopadhyay* 

  Recurrent Spiking Neural Networks (RSNNs) have emerged as a computationally
efficient and brain-inspired learning model. The design of sparse RSNNs with
fewer neurons and synapses helps reduce the computational complexity of RSNNs.
Traditionally, sparse SNNs are obtained by first training a dense and complex
SNN for a target task, and, then, pruning neurons with low activity
(activity-based pruning) while maintaining task performance. In contrast, this
paper presents a task-agnostic methodology for designing sparse RSNNs by
pruning a large randomly initialized model. We introduce a novel Lyapunov Noise
Pruning (LNP) algorithm that uses graph sparsification methods and utilizes
Lyapunov exponents to design a stable sparse RSNN from a randomly initialized
RSNN. We show that the LNP can leverage diversity in neuronal timescales to
design a sparse Heterogeneous RSNN (HRSNN). Further, we show that the same
sparse HRSNN model can be trained for different tasks, such as image
classification and temporal prediction. We experimentally show that, in spite
of being task-agnostic, LNP increases computational efficiency (fewer neurons
and synapses) and prediction performance of RSNNs compared to traditional
activity-based pruning of trained dense models.

---------------

### 06 Jun 2023 | [ESL-SNNs: An Evolutionary Structure Learning Strategy for Spiking Neural  Networks](https://arxiv.org/abs/2306.03693) | [⬇️](https://arxiv.org/pdf/2306.03693)
*Jiangrong Shen, Qi Xu, Jian K. Liu, Yueming Wang, Gang Pan, Huajin  Tang* 

  Spiking neural networks (SNNs) have manifested remarkable advantages in power
consumption and event-driven property during the inference process. To take
full advantage of low power consumption and improve the efficiency of these
models further, the pruning methods have been explored to find sparse SNNs
without redundancy connections after training. However, parameter redundancy
still hinders the efficiency of SNNs during training. In the human brain, the
rewiring process of neural networks is highly dynamic, while synaptic
connections maintain relatively sparse during brain development. Inspired by
this, here we propose an efficient evolutionary structure learning (ESL)
framework for SNNs, named ESL-SNNs, to implement the sparse SNN training from
scratch. The pruning and regeneration of synaptic connections in SNNs evolve
dynamically during learning, yet keep the structural sparsity at a certain
level. As a result, the ESL-SNNs can search for optimal sparse connectivity by
exploring all possible parameters across time. Our experiments show that the
proposed ESL-SNNs framework is able to learn SNNs with sparse structures
effectively while reducing the limited accuracy. The ESL-SNNs achieve merely
0.28% accuracy loss with 10% connection density on the DVS-Cifar10 dataset. Our
work presents a brand-new approach for sparse training of SNNs from scratch
with biologically plausible evolutionary mechanisms, closing the gap in the
expressibility between sparse training and dense training. Hence, it has great
potential for SNN lightweight training and inference with low power consumption
and small memory usage.

---------------

### 06 Apr 2020 | [GraphChallenge.org Sparse Deep Neural Network Performance](https://arxiv.org/abs/2004.01181) | [⬇️](https://arxiv.org/pdf/2004.01181)
*Jeremy Kepner, Simon Alford, Vijay Gadepally, Michael Jones, Lauren  Milechin, Albert Reuther, Ryan Robinett, Sid Samsi* 

  The MIT/IEEE/Amazon GraphChallenge.org encourages community approaches to
developing new solutions for analyzing graphs and sparse data. Sparse AI
analytics present unique scalability difficulties. The Sparse Deep Neural
Network (DNN) Challenge draws upon prior challenges from machine learning, high
performance computing, and visual analytics to create a challenge that is
reflective of emerging sparse AI systems. The sparse DNN challenge is based on
a mathematically well-defined DNN inference computation and can be implemented
in any programming environment. In 2019 several sparse DNN challenge
submissions were received from a wide range of authors and organizations. This
paper presents a performance analysis of the best performers of these
submissions. These submissions show that their state-of-the-art sparse DNN
execution time, $T_{\rm DNN}$, is a strong function of the number of DNN
operations performed, $N_{\rm op}$. The sparse DNN challenge provides a clear
picture of current sparse DNN systems and underscores the need for new
innovations to achieve high performance on very large sparse DNNs.

---------------
**Date:** 27 Apr 2021

**Title:** Explore the Knowledge contained in Network Weights to Obtain Sparse  Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2103.15590](https://arxiv.org/abs/2103.15590)

**PDF Link:** [https://arxiv.org/pdf/2103.15590](https://arxiv.org/pdf/2103.15590)

---

**Date:** 28 Dec 2018

**Title:** Hierarchical Block Sparse Neural Networks

**Abstract Link:** [https://arxiv.org/abs/1808.03420](https://arxiv.org/abs/1808.03420)

**PDF Link:** [https://arxiv.org/pdf/1808.03420](https://arxiv.org/pdf/1808.03420)

---

**Date:** 03 Mar 2023

**Title:** Sparsity May Cry: Let Us Fail (Current) Sparse Neural Networks Together!

**Abstract Link:** [https://arxiv.org/abs/2303.02141](https://arxiv.org/abs/2303.02141)

**PDF Link:** [https://arxiv.org/pdf/2303.02141](https://arxiv.org/pdf/2303.02141)

---

**Date:** 04 Jul 2020

**Title:** Topological Insights into Sparse Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2006.14085](https://arxiv.org/abs/2006.14085)

**PDF Link:** [https://arxiv.org/pdf/2006.14085](https://arxiv.org/pdf/2006.14085)

---

**Date:** 14 Sep 2018

**Title:** Neural Network Topologies for Sparse Training

**Abstract Link:** [https://arxiv.org/abs/1809.05242](https://arxiv.org/abs/1809.05242)

**PDF Link:** [https://arxiv.org/pdf/1809.05242](https://arxiv.org/pdf/1809.05242)

---

**Date:** 30 Apr 2019

**Title:** RadiX-Net: Structured Sparse Matrices for Deep Neural Networks

**Abstract Link:** [https://arxiv.org/abs/1905.00416](https://arxiv.org/abs/1905.00416)

**PDF Link:** [https://arxiv.org/pdf/1905.00416](https://arxiv.org/pdf/1905.00416)

---

**Date:** 18 Jun 2017

**Title:** Sparse Neural Networks Topologies

**Abstract Link:** [https://arxiv.org/abs/1706.05683](https://arxiv.org/abs/1706.05683)

**PDF Link:** [https://arxiv.org/pdf/1706.05683](https://arxiv.org/pdf/1706.05683)

---

**Date:** 16 Aug 2023

**Title:** HyperSparse Neural Networks: Shifting Exploration to Exploitation  through Adaptive Regularization

**Abstract Link:** [https://arxiv.org/abs/2308.07163](https://arxiv.org/abs/2308.07163)

**PDF Link:** [https://arxiv.org/pdf/2308.07163](https://arxiv.org/pdf/2308.07163)

---

**Date:** 28 Dec 2023

**Title:** SparseProp: Efficient Event-Based Simulation and Training of Sparse  Recurrent Spiking Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2312.17216](https://arxiv.org/abs/2312.17216)

**PDF Link:** [https://arxiv.org/pdf/2312.17216](https://arxiv.org/pdf/2312.17216)

---

**Date:** 15 Jun 2021

**Title:** Selfish Sparse RNN Training

**Abstract Link:** [https://arxiv.org/abs/2101.09048](https://arxiv.org/abs/2101.09048)

**PDF Link:** [https://arxiv.org/pdf/2101.09048](https://arxiv.org/pdf/2101.09048)

---

**Date:** 05 Jun 2023

**Title:** Learning Activation Functions for Sparse Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2305.10964](https://arxiv.org/abs/2305.10964)

**PDF Link:** [https://arxiv.org/pdf/2305.10964](https://arxiv.org/pdf/2305.10964)

---

**Date:** 10 Nov 2022

**Title:** A Brain-inspired Algorithm for Training Highly Sparse Neural Networks

**Abstract Link:** [https://arxiv.org/abs/1903.07138](https://arxiv.org/abs/1903.07138)

**PDF Link:** [https://arxiv.org/pdf/1903.07138](https://arxiv.org/pdf/1903.07138)

---

**Date:** 09 Sep 2021

**Title:** SONIC: A Sparse Neural Network Inference Accelerator with Silicon  Photonics for Energy-Efficient Deep Learning

**Abstract Link:** [https://arxiv.org/abs/2109.04459](https://arxiv.org/abs/2109.04459)

**PDF Link:** [https://arxiv.org/pdf/2109.04459](https://arxiv.org/pdf/2109.04459)

---

**Date:** 21 Dec 2021

**Title:** Compact Multi-level Sparse Neural Networks with Input Independent  Dynamic Rerouting

**Abstract Link:** [https://arxiv.org/abs/2112.10930](https://arxiv.org/abs/2112.10930)

**PDF Link:** [https://arxiv.org/pdf/2112.10930](https://arxiv.org/pdf/2112.10930)

---

**Date:** 02 Jul 2020

**Title:** Ramanujan Bipartite Graph Products for Efficient Block Sparse Neural  Networks

**Abstract Link:** [https://arxiv.org/abs/2006.13486](https://arxiv.org/abs/2006.13486)

**PDF Link:** [https://arxiv.org/pdf/2006.13486](https://arxiv.org/pdf/2006.13486)

---

**Date:** 17 Jul 2018

**Title:** Building Sparse Deep Feedforward Networks using Tree Receptive Fields

**Abstract Link:** [https://arxiv.org/abs/1803.05209](https://arxiv.org/abs/1803.05209)

**PDF Link:** [https://arxiv.org/pdf/1803.05209](https://arxiv.org/pdf/1803.05209)

---

**Date:** 17 May 2022

**Title:** On the Landscape of One-hidden-layer Sparse Networks and Beyond

**Abstract Link:** [https://arxiv.org/abs/2009.07439](https://arxiv.org/abs/2009.07439)

**PDF Link:** [https://arxiv.org/pdf/2009.07439](https://arxiv.org/pdf/2009.07439)

---

**Date:** 06 Mar 2024

**Title:** Sparse Spiking Neural Network: Exploiting Heterogeneity in Timescales  for Pruning Recurrent SNN

**Abstract Link:** [https://arxiv.org/abs/2403.03409](https://arxiv.org/abs/2403.03409)

**PDF Link:** [https://arxiv.org/pdf/2403.03409](https://arxiv.org/pdf/2403.03409)

---

**Date:** 06 Jun 2023

**Title:** ESL-SNNs: An Evolutionary Structure Learning Strategy for Spiking Neural  Networks

**Abstract Link:** [https://arxiv.org/abs/2306.03693](https://arxiv.org/abs/2306.03693)

**PDF Link:** [https://arxiv.org/pdf/2306.03693](https://arxiv.org/pdf/2306.03693)

---

**Date:** 06 Apr 2020

**Title:** GraphChallenge.org Sparse Deep Neural Network Performance

**Abstract Link:** [https://arxiv.org/abs/2004.01181](https://arxiv.org/abs/2004.01181)

**PDF Link:** [https://arxiv.org/pdf/2004.01181](https://arxiv.org/pdf/2004.01181)

---

