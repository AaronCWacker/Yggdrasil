AI Applications 💼

### 🔎 AI Applications 💼



# AI in Healthcare

Artificial Intelligence (AI) is revolutionizing the healthcare industry by providing innovative solutions to improve patient care, reduce costs, and increase efficiency. AI can analyze vast amounts of data quickly and accurately, enabling healthcare providers to make better decisions, diagnose diseases earlier, and develop personalized treatment plans.

AI can be used in various applications in healthcare, such as medical imaging, drug discovery, patient monitoring, and virtual health assistants. In medical imaging, AI can help radiologists detect abnormalities in images, such as tumors, fractures, or strokes, more accurately and quickly. In drug discovery, AI can analyze large datasets of chemical compounds to identify potential drug candidates, reducing the time and cost of drug development.

Patient monitoring is another area where AI can make a significant impact. AI-powered wearable devices can track patients' vital signs, such as heart rate, blood pressure, and oxygen levels, and alert healthcare providers if there are any abnormalities. Virtual health assistants can provide patients with personalized health advice, reminders to take medication, and answers to health-related questions.

AI can also help healthcare providers manage their workload and improve efficiency. AI-powered chatbots can handle routine patient inquiries, freeing up healthcare providers to focus on more complex cases. AI can also automate administrative tasks, such as scheduling appointments and processing insurance claims, reducing the burden on healthcare staff.

However, AI in healthcare also raises ethical and privacy concerns. AI algorithms may perpetuate biases and discriminate against certain groups of patients. Patients' health data may be vulnerable to cyber attacks, and there may be concerns about who has access to this data and how it is used. Therefore, it is crucial to ensure that AI in healthcare is developed and deployed ethically and responsibly, with patients' privacy and safety as a top priority.

In conclusion, AI has the potential to transform the healthcare industry by providing innovative solutions to improve patient care, reduce costs, and increase efficiency. However, it is essential to ensure that AI is developed and deployed ethically and responsibly, with patients' privacy and safety as a top priority. By doing so, AI can help healthcare providers deliver better care to their patients and improve health outcomes for everyone.</s>
# 🩺🔍 Search Results
### 20 Jun 2023 | [A Graphical Modeling Language for Artificial Intelligence Applications  in Automation Systems](https://arxiv.org/abs/2306.11767) | [⬇️](https://arxiv.org/pdf/2306.11767)
*Marvin Schieseck, Philip Topalis, Alexander Fay* 

  Artificial Intelligence (AI) applications in automation systems are usually
distributed systems whose development and integration involve several experts.
Each expert uses its own domain-specific modeling language and tools to model
the system elements. An interdisciplinary graphical modeling language that
enables the modeling of an AI application as an overall system comprehensible
to all disciplines does not yet exist. As a result, there is often a lack of
interdisciplinary system understanding, leading to increased development,
integration, and maintenance efforts. This paper therefore presents a graphical
modeling language that enables consistent and understandable modeling of AI
applications in automation systems at system level. This makes it possible to
subdivide individual subareas into domain specific subsystems and thus reduce
the existing efforts.

---------------

### 09 Aug 2021 | [Extending LIME for Business Process Automation](https://arxiv.org/abs/2108.04371) | [⬇️](https://arxiv.org/pdf/2108.04371)
*Sohini Upadhyay, Vatche Isahagian, Vinod Muthusamy, Yara Rizk* 

  AI business process applications automate high-stakes business decisions
where there is an increasing demand to justify or explain the rationale behind
algorithmic decisions. Business process applications have ordering or
constraints on tasks and feature values that cause lightweight, model-agnostic,
existing explanation methods like LIME to fail. In response, we propose a local
explanation framework extending LIME for explaining AI business process
applications. Empirical evaluation of our extension underscores the advantage
of our approach in the business process setting.

---------------

### 13 Jan 2021 | [How AI Developers Overcome Communication Challenges in a  Multidisciplinary Team: A Case Study](https://arxiv.org/abs/2101.06098) | [⬇️](https://arxiv.org/pdf/2101.06098)
*David Piorkowski, Soya Park, April Yi Wang, Dakuo Wang, Michael  Muller, Felix Portnoy* 

  The development of AI applications is a multidisciplinary effort, involving
multiple roles collaborating with the AI developers, an umbrella term we use to
include data scientists and other AI-adjacent roles on the same team. During
these collaborations, there is a knowledge mismatch between AI developers, who
are skilled in data science, and external stakeholders who are typically not.
This difference leads to communication gaps, and the onus falls on AI
developers to explain data science concepts to their collaborators. In this
paper, we report on a study including analyses of both interviews with AI
developers and artifacts they produced for communication. Using the analytic
lens of shared mental models, we report on the types of communication gaps that
AI developers face, how AI developers communicate across disciplinary and
organizational boundaries, and how they simultaneously manage issues regarding
trust and expectations.

---------------

### 17 Mar 2022 | [CheXstray: Real-time Multi-Modal Data Concordance for Drift Detection in  Medical Imaging AI](https://arxiv.org/abs/2202.02833) | [⬇️](https://arxiv.org/pdf/2202.02833)
*Arjun Soin, Jameson Merkow, Jin Long, Joseph Paul Cohen, Smitha  Saligrama, Stephen Kaiser, Steven Borg, Ivan Tarapov and Matthew P Lungren* 

  Clinical Artificial lntelligence (AI) applications are rapidly expanding
worldwide, and have the potential to impact to all areas of medical practice.
Medical imaging applications constitute a vast majority of approved clinical AI
applications. Though healthcare systems are eager to adopt AI solutions a
fundamental question remains: \textit{what happens after the AI model goes into
production?} We use the CheXpert and PadChest public datasets to build and test
a medical imaging AI drift monitoring workflow to track data and model drift
without contemporaneous ground truth. We simulate drift in multiple experiments
to compare model performance with our novel multi-modal drift metric, which
uses DICOM metadata, image appearance representation from a variational
autoencoder (VAE), and model output probabilities as input. Through
experimentation, we demonstrate a strong proxy for ground truth performance
using unsupervised distributional shifts in relevant metadata, predicted
probabilities, and VAE latent representation. Our key contributions include (1)
proof-of-concept for medical imaging drift detection that includes the use of
VAE and domain specific statistical methods, (2) a multi-modal methodology to
measure and unify drift metrics, (3) new insights into the challenges and
solutions to observe deployed medical imaging AI, and (4) creation of
open-source tools that enable others to easily run their own workflows and
scenarios. This work has important implications. It addresses the concerning
translation gap found in continuous medical imaging AI model monitoring common
in dynamic healthcare environments.

---------------

### 11 Jun 2019 | [Governance by Glass-Box: Implementing Transparent Moral Bounds for AI  Behaviour](https://arxiv.org/abs/1905.04994) | [⬇️](https://arxiv.org/pdf/1905.04994)
*Andrea Aler Tubella, Andreas Theodorou, Virginia Dignum, Frank Dignum* 

  Artificial Intelligence (AI) applications are being used to predict and
assess behaviour in multiple domains, such as criminal justice and consumer
finance, which directly affect human well-being. However, if AI is to improve
people's lives, then people must be able to trust AI, which means being able to
understand what the system is doing and why. Even though transparency is often
seen as the requirement in this case, realistically it might not always be
possible or desirable, whereas the need to ensure that the system operates
within set moral bounds remains. In this paper, we present an approach to
evaluate the moral bounds of an AI system based on the monitoring of its inputs
and outputs. We place a "glass box" around the system by mapping moral values
into explicit verifiable norms that constrain inputs and outputs, in such a way
that if these remain within the box we can guarantee that the system adheres to
the value. The focus on inputs and outputs allows for the verification and
comparison of vastly different intelligent systems; from deep neural networks
to agent-based systems. The explicit transformation of abstract moral values
into concrete norms brings great benefits in terms of explainability;
stakeholders know exactly how the system is interpreting and employing relevant
abstract moral human values and calibrate their trust accordingly. Moreover, by
operating at a higher level we can check the compliance of the system with
different interpretations of the same value. These advantages will have an
impact on the well-being of AI systems users at large, building their trust and
providing them with concrete knowledge on how systems adhere to moral values.

---------------

### 21 Oct 2019 | [Risks of Using Non-verified Open Data: A case study on using Machine  Learning techniques for predicting Pregnancy Outcomes in India](https://arxiv.org/abs/1910.02136) | [⬇️](https://arxiv.org/pdf/1910.02136)
*Anusua Trivedi, Sumit Mukherjee, Edmund Tse, Anne Ewing, Juan Lavista  Ferres* 

  Artificial intelligence (AI) has evolved considerably in the last few years.
While applications of AI is now becoming more common in fields like retail and
marketing, application of AI in solving problems related to developing
countries is still an emerging topic. Specially, AI applications in
resource-poor settings remains relatively nascent. There is a huge scope of AI
being used in such settings. For example, researchers have started exploring AI
applications to reduce poverty and deliver a broad range of critical public
services. However, despite many promising use cases, there are many dataset
related challenges that one has to overcome in such projects. These challenges
often take the form of missing data, incorrectly collected data and improperly
labeled variables, among other factors. As a result, we can often end up using
data that is not representative of the problem we are trying to solve. In this
case study, we explore the challenges of using such an open dataset from India,
to predict an important health outcome. We highlight how the use of AI without
proper understanding of reporting metrics can lead to erroneous conclusions.

---------------

### 15 Nov 2022 | [Participation Interfaces for Human-Centered AI](https://arxiv.org/abs/2211.08419) | [⬇️](https://arxiv.org/pdf/2211.08419)
*Sean McGregor* 

  Emerging artificial intelligence (AI) applications often balance the
preferences and impacts among diverse and contentious stakeholder groups.
Accommodating these stakeholder groups during system design, development, and
deployment requires tools for the elicitation of disparate system interests and
collaboration interfaces supporting negotiation balancing those interests. This
paper introduces interactive visual "participation interfaces" for Markov
Decision Processes (MDPs) and collaborative ranking problems as examples
restoring a human-centered locus of control.

---------------

### 31 Oct 2021 | [Explainable Artificial Intelligence for Smart City Application: A Secure  and Trusted Platform](https://arxiv.org/abs/2111.00601) | [⬇️](https://arxiv.org/pdf/2111.00601)
*M. Humayn Kabir, Khondokar Fida Hasan, Mohammad Kamrul Hasan, Keyvan  Ansari* 

  Artificial Intelligence (AI) is one of the disruptive technologies that is
shaping the future. It has growing applications for data-driven decisions in
major smart city solutions, including transportation, education, healthcare,
public governance, and power systems. At the same time, it is gaining
popularity in protecting critical cyber infrastructure from cyber threats,
attacks, damages, or unauthorized access. However, one of the significant
issues of those traditional AI technologies (e.g., deep learning) is that the
rapid progress in complexity and sophistication propelled and turned out to be
uninterpretable black boxes. On many occasions, it is very challenging to
understand the decision and bias to control and trust systems' unexpected or
seemingly unpredictable outputs. It is acknowledged that the loss of control
over interpretability of decision-making becomes a critical issue for many
data-driven automated applications. But how may it affect the system's security
and trustworthiness? This chapter conducts a comprehensive study of machine
learning applications in cybersecurity to indicate the need for explainability
to address this question. While doing that, this chapter first discusses the
black-box problems of AI technologies for Cybersecurity applications in smart
city-based solutions. Later, considering the new technological paradigm,
Explainable Artificial Intelligence (XAI), this chapter discusses the
transition from black-box to white-box. This chapter also discusses the
transition requirements concerning the interpretability, transparency,
understandability, and Explainability of AI-based technologies in applying
different autonomous systems in smart cities. Finally, it has presented some
commercial XAI platforms that offer explainability over traditional AI
technologies before presenting future challenges and opportunities.

---------------

### 15 Jan 2018 | [Artificial Intelligence (AI) Methods in Optical Networks: A  Comprehensive Survey](https://arxiv.org/abs/1801.01704) | [⬇️](https://arxiv.org/pdf/1801.01704)
*Javier Mata, Ignacio de Miguel, Ram\'o n J. Dur\'a n, Noem\'i Merayo,  Sandeep Kumar Singh, Admela Jukan, Mohit Chamania* 

  Artificial intelligence (AI) is an extensive scientific discipline which
enables computer systems to solve problems by emulating complex biological
processes such as learning, reasoning and self-correction. This paper presents
a comprehensive review of the application of AI techniques for improving
performance of optical communication systems and networks. The use of AI-based
techniques is first studied in applications related to optical transmission,
ranging from the characterization and operation of network components to
performance monitoring, mitigation of nonlinearities, and quality of
transmission estimation. Then, applications related to optical network control
and management are also reviewed, including topics like optical network
planning and operation in both transport and access networks. Finally, the
paper also presents a summary of opportunities and challenges in optical
networking where AI is expected to play a key role in the near future.

---------------

### 04 Apr 2023 | [A Brief Review of Explainable Artificial Intelligence in Healthcare](https://arxiv.org/abs/2304.01543) | [⬇️](https://arxiv.org/pdf/2304.01543)
*Zahra Sadeghi, Roohallah Alizadehsani, Mehmet Akif Cifci, Samina  Kausar, Rizwan Rehman, Priyakshi Mahanta, Pranjal Kumar Bora, Ammar Almasri,  Rami S. Alkhawaldeh, Sadiq Hussain, Bilal Alatas, Afshin Shoeibi, Hossein  Moosaei, Milan Hladik, Saeid Nahavandi, Panos M. Pardalos* 

  XAI refers to the techniques and methods for building AI applications which
assist end users to interpret output and predictions of AI models. Black box AI
applications in high-stakes decision-making situations, such as medical domain
have increased the demand for transparency and explainability since wrong
predictions may have severe consequences. Model explainability and
interpretability are vital successful deployment of AI models in healthcare
practices. AI applications' underlying reasoning needs to be transparent to
clinicians in order to gain their trust. This paper presents a systematic
review of XAI aspects and challenges in the healthcare domain. The primary
goals of this study are to review various XAI methods, their challenges, and
related machine learning models in healthcare. The methods are discussed under
six categories: Features-oriented methods, global methods, concept models,
surrogate models, local pixel-based methods, and human-centric methods. Most
importantly, the paper explores XAI role in healthcare problems to clarify its
necessity in safety-critical applications. The paper intends to establish a
comprehensive understanding of XAI-related applications in the healthcare field
by reviewing the related experimental results. To facilitate future research
for filling research gaps, the importance of XAI models from different
viewpoints and their limitations are investigated.

---------------

### 17 Sep 2020 | [Optimising AI Training Deployments using Graph Compilers and Containers](https://arxiv.org/abs/2008.11675) | [⬇️](https://arxiv.org/pdf/2008.11675)
*Nina Mujkanovic and Karthee Sivalingam and Alfio Lazzaro* 

  Artificial Intelligence (AI) applications based on Deep Neural Networks (DNN)
or Deep Learning (DL) have become popular due to their success in solving
problems likeimage analysis and speech recognition. Training a DNN is
computationally intensive and High Performance Computing(HPC) has been a key
driver in AI growth. Virtualisation and container technology have led to the
convergence of cloud and HPC infrastructure. These infrastructures with diverse
hardware increase the complexity of deploying and optimising AI training
workloads. AI training deployments in HPC or cloud can be optimised with
target-specific libraries, graph compilers, andby improving data movement or
IO. Graph compilers aim to optimise the execution of a DNN graph by generating
an optimised code for a target hardware/backend. As part of SODALITE (a Horizon
2020 project), MODAK tool is developed to optimise application deployment in
software defined infrastructures. Using input from the data scientist and
performance modelling, MODAK maps optimal application parameters to a target
infrastructure and builds an optimised container. In this paper, we introduce
MODAK and review container technologies and graph compilers for AI. We
illustrate optimisation of AI training deployments using graph compilers and
Singularity containers. Evaluation using MNIST-CNN and ResNet50 training
workloads shows that custom built optimised containers outperform the official
images from DockerHub. We also found that the performance of graph compilers
depends on the target hardware and the complexity of the neural network.

---------------

### 30 Oct 2020 | [Biomedical Concept Relatedness -- A large EHR-based benchmark](https://arxiv.org/abs/2010.16218) | [⬇️](https://arxiv.org/pdf/2010.16218)
*Claudia Schulz and Josh Levy-Kramer and Camille Van Assel and Miklos  Kepes and Nils Hammerla* 

  A promising application of AI to healthcare is the retrieval of information
from electronic health records (EHRs), e.g. to aid clinicians in finding
relevant information for a consultation or to recruit suitable patients for a
study. This requires search capabilities far beyond simple string matching,
including the retrieval of concepts (diagnoses, symptoms, medications, etc.)
related to the one in question. The suitability of AI methods for such
applications is tested by predicting the relatedness of concepts with known
relatedness scores. However, all existing biomedical concept relatedness
datasets are notoriously small and consist of hand-picked concept pairs. We
open-source a novel concept relatedness benchmark overcoming these issues: it
is six times larger than existing datasets and concept pairs are chosen based
on co-occurrence in EHRs, ensuring their relevance for the application of
interest. We present an in-depth analysis of our new dataset and compare it to
existing ones, highlighting that it is not only larger but also complements
existing datasets in terms of the types of concepts included. Initial
experiments with state-of-the-art embedding methods show that our dataset is a
challenging new benchmark for testing concept relatedness models.

---------------

### 02 Feb 2023 | [Out of Context: Investigating the Bias and Fairness Concerns of  "Artificial Intelligence as a Service"](https://arxiv.org/abs/2302.01448) | [⬇️](https://arxiv.org/pdf/2302.01448)
*Kornel Lewicki, Michelle Seng Ah Lee, Jennifer Cobbe, Jatinder Singh* 

  "AI as a Service" (AIaaS) is a rapidly growing market, offering various
plug-and-play AI services and tools. AIaaS enables its customers (users) - who
may lack the expertise, data, and/or resources to develop their own systems -
to easily build and integrate AI capabilities into their applications. Yet, it
is known that AI systems can encapsulate biases and inequalities that can have
societal impact. This paper argues that the context-sensitive nature of
fairness is often incompatible with AIaaS' 'one-size-fits-all' approach,
leading to issues and tensions. Specifically, we review and systematise the
AIaaS space by proposing a taxonomy of AI services based on the levels of
autonomy afforded to the user. We then critically examine the different
categories of AIaaS, outlining how these services can lead to biases or be
otherwise harmful in the context of end-user applications. In doing so, we seek
to draw research attention to the challenges of this emerging area.

---------------

### 28 Feb 2024 | [Multi-stakeholder Perspective on Responsible Artificial Intelligence and  Acceptability in Education](https://arxiv.org/abs/2402.15027) | [⬇️](https://arxiv.org/pdf/2402.15027)
*A.J. Karran, P. Charland, J-T. Martineau, A. Ortiz de Guinea Lopez de  Arana, AM. Lesage, S. Senecal, P-M. Leger* 

  This study investigates the acceptability of different artificial
intelligence (AI) applications in education from a multi-stakeholder
perspective, including students, teachers, and parents. Acknowledging the
transformative potential of AI in education, it addresses concerns related to
data privacy, AI agency, transparency, explainability and the ethical
deployment of AI. Through a vignette methodology, participants were presented
with four scenarios where AI's agency, transparency, explainability, and
privacy were manipulated. After each scenario, participants completed a survey
that captured their perceptions of AI's global utility, individual usefulness,
justice, confidence, risk, and intention to use each scenario's AI if
available. The data collection comprising a final sample of 1198
multi-stakeholder participants was distributed through a partner institution
and social media campaigns and focused on individual responses to four AI use
cases. A mediation analysis of the data indicated that acceptance and trust in
AI varies significantly across stakeholder groups. We found that the key
mediators between high and low levels of AI's agency, transparency, and
explainability, as well as the intention to use the different educational AI,
included perceived global utility, justice, and confidence. The study
highlights that the acceptance of AI in education is a nuanced and multifaceted
issue that requires careful consideration of specific AI applications and their
characteristics, in addition to the diverse stakeholders' perceptions.

---------------

### 22 Dec 2023 | [Constructing Custom Thermodynamics Using Deep Learning](https://arxiv.org/abs/2308.04119) | [⬇️](https://arxiv.org/pdf/2308.04119)
*Xiaoli Chen, Beatrice W. Soh, Zi-En Ooi, Eleonore Vissol-Gaudin,  Haijun Yu, Kostya S. Novoselov, Kedar Hippalgaonkar, Qianxiao Li* 

  One of the most exciting applications of artificial intelligence (AI) is
automated scientific discovery based on previously amassed data, coupled with
restrictions provided by known physical principles, including symmetries and
conservation laws. Such automated hypothesis creation and verification can
assist scientists in studying complex phenomena, where traditional physical
intuition may fail. Here we develop a platform based on a generalized Onsager
principle to learn macroscopic dynamical descriptions of arbitrary stochastic
dissipative systems directly from observations of their microscopic
trajectories. Our method simultaneously constructs reduced thermodynamic
coordinates and interprets the dynamics on these coordinates. We demonstrate
its effectiveness by studying theoretically and validating experimentally the
stretching of long polymer chains in an externally applied field. Specifically,
we learn three interpretable thermodynamic coordinates and build a dynamical
landscape of polymer stretching, including the identification of stable and
transition states and the control of the stretching rate. Our general
methodology can be used to address a wide range of scientific and technological
applications.

---------------

### 24 Nov 2021 | [Edge Artificial Intelligence for 6G: Vision, Enabling Technologies, and  Applications](https://arxiv.org/abs/2111.12444) | [⬇️](https://arxiv.org/pdf/2111.12444)
*Khaled B. Letaief, Yuanming Shi, Jianmin Lu, Jianhua Lu* 

  The thriving of artificial intelligence (AI) applications is driving the
further evolution of wireless networks. It has been envisioned that 6G will be
transformative and will revolutionize the evolution of wireless from "connected
things" to "connected intelligence". However, state-of-the-art deep learning
and big data analytics based AI systems require tremendous computation and
communication resources, causing significant latency, energy consumption,
network congestion, and privacy leakage in both of the training and inference
processes. By embedding model training and inference capabilities into the
network edge, edge AI stands out as a disruptive technology for 6G to
seamlessly integrate sensing, communication, computation, and intelligence,
thereby improving the efficiency, effectiveness, privacy, and security of 6G
networks. In this paper, we shall provide our vision for scalable and
trustworthy edge AI systems with integrated design of wireless communication
strategies and decentralized machine learning models. New design principles of
wireless networks, service-driven resource allocation optimization methods, as
well as a holistic end-to-end system architecture to support edge AI will be
described. Standardization, software and hardware platforms, and application
scenarios are also discussed to facilitate the industrialization and
commercialization of edge AI systems.

---------------

### 04 Nov 2022 | [MONAI: An open-source framework for deep learning in healthcare](https://arxiv.org/abs/2211.02701) | [⬇️](https://arxiv.org/pdf/2211.02701)
*M. Jorge Cardoso, Wenqi Li, Richard Brown, Nic Ma, Eric Kerfoot,  Yiheng Wang, Benjamin Murrey, Andriy Myronenko, Can Zhao, Dong Yang, Vishwesh  Nath, Yufan He, Ziyue Xu, Ali Hatamizadeh, Andriy Myronenko, Wentao Zhu, Yun  Liu, Mingxin Zheng, Yucheng Tang, Isaac Yang, Michael Zephyr, Behrooz  Hashemian, Sachidanand Alle, Mohammad Zalbagi Darestani, Charlie Budd, Marc  Modat, Tom Vercauteren, Guotai Wang, Yiwen Li, Yipeng Hu, Yunguan Fu,  Benjamin Gorman, Hans Johnson, Brad Genereaux, Barbaros S. Erdal, Vikash  Gupta, Andres Diaz-Pinto, Andre Dourson, Lena Maier-Hein, Paul F. Jaeger,  Michael Baumgartner, Jayashree Kalpathy-Cramer, Mona Flores, Justin Kirby,  Lee A.D. Cooper, Holger R. Roth, Daguang Xu, David Bericat, Ralf Floca, S.  Kevin Zhou, Haris Shuaib, Keyvan Farahani, Klaus H. Maier-Hein, Stephen  Aylward, Prerna Dogra, Sebastien Ourselin, Andrew Feng* 

  Artificial Intelligence (AI) is having a tremendous impact across most areas
of science. Applications of AI in healthcare have the potential to improve our
ability to detect, diagnose, prognose, and intervene on human disease. For AI
models to be used clinically, they need to be made safe, reproducible and
robust, and the underlying software framework must be aware of the
particularities (e.g. geometry, physiology, physics) of medical data being
processed. This work introduces MONAI, a freely available, community-supported,
and consortium-led PyTorch-based framework for deep learning in healthcare.
MONAI extends PyTorch to support medical data, with a particular focus on
imaging, and provide purpose-specific AI model architectures, transformations
and utilities that streamline the development and deployment of medical AI
models. MONAI follows best practices for software-development, providing an
easy-to-use, robust, well-documented, and well-tested software framework. MONAI
preserves the simple, additive, and compositional approach of its underlying
PyTorch libraries. MONAI is being used by and receiving contributions from
research, clinical and industrial teams from around the world, who are pursuing
applications spanning nearly every aspect of healthcare.

---------------

### 16 Jun 2020 | [Quality Management of Machine Learning Systems](https://arxiv.org/abs/2006.09529) | [⬇️](https://arxiv.org/pdf/2006.09529)
*P. Santhanam* 

  In the past decade, Artificial Intelligence (AI) has become a part of our
daily lives due to major advances in Machine Learning (ML) techniques. In spite
of an explosive growth in the raw AI technology and in consumer facing
applications on the internet, its adoption in business applications has
conspicuously lagged behind. For business/mission-critical systems, serious
concerns about reliability and maintainability of AI applications remain. Due
to the statistical nature of the output, software 'defects' are not well
defined. Consequently, many traditional quality management techniques such as
program debugging, static code analysis, functional testing, etc. have to be
reevaluated. Beyond the correctness of an AI model, many other new quality
attributes, such as fairness, robustness, explainability, transparency, etc.
become important in delivering an AI system. The purpose of this paper is to
present a view of a holistic quality management framework for ML applications
based on the current advances and identify new areas of software engineering
research to achieve a more trustworthy AI.

---------------

### 19 Feb 2024 | [Worldwide AI Ethics: a review of 200 guidelines and recommendations for  AI governance](https://arxiv.org/abs/2206.11922) | [⬇️](https://arxiv.org/pdf/2206.11922)
*Nicholas Kluge Corr\^ea, Camila Galv\~ao, James William Santos,  Carolina Del Pino, Edson Pontes Pinto, Camila Barbosa, Diogo Massmann,  Rodrigo Mambrini, Luiza Galv\~ao, Edmund Terem, Nythamar de Oliveira* 

  The utilization of artificial intelligence (AI) applications has experienced
tremendous growth in recent years, bringing forth numerous benefits and
conveniences. However, this expansion has also provoked ethical concerns, such
as privacy breaches, algorithmic discrimination, security and reliability
issues, transparency, and other unintended consequences. To determine whether a
global consensus exists regarding the ethical principles that should govern AI
applications and to contribute to the formation of future regulations, this
paper conducts a meta-analysis of 200 governance policies and ethical
guidelines for AI usage published by public bodies, academic institutions,
private companies, and civil society organizations worldwide. We identified at
least 17 resonating principles prevalent in the policies and guidelines of our
dataset, released as an open-source database and tool. We present the
limitations of performing a global scale analysis study paired with a critical
analysis of our findings, presenting areas of consensus that should be
incorporated into future regulatory efforts. All components tied to this work
can be found in https://nkluge-correa.github.io/worldwide_AI-ethics/

---------------

### 26 Apr 2018 | [PANDA: Facilitating Usable AI Development](https://arxiv.org/abs/1804.09997) | [⬇️](https://arxiv.org/pdf/1804.09997)
*Jinyang Gao, Wei Wang, Meihui Zhang, Gang Chen, H.V. Jagadish,  Guoliang Li, Teck Khim Ng, Beng Chin Ooi, Sheng Wang, Jingren Zhou* 

  Recent advances in artificial intelligence (AI) and machine learning have
created a general perception that AI could be used to solve complex problems,
and in some situations over-hyped as a tool that can be so easily used.
Unfortunately, the barrier to realization of mass adoption of AI on various
business domains is too high because most domain experts have no background in
AI. Developing AI applications involves multiple phases, namely data
preparation, application modeling, and product deployment. The effort of AI
research has been spent mostly on new AI models (in the model training stage)
to improve the performance of benchmark tasks such as image recognition. Many
other factors such as usability, efficiency and security of AI have not been
well addressed, and therefore form a barrier to democratizing AI. Further, for
many real world applications such as healthcare and autonomous driving,
learning via huge amounts of possibility exploration is not feasible since
humans are involved. In many complex applications such as healthcare, subject
matter experts (e.g. Clinicians) are the ones who appreciate the importance of
features that affect health, and their knowledge together with existing
knowledge bases are critical to the end results. In this paper, we take a new
perspective on developing AI solutions, and present a solution for making AI
usable. We hope that this resolution will enable all subject matter experts
(eg. Clinicians) to exploit AI like data scientists.

---------------
**Date:** 20 Jun 2023

**Title:** A Graphical Modeling Language for Artificial Intelligence Applications  in Automation Systems

**Abstract Link:** [https://arxiv.org/abs/2306.11767](https://arxiv.org/abs/2306.11767)

**PDF Link:** [https://arxiv.org/pdf/2306.11767](https://arxiv.org/pdf/2306.11767)

---

**Date:** 09 Aug 2021

**Title:** Extending LIME for Business Process Automation

**Abstract Link:** [https://arxiv.org/abs/2108.04371](https://arxiv.org/abs/2108.04371)

**PDF Link:** [https://arxiv.org/pdf/2108.04371](https://arxiv.org/pdf/2108.04371)

---

**Date:** 13 Jan 2021

**Title:** How AI Developers Overcome Communication Challenges in a  Multidisciplinary Team: A Case Study

**Abstract Link:** [https://arxiv.org/abs/2101.06098](https://arxiv.org/abs/2101.06098)

**PDF Link:** [https://arxiv.org/pdf/2101.06098](https://arxiv.org/pdf/2101.06098)

---

**Date:** 17 Mar 2022

**Title:** CheXstray: Real-time Multi-Modal Data Concordance for Drift Detection in  Medical Imaging AI

**Abstract Link:** [https://arxiv.org/abs/2202.02833](https://arxiv.org/abs/2202.02833)

**PDF Link:** [https://arxiv.org/pdf/2202.02833](https://arxiv.org/pdf/2202.02833)

---

**Date:** 11 Jun 2019

**Title:** Governance by Glass-Box: Implementing Transparent Moral Bounds for AI  Behaviour

**Abstract Link:** [https://arxiv.org/abs/1905.04994](https://arxiv.org/abs/1905.04994)

**PDF Link:** [https://arxiv.org/pdf/1905.04994](https://arxiv.org/pdf/1905.04994)

---

**Date:** 21 Oct 2019

**Title:** Risks of Using Non-verified Open Data: A case study on using Machine  Learning techniques for predicting Pregnancy Outcomes in India

**Abstract Link:** [https://arxiv.org/abs/1910.02136](https://arxiv.org/abs/1910.02136)

**PDF Link:** [https://arxiv.org/pdf/1910.02136](https://arxiv.org/pdf/1910.02136)

---

**Date:** 15 Nov 2022

**Title:** Participation Interfaces for Human-Centered AI

**Abstract Link:** [https://arxiv.org/abs/2211.08419](https://arxiv.org/abs/2211.08419)

**PDF Link:** [https://arxiv.org/pdf/2211.08419](https://arxiv.org/pdf/2211.08419)

---

**Date:** 31 Oct 2021

**Title:** Explainable Artificial Intelligence for Smart City Application: A Secure  and Trusted Platform

**Abstract Link:** [https://arxiv.org/abs/2111.00601](https://arxiv.org/abs/2111.00601)

**PDF Link:** [https://arxiv.org/pdf/2111.00601](https://arxiv.org/pdf/2111.00601)

---

**Date:** 15 Jan 2018

**Title:** Artificial Intelligence (AI) Methods in Optical Networks: A  Comprehensive Survey

**Abstract Link:** [https://arxiv.org/abs/1801.01704](https://arxiv.org/abs/1801.01704)

**PDF Link:** [https://arxiv.org/pdf/1801.01704](https://arxiv.org/pdf/1801.01704)

---

**Date:** 04 Apr 2023

**Title:** A Brief Review of Explainable Artificial Intelligence in Healthcare

**Abstract Link:** [https://arxiv.org/abs/2304.01543](https://arxiv.org/abs/2304.01543)

**PDF Link:** [https://arxiv.org/pdf/2304.01543](https://arxiv.org/pdf/2304.01543)

---

**Date:** 17 Sep 2020

**Title:** Optimising AI Training Deployments using Graph Compilers and Containers

**Abstract Link:** [https://arxiv.org/abs/2008.11675](https://arxiv.org/abs/2008.11675)

**PDF Link:** [https://arxiv.org/pdf/2008.11675](https://arxiv.org/pdf/2008.11675)

---

**Date:** 30 Oct 2020

**Title:** Biomedical Concept Relatedness -- A large EHR-based benchmark

**Abstract Link:** [https://arxiv.org/abs/2010.16218](https://arxiv.org/abs/2010.16218)

**PDF Link:** [https://arxiv.org/pdf/2010.16218](https://arxiv.org/pdf/2010.16218)

---

**Date:** 02 Feb 2023

**Title:** Out of Context: Investigating the Bias and Fairness Concerns of  "Artificial Intelligence as a Service"

**Abstract Link:** [https://arxiv.org/abs/2302.01448](https://arxiv.org/abs/2302.01448)

**PDF Link:** [https://arxiv.org/pdf/2302.01448](https://arxiv.org/pdf/2302.01448)

---

**Date:** 28 Feb 2024

**Title:** Multi-stakeholder Perspective on Responsible Artificial Intelligence and  Acceptability in Education

**Abstract Link:** [https://arxiv.org/abs/2402.15027](https://arxiv.org/abs/2402.15027)

**PDF Link:** [https://arxiv.org/pdf/2402.15027](https://arxiv.org/pdf/2402.15027)

---

**Date:** 22 Dec 2023

**Title:** Constructing Custom Thermodynamics Using Deep Learning

**Abstract Link:** [https://arxiv.org/abs/2308.04119](https://arxiv.org/abs/2308.04119)

**PDF Link:** [https://arxiv.org/pdf/2308.04119](https://arxiv.org/pdf/2308.04119)

---

**Date:** 24 Nov 2021

**Title:** Edge Artificial Intelligence for 6G: Vision, Enabling Technologies, and  Applications

**Abstract Link:** [https://arxiv.org/abs/2111.12444](https://arxiv.org/abs/2111.12444)

**PDF Link:** [https://arxiv.org/pdf/2111.12444](https://arxiv.org/pdf/2111.12444)

---

**Date:** 04 Nov 2022

**Title:** MONAI: An open-source framework for deep learning in healthcare

**Abstract Link:** [https://arxiv.org/abs/2211.02701](https://arxiv.org/abs/2211.02701)

**PDF Link:** [https://arxiv.org/pdf/2211.02701](https://arxiv.org/pdf/2211.02701)

---

**Date:** 16 Jun 2020

**Title:** Quality Management of Machine Learning Systems

**Abstract Link:** [https://arxiv.org/abs/2006.09529](https://arxiv.org/abs/2006.09529)

**PDF Link:** [https://arxiv.org/pdf/2006.09529](https://arxiv.org/pdf/2006.09529)

---

**Date:** 19 Feb 2024

**Title:** Worldwide AI Ethics: a review of 200 guidelines and recommendations for  AI governance

**Abstract Link:** [https://arxiv.org/abs/2206.11922](https://arxiv.org/abs/2206.11922)

**PDF Link:** [https://arxiv.org/pdf/2206.11922](https://arxiv.org/pdf/2206.11922)

---

**Date:** 26 Apr 2018

**Title:** PANDA: Facilitating Usable AI Development

**Abstract Link:** [https://arxiv.org/abs/1804.09997](https://arxiv.org/abs/1804.09997)

**PDF Link:** [https://arxiv.org/pdf/1804.09997](https://arxiv.org/pdf/1804.09997)

---

