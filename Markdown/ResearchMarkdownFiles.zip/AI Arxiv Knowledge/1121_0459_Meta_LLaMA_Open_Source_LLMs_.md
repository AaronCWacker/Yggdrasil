Meta: LLaMA Open Source LLMs 👤

### 🔎 Meta: LLaMA Open Source LLMs 👤


================================

<p align="center">
  <img src="https://github.com/LAION-AI/Meta/blob/main/llama.png" width="200" height="200">
</p>

<p align="center">
  <a href="https://github.com/LAION-AI/Meta/blob/main/LICENSE">
    <img src="https://img.shields.io/github/license/LAION-AI/Meta?style=flat-square" alt="GitHub license">
  </a>
  <a href="https://github.com/LAION-AI/Meta/issues">
    <img src="https://img.shields.io/github/issues/LAION-AI/Meta?style=flat-square" alt="GitHub issues">
  </a>
  <a href="https://github.com/LAION-AI/Meta/pulls">
    <img src="https://img.shields.io/github/issues-pr/LAION-AI/Meta?style=flat-square" alt="GitHub pull requests">
  </a>
  <a href="https://github.com/LAION-AI/Meta/stargazers">
    <img src="https://img.shields.io/github/stars/LAION-AI/Meta?style=flat-square" alt="GitHub stars">
  </a>
  <a href="https://github.com/LAION-AI/Meta/network/members">
    <img src="https://img.shields.io/github/forks/LAION-AI/Meta?style=flat-square" alt="GitHub forks">
  </a>
</p>

<p align="center">
  <a href="https://github.com/LAION-AI/Meta/actions">
    <img src="https://github.com/LAION-AI/Meta/actions/workflows/main.yml/badge.svg" alt="GitHub Actions">
  </a>
  <a href="https://github.com/LAION-AI/Meta/blob/
# 🩺🔍 Search Results
### 09 Oct 2023 | [MetaMath: Bootstrap Your Own Mathematical Questions for Large Language  Models](https://arxiv.org/abs/2309.12284) | [⬇️](https://arxiv.org/pdf/2309.12284)
*Longhui Yu, Weisen Jiang, Han Shi, Jincheng Yu, Zhengying Liu, Yu  Zhang, James T. Kwok, Zhenguo Li, Adrian Weller, Weiyang Liu* 

  Large language models (LLMs) have pushed the limits of natural language
understanding and exhibited excellent problem-solving ability. Despite the
great success, most existing open-source LLMs (e.g., LLaMA-2) are still far
away from satisfactory for solving mathematical problem due to the complex
reasoning procedures. To bridge this gap, we propose MetaMath, a fine-tuned
language model that specializes in mathematical reasoning. Specifically, we
start by bootstrapping mathematical questions by rewriting the question from
multiple perspectives without extra knowledge, which results in a new dataset
called MetaMathQA. Then we fine-tune the LLaMA-2 models on MetaMathQA.
Experimental results on two popular benchmarks (i.e., GSM8K and MATH) for
mathematical reasoning demonstrate that MetaMath outperforms a suite of
open-source LLMs by a significant margin. Our MetaMath-7B model achieves 66.4%
on GSM8K and 19.4% on MATH, exceeding the state-of-the-art models of the same
size by 11.5% and 8.7%. Particularly, MetaMath-70B achieves an accuracy of
82.3% on GSM8K, slightly better than GPT-3.5-Turbo. We release all the
MetaMathQA dataset, the MetaMath models with different model sizes and the
training code for public use.

---------------

### 21 Nov 2023 | [A Survey on Large Language Models for Personalized and Explainable  Recommendations](https://arxiv.org/abs/2311.12338) | [⬇️](https://arxiv.org/pdf/2311.12338)
*Junyi Chen* 

  In recent years, Recommender Systems(RS) have witnessed a transformative
shift with the advent of Large Language Models(LLMs) in the field of Natural
Language Processing(NLP). These models such as OpenAI's GPT-3.5/4, Llama from
Meta, have demonstrated unprecedented capabilities in understanding and
generating human-like text. This has led to a paradigm shift in the realm of
personalized and explainable recommendations, as LLMs offer a versatile toolset
for processing vast amounts of textual data to enhance user experiences. To
provide a comprehensive understanding of the existing LLM-based recommendation
systems, this survey aims to analyze how RS can benefit from LLM-based
methodologies. Furthermore, we describe major challenges in Personalized
Explanation Generating(PEG) tasks, which are cold-start problems, unfairness
and bias problems in RS.

---------------

### 15 Dec 2023 | [LLaMAntino: LLaMA 2 Models for Effective Text Generation in Italian  Language](https://arxiv.org/abs/2312.09993) | [⬇️](https://arxiv.org/pdf/2312.09993)
*Pierpaolo Basile, Elio Musacchio, Marco Polignano, Lucia Siciliani,  Giuseppe Fiameni, Giovanni Semeraro* 

  Large Language Models represent state-of-the-art linguistic models designed
to equip computers with the ability to comprehend natural language. With its
exceptional capacity to capture complex contextual relationships, the LLaMA
(Large Language Model Meta AI) family represents a novel advancement in the
field of natural language processing by releasing foundational models designed
to improve the natural language understanding abilities of the transformer
architecture thanks to their large amount of trainable parameters (7, 13, and
70 billion parameters). In many natural language understanding tasks, these
models obtain the same performances as private company models such as OpenAI
Chat-GPT with the advantage to make publicly available weights and code for
research and commercial uses. In this work, we investigate the possibility of
Language Adaptation for LLaMA models, explicitly focusing on addressing the
challenge of Italian Language coverage. Adopting an open science approach, we
explore various tuning approaches to ensure a high-quality text generated in
Italian suitable for common tasks in this underrepresented language in the
original models' datasets. We aim to release effective text generation models
with strong linguistic properties for many tasks that seem challenging using
multilingual or general-purpose LLMs. By leveraging an open science philosophy,
this study contributes to Language Adaptation strategies for the Italian
language by introducing the novel LLaMAntino family of Italian LLMs.

---------------

### 19 Jul 2023 | [Llama 2: Open Foundation and Fine-Tuned Chat Models](https://arxiv.org/abs/2307.09288) | [⬇️](https://arxiv.org/pdf/2307.09288)
*Hugo Touvron and Louis Martin and Kevin Stone and Peter Albert and  Amjad Almahairi and Yasmine Babaei and Nikolay Bashlykov and Soumya Batra and  Prajjwal Bhargava and Shruti Bhosale and Dan Bikel and Lukas Blecher and  Cristian Canton Ferrer and Moya Chen and Guillem Cucurull and David Esiobu  and Jude Fernandes and Jeremy Fu and Wenyin Fu and Brian Fuller and Cynthia  Gao and Vedanuj Goswami and Naman Goyal and Anthony Hartshorn and Saghar  Hosseini and Rui Hou and Hakan Inan and Marcin Kardas and Viktor Kerkez and  Madian Khabsa and Isabel Kloumann and Artem Korenev and Punit Singh Koura and  Marie-Anne Lachaux and Thibaut Lavril and Jenya Lee and Diana Liskovich and  Yinghai Lu and Yuning Mao and Xavier Martinet and Todor Mihaylov and Pushkar  Mishra and Igor Molybog and Yixin Nie and Andrew Poulton and Jeremy  Reizenstein and Rashi Rungta and Kalyan Saladi and Alan Schelten and Ruan  Silva and Eric Michael Smith and Ranjan Subramanian and Xiaoqing Ellen Tan  and Binh Tang and Ross Taylor and Adina Williams and Jian Xiang Kuan and  Puxin Xu and Zheng Yan and Iliyan Zarov and Yuchen Zhang and Angela Fan and  Melanie Kambadur and Sharan Narang and Aurelien Rodriguez and Robert Stojnic  and Sergey Edunov and Thomas Scialom* 

  In this work, we develop and release Llama 2, a collection of pretrained and
fine-tuned large language models (LLMs) ranging in scale from 7 billion to 70
billion parameters. Our fine-tuned LLMs, called Llama 2-Chat, are optimized for
dialogue use cases. Our models outperform open-source chat models on most
benchmarks we tested, and based on our human evaluations for helpfulness and
safety, may be a suitable substitute for closed-source models. We provide a
detailed description of our approach to fine-tuning and safety improvements of
Llama 2-Chat in order to enable the community to build on our work and
contribute to the responsible development of LLMs.

---------------

### 30 Aug 2023 | [Large Language Models as Data Preprocessors](https://arxiv.org/abs/2308.16361) | [⬇️](https://arxiv.org/pdf/2308.16361)
*Haochen Zhang, Yuyang Dong, Chuan Xiao, Masafumi Oyamada* 

  Large Language Models (LLMs), typified by OpenAI's GPT series and Meta's
LLaMA variants, have marked a significant advancement in artificial
intelligence. Trained on vast amounts of text data, LLMs are capable of
understanding and generating human-like text across a diverse range of topics.
This study expands on the applications of LLMs, exploring their potential in
data preprocessing, a critical stage in data mining and analytics applications.
We delve into the applicability of state-of-the-art LLMs such as GPT-3.5,
GPT-4, and Vicuna-13B for error detection, data imputation, schema matching,
and entity matching tasks. Alongside showcasing the inherent capabilities of
LLMs, we highlight their limitations, particularly in terms of computational
expense and inefficiency. We propose an LLM-based framework for data
preprocessing, which integrates cutting-edge prompt engineering techniques,
coupled with traditional methods like contextualization and feature selection,
to improve the performance and efficiency of these models. The effectiveness of
LLMs in data preprocessing is evaluated through an experimental study spanning
12 datasets. GPT-4 emerged as a standout, achieving 100\% accuracy or F1 score
on 4 datasets, suggesting LLMs' immense potential in these tasks. Despite
certain limitations, our study underscores the promise of LLMs in this domain
and anticipates future developments to overcome current hurdles.

---------------

### 10 Feb 2024 | [Sentinels of the Stream: Unleashing Large Language Models for Dynamic  Packet Classification in Software Defined Networks -- Position Paper](https://arxiv.org/abs/2402.07950) | [⬇️](https://arxiv.org/pdf/2402.07950)
*Shariq Murtuza* 

  With the release of OpenAI's ChatGPT, the field of large language models
(LLM) saw an increase of academic interest in GPT based chat assistants. In the
next few months multiple accesible large language models were released that
included Meta's LLama models and Mistral AI's Mistral and Mixtral MoE models.
These models are available openly for a wide array of purposes with a wide
spectrum of licenses. These LLMs have found their use in a different number of
fields like code development, SQL generation etc. In this work we propose our
plan to explore the applicability of large language model in the domain of
network security. We plan to create Sentinel, a LLM, to analyse network packet
contents and pass a judgment on it's threat level. This work is a preliminary
report that will lay our plan for our future endeavors.

---------------

### 28 Aug 2023 | [Fine-Tuning Llama 2 Large Language Models for Detecting Online Sexual  Predatory Chats and Abusive Texts](https://arxiv.org/abs/2308.14683) | [⬇️](https://arxiv.org/pdf/2308.14683)
*Thanh Thi Nguyen, Campbell Wilson, Janis Dalins* 

  Detecting online sexual predatory behaviours and abusive language on social
media platforms has become a critical area of research due to the growing
concerns about online safety, especially for vulnerable populations such as
children and adolescents. Researchers have been exploring various techniques
and approaches to develop effective detection systems that can identify and
mitigate these risks. Recent development of large language models (LLMs) has
opened a new opportunity to address this problem more effectively. This paper
proposes an approach to detection of online sexual predatory chats and abusive
language using the open-source pretrained Llama 2 7B-parameter model, recently
released by Meta GenAI. We fine-tune the LLM using datasets with different
sizes, imbalance degrees, and languages (i.e., English, Roman Urdu and Urdu).
Based on the power of LLMs, our approach is generic and automated without a
manual search for a synergy between feature extraction and classifier design
steps like conventional methods in this domain. Experimental results show a
strong performance of the proposed approach, which performs proficiently and
consistently across three distinct datasets with five sets of experiments. This
study's outcomes indicate that the proposed method can be implemented in
real-world applications (even with non-English languages) for flagging sexual
predators, offensive or toxic content, hate speech, and discriminatory language
in online discussions and comments to maintain respectful internet or digital
communities. Furthermore, it can be employed for solving text classification
problems with other potential applications such as sentiment analysis, spam and
phishing detection, sorting legal documents, fake news detection, language
identification, user intent recognition, text-based product categorization,
medical record analysis, and resume screening.

---------------

### 05 Oct 2023 | [Fine-tuning Aligned Language Models Compromises Safety, Even When Users  Do Not Intend To!](https://arxiv.org/abs/2310.03693) | [⬇️](https://arxiv.org/pdf/2310.03693)
*Xiangyu Qi, Yi Zeng, Tinghao Xie, Pin-Yu Chen, Ruoxi Jia, Prateek  Mittal, Peter Henderson* 

  Optimizing large language models (LLMs) for downstream use cases often
involves the customization of pre-trained LLMs through further fine-tuning.
Meta's open release of Llama models and OpenAI's APIs for fine-tuning GPT-3.5
Turbo on custom datasets also encourage this practice. But, what are the safety
costs associated with such custom fine-tuning? We note that while existing
safety alignment infrastructures can restrict harmful behaviors of LLMs at
inference time, they do not cover safety risks when fine-tuning privileges are
extended to end-users. Our red teaming studies find that the safety alignment
of LLMs can be compromised by fine-tuning with only a few adversarially
designed training examples. For instance, we jailbreak GPT-3.5 Turbo's safety
guardrails by fine-tuning it on only 10 such examples at a cost of less than
$0.20 via OpenAI's APIs, making the model responsive to nearly any harmful
instructions. Disconcertingly, our research also reveals that, even without
malicious intent, simply fine-tuning with benign and commonly used datasets can
also inadvertently degrade the safety alignment of LLMs, though to a lesser
extent. These findings suggest that fine-tuning aligned LLMs introduces new
safety risks that current safety infrastructures fall short of addressing --
even if a model's initial safety alignment is impeccable, it is not necessarily
to be maintained after custom fine-tuning. We outline and critically analyze
potential mitigations and advocate for further research efforts toward
reinforcing safety protocols for the custom fine-tuning of aligned LLMs.

---------------

### 19 Dec 2023 | [Large Language Models in Medical Term Classification and Unexpected  Misalignment Between Response and Reasoning](https://arxiv.org/abs/2312.14184) | [⬇️](https://arxiv.org/pdf/2312.14184)
*Xiaodan Zhang, Sandeep Vemulapalli, Nabasmita Talukdar, Sumyeong Ahn,  Jiankun Wang, Han Meng, Sardar Mehtab Bin Murtaza, Aakash Ajay Dave, Dmitry  Leshchiner, Dimitri F. Joseph, Martin Witteveen-Lane, Dave Chesla, Jiayu  Zhou, and Bin Chen* 

  This study assesses the ability of state-of-the-art large language models
(LLMs) including GPT-3.5, GPT-4, Falcon, and LLaMA 2 to identify patients with
mild cognitive impairment (MCI) from discharge summaries and examines instances
where the models' responses were misaligned with their reasoning. Utilizing the
MIMIC-IV v2.2 database, we focused on a cohort aged 65 and older, verifying MCI
diagnoses against ICD codes and expert evaluations. The data was partitioned
into training, validation, and testing sets in a 7:2:1 ratio for model
fine-tuning and evaluation, with an additional metastatic cancer dataset from
MIMIC III used to further assess reasoning consistency. GPT-4 demonstrated
superior interpretative capabilities, particularly in response to complex
prompts, yet displayed notable response-reasoning inconsistencies. In contrast,
open-source models like Falcon and LLaMA 2 achieved high accuracy but lacked
explanatory reasoning, underscoring the necessity for further research to
optimize both performance and interpretability. The study emphasizes the
significance of prompt engineering and the need for further exploration into
the unexpected reasoning-response misalignment observed in GPT-4. The results
underscore the promise of incorporating LLMs into healthcare diagnostics,
contingent upon methodological advancements to ensure accuracy and clinical
coherence of AI-generated outputs, thereby improving the trustworthiness of
LLMs for medical decision-making.

---------------

### 11 Dec 2023 | [LLM360: Towards Fully Transparent Open-Source LLMs](https://arxiv.org/abs/2312.06550) | [⬇️](https://arxiv.org/pdf/2312.06550)
*Zhengzhong Liu, Aurick Qiao, Willie Neiswanger, Hongyi Wang, Bowen  Tan, Tianhua Tao, Junbo Li, Yuqi Wang, Suqi Sun, Omkar Pangarkar, Richard  Fan, Yi Gu, Victor Miller, Yonghao Zhuang, Guowei He, Haonan Li, Fajri Koto,  Liping Tang, Nikhil Ranjan, Zhiqiang Shen, Xuguang Ren, Roberto Iriondo, Cun  Mu, Zhiting Hu, Mark Schulze, Preslav Nakov, Tim Baldwin, Eric P. Xing* 

  The recent surge in open-source Large Language Models (LLMs), such as LLaMA,
Falcon, and Mistral, provides diverse options for AI practitioners and
researchers. However, most LLMs have only released partial artifacts, such as
the final model weights or inference code, and technical reports increasingly
limit their scope to high-level design choices and surface statistics. These
choices hinder progress in the field by degrading transparency into the
training of LLMs and forcing teams to rediscover many details in the training
process. We present LLM360, an initiative to fully open-source LLMs, which
advocates for all training code and data, model checkpoints, and intermediate
results to be made available to the community. The goal of LLM360 is to support
open and collaborative AI research by making the end-to-end LLM training
process transparent and reproducible by everyone. As a first step of LLM360, we
release two 7B parameter LLMs pre-trained from scratch, Amber and CrystalCoder,
including their training code, data, intermediate checkpoints, and analyses (at
https://www.llm360.ai). We are committed to continually pushing the boundaries
of LLMs through this open-source effort. More large-scale and stronger models
are underway and will be released in the future.

---------------

### 13 Nov 2023 | [VerityMath: Advancing Mathematical Reasoning by Self-Verification  Through Unit Consistency](https://arxiv.org/abs/2311.07172) | [⬇️](https://arxiv.org/pdf/2311.07172)
*Vernon Toh, Ratish Puduppully, Nancy F. Chen* 

  Large Language Models (LLMs) combined with program-based solving techniques
are increasingly demonstrating proficiency in mathematical reasoning. However,
such progress is mostly demonstrated in closed-source models such as
OpenAI-GPT4 and Claude. In this paper, we seek to study the performance of
strong open-source LLMs. Specifically, we analyze the outputs of Code Llama
(7B) when applied to math word problems. We identify a category of problems
that pose a challenge for the model, particularly those involving quantities
that span multiple types or units. To address this issue, we propose a
systematic approach by defining units for each quantity and ensuring the
consistency of these units during mathematical operations. We developed Unit
Consistency Programs (UCPs), an annotated dataset of math word problems, each
paired with programs that contain unit specifications and unit verification
routines. Finally, we finetune the Code Llama (7B) model with UCPs to produce
VerityMath and present our preliminary findings.

---------------

### 15 Dec 2023 | [Distilling Large Language Models for Matching Patients to Clinical  Trials](https://arxiv.org/abs/2312.09958) | [⬇️](https://arxiv.org/pdf/2312.09958)
*Mauro Nievas, Aditya Basu, Yanshan Wang, Hrituraj Singh* 

  The recent success of large language models (LLMs) has paved the way for
their adoption in the high-stakes domain of healthcare. Specifically, the
application of LLMs in patient-trial matching, which involves assessing patient
eligibility against clinical trial's nuanced inclusion and exclusion criteria,
has shown promise. Recent research has shown that GPT-3.5, a widely recognized
LLM developed by OpenAI, can outperform existing methods with minimal 'variable
engineering' by simply comparing clinical trial information against patient
summaries. However, there are significant challenges associated with using
closed-source proprietary LLMs like GPT-3.5 in practical healthcare
applications, such as cost, privacy and reproducibility concerns. To address
these issues, this study presents the first systematic examination of the
efficacy of both proprietary (GPT-3.5, and GPT-4) and open-source LLMs (LLAMA
7B,13B, and 70B) for the task of patient-trial matching. Employing a
multifaceted evaluation framework, we conducted extensive automated and
human-centric assessments coupled with a detailed error analysis for each
model. To enhance the adaptability of open-source LLMs, we have created a
specialized synthetic dataset utilizing GPT-4, enabling effective fine-tuning
under constrained data conditions. Our findings reveal that open-source LLMs,
when fine-tuned on this limited and synthetic dataset, demonstrate performance
parity with their proprietary counterparts. This presents a massive opportunity
for their deployment in real-world healthcare applications. To foster further
research and applications in this field, we release both the annotated
evaluation dataset along with the fine-tuned LLM -- Trial-LLAMA -- for public
use.

---------------

### 22 Dec 2023 | [YAYI 2: Multilingual Open-Source Large Language Models](https://arxiv.org/abs/2312.14862) | [⬇️](https://arxiv.org/pdf/2312.14862)
*Yin Luo, Qingchao Kong, Nan Xu, Jia Cao, Bao Hao, Baoyu Qu, Bo Chen,  Chao Zhu, Chenyang Zhao, Donglei Zhang, Fan Feng, Feifei Zhao, Hailong Sun,  Hanxuan Yang, Haojun Pan, Hongyu Liu, Jianbin Guo, Jiangtao Du, Jingyi Wang,  Junfeng Li, Lei Sun, Liduo Liu, Lifeng Dong, Lili Liu, Lin Wang, Liwen Zhang,  Minzheng Wang, Pin Wang, Ping Yu, Qingxiao Li, Rui Yan, Rui Zou, Ruiqun Li,  Taiwen Huang, Xiaodong Wang, Xiaofei Wu, Xin Peng, Xina Zhang, Xing Fang,  Xinglin Xiao, Yanni Hao, Yao Dong, Yigang Wang, Ying Liu, Yongyu Jiang,  Yungan Wang, Yuqi Wang, Zhangsheng Wang, Zhaoxin Yu, Zhen Luo, Wenji Mao, Lei  Wang, Dajun Zeng* 

  As the latest advancements in natural language processing, large language
models (LLMs) have achieved human-level language understanding and generation
abilities in many real-world tasks, and even have been regarded as a potential
path to the artificial general intelligence. To better facilitate research on
LLMs, many open-source LLMs, such as Llama 2 and Falcon, have recently been
proposed and gained comparable performances to proprietary models. However,
these models are primarily designed for English scenarios and exhibit poor
performances in Chinese contexts. In this technical report, we propose YAYI 2,
including both base and chat models, with 30 billion parameters. YAYI 2 is
pre-trained from scratch on a multilingual corpus which contains 2.65 trillion
tokens filtered by our pre-training data processing pipeline. The base model is
aligned with human values through supervised fine-tuning with millions of
instructions and reinforcement learning from human feedback. Extensive
experiments on multiple benchmarks, such as MMLU and CMMLU, consistently
demonstrate that the proposed YAYI 2 outperforms other similar sized
open-source models.

---------------

### 02 Oct 2023 | [Label Supervised LLaMA Finetuning](https://arxiv.org/abs/2310.01208) | [⬇️](https://arxiv.org/pdf/2310.01208)
*Zongxi Li, Xianming Li, Yuzhang Liu, Haoran Xie, Jing Li, Fu-lee Wang,  Qing Li, Xiaoqin Zhong* 

  The recent success of Large Language Models (LLMs) has gained significant
attention in both academia and industry. Substantial efforts have been made to
enhance the zero- and few-shot generalization capabilities of open-source LLMs
through finetuning. Currently, the prevailing approach is instruction-tuning,
which trains LLMs to complete real-world tasks by generating responses guided
by natural language instructions. It is worth noticing that such an approach
may underperform in sequence and token classification tasks. Unlike text
generation tasks, classification tasks have a limited label space, where
precise label prediction is more appreciated than generating diverse and
human-like responses. Prior research has unveiled that instruction-tuned LLMs
cannot outperform BERT, prompting us to explore the potential of leveraging
latent representations from LLMs for supervised label prediction. In this
paper, we introduce a label-supervised adaptation for LLMs, which aims to
finetuning the model with discriminant labels. We evaluate this approach with
Label Supervised LLaMA (LS-LLaMA), based on LLaMA-2-7B, a relatively
small-scale LLM, and can be finetuned on a single GeForce RTX4090 GPU. We
extract latent representations from the final LLaMA layer and project them into
the label space to compute the cross-entropy loss. The model is finetuned by
Low-Rank Adaptation (LoRA) to minimize this loss. Remarkably, without intricate
prompt engineering or external knowledge, LS-LLaMA substantially outperforms
LLMs ten times its size in scale and demonstrates consistent improvements
compared to robust baselines like BERT-Large and RoBERTa-Large in text
classification. Moreover, by removing the causal mask from decoders, LS-unLLaMA
achieves the state-of-the-art performance in named entity recognition (NER).
Our work will shed light on a novel approach to adapting LLMs for various
downstream tasks.

---------------

### 24 Jun 2023 | [ChatDoctor: A Medical Chat Model Fine-Tuned on a Large Language Model  Meta-AI (LLaMA) Using Medical Domain Knowledge](https://arxiv.org/abs/2303.14070) | [⬇️](https://arxiv.org/pdf/2303.14070)
*Yunxiang Li, Zihan Li, Kai Zhang, Ruilong Dan, Steve Jiang, You Zhang* 

  The primary aim of this research was to address the limitations observed in
the medical knowledge of prevalent large language models (LLMs) such as
ChatGPT, by creating a specialized language model with enhanced accuracy in
medical advice. We achieved this by adapting and refining the large language
model meta-AI (LLaMA) using a large dataset of 100,000 patient-doctor dialogues
sourced from a widely used online medical consultation platform. These
conversations were cleaned and anonymized to respect privacy concerns. In
addition to the model refinement, we incorporated a self-directed information
retrieval mechanism, allowing the model to access and utilize real-time
information from online sources like Wikipedia and data from curated offline
medical databases. The fine-tuning of the model with real-world patient-doctor
interactions significantly improved the model's ability to understand patient
needs and provide informed advice. By equipping the model with self-directed
information retrieval from reliable online and offline sources, we observed
substantial improvements in the accuracy of its responses. Our proposed
ChatDoctor, represents a significant advancement in medical LLMs, demonstrating
a significant improvement in understanding patient inquiries and providing
accurate advice. Given the high stakes and low error tolerance in the medical
field, such enhancements in providing accurate and reliable information are not
only beneficial but essential.

---------------

### 22 May 2023 | [Observations on LLMs for Telecom Domain: Capabilities and Limitations](https://arxiv.org/abs/2305.13102) | [⬇️](https://arxiv.org/pdf/2305.13102)
*Sumit Soman, Ranjani H G* 

  The landscape for building conversational interfaces (chatbots) has witnessed
a paradigm shift with recent developments in generative Artificial Intelligence
(AI) based Large Language Models (LLMs), such as ChatGPT by OpenAI (GPT3.5 and
GPT4), Google's Bard, Large Language Model Meta AI (LLaMA), among others. In
this paper, we analyze capabilities and limitations of incorporating such
models in conversational interfaces for the telecommunication domain,
specifically for enterprise wireless products and services. Using Cradlepoint's
publicly available data for our experiments, we present a comparative analysis
of the responses from such models for multiple use-cases including domain
adaptation for terminology and product taxonomy, context continuity, robustness
to input perturbations and errors. We believe this evaluation would provide
useful insights to data scientists engaged in building customized
conversational interfaces for domain-specific requirements.

---------------

### 03 Oct 2023 | [ToolLLM: Facilitating Large Language Models to Master 16000+ Real-world  APIs](https://arxiv.org/abs/2307.16789) | [⬇️](https://arxiv.org/pdf/2307.16789)
*Yujia Qin, Shihao Liang, Yining Ye, Kunlun Zhu, Lan Yan, Yaxi Lu,  Yankai Lin, Xin Cong, Xiangru Tang, Bill Qian, Sihan Zhao, Lauren Hong,  Runchu Tian, Ruobing Xie, Jie Zhou, Mark Gerstein, Dahai Li, Zhiyuan Liu,  Maosong Sun* 

  Despite the advancements of open-source large language models (LLMs), e.g.,
LLaMA, they remain significantly limited in tool-use capabilities, i.e., using
external tools (APIs) to fulfill human instructions. The reason is that current
instruction tuning largely focuses on basic language tasks but ignores the
tool-use domain. This is in contrast to the excellent tool-use capabilities of
state-of-the-art (SOTA) closed-source LLMs, e.g., ChatGPT. To bridge this gap,
we introduce ToolLLM, a general tool-use framework encompassing data
construction, model training, and evaluation. We first present ToolBench, an
instruction-tuning dataset for tool use, which is constructed automatically
using ChatGPT. Specifically, the construction can be divided into three stages:
(i) API collection: we collect 16,464 real-world RESTful APIs spanning 49
categories from RapidAPI Hub; (ii) instruction generation: we prompt ChatGPT to
generate diverse instructions involving these APIs, covering both single-tool
and multi-tool scenarios; (iii) solution path annotation: we use ChatGPT to
search for a valid solution path (chain of API calls) for each instruction. To
enhance the reasoning capabilities of LLMs, we develop a novel depth-first
search-based decision tree algorithm. It enables LLMs to evaluate multiple
reasoning traces and expand the search space. Moreover, to evaluate the
tool-use capabilities of LLMs, we develop an automatic evaluator: ToolEval.
Based on ToolBench, we fine-tune LLaMA to obtain an LLM ToolLLaMA, and equip it
with a neural API retriever to recommend appropriate APIs for each instruction.
Experiments show that ToolLLaMA demonstrates a remarkable ability to execute
complex instructions and generalize to unseen APIs, and exhibits comparable
performance to ChatGPT. Our ToolLLaMA also demonstrates strong zero-shot
generalization ability in an out-of-distribution tool-use dataset: APIBench.

---------------

### 12 Sep 2023 | [Comparing Llama-2 and GPT-3 LLMs for HPC kernels generation](https://arxiv.org/abs/2309.07103) | [⬇️](https://arxiv.org/pdf/2309.07103)
*Pedro Valero-Lara, Alexis Huante, Mustafa Al Lail, William F. Godoy,  Keita Teranishi, Prasanna Balaprakash, Jeffrey S. Vetter* 

  We evaluate the use of the open-source Llama-2 model for generating
well-known, high-performance computing kernels (e.g., AXPY, GEMV, GEMM) on
different parallel programming models and languages (e.g., C++: OpenMP, OpenMP
Offload, OpenACC, CUDA, HIP; Fortran: OpenMP, OpenMP Offload, OpenACC; Python:
numpy, Numba, pyCUDA, cuPy; and Julia: Threads, CUDA.jl, AMDGPU.jl). We built
upon our previous work that is based on the OpenAI Codex, which is a descendant
of GPT-3, to generate similar kernels with simple prompts via GitHub Copilot.
Our goal is to compare the accuracy of Llama-2 and our original GPT-3 baseline
by using a similar metric. Llama-2 has a simplified model that shows
competitive or even superior accuracy. We also report on the differences
between these foundational large language models as generative AI continues to
redefine human-computer interactions. Overall, Copilot generates codes that are
more reliable but less optimized, whereas codes generated by Llama-2 are less
reliable but more optimized when correct.

---------------

### 05 Jan 2024 | [DeepSeek LLM: Scaling Open-Source Language Models with Longtermism](https://arxiv.org/abs/2401.02954) | [⬇️](https://arxiv.org/pdf/2401.02954)
*DeepSeek-AI: Xiao Bi, Deli Chen, Guanting Chen, Shanhuang Chen, Damai  Dai, Chengqi Deng, Honghui Ding, Kai Dong, Qiushi Du, Zhe Fu, Huazuo Gao,  Kaige Gao, Wenjun Gao, Ruiqi Ge, Kang Guan, Daya Guo, Jianzhong Guo, Guangbo  Hao, Zhewen Hao, Ying He, Wenjie Hu, Panpan Huang, Erhang Li, Guowei Li,  Jiashi Li, Yao Li, Y.K. Li, Wenfeng Liang, Fangyun Lin, A.X. Liu, Bo Liu, Wen  Liu, Xiaodong Liu, Xin Liu, Yiyuan Liu, Haoyu Lu, Shanghao Lu, Fuli Luo,  Shirong Ma, Xiaotao Nie, Tian Pei, Yishi Piao, Junjie Qiu, Hui Qu, Tongzheng  Ren, Zehui Ren, Chong Ruan, Zhangli Sha, Zhihong Shao, Junxiao Song, Xuecheng  Su, Jingxiang Sun, Yaofeng Sun, Minghui Tang, Bingxuan Wang, Peiyi Wang,  Shiyu Wang, Yaohui Wang, Yongji Wang, Tong Wu, Y. Wu, Xin Xie, Zhenda Xie,  Ziwei Xie, Yiliang Xiong, Hanwei Xu, R.X. Xu, Yanhong Xu, Dejian Yang,  Yuxiang You, Shuiping Yu, Xingkai Yu, B. Zhang, Haowei Zhang, Lecong Zhang,  Liyue Zhang, Mingchuan Zhang, Minghua Zhang, Wentao Zhang, Yichao Zhang,  Chenggang Zhao, Yao Zhao, Shangyan Zhou, Shunfeng Zhou, Qihao Zhu, Yuheng Zou* 

  The rapid development of open-source large language models (LLMs) has been
truly remarkable. However, the scaling law described in previous literature
presents varying conclusions, which casts a dark cloud over scaling LLMs. We
delve into the study of scaling laws and present our distinctive findings that
facilitate scaling of large scale models in two commonly used open-source
configurations, 7B and 67B. Guided by the scaling laws, we introduce DeepSeek
LLM, a project dedicated to advancing open-source language models with a
long-term perspective. To support the pre-training phase, we have developed a
dataset that currently consists of 2 trillion tokens and is continuously
expanding. We further conduct supervised fine-tuning (SFT) and Direct
Preference Optimization (DPO) on DeepSeek LLM Base models, resulting in the
creation of DeepSeek Chat models. Our evaluation results demonstrate that
DeepSeek LLM 67B surpasses LLaMA-2 70B on various benchmarks, particularly in
the domains of code, mathematics, and reasoning. Furthermore, open-ended
evaluations reveal that DeepSeek LLM 67B Chat exhibits superior performance
compared to GPT-3.5.

---------------

### 04 Jan 2024 | [Blar-SQL: Faster, Stronger, Smaller NL2SQL](https://arxiv.org/abs/2401.02997) | [⬇️](https://arxiv.org/pdf/2401.02997)
*Jos\'e Manuel Dom\'inguez, Benjam\'in Err\'azuriz, Patricio Daher* 

  Large Language Models (LLMs) have gained considerable notoriety in the field
of natural language to SQL tasks (NL2SQL). In this study, we show how task
decomposition can greatly benefit LLMs in database understanding and query
generation in order to answer human questions with an SQL query.
  We fined-tuned open source models, specifically Llama-2 and Code Llama, by
combining 2 different models each designated to focus on one of two tasks in
order to leverage each model's core competency to further increase the accuracy
of the final SQL query.
  We propose a new framework to divide the schema into chunks in order to fit
more information into a limited context. Our results are comparable with those
obtained by GPT-4 at the same time being 135 times smaller, 90 times faster and
more than 100 times cheaper than GPT-4.

---------------
**Date:** 09 Oct 2023

**Title:** MetaMath: Bootstrap Your Own Mathematical Questions for Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2309.12284](https://arxiv.org/abs/2309.12284)

**PDF Link:** [https://arxiv.org/pdf/2309.12284](https://arxiv.org/pdf/2309.12284)

---

**Date:** 21 Nov 2023

**Title:** A Survey on Large Language Models for Personalized and Explainable  Recommendations

**Abstract Link:** [https://arxiv.org/abs/2311.12338](https://arxiv.org/abs/2311.12338)

**PDF Link:** [https://arxiv.org/pdf/2311.12338](https://arxiv.org/pdf/2311.12338)

---

**Date:** 15 Dec 2023

**Title:** LLaMAntino: LLaMA 2 Models for Effective Text Generation in Italian  Language

**Abstract Link:** [https://arxiv.org/abs/2312.09993](https://arxiv.org/abs/2312.09993)

**PDF Link:** [https://arxiv.org/pdf/2312.09993](https://arxiv.org/pdf/2312.09993)

---

**Date:** 19 Jul 2023

**Title:** Llama 2: Open Foundation and Fine-Tuned Chat Models

**Abstract Link:** [https://arxiv.org/abs/2307.09288](https://arxiv.org/abs/2307.09288)

**PDF Link:** [https://arxiv.org/pdf/2307.09288](https://arxiv.org/pdf/2307.09288)

---

**Date:** 30 Aug 2023

**Title:** Large Language Models as Data Preprocessors

**Abstract Link:** [https://arxiv.org/abs/2308.16361](https://arxiv.org/abs/2308.16361)

**PDF Link:** [https://arxiv.org/pdf/2308.16361](https://arxiv.org/pdf/2308.16361)

---

**Date:** 10 Feb 2024

**Title:** Sentinels of the Stream: Unleashing Large Language Models for Dynamic  Packet Classification in Software Defined Networks -- Position Paper

**Abstract Link:** [https://arxiv.org/abs/2402.07950](https://arxiv.org/abs/2402.07950)

**PDF Link:** [https://arxiv.org/pdf/2402.07950](https://arxiv.org/pdf/2402.07950)

---

**Date:** 28 Aug 2023

**Title:** Fine-Tuning Llama 2 Large Language Models for Detecting Online Sexual  Predatory Chats and Abusive Texts

**Abstract Link:** [https://arxiv.org/abs/2308.14683](https://arxiv.org/abs/2308.14683)

**PDF Link:** [https://arxiv.org/pdf/2308.14683](https://arxiv.org/pdf/2308.14683)

---

**Date:** 05 Oct 2023

**Title:** Fine-tuning Aligned Language Models Compromises Safety, Even When Users  Do Not Intend To!

**Abstract Link:** [https://arxiv.org/abs/2310.03693](https://arxiv.org/abs/2310.03693)

**PDF Link:** [https://arxiv.org/pdf/2310.03693](https://arxiv.org/pdf/2310.03693)

---

**Date:** 19 Dec 2023

**Title:** Large Language Models in Medical Term Classification and Unexpected  Misalignment Between Response and Reasoning

**Abstract Link:** [https://arxiv.org/abs/2312.14184](https://arxiv.org/abs/2312.14184)

**PDF Link:** [https://arxiv.org/pdf/2312.14184](https://arxiv.org/pdf/2312.14184)

---

**Date:** 11 Dec 2023

**Title:** LLM360: Towards Fully Transparent Open-Source LLMs

**Abstract Link:** [https://arxiv.org/abs/2312.06550](https://arxiv.org/abs/2312.06550)

**PDF Link:** [https://arxiv.org/pdf/2312.06550](https://arxiv.org/pdf/2312.06550)

---

**Date:** 13 Nov 2023

**Title:** VerityMath: Advancing Mathematical Reasoning by Self-Verification  Through Unit Consistency

**Abstract Link:** [https://arxiv.org/abs/2311.07172](https://arxiv.org/abs/2311.07172)

**PDF Link:** [https://arxiv.org/pdf/2311.07172](https://arxiv.org/pdf/2311.07172)

---

**Date:** 15 Dec 2023

**Title:** Distilling Large Language Models for Matching Patients to Clinical  Trials

**Abstract Link:** [https://arxiv.org/abs/2312.09958](https://arxiv.org/abs/2312.09958)

**PDF Link:** [https://arxiv.org/pdf/2312.09958](https://arxiv.org/pdf/2312.09958)

---

**Date:** 22 Dec 2023

**Title:** YAYI 2: Multilingual Open-Source Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2312.14862](https://arxiv.org/abs/2312.14862)

**PDF Link:** [https://arxiv.org/pdf/2312.14862](https://arxiv.org/pdf/2312.14862)

---

**Date:** 02 Oct 2023

**Title:** Label Supervised LLaMA Finetuning

**Abstract Link:** [https://arxiv.org/abs/2310.01208](https://arxiv.org/abs/2310.01208)

**PDF Link:** [https://arxiv.org/pdf/2310.01208](https://arxiv.org/pdf/2310.01208)

---

**Date:** 24 Jun 2023

**Title:** ChatDoctor: A Medical Chat Model Fine-Tuned on a Large Language Model  Meta-AI (LLaMA) Using Medical Domain Knowledge

**Abstract Link:** [https://arxiv.org/abs/2303.14070](https://arxiv.org/abs/2303.14070)

**PDF Link:** [https://arxiv.org/pdf/2303.14070](https://arxiv.org/pdf/2303.14070)

---

**Date:** 22 May 2023

**Title:** Observations on LLMs for Telecom Domain: Capabilities and Limitations

**Abstract Link:** [https://arxiv.org/abs/2305.13102](https://arxiv.org/abs/2305.13102)

**PDF Link:** [https://arxiv.org/pdf/2305.13102](https://arxiv.org/pdf/2305.13102)

---

**Date:** 03 Oct 2023

**Title:** ToolLLM: Facilitating Large Language Models to Master 16000+ Real-world  APIs

**Abstract Link:** [https://arxiv.org/abs/2307.16789](https://arxiv.org/abs/2307.16789)

**PDF Link:** [https://arxiv.org/pdf/2307.16789](https://arxiv.org/pdf/2307.16789)

---

**Date:** 12 Sep 2023

**Title:** Comparing Llama-2 and GPT-3 LLMs for HPC kernels generation

**Abstract Link:** [https://arxiv.org/abs/2309.07103](https://arxiv.org/abs/2309.07103)

**PDF Link:** [https://arxiv.org/pdf/2309.07103](https://arxiv.org/pdf/2309.07103)

---

**Date:** 05 Jan 2024

**Title:** DeepSeek LLM: Scaling Open-Source Language Models with Longtermism

**Abstract Link:** [https://arxiv.org/abs/2401.02954](https://arxiv.org/abs/2401.02954)

**PDF Link:** [https://arxiv.org/pdf/2401.02954](https://arxiv.org/pdf/2401.02954)

---

**Date:** 04 Jan 2024

**Title:** Blar-SQL: Faster, Stronger, Smaller NL2SQL

**Abstract Link:** [https://arxiv.org/abs/2401.02997](https://arxiv.org/abs/2401.02997)

**PDF Link:** [https://arxiv.org/pdf/2401.02997](https://arxiv.org/pdf/2401.02997)

---

