OpenAI: GPT-4 DALL-E Foundation Models 🔵

### 🔎 OpenAI: GPT-4 DALL-E Foundation Models 🔵



OpenAI is a research organization dedicated to promoting and developing friendly AI in a way that benefits humanity as a whole. They have developed several powerful AI models, including GPT-3, GPT-4, and DALL-E.

GPT-3 (Generative Pretrained Transformer 3) is a language model that uses deep learning to produce human-like text. It is trained on a large dataset of text and can generate coherent and contextually relevant sentences. GPT-3 has been used in a variety of applications, including chatbots, text generation, and translation.

GPT-4 is the successor to GPT-3 and is even more powerful. It has been trained on an even larger dataset of text and is capable of generating more sophisticated and nuanced text. GPT-4 is also able to understand and respond to more complex instructions and prompts.

DALL-E is a model that uses deep learning to generate images from textual descriptions. It is trained on a large dataset of images and text and is able to generate realistic and detailed images based on textual prompts. DALL-E has been used to create a wide variety of images, including landscapes, objects, and characters.

OpenAI's foundation models, including GPT-3, GPT-4, and DALL-E, are powerful tools that have the potential to revolutionize a wide range of industries and applications. However, they also raise important ethical and societal concerns, and OpenAI is committed to working responsibly and transparently to ensure that these models are used in a way that benefits humanity as a whole.</s>
# 🩺🔍 Search Results
### 12 Dec 2023 | [Enhancing Medical Task Performance in GPT-4V: A Comprehensive Study on  Prompt Engineering Strategies](https://arxiv.org/abs/2312.04344) | [⬇️](https://arxiv.org/pdf/2312.04344)
*Pengcheng Chen, Ziyan Huang, Zhongying Deng, Tianbin Li, Yanzhou Su,  Haoyu Wang, Jin Ye, Yu Qiao, Junjun He* 

  OpenAI's latest large vision-language model (LVLM), GPT-4V(ision), has piqued
considerable interest for its potential in medical applications. Despite its
promise, recent studies and internal reviews highlight its underperformance in
specialized medical tasks. This paper explores the boundary of GPT-4V's
capabilities in medicine, particularly in processing complex imaging data from
endoscopies, CT scans, and MRIs etc. Leveraging open-source datasets, we
assessed its foundational competencies, identifying substantial areas for
enhancement. Our research emphasizes prompt engineering, an often-underutilized
strategy for improving AI responsiveness. Through iterative testing, we refined
the model's prompts, significantly improving its interpretative accuracy and
relevance in medical imaging. From our comprehensive evaluations, we distilled
10 effective prompt engineering techniques, each fortifying GPT-4V's medical
acumen. These methodical enhancements facilitate more reliable, precise, and
clinically valuable insights from GPT-4V, advancing its operability in critical
healthcare environments. Our findings are pivotal for those employing AI in
medicine, providing clear, actionable guidance on harnessing GPT-4V's full
diagnostic potential.

---------------

### 22 Dec 2023 | [Gemini vs GPT-4V: A Preliminary Comparison and Combination of  Vision-Language Models Through Qualitative Cases](https://arxiv.org/abs/2312.15011) | [⬇️](https://arxiv.org/pdf/2312.15011)
*Zhangyang Qi, Ye Fang, Mengchen Zhang, Zeyi Sun, Tong Wu, Ziwei Liu,  Dahua Lin, Jiaqi Wang, Hengshuang Zhao* 

  The rapidly evolving sector of Multi-modal Large Language Models (MLLMs) is
at the forefront of integrating linguistic and visual processing in artificial
intelligence. This paper presents an in-depth comparative study of two
pioneering models: Google's Gemini and OpenAI's GPT-4V(ision). Our study
involves a multi-faceted evaluation of both models across key dimensions such
as Vision-Language Capability, Interaction with Humans, Temporal Understanding,
and assessments in both Intelligence and Emotional Quotients. The core of our
analysis delves into the distinct visual comprehension abilities of each model.
We conducted a series of structured experiments to evaluate their performance
in various industrial application scenarios, offering a comprehensive
perspective on their practical utility. We not only involve direct performance
comparisons but also include adjustments in prompts and scenarios to ensure a
balanced and fair analysis. Our findings illuminate the unique strengths and
niches of both models. GPT-4V distinguishes itself with its precision and
succinctness in responses, while Gemini excels in providing detailed, expansive
answers accompanied by relevant imagery and links. These understandings not
only shed light on the comparative merits of Gemini and GPT-4V but also
underscore the evolving landscape of multimodal foundation models, paving the
way for future advancements in this area. After the comparison, we attempted to
achieve better results by combining the two models. Finally, We would like to
express our profound gratitude to the teams behind GPT-4V and Gemini for their
pioneering contributions to the field. Our acknowledgments are also extended to
the comprehensive qualitative analysis presented in 'Dawn' by Yang et al. This
work, with its extensive collection of image samples, prompts, and
GPT-4V-related results, provided a foundational basis for our analysis.

---------------

### 04 Dec 2023 | [Can GPT-4V(ision) Serve Medical Applications? Case Studies on GPT-4V for  Multimodal Medical Diagnosis](https://arxiv.org/abs/2310.09909) | [⬇️](https://arxiv.org/pdf/2310.09909)
*Chaoyi Wu, Jiayu Lei, Qiaoyu Zheng, Weike Zhao, Weixiong Lin, Xiaoman  Zhang, Xiao Zhou, Ziheng Zhao, Ya Zhang, Yanfeng Wang and Weidi Xie* 

  Driven by the large foundation models, the development of artificial
intelligence has witnessed tremendous progress lately, leading to a surge of
general interest from the public. In this study, we aim to assess the
performance of OpenAI's newest model, GPT-4V(ision), specifically in the realm
of multimodal medical diagnosis. Our evaluation encompasses 17 human body
systems, including Central Nervous System, Head and Neck, Cardiac, Chest,
Hematology, Hepatobiliary, Gastrointestinal, Urogenital, Gynecology,
Obstetrics, Breast, Musculoskeletal, Spine, Vascular, Oncology, Trauma,
Pediatrics, with images taken from 8 modalities used in daily clinic routine,
e.g., X-ray, Computed Tomography (CT), Magnetic Resonance Imaging (MRI),
Positron Emission Tomography (PET), Digital Subtraction Angiography (DSA),
Mammography, Ultrasound, and Pathology. We probe the GPT-4V's ability on
multiple clinical tasks with or without patent history provided, including
imaging modality and anatomy recognition, disease diagnosis, report generation,
disease localisation.
  Our observation shows that, while GPT-4V demonstrates proficiency in
distinguishing between medical image modalities and anatomy, it faces
significant challenges in disease diagnosis and generating comprehensive
reports. These findings underscore that while large multimodal models have made
significant advancements in computer vision and natural language processing, it
remains far from being used to effectively support real-world medical
applications and clinical decision-making.
  All images used in this report can be found in
https://github.com/chaoyi-wu/GPT-4V_Medical_Evaluation.

---------------

### 16 Nov 2023 | [UnifiedVisionGPT: Streamlining Vision-Oriented AI through Generalized  Multimodal Framework](https://arxiv.org/abs/2311.10125) | [⬇️](https://arxiv.org/pdf/2311.10125)
*Chris Kelly, Luhui Hu, Cindy Yang, Yu Tian, Deshun Yang, Bang Yang,  Zaoshan Huang, Zihao Li, Yuexian Zou* 

  In the current landscape of artificial intelligence, foundation models serve
as the bedrock for advancements in both language and vision domains. OpenAI
GPT-4 has emerged as the pinnacle in large language models (LLMs), while the
computer vision (CV) domain boasts a plethora of state-of-the-art (SOTA) models
such as Meta's SAM and DINO, and YOLOS. However, the financial and
computational burdens of training new models from scratch remain a significant
barrier to progress. In response to this challenge, we introduce
UnifiedVisionGPT, a novel framework designed to consolidate and automate the
integration of SOTA vision models, thereby facilitating the development of
vision-oriented AI. UnifiedVisionGPT distinguishes itself through four key
features: (1) provides a versatile multimodal framework adaptable to a wide
range of applications, building upon the strengths of multimodal foundation
models; (2) seamlessly integrates various SOTA vision models to create a
comprehensive multimodal platform, capitalizing on the best components of each
model; (3) prioritizes vision-oriented AI, ensuring a more rapid progression in
the CV domain compared to the current trajectory of LLMs; and (4) introduces
automation in the selection of SOTA vision models, generating optimal results
based on diverse multimodal inputs such as text prompts and images. This paper
outlines the architecture and capabilities of UnifiedVisionGPT, demonstrating
its potential to revolutionize the field of computer vision through enhanced
efficiency, versatility, generalization, and performance. Our implementation,
along with the unified multimodal framework and comprehensive dataset, is made
publicly available at https://github.com/LHBuilder/SA-Segment-Anything.

---------------

### 16 Jan 2024 | [Forging Vision Foundation Models for Autonomous Driving: Challenges,  Methodologies, and Opportunities](https://arxiv.org/abs/2401.08045) | [⬇️](https://arxiv.org/pdf/2401.08045)
*Xu Yan, Haiming Zhang, Yingjie Cai, Jingming Guo, Weichao Qiu, Bin  Gao, Kaiqiang Zhou, Yue Zhao, Huan Jin, Jiantao Gao, Zhen Li, Lihui Jiang,  Wei Zhang, Hongbo Zhang, Dengxin Dai, Bingbing Liu* 

  The rise of large foundation models, trained on extensive datasets, is
revolutionizing the field of AI. Models such as SAM, DALL-E2, and GPT-4
showcase their adaptability by extracting intricate patterns and performing
effectively across diverse tasks, thereby serving as potent building blocks for
a wide range of AI applications. Autonomous driving, a vibrant front in AI
applications, remains challenged by the lack of dedicated vision foundation
models (VFMs). The scarcity of comprehensive training data, the need for
multi-sensor integration, and the diverse task-specific architectures pose
significant obstacles to the development of VFMs in this field. This paper
delves into the critical challenge of forging VFMs tailored specifically for
autonomous driving, while also outlining future directions. Through a
systematic analysis of over 250 papers, we dissect essential techniques for VFM
development, including data preparation, pre-training strategies, and
downstream task adaptation. Moreover, we explore key advancements such as NeRF,
diffusion models, 3D Gaussian Splatting, and world models, presenting a
comprehensive roadmap for future research. To empower researchers, we have
built and maintained https://github.com/zhanghm1995/Forge_VFM4AD, an
open-access repository constantly updated with the latest advancements in
forging VFMs for autonomous driving.

---------------

### 11 Oct 2023 | [The Dawn of LMMs: Preliminary Explorations with GPT-4V(ision)](https://arxiv.org/abs/2309.17421) | [⬇️](https://arxiv.org/pdf/2309.17421)
*Zhengyuan Yang, Linjie Li, Kevin Lin, Jianfeng Wang, Chung-Ching Lin,  Zicheng Liu, Lijuan Wang* 

  Large multimodal models (LMMs) extend large language models (LLMs) with
multi-sensory skills, such as visual understanding, to achieve stronger generic
intelligence. In this paper, we analyze the latest model, GPT-4V(ision), to
deepen the understanding of LMMs. The analysis focuses on the intriguing tasks
that GPT-4V can perform, containing test samples to probe the quality and
genericity of GPT-4V's capabilities, its supported inputs and working modes,
and the effective ways to prompt the model. In our approach to exploring
GPT-4V, we curate and organize a collection of carefully designed qualitative
samples spanning a variety of domains and tasks. Observations from these
samples demonstrate that GPT-4V's unprecedented ability in processing
arbitrarily interleaved multimodal inputs and the genericity of its
capabilities together make GPT-4V a powerful multimodal generalist system.
Furthermore, GPT-4V's unique capability of understanding visual markers drawn
on input images can give rise to new human-computer interaction methods such as
visual referring prompting. We conclude the report with in-depth discussions on
the emerging application scenarios and the future research directions for
GPT-4V-based systems. We hope that this preliminary exploration will inspire
future research on the next-generation multimodal task formulation, new ways to
exploit and enhance LMMs to solve real-world problems, and gaining better
understanding of multimodal foundation models. Finally, we acknowledge that the
model under our study is solely the product of OpenAI's innovative work, and
they should be fully credited for its development. Please see the GPT-4V
contributions paper for the authorship and credit attribution:
https://cdn.openai.com/contributions/gpt-4v.pdf

---------------

### 04 May 2023 | [Gpt-4: A Review on Advancements and Opportunities in Natural Language  Processing](https://arxiv.org/abs/2305.03195) | [⬇️](https://arxiv.org/pdf/2305.03195)
*Jawid Ahmad Baktash and Mursal Dawodi* 

  Generative Pre-trained Transformer 4 (GPT-4) is the fourth-generation
language model in the GPT series, developed by OpenAI, which promises
significant advancements in the field of natural language processing (NLP). In
this research article, we have discussed the features of GPT-4, its potential
applications, and the challenges that it might face. We have also compared
GPT-4 with its predecessor, GPT-3. GPT-4 has a larger model size (more than one
trillion), better multilingual capabilities, improved contextual understanding,
and reasoning capabilities than GPT-3. Some of the potential applications of
GPT-4 include chatbots, personal assistants, language translation, text
summarization, and question-answering. However, GPT-4 poses several challenges
and limitations such as computational requirements, data requirements, and
ethical concerns.

---------------

### 16 Jan 2024 | [AiGen-FoodReview: A Multimodal Dataset of Machine-Generated Restaurant  Reviews and Images on Social Media](https://arxiv.org/abs/2401.08825) | [⬇️](https://arxiv.org/pdf/2401.08825)
*Alessandro Gambetti, Qiwei Han* 

  Online reviews in the form of user-generated content (UGC) significantly
impact consumer decision-making. However, the pervasive issue of not only human
fake content but also machine-generated content challenges UGC's reliability.
Recent advances in Large Language Models (LLMs) may pave the way to fabricate
indistinguishable fake generated content at a much lower cost. Leveraging
OpenAI's GPT-4-Turbo and DALL-E-2 models, we craft AiGen-FoodReview, a
multi-modal dataset of 20,144 restaurant review-image pairs divided into
authentic and machine-generated. We explore unimodal and multimodal detection
models, achieving 99.80% multimodal accuracy with FLAVA. We use attributes from
readability and photographic theories to score reviews and images,
respectively, demonstrating their utility as hand-crafted features in scalable
and interpretable detection models, with comparable performance. The paper
contributes by open-sourcing the dataset and releasing fake review detectors,
recommending its use in unimodal and multimodal fake review detection tasks,
and evaluating linguistic and visual features in synthetic versus authentic
data.

---------------

### 10 Aug 2023 | [Adaptive Low Rank Adaptation of Segment Anything to Salient Object  Detection](https://arxiv.org/abs/2308.05426) | [⬇️](https://arxiv.org/pdf/2308.05426)
*Ruikai Cui, Siyuan He, Shi Qiu* 

  Foundation models, such as OpenAI's GPT-3 and GPT-4, Meta's LLaMA, and
Google's PaLM2, have revolutionized the field of artificial intelligence. A
notable paradigm shift has been the advent of the Segment Anything Model (SAM),
which has exhibited a remarkable capability to segment real-world objects,
trained on 1 billion masks and 11 million images. Although SAM excels in
general object segmentation, it lacks the intrinsic ability to detect salient
objects, resulting in suboptimal performance in this domain. To address this
challenge, we present the Segment Salient Object Model (SSOM), an innovative
approach that adaptively fine-tunes SAM for salient object detection by
harnessing the low-rank structure inherent in deep learning. Comprehensive
qualitative and quantitative evaluations across five challenging RGB benchmark
datasets demonstrate the superior performance of our approach, surpassing
state-of-the-art methods.

---------------

### 13 Apr 2023 | [Sparks of Artificial General Intelligence: Early experiments with GPT-4](https://arxiv.org/abs/2303.12712) | [⬇️](https://arxiv.org/pdf/2303.12712)
*S\'ebastien Bubeck, Varun Chandrasekaran, Ronen Eldan, Johannes  Gehrke, Eric Horvitz, Ece Kamar, Peter Lee, Yin Tat Lee, Yuanzhi Li, Scott  Lundberg, Harsha Nori, Hamid Palangi, Marco Tulio Ribeiro, Yi Zhang* 

  Artificial intelligence (AI) researchers have been developing and refining
large language models (LLMs) that exhibit remarkable capabilities across a
variety of domains and tasks, challenging our understanding of learning and
cognition. The latest model developed by OpenAI, GPT-4, was trained using an
unprecedented scale of compute and data. In this paper, we report on our
investigation of an early version of GPT-4, when it was still in active
development by OpenAI. We contend that (this early version of) GPT-4 is part of
a new cohort of LLMs (along with ChatGPT and Google's PaLM for example) that
exhibit more general intelligence than previous AI models. We discuss the
rising capabilities and implications of these models. We demonstrate that,
beyond its mastery of language, GPT-4 can solve novel and difficult tasks that
span mathematics, coding, vision, medicine, law, psychology and more, without
needing any special prompting. Moreover, in all of these tasks, GPT-4's
performance is strikingly close to human-level performance, and often vastly
surpasses prior models such as ChatGPT. Given the breadth and depth of GPT-4's
capabilities, we believe that it could reasonably be viewed as an early (yet
still incomplete) version of an artificial general intelligence (AGI) system.
In our exploration of GPT-4, we put special emphasis on discovering its
limitations, and we discuss the challenges ahead for advancing towards deeper
and more comprehensive versions of AGI, including the possible need for
pursuing a new paradigm that moves beyond next-word prediction. We conclude
with reflections on societal influences of the recent technological leap and
future research directions.

---------------

### 12 Sep 2023 | [Galactic ChitChat: Using Large Language Models to Converse with  Astronomy Literature](https://arxiv.org/abs/2304.05406) | [⬇️](https://arxiv.org/pdf/2304.05406)
*Ioana Ciuc\u{a} and Yuan-Sen Ting* 

  We demonstrate the potential of the state-of-the-art OpenAI GPT-4 large
language model to engage in meaningful interactions with Astronomy papers using
in-context prompting. To optimize for efficiency, we employ a distillation
technique that effectively reduces the size of the original input paper by
50\%, while maintaining the paragraph structure and overall semantic integrity.
We then explore the model's responses using a multi-document context (ten
distilled documents). Our findings indicate that GPT-4 excels in the
multi-document domain, providing detailed answers contextualized within the
framework of related research findings. Our results showcase the potential of
large language models for the astronomical community, offering a promising
avenue for further exploration, particularly the possibility of utilizing the
models for hypothesis generation.

---------------

### 02 Jan 2024 | [Evaluating Large Language Models on the GMAT: Implications for the  Future of Business Education](https://arxiv.org/abs/2401.02985) | [⬇️](https://arxiv.org/pdf/2401.02985)
*Vahid Ashrafimoghari, Necdet G\"urkan, and Jordan W. Suchow* 

  The rapid evolution of artificial intelligence (AI), especially in the domain
of Large Language Models (LLMs) and generative AI, has opened new avenues for
application across various fields, yet its role in business education remains
underexplored. This study introduces the first benchmark to assess the
performance of seven major LLMs, OpenAI's models (GPT-3.5 Turbo, GPT-4, and
GPT-4 Turbo), Google's models (PaLM 2, Gemini 1.0 Pro), and Anthropic's models
(Claude 2 and Claude 2.1), on the GMAT, which is a key exam in the admission
process for graduate business programs. Our analysis shows that most LLMs
outperform human candidates, with GPT-4 Turbo not only outperforming the other
models but also surpassing the average scores of graduate students at top
business schools. Through a case study, this research examines GPT-4 Turbo's
ability to explain answers, evaluate responses, identify errors, tailor
instructions, and generate alternative scenarios. The latest LLM versions,
GPT-4 Turbo, Claude 2.1, and Gemini 1.0 Pro, show marked improvements in
reasoning tasks compared to their predecessors, underscoring their potential
for complex problem-solving. While AI's promise in education, assessment, and
tutoring is clear, challenges remain. Our study not only sheds light on LLMs'
academic potential but also emphasizes the need for careful development and
application of AI in education. As AI technology advances, it is imperative to
establish frameworks and protocols for AI interaction, verify the accuracy of
AI-generated content, ensure worldwide access for diverse learners, and create
an educational environment where AI supports human expertise. This research
sets the stage for further exploration into the responsible use of AI to enrich
educational experiences and improve exam preparation and assessment methods.

---------------

### 19 Oct 2023 | [The Foundation Model Transparency Index](https://arxiv.org/abs/2310.12941) | [⬇️](https://arxiv.org/pdf/2310.12941)
*Rishi Bommasani, Kevin Klyman, Shayne Longpre, Sayash Kapoor, Nestor  Maslej, Betty Xiong, Daniel Zhang, Percy Liang* 

  Foundation models have rapidly permeated society, catalyzing a wave of
generative AI applications spanning enterprise and consumer-facing contexts.
While the societal impact of foundation models is growing, transparency is on
the decline, mirroring the opacity that has plagued past digital technologies
(e.g. social media). Reversing this trend is essential: transparency is a vital
precondition for public accountability, scientific innovation, and effective
governance. To assess the transparency of the foundation model ecosystem and
help improve transparency over time, we introduce the Foundation Model
Transparency Index. The Foundation Model Transparency Index specifies 100
fine-grained indicators that comprehensively codify transparency for foundation
models, spanning the upstream resources used to build a foundation model (e.g
data, labor, compute), details about the model itself (e.g. size, capabilities,
risks), and the downstream use (e.g. distribution channels, usage policies,
affected geographies). We score 10 major foundation model developers (e.g.
OpenAI, Google, Meta) against the 100 indicators to assess their transparency.
To facilitate and standardize assessment, we score developers in relation to
their practices for their flagship foundation model (e.g. GPT-4 for OpenAI,
PaLM 2 for Google, Llama 2 for Meta). We present 10 top-level findings about
the foundation model ecosystem: for example, no developer currently discloses
significant information about the downstream impact of its flagship model, such
as the number of users, affected market sectors, or how users can seek redress
for harm. Overall, the Foundation Model Transparency Index establishes the
level of transparency today to drive progress on foundation model governance
via industry standards and regulatory intervention.

---------------

### 27 Nov 2023 | [Real Customization or Just Marketing: Are Customized Versions of Chat  GPT Useful?](https://arxiv.org/abs/2312.03728) | [⬇️](https://arxiv.org/pdf/2312.03728)
*Eduardo C. Garrido-Merch\'an, Jose L. Arroyo-Barrig\"uete, Francisco  Borr\'as-Pala, Leandro Escobar-Torres, Carlos Mart\'inez de Ibarreta, Jose  Mar\'ia Ortiz-Lozano, and Antonio Rua-Vieites* 

  Large Language Models (LLMs), as the case of OpenAI ChatGPT-4 Turbo, are
revolutionizing several industries, including higher education. In this
context, LLMs can be personalized through a fine-tuning process to meet the
student demands on every particular subject, like statistics. Recently, OpenAI
has launched the possibility to fine-tune their model with a natural language
web interface, enabling the possibility to create customized GPT version
deliberately conditioned to meet the demands of a specific task. The objective
of this research is to assess the potential of the customized GPTs that have
recently been launched by OpenAI. After developing a Business Statistics
Virtual Professor (BSVP), tailored for students at the Universidad Pontificia
Comillas, its behavior was evaluated and compared with that of ChatGPT-4 Turbo.
The results lead to several conclusions. Firstly, a substantial modification in
the style of communication was observed. Following the instructions it was
trained with, BSVP provided responses in a more relatable and friendly tone,
even incorporating a few minor jokes. Secondly, and this is a matter of
relevance, when explicitly asked for something like, "I would like to practice
a programming exercise similar to those in R practice 4," BSVP was capable of
providing a far superior response: having access to contextual documentation,
it could fulfill the request, something beyond ChatGPT-4 Turbo's capabilities.
On the downside, the response times were generally higher. Lastly, regarding
overall performance, quality, depth, and alignment with the specific content of
the course, no statistically significant differences were observed in the
responses between BSVP and ChatGPT-4 Turbo. It appears that customized
assistants trained with prompts present advantages as virtual aids for
students, yet they do not constitute a substantial improvement over ChatGPT-4
Turbo.

---------------

### 31 Mar 2023 | ["Genlangs" and Zipf's Law: Do languages generated by ChatGPT  statistically look human?](https://arxiv.org/abs/2304.12191) | [⬇️](https://arxiv.org/pdf/2304.12191)
*Justin Diamond* 

  OpenAI's GPT-4 is a Large Language Model (LLM) that can generate coherent
constructed languages, or "conlangs," which we propose be called "genlangs"
when generated by Artificial Intelligence (AI). The genlangs created by ChatGPT
for this research (Voxphera, Vivenzia, and Lumivoxa) each have unique features,
appear facially coherent, and plausibly "translate" into English. This study
investigates whether genlangs created by ChatGPT follow Zipf's law. Zipf's law
approximately holds across all natural and artificially constructed human
languages. According to Zipf's law, the word frequencies in a text corpus are
inversely proportional to their rank in the frequency table. This means that
the most frequent word appears about twice as often as the second most frequent
word, three times as often as the third most frequent word, and so on. We
hypothesize that Zipf's law will hold for genlangs because (1) genlangs created
by ChatGPT fundamentally operate in the same way as human language with respect
to the semantic usefulness of certain tokens, and (2) ChatGPT has been trained
on a corpora of text that includes many different languages, all of which
exhibit Zipf's law to varying degrees. Through statistical linguistics, we aim
to understand if LLM-based languages statistically look human. Our findings
indicate that genlangs adhere closely to Zipf's law, supporting the hypothesis
that genlangs created by ChatGPT exhibit similar statistical properties to
natural and artificial human languages. We also conclude that with human
assistance, AI is already capable of creating the world's first
fully-functional genlang, and we call for its development.

---------------

### 10 Aug 2023 | [GPT-4 Can't Reason](https://arxiv.org/abs/2308.03762) | [⬇️](https://arxiv.org/pdf/2308.03762)
*Konstantine Arkoudas* 

  GPT-4 was released in March 2023 to wide acclaim, marking a very substantial
improvement across the board over GPT-3.5 (OpenAI's previously best model,
which had powered the initial release of ChatGPT). However, despite the
genuinely impressive improvement, there are good reasons to be highly skeptical
of GPT-4's ability to reason. This position paper discusses the nature of
reasoning; criticizes the current formulation of reasoning problems in the NLP
community, as well as the way in which LLM reasoning performance is currently
evaluated; introduces a small collection of 21 diverse reasoning problems; and
performs a detailed qualitative evaluation of GPT-4's performance on those
problems. Based on this analysis, the paper concludes that, despite its
occasional flashes of analytical brilliance, GPT-4 at present is utterly
incapable of reasoning.

---------------

### 19 Feb 2024 | [Robust CLIP: Unsupervised Adversarial Fine-Tuning of Vision Embeddings  for Robust Large Vision-Language Models](https://arxiv.org/abs/2402.12336) | [⬇️](https://arxiv.org/pdf/2402.12336)
*Christian Schlarmann, Naman Deep Singh, Francesco Croce, Matthias Hein* 

  Multi-modal foundation models like OpenFlamingo, LLaVA, and GPT-4 are
increasingly used for various real-world tasks. Prior work has shown that these
models are highly vulnerable to adversarial attacks on the vision modality.
These attacks can be leveraged to spread fake information or defraud users, and
thus pose a significant risk, which makes the robustness of large multi-modal
foundation models a pressing problem. The CLIP model, or one of its variants,
is used as a frozen vision encoder in many vision-language models (VLMs), e.g.
LLaVA and OpenFlamingo. We propose an unsupervised adversarial fine-tuning
scheme to obtain a robust CLIP vision encoder, which yields robustness on all
vision down-stream tasks (VLMs, zero-shot classification) that rely on CLIP. In
particular, we show that stealth-attacks on users of VLMs by a malicious third
party providing manipulated images are no longer possible once one replaces the
original CLIP model with our robust one. No retraining or fine-tuning of the
VLM is required. The code and robust models are available at
https://github.com/chs20/RobustVLM

---------------

### 15 Aug 2023 | [Solving Challenging Math Word Problems Using GPT-4 Code Interpreter with  Code-based Self-Verification](https://arxiv.org/abs/2308.07921) | [⬇️](https://arxiv.org/pdf/2308.07921)
*Aojun Zhou, Ke Wang, Zimu Lu, Weikang Shi, Sichun Luo, Zipeng Qin,  Shaoqing Lu, Anya Jia, Linqi Song, Mingjie Zhan, Hongsheng Li* 

  Recent progress in large language models (LLMs) like GPT-4 and PaLM-2 has
brought significant advancements in addressing math reasoning problems. In
particular, OpenAI's latest version of GPT-4, known as GPT-4 Code Interpreter,
shows remarkable performance on challenging math datasets. In this paper, we
explore the effect of code on enhancing LLMs' reasoning capability by
introducing different constraints on the \textit{Code Usage Frequency} of GPT-4
Code Interpreter. We found that its success can be largely attributed to its
powerful skills in generating and executing code, evaluating the output of code
execution, and rectifying its solution when receiving unreasonable outputs.
Based on this insight, we propose a novel and effective prompting method,
explicit \uline{c}ode-based \uline{s}elf-\uline{v}erification~(CSV), to further
boost the mathematical reasoning potential of GPT-4 Code Interpreter. This
method employs a zero-shot prompt on GPT-4 Code Interpreter to encourage it to
use code to self-verify its answers. In instances where the verification state
registers as ``False'', the model shall automatically amend its solution,
analogous to our approach of rectifying errors during a mathematics
examination. Furthermore, we recognize that the states of the verification
result indicate the confidence of a solution, which can improve the
effectiveness of majority voting. With GPT-4 Code Interpreter and CSV, we
achieve an impressive zero-shot accuracy on MATH dataset \textbf{(53.9\% $\to$
84.3\%)}.

---------------

### 15 Jan 2024 | [A Trade-off Analysis of Replacing Proprietary LLMs with Open Source SLMs  in Production](https://arxiv.org/abs/2312.14972) | [⬇️](https://arxiv.org/pdf/2312.14972)
*Chandra Irugalbandara, Ashish Mahendra, Roland Daynauth, Tharuka  Kasthuri Arachchige, Krisztian Flautner, Lingjia Tang, Yiping Kang, Jason  Mars* 

  Many companies rely on APIs of managed AI models such as OpenAI's GPT-4 to
create AI-enabled experiences in their products. Along with the benefits of
ease of use and shortened time to production, this reliance on proprietary APIs
has downsides in terms of model control, performance reliability, up-time
predictability, and cost. At the same time, there has been a flurry of open
source small language models (SLMs) that have been made available for
commercial use. However, their readiness to replace existing capabilities
remains unclear, and a systematic approach to test these models is not readily
available. In this paper, we present a systematic evaluation methodology for,
and characterization of, modern open source SLMs and their trade-offs when
replacing a proprietary LLM APIs for a real-world product feature. We have
designed SLaM, an automated analysis tool that enables the quantitative and
qualitative testing of product features utilizing arbitrary SLMs. Using SLaM,
we examine both the quality and the performance characteristics of modern SLMs
relative to an existing customer-facing OpenAI-based implementation. We find
that across 9 SLMs and 29 variants, we observe competitive quality-of-results
for our use case, significant performance consistency improvement, and a cost
reduction of 5x-29x when compared to OpenAI GPT-4.

---------------

### 19 Feb 2024 | [Is Open-Source There Yet? A Comparative Study on Commercial and  Open-Source LLMs in Their Ability to Label Chest X-Ray Reports](https://arxiv.org/abs/2402.12298) | [⬇️](https://arxiv.org/pdf/2402.12298)
*Felix J. Dorfner, Liv J\"urgensen, Leonhard Donle, Fares Al Mohamad,  Tobias R. Bodenmann, Mason C. Cleveland, Felix Busch, Lisa C. Adams, James  Sato, Thomas Schultz, Albert E. Kim, Jameson Merkow, Keno K. Bressem,  Christopher P. Bridge* 

  Introduction: With the rapid advances in large language models (LLMs), there
have been numerous new open source as well as commercial models. While recent
publications have explored GPT-4 in its application to extracting information
of interest from radiology reports, there has not been a real-world comparison
of GPT-4 to different leading open-source models.
  Materials and Methods: Two different and independent datasets were used. The
first dataset consists of 540 chest x-ray reports that were created at the
Massachusetts General Hospital between July 2019 and July 2021. The second
dataset consists of 500 chest x-ray reports from the ImaGenome dataset. We then
compared the commercial models GPT-3.5 Turbo and GPT-4 from OpenAI to the
open-source models Mistral-7B, Mixtral-8x7B, Llama2-13B, Llama2-70B,
QWEN1.5-72B and CheXbert and CheXpert-labeler in their ability to accurately
label the presence of multiple findings in x-ray text reports using different
prompting techniques.
  Results: On the ImaGenome dataset, the best performing open-source model was
Llama2-70B with micro F1-scores of 0.972 and 0.970 for zero- and few-shot
prompts, respectively. GPT-4 achieved micro F1-scores of 0.975 and 0.984,
respectively. On the institutional dataset, the best performing open-source
model was QWEN1.5-72B with micro F1-scores of 0.952 and 0.965 for zero- and
few-shot prompting, respectively. GPT-4 achieved micro F1-scores of 0.975 and
0.973, respectively.
  Conclusion: In this paper, we show that while GPT-4 is superior to
open-source models in zero-shot report labeling, the implementation of few-shot
prompting can bring open-source models on par with GPT-4. This shows that
open-source models could be a performant and privacy preserving alternative to
GPT-4 for the task of radiology report classification.

---------------
**Date:** 12 Dec 2023

**Title:** Enhancing Medical Task Performance in GPT-4V: A Comprehensive Study on  Prompt Engineering Strategies

**Abstract Link:** [https://arxiv.org/abs/2312.04344](https://arxiv.org/abs/2312.04344)

**PDF Link:** [https://arxiv.org/pdf/2312.04344](https://arxiv.org/pdf/2312.04344)

---

**Date:** 22 Dec 2023

**Title:** Gemini vs GPT-4V: A Preliminary Comparison and Combination of  Vision-Language Models Through Qualitative Cases

**Abstract Link:** [https://arxiv.org/abs/2312.15011](https://arxiv.org/abs/2312.15011)

**PDF Link:** [https://arxiv.org/pdf/2312.15011](https://arxiv.org/pdf/2312.15011)

---

**Date:** 04 Dec 2023

**Title:** Can GPT-4V(ision) Serve Medical Applications? Case Studies on GPT-4V for  Multimodal Medical Diagnosis

**Abstract Link:** [https://arxiv.org/abs/2310.09909](https://arxiv.org/abs/2310.09909)

**PDF Link:** [https://arxiv.org/pdf/2310.09909](https://arxiv.org/pdf/2310.09909)

---

**Date:** 16 Nov 2023

**Title:** UnifiedVisionGPT: Streamlining Vision-Oriented AI through Generalized  Multimodal Framework

**Abstract Link:** [https://arxiv.org/abs/2311.10125](https://arxiv.org/abs/2311.10125)

**PDF Link:** [https://arxiv.org/pdf/2311.10125](https://arxiv.org/pdf/2311.10125)

---

**Date:** 16 Jan 2024

**Title:** Forging Vision Foundation Models for Autonomous Driving: Challenges,  Methodologies, and Opportunities

**Abstract Link:** [https://arxiv.org/abs/2401.08045](https://arxiv.org/abs/2401.08045)

**PDF Link:** [https://arxiv.org/pdf/2401.08045](https://arxiv.org/pdf/2401.08045)

---

**Date:** 11 Oct 2023

**Title:** The Dawn of LMMs: Preliminary Explorations with GPT-4V(ision)

**Abstract Link:** [https://arxiv.org/abs/2309.17421](https://arxiv.org/abs/2309.17421)

**PDF Link:** [https://arxiv.org/pdf/2309.17421](https://arxiv.org/pdf/2309.17421)

---

**Date:** 04 May 2023

**Title:** Gpt-4: A Review on Advancements and Opportunities in Natural Language  Processing

**Abstract Link:** [https://arxiv.org/abs/2305.03195](https://arxiv.org/abs/2305.03195)

**PDF Link:** [https://arxiv.org/pdf/2305.03195](https://arxiv.org/pdf/2305.03195)

---

**Date:** 16 Jan 2024

**Title:** AiGen-FoodReview: A Multimodal Dataset of Machine-Generated Restaurant  Reviews and Images on Social Media

**Abstract Link:** [https://arxiv.org/abs/2401.08825](https://arxiv.org/abs/2401.08825)

**PDF Link:** [https://arxiv.org/pdf/2401.08825](https://arxiv.org/pdf/2401.08825)

---

**Date:** 10 Aug 2023

**Title:** Adaptive Low Rank Adaptation of Segment Anything to Salient Object  Detection

**Abstract Link:** [https://arxiv.org/abs/2308.05426](https://arxiv.org/abs/2308.05426)

**PDF Link:** [https://arxiv.org/pdf/2308.05426](https://arxiv.org/pdf/2308.05426)

---

**Date:** 13 Apr 2023

**Title:** Sparks of Artificial General Intelligence: Early experiments with GPT-4

**Abstract Link:** [https://arxiv.org/abs/2303.12712](https://arxiv.org/abs/2303.12712)

**PDF Link:** [https://arxiv.org/pdf/2303.12712](https://arxiv.org/pdf/2303.12712)

---

**Date:** 12 Sep 2023

**Title:** Galactic ChitChat: Using Large Language Models to Converse with  Astronomy Literature

**Abstract Link:** [https://arxiv.org/abs/2304.05406](https://arxiv.org/abs/2304.05406)

**PDF Link:** [https://arxiv.org/pdf/2304.05406](https://arxiv.org/pdf/2304.05406)

---

**Date:** 02 Jan 2024

**Title:** Evaluating Large Language Models on the GMAT: Implications for the  Future of Business Education

**Abstract Link:** [https://arxiv.org/abs/2401.02985](https://arxiv.org/abs/2401.02985)

**PDF Link:** [https://arxiv.org/pdf/2401.02985](https://arxiv.org/pdf/2401.02985)

---

**Date:** 19 Oct 2023

**Title:** The Foundation Model Transparency Index

**Abstract Link:** [https://arxiv.org/abs/2310.12941](https://arxiv.org/abs/2310.12941)

**PDF Link:** [https://arxiv.org/pdf/2310.12941](https://arxiv.org/pdf/2310.12941)

---

**Date:** 27 Nov 2023

**Title:** Real Customization or Just Marketing: Are Customized Versions of Chat  GPT Useful?

**Abstract Link:** [https://arxiv.org/abs/2312.03728](https://arxiv.org/abs/2312.03728)

**PDF Link:** [https://arxiv.org/pdf/2312.03728](https://arxiv.org/pdf/2312.03728)

---

**Date:** 31 Mar 2023

**Title:** "Genlangs" and Zipf's Law: Do languages generated by ChatGPT  statistically look human?

**Abstract Link:** [https://arxiv.org/abs/2304.12191](https://arxiv.org/abs/2304.12191)

**PDF Link:** [https://arxiv.org/pdf/2304.12191](https://arxiv.org/pdf/2304.12191)

---

**Date:** 10 Aug 2023

**Title:** GPT-4 Can't Reason

**Abstract Link:** [https://arxiv.org/abs/2308.03762](https://arxiv.org/abs/2308.03762)

**PDF Link:** [https://arxiv.org/pdf/2308.03762](https://arxiv.org/pdf/2308.03762)

---

**Date:** 19 Feb 2024

**Title:** Robust CLIP: Unsupervised Adversarial Fine-Tuning of Vision Embeddings  for Robust Large Vision-Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.12336](https://arxiv.org/abs/2402.12336)

**PDF Link:** [https://arxiv.org/pdf/2402.12336](https://arxiv.org/pdf/2402.12336)

---

**Date:** 15 Aug 2023

**Title:** Solving Challenging Math Word Problems Using GPT-4 Code Interpreter with  Code-based Self-Verification

**Abstract Link:** [https://arxiv.org/abs/2308.07921](https://arxiv.org/abs/2308.07921)

**PDF Link:** [https://arxiv.org/pdf/2308.07921](https://arxiv.org/pdf/2308.07921)

---

**Date:** 15 Jan 2024

**Title:** A Trade-off Analysis of Replacing Proprietary LLMs with Open Source SLMs  in Production

**Abstract Link:** [https://arxiv.org/abs/2312.14972](https://arxiv.org/abs/2312.14972)

**PDF Link:** [https://arxiv.org/pdf/2312.14972](https://arxiv.org/pdf/2312.14972)

---

**Date:** 19 Feb 2024

**Title:** Is Open-Source There Yet? A Comparative Study on Commercial and  Open-Source LLMs in Their Ability to Label Chest X-Ray Reports

**Abstract Link:** [https://arxiv.org/abs/2402.12298](https://arxiv.org/abs/2402.12298)

**PDF Link:** [https://arxiv.org/pdf/2402.12298](https://arxiv.org/pdf/2402.12298)

---

