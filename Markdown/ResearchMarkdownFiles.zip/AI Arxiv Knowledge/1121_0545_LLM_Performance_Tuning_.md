LLM Performance Tuning 🎢

### 🔎 LLM Performance Tuning 🎢



# 🎢 Performance Tuning

Performance tuning is the process of optimizing the speed or efficiency of a system, often by making adjustments to the configuration or code of the system. In the context of web development, performance tuning often involves optimizing the speed and efficiency of a web application or website.

There are many different techniques and tools that can be used for performance tuning, and the specific approach will depend on the specific system and goals of the optimization. Some common techniques for performance tuning include:

1. Identifying and addressing bottlenecks: This involves identifying the parts of the system that are causing the most delay or using the most resources, and making changes to improve their performance.
2. Caching: Caching involves storing frequently accessed data or results in a cache, so that they can be quickly retrieved in the future without having to be recalculated or fetched from the original source.
3. Load balancing: Load balancing involves distributing incoming requests or workload across multiple servers or resources, in order to improve the overall performance and availability of the system.
4. Code optimization: This involves making changes to the code of the system in order to improve its speed or efficiency. This can include things like reducing the number of database queries, optimizing algorithms, or using more efficient data structures.
5. Using performance monitoring tools: There are many tools available that can help you monitor the performance of your system and identify areas for optimization. These tools can provide detailed information about things like response times, resource usage, and error rates.

Overall, performance tuning is an important aspect of web development, as it can help ensure that your application or website is fast, efficient, and able to handle high levels of traffic and usage.</s>
# 🩺🔍 Search Results
### 27 Dec 2023 | [Rethinking the Instruction Quality: LIFT is What You Need](https://arxiv.org/abs/2312.11508) | [⬇️](https://arxiv.org/pdf/2312.11508)
*Yang Xu, Yongqiang Yao, Yufan Huang, Mengnan Qi, Maoquan Wang, Bin Gu,  Neel Sundaresan* 

  Instruction tuning, a specialized technique to enhance large language model
(LLM) performance via instruction datasets, relies heavily on the quality of
employed data. Existing quality improvement methods alter instruction data
through dataset expansion or curation. However, the expansion method risks data
redundancy, potentially compromising LLM performance, while the curation
approach confines the LLM's potential to the original dataset. Our aim is to
surpass the original data quality without encountering these shortcomings. To
achieve this, we propose LIFT (LLM Instruction Fusion Transfer), a novel and
versatile paradigm designed to elevate the instruction quality to new heights.
LIFT strategically broadens data distribution to encompass more high-quality
subspaces and eliminates redundancy, concentrating on high-quality segments
across overall data subspaces. Experimental results demonstrate that, even with
a limited quantity of high-quality instruction data selected by our paradigm,
LLMs not only consistently uphold robust performance across various tasks but
also surpass some state-of-the-art results, highlighting the significant
improvement in instruction quality achieved by our paradigm.

---------------

### 01 Dec 2023 | [Instruction-tuning Aligns LLMs to the Human Brain](https://arxiv.org/abs/2312.00575) | [⬇️](https://arxiv.org/pdf/2312.00575)
*Khai Loong Aw, Syrielle Montariol, Badr AlKhamissi, Martin Schrimpf,  Antoine Bosselut* 

  Instruction-tuning is a widely adopted method of finetuning that enables
large language models (LLMs) to generate output that more closely resembles
human responses to natural language queries, in many cases leading to
human-level performance on diverse testbeds. However, it remains unclear
whether instruction-tuning truly makes LLMs more similar to how humans process
language. We investigate the effect of instruction-tuning on LLM-human
similarity in two ways: (1) brain alignment, the similarity of LLM internal
representations to neural activity in the human language system, and (2)
behavioral alignment, the similarity of LLM and human behavior on a reading
task. We assess 25 vanilla and instruction-tuned LLMs across three datasets
involving humans reading naturalistic stories and sentences. We discover that
instruction-tuning generally enhances brain alignment by an average of 6%, but
does not have a similar effect on behavioral alignment. To identify the factors
underlying LLM-brain alignment, we compute correlations between the brain
alignment of LLMs and various model properties, such as model size, various
problem-solving abilities, and performance on tasks requiring world knowledge
spanning various domains. Notably, we find a strong positive correlation
between brain alignment and model size (r = 0.95), as well as performance on
tasks requiring world knowledge (r = 0.81). Our results demonstrate that
instruction-tuning LLMs improves both world knowledge representations and brain
alignment, suggesting that mechanisms that encode world knowledge in LLMs also
improve representational alignment to the human brain.

---------------

### 15 Feb 2024 | [Selective Reflection-Tuning: Student-Selected Data Recycling for LLM  Instruction-Tuning](https://arxiv.org/abs/2402.10110) | [⬇️](https://arxiv.org/pdf/2402.10110)
*Ming Li, Lichang Chen, Jiuhai Chen, Shwai He, Jiuxiang Gu, Tianyi Zhou* 

  Instruction tuning is critical to large language models (LLMs) for achieving
better instruction following and task adaptation capabilities but its success
heavily relies on the training data quality. Many recent methods focus on
improving the data quality but often overlook the compatibility of the data
with the student model being finetuned. This paper introduces Selective
Reflection-Tuning, a novel paradigm that synergizes a teacher LLM's reflection
and introspection for improving existing data quality with the data selection
capability of the student LLM, to automatically refine existing
instruction-tuning data. This teacher-student collaboration produces
high-quality and student-compatible instruction-response pairs, resulting in
sample-efficient instruction tuning and LLMs of superior performance. Selective
Reflection-Tuning is a data augmentation and synthesis that generally improves
LLM finetuning and self-improvement without collecting brand-new data. We apply
our method to Alpaca and WizardLM data and achieve much stronger and top-tier
7B and 13B LLMs. Our codes, models, and data will be released at
https://github.com/tianyi-lab/Reflection_Tuning.

---------------

### 16 May 2023 | [Maybe Only 0.5% Data is Needed: A Preliminary Exploration of Low  Training Data Instruction Tuning](https://arxiv.org/abs/2305.09246) | [⬇️](https://arxiv.org/pdf/2305.09246)
*Hao Chen, Yiming Zhang, Qi Zhang, Hantao Yang, Xiaomeng Hu, Xuetao Ma,  Yifan Yanggong, Junbo Zhao* 

  Instruction tuning for large language models (LLMs) has gained attention from
researchers due to its ability to unlock the potential of LLMs in following
instructions. While instruction tuning offers advantages for facilitating the
adaptation of large language models (LLMs) to downstream tasks as a fine-tuning
approach, training models with tens of millions or even billions of parameters
on large amounts of data results in unaffordable computational costs. To
address this, we focus on reducing the data used in LLM instruction tuning to
decrease training costs and improve data efficiency, dubbed as Low Training
Data Instruction Tuning (LTD Instruction Tuning). Specifically, this paper
conducts a preliminary exploration into reducing the data used in LLM training
and identifies several observations regarding task specialization for LLM
training, such as the optimization of performance for a specific task, the
number of instruction types required for instruction tuning, and the amount of
data required for task-specific models. The results suggest that task-specific
models can be trained using less than 0.5% of the original dataset, with a 2%
improvement in performance over those trained on full task-related data.

---------------

### 25 Nov 2023 | [Vision-Language Instruction Tuning: A Review and Analysis](https://arxiv.org/abs/2311.08172) | [⬇️](https://arxiv.org/pdf/2311.08172)
*Chen Li, Yixiao Ge, Dian Li, and Ying Shan* 

  Instruction tuning is a crucial supervised training phase in Large Language
Models (LLMs), aiming to enhance the LLM's ability to generalize instruction
execution and adapt to user preferences. With the increasing integration of
multi-modal data into LLMs, there is growing interest in Vision-Language
Instruction Tuning (VLIT), which presents more complex characteristics compared
to pure text instruction tuning. In this paper, we systematically review the
latest VLIT settings and corresponding datasets in multi-modal LLMs and provide
insights into the intrinsic motivations behind their design. For the first
time, we offer a detailed multi-perspective categorization for existing VLIT
datasets and identify the characteristics that high-quality VLIT data should
possess. By incorporating these characteristics as guiding principles into the
existing VLIT data construction process, we conduct extensive experiments and
verify their positive impact on the performance of tuned multi-modal LLMs.
Furthermore, we discuss the current challenges and future research directions
of VLIT, providing insights for the continuous development of this field. The
code and dataset related to this paper have been open-sourced at
https://github.com/palchenli/VL-Instruction-Tuning.

---------------

### 22 Nov 2023 | [Automatic Instruction Optimization for Open-source LLM Instruction  Tuning](https://arxiv.org/abs/2311.13246) | [⬇️](https://arxiv.org/pdf/2311.13246)
*Yilun Liu, Shimin Tao, Xiaofeng Zhao, Ming Zhu, Wenbing Ma, Junhao  Zhu, Chang Su, Yutai Hou, Miao Zhang, Min Zhang, Hongxia Ma, Li Zhang, Hao  Yang, Yanfei Jiang* 

  Instruction tuning is crucial for enabling Language Learning Models (LLMs) in
responding to human instructions. The quality of instruction pairs used for
tuning greatly affects the performance of LLMs. However, the manual creation of
high-quality instruction datasets is costly, leading to the adoption of
automatic generation of instruction pairs by LLMs as a popular alternative in
the training of open-source LLMs. To ensure the high quality of LLM-generated
instruction datasets, several approaches have been proposed. Nevertheless,
existing methods either compromise dataset integrity by filtering a large
proportion of samples, or are unsuitable for industrial applications. In this
paper, instead of discarding low-quality samples, we propose CoachLM, a novel
approach to enhance the quality of instruction datasets through automatic
revisions on samples in the dataset. CoachLM is trained from the samples
revised by human experts and significantly increases the proportion of
high-quality samples in the dataset from 17.7% to 78.9%. The effectiveness of
CoachLM is further assessed on various real-world instruction test sets. The
results show that CoachLM improves the instruction-following capabilities of
the instruction-tuned LLM by an average of 29.9%, which even surpasses larger
LLMs with nearly twice the number of parameters. Furthermore, CoachLM is
successfully deployed in a data management system for LLMs at Huawei, resulting
in an efficiency improvement of up to 20% in the cleaning of 40k real-world
instruction pairs. We release the training data and code of CoachLM
(https://github.com/lunyiliu/CoachLM).

---------------

### 17 Feb 2024 | [Contrastive Instruction Tuning](https://arxiv.org/abs/2402.11138) | [⬇️](https://arxiv.org/pdf/2402.11138)
*Tianyi Yan, Fei Wang, James Y. Huang, Wenxuan Zhou, Fan Yin, Aram  Galstyan, Wenpeng Yin, Muhao Chen* 

  Instruction tuning has been used as a promising approach to improve the
performance of large language models (LLMs) on unseen tasks. However, current
LLMs exhibit limited robustness to unseen instructions, generating inconsistent
outputs when the same instruction is phrased with slightly varied forms or
language styles. This behavior indicates LLMs' lack of robustness to textual
variations and generalizability to unseen instructions, potentially leading to
trustworthiness issues. Accordingly, we propose Contrastive Instruction Tuning,
which maximizes the similarity between the hidden representations of
semantically equivalent instruction-instance pairs while minimizing the
similarity between semantically different ones. To facilitate this approach, we
augment the existing FLAN collection by paraphrasing task instructions.
Experiments on the PromptBench benchmark show that CoIN consistently improves
LLMs' robustness to unseen instructions with variations across character, word,
sentence, and semantic levels by an average of +2.5% in accuracy.

---------------

### 11 Feb 2024 | [Federated Learning of Large Language Models with Parameter-Efficient  Prompt Tuning and Adaptive Optimization](https://arxiv.org/abs/2310.15080) | [⬇️](https://arxiv.org/pdf/2310.15080)
*Tianshi Che, Ji Liu, Yang Zhou, Jiaxiang Ren, Jiwen Zhou, Victor S.  Sheng, Huaiyu Dai, Dejing Dou* 

  Federated learning (FL) is a promising paradigm to enable collaborative model
training with decentralized data. However, the training process of Large
Language Models (LLMs) generally incurs the update of significant parameters,
which limits the applicability of FL techniques to tackle the LLMs in real
scenarios. Prompt tuning can significantly reduce the number of parameters to
update, but it either incurs performance degradation or low training
efficiency. The straightforward utilization of prompt tuning in the FL often
raises non-trivial communication costs and dramatically degrades performance.
In addition, the decentralized data is generally non-Independent and
Identically Distributed (non-IID), which brings client drift problems and thus
poor performance. This paper proposes a Parameter-efficient prompt Tuning
approach with Adaptive Optimization, i.e., FedPepTAO, to enable efficient and
effective FL of LLMs. First, an efficient partial prompt tuning approach is
proposed to improve performance and efficiency simultaneously. Second, a novel
adaptive optimization method is developed to address the client drift problems
on both the device and server sides to enhance performance further. Extensive
experiments based on 10 datasets demonstrate the superb performance (up to
60.8\% in terms of accuracy) and efficiency (up to 97.59\% in terms of training
time) of FedPepTAO compared with 9 baseline approaches. Our code is available
at https://github.com/llm-eff/FedPepTAO.

---------------

### 04 Oct 2023 | [Two-stage LLM Fine-tuning with Less Specialization and More  Generalization](https://arxiv.org/abs/2211.00635) | [⬇️](https://arxiv.org/pdf/2211.00635)
*Yihan Wang, Si Si, Daliang Li, Michal Lukasik, Felix Yu, Cho-Jui  Hsieh, Inderjit S Dhillon, Sanjiv Kumar* 

  Pretrained large language models (LLMs) are general purpose problem solvers
applicable to a diverse set of tasks with prompts. They can be further improved
towards a specific task by fine-tuning on a specialized dataset. However,
fine-tuning usually makes the model narrowly specialized on this dataset with
reduced general in-context learning performances, which is undesirable whenever
the fine-tuned model needs to handle additional tasks where no fine-tuning data
is available. In this work, we first demonstrate that fine-tuning on a single
task indeed decreases LLMs' general in-context learning performance. We
discover one important cause of such forgetting, format specialization, where
the model overfits to the format of the fine-tuned task. We further show that
format specialization happens at the very beginning of fine-tuning. To solve
this problem, we propose Prompt Tuning with MOdel Tuning (ProMoT), a simple yet
effective two-stage fine-tuning framework that reduces format specialization
and improves generalization. ProMoT offloads task-specific format learning into
additional and removable parameters by first doing prompt tuning and then
fine-tuning the model itself with this soft prompt attached. With experiments
on several fine-tuning tasks and 8 in-context evaluation tasks, we show that
ProMoT achieves comparable performance on fine-tuned tasks to standard
fine-tuning, but with much less loss of in-context learning performances across
a board range of out-of-domain evaluation tasks. More importantly, ProMoT can
even enhance generalization on in-context learning tasks that are semantically
related to the fine-tuned task, e.g. ProMoT on En-Fr translation significantly
improves performance on other language pairs, and ProMoT on NLI improves
performance on summarization. Experiments also show that ProMoT can improve the
generalization performance of multi-task training.

---------------

### 18 Feb 2024 | [Demystifying Instruction Mixing for Fine-tuning Large Language Models](https://arxiv.org/abs/2312.10793) | [⬇️](https://arxiv.org/pdf/2312.10793)
*Renxi Wang, Haonan Li, Minghao Wu, Yuxia Wang, Xudong Han, Chiyu  Zhang, Timothy Baldwin* 

  Instruction tuning significantly enhances the performance of large language
models (LLMs) across various tasks. However, the procedure to optimizing the
mixing of instruction datasets for LLM fine-tuning is still poorly understood.
This study categorizes instructions into three primary types: NLP downstream
tasks, coding, and general chat. We explore the effects of instruction tuning
on different combinations of datasets on LLM performance, and find that certain
instruction types are more advantageous for specific applications but can
negatively impact other areas. This work provides insights into instruction
mixtures, laying the foundations for future research.

---------------

### 31 Dec 2023 | [LaFFi: Leveraging Hybrid Natural Language Feedback for Fine-tuning  Language Models](https://arxiv.org/abs/2401.00907) | [⬇️](https://arxiv.org/pdf/2401.00907)
*Qianxi Li, Yingyue Cao, Jikun Kang, Tianpei Yang, Xi Chen, Jun Jin and  Matthew E. Taylor* 

  Fine-tuning Large Language Models (LLMs) adapts a trained model to specific
downstream tasks, significantly improving task-specific performance. Supervised
Fine-Tuning (SFT) is a common approach, where an LLM is trained to produce
desired answers. However, LLMs trained with SFT sometimes make simple mistakes
and result in hallucinations on reasoning tasks such as question-answering.
Without external feedback, it is difficult for SFT to learn a good mapping
between the question and the desired answer, especially with a small dataset.
This paper introduces an alternative to SFT called Natural Language Feedback
for Finetuning LLMs (LaFFi). LaFFi has LLMs directly predict the feedback they
will receive from an annotator. We find that requiring such reflection can
significantly improve the accuracy in in-domain question-answering tasks,
providing a promising direction for the application of natural language
feedback in the realm of SFT LLMs. Additional ablation studies show that the
portion of human-annotated data in the annotated datasets affects the
fine-tuning performance.

---------------

### 21 Jun 2023 | [BayLing: Bridging Cross-lingual Alignment and Instruction Following  through Interactive Translation for Large Language Models](https://arxiv.org/abs/2306.10968) | [⬇️](https://arxiv.org/pdf/2306.10968)
*Shaolei Zhang, Qingkai Fang, Zhuocheng Zhang, Zhengrui Ma, Yan Zhou,  Langlin Huang, Mengyu Bu, Shangtong Gui, Yunji Chen, Xilin Chen, Yang Feng* 

  Large language models (LLMs) have demonstrated remarkable prowess in language
understanding and generation. Advancing from foundation LLMs to
instructionfollowing LLMs, instruction tuning plays a vital role in aligning
LLMs to human preferences. However, the existing LLMs are usually focused on
English, leading to inferior performance in non-English languages. In order to
improve the performance for non-English languages, it is necessary to collect
language-specific training data for foundation LLMs and construct
language-specific instructions for instruction tuning, both of which are heavy
loads. To minimize human workload, we propose to transfer the capabilities of
language generation and instruction following from English to other languages
through an interactive translation task. We have developed BayLing, an
instruction-following LLM by utilizing LLaMA as the foundation LLM and
automatically constructing interactive translation instructions for instructing
tuning. Extensive assessments demonstrate that BayLing achieves comparable
performance to GPT-3.5-turbo, despite utilizing a considerably smaller
parameter size of only 13 billion. Experimental results on translation tasks
show that BayLing achieves 95% of single-turn translation capability compared
to GPT-4 with automatic evaluation and 96% of interactive translation
capability compared to GPT-3.5-turbo with human evaluation. To estimate the
performance on general tasks, we created a multi-turn instruction test set
called BayLing-80. The experimental results on BayLing-80 indicate that BayLing
achieves 89% of performance compared to GPT-3.5-turbo. BayLing also
demonstrates outstanding performance on knowledge assessment of Chinese GaoKao
and English SAT, second only to GPT-3.5-turbo among a multitude of
instruction-following LLMs. Demo, homepage, code and models of BayLing are
available.

---------------

### 18 May 2023 | [Aligning Instruction Tasks Unlocks Large Language Models as Zero-Shot  Relation Extractors](https://arxiv.org/abs/2305.11159) | [⬇️](https://arxiv.org/pdf/2305.11159)
*Kai Zhang, Bernal Jim\'enez Guti\'errez, Yu Su* 

  Recent work has shown that fine-tuning large language models (LLMs) on
large-scale instruction-following datasets substantially improves their
performance on a wide range of NLP tasks, especially in the zero-shot setting.
However, even advanced instruction-tuned LLMs still fail to outperform small
LMs on relation extraction (RE), a fundamental information extraction task. We
hypothesize that instruction-tuning has been unable to elicit strong RE
capabilities in LLMs due to RE's low incidence in instruction-tuning datasets,
making up less than 1% of all tasks (Wang et al., 2022). To address this
limitation, we propose QA4RE, a framework that aligns RE with question
answering (QA), a predominant task in instruction-tuning datasets.
Comprehensive zero-shot RE experiments over four datasets with two series of
instruction-tuned LLMs (six LLMs in total) demonstrate that our QA4RE framework
consistently improves LLM performance, strongly verifying our hypothesis and
enabling LLMs to outperform strong zero-shot baselines by a large margin.
Additionally, we provide thorough experiments and discussions to show the
robustness, few-shot effectiveness, and strong transferability of our QA4RE
framework. This work illustrates a promising way of adapting LLMs to
challenging and underrepresented tasks by aligning these tasks with more common
instruction-tuning tasks like QA.

---------------

### 19 Dec 2023 | [Taiyi: A Bilingual Fine-Tuned Large Language Model for Diverse  Biomedical Tasks](https://arxiv.org/abs/2311.11608) | [⬇️](https://arxiv.org/pdf/2311.11608)
*Ling Luo, Jinzhong Ning, Yingwen Zhao, Zhijun Wang, Zeyuan Ding, Peng  Chen, Weiru Fu, Qinyu Han, Guangtao Xu, Yunzhi Qiu, Dinghao Pan, Jiru Li, Hao  Li, Wenduo Feng, Senbo Tu, Yuqi Liu, Zhihao Yang, Jian Wang, Yuanyuan Sun,  Hongfei Lin* 

  Objective: Most existing fine-tuned biomedical large language models (LLMs)
focus on enhancing performance in monolingual biomedical question answering and
conversation tasks. To investigate the effectiveness of the fine-tuned LLMs on
diverse biomedical NLP tasks in different languages, We present Taiyi, a
bilingual fine-tuned LLM for diverse biomedical tasks. Materials and Methods:
We first curated a comprehensive collection of 140 existing biomedical text
mining datasets (102 English and 38 Chinese datasets) across over 10 task
types. Subsequently, a two-stage strategy is proposed for supervised
fine-tuning to optimize the model performance across varied tasks. Results:
Experimental results on 13 test sets covering named entity recognition,
relation extraction, text classification, question answering tasks demonstrate
that Taiyi achieves superior performance compared to general LLMs. The case
study involving additional biomedical NLP tasks further shows Taiyi's
considerable potential for bilingual biomedical multi-tasking. Conclusion:
Leveraging rich high-quality biomedical corpora and developing effective
fine-tuning strategies can significantly improve the performance of LLMs within
the biomedical domain. Taiyi shows the bilingual multi-tasking capability
through supervised fine-tuning. However, those tasks such as information
extraction that are not generation tasks in nature remain challenging for
LLM-based generative approaches, and they still underperform the conventional
discriminative approaches of smaller language models.

---------------

### 19 Feb 2024 | [JsonTuning: Towards Generalizable, Robust, and Controllable Instruction  Tuning](https://arxiv.org/abs/2310.02953) | [⬇️](https://arxiv.org/pdf/2310.02953)
*Chang Gao, Wenxuan Zhang, Guizhen Chen, Wai Lam* 

  Instruction tuning has emerged as a crucial process for harnessing the
capabilities of large language models (LLMs) by providing explicit task
instructions, leading to improved performance in various tasks. However,
prevalent text-to-text instruction tuning (TextTuning) methods suffer from
limitations in generalization, robustness, and controllability due to the
ambiguity and lack of explicit structure in tasks. In this paper, we propose
JsonTuning, a novel structure-to-structure approach for instruction tuning. By
leveraging the versatility and structured nature of JSON to represent tasks,
JsonTuning enhances generalization by helping the model understand essential
task elements and their relations, improves robustness by minimizing ambiguity,
and increases controllability by providing explicit control over the output. We
conduct a comprehensive comparative study with diverse language models and
evaluation benchmarks. Experimental results show that JsonTuning outperforms
TextTuning in various applications, showcasing improved performance,
adaptability, robustness, and controllability. By overcoming the limitations of
TextTuning, JsonTuning demonstrates significant potential for more effective
and reliable LLMs capable of handling diverse scenarios.

---------------

### 14 Feb 2024 | [DolphCoder: Echo-Locating Code Large Language Models with Diverse and  Multi-Objective Instruction Tuning](https://arxiv.org/abs/2402.09136) | [⬇️](https://arxiv.org/pdf/2402.09136)
*Yejie Wang, Keqing He, Guanting Dong, Pei Wang, Weihao Zeng, Muxi  Diao, Yutao Mou, Mengdi Zhang, Jingang Wang, Xunliang Cai, Weiran Xu* 

  Code Large Language Models (Code LLMs) have demonstrated outstanding
performance in code-related tasks. Several instruction tuning approaches have
been proposed to boost the code generation performance of pre-trained Code
LLMs. In this paper, we introduce a diverse instruction model (DolphCoder) with
self-evaluating for code generation. It learns diverse instruction targets and
combines a code evaluation objective to enhance its code generation ability.
Our model achieves superior performance on the HumanEval and MBPP benchmarks,
demonstrating new insights for future code instruction tuning work. Our key
findings are: (1) Augmenting more diverse responses with distinct reasoning
paths increases the code capability of LLMs. (2) Improving one's ability to
evaluate the correctness of code solutions also enhances their ability to
create it.

---------------

### 06 Jun 2023 | [On the Role of Attention in Prompt-tuning](https://arxiv.org/abs/2306.03435) | [⬇️](https://arxiv.org/pdf/2306.03435)
*Samet Oymak, Ankit Singh Rawat, Mahdi Soltanolkotabi, Christos  Thrampoulidis* 

  Prompt-tuning is an emerging strategy to adapt large language models (LLM) to
downstream tasks by learning a (soft-)prompt parameter from data. Despite its
success in LLMs, there is limited theoretical understanding of the power of
prompt-tuning and the role of the attention mechanism in prompting. In this
work, we explore prompt-tuning for one-layer attention architectures and study
contextual mixture-models where each input token belongs to a context-relevant
or -irrelevant set. We isolate the role of prompt-tuning through a
self-contained prompt-attention model. Our contributions are as follows: (1) We
show that softmax-prompt-attention is provably more expressive than
softmax-self-attention and linear-prompt-attention under our contextual data
model. (2) We analyze the initial trajectory of gradient descent and show that
it learns the prompt and prediction head with near-optimal sample complexity
and demonstrate how prompt can provably attend to sparse context-relevant
tokens. (3) Assuming a known prompt but an unknown prediction head, we
characterize the exact finite sample performance of prompt-attention which
reveals the fundamental performance limits and the precise benefit of the
context information. We also provide experiments that verify our theoretical
insights on real datasets and demonstrate how prompt-tuning enables the model
to attend to context-relevant information.

---------------

### 30 Jan 2024 | [Hyperparameter Optimization for Large Language Model Instruction-Tuning](https://arxiv.org/abs/2312.00949) | [⬇️](https://arxiv.org/pdf/2312.00949)
*Christophe Tribes, Sacha Benarroch-Lelong, Peng Lu, Ivan Kobyzev* 

  The fine-tuning of Large Language Models (LLMs) has enabled them to recently
achieve milestones in natural language processing applications. The emergence
of ever larger LLMs has paved the way for more efficient fine-tuning methods.
Among these, the Low-Rank Adaptation (LoRA) method keeps most of the weights of
the pre-trained LLM frozen while introducing a low-rank decomposition of the
weight matrix, enabling the tuning of only a very small proportion of the
network. The performance on downstream tasks of models fine-tuned with LoRA
heavily relies on a set of hyperparameters including the rank of the
decomposition. In this work, we investigate the choice of these hyperparameters
through two main blackbox optimization (BBO) techniques. We examine the whole
pipeline of performing fine-tuning and validation on a pre-trained LLM as a
blackbox and efficiently explore the space of hyperparameters with the \nomad
algorithm, achieving a boost in performance and human alignment of the tuned
model.

---------------

### 28 Feb 2024 | [A Closer Look at the Limitations of Instruction Tuning](https://arxiv.org/abs/2402.05119) | [⬇️](https://arxiv.org/pdf/2402.05119)
*Sreyan Ghosh and Chandra Kiran Reddy Evuru and Sonal Kumar and  Ramaneswaran S and Deepali Aneja and Zeyu Jin and Ramani Duraiswami and  Dinesh Manocha* 

  Instruction Tuning (IT), the process of training large language models (LLMs)
using instruction-response pairs, has emerged as the predominant method for
transforming base pre-trained LLMs into open-domain conversational agents.
While IT has achieved notable success and widespread adoption, its limitations
and shortcomings remain underexplored. In this paper, through rigorous
experiments and an in-depth analysis of the changes LLMs undergo through IT, we
reveal various limitations of IT. In particular, we show that (1) IT fails to
enhance knowledge or skills in LLMs. LoRA fine-tuning is limited to learning
response initiation and style tokens, and full-parameter fine-tuning leads to
knowledge degradation. (2) Copying response patterns from IT datasets derived
from knowledgeable sources leads to a decline in response quality. (3)
Full-parameter fine-tuning increases hallucination by inaccurately borrowing
tokens from conceptually similar instances in the IT dataset for generating
responses. (4) Popular methods to improve IT do not lead to performance
improvements over a simple LoRA fine-tuned model. Our findings reveal that
responses generated solely from pre-trained knowledge consistently outperform
responses by models that learn any form of new knowledge from IT on open-source
datasets. We hope the insights and challenges revealed inspire future work.

---------------

### 31 Jan 2024 | [Federated Full-Parameter Tuning of Billion-Sized Language Models with  Communication Cost under 18 Kilobytes](https://arxiv.org/abs/2312.06353) | [⬇️](https://arxiv.org/pdf/2312.06353)
*Zhen Qin, Daoyuan Chen, Bingchen Qian, Bolin Ding, Yaliang Li,  Shuiguang Deng* 

  Pre-trained large language models (LLMs) need fine-tuning to improve their
responsiveness to natural language instructions. Federated learning offers a
way to fine-tune LLMs using the abundant data on end devices without
compromising data privacy. Most existing federated fine-tuning methods for LLMs
rely on parameter-efficient fine-tuning techniques, which may not reach the
performance height possible with full-parameter tuning. However, federated
full-parameter tuning of LLMs is a non-trivial problem due to the immense
communication cost. This work introduces FedKSeed that employs zeroth-order
optimization with a finite set of random seeds. It significantly reduces
transmission requirements between the server and clients to just a few random
seeds and scalar gradients, amounting to only a few thousand bytes, making
federated full-parameter tuning of billion-sized LLMs possible on devices.
Building on it, we develop a strategy enabling probability-differentiated seed
sampling, prioritizing perturbations with greater impact on model accuracy.
Experiments across six scenarios with various LLMs, datasets and data
partitions demonstrate that our approach outperforms existing federated LLM
fine-tuning methods in both communication efficiency and new task
generalization.

---------------
**Date:** 27 Dec 2023

**Title:** Rethinking the Instruction Quality: LIFT is What You Need

**Abstract Link:** [https://arxiv.org/abs/2312.11508](https://arxiv.org/abs/2312.11508)

**PDF Link:** [https://arxiv.org/pdf/2312.11508](https://arxiv.org/pdf/2312.11508)

---

**Date:** 01 Dec 2023

**Title:** Instruction-tuning Aligns LLMs to the Human Brain

**Abstract Link:** [https://arxiv.org/abs/2312.00575](https://arxiv.org/abs/2312.00575)

**PDF Link:** [https://arxiv.org/pdf/2312.00575](https://arxiv.org/pdf/2312.00575)

---

**Date:** 15 Feb 2024

**Title:** Selective Reflection-Tuning: Student-Selected Data Recycling for LLM  Instruction-Tuning

**Abstract Link:** [https://arxiv.org/abs/2402.10110](https://arxiv.org/abs/2402.10110)

**PDF Link:** [https://arxiv.org/pdf/2402.10110](https://arxiv.org/pdf/2402.10110)

---

**Date:** 16 May 2023

**Title:** Maybe Only 0.5% Data is Needed: A Preliminary Exploration of Low  Training Data Instruction Tuning

**Abstract Link:** [https://arxiv.org/abs/2305.09246](https://arxiv.org/abs/2305.09246)

**PDF Link:** [https://arxiv.org/pdf/2305.09246](https://arxiv.org/pdf/2305.09246)

---

**Date:** 25 Nov 2023

**Title:** Vision-Language Instruction Tuning: A Review and Analysis

**Abstract Link:** [https://arxiv.org/abs/2311.08172](https://arxiv.org/abs/2311.08172)

**PDF Link:** [https://arxiv.org/pdf/2311.08172](https://arxiv.org/pdf/2311.08172)

---

**Date:** 22 Nov 2023

**Title:** Automatic Instruction Optimization for Open-source LLM Instruction  Tuning

**Abstract Link:** [https://arxiv.org/abs/2311.13246](https://arxiv.org/abs/2311.13246)

**PDF Link:** [https://arxiv.org/pdf/2311.13246](https://arxiv.org/pdf/2311.13246)

---

**Date:** 17 Feb 2024

**Title:** Contrastive Instruction Tuning

**Abstract Link:** [https://arxiv.org/abs/2402.11138](https://arxiv.org/abs/2402.11138)

**PDF Link:** [https://arxiv.org/pdf/2402.11138](https://arxiv.org/pdf/2402.11138)

---

**Date:** 11 Feb 2024

**Title:** Federated Learning of Large Language Models with Parameter-Efficient  Prompt Tuning and Adaptive Optimization

**Abstract Link:** [https://arxiv.org/abs/2310.15080](https://arxiv.org/abs/2310.15080)

**PDF Link:** [https://arxiv.org/pdf/2310.15080](https://arxiv.org/pdf/2310.15080)

---

**Date:** 04 Oct 2023

**Title:** Two-stage LLM Fine-tuning with Less Specialization and More  Generalization

**Abstract Link:** [https://arxiv.org/abs/2211.00635](https://arxiv.org/abs/2211.00635)

**PDF Link:** [https://arxiv.org/pdf/2211.00635](https://arxiv.org/pdf/2211.00635)

---

**Date:** 18 Feb 2024

**Title:** Demystifying Instruction Mixing for Fine-tuning Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2312.10793](https://arxiv.org/abs/2312.10793)

**PDF Link:** [https://arxiv.org/pdf/2312.10793](https://arxiv.org/pdf/2312.10793)

---

**Date:** 31 Dec 2023

**Title:** LaFFi: Leveraging Hybrid Natural Language Feedback for Fine-tuning  Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.00907](https://arxiv.org/abs/2401.00907)

**PDF Link:** [https://arxiv.org/pdf/2401.00907](https://arxiv.org/pdf/2401.00907)

---

**Date:** 21 Jun 2023

**Title:** BayLing: Bridging Cross-lingual Alignment and Instruction Following  through Interactive Translation for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2306.10968](https://arxiv.org/abs/2306.10968)

**PDF Link:** [https://arxiv.org/pdf/2306.10968](https://arxiv.org/pdf/2306.10968)

---

**Date:** 18 May 2023

**Title:** Aligning Instruction Tasks Unlocks Large Language Models as Zero-Shot  Relation Extractors

**Abstract Link:** [https://arxiv.org/abs/2305.11159](https://arxiv.org/abs/2305.11159)

**PDF Link:** [https://arxiv.org/pdf/2305.11159](https://arxiv.org/pdf/2305.11159)

---

**Date:** 19 Dec 2023

**Title:** Taiyi: A Bilingual Fine-Tuned Large Language Model for Diverse  Biomedical Tasks

**Abstract Link:** [https://arxiv.org/abs/2311.11608](https://arxiv.org/abs/2311.11608)

**PDF Link:** [https://arxiv.org/pdf/2311.11608](https://arxiv.org/pdf/2311.11608)

---

**Date:** 19 Feb 2024

**Title:** JsonTuning: Towards Generalizable, Robust, and Controllable Instruction  Tuning

**Abstract Link:** [https://arxiv.org/abs/2310.02953](https://arxiv.org/abs/2310.02953)

**PDF Link:** [https://arxiv.org/pdf/2310.02953](https://arxiv.org/pdf/2310.02953)

---

**Date:** 14 Feb 2024

**Title:** DolphCoder: Echo-Locating Code Large Language Models with Diverse and  Multi-Objective Instruction Tuning

**Abstract Link:** [https://arxiv.org/abs/2402.09136](https://arxiv.org/abs/2402.09136)

**PDF Link:** [https://arxiv.org/pdf/2402.09136](https://arxiv.org/pdf/2402.09136)

---

**Date:** 06 Jun 2023

**Title:** On the Role of Attention in Prompt-tuning

**Abstract Link:** [https://arxiv.org/abs/2306.03435](https://arxiv.org/abs/2306.03435)

**PDF Link:** [https://arxiv.org/pdf/2306.03435](https://arxiv.org/pdf/2306.03435)

---

**Date:** 30 Jan 2024

**Title:** Hyperparameter Optimization for Large Language Model Instruction-Tuning

**Abstract Link:** [https://arxiv.org/abs/2312.00949](https://arxiv.org/abs/2312.00949)

**PDF Link:** [https://arxiv.org/pdf/2312.00949](https://arxiv.org/pdf/2312.00949)

---

**Date:** 28 Feb 2024

**Title:** A Closer Look at the Limitations of Instruction Tuning

**Abstract Link:** [https://arxiv.org/abs/2402.05119](https://arxiv.org/abs/2402.05119)

**PDF Link:** [https://arxiv.org/pdf/2402.05119](https://arxiv.org/pdf/2402.05119)

---

**Date:** 31 Jan 2024

**Title:** Federated Full-Parameter Tuning of Billion-Sized Language Models with  Communication Cost under 18 Kilobytes

**Abstract Link:** [https://arxiv.org/abs/2312.06353](https://arxiv.org/abs/2312.06353)

**PDF Link:** [https://arxiv.org/pdf/2312.06353](https://arxiv.org/pdf/2312.06353)

---

