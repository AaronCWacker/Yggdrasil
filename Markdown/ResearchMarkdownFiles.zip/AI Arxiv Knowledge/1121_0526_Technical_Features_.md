Technical Features 📐

### 🔎 Technical Features 📐



- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100% polyester
- 100%
# 🩺🔍 Search Results
### 11 May 2021 | [Entity Summarization: State of the Art and Future Challenges](https://arxiv.org/abs/1910.08252) | [⬇️](https://arxiv.org/pdf/1910.08252)
*Qingxia Liu, Gong Cheng, Kalpa Gunaratna, Yuzhong Qu* 

  The increasing availability of semantic data has substantially enhanced Web
applications. Semantic data such as RDF data is commonly represented as
entity-property-value triples. The magnitude of semantic data, in particular
the large number of triples describing an entity, could overload users with
excessive amounts of information. This has motivated fruitful research on
automated generation of summaries for entity descriptions to satisfy users'
information needs efficiently and effectively. We focus on this prominent topic
of entity summarization, and our research objective is to present the first
comprehensive survey of entity summarization research. Rather than separately
reviewing each method, our contributions include (1) identifying and
classifying technical features of existing methods to form a high-level
overview, (2) identifying and classifying frameworks for combining multiple
technical features adopted by existing methods, (3) collecting known benchmarks
for intrinsic evaluation and efforts for extrinsic evaluation, and (4)
suggesting research directions for future work. By investigating the
literature, we synthesized two hierarchies of techniques. The first hierarchy
categories generic technical features into several perspectives: frequency and
centrality, informativeness, and diversity and coverage. In the second
hierarchy we present domain-specific and task-specific technical features,
including the use of domain knowledge, context awareness, and personalization.
Our review demonstrated that existing methods are mainly unsupervised and they
combine multiple technical features using various frameworks: random surfer
models, similarity-based grouping, MMR-like re-ranking, or combinatorial
optimization. We also found a few deep learning based methods in recent
research.

---------------

### 19 Dec 2023 | [Detecting Technical Debt Using Natural Language Processing Approaches --  A Systematic Literature Review](https://arxiv.org/abs/2312.15020) | [⬇️](https://arxiv.org/pdf/2312.15020)
*Edi Sutoyo, Andrea Capiluppi* 

  Context: Technical debt (TD) is a well-known metaphor for the long-term
effects of architectural decisions in software development and the trade-off
between producing high-quality, effective, and efficient code and meeting a
release schedule. Thus, the code degrades and needs refactoring. A lack of
resources, time, knowledge, or experience on the development team might cause
TD in any software development project. Objective: In the context of TD
detection, NLP has been utilized to identify the presence of TD automatically
and even recognize specific types of TD. However, the enormous variety of
feature extraction approaches and ML/DL algorithms employed in the literature
often hinders researchers from trying to improve their performance. Method: In
light of this, this SLR proposes a taxonomy of feature extraction techniques
and algorithms used in technical debt detection: its objective is to compare
and benchmark their performance in the examined studies. Results: We selected
55 articles that passed the quality evaluation of this SLR. We then
investigated which feature extractions and algorithms were employed to identify
TD in each SDLC phase. All approaches proposed in the analyzed studies were
grouped into NLP, NLP+ML, and NLP+DL. This allows us to discuss the performance
in three different ways. Conclusion: Overall, the NLP+DL group consistently
outperforms in precision and F1-score for all projects, and in all but one
project for the recall metric. Regarding the feature extraction techniques, the
PTWE consistently achieves higher precision, recall, and F1-score for each
project analyzed. Furthermore, TD types have been mapped, when possible, to
SDLC phases: this served to determine the best-performing feature extractions
and algorithms for each SDLC phase. Finally, based on the SLR results, we also
identify implications that could be of concern to researchers and
practitioners.

---------------

### 04 Feb 2022 | [Tracking Discourse Influence in Darknet Forums](https://arxiv.org/abs/2202.02081) | [⬇️](https://arxiv.org/pdf/2202.02081)
*Christopher Akiki, Lukas Gienapp, Martin Potthast* 

  This technical report documents our efforts in addressing the tasks set forth
by the 2021 AMoC (Advanced Modelling of Cyber Criminal Careers) Hackathon. Our
main contribution is a joint visualisation of semantic and temporal features,
generating insight into the supplied data on darknet cybercrime through the
aspects of novelty, transience, and resonance, which describe the potential
impact a message might have on the overall discourse in darknet communities.
All code and data produced by us as part of this hackathon is publicly
available.

---------------

### 28 Mar 2023 | [On Feature Scaling of Recursive Feature Machines](https://arxiv.org/abs/2303.15745) | [⬇️](https://arxiv.org/pdf/2303.15745)
*Arunav Gupta, Rohit Mishra, William Luu, Mehdi Bouassami* 

  In this technical report, we explore the behavior of Recursive Feature
Machines (RFMs), a type of novel kernel machine that recursively learns
features via the average gradient outer product, through a series of
experiments on regression datasets. When successively adding random noise
features to a dataset, we observe intriguing patterns in the Mean Squared Error
(MSE) curves with the test MSE exhibiting a decrease-increase-decrease pattern.
This behavior is consistent across different dataset sizes, noise parameters,
and target functions. Interestingly, the observed MSE curves show similarities
to the "double descent" phenomenon observed in deep neural networks, hinting at
new connection between RFMs and neural network behavior. This report lays the
groundwork for future research into this peculiar behavior.

---------------

### 11 Aug 2023 | [PENTACET data -- 23 Million Contextual Code Comments and 250,000 SATD  comments](https://arxiv.org/abs/2303.14029) | [⬇️](https://arxiv.org/pdf/2303.14029)
*Murali Sridharan, Leevi Rantala, Mika M\"antyl\"a* 

  Most Self-Admitted Technical Debt (SATD) research utilizes explicit SATD
features such as 'TODO' and 'FIXME' for SATD detection. A closer look reveals
several SATD research uses simple SATD ('Easy to Find') code comments without
the contextual data (preceding and succeeding source code context). This work
addresses this gap through PENTACET (or 5C dataset) data. PENTACET is a large
Curated Contextual Code Comments per Contributor and the most extensive SATD
data. We mine 9,096 Open Source Software Java projects with a total of 435
million LOC. The outcome is a dataset with 23 million code comments, preceding
and succeeding source code context for each comment, and more than 250,000
comments labeled as SATD, including both 'Easy to Find' and 'Hard to Find'
SATD. We believe PENTACET data will further SATD research using Artificial
Intelligence techniques.

---------------

### 16 Aug 2020 | [GA-MSSR: Genetic Algorithm Maximizing Sharpe and Sterling Ratio Method  for RoboTrading](https://arxiv.org/abs/2008.09471) | [⬇️](https://arxiv.org/pdf/2008.09471)
*Zezheng Zhang and Matloob Khushi* 

  Foreign exchange is the largest financial market in the world, and it is also
one of the most volatile markets. Technical analysis plays an important role in
the forex market and trading algorithms are designed utilizing machine learning
techniques. Most literature used historical price information and technical
indicators for training. However, the noisy nature of the market affects the
consistency and profitability of the algorithms. To address this problem, we
designed trading rule features that are derived from technical indicators and
trading rules. The parameters of technical indicators are optimized to maximize
trading performance. We also proposed a novel cost function that computes the
risk-adjusted return, Sharpe and Sterling Ratio (SSR), in an effort to reduce
the variance and the magnitude of drawdowns. An automatic robotic trading
(RoboTrading) strategy is designed with the proposed Genetic Algorithm
Maximizing Sharpe and Sterling Ratio model (GA-MSSR) model. The experiment was
conducted on intraday data of 6 major currency pairs from 2018 to 2019. The
results consistently showed significant positive returns and the performance of
the trading system is superior using the optimized rule-based features. The
highest return obtained was 320% annually using 5-minute AUDUSD currency pair.
Besides, the proposed model achieves the best performance on risk factors,
including maximum drawdowns and variance in return, comparing to benchmark
models. The code can be accessed at
https://github.com/zzzac/rule-based-forextrading-system

---------------

### 26 Jun 2023 | [INDEXITY: a web-based collaborative tool for medical video annotation](https://arxiv.org/abs/2306.14780) | [⬇️](https://arxiv.org/pdf/2306.14780)
*Jean-Paul Mazellier, M\'eline Bour-Lang, Sabrina Bourouis, Johan  Moreau, Aimable Muzuri, Olivier Schweitzer, Aslan Vatsaev, Julien Waechter,  Emilie Wernert, Frederic Woelffel, Alexandre Hostettler, Nicolas Padoy,  Flavien Bridault* 

  This technical report presents Indexity 1.4.0, a web-based tool designed for
medical video annotation in surgical data science projects. We describe the
main features available for the management of videos, annotations, ontology and
users, as well as the global software architecture.

---------------

### 02 Jun 2016 | [Sequential Principal Curves Analysis](https://arxiv.org/abs/1606.00856) | [⬇️](https://arxiv.org/pdf/1606.00856)
*Valero Laparra and Jesus Malo* 

  This work includes all the technical details of the Sequential Principal
Curves Analysis (SPCA) in a single document. SPCA is an unsupervised nonlinear
and invertible feature extraction technique. The identified curvilinear
features can be interpreted as a set of nonlinear sensors: the response of each
sensor is the projection onto the corresponding feature. Moreover, it can be
easily tuned for different optimization criteria; e.g. infomax, error
minimization, decorrelation; by choosing the right way to measure distances
along each curvilinear feature. Even though proposed in [Laparra et al. Neural
Comp. 12] and shown to work in multiple modalities in [Laparra and Malo
Frontiers Hum. Neuro. 15], the SPCA framework has its original roots in the
nonlinear ICA algorithm in [Malo and Gutierrez Network 06]. Later on, the SPCA
philosophy for nonlinear generalization of PCA originated substantially faster
alternatives at the cost of introducing different constraints in the model.
Namely, the Principal Polynomial Analysis (PPA) [Laparra et al. IJNS 14], and
the Dimensionality Reduction via Regression (DRR) [Laparra et al. IEEE TGRS
15]. This report illustrates the reasons why we developed such family and is
the appropriate technical companion for the missing details in [Laparra et al.,
NeCo 12, Laparra and Malo, Front.Hum.Neuro. 15]. See also the data, code and
examples in the dedicated sites http://isp.uv.es/spca.html and
http://isp.uv.es/after effects.html

---------------

### 29 May 2018 | [Currency exchange prediction using machine learning, genetic algorithms  and technical analysis](https://arxiv.org/abs/1805.11232) | [⬇️](https://arxiv.org/pdf/1805.11232)
*Gon\c{c}alo Abreu, Rui Neves, Nuno Horta* 

  Technical analysis is used to discover investment opportunities. To test this
hypothesis we propose an hybrid system using machine learning techniques
together with genetic algorithms. Using technical analysis there are more ways
to represent a currency exchange time series than the ones it is possible to
test computationally, i.e., it is unfeasible to search the whole input feature
space thus a genetic algorithm is an alternative. In this work, an architecture
for automatic feature selection is proposed to optimize the cross validated
performance estimation of a Naive Bayes model using a genetic algorithm. The
proposed architecture improves the return on investment of the unoptimized
system from 0,43% to 10,29% in the validation set. The features selected and
the model decision boundary are visualized using the algorithm t-Distributed
Stochastic Neighbor embedding.

---------------

### 28 Mar 2022 | [Towards Implicit Text-Guided 3D Shape Generation](https://arxiv.org/abs/2203.14622) | [⬇️](https://arxiv.org/pdf/2203.14622)
*Zhengzhe Liu, Yi Wang, Xiaojuan Qi, Chi-Wing Fu* 

  In this work, we explore the challenging task of generating 3D shapes from
text. Beyond the existing works, we propose a new approach for text-guided 3D
shape generation, capable of producing high-fidelity shapes with colors that
match the given text description. This work has several technical
contributions. First, we decouple the shape and color predictions for learning
features in both texts and shapes, and propose the word-level spatial
transformer to correlate word features from text with spatial features from
shape. Also, we design a cyclic loss to encourage consistency between text and
shape, and introduce the shape IMLE to diversify the generated shapes. Further,
we extend the framework to enable text-guided shape manipulation. Extensive
experiments on the largest existing text-shape benchmark manifest the
superiority of this work. The code and the models are available at
https://github.com/liuzhengzhe/Towards-Implicit Text-Guided-Shape-Generation.

---------------

### 26 Apr 2023 | [Conjunctive Query Based Constraint Solving For Feature Model  Configuration](https://arxiv.org/abs/2304.13422) | [⬇️](https://arxiv.org/pdf/2304.13422)
*Alexander Felfernig, Viet-Man Le, Sebastian Lubos* 

  Feature model configuration can be supported on the basis of various types of
reasoning approaches. Examples thereof are SAT solving, constraint solving, and
answer set programming (ASP). Using these approaches requires technical
expertise of how to define and solve the underlying configuration problem. In
this paper, we show how to apply conjunctive queries typically supported by
today's relational database systems to solve constraint satisfaction problems
(CSP) and -- more specifically -- feature model configuration tasks. This
approach allows the application of a wide-spread database technology to solve
configuration tasks and also allows for new algorithmic approaches when it
comes to the identification and resolution of inconsistencies.

---------------

### 28 May 2020 | [Disentanglement Then Reconstruction: Learning Compact Features for  Unsupervised Domain Adaptation](https://arxiv.org/abs/2005.13947) | [⬇️](https://arxiv.org/pdf/2005.13947)
*Lihua Zhou, Mao Ye, Xinpeng Li, Ce Zhu, Yiguang Liu, and Xue Li* 

  Recent works in domain adaptation always learn domain invariant features to
mitigate the gap between the source and target domains by adversarial methods.
The category information are not sufficiently used which causes the learned
domain invariant features are not enough discriminative. We propose a new
domain adaptation method based on prototype construction which likes capturing
data cluster centers. Specifically, it consists of two parts: disentanglement
and reconstruction. First, the domain specific features and domain invariant
features are disentangled from the original features. At the same time, the
domain prototypes and class prototypes of both domains are estimated. Then, a
reconstructor is trained by reconstructing the original features from the
disentangled domain invariant features and domain specific features. By this
reconstructor, we can construct prototypes for the original features using
class prototypes and domain prototypes correspondingly. In the end, the feature
extraction network is forced to extract features close to these prototypes. Our
contribution lies in the technical use of the reconstructor to obtain the
original feature prototypes which helps to learn compact and discriminant
features. As far as we know, this idea is proposed for the first time.
Experiment results on several public datasets confirm the state-of-the-art
performance of our method.

---------------

### 21 Apr 2015 | [Deep Convolutional Neural Networks Based on Semi-Discrete Frames](https://arxiv.org/abs/1504.05487) | [⬇️](https://arxiv.org/pdf/1504.05487)
*Thomas Wiatowski and Helmut B\"olcskei* 

  Deep convolutional neural networks have led to breakthrough results in
practical feature extraction applications. The mathematical analysis of these
networks was pioneered by Mallat, 2012. Specifically, Mallat considered
so-called scattering networks based on identical semi-discrete wavelet frames
in each network layer, and proved translation-invariance as well as deformation
stability of the resulting feature extractor. The purpose of this paper is to
develop Mallat's theory further by allowing for different and, most
importantly, general semi-discrete frames (such as, e.g., Gabor frames,
wavelets, curvelets, shearlets, ridgelets) in distinct network layers. This
allows to extract wider classes of features than point singularities resolved
by the wavelet transform. Our generalized feature extractor is proven to be
translation-invariant, and we develop deformation stability results for a
larger class of deformations than those considered by Mallat. For Mallat's
wavelet-based feature extractor, we get rid of a number of technical
conditions. The mathematical engine behind our results is continuous frame
theory, which allows us to completely detach the invariance and deformation
stability proofs from the particular algebraic structure of the underlying
frames.

---------------

### 17 Feb 2021 | [On Technical Trading and Social Media Indicators in Cryptocurrencies'  Price Classification Through Deep Learning](https://arxiv.org/abs/2102.08189) | [⬇️](https://arxiv.org/pdf/2102.08189)
*Marco Ortu, Nicola Uras, Claudio Conversano, Giuseppe Destefanis,  Silvia Bartolucci* 

  This work aims to analyse the predictability of price movements of
cryptocurrencies on both hourly and daily data observed from January 2017 to
January 2021, using deep learning algorithms. For our experiments, we used
three sets of features: technical, trading and social media indicators,
considering a restricted model of only technical indicators and an unrestricted
model with technical, trading and social media indicators. We verified whether
the consideration of trading and social media indicators, along with the
classic technical variables (such as price's returns), leads to a significative
improvement in the prediction of cryptocurrencies price's changes. We conducted
the study on the two highest cryptocurrencies in volume and value (at the time
of the study): Bitcoin and Ethereum. We implemented four different machine
learning algorithms typically used in time-series classification problems:
Multi Layers Perceptron (MLP), Convolutional Neural Network (CNN), Long Short
Term Memory (LSTM) neural network and Attention Long Short Term Memory (ALSTM).
We devised the experiments using the advanced bootstrap technique to consider
the variance problem on test samples, which allowed us to evaluate a more
reliable estimate of the model's performance. Furthermore, the Grid Search
technique was used to find the best hyperparameters values for each implemented
algorithm. The study shows that, based on the hourly frequency results, the
unrestricted model outperforms the restricted one. The addition of the trading
indicators to the classic technical indicators improves the accuracy of Bitcoin
and Ethereum price's changes prediction, with an increase of accuracy from a
range of 51-55% for the restricted model, to 67-84% for the unrestricted model.

---------------

### 27 Apr 2021 | [Augmenting Scientific Papers with Just-in-Time, Position-Sensitive  Definitions of Terms and Symbols](https://arxiv.org/abs/2009.14237) | [⬇️](https://arxiv.org/pdf/2009.14237)
*Andrew Head (UC Berkeley), Kyle Lo (Allen Institute for AI), Dongyeop  Kang (UC Berkeley), Raymond Fok (University of Washington), Sam Skjonsberg  (Allen Institute for AI), Daniel S. Weld (Allen Institute for AI, University  of Washington), Marti A. Hearst (UC Berkeley)* 

  Despite the central importance of research papers to scientific progress,
they can be difficult to read. Comprehension is often stymied when the
information needed to understand a passage resides somewhere else: in another
section, or in another paper. In this work, we envision how interfaces can
bring definitions of technical terms and symbols to readers when and where they
need them most. We introduce ScholarPhi, an augmented reading interface with
four novel features: (1) tooltips that surface position-sensitive definitions
from elsewhere in a paper, (2) a filter over the paper that "declutters" it to
reveal how the term or symbol is used across the paper, (3) automatic equation
diagrams that expose multiple definitions in parallel, and (4) an automatically
generated glossary of important terms and symbols. A usability study showed
that the tool helps researchers of all experience levels read papers.
Furthermore, researchers were eager to have ScholarPhi's definitions available
to support their everyday reading.

---------------

### 06 Nov 2023 | [Feature selection and regression methods for stock price prediction  using technical indicators](https://arxiv.org/abs/2310.09903) | [⬇️](https://arxiv.org/pdf/2310.09903)
*Fatemeh Moodi, Amir Jahangard-Rafsanjani, Sajad Zarifzadeh* 

  Due to the influence of many factors, including technical indicators on stock
price prediction, feature selection is important to choose the best indicators.
This study uses technical indicators and features selection and regression
methods to solve the problem of closing the stock market price. The aim of this
research is to predict the stock market price with the least error. By the
proposed method, the data created by the 3-day time window were converted to
the appropriate input for regression methods. In this paper, 10 regressor and
123 technical indicators have been examined on data of the last 13 years of
Apple Company. The results have been investigated by 5 error-based evaluation
criteria. Based on results of the proposed method, MLPSF has 56/47% better
performance than MLP. Also, SVRSF has 67/42% improved compared to SVR. LRSF was
76.7 % improved compared to LR. The RISF method also improved 72.82 % of Ridge
regression. The DTRSB method had 24.23 % improvement over DTR. KNNSB had 15.52
% improvement over KNN regression. RFSB had a 6 % improvement over RF. GBRSF
also improved at 7% over GBR. Finally, ADASF and ADASB also had a 4%
improvement over the ADA regression. Also, Ridge and LinearRegression had the
best results for stock price prediction. Based on results, the best indicators
to predict stock price are: the Squeeze_pro, Percentage Price Oscillator,
Thermo, Decay, Archer On-Balance Volume, Bollinger Bands, Squeeze and Ichimoku
indicator. According to the results, the use of suitable combination of
suggested indicators along with regression methods has resulted in high
accuracy in predicting the closing price.

---------------

### 30 Apr 2019 | [Machine Decisions and Human Consequences](https://arxiv.org/abs/1811.06747) | [⬇️](https://arxiv.org/pdf/1811.06747)
*Teresa Scantamburlo, Andrew Charlesworth, Nello Cristianini* 

  As we increasingly delegate decision-making to algorithms, whether directly
or indirectly, important questions emerge in circumstances where those
decisions have direct consequences for individual rights and personal
opportunities, as well as for the collective good. A key problem for
policymakers is that the social implications of these new methods can only be
grasped if there is an adequate comprehension of their general technical
underpinnings. The discussion here focuses primarily on the case of enforcement
decisions in the criminal justice system, but draws on similar situations
emerging from other algorithms utilised in controlling access to opportunities,
to explain how machine learning works and, as a result, how decisions are made
by modern intelligent algorithms or 'classifiers'. It examines the key aspects
of the performance of classifiers, including how classifiers learn, the fact
that they operate on the basis of correlation rather than causation, and that
the term 'bias' in machine learning has a different meaning to common usage. An
example of a real world 'classifier', the Harm Assessment Risk Tool (HART), is
examined, through identification of its technical features: the classification
method, the training data and the test data, the features and the labels,
validation and performance measures. Four normative benchmarks are then
considered by reference to HART: (a) prediction accuracy (b) fairness and
equality before the law (c) transparency and accountability (d) informational
privacy and freedom of expression, in order to demonstrate how its technical
features have important normative dimensions that bear directly on the extent
to which the system can be regarded as a viable and legitimate support for, or
even alternative to, existing human decision-makers.

---------------

### 15 Jun 2019 | [Neural Feature Learning From Relational Database](https://arxiv.org/abs/1801.05372) | [⬇️](https://arxiv.org/pdf/1801.05372)
*Hoang Thanh Lam, Tran Ngoc Minh, Mathieu Sinn, Beat Buesser and Martin  Wistuba* 

  Feature engineering is one of the most important but most tedious tasks in
data science. This work studies automation of feature learning from relational
database. We first prove theoretically that finding the optimal features from
relational data for predictive tasks is NP-hard. We propose an efficient
rule-based approach based on heuristics and a deep neural network to
automatically learn appropriate features from relational data. We benchmark our
approaches in ensembles in past Kaggle competitions. Our new approach wins late
medals and beats the state-of-the-art solutions with significant margins. To
the best of our knowledge, this is the first time an automated data science
system could win medals in Kaggle competitions with complex relational
database.

---------------

### 11 Jul 2021 | [Random Features for Kernel Approximation: A Survey on Algorithms,  Theory, and Beyond](https://arxiv.org/abs/2004.11154) | [⬇️](https://arxiv.org/pdf/2004.11154)
*Fanghui Liu, Xiaolin Huang, Yudong Chen, and Johan A.K. Suykens* 

  Random features is one of the most popular techniques to speed up kernel
methods in large-scale problems. Related works have been recognized by the
NeurIPS Test-of-Time award in 2017 and the ICML Best Paper Finalist in 2019.
The body of work on random features has grown rapidly, and hence it is
desirable to have a comprehensive overview on this topic explaining the
connections among various algorithms and theoretical results. In this survey,
we systematically review the work on random features from the past ten years.
First, the motivations, characteristics and contributions of representative
random features based algorithms are summarized according to their sampling
schemes, learning procedures, variance reduction properties and how they
exploit training data. Second, we review theoretical results that center around
the following key question: how many random features are needed to ensure a
high approximation quality or no loss in the empirical/expected risks of the
learned estimator. Third, we provide a comprehensive evaluation of popular
random features based algorithms on several large-scale benchmark datasets and
discuss their approximation quality and prediction performance for
classification. Last, we discuss the relationship between random features and
modern over-parameterized deep neural networks (DNNs), including the use of
high dimensional random features in the analysis of DNNs as well as the gaps
between current theoretical and empirical results. This survey may serve as a
gentle introduction to this topic, and as a users' guide for practitioners
interested in applying the representative algorithms and understanding
theoretical results under various technical assumptions. We hope that this
survey will facilitate discussion on the open problems in this topic, and more
importantly, shed light on future research directions.

---------------

### 06 Jul 2020 | [Constrained Linear Data-feature Mapping for Image Classification](https://arxiv.org/abs/1911.10428) | [⬇️](https://arxiv.org/pdf/1911.10428)
*Juncai He, Yuyan Chen, Lian Zhang, Jinchao Xu* 

  In this paper, we propose a constrained linear data-feature mapping model as
an interpretable mathematical model for image classification using
convolutional neural network (CNN) such as the ResNet. From this viewpoint, we
establish the detailed connections in a technical level between the traditional
iterative schemes for constrained linear system and the architecture for the
basic blocks of ResNet. Under these connections, we propose some natural
modifications of ResNet type models which will have less parameters but still
maintain almost the same accuracy as these corresponding original models. Some
numerical experiments are shown to demonstrate the validity of this constrained
learning data-feature mapping assumption.

---------------
**Date:** 11 May 2021

**Title:** Entity Summarization: State of the Art and Future Challenges

**Abstract Link:** [https://arxiv.org/abs/1910.08252](https://arxiv.org/abs/1910.08252)

**PDF Link:** [https://arxiv.org/pdf/1910.08252](https://arxiv.org/pdf/1910.08252)

---

**Date:** 19 Dec 2023

**Title:** Detecting Technical Debt Using Natural Language Processing Approaches --  A Systematic Literature Review

**Abstract Link:** [https://arxiv.org/abs/2312.15020](https://arxiv.org/abs/2312.15020)

**PDF Link:** [https://arxiv.org/pdf/2312.15020](https://arxiv.org/pdf/2312.15020)

---

**Date:** 04 Feb 2022

**Title:** Tracking Discourse Influence in Darknet Forums

**Abstract Link:** [https://arxiv.org/abs/2202.02081](https://arxiv.org/abs/2202.02081)

**PDF Link:** [https://arxiv.org/pdf/2202.02081](https://arxiv.org/pdf/2202.02081)

---

**Date:** 28 Mar 2023

**Title:** On Feature Scaling of Recursive Feature Machines

**Abstract Link:** [https://arxiv.org/abs/2303.15745](https://arxiv.org/abs/2303.15745)

**PDF Link:** [https://arxiv.org/pdf/2303.15745](https://arxiv.org/pdf/2303.15745)

---

**Date:** 11 Aug 2023

**Title:** PENTACET data -- 23 Million Contextual Code Comments and 250,000 SATD  comments

**Abstract Link:** [https://arxiv.org/abs/2303.14029](https://arxiv.org/abs/2303.14029)

**PDF Link:** [https://arxiv.org/pdf/2303.14029](https://arxiv.org/pdf/2303.14029)

---

**Date:** 16 Aug 2020

**Title:** GA-MSSR: Genetic Algorithm Maximizing Sharpe and Sterling Ratio Method  for RoboTrading

**Abstract Link:** [https://arxiv.org/abs/2008.09471](https://arxiv.org/abs/2008.09471)

**PDF Link:** [https://arxiv.org/pdf/2008.09471](https://arxiv.org/pdf/2008.09471)

---

**Date:** 26 Jun 2023

**Title:** INDEXITY: a web-based collaborative tool for medical video annotation

**Abstract Link:** [https://arxiv.org/abs/2306.14780](https://arxiv.org/abs/2306.14780)

**PDF Link:** [https://arxiv.org/pdf/2306.14780](https://arxiv.org/pdf/2306.14780)

---

**Date:** 02 Jun 2016

**Title:** Sequential Principal Curves Analysis

**Abstract Link:** [https://arxiv.org/abs/1606.00856](https://arxiv.org/abs/1606.00856)

**PDF Link:** [https://arxiv.org/pdf/1606.00856](https://arxiv.org/pdf/1606.00856)

---

**Date:** 29 May 2018

**Title:** Currency exchange prediction using machine learning, genetic algorithms  and technical analysis

**Abstract Link:** [https://arxiv.org/abs/1805.11232](https://arxiv.org/abs/1805.11232)

**PDF Link:** [https://arxiv.org/pdf/1805.11232](https://arxiv.org/pdf/1805.11232)

---

**Date:** 28 Mar 2022

**Title:** Towards Implicit Text-Guided 3D Shape Generation

**Abstract Link:** [https://arxiv.org/abs/2203.14622](https://arxiv.org/abs/2203.14622)

**PDF Link:** [https://arxiv.org/pdf/2203.14622](https://arxiv.org/pdf/2203.14622)

---

**Date:** 26 Apr 2023

**Title:** Conjunctive Query Based Constraint Solving For Feature Model  Configuration

**Abstract Link:** [https://arxiv.org/abs/2304.13422](https://arxiv.org/abs/2304.13422)

**PDF Link:** [https://arxiv.org/pdf/2304.13422](https://arxiv.org/pdf/2304.13422)

---

**Date:** 28 May 2020

**Title:** Disentanglement Then Reconstruction: Learning Compact Features for  Unsupervised Domain Adaptation

**Abstract Link:** [https://arxiv.org/abs/2005.13947](https://arxiv.org/abs/2005.13947)

**PDF Link:** [https://arxiv.org/pdf/2005.13947](https://arxiv.org/pdf/2005.13947)

---

**Date:** 21 Apr 2015

**Title:** Deep Convolutional Neural Networks Based on Semi-Discrete Frames

**Abstract Link:** [https://arxiv.org/abs/1504.05487](https://arxiv.org/abs/1504.05487)

**PDF Link:** [https://arxiv.org/pdf/1504.05487](https://arxiv.org/pdf/1504.05487)

---

**Date:** 17 Feb 2021

**Title:** On Technical Trading and Social Media Indicators in Cryptocurrencies'  Price Classification Through Deep Learning

**Abstract Link:** [https://arxiv.org/abs/2102.08189](https://arxiv.org/abs/2102.08189)

**PDF Link:** [https://arxiv.org/pdf/2102.08189](https://arxiv.org/pdf/2102.08189)

---

**Date:** 27 Apr 2021

**Title:** Augmenting Scientific Papers with Just-in-Time, Position-Sensitive  Definitions of Terms and Symbols

**Abstract Link:** [https://arxiv.org/abs/2009.14237](https://arxiv.org/abs/2009.14237)

**PDF Link:** [https://arxiv.org/pdf/2009.14237](https://arxiv.org/pdf/2009.14237)

---

**Date:** 06 Nov 2023

**Title:** Feature selection and regression methods for stock price prediction  using technical indicators

**Abstract Link:** [https://arxiv.org/abs/2310.09903](https://arxiv.org/abs/2310.09903)

**PDF Link:** [https://arxiv.org/pdf/2310.09903](https://arxiv.org/pdf/2310.09903)

---

**Date:** 30 Apr 2019

**Title:** Machine Decisions and Human Consequences

**Abstract Link:** [https://arxiv.org/abs/1811.06747](https://arxiv.org/abs/1811.06747)

**PDF Link:** [https://arxiv.org/pdf/1811.06747](https://arxiv.org/pdf/1811.06747)

---

**Date:** 15 Jun 2019

**Title:** Neural Feature Learning From Relational Database

**Abstract Link:** [https://arxiv.org/abs/1801.05372](https://arxiv.org/abs/1801.05372)

**PDF Link:** [https://arxiv.org/pdf/1801.05372](https://arxiv.org/pdf/1801.05372)

---

**Date:** 11 Jul 2021

**Title:** Random Features for Kernel Approximation: A Survey on Algorithms,  Theory, and Beyond

**Abstract Link:** [https://arxiv.org/abs/2004.11154](https://arxiv.org/abs/2004.11154)

**PDF Link:** [https://arxiv.org/pdf/2004.11154](https://arxiv.org/pdf/2004.11154)

---

**Date:** 06 Jul 2020

**Title:** Constrained Linear Data-feature Mapping for Image Classification

**Abstract Link:** [https://arxiv.org/abs/1911.10428](https://arxiv.org/abs/1911.10428)

**PDF Link:** [https://arxiv.org/pdf/1911.10428](https://arxiv.org/pdf/1911.10428)

---

