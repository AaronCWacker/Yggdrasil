LLM Multi-agent Interaction 👾

### 🔎 LLM Multi-agent Interaction 👾



- Multi-agent systems are systems where multiple agents interact with each other to achieve a common goal or compete against each other.
- Agents can be software or hardware entities that can perceive their environment and take actions based on their perceptions.
- Multi-agent systems can be used in various applications such as traffic control, robotics, and social networks.
- Multi-agent systems can be classified based on the level of interaction between the agents, the degree of autonomy, and the type of communication.
- Multi-agent systems can be designed using various techniques such as game theory, auction theory, and machine learning.
- Multi-agent systems can be analyzed using various methods such as simulation, statistical analysis, and optimization.
- Multi-agent systems can be implemented using various programming languages and tools such as Java, Python, and MATLAB.

Multi-agent systems are systems where multiple agents interact with each other to achieve a common goal or compete against each other. Agents can be software or hardware entities that can perceive their environment and take actions based on their perceptions. Multi-agent systems can be used in various applications such as traffic control, robotics, and social networks.

Multi-agent systems can be classified based on the level of interaction between the agents, the degree of autonomy, and the type of communication. The level of interaction can be cooperative, competitive, or a combination of both. The degree of autonomy can range from fully autonomous agents to fully controlled agents. The type of communication can be explicit, implicit, or a combination of both.

Multi-agent systems can be designed using various techniques such as game theory, auction theory, and machine learning. Game theory is a mathematical model of strategic interaction between rational decision-makers. Auction theory is a framework for analyzing the allocation of goods or services among competing agents. Machine learning is a method of designing agents that can learn from experience.

Multi-agent systems can be analyzed using various methods such as simulation, statistical analysis, and optimization. Simulation is a method of creating a model of the system and observing its behavior over time. Statistical analysis is a method of analyzing the data collected from the system to identify patterns and trends. Optimization is a method of finding the best solution to a problem.

Multi-agent systems can be implemented using various programming languages and tools such as Java, Python, and MATLAB. Java is a popular programming
# 🩺🔍 Search Results
### 02 Feb 2024 | [MAGDi: Structured Distillation of Multi-Agent Interaction Graphs  Improves Reasoning in Smaller Language Models](https://arxiv.org/abs/2402.01620) | [⬇️](https://arxiv.org/pdf/2402.01620)
*Justin Chih-Yao Chen, Swarnadeep Saha, Elias Stengel-Eskin, Mohit  Bansal* 

  Multi-agent interactions between Large Language Model (LLM) agents have shown
major improvements on diverse reasoning tasks. However, these involve long
generations from multiple models across several rounds, making them expensive.
Moreover, these multi-agent approaches fail to provide a final, single model
for efficient inference. To address this, we introduce MAGDi, a new method for
structured distillation of the reasoning interactions between multiple LLMs
into smaller LMs. MAGDi teaches smaller models by representing multi-agent
interactions as graphs, augmenting a base student model with a graph encoder,
and distilling knowledge using three objective functions: next-token
prediction, a contrastive loss between correct and incorrect reasoning, and a
graph-based objective to model the interaction structure. Experiments on seven
widely-used commonsense and math reasoning benchmarks show that MAGDi improves
the reasoning capabilities of smaller models, outperforming several methods
that distill from a single teacher and multiple teachers. Moreover, MAGDi also
demonstrates an order of magnitude higher efficiency over its teachers. We
conduct extensive analyses to show that MAGDi (1) enhances the generalizability
to out-of-domain tasks, (2) scales positively with the size and strength of the
base student model, and (3) obtains larger improvements (via our multi-teacher
training) when applying self-consistency - an inference technique that relies
on model diversity.

---------------

### 05 Mar 2024 | [AntEval: Evaluation of Social Interaction Competencies in LLM-Driven  Agents](https://arxiv.org/abs/2401.06509) | [⬇️](https://arxiv.org/pdf/2401.06509)
*Yuanzhi Liang, Linchao Zhu, Yi Yang* 

  Large Language Models (LLMs) have demonstrated their ability to replicate
human behaviors across a wide range of scenarios. However, their capability in
handling complex, multi-character social interactions has yet to be fully
explored, primarily due to the absence of robust, quantitative evaluation
methods. This gap has slowed the development of agents proficient in more
nuanced interactions beyond simple exchanges, for example, small talk. To
address this challenge, we introduce the Multi-Agent Interaction Evaluation
Framework (AntEval), encompassing a novel interaction framework and evaluation
methods. The interaction framework aims to foster an complex interaction
environment that bolsters information exchange and intention expression within
social interactions. Furthermore, we introduce evaluation methods, including
two metrics: Information Exchanging Precision (IEP) and Interaction
Expressiveness Gap (IEG), designed for the quantitative and objective
assessment of agents' interaction competencies. Our findings highlight the
utility of these evaluative methods and show significant potential for
improving LLMs' ability to construct agents that interact in a more natural
manner with human-like intricacy.

---------------

### 28 Aug 2023 | [CGMI: Configurable General Multi-Agent Interaction Framework](https://arxiv.org/abs/2308.12503) | [⬇️](https://arxiv.org/pdf/2308.12503)
*Shi Jinxin, Zhao Jiabao, Wang Yilei, Wu Xingjiao, Li Jiawen, He Liang* 

  Benefiting from the powerful capabilities of large language models (LLMs),
agents based on LLMs have shown the potential to address domain-specific tasks
and emulate human behaviors. However, the content generated by these agents
remains somewhat superficial, owing to their limited domain expertise and the
absence of an effective cognitive architecture. To address this, we present the
Configurable General Multi-Agent Interaction (CGMI) framework, designed to
replicate human interactions in real-world scenarios. Specifically, we propose
a tree-structured methodology for the assignment, detection, and maintenance of
agent personality. Additionally, we designed a cognitive architecture equipped
with a skill library based on the ACT* model, which contains memory,
reflection, and planning modules. We have also integrated general agents to
augment the virtual environment's realism. Using the CGMI framework, we
simulated numerous classroom interactions between teacher and students. The
experiments indicate that aspects such as the teaching methodology, curriculum,
and student performance closely mirror real classroom settings. We will open
source our work.

---------------

### 19 Jan 2024 | [SocraSynth: Multi-LLM Reasoning with Conditional Statistics](https://arxiv.org/abs/2402.06634) | [⬇️](https://arxiv.org/pdf/2402.06634)
*Edward Y. Chang* 

  Large language models (LLMs), while promising, face criticisms for biases,
hallucinations, and a lack of reasoning capability. This paper introduces
SocraSynth, a multi-LLM agent reasoning platform developed to mitigate these
issues. SocraSynth utilizes conditional statistics and systematic context
enhancement through continuous arguments, alongside adjustable debate
contentiousness levels. The platform typically involves a human moderator and
two LLM agents representing opposing viewpoints on a given subject. SocraSynth
operates in two main phases: knowledge generation and reasoning evaluation. In
the knowledge generation phase, the moderator defines the debate topic and
contentiousness level, prompting the agents to formulate supporting arguments
for their respective stances. The reasoning evaluation phase then employs
Socratic reasoning and formal logic principles to appraise the quality of the
arguments presented. The dialogue concludes with the moderator adjusting the
contentiousness from confrontational to collaborative, gathering final,
conciliatory remarks to aid in human reasoning and decision-making. Through
case studies in three distinct application domains, this paper showcases
SocraSynth's effectiveness in fostering rigorous research, dynamic reasoning,
comprehensive assessment, and enhanced collaboration. This underscores the
value of multi-agent interactions in leveraging LLMs for advanced knowledge
extraction and decision-making support.

---------------

### 28 Feb 2024 | [Rethinking the Bounds of LLM Reasoning: Are Multi-Agent Discussions the  Key?](https://arxiv.org/abs/2402.18272) | [⬇️](https://arxiv.org/pdf/2402.18272)
*Qineng Wang, Zihao Wang, Ying Su, Hanghang Tong, Yangqiu Song* 

  Recent progress in LLMs discussion suggests that multi-agent discussion
improves the reasoning abilities of LLMs. In this work, we reevaluate this
claim through systematic experiments, where we propose a novel group discussion
framework to enrich the set of discussion mechanisms. Interestingly, our
results show that a single-agent LLM with strong prompts can achieve almost the
same performance as the best existing discussion approach on a wide range of
reasoning tasks and backbone LLMs. We observe that the multi-agent discussion
performs better than a single agent only when there is no demonstration in the
prompt. Further study reveals the common interaction mechanisms of LLMs during
the discussion.

---------------

### 26 Feb 2024 | [LLMArena: Assessing Capabilities of Large Language Models in Dynamic  Multi-Agent Environments](https://arxiv.org/abs/2402.16499) | [⬇️](https://arxiv.org/pdf/2402.16499)
*Junzhe Chen, Xuming Hu, Shuodi Liu, Shiyu Huang, Wei-Wei Tu, Zhaofeng  He and Lijie Wen* 

  Recent advancements in large language models (LLMs) have revealed their
potential for achieving autonomous agents possessing human-level intelligence.
However, existing benchmarks for evaluating LLM Agents either use static
datasets, potentially leading to data leakage or focus only on single-agent
scenarios, overlooking the complexities of multi-agent interactions. There is a
lack of a benchmark that evaluates the diverse capabilities of LLM agents in
multi-agent, dynamic environments. To this end, we introduce LLMArena, a novel
and easily extensible framework for evaluating the diverse capabilities of LLM
in multi-agent dynamic environments. LLMArena encompasses seven distinct gaming
environments, employing Trueskill scoring to assess crucial abilities in LLM
agents, including spatial reasoning, strategic planning, numerical reasoning,
risk assessment, communication, opponent modeling, and team collaboration. We
conduct an extensive experiment and human evaluation among different sizes and
types of LLMs, showing that LLMs still have a significant journey ahead in
their development towards becoming fully autonomous agents, especially in
opponent modeling and team collaboration. We hope LLMArena could guide future
research towards enhancing these capabilities in LLMs, ultimately leading to
more sophisticated and practical applications in dynamic, multi-agent settings.
The code and data will be available.

---------------

### 17 Feb 2024 | [Building Cooperative Embodied Agents Modularly with Large Language  Models](https://arxiv.org/abs/2307.02485) | [⬇️](https://arxiv.org/pdf/2307.02485)
*Hongxin Zhang, Weihua Du, Jiaming Shan, Qinhong Zhou, Yilun Du, Joshua  B. Tenenbaum, Tianmin Shu, Chuang Gan* 

  In this work, we address challenging multi-agent cooperation problems with
decentralized control, raw sensory observations, costly communication, and
multi-objective tasks instantiated in various embodied environments. While
previous research either presupposes a cost-free communication channel or
relies on a centralized controller with shared observations, we harness the
commonsense knowledge, reasoning ability, language comprehension, and text
generation prowess of LLMs and seamlessly incorporate them into a
cognitive-inspired modular framework that integrates with perception, memory,
and execution. Thus building a Cooperative Embodied Language Agent CoELA, who
can plan, communicate, and cooperate with others to accomplish long-horizon
tasks efficiently. Our experiments on C-WAH and TDW-MAT demonstrate that CoELA
driven by GPT-4 can surpass strong planning-based methods and exhibit emergent
effective communication. Though current Open LMs like LLAMA-2 still
underperform, we fine-tune a CoELA with data collected with our agents and show
how they can achieve promising performance. We also conducted a user study for
human-agent interaction and discovered that CoELA communicating in natural
language can earn more trust and cooperate more effectively with humans. Our
research underscores the potential of LLMs for future research in multi-agent
cooperation. Videos can be found on the project website
https://vis-www.cs.umass.edu/Co-LLM-Agents/.

---------------

### 05 Oct 2023 | [Balancing Autonomy and Alignment: A Multi-Dimensional Taxonomy for  Autonomous LLM-powered Multi-Agent Architectures](https://arxiv.org/abs/2310.03659) | [⬇️](https://arxiv.org/pdf/2310.03659)
*Thorsten H\"andler* 

  Large language models (LLMs) have revolutionized the field of artificial
intelligence, endowing it with sophisticated language understanding and
generation capabilities. However, when faced with more complex and
interconnected tasks that demand a profound and iterative thought process, LLMs
reveal their inherent limitations. Autonomous LLM-powered multi-agent systems
represent a strategic response to these challenges. Such systems strive for
autonomously tackling user-prompted goals by decomposing them into manageable
tasks and orchestrating their execution and result synthesis through a
collective of specialized intelligent agents. Equipped with LLM-powered
reasoning capabilities, these agents harness the cognitive synergy of
collaborating with their peers, enhanced by leveraging contextual resources
such as tools and datasets. While these architectures hold promising potential
in amplifying AI capabilities, striking the right balance between different
levels of autonomy and alignment remains the crucial challenge for their
effective operation. This paper proposes a comprehensive multi-dimensional
taxonomy, engineered to analyze how autonomous LLM-powered multi-agent systems
balance the dynamic interplay between autonomy and alignment across various
aspects inherent to architectural viewpoints such as goal-driven task
management, agent composition, multi-agent collaboration, and context
interaction. It also includes a domain-ontology model specifying fundamental
architectural concepts. Our taxonomy aims to empower researchers, engineers,
and AI practitioners to systematically analyze the architectural dynamics and
balancing strategies employed by these increasingly prevalent AI systems. The
exploratory taxonomic classification of selected representative LLM-powered
multi-agent systems illustrates its practical utility and reveals potential for
future research and development.

---------------

### 29 Feb 2024 | [Deciphering Digital Detectives: Understanding LLM Behaviors and  Capabilities in Multi-Agent Mystery Games](https://arxiv.org/abs/2312.00746) | [⬇️](https://arxiv.org/pdf/2312.00746)
*Dekun Wu, Haochen Shi, Zhiyuan Sun, Bang Liu* 

  In this study, we explore the application of Large Language Models (LLMs) in
\textit{Jubensha}, a Chinese detective role-playing game and a novel area in
Artificial Intelligence (AI) driven gaming. We introduce the first dataset
specifically for Jubensha, including character scripts and game rules, to
foster AI agent development in this complex narrative environment. Our work
also presents a unique multi-agent interaction framework using LLMs, allowing
AI agents to autonomously engage in this game. To evaluate the gaming
performance of these AI agents, we developed novel methods measuring their
mastery of case information and reasoning skills. Furthermore, we incorporated
the latest advancements in in-context learning to improve the agents'
performance in information gathering, murderer identification, and logical
reasoning. The experimental results validate the effectiveness of our proposed
methods. This work aims to offer a novel perspective on understanding LLM
capabilities and establish a new benchmark for evaluating large language
model-based agents.

---------------

### 29 Dec 2023 | [Cooperation on the Fly: Exploring Language Agents for Ad Hoc Teamwork in  the Avalon Game](https://arxiv.org/abs/2312.17515) | [⬇️](https://arxiv.org/pdf/2312.17515)
*Zijing Shi, Meng Fang, Shunfeng Zheng, Shilong Deng, Ling Chen, Yali  Du* 

  Multi-agent collaboration with Large Language Models (LLMs) demonstrates
proficiency in basic tasks, yet its efficiency in more complex scenarios
remains unexplored. In gaming environments, these agents often face situations
without established coordination protocols, requiring them to make intelligent
inferences about teammates from limited data. This problem motivates the area
of ad hoc teamwork, in which an agent may potentially cooperate with a variety
of teammates to achieve a shared goal. Our study focuses on the ad hoc teamwork
problem where the agent operates in an environment driven by natural language.
Our findings reveal the potential of LLM agents in team collaboration,
highlighting issues related to hallucinations in communication. To address this
issue, we develop CodeAct, a general agent that equips LLM with enhanced memory
and code-driven reasoning, enabling the repurposing of partial information for
rapid adaptation to new teammates.

---------------

### 06 Nov 2023 | [Leveraging Word Guessing Games to Assess the Intelligence of Large  Language Models](https://arxiv.org/abs/2310.20499) | [⬇️](https://arxiv.org/pdf/2310.20499)
*Tian Liang and Zhiwei He and Jen-tse Huang and Wenxuan Wang and  Wenxiang Jiao and Rui Wang and Yujiu Yang and Zhaopeng Tu and Shuming Shi and  Xing Wang* 

  The automatic evaluation of LLM-based agent intelligence is critical in
developing advanced LLM-based agents. Although considerable effort has been
devoted to developing human-annotated evaluation datasets, such as AlpacaEval,
existing techniques are costly, time-consuming, and lack adaptability. In this
paper, inspired by the popular language game ``Who is Spy'', we propose to use
the word guessing game to assess the intelligence performance of LLMs. Given a
word, the LLM is asked to describe the word and determine its identity (spy or
not) based on its and other players' descriptions. Ideally, an advanced agent
should possess the ability to accurately describe a given word using an
aggressive description while concurrently maximizing confusion in the
conservative description, enhancing its participation in the game. To this end,
we first develop DEEP to evaluate LLMs' expression and disguising abilities.
DEEP requires LLM to describe a word in aggressive and conservative modes. We
then introduce SpyGame, an interactive multi-agent framework designed to assess
LLMs' intelligence through participation in a competitive language-based board
game. Incorporating multi-agent interaction, SpyGame requires the target LLM to
possess linguistic skills and strategic thinking, providing a more
comprehensive evaluation of LLMs' human-like cognitive abilities and
adaptability in complex communication situations. The proposed evaluation
framework is very easy to implement. We collected words from multiple sources,
domains, and languages and used the proposed evaluation framework to conduct
experiments. Extensive experiments demonstrate that the proposed DEEP and
SpyGame effectively evaluate the capabilities of various LLMs, capturing their
ability to adapt to novel situations and engage in strategic communication.

---------------

### 19 Sep 2023 | [MindAgent: Emergent Gaming Interaction](https://arxiv.org/abs/2309.09971) | [⬇️](https://arxiv.org/pdf/2309.09971)
*Ran Gong, Qiuyuan Huang, Xiaojian Ma, Hoi Vo, Zane Durante, Yusuke  Noda, Zilong Zheng, Song-Chun Zhu, Demetri Terzopoulos, Li Fei-Fei, Jianfeng  Gao* 

  Large Language Models (LLMs) have the capacity of performing complex
scheduling in a multi-agent system and can coordinate these agents into
completing sophisticated tasks that require extensive collaboration. However,
despite the introduction of numerous gaming frameworks, the community has
insufficient benchmarks towards building general multi-agents collaboration
infrastructure that encompass both LLM and human-NPCs collaborations. In this
work, we propose a novel infrastructure - MindAgent - to evaluate planning and
coordination emergent capabilities for gaming interaction. In particular, our
infrastructure leverages existing gaming framework, to i) require understanding
of the coordinator for a multi-agent system, ii) collaborate with human players
via un-finetuned proper instructions, and iii) establish an in-context learning
on few-shot prompt with feedback. Furthermore, we introduce CUISINEWORLD, a new
gaming scenario and related benchmark that dispatch a multi-agent collaboration
efficiency and supervise multiple agents playing the game simultaneously. We
conduct comprehensive evaluations with new auto-metric CoS for calculating the
collaboration efficiency. Finally, our infrastructure can be deployed into
real-world gaming scenarios in a customized VR version of CUISINEWORLD and
adapted in existing broader Minecraft gaming domain. We hope our findings on
LLMs and the new infrastructure for general-purpose scheduling and coordination
can help shed light on how such skills can be obtained by learning from large
language corpora.

---------------

### 23 Feb 2024 | [On the Multi-turn Instruction Following for Conversational Web Agents](https://arxiv.org/abs/2402.15057) | [⬇️](https://arxiv.org/pdf/2402.15057)
*Yang Deng, Xuan Zhang, Wenxuan Zhang, Yifei Yuan, See-Kiong Ng,  Tat-Seng Chua* 

  Web agents powered by Large Language Models (LLMs) have demonstrated
remarkable abilities in planning and executing multi-step interactions within
complex web-based environments, fulfilling a wide range of web navigation
tasks. Despite these advancements, the potential for LLM-powered agents to
effectively engage with sequential user instructions in real-world scenarios
has not been fully explored. In this work, we introduce a new task of
Conversational Web Navigation, which necessitates sophisticated interactions
that span multiple turns with both the users and the environment, supported by
a specially developed dataset named Multi-Turn Mind2Web (MT-Mind2Web). To
tackle the limited context length of LLMs and the context-dependency issue of
the conversational tasks, we further propose a novel framework, named
self-reflective memory-augmented planning (Self-MAP), which employs memory
utilization and self-reflection techniques. Extensive experiments are conducted
to benchmark the MT-Mind2Web dataset, and validate the effectiveness of the
proposed method.

---------------

### 02 Feb 2024 | [A Multi-Agent Conversational Recommender System](https://arxiv.org/abs/2402.01135) | [⬇️](https://arxiv.org/pdf/2402.01135)
*Jiabao Fang, Shen Gao, Pengjie Ren, Xiuying Chen, Suzan Verberne,  Zhaochun Ren* 

  Due to strong capabilities in conducting fluent, multi-turn conversations
with users, Large Language Models (LLMs) have the potential to further improve
the performance of Conversational Recommender System (CRS). Unlike the aimless
chit-chat that LLM excels at, CRS has a clear target. So it is imperative to
control the dialogue flow in the LLM to successfully recommend appropriate
items to the users. Furthermore, user feedback in CRS can assist the system in
better modeling user preferences, which has been ignored by existing studies.
However, simply prompting LLM to conduct conversational recommendation cannot
address the above two key challenges.
  In this paper, we propose Multi-Agent Conversational Recommender System
(MACRS) which contains two essential modules. First, we design a multi-agent
act planning framework, which can control the dialogue flow based on four
LLM-based agents. This cooperative multi-agent framework will generate various
candidate responses based on different dialogue acts and then choose the most
appropriate response as the system response, which can help MACRS plan suitable
dialogue acts. Second, we propose a user feedback-aware reflection mechanism
which leverages user feedback to reason errors made in previous turns to adjust
the dialogue act planning, and higher-level user information from implicit
semantics. We conduct extensive experiments based on user simulator to
demonstrate the effectiveness of MACRS in recommendation and user preferences
collection. Experimental results illustrate that MACRS demonstrates an
improvement in user interaction experience compared to directly using LLMs.

---------------

### 23 Jan 2024 | [Controlling Large Language Model-based Agents for Large-Scale  Decision-Making: An Actor-Critic Approach](https://arxiv.org/abs/2311.13884) | [⬇️](https://arxiv.org/pdf/2311.13884)
*Bin Zhang, Hangyu Mao, Jingqing Ruan, Ying Wen, Yang Li, Shao Zhang,  Zhiwei Xu, Dapeng Li, Ziyue Li, Rui Zhao, Lijuan Li, Guoliang Fan* 

  The remarkable progress in Large Language Models (LLMs) opens up new avenues
for addressing planning and decision-making problems in Multi-Agent Systems
(MAS). However, as the number of agents increases, the issues of hallucination
in LLMs and coordination in MAS have become increasingly prominent.
Additionally, the efficient utilization of tokens emerges as a critical
consideration when employing LLMs to facilitate the interactions among a
substantial number of agents. In this paper, we develop a modular framework
called LLaMAC to mitigate these challenges. LLaMAC implements a value
distribution encoding similar to that found in the human brain, utilizing
internal and external feedback mechanisms to facilitate collaboration and
iterative reasoning among its modules. Through evaluations involving system
resource allocation and robot grid transportation, we demonstrate the
considerable advantages afforded by our proposed approach.

---------------

### 16 Jan 2024 | [MultiPLY: A Multisensory Object-Centric Embodied Large Language Model in  3D World](https://arxiv.org/abs/2401.08577) | [⬇️](https://arxiv.org/pdf/2401.08577)
*Yining Hong, Zishuo Zheng, Peihao Chen, Yian Wang, Junyan Li, Chuang  Gan* 

  Human beings possess the capability to multiply a melange of multisensory
cues while actively exploring and interacting with the 3D world. Current
multi-modal large language models, however, passively absorb sensory data as
inputs, lacking the capacity to actively interact with the objects in the 3D
environment and dynamically collect their multisensory information. To usher in
the study of this area, we propose MultiPLY, a multisensory embodied large
language model that could incorporate multisensory interactive data, including
visual, audio, tactile, and thermal information into large language models,
thereby establishing the correlation among words, actions, and percepts. To
this end, we first collect Multisensory Universe, a large-scale multisensory
interaction dataset comprising 500k data by deploying an LLM-powered embodied
agent to engage with the 3D environment. To perform instruction tuning with
pre-trained LLM on such generated data, we first encode the 3D scene as
abstracted object-centric representations and then introduce action tokens
denoting that the embodied agent takes certain actions within the environment,
as well as state tokens that represent the multisensory state observations of
the agent at each time step. In the inference time, MultiPLY could generate
action tokens, instructing the agent to take the action in the environment and
obtain the next multisensory state observation. The observation is then
appended back to the LLM via state tokens to generate subsequent text or action
tokens. We demonstrate that MultiPLY outperforms baselines by a large margin
through a diverse set of embodied tasks involving object retrieval, tool use,
multisensory captioning, and task decomposition.

---------------

### 21 Feb 2024 | [AgentScope: A Flexible yet Robust Multi-Agent Platform](https://arxiv.org/abs/2402.14034) | [⬇️](https://arxiv.org/pdf/2402.14034)
*Dawei Gao, Zitao Li, Weirui Kuang, Xuchen Pan, Daoyuan Chen, Zhijian  Ma, Bingchen Qian, Liuyi Yao, Lin Zhu, Chen Cheng, Hongzhu Shi, Yaliang Li,  Bolin Ding, Jingren Zhou* 

  With the rapid advancement of Large Language Models (LLMs), significant
progress has been made in multi-agent applications. However, the complexities
in coordinating agents' cooperation and LLMs' erratic performance pose notable
challenges in developing robust and efficient multi-agent applications. To
tackle these challenges, we propose AgentScope, a developer-centric multi-agent
platform with message exchange as its core communication mechanism. Together
with abundant syntactic tools, built-in resources, and user-friendly
interactions, our communication mechanism significantly reduces the barriers to
both development and understanding. Towards robust and flexible multi-agent
application, AgentScope provides both built-in and customizable fault tolerance
mechanisms while it is also armed with system-level supports for multi-modal
data generation, storage and transmission. Additionally, we design an
actor-based distribution framework, enabling easy conversion between local and
distributed deployments and automatic parallel optimization without extra
effort. With these features, AgentScope empowers developers to build
applications that fully realize the potential of intelligent agents. We have
released AgentScope at https://github.com/modelscope/agentscope, and hope
AgentScope invites wider participation and innovation in this fast-moving
field.

---------------

### 31 Oct 2023 | [Multi-Agent Consensus Seeking via Large Language Models](https://arxiv.org/abs/2310.20151) | [⬇️](https://arxiv.org/pdf/2310.20151)
*Huaben Chen, Wenkang Ji, Lufeng Xu, Shiyu Zhao* 

  Multi-agent systems driven by large language models (LLMs) have shown
promising abilities for solving complex tasks in a collaborative manner. This
work considers a fundamental problem in multi-agent collaboration: consensus
seeking. When multiple agents work together, we are interested in how they can
reach a consensus through inter-agent negotiation. To that end, this work
studies a consensus-seeking task where the state of each agent is a numerical
value and they negotiate with each other to reach a consensus value. It is
revealed that when not explicitly directed on which strategy should be adopted,
the LLM-driven agents primarily use the average strategy for consensus seeking
although they may occasionally use some other strategies. Moreover, this work
analyzes the impact of the agent number, agent personality, and network
topology on the negotiation process. The findings reported in this work can
potentially lay the foundations for understanding the behaviors of LLM-driven
multi-agent systems for solving more complex tasks. Furthermore, LLM-driven
consensus seeking is applied to a multi-robot aggregation task. This
application demonstrates the potential of LLM-driven agents to achieve
zero-shot autonomous planning for multi-robot collaboration tasks. Project
website: westlakeintelligentrobotics.github.io/ConsensusLLM/.

---------------

### 03 Feb 2024 | [A Survey on Context-Aware Multi-Agent Systems: Techniques, Challenges  and Future Directions](https://arxiv.org/abs/2402.01968) | [⬇️](https://arxiv.org/pdf/2402.01968)
*Hung Du, Srikanth Thudumu, Rajesh Vasa and Kon Mouzakis* 

  Research interest in autonomous agents is on the rise as an emerging topic.
The notable achievements of Large Language Models (LLMs) have demonstrated the
considerable potential to attain human-like intelligence in autonomous agents.
However, the challenge lies in enabling these agents to learn, reason, and
navigate uncertainties in dynamic environments. Context awareness emerges as a
pivotal element in fortifying multi-agent systems when dealing with dynamic
situations. Despite existing research focusing on both context-aware systems
and multi-agent systems, there is a lack of comprehensive surveys outlining
techniques for integrating context-aware systems with multi-agent systems. To
address this gap, this survey provides a comprehensive overview of
state-of-the-art context-aware multi-agent systems. First, we outline the
properties of both context-aware systems and multi-agent systems that
facilitate integration between these systems. Subsequently, we propose a
general process for context-aware systems, with each phase of the process
encompassing diverse approaches drawn from various application domains such as
collision avoidance in autonomous driving, disaster relief management, utility
management, supply chain management, human-AI interaction, and others. Finally,
we discuss the existing challenges of context-aware multi-agent systems and
provide future research directions in this field.

---------------

### 16 Feb 2024 | [When Large Language Model Agents Meet 6G Networks: Perception,  Grounding, and Alignment](https://arxiv.org/abs/2401.07764) | [⬇️](https://arxiv.org/pdf/2401.07764)
*Minrui Xu, Dusit Niyato, Jiawen Kang, Zehui Xiong, Shiwen Mao, Zhu  Han, Dong In Kim, and Khaled B. Letaief* 

  AI agents based on multimodal large language models (LLMs) are expected to
revolutionize human-computer interaction and offer more personalized assistant
services across various domains like healthcare, education, manufacturing, and
entertainment. Deploying LLM agents in 6G networks enables users to access
previously expensive AI assistant services via mobile devices democratically,
thereby reducing interaction latency and better preserving user privacy.
Nevertheless, the limited capacity of mobile devices constrains the
effectiveness of deploying and executing local LLMs, which necessitates
offloading complex tasks to global LLMs running on edge servers during
long-horizon interactions. In this article, we propose a split learning system
for LLM agents in 6G networks leveraging the collaboration between mobile
devices and edge servers, where multiple LLMs with different roles are
distributed across mobile devices and edge servers to perform user-agent
interactive tasks collaboratively. In the proposed system, LLM agents are split
into perception, grounding, and alignment modules, facilitating inter-module
communications to meet extended user requirements on 6G network functions,
including integrated sensing and communication, digital twins, and
task-oriented communications. Furthermore, we introduce a novel model caching
algorithm for LLMs within the proposed system to improve model utilization in
context, thus reducing network costs of the collaborative mobile and edge LLM
agents.

---------------
**Date:** 02 Feb 2024

**Title:** MAGDi: Structured Distillation of Multi-Agent Interaction Graphs  Improves Reasoning in Smaller Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.01620](https://arxiv.org/abs/2402.01620)

**PDF Link:** [https://arxiv.org/pdf/2402.01620](https://arxiv.org/pdf/2402.01620)

---

**Date:** 05 Mar 2024

**Title:** AntEval: Evaluation of Social Interaction Competencies in LLM-Driven  Agents

**Abstract Link:** [https://arxiv.org/abs/2401.06509](https://arxiv.org/abs/2401.06509)

**PDF Link:** [https://arxiv.org/pdf/2401.06509](https://arxiv.org/pdf/2401.06509)

---

**Date:** 28 Aug 2023

**Title:** CGMI: Configurable General Multi-Agent Interaction Framework

**Abstract Link:** [https://arxiv.org/abs/2308.12503](https://arxiv.org/abs/2308.12503)

**PDF Link:** [https://arxiv.org/pdf/2308.12503](https://arxiv.org/pdf/2308.12503)

---

**Date:** 19 Jan 2024

**Title:** SocraSynth: Multi-LLM Reasoning with Conditional Statistics

**Abstract Link:** [https://arxiv.org/abs/2402.06634](https://arxiv.org/abs/2402.06634)

**PDF Link:** [https://arxiv.org/pdf/2402.06634](https://arxiv.org/pdf/2402.06634)

---

**Date:** 28 Feb 2024

**Title:** Rethinking the Bounds of LLM Reasoning: Are Multi-Agent Discussions the  Key?

**Abstract Link:** [https://arxiv.org/abs/2402.18272](https://arxiv.org/abs/2402.18272)

**PDF Link:** [https://arxiv.org/pdf/2402.18272](https://arxiv.org/pdf/2402.18272)

---

**Date:** 26 Feb 2024

**Title:** LLMArena: Assessing Capabilities of Large Language Models in Dynamic  Multi-Agent Environments

**Abstract Link:** [https://arxiv.org/abs/2402.16499](https://arxiv.org/abs/2402.16499)

**PDF Link:** [https://arxiv.org/pdf/2402.16499](https://arxiv.org/pdf/2402.16499)

---

**Date:** 17 Feb 2024

**Title:** Building Cooperative Embodied Agents Modularly with Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2307.02485](https://arxiv.org/abs/2307.02485)

**PDF Link:** [https://arxiv.org/pdf/2307.02485](https://arxiv.org/pdf/2307.02485)

---

**Date:** 05 Oct 2023

**Title:** Balancing Autonomy and Alignment: A Multi-Dimensional Taxonomy for  Autonomous LLM-powered Multi-Agent Architectures

**Abstract Link:** [https://arxiv.org/abs/2310.03659](https://arxiv.org/abs/2310.03659)

**PDF Link:** [https://arxiv.org/pdf/2310.03659](https://arxiv.org/pdf/2310.03659)

---

**Date:** 29 Feb 2024

**Title:** Deciphering Digital Detectives: Understanding LLM Behaviors and  Capabilities in Multi-Agent Mystery Games

**Abstract Link:** [https://arxiv.org/abs/2312.00746](https://arxiv.org/abs/2312.00746)

**PDF Link:** [https://arxiv.org/pdf/2312.00746](https://arxiv.org/pdf/2312.00746)

---

**Date:** 29 Dec 2023

**Title:** Cooperation on the Fly: Exploring Language Agents for Ad Hoc Teamwork in  the Avalon Game

**Abstract Link:** [https://arxiv.org/abs/2312.17515](https://arxiv.org/abs/2312.17515)

**PDF Link:** [https://arxiv.org/pdf/2312.17515](https://arxiv.org/pdf/2312.17515)

---

**Date:** 06 Nov 2023

**Title:** Leveraging Word Guessing Games to Assess the Intelligence of Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.20499](https://arxiv.org/abs/2310.20499)

**PDF Link:** [https://arxiv.org/pdf/2310.20499](https://arxiv.org/pdf/2310.20499)

---

**Date:** 19 Sep 2023

**Title:** MindAgent: Emergent Gaming Interaction

**Abstract Link:** [https://arxiv.org/abs/2309.09971](https://arxiv.org/abs/2309.09971)

**PDF Link:** [https://arxiv.org/pdf/2309.09971](https://arxiv.org/pdf/2309.09971)

---

**Date:** 23 Feb 2024

**Title:** On the Multi-turn Instruction Following for Conversational Web Agents

**Abstract Link:** [https://arxiv.org/abs/2402.15057](https://arxiv.org/abs/2402.15057)

**PDF Link:** [https://arxiv.org/pdf/2402.15057](https://arxiv.org/pdf/2402.15057)

---

**Date:** 02 Feb 2024

**Title:** A Multi-Agent Conversational Recommender System

**Abstract Link:** [https://arxiv.org/abs/2402.01135](https://arxiv.org/abs/2402.01135)

**PDF Link:** [https://arxiv.org/pdf/2402.01135](https://arxiv.org/pdf/2402.01135)

---

**Date:** 23 Jan 2024

**Title:** Controlling Large Language Model-based Agents for Large-Scale  Decision-Making: An Actor-Critic Approach

**Abstract Link:** [https://arxiv.org/abs/2311.13884](https://arxiv.org/abs/2311.13884)

**PDF Link:** [https://arxiv.org/pdf/2311.13884](https://arxiv.org/pdf/2311.13884)

---

**Date:** 16 Jan 2024

**Title:** MultiPLY: A Multisensory Object-Centric Embodied Large Language Model in  3D World

**Abstract Link:** [https://arxiv.org/abs/2401.08577](https://arxiv.org/abs/2401.08577)

**PDF Link:** [https://arxiv.org/pdf/2401.08577](https://arxiv.org/pdf/2401.08577)

---

**Date:** 21 Feb 2024

**Title:** AgentScope: A Flexible yet Robust Multi-Agent Platform

**Abstract Link:** [https://arxiv.org/abs/2402.14034](https://arxiv.org/abs/2402.14034)

**PDF Link:** [https://arxiv.org/pdf/2402.14034](https://arxiv.org/pdf/2402.14034)

---

**Date:** 31 Oct 2023

**Title:** Multi-Agent Consensus Seeking via Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.20151](https://arxiv.org/abs/2310.20151)

**PDF Link:** [https://arxiv.org/pdf/2310.20151](https://arxiv.org/pdf/2310.20151)

---

**Date:** 03 Feb 2024

**Title:** A Survey on Context-Aware Multi-Agent Systems: Techniques, Challenges  and Future Directions

**Abstract Link:** [https://arxiv.org/abs/2402.01968](https://arxiv.org/abs/2402.01968)

**PDF Link:** [https://arxiv.org/pdf/2402.01968](https://arxiv.org/pdf/2402.01968)

---

**Date:** 16 Feb 2024

**Title:** When Large Language Model Agents Meet 6G Networks: Perception,  Grounding, and Alignment

**Abstract Link:** [https://arxiv.org/abs/2401.07764](https://arxiv.org/abs/2401.07764)

**PDF Link:** [https://arxiv.org/pdf/2401.07764](https://arxiv.org/pdf/2401.07764)

---

