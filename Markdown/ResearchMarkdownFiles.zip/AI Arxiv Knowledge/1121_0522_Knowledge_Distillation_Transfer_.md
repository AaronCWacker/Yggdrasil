Knowledge Distillation Transfer 📖

### 🔎 Knowledge Distillation Transfer 📖



# Knowledge Distillation Transfer

Knowledge Distillation Transfer (KD-T) is a method to transfer the knowledge from a large model to a smaller model. The idea is to train a smaller model to mimic the behavior of a larger model. This is done by training the smaller model to predict the same outputs as the larger model for a given input. The smaller model is then fine-tuned on a smaller dataset to further improve its performance.

KD-T can be used to improve the performance of a smaller model by leveraging the knowledge learned by a larger model. This is especially useful when the smaller model has limited capacity and cannot learn all the features present in the data. By using KD-T, the smaller model can learn to predict the same outputs as the larger model, which can lead to better performance.

KD-T can also be used to reduce the computational cost of deploying a large model. By training a smaller model to mimic the behavior of a larger model, the smaller model can be used instead of the larger model for inference. This can lead to significant savings in computational resources, especially when deploying the model on resource-constrained devices.

KD-T is a simple yet effective method for transferring knowledge from a large model to a smaller model. It has been shown to be effective in a variety of tasks, including image classification, object detection, and natural language processing. By using KD-T, researchers and practitioners can build smaller and more efficient models that can achieve similar or better performance than larger models.</s>
# 🩺🔍 Search Results
### 27 Feb 2023 | [Feature Structure Distillation with Centered Kernel Alignment in BERT  Transferring](https://arxiv.org/abs/2204.08922) | [⬇️](https://arxiv.org/pdf/2204.08922)
*Hee-Jun Jung, Doyeon Kim, Seung-Hoon Na, Kangil Kim* 

  Knowledge distillation is an approach to transfer information on
representations from a teacher to a student by reducing their difference. A
challenge of this approach is to reduce the flexibility of the student's
representations inducing inaccurate learning of the teacher's knowledge. To
resolve it in transferring, we investigate distillation of structures of
representations specified to three types: intra-feature, local inter-feature,
global inter-feature structures. To transfer them, we introduce feature
structure distillation methods based on the Centered Kernel Alignment, which
assigns a consistent value to similar features structures and reveals more
informative relations. In particular, a memory-augmented transfer method with
clustering is implemented for the global structures. The methods are
empirically analyzed on the nine tasks for language understanding of the GLUE
dataset with Bidirectional Encoder Representations from Transformers (BERT),
which is a representative neural language model. In the results, the proposed
methods effectively transfer the three types of structures and improve
performance compared to state-of-the-art distillation methods. Indeed, the code
for the methods is available in https://github.com/maroo-sky/FSD.

---------------

### 02 Jun 2020 | [Channel Distillation: Channel-Wise Attention for Knowledge Distillation](https://arxiv.org/abs/2006.01683) | [⬇️](https://arxiv.org/pdf/2006.01683)
*Zaida Zhou, Chaoran Zhuge, Xinwei Guan, Wen Liu* 

  Knowledge distillation is to transfer the knowledge from the data learned by
the teacher network to the student network, so that the student has the
advantage of less parameters and less calculations, and the accuracy is close
to the teacher. In this paper, we propose a new distillation method, which
contains two transfer distillation strategies and a loss decay strategy. The
first transfer strategy is based on channel-wise attention, called Channel
Distillation (CD). CD transfers the channel information from the teacher to the
student. The second is Guided Knowledge Distillation (GKD). Unlike Knowledge
Distillation (KD), which allows the student to mimic each sample's prediction
distribution of the teacher, GKD only enables the student to mimic the correct
output of the teacher. The last part is Early Decay Teacher (EDT). During the
training process, we gradually decay the weight of the distillation loss. The
purpose is to enable the student to gradually control the optimization rather
than the teacher. Our proposed method is evaluated on ImageNet and CIFAR100. On
ImageNet, we achieve 27.68% of top-1 error with ResNet18, which outperforms
state-of-the-art methods. On CIFAR100, we achieve surprising result that the
student outperforms the teacher. Code is available at
https://github.com/zhouzaida/channel-distillation.

---------------

### 18 Oct 2022 | [On effects of Knowledge Distillation on Transfer Learning](https://arxiv.org/abs/2210.09668) | [⬇️](https://arxiv.org/pdf/2210.09668)
*Sushil Thapa* 

  Knowledge distillation is a popular machine learning technique that aims to
transfer knowledge from a large 'teacher' network to a smaller 'student'
network and improve the student's performance by training it to emulate the
teacher. In recent years, there has been significant progress in novel
distillation techniques that push performance frontiers across multiple
problems and benchmarks. Most of the reported work focuses on achieving
state-of-the-art results on the specific problem. However, there has been a
significant gap in understanding the process and how it behaves under certain
training scenarios. Similarly, transfer learning (TL) is an effective technique
in training neural networks on a limited dataset faster by reusing
representations learned from a different but related problem. Despite its
effectiveness and popularity, there has not been much exploration of knowledge
distillation on transfer learning. In this thesis, we propose a machine
learning architecture we call TL+KD that combines knowledge distillation with
transfer learning; we then present a quantitative and qualitative comparison of
TL+KD with TL in the domain of image classification. Through this work, we show
that using guidance and knowledge from a larger teacher network during
fine-tuning, we can improve the student network to achieve better validation
performances like accuracy. We characterize the improvement in the validation
performance of the model using a variety of metrics beyond just accuracy
scores, and study its performance in scenarios such as input degradation.

---------------

### 19 Oct 2020 | [Locally Linear Region Knowledge Distillation](https://arxiv.org/abs/2010.04812) | [⬇️](https://arxiv.org/pdf/2010.04812)
*Xiang Deng and Zhongfei (Mark) Zhang* 

  Knowledge distillation (KD) is an effective technique to transfer knowledge
from one neural network (teacher) to another (student), thus improving the
performance of the student. To make the student better mimic the behavior of
the teacher, the existing work focuses on designing different criteria to align
their logits or representations. Different from these efforts, we address
knowledge distillation from a novel data perspective. We argue that
transferring knowledge at sparse training data points cannot enable the student
to well capture the local shape of the teacher function. To address this issue,
we propose locally linear region knowledge distillation ($\rm L^2$RKD) which
transfers the knowledge in local, linear regions from a teacher to a student.
This is achieved by enforcing the student to mimic the outputs of the teacher
function in local, linear regions. To the end, the student is able to better
capture the local shape of the teacher function and thus achieves a better
performance. Despite its simplicity, extensive experiments demonstrate that
$\rm L^2$RKD is superior to the original KD in many aspects as it outperforms
KD and the other state-of-the-art approaches by a large margin, shows
robustness and superiority under few-shot settings, and is more compatible with
the existing distillation approaches to further improve their performances
significantly.

---------------

### 18 Mar 2021 | [Similarity Transfer for Knowledge Distillation](https://arxiv.org/abs/2103.10047) | [⬇️](https://arxiv.org/pdf/2103.10047)
*Haoran Zhao, Kun Gong, Xin Sun, Junyu Dong and Hui Yu* 

  Knowledge distillation is a popular paradigm for learning portable neural
networks by transferring the knowledge from a large model into a smaller one.
Most existing approaches enhance the student model by utilizing the similarity
information between the categories of instance level provided by the teacher
model. However, these works ignore the similarity correlation between different
instances that plays an important role in confidence prediction. To tackle this
issue, we propose a novel method in this paper, called similarity transfer for
knowledge distillation (STKD), which aims to fully utilize the similarities
between categories of multiple samples. Furthermore, we propose to better
capture the similarity correlation between different instances by the mixup
technique, which creates virtual samples by a weighted linear interpolation.
Note that, our distillation loss can fully utilize the incorrect classes
similarities by the mixed labels. The proposed approach promotes the
performance of student model as the virtual sample created by multiple images
produces a similar probability distribution in the teacher and student
networks. Experiments and ablation studies on several public classification
datasets including CIFAR-10,CIFAR-100,CINIC-10 and Tiny-ImageNet verify that
this light-weight method can effectively boost the performance of the compact
student model. It shows that STKD substantially has outperformed the vanilla
knowledge distillation and has achieved superior accuracy over the
state-of-the-art knowledge distillation methods.

---------------

### 02 Nov 2022 | [Gradient Knowledge Distillation for Pre-trained Language Models](https://arxiv.org/abs/2211.01071) | [⬇️](https://arxiv.org/pdf/2211.01071)
*Lean Wang, Lei Li, Xu Sun* 

  Knowledge distillation (KD) is an effective framework to transfer knowledge
from a large-scale teacher to a compact yet well-performing student. Previous
KD practices for pre-trained language models mainly transfer knowledge by
aligning instance-wise outputs between the teacher and student, while
neglecting an important knowledge source, i.e., the gradient of the teacher.
The gradient characterizes how the teacher responds to changes in inputs, which
we assume is beneficial for the student to better approximate the underlying
mapping function of the teacher. Therefore, we propose Gradient Knowledge
Distillation (GKD) to incorporate the gradient alignment objective into the
distillation process. Experimental results show that GKD outperforms previous
KD methods regarding student performance. Further analysis shows that
incorporating gradient knowledge makes the student behave more consistently
with the teacher, improving the interpretability greatly.

---------------

### 25 May 2023 | [HARD: Hard Augmentations for Robust Distillation](https://arxiv.org/abs/2305.14890) | [⬇️](https://arxiv.org/pdf/2305.14890)
*Arne F. Nix, Max F. Burg, Fabian H. Sinz* 

  Knowledge distillation (KD) is a simple and successful method to transfer
knowledge from a teacher to a student model solely based on functional
activity. However, current KD has a few shortcomings: it has recently been
shown that this method is unsuitable to transfer simple inductive biases like
shift equivariance, struggles to transfer out of domain generalization, and
optimization time is magnitudes longer compared to default non-KD model
training. To improve these aspects of KD, we propose Hard Augmentations for
Robust Distillation (HARD), a generally applicable data augmentation framework,
that generates synthetic data points for which the teacher and the student
disagree. We show in a simple toy example that our augmentation framework
solves the problem of transferring simple equivariances with KD. We then apply
our framework in real-world tasks for a variety of augmentation models, ranging
from simple spatial transformations to unconstrained image manipulations with a
pretrained variational autoencoder. We find that our learned augmentations
significantly improve KD performance on in-domain and out-of-domain evaluation.
Moreover, our method outperforms even state-of-the-art data augmentations and
since the augmented training inputs can be visualized, they offer a qualitative
insight into the properties that are transferred from the teacher to the
student. Thus HARD represents a generally applicable, dynamically optimized
data augmentation technique tailored to improve the generalization and
convergence speed of models trained with KD.

---------------

### 31 Dec 2020 | [Towards Zero-Shot Knowledge Distillation for Natural Language Processing](https://arxiv.org/abs/2012.15495) | [⬇️](https://arxiv.org/pdf/2012.15495)
*Ahmad Rashid, Vasileios Lioutas, Abbas Ghaddar and Mehdi  Rezagholizadeh* 

  Knowledge Distillation (KD) is a common knowledge transfer algorithm used for
model compression across a variety of deep learning based natural language
processing (NLP) solutions. In its regular manifestations, KD requires access
to the teacher's training data for knowledge transfer to the student network.
However, privacy concerns, data regulations and proprietary reasons may prevent
access to such data. We present, to the best of our knowledge, the first work
on Zero-Shot Knowledge Distillation for NLP, where the student learns from the
much larger teacher without any task specific data. Our solution combines out
of domain data and adversarial training to learn the teacher's output
distribution. We investigate six tasks from the GLUE benchmark and demonstrate
that we can achieve between 75% and 92% of the teacher's classification score
(accuracy or F1) while compressing the model 30 times.

---------------

### 18 Nov 2020 | [Effectiveness of Arbitrary Transfer Sets for Data-free Knowledge  Distillation](https://arxiv.org/abs/2011.09113) | [⬇️](https://arxiv.org/pdf/2011.09113)
*Gaurav Kumar Nayak, Konda Reddy Mopuri, Anirban Chakraborty* 

  Knowledge Distillation is an effective method to transfer the learning across
deep neural networks. Typically, the dataset originally used for training the
Teacher model is chosen as the "Transfer Set" to conduct the knowledge transfer
to the Student. However, this original training data may not always be freely
available due to privacy or sensitivity concerns. In such scenarios, existing
approaches either iteratively compose a synthetic set representative of the
original training dataset, one sample at a time or learn a generative model to
compose such a transfer set. However, both these approaches involve complex
optimization (GAN training or several backpropagation steps to synthesize one
sample) and are often computationally expensive. In this paper, as a simple
alternative, we investigate the effectiveness of "arbitrary transfer sets" such
as random noise, publicly available synthetic, and natural datasets, all of
which are completely unrelated to the original training dataset in terms of
their visual or semantic contents. Through extensive experiments on multiple
benchmark datasets such as MNIST, FMNIST, CIFAR-10 and CIFAR-100, we discover
and validate surprising effectiveness of using arbitrary data to conduct
knowledge distillation when this dataset is "target-class balanced". We believe
that this important observation can potentially lead to designing baselines for
the data-free knowledge distillation task.

---------------

### 23 Nov 2021 | [Semi-Online Knowledge Distillation](https://arxiv.org/abs/2111.11747) | [⬇️](https://arxiv.org/pdf/2111.11747)
*Zhiqiang Liu, Yanxia Liu, Chengkai Huang* 

  Knowledge distillation is an effective and stable method for model
compression via knowledge transfer. Conventional knowledge distillation (KD) is
to transfer knowledge from a large and well pre-trained teacher network to a
small student network, which is a one-way process. Recently, deep mutual
learning (DML) has been proposed to help student networks learn collaboratively
and simultaneously. However, to the best of our knowledge, KD and DML have
never been jointly explored in a unified framework to solve the knowledge
distillation problem. In this paper, we investigate that the teacher model
supports more trustworthy supervision signals in KD, while the student captures
more similar behaviors from the teacher in DML. Based on these observations, we
first propose to combine KD with DML in a unified framework. Furthermore, we
propose a Semi-Online Knowledge Distillation (SOKD) method that effectively
improves the performance of the student and the teacher. In this method, we
introduce the peer-teaching training fashion in DML in order to alleviate the
student's imitation difficulty, and also leverage the supervision signals
provided by the well-trained teacher in KD. Besides, we also show our framework
can be easily extended to feature-based distillation methods. Extensive
experiments on CIFAR-100 and ImageNet datasets demonstrate the proposed method
achieves state-of-the-art performance.

---------------

### 01 Sep 2020 | [Classification of Diabetic Retinopathy Using Unlabeled Data and  Knowledge Distillation](https://arxiv.org/abs/2009.00982) | [⬇️](https://arxiv.org/pdf/2009.00982)
*Sajjad Abbasi, Mohsen Hajabdollahi, Pejman Khadivi, Nader Karimi,  Roshanak Roshandel, Shahram Shirani, Shadrokh Samavi* 

  Knowledge distillation allows transferring knowledge from a pre-trained model
to another. However, it suffers from limitations, and constraints related to
the two models need to be architecturally similar. Knowledge distillation
addresses some of the shortcomings associated with transfer learning by
generalizing a complex model to a lighter model. However, some parts of the
knowledge may not be distilled by knowledge distillation sufficiently. In this
paper, a novel knowledge distillation approach using transfer learning is
proposed. The proposed method transfers the entire knowledge of a model to a
new smaller one. To accomplish this, unlabeled data are used in an unsupervised
manner to transfer the maximum amount of knowledge to the new slimmer model.
The proposed method can be beneficial in medical image analysis, where labeled
data are typically scarce. The proposed approach is evaluated in the context of
classification of images for diagnosing Diabetic Retinopathy on two publicly
available datasets, including Messidor and EyePACS. Simulation results
demonstrate that the approach is effective in transferring knowledge from a
complex model to a lighter one. Furthermore, experimental results illustrate
that the performance of different small models is improved significantly using
unlabeled data and knowledge distillation.

---------------

### 18 Mar 2022 | [A Closer Look at Knowledge Distillation with Features, Logits, and  Gradients](https://arxiv.org/abs/2203.10163) | [⬇️](https://arxiv.org/pdf/2203.10163)
*Yen-Chang Hsu, James Smith, Yilin Shen, Zsolt Kira, Hongxia Jin* 

  Knowledge distillation (KD) is a substantial strategy for transferring
learned knowledge from one neural network model to another. A vast number of
methods have been developed for this strategy. While most method designs a more
efficient way to facilitate knowledge transfer, less attention has been put on
comparing the effect of knowledge sources such as features, logits, and
gradients. This work provides a new perspective to motivate a set of knowledge
distillation strategies by approximating the classical KL-divergence criteria
with different knowledge sources, making a systematic comparison possible in
model compression and incremental learning. Our analysis indicates that logits
are generally a more efficient knowledge source and suggests that having
sufficient feature dimensions is crucial for the model design, providing a
practical guideline for effective KD-based transfer learning.

---------------

### 25 Mar 2021 | [A New Training Framework for Deep Neural Network](https://arxiv.org/abs/2103.07350) | [⬇️](https://arxiv.org/pdf/2103.07350)
*Zhenyan Hou, Wenxuan Fan* 

  Knowledge distillation is the process of transferring the knowledge from a
large model to a small model. In this process, the small model learns the
generalization ability of the large model and retains the performance close to
that of the large model. Knowledge distillation provides a training means to
migrate the knowledge of models, facilitating model deployment and speeding up
inference. However, previous distillation methods require pre-trained teacher
models, which still bring computational and storage overheads. In this paper, a
novel general training framework called Self Distillation (SD) is proposed. We
demonstrate the effectiveness of our method by enumerating its performance
improvements in diverse tasks and benchmark datasets.

---------------

### 10 Apr 2023 | [A Survey on Recent Teacher-student Learning Studies](https://arxiv.org/abs/2304.04615) | [⬇️](https://arxiv.org/pdf/2304.04615)
*Minghong Gao* 

  Knowledge distillation is a method of transferring the knowledge from a
complex deep neural network (DNN) to a smaller and faster DNN, while preserving
its accuracy. Recent variants of knowledge distillation include teaching
assistant distillation, curriculum distillation, mask distillation, and
decoupling distillation, which aim to improve the performance of knowledge
distillation by introducing additional components or by changing the learning
process. Teaching assistant distillation involves an intermediate model called
the teaching assistant, while curriculum distillation follows a curriculum
similar to human education. Mask distillation focuses on transferring the
attention mechanism learned by the teacher, and decoupling distillation
decouples the distillation loss from the task loss. Overall, these variants of
knowledge distillation have shown promising results in improving the
performance of knowledge distillation.

---------------

### 02 Feb 2024 | [Cooperative Knowledge Distillation: A Learner Agnostic Approach](https://arxiv.org/abs/2402.05942) | [⬇️](https://arxiv.org/pdf/2402.05942)
*Michael Livanos, Ian Davidson, Stephen Wong* 

  Knowledge distillation is a simple but powerful way to transfer knowledge
between a teacher model to a student model. Existing work suffers from at least
one of the following key limitations in terms of direction and scope of
transfer which restrict its use: all knowledge is transferred from teacher to
student regardless of whether or not that knowledge is useful, the student is
the only one learning in this exchange, and typically distillation transfers
knowledge only from a single teacher to a single student. We formulate a novel
form of knowledge distillation in which many models can act as both students
and teachers which we call cooperative distillation. The models cooperate as
follows: a model (the student) identifies specific deficiencies in it's
performance and searches for another model (the teacher) who encodes learned
knowledge into instructional virtual instances via counterfactual instance
generation. Because different models may have different strengths and
weaknesses, all models can act as either students or teachers (cooperation)
when appropriate and only distill knowledge in areas specific to their
strengths (focus). Since counterfactuals as a paradigm are not tied to any
specific algorithm, we can use this method to distill knowledge between
learners of different architectures, algorithms, and even feature spaces. We
demonstrate that our approach not only outperforms baselines such as transfer
learning, self-supervised learning, and multiple knowledge distillation
algorithms on several datasets, but it can also be used in settings where the
aforementioned techniques cannot.

---------------

### 27 Oct 2021 | [Beyond Classification: Knowledge Distillation using Multi-Object  Impressions](https://arxiv.org/abs/2110.14215) | [⬇️](https://arxiv.org/pdf/2110.14215)
*Gaurav Kumar Nayak, Monish Keswani, Sharan Seshadri, Anirban  Chakraborty* 

  Knowledge Distillation (KD) utilizes training data as a transfer set to
transfer knowledge from a complex network (Teacher) to a smaller network
(Student). Several works have recently identified many scenarios where the
training data may not be available due to data privacy or sensitivity concerns
and have proposed solutions under this restrictive constraint for the
classification task. Unlike existing works, we, for the first time, solve a
much more challenging problem, i.e., "KD for object detection with zero
knowledge about the training data and its statistics". Our proposed approach
prepares pseudo-targets and synthesizes corresponding samples (termed as
"Multi-Object Impressions"), using only the pretrained Faster RCNN Teacher
network. We use this pseudo-dataset as a transfer set to conduct zero-shot KD
for object detection. We demonstrate the efficacy of our proposed method
through several ablations and extensive experiments on benchmark datasets like
KITTI, Pascal and COCO. Our approach with no training samples, achieves a
respectable mAP of 64.2% and 55.5% on the student with same and half capacity
while performing distillation from a Resnet-18 Teacher of 73.3% mAP on KITTI.

---------------

### 17 Nov 2022 | [CoupleFace: Relation Matters for Face Recognition Distillation](https://arxiv.org/abs/2204.05502) | [⬇️](https://arxiv.org/pdf/2204.05502)
*Jiaheng Liu, Haoyu Qin, Yichao Wu, Jinyang Guo, Ding Liang, Ke Xu* 

  Knowledge distillation is an effective method to improve the performance of a
lightweight neural network (i.e., student model) by transferring the knowledge
of a well-performed neural network (i.e., teacher model), which has been widely
applied in many computer vision tasks, including face recognition.
Nevertheless, the current face recognition distillation methods usually utilize
the Feature Consistency Distillation (FCD) (e.g., L2 distance) on the learned
embeddings extracted by the teacher and student models for each sample, which
is not able to fully transfer the knowledge from the teacher to the student for
face recognition. In this work, we observe that mutual relation knowledge
between samples is also important to improve the discriminative ability of the
learned representation of the student model, and propose an effective face
recognition distillation method called CoupleFace by additionally introducing
the Mutual Relation Distillation (MRD) into existing distillation framework.
Specifically, in MRD, we first propose to mine the informative mutual
relations, and then introduce the Relation-Aware Distillation (RAD) loss to
transfer the mutual relation knowledge of the teacher model to the student
model. Extensive experimental results on multiple benchmark datasets
demonstrate the effectiveness of our proposed CoupleFace for face recognition.
Moreover, based on our proposed CoupleFace, we have won the first place in the
ICCV21 Masked Face Recognition Challenge (MS1M track).

---------------

### 10 Apr 2021 | [Data-Free Knowledge Distillation with Soft Targeted Transfer Set  Synthesis](https://arxiv.org/abs/2104.04868) | [⬇️](https://arxiv.org/pdf/2104.04868)
*Zi Wang* 

  Knowledge distillation (KD) has proved to be an effective approach for deep
neural network compression, which learns a compact network (student) by
transferring the knowledge from a pre-trained, over-parameterized network
(teacher). In traditional KD, the transferred knowledge is usually obtained by
feeding training samples to the teacher network to obtain the class
probabilities. However, the original training dataset is not always available
due to storage costs or privacy issues. In this study, we propose a novel
data-free KD approach by modeling the intermediate feature space of the teacher
with a multivariate normal distribution and leveraging the soft targeted labels
generated by the distribution to synthesize pseudo samples as the transfer set.
Several student networks trained with these synthesized transfer sets present
competitive performance compared to the networks trained with the original
training set and other data-free KD approaches.

---------------

### 23 Oct 2022 | [Respecting Transfer Gap in Knowledge Distillation](https://arxiv.org/abs/2210.12787) | [⬇️](https://arxiv.org/pdf/2210.12787)
*Yulei Niu, Long Chen, Chang Zhou, Hanwang Zhang* 

  Knowledge distillation (KD) is essentially a process of transferring a
teacher model's behavior, e.g., network response, to a student model. The
network response serves as additional supervision to formulate the machine
domain, which uses the data collected from the human domain as a transfer set.
Traditional KD methods hold an underlying assumption that the data collected in
both human domain and machine domain are both independent and identically
distributed (IID). We point out that this naive assumption is unrealistic and
there is indeed a transfer gap between the two domains. Although the gap offers
the student model external knowledge from the machine domain, the imbalanced
teacher knowledge would make us incorrectly estimate how much to transfer from
teacher to student per sample on the non-IID transfer set. To tackle this
challenge, we propose Inverse Probability Weighting Distillation (IPWD) that
estimates the propensity score of a training sample belonging to the machine
domain, and assigns its inverse amount to compensate for under-represented
samples. Experiments on CIFAR-100 and ImageNet demonstrate the effectiveness of
IPWD for both two-stage distillation and one-stage self-distillation.

---------------

### 23 Feb 2021 | [Enhancing Data-Free Adversarial Distillation with Activation  Regularization and Virtual Interpolation](https://arxiv.org/abs/2102.11638) | [⬇️](https://arxiv.org/pdf/2102.11638)
*Xiaoyang Qu, Jianzong Wang, Jing Xiao* 

  Knowledge distillation refers to a technique of transferring the knowledge
from a large learned model or an ensemble of learned models to a small model.
This method relies on access to the original training set, which might not
always be available. A possible solution is a data-free adversarial
distillation framework, which deploys a generative network to transfer the
teacher model's knowledge to the student model. However, the data generation
efficiency is low in the data-free adversarial distillation. We add an
activation regularizer and a virtual interpolation method to improve the data
generation efficiency. The activation regularizer enables the students to match
the teacher's predictions close to activation boundaries and decision
boundaries. The virtual interpolation method can generate virtual samples and
labels in-between decision boundaries. Our experiments show that our approach
surpasses state-of-the-art data-free distillation methods. The student model
can achieve 95.42% accuracy on CIFAR-10 and 77.05% accuracy on CIFAR-100
without any original training data. Our model's accuracy is 13.8% higher than
the state-of-the-art data-free method on CIFAR-100.

---------------
**Date:** 27 Feb 2023

**Title:** Feature Structure Distillation with Centered Kernel Alignment in BERT  Transferring

**Abstract Link:** [https://arxiv.org/abs/2204.08922](https://arxiv.org/abs/2204.08922)

**PDF Link:** [https://arxiv.org/pdf/2204.08922](https://arxiv.org/pdf/2204.08922)

---

**Date:** 02 Jun 2020

**Title:** Channel Distillation: Channel-Wise Attention for Knowledge Distillation

**Abstract Link:** [https://arxiv.org/abs/2006.01683](https://arxiv.org/abs/2006.01683)

**PDF Link:** [https://arxiv.org/pdf/2006.01683](https://arxiv.org/pdf/2006.01683)

---

**Date:** 18 Oct 2022

**Title:** On effects of Knowledge Distillation on Transfer Learning

**Abstract Link:** [https://arxiv.org/abs/2210.09668](https://arxiv.org/abs/2210.09668)

**PDF Link:** [https://arxiv.org/pdf/2210.09668](https://arxiv.org/pdf/2210.09668)

---

**Date:** 19 Oct 2020

**Title:** Locally Linear Region Knowledge Distillation

**Abstract Link:** [https://arxiv.org/abs/2010.04812](https://arxiv.org/abs/2010.04812)

**PDF Link:** [https://arxiv.org/pdf/2010.04812](https://arxiv.org/pdf/2010.04812)

---

**Date:** 18 Mar 2021

**Title:** Similarity Transfer for Knowledge Distillation

**Abstract Link:** [https://arxiv.org/abs/2103.10047](https://arxiv.org/abs/2103.10047)

**PDF Link:** [https://arxiv.org/pdf/2103.10047](https://arxiv.org/pdf/2103.10047)

---

**Date:** 02 Nov 2022

**Title:** Gradient Knowledge Distillation for Pre-trained Language Models

**Abstract Link:** [https://arxiv.org/abs/2211.01071](https://arxiv.org/abs/2211.01071)

**PDF Link:** [https://arxiv.org/pdf/2211.01071](https://arxiv.org/pdf/2211.01071)

---

**Date:** 25 May 2023

**Title:** HARD: Hard Augmentations for Robust Distillation

**Abstract Link:** [https://arxiv.org/abs/2305.14890](https://arxiv.org/abs/2305.14890)

**PDF Link:** [https://arxiv.org/pdf/2305.14890](https://arxiv.org/pdf/2305.14890)

---

**Date:** 31 Dec 2020

**Title:** Towards Zero-Shot Knowledge Distillation for Natural Language Processing

**Abstract Link:** [https://arxiv.org/abs/2012.15495](https://arxiv.org/abs/2012.15495)

**PDF Link:** [https://arxiv.org/pdf/2012.15495](https://arxiv.org/pdf/2012.15495)

---

**Date:** 18 Nov 2020

**Title:** Effectiveness of Arbitrary Transfer Sets for Data-free Knowledge  Distillation

**Abstract Link:** [https://arxiv.org/abs/2011.09113](https://arxiv.org/abs/2011.09113)

**PDF Link:** [https://arxiv.org/pdf/2011.09113](https://arxiv.org/pdf/2011.09113)

---

**Date:** 23 Nov 2021

**Title:** Semi-Online Knowledge Distillation

**Abstract Link:** [https://arxiv.org/abs/2111.11747](https://arxiv.org/abs/2111.11747)

**PDF Link:** [https://arxiv.org/pdf/2111.11747](https://arxiv.org/pdf/2111.11747)

---

**Date:** 01 Sep 2020

**Title:** Classification of Diabetic Retinopathy Using Unlabeled Data and  Knowledge Distillation

**Abstract Link:** [https://arxiv.org/abs/2009.00982](https://arxiv.org/abs/2009.00982)

**PDF Link:** [https://arxiv.org/pdf/2009.00982](https://arxiv.org/pdf/2009.00982)

---

**Date:** 18 Mar 2022

**Title:** A Closer Look at Knowledge Distillation with Features, Logits, and  Gradients

**Abstract Link:** [https://arxiv.org/abs/2203.10163](https://arxiv.org/abs/2203.10163)

**PDF Link:** [https://arxiv.org/pdf/2203.10163](https://arxiv.org/pdf/2203.10163)

---

**Date:** 25 Mar 2021

**Title:** A New Training Framework for Deep Neural Network

**Abstract Link:** [https://arxiv.org/abs/2103.07350](https://arxiv.org/abs/2103.07350)

**PDF Link:** [https://arxiv.org/pdf/2103.07350](https://arxiv.org/pdf/2103.07350)

---

**Date:** 10 Apr 2023

**Title:** A Survey on Recent Teacher-student Learning Studies

**Abstract Link:** [https://arxiv.org/abs/2304.04615](https://arxiv.org/abs/2304.04615)

**PDF Link:** [https://arxiv.org/pdf/2304.04615](https://arxiv.org/pdf/2304.04615)

---

**Date:** 02 Feb 2024

**Title:** Cooperative Knowledge Distillation: A Learner Agnostic Approach

**Abstract Link:** [https://arxiv.org/abs/2402.05942](https://arxiv.org/abs/2402.05942)

**PDF Link:** [https://arxiv.org/pdf/2402.05942](https://arxiv.org/pdf/2402.05942)

---

**Date:** 27 Oct 2021

**Title:** Beyond Classification: Knowledge Distillation using Multi-Object  Impressions

**Abstract Link:** [https://arxiv.org/abs/2110.14215](https://arxiv.org/abs/2110.14215)

**PDF Link:** [https://arxiv.org/pdf/2110.14215](https://arxiv.org/pdf/2110.14215)

---

**Date:** 17 Nov 2022

**Title:** CoupleFace: Relation Matters for Face Recognition Distillation

**Abstract Link:** [https://arxiv.org/abs/2204.05502](https://arxiv.org/abs/2204.05502)

**PDF Link:** [https://arxiv.org/pdf/2204.05502](https://arxiv.org/pdf/2204.05502)

---

**Date:** 10 Apr 2021

**Title:** Data-Free Knowledge Distillation with Soft Targeted Transfer Set  Synthesis

**Abstract Link:** [https://arxiv.org/abs/2104.04868](https://arxiv.org/abs/2104.04868)

**PDF Link:** [https://arxiv.org/pdf/2104.04868](https://arxiv.org/pdf/2104.04868)

---

**Date:** 23 Oct 2022

**Title:** Respecting Transfer Gap in Knowledge Distillation

**Abstract Link:** [https://arxiv.org/abs/2210.12787](https://arxiv.org/abs/2210.12787)

**PDF Link:** [https://arxiv.org/pdf/2210.12787](https://arxiv.org/pdf/2210.12787)

---

**Date:** 23 Feb 2021

**Title:** Enhancing Data-Free Adversarial Distillation with Activation  Regularization and Virtual Interpolation

**Abstract Link:** [https://arxiv.org/abs/2102.11638](https://arxiv.org/abs/2102.11638)

**PDF Link:** [https://arxiv.org/pdf/2102.11638](https://arxiv.org/pdf/2102.11638)

---

