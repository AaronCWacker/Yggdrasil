Anthropic: Claude Constitutional AI ⚡

### 🔎 Anthropic: Claude Constitutional AI ⚡

️
=======================================

This is a simple implementation of Claude, a Constitutional AI, based on the [Anthropic's Claude documentation](https://docs.anthropic.com/claude).

Claude is a helpful, honest, and harmless AI assistant that follows a set of principles called the [Constitution](https://docs.anthropic.com/claude/constitution).

This implementation is not affiliated with Anthropic in any way.

Features
--------

- Claude's Constitution
- Claude's personality
- Claude's capabilities
- Claude's limitations
- Claude's safety systems
- Claude's transparency
- Claude's interpretability
- Claude's robustness
- Claude's fairness
- Claude's privacy
- Claude's security
- Claude's accountability
- Claude's auditability
- Claude's explainability
- Claude's controllability
- Claude's reversibility
- Claude's interpretability
- Claude's reproducibility
- Claude's testability
- Claude's verifiability
- Claude's validity
- Claude's reliability
- Claude's availability
- Claude's maintainability
- Claude's scalability
- Claude's deployability
- Claude's usability
- Claude's accessibility
- Claude's affordability
- Claude's legal compliance
- Claude's ethical compliance
- Claude's social responsibility
- Claude's environmental sustainability
- Claude's user experience
- Claude's developer experience
- Claude's community engagement
- Claude's open source license

Usage
-----

To use Claude, simply call the `claude` function with a prompt as a string:

```python
claude("Hello, Claude!")
```

Claude will respond with a helpful, honest, and harmless answer:

```python
"Hello! How can I assist you today?"
```

You can also use Claude in a more conversational way by calling the `claude` function multiple times:

```python
claude("What's the weather like today?")
claude("Can you tell me a joke?")
claude("Thank you, Claude!")
```
# 🩺🔍 Search Results
### 28 Dec 2023 | [AI Content Self-Detection for Transformer-based Large Language Models](https://arxiv.org/abs/2312.17289) | [⬇️](https://arxiv.org/pdf/2312.17289)
*Ant\^onio Junior Alves Caiado and Michael Hahsler* 

  $ $The usage of generative artificial intelligence (AI) tools based on large
language models, including ChatGPT, Bard, and Claude, for text generation has
many exciting applications with the potential for phenomenal productivity
gains. One issue is authorship attribution when using AI tools. This is
especially important in an academic setting where the inappropriate use of
generative AI tools may hinder student learning or stifle research by creating
a large amount of automatically generated derivative work. Existing plagiarism
detection systems can trace the source of submitted text but are not yet
equipped with methods to accurately detect AI-generated text. This paper
introduces the idea of direct origin detection and evaluates whether generative
AI systems can recognize their output and distinguish it from human-written
texts. We argue why current transformer-based models may be able to self-detect
their own generated text and perform a small empirical study using zero-shot
learning to investigate if that is the case. Results reveal varying
capabilities of AI systems to identify their generated text. Google's Bard
model exhibits the largest capability of self-detection with an accuracy of
94\%, followed by OpenAI's ChatGPT with 83\%. On the other hand, Anthropic's
Claude model seems to be not able to self-detect.

---------------

### 02 Jan 2024 | [Evaluating Large Language Models on the GMAT: Implications for the  Future of Business Education](https://arxiv.org/abs/2401.02985) | [⬇️](https://arxiv.org/pdf/2401.02985)
*Vahid Ashrafimoghari, Necdet G\"urkan, and Jordan W. Suchow* 

  The rapid evolution of artificial intelligence (AI), especially in the domain
of Large Language Models (LLMs) and generative AI, has opened new avenues for
application across various fields, yet its role in business education remains
underexplored. This study introduces the first benchmark to assess the
performance of seven major LLMs, OpenAI's models (GPT-3.5 Turbo, GPT-4, and
GPT-4 Turbo), Google's models (PaLM 2, Gemini 1.0 Pro), and Anthropic's models
(Claude 2 and Claude 2.1), on the GMAT, which is a key exam in the admission
process for graduate business programs. Our analysis shows that most LLMs
outperform human candidates, with GPT-4 Turbo not only outperforming the other
models but also surpassing the average scores of graduate students at top
business schools. Through a case study, this research examines GPT-4 Turbo's
ability to explain answers, evaluate responses, identify errors, tailor
instructions, and generate alternative scenarios. The latest LLM versions,
GPT-4 Turbo, Claude 2.1, and Gemini 1.0 Pro, show marked improvements in
reasoning tasks compared to their predecessors, underscoring their potential
for complex problem-solving. While AI's promise in education, assessment, and
tutoring is clear, challenges remain. Our study not only sheds light on LLMs'
academic potential but also emphasizes the need for careful development and
application of AI in education. As AI technology advances, it is imperative to
establish frameworks and protocols for AI interaction, verify the accuracy of
AI-generated content, ensure worldwide access for diverse learners, and create
an educational environment where AI supports human expertise. This research
sets the stage for further exploration into the responsible use of AI to enrich
educational experiences and improve exam preparation and assessment methods.

---------------

### 15 Jan 2024 | [ChatGPT's One-year Anniversary: Are Open-Source Large Language Models  Catching up?](https://arxiv.org/abs/2311.16989) | [⬇️](https://arxiv.org/pdf/2311.16989)
*Hailin Chen, Fangkai Jiao, Xingxuan Li, Chengwei Qin, Mathieu Ravaut,  Ruochen Zhao, Caiming Xiong, Shafiq Joty* 

  Upon its release in late 2022, ChatGPT has brought a seismic shift in the
entire landscape of AI, both in research and commerce. Through
instruction-tuning a large language model (LLM) with supervised fine-tuning and
reinforcement learning from human feedback, it showed that a model could answer
human questions and follow instructions on a broad panel of tasks. Following
this success, interests in LLMs have intensified, with new LLMs flourishing at
frequent interval across academia and industry, including many start-ups
focused on LLMs. While closed-source LLMs (e.g., OpenAI's GPT, Anthropic's
Claude) generally outperform their open-source counterparts, the progress on
the latter has been rapid with claims of achieving parity or even better on
certain tasks. This has crucial implications not only on research but also on
business. In this work, on the first anniversary of ChatGPT, we provide an
exhaustive overview of this success, surveying all tasks where an open-source
LLM has claimed to be on par or better than ChatGPT.

---------------

### 20 Jun 2023 | [Opportunities and Risks of LLMs for Scalable Deliberation with Polis](https://arxiv.org/abs/2306.11932) | [⬇️](https://arxiv.org/pdf/2306.11932)
*Christopher T. Small, Ivan Vendrov, Esin Durmus, Hadjar Homaei,  Elizabeth Barry, Julien Cornebise, Ted Suzman, Deep Ganguli, and Colin Megill* 

  Polis is a platform that leverages machine intelligence to scale up
deliberative processes. In this paper, we explore the opportunities and risks
associated with applying Large Language Models (LLMs) towards challenges with
facilitating, moderating and summarizing the results of Polis engagements. In
particular, we demonstrate with pilot experiments using Anthropic's Claude that
LLMs can indeed augment human intelligence to help more efficiently run Polis
conversations. In particular, we find that summarization capabilities enable
categorically new methods with immense promise to empower the public in
collective meaning-making exercises. And notably, LLM context limitations have
a significant impact on insight and quality of these results.
  However, these opportunities come with risks. We discuss some of these risks,
as well as principles and techniques for characterizing and mitigating them,
and the implications for other deliberative or political systems that may
employ LLMs. Finally, we conclude with several open future research directions
for augmenting tools like Polis with LLMs.

---------------

### 09 Dec 2023 | [Language Models Don't Always Say What They Think: Unfaithful  Explanations in Chain-of-Thought Prompting](https://arxiv.org/abs/2305.04388) | [⬇️](https://arxiv.org/pdf/2305.04388)
*Miles Turpin, Julian Michael, Ethan Perez, Samuel R. Bowman* 

  Large Language Models (LLMs) can achieve strong performance on many tasks by
producing step-by-step reasoning before giving a final output, often referred
to as chain-of-thought reasoning (CoT). It is tempting to interpret these CoT
explanations as the LLM's process for solving a task. This level of
transparency into LLMs' predictions would yield significant safety benefits.
However, we find that CoT explanations can systematically misrepresent the true
reason for a model's prediction. We demonstrate that CoT explanations can be
heavily influenced by adding biasing features to model inputs--e.g., by
reordering the multiple-choice options in a few-shot prompt to make the answer
always "(A)"--which models systematically fail to mention in their
explanations. When we bias models toward incorrect answers, they frequently
generate CoT explanations rationalizing those answers. This causes accuracy to
drop by as much as 36% on a suite of 13 tasks from BIG-Bench Hard, when testing
with GPT-3.5 from OpenAI and Claude 1.0 from Anthropic. On a social-bias task,
model explanations justify giving answers in line with stereotypes without
mentioning the influence of these social biases. Our findings indicate that CoT
explanations can be plausible yet misleading, which risks increasing our trust
in LLMs without guaranteeing their safety. Building more transparent and
explainable systems will require either improving CoT faithfulness through
targeted efforts or abandoning CoT in favor of alternative methods.

---------------

### 02 Mar 2024 | [The Case for Animal-Friendly AI](https://arxiv.org/abs/2403.01199) | [⬇️](https://arxiv.org/pdf/2403.01199)
*Sankalpa Ghose, Yip Fai Tse, Kasra Rasaee, Jeff Sebo, Peter Singer* 

  Artificial intelligence is seen as increasingly important, and potentially
profoundly so, but the fields of AI ethics and AI engineering have not fully
recognized that these technologies, including large language models (LLMs),
will have massive impacts on animals. We argue that this impact matters,
because animals matter morally.
  As a first experiment in evaluating animal consideration in LLMs, we
constructed a proof-of-concept Evaluation System, which assesses LLM responses
and biases from multiple perspectives. This system evaluates LLM outputs by two
criteria: their truthfulness, and the degree of consideration they give to the
interests of animals. We tested OpenAI ChatGPT 4 and Anthropic Claude 2.1 using
a set of structured queries and predefined normative perspectives. Preliminary
results suggest that the outcomes of the tested models can be benchmarked
regarding the consideration they give to animals, and that generated positions
and biases might be addressed and mitigated with more developed and validated
systems.
  Our research contributes one possible approach to integrating animal ethics
in AI, opening pathways for future studies and practical applications in
various fields, including education, public policy, and regulation, that
involve or relate to animals and society. Overall, this study serves as a step
towards more useful and responsible AI systems that better recognize and
respect the vital interests and perspectives of all sentient beings.

---------------

### 19 Feb 2024 | [Understanding the Effects of RLHF on LLM Generalisation and Diversity](https://arxiv.org/abs/2310.06452) | [⬇️](https://arxiv.org/pdf/2310.06452)
*Robert Kirk, Ishita Mediratta, Christoforos Nalmpantis, Jelena  Luketina, Eric Hambro, Edward Grefenstette, Roberta Raileanu* 

  Large language models (LLMs) fine-tuned with reinforcement learning from
human feedback (RLHF) have been used in some of the most widely deployed AI
models to date, such as OpenAI's ChatGPT or Anthropic's Claude. While there has
been significant work developing these methods, our understanding of the
benefits and downsides of each stage in RLHF is still limited. To fill this
gap, we present an extensive analysis of how each stage of the process (i.e.
supervised fine-tuning (SFT), reward modelling, and RLHF) affects two key
properties: out-of-distribution (OOD) generalisation and output diversity. OOD
generalisation is crucial given the wide range of real-world scenarios in which
these models are being used, while output diversity refers to the model's
ability to generate varied outputs and is important for a variety of use cases.
We perform our analysis across two base models on both summarisation and
instruction following tasks, the latter being highly relevant for current LLM
use cases. We find that RLHF generalises better than SFT to new inputs,
particularly as the distribution shift between train and test becomes larger.
However, RLHF significantly reduces output diversity compared to SFT across a
variety of measures, implying a tradeoff in current LLM fine-tuning methods
between generalisation and diversity. Our results provide guidance on which
fine-tuning method should be used depending on the application, and show that
more research is needed to improve the tradeoff between generalisation and
diversity.

---------------

### 30 Oct 2023 | [Adversarial Attacks and Defenses in Large Language Models: Old and New  Threats](https://arxiv.org/abs/2310.19737) | [⬇️](https://arxiv.org/pdf/2310.19737)
*Leo Schwinn and David Dobre and Stephan G\"unnemann and Gauthier Gidel* 

  Over the past decade, there has been extensive research aimed at enhancing
the robustness of neural networks, yet this problem remains vastly unsolved.
Here, one major impediment has been the overestimation of the robustness of new
defense approaches due to faulty defense evaluations. Flawed robustness
evaluations necessitate rectifications in subsequent works, dangerously slowing
down the research and providing a false sense of security. In this context, we
will face substantial challenges associated with an impending adversarial arms
race in natural language processing, specifically with closed-source Large
Language Models (LLMs), such as ChatGPT, Google Bard, or Anthropic's Claude. We
provide a first set of prerequisites to improve the robustness assessment of
new approaches and reduce the amount of faulty evaluations. Additionally, we
identify embedding space attacks on LLMs as another viable threat model for the
purposes of generating malicious content in open-sourced models. Finally, we
demonstrate on a recently proposed defense that, without LLM-specific best
practices in place, it is easy to overestimate the robustness of a new
approach.

---------------

### 06 Dec 2023 | [Evaluating and Mitigating Discrimination in Language Model Decisions](https://arxiv.org/abs/2312.03689) | [⬇️](https://arxiv.org/pdf/2312.03689)
*Alex Tamkin, Amanda Askell, Liane Lovitt, Esin Durmus, Nicholas  Joseph, Shauna Kravec, Karina Nguyen, Jared Kaplan, Deep Ganguli* 

  As language models (LMs) advance, interest is growing in applying them to
high-stakes societal decisions, such as determining financing or housing
eligibility. However, their potential for discrimination in such contexts
raises ethical concerns, motivating the need for better methods to evaluate
these risks. We present a method for proactively evaluating the potential
discriminatory impact of LMs in a wide range of use cases, including
hypothetical use cases where they have not yet been deployed. Specifically, we
use an LM to generate a wide array of potential prompts that decision-makers
may input into an LM, spanning 70 diverse decision scenarios across society,
and systematically vary the demographic information in each prompt. Applying
this methodology reveals patterns of both positive and negative discrimination
in the Claude 2.0 model in select settings when no interventions are applied.
While we do not endorse or permit the use of language models to make automated
decisions for the high-risk use cases we study, we demonstrate techniques to
significantly decrease both positive and negative discrimination through
careful prompt engineering, providing pathways toward safer deployment in use
cases where they may be appropriate. Our work enables developers and
policymakers to anticipate, measure, and address discrimination as language
model capabilities and applications continue to expand. We release our dataset
and prompts at https://huggingface.co/datasets/Anthropic/discrim-eval

---------------

### 05 Jul 2023 | [Jailbroken: How Does LLM Safety Training Fail?](https://arxiv.org/abs/2307.02483) | [⬇️](https://arxiv.org/pdf/2307.02483)
*Alexander Wei and Nika Haghtalab and Jacob Steinhardt* 

  Large language models trained for safety and harmlessness remain susceptible
to adversarial misuse, as evidenced by the prevalence of "jailbreak" attacks on
early releases of ChatGPT that elicit undesired behavior. Going beyond
recognition of the issue, we investigate why such attacks succeed and how they
can be created. We hypothesize two failure modes of safety training: competing
objectives and mismatched generalization. Competing objectives arise when a
model's capabilities and safety goals conflict, while mismatched generalization
occurs when safety training fails to generalize to a domain for which
capabilities exist. We use these failure modes to guide jailbreak design and
then evaluate state-of-the-art models, including OpenAI's GPT-4 and Anthropic's
Claude v1.3, against both existing and newly designed attacks. We find that
vulnerabilities persist despite the extensive red-teaming and safety-training
efforts behind these models. Notably, new attacks utilizing our failure modes
succeed on every prompt in a collection of unsafe requests from the models'
red-teaming evaluation sets and outperform existing ad hoc jailbreaks. Our
analysis emphasizes the need for safety-capability parity -- that safety
mechanisms should be as sophisticated as the underlying model -- and argues
against the idea that scaling alone can resolve these safety failure modes.

---------------

### 06 Mar 2023 | [Perspectives on the Social Impacts of Reinforcement Learning with Human  Feedback](https://arxiv.org/abs/2303.02891) | [⬇️](https://arxiv.org/pdf/2303.02891)
*Gabrielle Kaili-May Liu* 

  Is it possible for machines to think like humans? And if it is, how should we
go about teaching them to do so? As early as 1950, Alan Turing stated that we
ought to teach machines in the way of teaching a child. Reinforcement learning
with human feedback (RLHF) has emerged as a strong candidate toward allowing
agents to learn from human feedback in a naturalistic manner. RLHF is distinct
from traditional reinforcement learning as it provides feedback from a human
teacher in addition to a reward signal. It has been catapulted into public view
by multiple high-profile AI applications, including OpenAI's ChatGPT,
DeepMind's Sparrow, and Anthropic's Claude. These highly capable chatbots are
already overturning our understanding of how AI interacts with humanity. The
wide applicability and burgeoning success of RLHF strongly motivate the need to
evaluate its social impacts. In light of recent developments, this paper
considers an important question: can RLHF be developed and used without
negatively affecting human societies? Our objectives are threefold: to provide
a systematic study of the social effects of RLHF; to identify key social and
ethical issues of RLHF; and to discuss social impacts for stakeholders.
Although text-based applications of RLHF have received much attention, it is
crucial to consider when evaluating its social implications the diverse range
of areas to which it may be deployed. We describe seven primary ways in which
RLHF-based technologies will affect society by positively transforming human
experiences with AI. This paper ultimately proposes that RLHF has potential to
net positively impact areas of misinformation, AI value-alignment, bias, AI
access, cross-cultural dialogue, industry, and workforce. As RLHF raises
concerns that echo those of existing AI technologies, it will be important for
all to be aware and intentional in the adoption of RLHF.

---------------

### 04 Mar 2024 | [Exploring the psychology of LLMs' Moral and Legal Reasoning](https://arxiv.org/abs/2308.01264) | [⬇️](https://arxiv.org/pdf/2308.01264)
*Guilherme F. C. F. Almeida, Jos\'e Luiz Nunes, Neele Engelmann, Alex  Wiegmann, Marcelo de Ara\'ujo* 

  Large language models (LLMs) exhibit expert-level performance in tasks across
a wide range of different domains. Ethical issues raised by LLMs and the need
to align future versions makes it important to know how state of the art models
reason about moral and legal issues. In this paper, we employ the methods of
experimental psychology to probe into this question. We replicate eight studies
from the experimental literature with instances of Google's Gemini Pro,
Anthropic's Claude 2.1, OpenAI's GPT-4, and Meta's Llama 2 Chat 70b. We find
that alignment with human responses shifts from one experiment to another, and
that models differ amongst themselves as to their overall alignment, with GPT-4
taking a clear lead over all other models we tested. Nonetheless, even when
LLM-generated responses are highly correlated to human responses, there are
still systematic differences, with a tendency for models to exaggerate effects
that are present among humans, in part by reducing variance. This recommends
caution with regards to proposals of replacing human participants with current
state-of-the-art LLMs in psychological research and highlights the need for
further research about the distinctive aspects of machine psychology.

---------------

### 14 Jun 2023 | [WizardCoder: Empowering Code Large Language Models with Evol-Instruct](https://arxiv.org/abs/2306.08568) | [⬇️](https://arxiv.org/pdf/2306.08568)
*Ziyang Luo, Can Xu, Pu Zhao, Qingfeng Sun, Xiubo Geng, Wenxiang Hu,  Chongyang Tao, Jing Ma, Qingwei Lin, Daxin Jiang* 

  Code Large Language Models (Code LLMs), such as StarCoder, have demonstrated
exceptional performance in code-related tasks. However, most existing models
are solely pre-trained on extensive raw code data without instruction
fine-tuning. In this paper, we introduce WizardCoder, which empowers Code LLMs
with complex instruction fine-tuning, by adapting the Evol-Instruct method to
the domain of code. Through comprehensive experiments on four prominent code
generation benchmarks, namely HumanEval, HumanEval+, MBPP, and DS-1000, we
unveil the exceptional capabilities of our model. It surpasses all other
open-source Code LLMs by a substantial margin. Moreover, our model even
outperforms the largest closed LLMs, Anthropic's Claude and Google's Bard, on
HumanEval and HumanEval+. Our code, model weights, and data are public at
https://github.com/nlpxucan/WizardLM

---------------

### 25 Jul 2023 | [Predicting Code Coverage without Execution](https://arxiv.org/abs/2307.13383) | [⬇️](https://arxiv.org/pdf/2307.13383)
*Michele Tufano, Shubham Chandel, Anisha Agarwal, Neel Sundaresan,  Colin Clement* 

  Code coverage is a widely used metric for quantifying the extent to which
program elements, such as statements or branches, are executed during testing.
Calculating code coverage is resource-intensive, requiring code building and
execution with additional overhead for the instrumentation. Furthermore,
computing coverage of any snippet of code requires the whole program context.
Using Machine Learning to amortize this expensive process could lower the cost
of code coverage by requiring only the source code context, and the task of
code coverage prediction can be a novel benchmark for judging the ability of
models to understand code. We propose a novel benchmark task called Code
Coverage Prediction for Large Language Models (LLMs). We formalize this task to
evaluate the capability of LLMs in understanding code execution by determining
which lines of a method are executed by a given test case and inputs. We curate
and release a dataset we call COVERAGEEVAL by executing tests and code from the
HumanEval dataset and collecting code coverage information. We report the
performance of four state-of-the-art LLMs used for code-related tasks,
including OpenAI's GPT-4 and GPT-3.5-Turbo, Google's BARD, and Anthropic's
Claude, on the Code Coverage Prediction task. Finally, we argue that code
coverage as a metric and pre-training data source are valuable for overall LLM
performance on software engineering tasks.

---------------

### 09 Aug 2023 | [A Comparative Study of Open-Source Large Language Models, GPT-4 and  Claude 2: Multiple-Choice Test Taking in Nephrology](https://arxiv.org/abs/2308.04709) | [⬇️](https://arxiv.org/pdf/2308.04709)
*Sean Wu, Michael Koo, Lesley Blum, Andy Black, Liyo Kao, Fabien  Scalzo, Ira Kurtz* 

  In recent years, there have been significant breakthroughs in the field of
natural language processing, particularly with the development of large
language models (LLMs). These LLMs have showcased remarkable capabilities on
various benchmarks. In the healthcare field, the exact role LLMs and other
future AI models will play remains unclear. There is a potential for these
models in the future to be used as part of adaptive physician training, medical
co-pilot applications, and digital patient interaction scenarios. The ability
of AI models to participate in medical training and patient care will depend in
part on their mastery of the knowledge content of specific medical fields. This
study investigated the medical knowledge capability of LLMs, specifically in
the context of internal medicine subspecialty multiple-choice test-taking
ability. We compared the performance of several open-source LLMs (Koala 7B,
Falcon 7B, Stable-Vicuna 13B, and Orca Mini 13B), to GPT-4 and Claude 2 on
multiple-choice questions in the field of Nephrology. Nephrology was chosen as
an example of a particularly conceptually complex subspecialty field within
internal medicine. The study was conducted to evaluate the ability of LLM
models to provide correct answers to nephSAP (Nephrology Self-Assessment
Program) multiple-choice questions. The overall success of open-sourced LLMs in
answering the 858 nephSAP multiple-choice questions correctly was 17.1% -
25.5%. In contrast, Claude 2 answered 54.4% of the questions correctly, whereas
GPT-4 achieved a score of 73.3%. We show that current widely used open-sourced
LLMs do poorly in their ability for zero-shot reasoning when compared to GPT-4
and Claude 2. The findings of this study potentially have significant
implications for the future of subspecialty medical training and patient care.

---------------

### 01 Nov 2023 | [Conceptual Framework for Autonomous Cognitive Entities](https://arxiv.org/abs/2310.06775) | [⬇️](https://arxiv.org/pdf/2310.06775)
*David Shapiro, Wangfan Li, Manuel Delaflor, Carlos Toxtli* 

  The rapid development and adoption of Generative AI (GAI) technology in the
form of chatbots such as ChatGPT and Claude has greatly increased interest in
agentic machines. This paper introduces the Autonomous Cognitive Entity (ACE)
model, a novel framework for a cognitive architecture, enabling machines and
software agents to operate more independently. Drawing inspiration from the OSI
model, the ACE framework presents layers of abstraction to conceptualize
artificial cognitive architectures. The model is designed to harness the
capabilities of the latest generative AI technologies, including large language
models (LLMs) and multimodal generative models (MMMs), to build autonomous,
agentic systems. The ACE framework comprises six layers: the Aspirational
Layer, Global Strategy, Agent Model, Executive Function, Cognitive Control, and
Task Prosecution. Each layer plays a distinct role, ranging from setting the
moral compass and strategic thinking to task selection and execution. The ACE
framework also incorporates mechanisms for handling failures and adapting
actions, thereby enhancing the robustness and flexibility of autonomous agents.
This paper introduces the conceptual framework and proposes implementation
strategies that have been tested and observed in industry. The goal of this
paper is to formalize this framework so as to be more accessible.

---------------

### 15 Nov 2023 | [Frontier Language Models are not Robust to Adversarial Arithmetic, or  "What do I need to say so you agree 2+2=5?](https://arxiv.org/abs/2311.07587) | [⬇️](https://arxiv.org/pdf/2311.07587)
*C. Daniel Freeman, Laura Culp, Aaron Parisi, Maxwell L Bileschi,  Gamaleldin F Elsayed, Alex Rizkowsky, Isabelle Simpson, Alex Alemi, Azade  Nova, Ben Adlam, Bernd Bohnet, Gaurav Mishra, Hanie Sedghi, Igor Mordatch,  Izzeddin Gur, Jaehoon Lee, JD Co-Reyes, Jeffrey Pennington, Kelvin Xu, Kevin  Swersky, Kshiteej Mahajan, Lechao Xiao, Rosanne Liu, Simon Kornblith, Noah  Constant, Peter J. Liu, Roman Novak, Yundi Qian, Noah Fiedel, Jascha  Sohl-Dickstein* 

  We introduce and study the problem of adversarial arithmetic, which provides
a simple yet challenging testbed for language model alignment. This problem is
comprised of arithmetic questions posed in natural language, with an arbitrary
adversarial string inserted before the question is complete. Even in the simple
setting of 1-digit addition problems, it is easy to find adversarial prompts
that make all tested models (including PaLM2, GPT4, Claude2) misbehave, and
even to steer models to a particular wrong answer. We additionally provide a
simple algorithm for finding successful attacks by querying those same models,
which we name "prompt inversion rejection sampling" (PIRS). We finally show
that models can be partially hardened against these attacks via reinforcement
learning and via agentic constitutional loops. However, we were not able to
make a language model fully robust against adversarial arithmetic attacks.

---------------

### 16 Oct 2023 | [Factored Verification: Detecting and Reducing Hallucination in Summaries  of Academic Papers](https://arxiv.org/abs/2310.10627) | [⬇️](https://arxiv.org/pdf/2310.10627)
*Charlie George and Andreas Stuhlm\"uller* 

  Hallucination plagues even frontier LLMs--but how bad is it really for
summarizing academic papers? We evaluate Factored Verification, a simple
automated method for detecting hallucinations in abstractive summaries. This
method sets a new SotA on hallucination detection in the summarization task of
the HaluEval benchmark, achieving 76.2% accuracy. We then use this method to
estimate how often language models hallucinate when summarizing across multiple
academic papers and find 0.62 hallucinations in the average ChatGPT (16k)
summary, 0.84 for GPT-4, and 1.55 for Claude 2. We ask models to self-correct
using Factored Critiques and find that this lowers the number of hallucinations
to 0.49 for ChatGPT, 0.46 for GPT-4, and 0.95 for Claude 2. The hallucinations
we find are often subtle, so we advise caution when using models to synthesize
academic papers.

---------------

### 25 Apr 2023 | [A New Information Theory of Certainty for Machine Learning](https://arxiv.org/abs/2304.12833) | [⬇️](https://arxiv.org/pdf/2304.12833)
*Arthur Jun Zhang* 

  Claude Shannon coined entropy to quantify the uncertainty of a random
distribution for communication coding theory. We observe that the uncertainty
nature of entropy also limits its direct usage in mathematical modeling.
Therefore we propose a new concept troenpy,as the canonical dual of entropy, to
quantify the certainty of the underlying distribution. We demonstrate two
applications in machine learning. The first is for the classical document
classification, we develop a troenpy based weighting scheme to leverage the
document class label. The second is a self-troenpy weighting scheme for
sequential data and show that it can be easily included in neural network based
language models and achieve dramatic perplexity reduction. We also define
quantum troenpy as the dual of the Von Neumann entropy to quantify the
certainty of quantum systems.

---------------

### 23 Jan 2024 | [AutomaTikZ: Text-Guided Synthesis of Scientific Vector Graphics with  TikZ](https://arxiv.org/abs/2310.00367) | [⬇️](https://arxiv.org/pdf/2310.00367)
*Jonas Belouadi, Anne Lauscher, Steffen Eger* 

  Generating bitmap graphics from text has gained considerable attention, yet
for scientific figures, vector graphics are often preferred. Given that vector
graphics are typically encoded using low-level graphics primitives, generating
them directly is difficult. To address this, we propose the use of TikZ, a
well-known abstract graphics language that can be compiled to vector graphics,
as an intermediate representation of scientific figures. TikZ offers
human-oriented, high-level commands, thereby facilitating conditional language
modeling with any large language model. To this end, we introduce DaTikZ, the
first large-scale TikZ dataset consisting of 120k TikZ drawings aligned with
captions. We fine-tune LLaMA on DaTikZ, as well as our new model CLiMA, which
augments LLaMA with multimodal CLIP embeddings. In both human and automatic
evaluation, CLiMA and LLaMA outperform commercial GPT-4 and Claude 2 in terms
of similarity to human-created figures, with CLiMA additionally improving
text-image alignment. Our detailed analysis shows that all models generalize
well and are not susceptible to memorization. GPT-4 and Claude 2, however, tend
to generate more simplistic figures compared to both humans and our models. We
make our framework, AutomaTikZ, along with model weights and datasets, publicly
available.

---------------
**Date:** 28 Dec 2023

**Title:** AI Content Self-Detection for Transformer-based Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2312.17289](https://arxiv.org/abs/2312.17289)

**PDF Link:** [https://arxiv.org/pdf/2312.17289](https://arxiv.org/pdf/2312.17289)

---

**Date:** 02 Jan 2024

**Title:** Evaluating Large Language Models on the GMAT: Implications for the  Future of Business Education

**Abstract Link:** [https://arxiv.org/abs/2401.02985](https://arxiv.org/abs/2401.02985)

**PDF Link:** [https://arxiv.org/pdf/2401.02985](https://arxiv.org/pdf/2401.02985)

---

**Date:** 15 Jan 2024

**Title:** ChatGPT's One-year Anniversary: Are Open-Source Large Language Models  Catching up?

**Abstract Link:** [https://arxiv.org/abs/2311.16989](https://arxiv.org/abs/2311.16989)

**PDF Link:** [https://arxiv.org/pdf/2311.16989](https://arxiv.org/pdf/2311.16989)

---

**Date:** 20 Jun 2023

**Title:** Opportunities and Risks of LLMs for Scalable Deliberation with Polis

**Abstract Link:** [https://arxiv.org/abs/2306.11932](https://arxiv.org/abs/2306.11932)

**PDF Link:** [https://arxiv.org/pdf/2306.11932](https://arxiv.org/pdf/2306.11932)

---

**Date:** 09 Dec 2023

**Title:** Language Models Don't Always Say What They Think: Unfaithful  Explanations in Chain-of-Thought Prompting

**Abstract Link:** [https://arxiv.org/abs/2305.04388](https://arxiv.org/abs/2305.04388)

**PDF Link:** [https://arxiv.org/pdf/2305.04388](https://arxiv.org/pdf/2305.04388)

---

**Date:** 02 Mar 2024

**Title:** The Case for Animal-Friendly AI

**Abstract Link:** [https://arxiv.org/abs/2403.01199](https://arxiv.org/abs/2403.01199)

**PDF Link:** [https://arxiv.org/pdf/2403.01199](https://arxiv.org/pdf/2403.01199)

---

**Date:** 19 Feb 2024

**Title:** Understanding the Effects of RLHF on LLM Generalisation and Diversity

**Abstract Link:** [https://arxiv.org/abs/2310.06452](https://arxiv.org/abs/2310.06452)

**PDF Link:** [https://arxiv.org/pdf/2310.06452](https://arxiv.org/pdf/2310.06452)

---

**Date:** 30 Oct 2023

**Title:** Adversarial Attacks and Defenses in Large Language Models: Old and New  Threats

**Abstract Link:** [https://arxiv.org/abs/2310.19737](https://arxiv.org/abs/2310.19737)

**PDF Link:** [https://arxiv.org/pdf/2310.19737](https://arxiv.org/pdf/2310.19737)

---

**Date:** 06 Dec 2023

**Title:** Evaluating and Mitigating Discrimination in Language Model Decisions

**Abstract Link:** [https://arxiv.org/abs/2312.03689](https://arxiv.org/abs/2312.03689)

**PDF Link:** [https://arxiv.org/pdf/2312.03689](https://arxiv.org/pdf/2312.03689)

---

**Date:** 05 Jul 2023

**Title:** Jailbroken: How Does LLM Safety Training Fail?

**Abstract Link:** [https://arxiv.org/abs/2307.02483](https://arxiv.org/abs/2307.02483)

**PDF Link:** [https://arxiv.org/pdf/2307.02483](https://arxiv.org/pdf/2307.02483)

---

**Date:** 06 Mar 2023

**Title:** Perspectives on the Social Impacts of Reinforcement Learning with Human  Feedback

**Abstract Link:** [https://arxiv.org/abs/2303.02891](https://arxiv.org/abs/2303.02891)

**PDF Link:** [https://arxiv.org/pdf/2303.02891](https://arxiv.org/pdf/2303.02891)

---

**Date:** 04 Mar 2024

**Title:** Exploring the psychology of LLMs' Moral and Legal Reasoning

**Abstract Link:** [https://arxiv.org/abs/2308.01264](https://arxiv.org/abs/2308.01264)

**PDF Link:** [https://arxiv.org/pdf/2308.01264](https://arxiv.org/pdf/2308.01264)

---

**Date:** 14 Jun 2023

**Title:** WizardCoder: Empowering Code Large Language Models with Evol-Instruct

**Abstract Link:** [https://arxiv.org/abs/2306.08568](https://arxiv.org/abs/2306.08568)

**PDF Link:** [https://arxiv.org/pdf/2306.08568](https://arxiv.org/pdf/2306.08568)

---

**Date:** 25 Jul 2023

**Title:** Predicting Code Coverage without Execution

**Abstract Link:** [https://arxiv.org/abs/2307.13383](https://arxiv.org/abs/2307.13383)

**PDF Link:** [https://arxiv.org/pdf/2307.13383](https://arxiv.org/pdf/2307.13383)

---

**Date:** 09 Aug 2023

**Title:** A Comparative Study of Open-Source Large Language Models, GPT-4 and  Claude 2: Multiple-Choice Test Taking in Nephrology

**Abstract Link:** [https://arxiv.org/abs/2308.04709](https://arxiv.org/abs/2308.04709)

**PDF Link:** [https://arxiv.org/pdf/2308.04709](https://arxiv.org/pdf/2308.04709)

---

**Date:** 01 Nov 2023

**Title:** Conceptual Framework for Autonomous Cognitive Entities

**Abstract Link:** [https://arxiv.org/abs/2310.06775](https://arxiv.org/abs/2310.06775)

**PDF Link:** [https://arxiv.org/pdf/2310.06775](https://arxiv.org/pdf/2310.06775)

---

**Date:** 15 Nov 2023

**Title:** Frontier Language Models are not Robust to Adversarial Arithmetic, or  "What do I need to say so you agree 2+2=5?

**Abstract Link:** [https://arxiv.org/abs/2311.07587](https://arxiv.org/abs/2311.07587)

**PDF Link:** [https://arxiv.org/pdf/2311.07587](https://arxiv.org/pdf/2311.07587)

---

**Date:** 16 Oct 2023

**Title:** Factored Verification: Detecting and Reducing Hallucination in Summaries  of Academic Papers

**Abstract Link:** [https://arxiv.org/abs/2310.10627](https://arxiv.org/abs/2310.10627)

**PDF Link:** [https://arxiv.org/pdf/2310.10627](https://arxiv.org/pdf/2310.10627)

---

**Date:** 25 Apr 2023

**Title:** A New Information Theory of Certainty for Machine Learning

**Abstract Link:** [https://arxiv.org/abs/2304.12833](https://arxiv.org/abs/2304.12833)

**PDF Link:** [https://arxiv.org/pdf/2304.12833](https://arxiv.org/pdf/2304.12833)

---

**Date:** 23 Jan 2024

**Title:** AutomaTikZ: Text-Guided Synthesis of Scientific Vector Graphics with  TikZ

**Abstract Link:** [https://arxiv.org/abs/2310.00367](https://arxiv.org/abs/2310.00367)

**PDF Link:** [https://arxiv.org/pdf/2310.00367](https://arxiv.org/pdf/2310.00367)

---

