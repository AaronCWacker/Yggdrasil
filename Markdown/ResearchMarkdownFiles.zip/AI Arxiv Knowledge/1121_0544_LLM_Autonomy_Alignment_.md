LLM Autonomy Alignment 🎪

### 🔎 LLM Autonomy Alignment 🎪



Autonomy Alignment is a concept that I've been thinking about a lot lately. It's the idea that in order to be truly autonomous, you need to be aligned with your values, goals, and purpose.

When you're aligned, you're able to make decisions that are in line with what you truly want, rather than being swayed by external factors or other people's agendas. You're able to stay true to yourself and your vision, even when things get tough or when you face resistance.

But alignment isn't just about making the "right" decisions. It's also about creating a sense of inner harmony and peace. When you're aligned, you feel more confident, centered, and grounded. You're able to tap into your inner wisdom and intuition, which can guide you towards your highest potential.

Of course, alignment isn't always easy to achieve. It requires self-awareness, self-reflection, and a willingness to let go of things that no longer serve you. It requires a deep understanding of your values, goals, and purpose, and a commitment to living in accordance with them.

But the rewards of alignment are well worth the effort. When you're aligned, you're able to live a life that is authentic, fulfilling, and meaningful. You're able to create the kind of impact that you want to have in the world, and you're able to do so with a sense of joy, ease, and flow.

So if you're feeling disconnected, unfulfilled, or uncertain about your path, take some time to explore your alignment. Ask yourself what matters most to you, and what kind of legacy you want to leave behind. And then take action to align your life with your values, goals, and purpose.

Because when you're aligned, you're unstoppable. 💪</s>
# 🩺🔍 Search Results
### 05 Oct 2023 | [Balancing Autonomy and Alignment: A Multi-Dimensional Taxonomy for  Autonomous LLM-powered Multi-Agent Architectures](https://arxiv.org/abs/2310.03659) | [⬇️](https://arxiv.org/pdf/2310.03659)
*Thorsten H\"andler* 

  Large language models (LLMs) have revolutionized the field of artificial
intelligence, endowing it with sophisticated language understanding and
generation capabilities. However, when faced with more complex and
interconnected tasks that demand a profound and iterative thought process, LLMs
reveal their inherent limitations. Autonomous LLM-powered multi-agent systems
represent a strategic response to these challenges. Such systems strive for
autonomously tackling user-prompted goals by decomposing them into manageable
tasks and orchestrating their execution and result synthesis through a
collective of specialized intelligent agents. Equipped with LLM-powered
reasoning capabilities, these agents harness the cognitive synergy of
collaborating with their peers, enhanced by leveraging contextual resources
such as tools and datasets. While these architectures hold promising potential
in amplifying AI capabilities, striking the right balance between different
levels of autonomy and alignment remains the crucial challenge for their
effective operation. This paper proposes a comprehensive multi-dimensional
taxonomy, engineered to analyze how autonomous LLM-powered multi-agent systems
balance the dynamic interplay between autonomy and alignment across various
aspects inherent to architectural viewpoints such as goal-driven task
management, agent composition, multi-agent collaboration, and context
interaction. It also includes a domain-ontology model specifying fundamental
architectural concepts. Our taxonomy aims to empower researchers, engineers,
and AI practitioners to systematically analyze the architectural dynamics and
balancing strategies employed by these increasingly prevalent AI systems. The
exploratory taxonomic classification of selected representative LLM-powered
multi-agent systems illustrates its practical utility and reveals potential for
future research and development.

---------------

### 14 Dec 2023 | [CERN for AGI: A Theoretical Framework for Autonomous Simulation-Based  Artificial Intelligence Testing and Alignment](https://arxiv.org/abs/2312.09402) | [⬇️](https://arxiv.org/pdf/2312.09402)
*Ljubisa Bojic, Matteo Cinelli, Dubravko Culibrk, Boris Delibasic* 

  This paper explores the potential of a multidisciplinary approach to testing
and aligning artificial general intelligence (AGI) and LLMs. Due to the rapid
development and wide application of LLMs, challenges such as ethical alignment,
controllability, and predictability of these models have become important
research topics. This study investigates an innovative simulation-based
multi-agent system within a virtual reality framework that replicates the
real-world environment. The framework is populated by automated 'digital
citizens,' simulating complex social structures and interactions to examine and
optimize AGI. Application of various theories from the fields of sociology,
social psychology, computer science, physics, biology, and economics
demonstrates the possibility of a more human-aligned and socially responsible
AGI. The purpose of such a digital environment is to provide a dynamic platform
where advanced AI agents can interact and make independent decisions, thereby
mimicking realistic scenarios. The actors in this digital city, operated by the
LLMs, serve as the primary agents, exhibiting high degrees of autonomy. While
this approach shows immense potential, there are notable challenges and
limitations, most significantly the unpredictable nature of real-world social
dynamics. This research endeavors to contribute to the development and
refinement of AGI, emphasizing the integration of social, ethical, and
theoretical dimensions for future research.

---------------

### 30 Jan 2024 | [Two Heads Are Better Than One: Integrating Knowledge from Knowledge  Graphs and Large Language Models for Entity Alignment](https://arxiv.org/abs/2401.16960) | [⬇️](https://arxiv.org/pdf/2401.16960)
*Linyao Yang and Hongyang Chen and Xiao Wang and Jing Yang and Fei-Yue  Wang and Han Liu* 

  Entity alignment, which is a prerequisite for creating a more comprehensive
Knowledge Graph (KG), involves pinpointing equivalent entities across disparate
KGs. Contemporary methods for entity alignment have predominantly utilized
knowledge embedding models to procure entity embeddings that encapsulate
various similarities-structural, relational, and attributive. These embeddings
are then integrated through attention-based information fusion mechanisms.
Despite this progress, effectively harnessing multifaceted information remains
challenging due to inherent heterogeneity. Moreover, while Large Language
Models (LLMs) have exhibited exceptional performance across diverse downstream
tasks by implicitly capturing entity semantics, this implicit knowledge has yet
to be exploited for entity alignment. In this study, we propose a Large
Language Model-enhanced Entity Alignment framework (LLMEA), integrating
structural knowledge from KGs with semantic knowledge from LLMs to enhance
entity alignment. Specifically, LLMEA identifies candidate alignments for a
given entity by considering both embedding similarities between entities across
KGs and edit distances to a virtual equivalent entity. It then engages an LLM
iteratively, posing multiple multi-choice questions to draw upon the LLM's
inference capability. The final prediction of the equivalent entity is derived
from the LLM's output. Experiments conducted on three public datasets reveal
that LLMEA surpasses leading baseline models. Additional ablation studies
underscore the efficacy of our proposed framework.

---------------

### 25 Oct 2023 | [Privately Aligning Language Models with Reinforcement Learning](https://arxiv.org/abs/2310.16960) | [⬇️](https://arxiv.org/pdf/2310.16960)
*Fan Wu, Huseyin A. Inan, Arturs Backurs, Varun Chandrasekaran,  Janardhan Kulkarni, Robert Sim* 

  Positioned between pre-training and user deployment, aligning large language
models (LLMs) through reinforcement learning (RL) has emerged as a prevailing
strategy for training instruction following-models such as ChatGPT. In this
work, we initiate the study of privacy-preserving alignment of LLMs through
Differential Privacy (DP) in conjunction with RL. Following the influential
work of Ziegler et al. (2020), we study two dominant paradigms: (i) alignment
via RL without human in the loop (e.g., positive review generation) and (ii)
alignment via RL from human feedback (RLHF) (e.g., summarization in a
human-preferred way). We give a new DP framework to achieve alignment via RL,
and prove its correctness. Our experimental results validate the effectiveness
of our approach, offering competitive utility while ensuring strong privacy
protections.

---------------

### 02 Nov 2023 | [REAL: Resilience and Adaptation using Large Language Models on  Autonomous Aerial Robots](https://arxiv.org/abs/2311.01403) | [⬇️](https://arxiv.org/pdf/2311.01403)
*Andrea Tagliabue, Kota Kondo, Tong Zhao, Mason Peterson, Claudius T.  Tewari, Jonathan P. How* 

  Large Language Models (LLMs) pre-trained on internet-scale datasets have
shown impressive capabilities in code understanding, synthesis, and general
purpose question-and-answering. Key to their performance is the substantial
prior knowledge acquired during training and their ability to reason over
extended sequences of symbols, often presented in natural language. In this
work, we aim to harness the extensive long-term reasoning, natural language
comprehension, and the available prior knowledge of LLMs for increased
resilience and adaptation in autonomous mobile robots. We introduce REAL, an
approach for REsilience and Adaptation using LLMs. REAL provides a strategy to
employ LLMs as a part of the mission planning and control framework of an
autonomous robot. The LLM employed by REAL provides (i) a source of prior
knowledge to increase resilience for challenging scenarios that the system had
not been explicitly designed for; (ii) a way to interpret natural-language and
other log/diagnostic information available in the autonomy stack, for mission
planning; (iii) a way to adapt the control inputs using minimal user-provided
prior knowledge about the dynamics/kinematics of the robot. We integrate REAL
in the autonomy stack of a real multirotor, querying onboard an offboard LLM at
0.1-1.0 Hz as part the robot's mission planning and control feedback loops. We
demonstrate in real-world experiments the ability of the LLM to reduce the
position tracking errors of a multirotor under the presence of (i) errors in
the parameters of the controller and (ii) unmodeled dynamics. We also show
(iii) decision making to avoid potentially dangerous scenarios (e.g., robot
oscillates) that had not been explicitly accounted for in the initial prompt
design.

---------------

### 12 Sep 2023 | [The Moral Machine Experiment on Large Language Models](https://arxiv.org/abs/2309.05958) | [⬇️](https://arxiv.org/pdf/2309.05958)
*Kazuhiro Takemoto* 

  As large language models (LLMs) become more deeply integrated into various
sectors, understanding how they make moral judgments has become crucial,
particularly in the realm of autonomous driving. This study utilized the Moral
Machine framework to investigate the ethical decision-making tendencies of
prominent LLMs, including GPT-3.5, GPT-4, PaLM 2, and Llama 2, comparing their
responses to human preferences. While LLMs' and humans' preferences such as
prioritizing humans over pets and favoring saving more lives are broadly
aligned, PaLM 2 and Llama 2, especially, evidence distinct deviations.
Additionally, despite the qualitative similarities between the LLM and human
preferences, there are significant quantitative disparities, suggesting that
LLMs might lean toward more uncompromising decisions, compared to the milder
inclinations of humans. These insights elucidate the ethical frameworks of LLMs
and their potential implications for autonomous driving.

---------------

### 25 Oct 2023 | [AgentBench: Evaluating LLMs as Agents](https://arxiv.org/abs/2308.03688) | [⬇️](https://arxiv.org/pdf/2308.03688)
*Xiao Liu, Hao Yu, Hanchen Zhang, Yifan Xu, Xuanyu Lei, Hanyu Lai, Yu  Gu, Hangliang Ding, Kaiwen Men, Kejuan Yang, Shudan Zhang, Xiang Deng, Aohan  Zeng, Zhengxiao Du, Chenhui Zhang, Sheng Shen, Tianjun Zhang, Yu Su, Huan  Sun, Minlie Huang, Yuxiao Dong, Jie Tang* 

  Large Language Models (LLMs) are becoming increasingly smart and autonomous,
targeting real-world pragmatic missions beyond traditional NLP tasks. As a
result, there has been an urgent need to evaluate LLMs as agents on challenging
tasks in interactive environments. We present AgentBench, a multi-dimensional
evolving benchmark that currently consists of 8 distinct environments to assess
LLM-as-Agent's reasoning and decision-making abilities in a multi-turn
open-ended generation setting. Our extensive test over 27 API-based and
open-sourced (OSS) LLMs shows that, while top commercial LLMs present a strong
ability of acting as agents in complex environments, there is a significant
disparity in performance between them and OSS competitors. We identify the
typical reasons of failures in environments and LLMs, showing that poor
long-term reasoning, decision-making, and instruction following abilities are
the main obstacles for developing usable LLM agents. Training on code and high
quality multi-turn alignment data could improve agent performance. Datasets,
environments, and an integrated evaluation package for AgentBench are released
at \url{https://github.com/THUDM/AgentBench}.

---------------

### 13 Oct 2023 | [Driving with LLMs: Fusing Object-Level Vector Modality for Explainable  Autonomous Driving](https://arxiv.org/abs/2310.01957) | [⬇️](https://arxiv.org/pdf/2310.01957)
*Long Chen, Oleg Sinavski, Jan H\"unermann, Alice Karnsund, Andrew  James Willmott, Danny Birch, Daniel Maund, Jamie Shotton* 

  Large Language Models (LLMs) have shown promise in the autonomous driving
sector, particularly in generalization and interpretability. We introduce a
unique object-level multimodal LLM architecture that merges vectorized numeric
modalities with a pre-trained LLM to improve context understanding in driving
situations. We also present a new dataset of 160k QA pairs derived from 10k
driving scenarios, paired with high quality control commands collected with RL
agent and question answer pairs generated by teacher LLM (GPT-3.5). A distinct
pretraining strategy is devised to align numeric vector modalities with static
LLM representations using vector captioning language data. We also introduce an
evaluation metric for Driving QA and demonstrate our LLM-driver's proficiency
in interpreting driving scenarios, answering questions, and decision-making.
Our findings highlight the potential of LLM-based driving action generation in
comparison to traditional behavioral cloning. We make our benchmark, datasets,
and model available for further exploration.

---------------

### 26 Nov 2023 | [AI-Augmented Surveys: Leveraging Large Language Models and Surveys for  Opinion Prediction](https://arxiv.org/abs/2305.09620) | [⬇️](https://arxiv.org/pdf/2305.09620)
*Junsol Kim, Byungkyu Lee* 

  Large language models (LLMs) that produce human-like responses have begun to
revolutionize research practices in the social sciences. This paper shows how
we can integrate LLMs and social surveys to accurately predict individual
responses to survey questions that were not asked before. We develop a novel
methodological framework to personalize LLMs by considering the meaning of
survey questions derived from their text, the latent beliefs of individuals
inferred from their response patterns, and the temporal contexts across
different survey periods through fine-tuning LLMs with survey data. Using the
General Social Survey from 1972 to 2021, we show that the fine-tuned model
based on Alpaca-7b can predict individual responses to survey questions that
are partially missing as well as entirely missing. The remarkable prediction
capabilities allow us to fill in missing trends with high confidence and
pinpoint when public attitudes changed, such as the rising support for same-sex
marriage. We discuss practical constraints, socio-demographic representation,
and ethical concerns regarding individual autonomy and privacy when using LLMs
for opinion prediction. This study demonstrates that LLMs and surveys can
mutually enhance each other's capabilities: LLMs broaden survey potential,
while surveys improve the alignment of LLMs.

---------------

### 27 Feb 2024 | [SoFA: Shielded On-the-fly Alignment via Priority Rule Following](https://arxiv.org/abs/2402.17358) | [⬇️](https://arxiv.org/pdf/2402.17358)
*Xinyu Lu, Bowen Yu, Yaojie Lu, Hongyu Lin, Haiyang Yu, Le Sun, Xianpei  Han, Yongbin Li* 

  The alignment problem in Large Language Models (LLMs) involves adapting them
to the broad spectrum of human values. This requirement challenges existing
alignment methods due to diversity of preferences and regulatory standards.
This paper introduces a novel alignment paradigm, priority rule following,
which defines rules as the primary control mechanism in each dialog,
prioritizing them over user instructions. Our preliminary analysis reveals that
even the advanced LLMs, such as GPT-4, exhibit shortcomings in understanding
and prioritizing the rules. Therefore, we present PriorityDistill, a
semi-automated approach for distilling priority following signals from LLM
simulations to ensure robust rule integration and adherence. Our experiments
show that this method not only effectively minimizes misalignments utilizing
only one general rule but also adapts smoothly to various unseen rules,
ensuring they are shielded from hijacking and that the model responds
appropriately.

---------------

### 03 Dec 2023 | [FinMem: A Performance-Enhanced LLM Trading Agent with Layered Memory and  Character Design](https://arxiv.org/abs/2311.13743) | [⬇️](https://arxiv.org/pdf/2311.13743)
*Yangyang Yu, Haohang Li, Zhi Chen, Yuechen Jiang, Yang Li, Denghui  Zhang, Rong Liu, Jordan W. Suchow, Khaldoun Khashanah* 

  Recent advancements in Large Language Models (LLMs) have exhibited notable
efficacy in question-answering (QA) tasks across diverse domains. Their prowess
in integrating extensive web knowledge has fueled interest in developing
LLM-based autonomous agents. While LLMs are efficient in decoding human
instructions and deriving solutions by holistically processing historical
inputs, transitioning to purpose-driven agents requires a supplementary
rational architecture to process multi-source information, establish reasoning
chains, and prioritize critical tasks. Addressing this, we introduce
\textsc{FinMem}, a novel LLM-based agent framework devised for financial
decision-making. It encompasses three core modules: Profiling, to customize the
agent's characteristics; Memory, with layered message processing, to aid the
agent in assimilating hierarchical financial data; and Decision-making, to
convert insights gained from memories into investment decisions. Notably,
\textsc{FinMem}'s memory module aligns closely with the cognitive structure of
human traders, offering robust interpretability and real-time tuning. Its
adjustable cognitive span allows for the retention of critical information
beyond human perceptual limits, thereby enhancing trading outcomes. This
framework enables the agent to self-evolve its professional knowledge, react
agilely to new investment cues, and continuously refine trading decisions in
the volatile financial environment. We first compare \textsc{FinMem} with
various algorithmic agents on a scalable real-world financial dataset,
underscoring its leading trading performance in stocks. We then fine-tuned the
agent's perceptual span and character setting to achieve a significantly
enhanced trading performance. Collectively, \textsc{FinMem} presents a
cutting-edge LLM agent framework for automated trading, boosting cumulative
investment returns.

---------------

### 04 Sep 2023 | [Robots That Ask For Help: Uncertainty Alignment for Large Language Model  Planners](https://arxiv.org/abs/2307.01928) | [⬇️](https://arxiv.org/pdf/2307.01928)
*Allen Z. Ren, Anushri Dixit, Alexandra Bodrova, Sumeet Singh, Stephen  Tu, Noah Brown, Peng Xu, Leila Takayama, Fei Xia, Jake Varley, Zhenjia Xu,  Dorsa Sadigh, Andy Zeng, Anirudha Majumdar* 

  Large language models (LLMs) exhibit a wide range of promising capabilities
-- from step-by-step planning to commonsense reasoning -- that may provide
utility for robots, but remain prone to confidently hallucinated predictions.
In this work, we present KnowNo, which is a framework for measuring and
aligning the uncertainty of LLM-based planners such that they know when they
don't know and ask for help when needed. KnowNo builds on the theory of
conformal prediction to provide statistical guarantees on task completion while
minimizing human help in complex multi-step planning settings. Experiments
across a variety of simulated and real robot setups that involve tasks with
different modes of ambiguity (e.g., from spatial to numeric uncertainties, from
human preferences to Winograd schemas) show that KnowNo performs favorably over
modern baselines (which may involve ensembles or extensive prompt tuning) in
terms of improving efficiency and autonomy, while providing formal assurances.
KnowNo can be used with LLMs out of the box without model-finetuning, and
suggests a promising lightweight approach to modeling uncertainty that can
complement and scale with the growing capabilities of foundation models.
Website: https://robot-help.github.io

---------------

### 05 Dec 2023 | [AlignBench: Benchmarking Chinese Alignment of Large Language Models](https://arxiv.org/abs/2311.18743) | [⬇️](https://arxiv.org/pdf/2311.18743)
*Xiao Liu, Xuanyu Lei, Shengyuan Wang, Yue Huang, Zhuoer Feng, Bosi  Wen, Jiale Cheng, Pei Ke, Yifan Xu, Weng Lam Tam, Xiaohan Zhang, Lichao Sun,  Hongning Wang, Jing Zhang, Minlie Huang, Yuxiao Dong, Jie Tang* 

  Alignment has become a critical step for instruction-tuned Large Language
Models (LLMs) to become helpful assistants. However, effective evaluation of
alignment for emerging Chinese LLMs is still significantly lacking, calling for
real-scenario grounded, open-ended, challenging and automatic evaluations
tailored for alignment. To fill in this gap, we introduce AlignBench, a
comprehensive multi-dimensional benchmark for evaluating LLMs' alignment in
Chinese. Equipped with a human-in-the-loop data curation pipeline, our
benchmark employs a rule-calibrated multi-dimensional LLM-as-Judge with
Chain-of-Thought to generate explanations and final ratings as evaluations,
ensuring high reliability and interpretability. Furthermore, we report
AlignBench evaluated by CritiqueLLM, a dedicated Chinese evaluator LLM that
recovers 95% of GPT-4's evaluation ability. We will provide public APIs for
evaluating AlignBench with CritiqueLLM to facilitate the evaluation of LLMs'
Chinese alignment. All evaluation codes, data, and LLM generations are
available at \url{https://github.com/THUDM/AlignBench}.

---------------

### 23 Feb 2024 | [Unlocking the Power of Large Language Models for Entity Alignment](https://arxiv.org/abs/2402.15048) | [⬇️](https://arxiv.org/pdf/2402.15048)
*Xuhui Jiang, Yinghan Shen, Zhichao Shi, Chengjin Xu, Wei Li, Zixuan  Li, Jian Guo, Huawei Shen, Yuanzhuo Wang* 

  Entity Alignment (EA) is vital for integrating diverse knowledge graph (KG)
data, playing a crucial role in data-driven AI applications. Traditional EA
methods primarily rely on comparing entity embeddings, but their effectiveness
is constrained by the limited input KG data and the capabilities of the
representation learning techniques. Against this backdrop, we introduce ChatEA,
an innovative framework that incorporates large language models (LLMs) to
improve EA. To address the constraints of limited input KG data, ChatEA
introduces a KG-code translation module that translates KG structures into a
format understandable by LLMs, thereby allowing LLMs to utilize their extensive
background knowledge to improve EA accuracy. To overcome the over-reliance on
entity embedding comparisons, ChatEA implements a two-stage EA strategy that
capitalizes on LLMs' capability for multi-step reasoning in a dialogue format,
thereby enhancing accuracy while preserving efficiency. Our experimental
results affirm ChatEA's superior performance, highlighting LLMs' potential in
facilitating EA tasks.

---------------

### 22 Dec 2022 | [Methodological reflections for AI alignment research using human  feedback](https://arxiv.org/abs/2301.06859) | [⬇️](https://arxiv.org/pdf/2301.06859)
*Thilo Hagendorff, Sarah Fabi* 

  The field of artificial intelligence (AI) alignment aims to investigate
whether AI technologies align with human interests and values and function in a
safe and ethical manner. AI alignment is particularly relevant for large
language models (LLMs), which have the potential to exhibit unintended behavior
due to their ability to learn and adapt in ways that are difficult to predict.
In this paper, we discuss methodological challenges for the alignment problem
specifically in the context of LLMs trained to summarize texts. In particular,
we focus on methods for collecting reliable human feedback on summaries to
train a reward model which in turn improves the summarization model. We
conclude by suggesting specific improvements in the experimental design of
alignment studies for LLMs' summarization capabilities.

---------------

### 06 Jan 2024 | [Human-Instruction-Free LLM Self-Alignment with Limited Samples](https://arxiv.org/abs/2401.06785) | [⬇️](https://arxiv.org/pdf/2401.06785)
*Hongyi Guo, Yuanshun Yao, Wei Shen, Jiaheng Wei, Xiaoying Zhang,  Zhaoran Wang, Yang Liu* 

  Aligning large language models (LLMs) with human values is a vital task for
LLM practitioners. Current alignment techniques have several limitations: (1)
requiring a large amount of annotated data; (2) demanding heavy human
involvement; (3) lacking a systematic mechanism to continuously improve. In
this work, we study aligning LLMs to a new domain with limited samples (e.g. <
100). We propose an algorithm that can self-align LLMs iteratively without
active human involvement. Unlike existing works, our algorithm relies on
neither human-crafted instructions nor labeled rewards, significantly reducing
human involvement. In addition, our algorithm can self-improve the alignment
continuously. The key idea is to first retrieve high-quality samples related to
the target domain and use them as In-context Learning examples to generate more
samples. Then we use the self-generated samples to finetune the LLM
iteratively. We show that our method can unlock the LLMs' self-generalization
ability to perform alignment with near-zero human supervision. We test our
algorithm on three benchmarks in safety, truthfulness, and
instruction-following, and show good performance in alignment, domain
adaptability, and scalability.

---------------

### 21 Sep 2023 | [You Only Look at Screens: Multimodal Chain-of-Action Agents](https://arxiv.org/abs/2309.11436) | [⬇️](https://arxiv.org/pdf/2309.11436)
*Zhuosheng Zhang, Aston Zhang* 

  Autonomous user interface (UI) agents aim to facilitate task automation by
interacting with the user interface without manual intervention. Recent studies
have investigated eliciting the capabilities of large language models (LLMs)
for effective engagement in diverse environments. To align with the
input-output requirement of LLMs, existing approaches are developed under a
sandbox setting where they rely on external tools and application-specific APIs
to parse the environment into textual elements and interpret the predicted
actions. Consequently, those approaches often grapple with inference
inefficiency and error propagation risks. To mitigate the challenges, we
introduce Auto-UI, a multimodal solution that directly interacts with the
interface, bypassing the need for environment parsing or reliance on
application-dependent APIs. Moreover, we propose a chain-of-action technique --
leveraging a series of intermediate previous action histories and future action
plans -- to help the agent decide what action to execute. We evaluate our
approach on a new device-control benchmark AITW with 30K unique instructions,
spanning multi-step tasks such as application operation, web searching, and web
shopping. Experimental results show that Auto-UI achieves state-of-the-art
performance with an action type prediction accuracy of 90% and an overall
action success rate of 74%. Code is publicly available at
https://github.com/cooelf/Auto-UI.

---------------

### 28 Nov 2023 | [Building the Future of Responsible AI: A Reference Architecture for  Designing Large Language Model based Agents](https://arxiv.org/abs/2311.13148) | [⬇️](https://arxiv.org/pdf/2311.13148)
*Qinghua Lu, Liming Zhu, Xiwei Xu, Zhenchang Xing, Stefan Harrer, Jon  Whittle* 

  Large language models (LLMs) have been widely recognised as transformative
artificial generative intelligence (AGI) technologies due to their capabilities
to understand and generate content, including plans with reasoning
capabilities. Foundation model based agents derive their autonomy from the
capabilities of foundation models, which enable them to autonomously break down
a given goal into a set of manageable tasks and orchestrate task execution to
meet the goal. Despite the huge efforts put into building foundation model
based autonomous agents, the architecture design of the agents has not yet been
systematically explored. Also, while there are significant benefits of using
autonomous agents for planning and execution, there are serious considerations
regarding responsible AI related software quality attributes, such as security
and accountability. Therefore, this paper presents a pattern-oriented reference
architecture that serves as architecture design guidance and enables
responsible-AI-by-design when designing foundation model based autonomous
agents. We evaluate the completeness and utility of the proposed reference
architecture by mapping it to the architecture of two real-world agents.

---------------

### 07 Feb 2024 | [Prioritizing Safeguarding Over Autonomy: Risks of LLM Agents for Science](https://arxiv.org/abs/2402.04247) | [⬇️](https://arxiv.org/pdf/2402.04247)
*Xiangru Tang, Qiao Jin, Kunlun Zhu, Tongxin Yuan, Yichi Zhang,  Wangchunshu Zhou, Meng Qu, Yilun Zhao, Jian Tang, Zhuosheng Zhang, Arman  Cohan, Zhiyong Lu, Mark Gerstein* 

  Intelligent agents powered by large language models (LLMs) have demonstrated
substantial promise in autonomously conducting experiments and facilitating
scientific discoveries across various disciplines. While their capabilities are
promising, they also introduce novel vulnerabilities that demand careful
consideration for safety. However, there exists a notable gap in the
literature, as there has been no comprehensive exploration of these
vulnerabilities. This position paper fills this gap by conducting a thorough
examination of vulnerabilities in LLM-based agents within scientific domains,
shedding light on potential risks associated with their misuse and emphasizing
the need for safety measures. We begin by providing a comprehensive overview of
the potential risks inherent to scientific LLM agents, taking into account user
intent, the specific scientific domain, and their potential impact on the
external environment. Then, we delve into the origins of these vulnerabilities
and provide a scoping review of the limited existing works. Based on our
analysis, we propose a triadic framework involving human regulation, agent
alignment, and an understanding of environmental feedback (agent regulation) to
mitigate these identified risks. Furthermore, we highlight the limitations and
challenges associated with safeguarding scientific agents and advocate for the
development of improved models, robust benchmarks, and comprehensive
regulations to address these issues effectively.

---------------

### 25 Jan 2024 | [MULTIVERSE: Exposing Large Language Model Alignment Problems in Diverse  Worlds](https://arxiv.org/abs/2402.01706) | [⬇️](https://arxiv.org/pdf/2402.01706)
*Xiaolong Jin, Zhuo Zhang, Xiangyu Zhang* 

  Large Language Model (LLM) alignment aims to ensure that LLM outputs match
with human values. Researchers have demonstrated the severity of alignment
problems with a large spectrum of jailbreak techniques that can induce LLMs to
produce malicious content during conversations. Finding the corresponding
jailbreaking prompts usually requires substantial human intelligence or
computation resources. In this paper, we report that LLMs have different levels
of alignment in various contexts. As such, by systematically constructing many
contexts, called worlds, leveraging a Domain Specific Language describing
possible worlds (e.g., time, location, characters, actions and languages) and
the corresponding compiler, we can cost-effectively expose latent alignment
issues. Given the low cost of our method, we are able to conduct a large scale
study regarding LLM alignment issues in different worlds. Our results show that
our method outperforms the-state-of-the-art jailbreaking techniques on both
effectiveness and efficiency. In addition, our results indicate that existing
LLMs are extremely vulnerable to nesting worlds and programming language
worlds. They imply that existing alignment training focuses on the real-world
and is lacking in various (virtual) worlds where LLMs can be exploited.

---------------
**Date:** 05 Oct 2023

**Title:** Balancing Autonomy and Alignment: A Multi-Dimensional Taxonomy for  Autonomous LLM-powered Multi-Agent Architectures

**Abstract Link:** [https://arxiv.org/abs/2310.03659](https://arxiv.org/abs/2310.03659)

**PDF Link:** [https://arxiv.org/pdf/2310.03659](https://arxiv.org/pdf/2310.03659)

---

**Date:** 14 Dec 2023

**Title:** CERN for AGI: A Theoretical Framework for Autonomous Simulation-Based  Artificial Intelligence Testing and Alignment

**Abstract Link:** [https://arxiv.org/abs/2312.09402](https://arxiv.org/abs/2312.09402)

**PDF Link:** [https://arxiv.org/pdf/2312.09402](https://arxiv.org/pdf/2312.09402)

---

**Date:** 30 Jan 2024

**Title:** Two Heads Are Better Than One: Integrating Knowledge from Knowledge  Graphs and Large Language Models for Entity Alignment

**Abstract Link:** [https://arxiv.org/abs/2401.16960](https://arxiv.org/abs/2401.16960)

**PDF Link:** [https://arxiv.org/pdf/2401.16960](https://arxiv.org/pdf/2401.16960)

---

**Date:** 25 Oct 2023

**Title:** Privately Aligning Language Models with Reinforcement Learning

**Abstract Link:** [https://arxiv.org/abs/2310.16960](https://arxiv.org/abs/2310.16960)

**PDF Link:** [https://arxiv.org/pdf/2310.16960](https://arxiv.org/pdf/2310.16960)

---

**Date:** 02 Nov 2023

**Title:** REAL: Resilience and Adaptation using Large Language Models on  Autonomous Aerial Robots

**Abstract Link:** [https://arxiv.org/abs/2311.01403](https://arxiv.org/abs/2311.01403)

**PDF Link:** [https://arxiv.org/pdf/2311.01403](https://arxiv.org/pdf/2311.01403)

---

**Date:** 12 Sep 2023

**Title:** The Moral Machine Experiment on Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2309.05958](https://arxiv.org/abs/2309.05958)

**PDF Link:** [https://arxiv.org/pdf/2309.05958](https://arxiv.org/pdf/2309.05958)

---

**Date:** 25 Oct 2023

**Title:** AgentBench: Evaluating LLMs as Agents

**Abstract Link:** [https://arxiv.org/abs/2308.03688](https://arxiv.org/abs/2308.03688)

**PDF Link:** [https://arxiv.org/pdf/2308.03688](https://arxiv.org/pdf/2308.03688)

---

**Date:** 13 Oct 2023

**Title:** Driving with LLMs: Fusing Object-Level Vector Modality for Explainable  Autonomous Driving

**Abstract Link:** [https://arxiv.org/abs/2310.01957](https://arxiv.org/abs/2310.01957)

**PDF Link:** [https://arxiv.org/pdf/2310.01957](https://arxiv.org/pdf/2310.01957)

---

**Date:** 26 Nov 2023

**Title:** AI-Augmented Surveys: Leveraging Large Language Models and Surveys for  Opinion Prediction

**Abstract Link:** [https://arxiv.org/abs/2305.09620](https://arxiv.org/abs/2305.09620)

**PDF Link:** [https://arxiv.org/pdf/2305.09620](https://arxiv.org/pdf/2305.09620)

---

**Date:** 27 Feb 2024

**Title:** SoFA: Shielded On-the-fly Alignment via Priority Rule Following

**Abstract Link:** [https://arxiv.org/abs/2402.17358](https://arxiv.org/abs/2402.17358)

**PDF Link:** [https://arxiv.org/pdf/2402.17358](https://arxiv.org/pdf/2402.17358)

---

**Date:** 03 Dec 2023

**Title:** FinMem: A Performance-Enhanced LLM Trading Agent with Layered Memory and  Character Design

**Abstract Link:** [https://arxiv.org/abs/2311.13743](https://arxiv.org/abs/2311.13743)

**PDF Link:** [https://arxiv.org/pdf/2311.13743](https://arxiv.org/pdf/2311.13743)

---

**Date:** 04 Sep 2023

**Title:** Robots That Ask For Help: Uncertainty Alignment for Large Language Model  Planners

**Abstract Link:** [https://arxiv.org/abs/2307.01928](https://arxiv.org/abs/2307.01928)

**PDF Link:** [https://arxiv.org/pdf/2307.01928](https://arxiv.org/pdf/2307.01928)

---

**Date:** 05 Dec 2023

**Title:** AlignBench: Benchmarking Chinese Alignment of Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2311.18743](https://arxiv.org/abs/2311.18743)

**PDF Link:** [https://arxiv.org/pdf/2311.18743](https://arxiv.org/pdf/2311.18743)

---

**Date:** 23 Feb 2024

**Title:** Unlocking the Power of Large Language Models for Entity Alignment

**Abstract Link:** [https://arxiv.org/abs/2402.15048](https://arxiv.org/abs/2402.15048)

**PDF Link:** [https://arxiv.org/pdf/2402.15048](https://arxiv.org/pdf/2402.15048)

---

**Date:** 22 Dec 2022

**Title:** Methodological reflections for AI alignment research using human  feedback

**Abstract Link:** [https://arxiv.org/abs/2301.06859](https://arxiv.org/abs/2301.06859)

**PDF Link:** [https://arxiv.org/pdf/2301.06859](https://arxiv.org/pdf/2301.06859)

---

**Date:** 06 Jan 2024

**Title:** Human-Instruction-Free LLM Self-Alignment with Limited Samples

**Abstract Link:** [https://arxiv.org/abs/2401.06785](https://arxiv.org/abs/2401.06785)

**PDF Link:** [https://arxiv.org/pdf/2401.06785](https://arxiv.org/pdf/2401.06785)

---

**Date:** 21 Sep 2023

**Title:** You Only Look at Screens: Multimodal Chain-of-Action Agents

**Abstract Link:** [https://arxiv.org/abs/2309.11436](https://arxiv.org/abs/2309.11436)

**PDF Link:** [https://arxiv.org/pdf/2309.11436](https://arxiv.org/pdf/2309.11436)

---

**Date:** 28 Nov 2023

**Title:** Building the Future of Responsible AI: A Reference Architecture for  Designing Large Language Model based Agents

**Abstract Link:** [https://arxiv.org/abs/2311.13148](https://arxiv.org/abs/2311.13148)

**PDF Link:** [https://arxiv.org/pdf/2311.13148](https://arxiv.org/pdf/2311.13148)

---

**Date:** 07 Feb 2024

**Title:** Prioritizing Safeguarding Over Autonomy: Risks of LLM Agents for Science

**Abstract Link:** [https://arxiv.org/abs/2402.04247](https://arxiv.org/abs/2402.04247)

**PDF Link:** [https://arxiv.org/pdf/2402.04247](https://arxiv.org/pdf/2402.04247)

---

**Date:** 25 Jan 2024

**Title:** MULTIVERSE: Exposing Large Language Model Alignment Problems in Diverse  Worlds

**Abstract Link:** [https://arxiv.org/abs/2402.01706](https://arxiv.org/abs/2402.01706)

**PDF Link:** [https://arxiv.org/pdf/2402.01706](https://arxiv.org/pdf/2402.01706)

---

