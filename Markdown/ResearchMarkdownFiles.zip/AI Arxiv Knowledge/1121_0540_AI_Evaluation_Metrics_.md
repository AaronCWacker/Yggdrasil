AI Evaluation Metrics 📌

### 🔎 AI Evaluation Metrics 📌



1. Precision:
- Precision is the ratio of correctly predicted positive observations to the total predicted positives.
- High precision relates to the low false positive rate.
- In simple words, precision is the measure of relevancy of the result.

2. Recall (Sensitivity):
- Recall (Sensitivity) is the ratio of correctly predicted positive observations to the all observations in actual class.
- High recall relates to the low false negative rate.
- In simple words, recall is the measure of completeness of the result.

3. F1 Score:
- F1 Score is the weighted average of Precision and Recall.
- It tries to find the balance between precision and recall.

4. Accuracy:
- Accuracy is the ratio of correctly predicted observation to the total observations.
- High accuracy relates to the low error rate.
- In simple words, accuracy is the proportion of true results (both true positives and true negatives) among the total number of cases examined.

5. Specificity:
- Specificity is the ratio of correctly predicted negative observations to the all observations in actual class.
- High specificity relates to the low false positive rate.
- In simple words, specificity is the measure of the test's ability to correctly identify those with a negative outcome.

6. Confusion Matrix:
- A table used to describe the performance of a classification model (or "classifier") on a set of test data for which the true values are known.
- It allows visualization of the performance of an algorithm.
- It can be used to derive other metrics such as accuracy, precision, recall, F1 score, specificity etc.

7. ROC Curve:
- A plot of the true positive rate (TPR) against the false positive rate (FPR) for a binary classifier system as its discrimination threshold is varied.
- It shows the tradeoff between sensitivity and specificity.
- It can be used to derive other metrics such as accuracy, precision, recall, F1 score, specificity etc.

8. AUC:
- AUC stands for Area Under Curve.
- AUC represents degree or measure of separability.
- It tells how much model is capable of distinguishing between classes.
- Higher the AUC, better
# 🩺🔍 Search Results
### 25 Oct 2023 | [On the stability, correctness and plausibility of visual explanation  methods based on feature importance](https://arxiv.org/abs/2311.12860) | [⬇️](https://arxiv.org/pdf/2311.12860)
*Romain Xu-Darme (LSL, LIG), Jenny Benois-Pineau (LaBRI), Romain Giot  (LaBRI), Georges Qu\'enot (LIG), Zakaria Chihani (LSL), Marie-Christine  Rousset (LIG), Alexey Zhukov (LaBRI)* 

  In the field of Explainable AI, multiples evaluation metrics have been
proposed in order to assess the quality of explanation methods w.r.t. a set of
desired properties. In this work, we study the articulation between the
stability, correctness and plausibility of explanations based on feature
importance for image classifiers. We show that the existing metrics for
evaluating these properties do not always agree, raising the issue of what
constitutes a good evaluation metric for explanations. Finally, in the
particular case of stability and correctness, we show the possible limitations
of some evaluation metrics and propose new ones that take into account the
local behaviour of the model under test.

---------------

### 06 Aug 2023 | [Precise Benchmarking of Explainable AI Attribution Methods](https://arxiv.org/abs/2308.03161) | [⬇️](https://arxiv.org/pdf/2308.03161)
*Rafa\"el Brandt, Daan Raatjens, Georgi Gaydadjiev* 

  The rationale behind a deep learning model's output is often difficult to
understand by humans. EXplainable AI (XAI) aims at solving this by developing
methods that improve interpretability and explainability of machine learning
models. Reliable evaluation metrics are needed to assess and compare different
XAI methods. We propose a novel evaluation approach for benchmarking
state-of-the-art XAI attribution methods. Our proposal consists of a synthetic
classification model accompanied by its derived ground truth explanations
allowing high precision representation of input nodes contributions. We also
propose new high-fidelity metrics to quantify the difference between
explanations of the investigated XAI method and those derived from the
synthetic model. Our metrics allow assessment of explanations in terms of
precision and recall separately. Also, we propose metrics to independently
evaluate negative or positive contributions of inputs. Our proposal provides
deeper insights into XAI methods output. We investigate our proposal by
constructing a synthetic convolutional image classification model and
benchmarking several widely used XAI attribution methods using our evaluation
approach. We compare our results with established prior XAI evaluation metrics.
By deriving the ground truth directly from the constructed model in our method,
we ensure the absence of bias, e.g., subjective either based on the training
set. Our experimental results provide novel insights into the performance of
Guided-Backprop and Smoothgrad XAI methods that are widely in use. Both have
good precision and recall scores among positively contributing pixels (0.7,
0.76 and 0.7, 0.77, respectively), but poor precision scores among negatively
contributing pixels (0.44, 0.61 and 0.47, 0.75, resp.). The recall scores in
the latter case remain close. We show that our metrics are among the fastest in
terms of execution time.

---------------

### 25 May 2023 | [An Experimental Investigation into the Evaluation of Explainability  Methods](https://arxiv.org/abs/2305.16361) | [⬇️](https://arxiv.org/pdf/2305.16361)
*S\'edrick Stassin, Alexandre Englebert, G\'eraldin Nanfack, Julien  Albert, Nassim Versbraegen, Gilles Peiffer, Miriam Doh, Nicolas Riche,  Beno\^it Frenay, Christophe De Vleeschouwer* 

  EXplainable Artificial Intelligence (XAI) aims to help users to grasp the
reasoning behind the predictions of an Artificial Intelligence (AI) system.
Many XAI approaches have emerged in recent years. Consequently, a subfield
related to the evaluation of XAI methods has gained considerable attention,
with the aim to determine which methods provide the best explanation using
various approaches and criteria. However, the literature lacks a comparison of
the evaluation metrics themselves, that one can use to evaluate XAI methods.
This work aims to fill this gap by comparing 14 different metrics when applied
to nine state-of-the-art XAI methods and three dummy methods (e.g., random
saliency maps) used as references. Experimental results show which of these
metrics produces highly correlated results, indicating potential redundancy. We
also demonstrate the significant impact of varying the baseline hyperparameter
on the evaluation metric values. Finally, we use dummy methods to assess the
reliability of metrics in terms of ranking, pointing out their limitations.

---------------

### 04 Aug 2021 | [Ensemble of MRR and NDCG models for Visual Dialog](https://arxiv.org/abs/2104.07511) | [⬇️](https://arxiv.org/pdf/2104.07511)
*Idan Schwartz* 

  Assessing an AI agent that can converse in human language and understand
visual content is challenging. Generation metrics, such as BLEU scores favor
correct syntax over semantics. Hence a discriminative approach is often used,
where an agent ranks a set of candidate options. The mean reciprocal rank (MRR)
metric evaluates the model performance by taking into account the rank of a
single human-derived answer. This approach, however, raises a new challenge:
the ambiguity and synonymy of answers, for instance, semantic equivalence
(e.g., `yeah' and `yes'). To address this, the normalized discounted cumulative
gain (NDCG) metric has been used to capture the relevance of all the correct
answers via dense annotations. However, the NDCG metric favors the usually
applicable uncertain answers such as `I don't know. Crafting a model that
excels on both MRR and NDCG metrics is challenging. Ideally, an AI agent should
answer a human-like reply and validate the correctness of any answer. To
address this issue, we describe a two-step non-parametric ranking approach that
can merge strong MRR and NDCG models. Using our approach, we manage to keep
most MRR state-of-the-art performance (70.41% vs. 71.24%) and the NDCG
state-of-the-art performance (72.16% vs. 75.35%). Moreover, our approach won
the recent Visual Dialog 2020 challenge. Source code is available at
https://github.com/idansc/mrr-ndcg.

---------------

### 04 Jun 2018 | [Shallow decision-making analysis in General Video Game Playing](https://arxiv.org/abs/1806.01151) | [⬇️](https://arxiv.org/pdf/1806.01151)
*Ivan Bravi, Jialin Liu, Diego Perez-Liebana, Simon Lucas* 

  The General Video Game AI competitions have been the testing ground for
several techniques for game playing, such as evolutionary computation
techniques, tree search algorithms, hyper heuristic based or knowledge based
algorithms. So far the metrics used to evaluate the performance of agents have
been win ratio, game score and length of games. In this paper we provide a
wider set of metrics and a comparison method for evaluating and comparing
agents. The metrics and the comparison method give shallow introspection into
the agent's decision making process and they can be applied to any agent
regardless of its algorithmic nature. In this work, the metrics and the
comparison method are used to measure the impact of the terms that compose a
tree policy of an MCTS based agent, comparing with several baseline agents. The
results clearly show how promising such general approach is and how it can be
useful to understand the behaviour of an AI agent, in particular, how the
comparison with baseline agents can help understanding the shape of the agent
decision landscape. The presented metrics and comparison method represent a
step toward to more descriptive ways of logging and analysing agent's
behaviours.

---------------

### 06 Apr 2020 | [A Neuro-AI Interface for Evaluating Generative Adversarial Networks](https://arxiv.org/abs/2003.03193) | [⬇️](https://arxiv.org/pdf/2003.03193)
*Zhengwei Wang, Qi She, Alan F. Smeaton, Tomas E. Ward, Graham Healy* 

  Generative adversarial networks (GANs) are increasingly attracting attention
in the computer vision, natural language processing, speech synthesis and
similar domains. However, evaluating the performance of GANs is still an open
and challenging problem. Existing evaluation metrics primarily measure the
dissimilarity between real and generated images using automated statistical
methods. They often require large sample sizes for evaluation and do not
directly reflect human perception of image quality. In this work, we introduce
an evaluation metric called Neuroscore, for evaluating the performance of GANs,
that more directly reflects psychoperceptual image quality through the
utilization of brain signals. Our results show that Neuroscore has superior
performance to the current evaluation metrics in that: (1) It is more
consistent with human judgment; (2) The evaluation process needs much smaller
numbers of samples; and (3) It is able to rank the quality of images on a per
GAN basis. A convolutional neural network (CNN) based neuro-AI interface is
proposed to predict Neuroscore from GAN-generated images directly without the
need for neural responses. Importantly, we show that including neural responses
during the training phase of the network can significantly improve the
prediction capability of the proposed model. Codes and data can be referred at
this link: https://github.com/villawang/Neuro-AI-Interface.

---------------

### 21 Jan 2023 | [Evaluation of Explanation Methods of AI -- CNNs in Image Classification  Tasks with Reference-based and No-reference Metrics](https://arxiv.org/abs/2212.01222) | [⬇️](https://arxiv.org/pdf/2212.01222)
*A. Zhukov, J. Benois-Pineau, R. Giot* 

  The most popular methods in AI-machine learning paradigm are mainly black
boxes. This is why explanation of AI decisions is of emergency. Although
dedicated explanation tools have been massively developed, the evaluation of
their quality remains an open research question. In this paper, we generalize
the methodologies of evaluation of post-hoc explainers of CNNs' decisions in
visual classification tasks with reference and no-reference based metrics. We
apply them on our previously developed explainers (FEM, MLFEM), and popular
Grad-CAM. The reference-based metrics are Pearson correlation coefficient and
Similarity computed between the explanation map and its ground truth
represented by a Gaze Fixation Density Map obtained with a psycho-visual
experiment. As a no-reference metric, we use stability metric, proposed by
Alvarez-Melis and Jaakkola. We study its behaviour, consensus with
reference-based metrics and show that in case of several kinds of degradation
on input images, this metric is in agreement with reference-based ones.
Therefore, it can be used for evaluation of the quality of explainers when the
ground truth is not available.

---------------

### 06 Aug 2023 | [Empirical Optimal Risk to Quantify Model Trustworthiness for Failure  Detection](https://arxiv.org/abs/2308.03179) | [⬇️](https://arxiv.org/pdf/2308.03179)
*Shuang Ao, Stefan Rueger, Advaith Siddharthan* 

  Failure detection (FD) in AI systems is a crucial safeguard for the
deployment for safety-critical tasks. The common evaluation method of FD
performance is the Risk-coverage (RC) curve, which reveals the trade-off
between the data coverage rate and the performance on accepted data. One common
way to quantify the RC curve by calculating the area under the RC curve.
However, this metric does not inform on how suited any method is for FD, or
what the optimal coverage rate should be. As FD aims to achieve higher
performance with fewer data discarded, evaluating with partial coverage
excluding the most uncertain samples is more intuitive and meaningful than full
coverage. In addition, there is an optimal point in the coverage where the
model could achieve ideal performance theoretically. We propose the Excess Area
Under the Optimal RC Curve (E-AUoptRC), with the area in coverage from the
optimal point to the full coverage. Further, the model performance at this
optimal point can represent both model learning ability and calibration. We
propose it as the Trust Index (TI), a complementary evaluation metric to the
overall model accuracy. We report extensive experiments on three benchmark
image datasets with ten variants of transformer and CNN models. Our results
show that our proposed methods can better reflect the model trustworthiness
than existing evaluation metrics. We further observe that the model with high
overall accuracy does not always yield the high TI, which indicates the
necessity of the proposed Trust Index as a complementary metric to the model
overall accuracy. The code are available at
\url{https://github.com/AoShuang92/optimal_risk}.

---------------

### 29 Sep 2021 | [An Empirical Study of Accuracy, Fairness, Explainability, Distributional  Robustness, and Adversarial Robustness](https://arxiv.org/abs/2109.14653) | [⬇️](https://arxiv.org/pdf/2109.14653)
*Moninder Singh, Gevorg Ghalachyan, Kush R. Varshney, Reginald E.  Bryant* 

  To ensure trust in AI models, it is becoming increasingly apparent that
evaluation of models must be extended beyond traditional performance metrics,
like accuracy, to other dimensions, such as fairness, explainability,
adversarial robustness, and distribution shift. We describe an empirical study
to evaluate multiple model types on various metrics along these dimensions on
several datasets. Our results show that no particular model type performs well
on all dimensions, and demonstrate the kinds of trade-offs involved in
selecting models evaluated along multiple dimensions.

---------------

### 17 Feb 2024 | [Leveraging Professional Radiologists' Expertise to Enhance LLMs'  Evaluation for Radiology Reports](https://arxiv.org/abs/2401.16578) | [⬇️](https://arxiv.org/pdf/2401.16578)
*Qingqing Zhu, Xiuying Chen, Qiao Jin, Benjamin Hou, Tejas Sudharshan  Mathai, Pritam Mukherjee, Xin Gao, Ronald M Summers, Zhiyong Lu* 

  In radiology, Artificial Intelligence (AI) has significantly advanced report
generation, but automatic evaluation of these AI-produced reports remains
challenging. Current metrics, such as Conventional Natural Language Generation
(NLG) and Clinical Efficacy (CE), often fall short in capturing the semantic
intricacies of clinical contexts or overemphasize clinical details, undermining
report clarity. To overcome these issues, our proposed method synergizes the
expertise of professional radiologists with Large Language Models (LLMs), like
GPT-3.5 and GPT-4 1. Utilizing In-Context Instruction Learning (ICIL) and Chain
of Thought (CoT) reasoning, our approach aligns LLM evaluations with
radiologist standards, enabling detailed comparisons between human and AI
generated reports. This is further enhanced by a Regression model that
aggregates sentence evaluation scores. Experimental results show that our
"Detailed GPT-4 (5-shot)" model achieves a 0.48 score, outperforming the METEOR
metric by 0.19, while our "Regressed GPT-4" model shows even greater alignment
with expert evaluations, exceeding the best existing metric by a 0.35 margin.
Moreover, the robustness of our explanations has been validated through a
thorough iterative strategy. We plan to publicly release annotations from
radiology experts, setting a new standard for accuracy in future assessments.
This underscores the potential of our approach in enhancing the quality
assessment of AI-driven medical reports.

---------------

### 26 Aug 2023 | [A Comprehensive Survey for Evaluation Methodologies of AI-Generated  Music](https://arxiv.org/abs/2308.13736) | [⬇️](https://arxiv.org/pdf/2308.13736)
*Zeyu Xiong, Weitao Wang, Jing Yu, Yue Lin, Ziyan Wang* 

  In recent years, AI-generated music has made significant progress, with
several models performing well in multimodal and complex musical genres and
scenes. While objective metrics can be used to evaluate generative music, they
often lack interpretability for musical evaluation. Therefore, researchers
often resort to subjective user studies to assess the quality of the generated
works, which can be resource-intensive and less reproducible than objective
metrics. This study aims to comprehensively evaluate the subjective, objective,
and combined methodologies for assessing AI-generated music, highlighting the
advantages and disadvantages of each approach. Ultimately, this study provides
a valuable reference for unifying generative AI in the field of music
evaluation.

---------------

### 18 Jul 2016 | [Performance Based Evaluation of Various Machine Learning Classification  Techniques for Chronic Kidney Disease Diagnosis](https://arxiv.org/abs/1606.09581) | [⬇️](https://arxiv.org/pdf/1606.09581)
*Sahil Sharma, Vinod Sharma and Atul Sharma* 

  Areas where Artificial Intelligence (AI) & related fields are finding their
applications are increasing day by day, moving from core areas of computer
science they are finding their applications in various other domains.In recent
times Machine Learning i.e. a sub-domain of AI has been widely used in order to
assist medical experts and doctors in the prediction, diagnosis and prognosis
of various diseases and other medical disorders. In this manuscript the authors
applied various machine learning algorithms to a problem in the domain of
medical diagnosis and analyzed their efficiency in predicting the results. The
problem selected for the study is the diagnosis of the Chronic Kidney
Disease.The dataset used for the study consists of 400 instances and 24
attributes. The authors evaluated 12 classification techniques by applying them
to the Chronic Kidney Disease data. In order to calculate efficiency, results
of the prediction by candidate methods were compared with the actual medical
results of the subject.The various metrics used for performance evaluation are
predictive accuracy, precision, sensitivity and specificity. The results
indicate that decision-tree performed best with nearly the accuracy of 98.6%,
sensitivity of 0.9720, precision of 1 and specificity of 1.

---------------

### 08 May 2023 | [Learning to Evaluate the Artness of AI-generated Images](https://arxiv.org/abs/2305.04923) | [⬇️](https://arxiv.org/pdf/2305.04923)
*Junyu Chen, Jie An, Hanjia Lyu, Jiebo Luo* 

  Assessing the artness of AI-generated images continues to be a challenge
within the realm of image generation. Most existing metrics cannot be used to
perform instance-level and reference-free artness evaluation. This paper
presents ArtScore, a metric designed to evaluate the degree to which an image
resembles authentic artworks by artists (or conversely photographs), thereby
offering a novel approach to artness assessment. We first blend pre-trained
models for photo and artwork generation, resulting in a series of mixed models.
Subsequently, we utilize these mixed models to generate images exhibiting
varying degrees of artness with pseudo-annotations. Each photorealistic image
has a corresponding artistic counterpart and a series of interpolated images
that range from realistic to artistic. This dataset is then employed to train a
neural network that learns to estimate quantized artness levels of arbitrary
images. Extensive experiments reveal that the artness levels predicted by
ArtScore align more closely with human artistic evaluation than existing
evaluation metrics, such as Gram loss and ArtFID.

---------------

### 26 Jan 2024 | [A structured regression approach for evaluating model performance across  intersectional subgroups](https://arxiv.org/abs/2401.14893) | [⬇️](https://arxiv.org/pdf/2401.14893)
*Christine Herlihy, Kimberly Truong, Alexandra Chouldechova, Miroslav  Dudik* 

  Disaggregated evaluation is a central task in AI fairness assessment, with
the goal to measure an AI system's performance across different subgroups
defined by combinations of demographic or other sensitive attributes. The
standard approach is to stratify the evaluation data across subgroups and
compute performance metrics separately for each group. However, even for
moderately-sized evaluation datasets, sample sizes quickly get small once
considering intersectional subgroups, which greatly limits the extent to which
intersectional groups are considered in many disaggregated evaluations. In this
work, we introduce a structured regression approach to disaggregated evaluation
that we demonstrate can yield reliable system performance estimates even for
very small subgroups. We also provide corresponding inference strategies for
constructing confidence intervals and explore how goodness-of-fit testing can
yield insight into the structure of fairness-related harms experienced by
intersectional groups. We evaluate our approach on two publicly available
datasets, and several variants of semi-synthetic data. The results show that
our method is considerably more accurate than the standard approach, especially
for small subgroups, and goodness-of-fit testing helps identify the key factors
that drive differences in performance.

---------------

### 23 Jan 2024 | [AIGCBench: Comprehensive Evaluation of Image-to-Video Content Generated  by AI](https://arxiv.org/abs/2401.01651) | [⬇️](https://arxiv.org/pdf/2401.01651)
*Fanda Fan, Chunjie Luo, Wanling Gao, Jianfeng Zhan* 

  The burgeoning field of Artificial Intelligence Generated Content (AIGC) is
witnessing rapid advancements, particularly in video generation. This paper
introduces AIGCBench, a pioneering comprehensive and scalable benchmark
designed to evaluate a variety of video generation tasks, with a primary focus
on Image-to-Video (I2V) generation. AIGCBench tackles the limitations of
existing benchmarks, which suffer from a lack of diverse datasets, by including
a varied and open-domain image-text dataset that evaluates different
state-of-the-art algorithms under equivalent conditions. We employ a novel text
combiner and GPT-4 to create rich text prompts, which are then used to generate
images via advanced Text-to-Image models. To establish a unified evaluation
framework for video generation tasks, our benchmark includes 11 metrics
spanning four dimensions to assess algorithm performance. These dimensions are
control-video alignment, motion effects, temporal consistency, and video
quality. These metrics are both reference video-dependent and video-free,
ensuring a comprehensive evaluation strategy. The evaluation standard proposed
correlates well with human judgment, providing insights into the strengths and
weaknesses of current I2V algorithms. The findings from our extensive
experiments aim to stimulate further research and development in the I2V field.
AIGCBench represents a significant step toward creating standardized benchmarks
for the broader AIGC landscape, proposing an adaptable and equitable framework
for future assessments of video generation tasks. We have open-sourced the
dataset and evaluation code on the project website:
https://www.benchcouncil.org/AIGCBench.

---------------

### 28 Nov 2023 | [Extending CAM-based XAI methods for Remote Sensing Imagery Segmentation](https://arxiv.org/abs/2310.01837) | [⬇️](https://arxiv.org/pdf/2310.01837)
*Abdul Karim Gizzini, Mustafa Shukor and Ali J. Ghandour* 

  Current AI-based methods do not provide comprehensible physical
interpretations of the utilized data, extracted features, and
predictions/inference operations. As a result, deep learning models trained
using high-resolution satellite imagery lack transparency and explainability
and can be merely seen as a black box, which limits their wide-level adoption.
Experts need help understanding the complex behavior of AI models and the
underlying decision-making process. The explainable artificial intelligence
(XAI) field is an emerging field providing means for robust, practical, and
trustworthy deployment of AI models. Several XAI techniques have been proposed
for image classification tasks, whereas the interpretation of image
segmentation remains largely unexplored. This paper offers to bridge this gap
by adapting the recent XAI classification algorithms and making them usable for
muti-class image segmentation, where we mainly focus on buildings' segmentation
from high-resolution satellite images. To benchmark and compare the performance
of the proposed approaches, we introduce a new XAI evaluation methodology and
metric based on "Entropy" to measure the model uncertainty. Conventional XAI
evaluation methods rely mainly on feeding area-of-interest regions from the
image back to the pre-trained (utility) model and then calculating the average
change in the probability of the target class. Those evaluation metrics lack
the needed robustness, and we show that using Entropy to monitor the model
uncertainty in segmenting the pixels within the target class is more suitable.
We hope this work will pave the way for additional XAI research for image
segmentation and applications in the remote sensing discipline.

---------------

### 03 Feb 2020 | [Synthetic-Neuroscore: Using A Neuro-AI Interface for Evaluating  Generative Adversarial Networks](https://arxiv.org/abs/1905.04243) | [⬇️](https://arxiv.org/pdf/1905.04243)
*Zhengwei Wang, Qi She, Alan F. Smeaton, Tomas E. Ward, Graham Healy* 

  Generative adversarial networks (GANs) are increasingly attracting attention
in the computer vision, natural language processing, speech synthesis and
similar domains. Arguably the most striking results have been in the area of
image synthesis. However, evaluating the performance of GANs is still an open
and challenging problem. Existing evaluation metrics primarily measure the
dissimilarity between real and generated images using automated statistical
methods. They often require large sample sizes for evaluation and do not
directly reflect human perception of image quality. In this work, we describe
an evaluation metric we call Neuroscore, for evaluating the performance of
GANs, that more directly reflects psychoperceptual image quality through the
utilization of brain signals. Our results show that Neuroscore has superior
performance to the current evaluation metrics in that: (1) It is more
consistent with human judgment; (2) The evaluation process needs much smaller
numbers of samples; and (3) It is able to rank the quality of images on a per
GAN basis. A convolutional neural network (CNN) based neuro-AI interface is
proposed to predict Neuroscore from GAN-generated images directly without the
need for neural responses. Importantly, we show that including neural responses
during the training phase of the network can significantly improve the
prediction capability of the proposed model. Materials related to this work are
provided at https://github.com/villawang/Neuro-AI-Interface.

---------------

### 13 Sep 2022 | [Gradient Episodic Memory for Continual Learning](https://arxiv.org/abs/1706.08840) | [⬇️](https://arxiv.org/pdf/1706.08840)
*David Lopez-Paz and Marc'Aurelio Ranzato* 

  One major obstacle towards AI is the poor ability of models to solve new
problems quicker, and without forgetting previously acquired knowledge. To
better understand this issue, we study the problem of continual learning, where
the model observes, once and one by one, examples concerning a sequence of
tasks. First, we propose a set of metrics to evaluate models learning over a
continuum of data. These metrics characterize models not only by their test
accuracy, but also in terms of their ability to transfer knowledge across
tasks. Second, we propose a model for continual learning, called Gradient
Episodic Memory (GEM) that alleviates forgetting, while allowing beneficial
transfer of knowledge to previous tasks. Our experiments on variants of the
MNIST and CIFAR-100 datasets demonstrate the strong performance of GEM when
compared to the state-of-the-art.

---------------

### 11 Jan 2021 | [PyHealth: A Python Library for Health Predictive Models](https://arxiv.org/abs/2101.04209) | [⬇️](https://arxiv.org/pdf/2101.04209)
*Yue Zhao, Zhi Qiao, Cao Xiao, Lucas Glass, Jimeng Sun* 

  Despite the explosion of interest in healthcare AI research, the
reproducibility and benchmarking of those research works are often limited due
to the lack of standard benchmark datasets and diverse evaluation metrics. To
address this reproducibility challenge, we develop PyHealth, an open-source
Python toolbox for developing various predictive models on healthcare data.
  PyHealth consists of data preprocessing module, predictive modeling module,
and evaluation module. The target users of PyHealth are both computer science
researchers and healthcare data scientists. With PyHealth, they can conduct
complex machine learning pipelines on healthcare datasets with fewer than ten
lines of code. The data preprocessing module enables the transformation of
complex healthcare datasets such as longitudinal electronic health records,
medical images, continuous signals (e.g., electrocardiogram), and clinical
notes into machine learning friendly formats. The predictive modeling module
provides more than 30 machine learning models, including established ensemble
trees and deep neural network-based approaches, via a unified but extendable
API designed for both researchers and practitioners. The evaluation module
provides various evaluation strategies (e.g., cross-validation and
train-validation-test split) and predictive model metrics.
  With robustness and scalability in mind, best practices such as unit testing,
continuous integration, code coverage, and interactive examples are introduced
in the library's development. PyHealth can be installed through the Python
Package Index (PyPI) or https://github.com/yzhao062/PyHealth .

---------------

### 24 Jan 2024 | [Can I trust my fake data -- A comprehensive quality assessment framework  for synthetic tabular data in healthcare](https://arxiv.org/abs/2401.13716) | [⬇️](https://arxiv.org/pdf/2401.13716)
*Vibeke Binz Vallevik, Aleksandar Babic, Serena Elizabeth Marshall,  Severin Elvatun, Helga Br{\o}gger, Sharmini Alagaratnam, Bj{\o}rn Edwin,  Narasimha Raghavan Veeraragavan, Anne Kjersti Befring, Jan Franz Nyg{\aa}rd* 

  Ensuring safe adoption of AI tools in healthcare hinges on access to
sufficient data for training, testing and validation. In response to privacy
concerns and regulatory requirements, using synthetic data has been suggested.
Synthetic data is created by training a generator on real data to produce a
dataset with similar statistical properties. Competing metrics with differing
taxonomies for quality evaluation have been suggested, resulting in a complex
landscape. Optimising quality entails balancing considerations that make the
data fit for use, yet relevant dimensions are left out of existing frameworks.
We performed a comprehensive literature review on the use of quality evaluation
metrics on SD within the scope of tabular healthcare data and SD made using
deep generative methods. Based on this and the collective team experiences, we
developed a conceptual framework for quality assurance. The applicability was
benchmarked against a practical case from the Dutch National Cancer Registry.
We present a conceptual framework for quality assurance of SD for AI
applications in healthcare that aligns diverging taxonomies, expands on common
quality dimensions to include the dimensions of Fairness and Carbon footprint,
and proposes stages necessary to support real-life applications. Building trust
in synthetic data by increasing transparency and reducing the safety risk will
accelerate the development and uptake of trustworthy AI tools for the benefit
of patients. Despite the growing emphasis on algorithmic fairness and carbon
footprint, these metrics were scarce in the literature review. The overwhelming
focus was on statistical similarity using distance metrics while sequential
logic detection was scarce. A consensus-backed framework that includes all
relevant quality dimensions can provide assurance for safe and responsible
real-life applications of SD.

---------------
**Date:** 25 Oct 2023

**Title:** On the stability, correctness and plausibility of visual explanation  methods based on feature importance

**Abstract Link:** [https://arxiv.org/abs/2311.12860](https://arxiv.org/abs/2311.12860)

**PDF Link:** [https://arxiv.org/pdf/2311.12860](https://arxiv.org/pdf/2311.12860)

---

**Date:** 06 Aug 2023

**Title:** Precise Benchmarking of Explainable AI Attribution Methods

**Abstract Link:** [https://arxiv.org/abs/2308.03161](https://arxiv.org/abs/2308.03161)

**PDF Link:** [https://arxiv.org/pdf/2308.03161](https://arxiv.org/pdf/2308.03161)

---

**Date:** 25 May 2023

**Title:** An Experimental Investigation into the Evaluation of Explainability  Methods

**Abstract Link:** [https://arxiv.org/abs/2305.16361](https://arxiv.org/abs/2305.16361)

**PDF Link:** [https://arxiv.org/pdf/2305.16361](https://arxiv.org/pdf/2305.16361)

---

**Date:** 04 Aug 2021

**Title:** Ensemble of MRR and NDCG models for Visual Dialog

**Abstract Link:** [https://arxiv.org/abs/2104.07511](https://arxiv.org/abs/2104.07511)

**PDF Link:** [https://arxiv.org/pdf/2104.07511](https://arxiv.org/pdf/2104.07511)

---

**Date:** 04 Jun 2018

**Title:** Shallow decision-making analysis in General Video Game Playing

**Abstract Link:** [https://arxiv.org/abs/1806.01151](https://arxiv.org/abs/1806.01151)

**PDF Link:** [https://arxiv.org/pdf/1806.01151](https://arxiv.org/pdf/1806.01151)

---

**Date:** 06 Apr 2020

**Title:** A Neuro-AI Interface for Evaluating Generative Adversarial Networks

**Abstract Link:** [https://arxiv.org/abs/2003.03193](https://arxiv.org/abs/2003.03193)

**PDF Link:** [https://arxiv.org/pdf/2003.03193](https://arxiv.org/pdf/2003.03193)

---

**Date:** 21 Jan 2023

**Title:** Evaluation of Explanation Methods of AI -- CNNs in Image Classification  Tasks with Reference-based and No-reference Metrics

**Abstract Link:** [https://arxiv.org/abs/2212.01222](https://arxiv.org/abs/2212.01222)

**PDF Link:** [https://arxiv.org/pdf/2212.01222](https://arxiv.org/pdf/2212.01222)

---

**Date:** 06 Aug 2023

**Title:** Empirical Optimal Risk to Quantify Model Trustworthiness for Failure  Detection

**Abstract Link:** [https://arxiv.org/abs/2308.03179](https://arxiv.org/abs/2308.03179)

**PDF Link:** [https://arxiv.org/pdf/2308.03179](https://arxiv.org/pdf/2308.03179)

---

**Date:** 29 Sep 2021

**Title:** An Empirical Study of Accuracy, Fairness, Explainability, Distributional  Robustness, and Adversarial Robustness

**Abstract Link:** [https://arxiv.org/abs/2109.14653](https://arxiv.org/abs/2109.14653)

**PDF Link:** [https://arxiv.org/pdf/2109.14653](https://arxiv.org/pdf/2109.14653)

---

**Date:** 17 Feb 2024

**Title:** Leveraging Professional Radiologists' Expertise to Enhance LLMs'  Evaluation for Radiology Reports

**Abstract Link:** [https://arxiv.org/abs/2401.16578](https://arxiv.org/abs/2401.16578)

**PDF Link:** [https://arxiv.org/pdf/2401.16578](https://arxiv.org/pdf/2401.16578)

---

**Date:** 26 Aug 2023

**Title:** A Comprehensive Survey for Evaluation Methodologies of AI-Generated  Music

**Abstract Link:** [https://arxiv.org/abs/2308.13736](https://arxiv.org/abs/2308.13736)

**PDF Link:** [https://arxiv.org/pdf/2308.13736](https://arxiv.org/pdf/2308.13736)

---

**Date:** 18 Jul 2016

**Title:** Performance Based Evaluation of Various Machine Learning Classification  Techniques for Chronic Kidney Disease Diagnosis

**Abstract Link:** [https://arxiv.org/abs/1606.09581](https://arxiv.org/abs/1606.09581)

**PDF Link:** [https://arxiv.org/pdf/1606.09581](https://arxiv.org/pdf/1606.09581)

---

**Date:** 08 May 2023

**Title:** Learning to Evaluate the Artness of AI-generated Images

**Abstract Link:** [https://arxiv.org/abs/2305.04923](https://arxiv.org/abs/2305.04923)

**PDF Link:** [https://arxiv.org/pdf/2305.04923](https://arxiv.org/pdf/2305.04923)

---

**Date:** 26 Jan 2024

**Title:** A structured regression approach for evaluating model performance across  intersectional subgroups

**Abstract Link:** [https://arxiv.org/abs/2401.14893](https://arxiv.org/abs/2401.14893)

**PDF Link:** [https://arxiv.org/pdf/2401.14893](https://arxiv.org/pdf/2401.14893)

---

**Date:** 23 Jan 2024

**Title:** AIGCBench: Comprehensive Evaluation of Image-to-Video Content Generated  by AI

**Abstract Link:** [https://arxiv.org/abs/2401.01651](https://arxiv.org/abs/2401.01651)

**PDF Link:** [https://arxiv.org/pdf/2401.01651](https://arxiv.org/pdf/2401.01651)

---

**Date:** 28 Nov 2023

**Title:** Extending CAM-based XAI methods for Remote Sensing Imagery Segmentation

**Abstract Link:** [https://arxiv.org/abs/2310.01837](https://arxiv.org/abs/2310.01837)

**PDF Link:** [https://arxiv.org/pdf/2310.01837](https://arxiv.org/pdf/2310.01837)

---

**Date:** 03 Feb 2020

**Title:** Synthetic-Neuroscore: Using A Neuro-AI Interface for Evaluating  Generative Adversarial Networks

**Abstract Link:** [https://arxiv.org/abs/1905.04243](https://arxiv.org/abs/1905.04243)

**PDF Link:** [https://arxiv.org/pdf/1905.04243](https://arxiv.org/pdf/1905.04243)

---

**Date:** 13 Sep 2022

**Title:** Gradient Episodic Memory for Continual Learning

**Abstract Link:** [https://arxiv.org/abs/1706.08840](https://arxiv.org/abs/1706.08840)

**PDF Link:** [https://arxiv.org/pdf/1706.08840](https://arxiv.org/pdf/1706.08840)

---

**Date:** 11 Jan 2021

**Title:** PyHealth: A Python Library for Health Predictive Models

**Abstract Link:** [https://arxiv.org/abs/2101.04209](https://arxiv.org/abs/2101.04209)

**PDF Link:** [https://arxiv.org/pdf/2101.04209](https://arxiv.org/pdf/2101.04209)

---

**Date:** 24 Jan 2024

**Title:** Can I trust my fake data -- A comprehensive quality assessment framework  for synthetic tabular data in healthcare

**Abstract Link:** [https://arxiv.org/abs/2401.13716](https://arxiv.org/abs/2401.13716)

**PDF Link:** [https://arxiv.org/pdf/2401.13716](https://arxiv.org/pdf/2401.13716)

---

