LLM Feature Detection 🔍

### 🔎 LLM Feature Detection 🔍



Feature Detection is a technique used in computer vision to identify and locate features in an image. These features can be anything from edges, corners, blobs, or any other distinctive pattern that can be used to identify and distinguish one image from another.

Feature detection algorithms can be broadly classified into two categories:

1. **Local Feature Detection**: These algorithms focus on detecting and describing features in a small region of an image. Examples of local feature detection algorithms include the Harris Corner Detector, SIFT (Scale-Invariant Feature Transform), SURF (Speeded-Up Robust Features), and ORB (Oriented FAST and Rotated BRIEF).
2. **Global Feature Detection**: These algorithms focus on detecting features that cover the entire image. Examples of global feature detection algorithms include the Edge Histogram, HOG (Histogram of Oriented Gradients), and GIST (Perceptual Dimensions of Scene Images).

Feature detection is an important step in many computer vision applications, such as image matching, object recognition, and 3D reconstruction. By detecting and describing features in an image, we can compare and match features between different images, which can be used to identify similarities and differences between images.

Here's an example of feature detection using the Harris Corner Detector in OpenCV:
```python
import cv2
import matplotlib.pyplot as plt

# Load an image
img = cv2.imread('image.jpg')

# Convert the image to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Detect corners using the Harris Corner Detector
corners = cv2.cornerHarris(gray, 2, 3, 0.04)

# Threshold the corners to get only the strong corners
corners_thresholded = corners > 0.01 * corners.max()

# Convert the corners to a numpy array and reshape it to match the image shape
corners_array = corners_thresholded.reshape(gray.shape[:2])

# Draw the corners on the image
img_with_corners = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
cv
# 🩺🔍 Search Results
### 15 Dec 2023 | [SeqXGPT: Sentence-Level AI-Generated Text Detection](https://arxiv.org/abs/2310.08903) | [⬇️](https://arxiv.org/pdf/2310.08903)
*Pengyu Wang, Linyang Li, Ke Ren, Botian Jiang, Dong Zhang, Xipeng Qiu* 

  Widely applied large language models (LLMs) can generate human-like content,
raising concerns about the abuse of LLMs. Therefore, it is important to build
strong AI-generated text (AIGT) detectors. Current works only consider
document-level AIGT detection, therefore, in this paper, we first introduce a
sentence-level detection challenge by synthesizing a dataset that contains
documents that are polished with LLMs, that is, the documents contain sentences
written by humans and sentences modified by LLMs. Then we propose
\textbf{Seq}uence \textbf{X} (Check) \textbf{GPT}, a novel method that utilizes
log probability lists from white-box LLMs as features for sentence-level AIGT
detection. These features are composed like \textit{waves} in speech processing
and cannot be studied by LLMs. Therefore, we build SeqXGPT based on convolution
and self-attention networks. We test it in both sentence and document-level
detection challenges. Experimental results show that previous methods struggle
in solving sentence-level AIGT detection, while our method not only
significantly surpasses baseline methods in both sentence and document-level
detection challenges but also exhibits strong generalization capabilities.

---------------

### 28 Aug 2023 | [Fine-Tuning Llama 2 Large Language Models for Detecting Online Sexual  Predatory Chats and Abusive Texts](https://arxiv.org/abs/2308.14683) | [⬇️](https://arxiv.org/pdf/2308.14683)
*Thanh Thi Nguyen, Campbell Wilson, Janis Dalins* 

  Detecting online sexual predatory behaviours and abusive language on social
media platforms has become a critical area of research due to the growing
concerns about online safety, especially for vulnerable populations such as
children and adolescents. Researchers have been exploring various techniques
and approaches to develop effective detection systems that can identify and
mitigate these risks. Recent development of large language models (LLMs) has
opened a new opportunity to address this problem more effectively. This paper
proposes an approach to detection of online sexual predatory chats and abusive
language using the open-source pretrained Llama 2 7B-parameter model, recently
released by Meta GenAI. We fine-tune the LLM using datasets with different
sizes, imbalance degrees, and languages (i.e., English, Roman Urdu and Urdu).
Based on the power of LLMs, our approach is generic and automated without a
manual search for a synergy between feature extraction and classifier design
steps like conventional methods in this domain. Experimental results show a
strong performance of the proposed approach, which performs proficiently and
consistently across three distinct datasets with five sets of experiments. This
study's outcomes indicate that the proposed method can be implemented in
real-world applications (even with non-English languages) for flagging sexual
predators, offensive or toxic content, hate speech, and discriminatory language
in online discussions and comments to maintain respectful internet or digital
communities. Furthermore, it can be employed for solving text classification
problems with other potential applications such as sentiment analysis, spam and
phishing detection, sorting legal documents, fake news detection, language
identification, user intent recognition, text-based product categorization,
medical record analysis, and resume screening.

---------------

### 16 Oct 2023 | [Stance Detection with Collaborative Role-Infused LLM-Based Agents](https://arxiv.org/abs/2310.10467) | [⬇️](https://arxiv.org/pdf/2310.10467)
*Xiaochong Lan, Chen Gao, Depeng Jin, Yong Li* 

  Stance detection automatically detects the stance in a text towards a target,
vital for content analysis in web and social media research. Despite their
promising capabilities, LLMs encounter challenges when directly applied to
stance detection. First, stance detection demands multi-aspect knowledge, from
deciphering event-related terminologies to understanding the expression styles
in social media platforms. Second, stance detection requires advanced reasoning
to infer authors' implicit viewpoints, as stance are often subtly embedded
rather than overtly stated in the text. To address these challenges, we design
a three-stage framework COLA (short for Collaborative rOle-infused LLM-based
Agents) in which LLMs are designated distinct roles, creating a collaborative
system where each role contributes uniquely. Initially, in the multidimensional
text analysis stage, we configure the LLMs to act as a linguistic expert, a
domain specialist, and a social media veteran to get a multifaceted analysis of
texts, thus overcoming the first challenge. Next, in the reasoning-enhanced
debating stage, for each potential stance, we designate a specific LLM-based
agent to advocate for it, guiding the LLM to detect logical connections between
text features and stance, tackling the second challenge. Finally, in the stance
conclusion stage, a final decision maker agent consolidates prior insights to
determine the stance. Our approach avoids extra annotated data and model
training and is highly usable. We achieve state-of-the-art performance across
multiple datasets. Ablation studies validate the effectiveness of each design
role in handling stance detection. Further experiments have demonstrated the
explainability and the versatility of our approach. Our approach excels in
usability, accuracy, effectiveness, explainability and versatility,
highlighting its value.

---------------

### 26 May 2023 | [Efficient Detection of LLM-generated Texts with a Bayesian Surrogate  Model](https://arxiv.org/abs/2305.16617) | [⬇️](https://arxiv.org/pdf/2305.16617)
*Zhijie Deng, Hongcheng Gao, Yibo Miao, Hao Zhang* 

  The detection of machine-generated text, especially from large language
models (LLMs), is crucial in preventing serious social problems resulting from
their misuse. Some methods train dedicated detectors on specific datasets but
fall short in generalizing to unseen test data, while other zero-shot ones
often yield suboptimal performance. Although the recent DetectGPT has shown
promising detection performance, it suffers from significant inefficiency
issues, as detecting a single candidate requires scoring hundreds of its
perturbations with the source LLM. This paper aims to bridge this gap.
Technically, we propose to incorporate a Bayesian surrogate model, which allows
us to select typical samples based on Bayesian uncertainty and interpolate
scores from typical samples to other ones, to improve query efficiency. Our
empirical results demonstrate that our method significantly outperforms
existing approaches under a low query budget. Notably, our method achieves
similar performance with up to 2 times fewer queries than DetectGPT and 3.7%
higher AUROC at a query number of 5.

---------------

### 24 Jan 2024 | [Research about the Ability of LLM in the Tamper-Detection Area](https://arxiv.org/abs/2401.13504) | [⬇️](https://arxiv.org/pdf/2401.13504)
*Xinyu Yang and Jizhe Zhou* 

  In recent years, particularly since the early 2020s, Large Language Models
(LLMs) have emerged as the most powerful AI tools in addressing a diverse range
of challenges, from natural language processing to complex problem-solving in
various domains. In the field of tamper detection, LLMs are capable of
identifying basic tampering activities.To assess the capabilities of LLMs in
more specialized domains, we have collected five different LLMs developed by
various companies: GPT-4, LLaMA, Bard, ERNIE Bot 4.0, and Tongyi Qianwen. This
diverse range of models allows for a comprehensive evaluation of their
performance in detecting sophisticated tampering instances.We devised two
domains of detection: AI-Generated Content (AIGC) detection and manipulation
detection. AIGC detection aims to test the ability to distinguish whether an
image is real or AI-generated. Manipulation detection, on the other hand,
focuses on identifying tampered images. According to our experiments, most LLMs
can identify composite pictures that are inconsistent with logic, and only more
powerful LLMs can distinguish logical, but visible signs of tampering to the
human eye. All of the LLMs can't identify carefully forged images and very
realistic images generated by AI. In the area of tamper detection, LLMs still
have a long way to go, particularly in reliably identifying highly
sophisticated forgeries and AI-generated images that closely mimic reality.

---------------

### 01 Mar 2024 | [How Good Are Large Language Models at Out-of-Distribution Detection?](https://arxiv.org/abs/2308.10261) | [⬇️](https://arxiv.org/pdf/2308.10261)
*Bo Liu, Liming Zhan, Zexin Lu, Yujie Feng, Lei Xue, Xiao-Ming Wu* 

  Out-of-distribution (OOD) detection plays a vital role in enhancing the
reliability of machine learning (ML) models. The emergence of large language
models (LLMs) has catalyzed a paradigm shift within the ML community,
showcasing their exceptional capabilities across diverse natural language
processing tasks. While existing research has probed OOD detection with
relative small-scale Transformers like BERT, RoBERTa and GPT-2, the stark
differences in scales, pre-training objectives, and inference paradigms call
into question the applicability of these findings to LLMs. This paper embarks
on a pioneering empirical investigation of OOD detection in the domain of LLMs,
focusing on LLaMA series ranging from 7B to 65B in size. We thoroughly evaluate
commonly-used OOD detectors, scrutinizing their performance in both zero-grad
and fine-tuning scenarios. Notably, we alter previous discriminative
in-distribution fine-tuning into generative fine-tuning, aligning the
pre-training objective of LLMs with downstream tasks. Our findings unveil that
a simple cosine distance OOD detector demonstrates superior efficacy,
outperforming other OOD detectors. We provide an intriguing explanation for
this phenomenon by highlighting the isotropic nature of the embedding spaces of
LLMs, which distinctly contrasts with the anisotropic property observed in
smaller BERT family models. The new insight enhances our understanding of how
LLMs detect OOD data, thereby enhancing their adaptability and reliability in
dynamic environments.

---------------

### 12 Feb 2024 | [Large language models can enhance persuasion through linguistic feature  alignment](https://arxiv.org/abs/2311.16466) | [⬇️](https://arxiv.org/pdf/2311.16466)
*Minkyu Shin and Jin Kim* 

  Although large language models (LLMs) are reshaping various aspects of human
life, our current understanding of their impacts remains somewhat constrained.
Here we investigate the impact of LLMs on human communication, using data on
consumer complaints in the financial industry. By employing an AI detection
tool on more than 820K complaints gathered by the Consumer Financial Protection
Bureau (CFPB), we find a sharp increase in the likely use of LLMs shortly after
the release of ChatGPT. Moreover, the likely LLM usage was positively
correlated with message persuasiveness (i.e., increased likelihood of obtaining
relief from financial firms). Computational linguistic analyses suggest that
the positive correlation may be explained by LLMs' enhancement of various
linguistic features. Based on the results of these observational studies, we
hypothesize that LLM usage may enhance a comprehensive set of linguistic
features, increasing message persuasiveness to receivers with heterogeneous
linguistic preferences (i.e., linguistic feature alignment). We test this
hypothesis in preregistered experiments and find support for it. As an instance
of early empirical demonstrations of LLM usage for enhancing persuasion, our
research highlights the transformative potential of LLMs in human
communication.

---------------

### 04 Mar 2024 | [Beyond the Known: Investigating LLMs Performance on Out-of-Domain Intent  Detection](https://arxiv.org/abs/2402.17256) | [⬇️](https://arxiv.org/pdf/2402.17256)
*Pei Wang, Keqing He, Yejie Wang, Xiaoshuai Song, Yutao Mou, Jingang  Wang, Yunsen Xian, Xunliang Cai, Weiran Xu* 

  Out-of-domain (OOD) intent detection aims to examine whether the user's query
falls outside the predefined domain of the system, which is crucial for the
proper functioning of task-oriented dialogue (TOD) systems. Previous methods
address it by fine-tuning discriminative models. Recently, some studies have
been exploring the application of large language models (LLMs) represented by
ChatGPT to various downstream tasks, but it is still unclear for their ability
on OOD detection task.This paper conducts a comprehensive evaluation of LLMs
under various experimental settings, and then outline the strengths and
weaknesses of LLMs. We find that LLMs exhibit strong zero-shot and few-shot
capabilities, but is still at a disadvantage compared to models fine-tuned with
full resource. More deeply, through a series of additional analysis
experiments, we discuss and summarize the challenges faced by LLMs and provide
guidance for future work including injecting domain knowledge, strengthening
knowledge transfer from IND(In-domain) to OOD, and understanding long
instructions.

---------------

### 03 Mar 2024 | [GPTSee: Enhancing Moment Retrieval and Highlight Detection via  Description-Based Similarity Features](https://arxiv.org/abs/2403.01437) | [⬇️](https://arxiv.org/pdf/2403.01437)
*Yunzhuo Sun, Yifang Xu, Zien Xie, Yukun Shu, and Sidan Du* 

  Moment retrieval (MR) and highlight detection (HD) aim to identify relevant
moments and highlights in video from corresponding natural language query.
Large language models (LLMs) have demonstrated proficiency in various computer
vision tasks. However, existing methods for MR\&HD have not yet been integrated
with LLMs. In this letter, we propose a novel two-stage model that takes the
output of LLMs as the input to the second-stage transformer encoder-decoder.
First, MiniGPT-4 is employed to generate the detailed description of the video
frame and rewrite the query statement, fed into the encoder as new features.
Then, semantic similarity is computed between the generated description and the
rewritten queries. Finally, continuous high-similarity video frames are
converted into span anchors, serving as prior position information for the
decoder. Experiments demonstrate that our approach achieves a state-of-the-art
result, and by using only span anchors and similarity scores as outputs,
positioning accuracy outperforms traditional methods, like Moment-DETR.

---------------

### 06 Feb 2024 | [INSIDE: LLMs' Internal States Retain the Power of Hallucination  Detection](https://arxiv.org/abs/2402.03744) | [⬇️](https://arxiv.org/pdf/2402.03744)
*Chao Chen, Kai Liu, Ze Chen, Yi Gu, Yue Wu, Mingyuan Tao, Zhihang Fu,  Jieping Ye* 

  Knowledge hallucination have raised widespread concerns for the security and
reliability of deployed LLMs. Previous efforts in detecting hallucinations have
been employed at logit-level uncertainty estimation or language-level
self-consistency evaluation, where the semantic information is inevitably lost
during the token-decoding procedure. Thus, we propose to explore the dense
semantic information retained within LLMs' \textbf{IN}ternal \textbf{S}tates
for halluc\textbf{I}nation \textbf{DE}tection (\textbf{INSIDE}). In particular,
a simple yet effective \textbf{EigenScore} metric is proposed to better
evaluate responses' self-consistency, which exploits the eigenvalues of
responses' covariance matrix to measure the semantic consistency/diversity in
the dense embedding space. Furthermore, from the perspective of self-consistent
hallucination detection, a test time feature clipping approach is explored to
truncate extreme activations in the internal states, which reduces
overconfident generations and potentially benefits the detection of
overconfident hallucinations. Extensive experiments and ablation studies are
performed on several popular LLMs and question-answering (QA) benchmarks,
showing the effectiveness of our proposal.

---------------

### 24 Oct 2023 | [A Survey on Detection of LLMs-Generated Content](https://arxiv.org/abs/2310.15654) | [⬇️](https://arxiv.org/pdf/2310.15654)
*Xianjun Yang, Liangming Pan, Xuandong Zhao, Haifeng Chen, Linda  Petzold, William Yang Wang, Wei Cheng* 

  The burgeoning capabilities of advanced large language models (LLMs) such as
ChatGPT have led to an increase in synthetic content generation with
implications across a variety of sectors, including media, cybersecurity,
public discourse, and education. As such, the ability to detect LLMs-generated
content has become of paramount importance. We aim to provide a detailed
overview of existing detection strategies and benchmarks, scrutinizing their
differences and identifying key challenges and prospects in the field,
advocating for more adaptable and robust models to enhance detection accuracy.
We also posit the necessity for a multi-faceted approach to defend against
various attacks to counter the rapidly advancing capabilities of LLMs. To the
best of our knowledge, this work is the first comprehensive survey on the
detection in the era of LLMs. We hope it will provide a broad understanding of
the current landscape of LLMs-generated content detection, offering a guiding
reference for researchers and practitioners striving to uphold the integrity of
digital information in an era increasingly dominated by synthetic content. The
relevant papers are summarized and will be consistently updated at
https://github.com/Xianjun-Yang/Awesome_papers_on_LLMs_detection.git.

---------------

### 12 Nov 2023 | [An Improved Transformer-based Model for Detecting Phishing, Spam, and  Ham: A Large Language Model Approach](https://arxiv.org/abs/2311.04913) | [⬇️](https://arxiv.org/pdf/2311.04913)
*Suhaima Jamal and Hayden Wimmer* 

  Phishing and spam detection is long standing challenge that has been the
subject of much academic research. Large Language Models (LLM) have vast
potential to transform society and provide new and innovative approaches to
solve well-established challenges. Phishing and spam have caused financial
hardships and lost time and resources to email users all over the world and
frequently serve as an entry point for ransomware threat actors. While
detection approaches exist, especially heuristic-based approaches, LLMs offer
the potential to venture into a new unexplored area for understanding and
solving this challenge. LLMs have rapidly altered the landscape from business,
consumers, and throughout academia and demonstrate transformational potential
for the potential of society. Based on this, applying these new and innovative
approaches to email detection is a rational next step in academic research. In
this work, we present IPSDM, our model based on fine-tuning the BERT family of
models to specifically detect phishing and spam email. We demonstrate our
fine-tuned version, IPSDM, is able to better classify emails in both unbalanced
and balanced datasets. This work serves as an important first step towards
employing LLMs to improve the security of our information systems.

---------------

### 12 Oct 2023 | [Exploring Large Language Models for Multi-Modal Out-of-Distribution  Detection](https://arxiv.org/abs/2310.08027) | [⬇️](https://arxiv.org/pdf/2310.08027)
*Yi Dai, Hao Lang, Kaisheng Zeng, Fei Huang, Yongbin Li* 

  Out-of-distribution (OOD) detection is essential for reliable and trustworthy
machine learning. Recent multi-modal OOD detection leverages textual
information from in-distribution (ID) class names for visual OOD detection, yet
it currently neglects the rich contextual information of ID classes. Large
language models (LLMs) encode a wealth of world knowledge and can be prompted
to generate descriptive features for each class. Indiscriminately using such
knowledge causes catastrophic damage to OOD detection due to LLMs'
hallucinations, as is observed by our analysis. In this paper, we propose to
apply world knowledge to enhance OOD detection performance through selective
generation from LLMs. Specifically, we introduce a consistency-based
uncertainty calibration method to estimate the confidence score of each
generation. We further extract visual objects from each image to fully
capitalize on the aforementioned world knowledge. Extensive experiments
demonstrate that our method consistently outperforms the state-of-the-art.

---------------

### 23 Jul 2023 | [DetectGPT: Zero-Shot Machine-Generated Text Detection using Probability  Curvature](https://arxiv.org/abs/2301.11305) | [⬇️](https://arxiv.org/pdf/2301.11305)
*Eric Mitchell, Yoonho Lee, Alexander Khazatsky, Christopher D.  Manning, Chelsea Finn* 

  The increasing fluency and widespread usage of large language models (LLMs)
highlight the desirability of corresponding tools aiding detection of
LLM-generated text. In this paper, we identify a property of the structure of
an LLM's probability function that is useful for such detection. Specifically,
we demonstrate that text sampled from an LLM tends to occupy negative curvature
regions of the model's log probability function. Leveraging this observation,
we then define a new curvature-based criterion for judging if a passage is
generated from a given LLM. This approach, which we call DetectGPT, does not
require training a separate classifier, collecting a dataset of real or
generated passages, or explicitly watermarking generated text. It uses only log
probabilities computed by the model of interest and random perturbations of the
passage from another generic pre-trained language model (e.g., T5). We find
DetectGPT is more discriminative than existing zero-shot methods for model
sample detection, notably improving detection of fake news articles generated
by 20B parameter GPT-NeoX from 0.81 AUROC for the strongest zero-shot baseline
to 0.95 AUROC for DetectGPT. See https://ericmitchell.ai/detectgpt for code,
data, and other project information.

---------------

### 22 Feb 2024 | [Fast-DetectGPT: Efficient Zero-Shot Detection of Machine-Generated Text  via Conditional Probability Curvature](https://arxiv.org/abs/2310.05130) | [⬇️](https://arxiv.org/pdf/2310.05130)
*Guangsheng Bao, Yanbin Zhao, Zhiyang Teng, Linyi Yang, Yue Zhang* 

  Large language models (LLMs) have shown the ability to produce fluent and
cogent content, presenting both productivity opportunities and societal risks.
To build trustworthy AI systems, it is imperative to distinguish between
machine-generated and human-authored content. The leading zero-shot detector,
DetectGPT, showcases commendable performance but is marred by its intensive
computational costs. In this paper, we introduce the concept of conditional
probability curvature to elucidate discrepancies in word choices between LLMs
and humans within a given context. Utilizing this curvature as a foundational
metric, we present **Fast-DetectGPT**, an optimized zero-shot detector, which
substitutes DetectGPT's perturbation step with a more efficient sampling step.
Our evaluations on various datasets, source models, and test conditions
indicate that Fast-DetectGPT not only surpasses DetectGPT by a relative around
75% in both the white-box and black-box settings but also accelerates the
detection process by a factor of 340, as detailed in Table 1. See
\url{https://github.com/baoguangsheng/fast-detect-gpt} for code, data, and
results.

---------------

### 04 Aug 2023 | [G3Detector: General GPT-Generated Text Detector](https://arxiv.org/abs/2305.12680) | [⬇️](https://arxiv.org/pdf/2305.12680)
*Haolan Zhan and Xuanli He and Qiongkai Xu and Yuxiang Wu and Pontus  Stenetorp* 

  The burgeoning progress in the field of Large Language Models (LLMs) heralds
significant benefits due to their unparalleled capacities. However, it is
critical to acknowledge the potential misuse of these models, which could give
rise to a spectrum of social and ethical dilemmas. Despite numerous preceding
efforts centered around distinguishing synthetic text, most existing detection
systems fail to identify data synthesized by the latest LLMs, such as ChatGPT
and GPT-4. In response to this challenge, we introduce an unpretentious yet
potent detection approach proficient in identifying synthetic text across a
wide array of fields. Moreover, our detector demonstrates outstanding
performance uniformly across various model architectures and decoding
strategies. It also possesses the capability to identify text generated
utilizing a potent detection-evasion technique. Our comprehensive research
underlines our commitment to boosting the robustness and efficiency of
machine-generated text detection mechanisms, particularly in the context of
swiftly progressing and increasingly adaptive AI technologies.

---------------

### 02 Nov 2023 | [Incorporating Language-Driven Appearance Knowledge Units with Visual  Cues in Pedestrian Detection](https://arxiv.org/abs/2311.01025) | [⬇️](https://arxiv.org/pdf/2311.01025)
*Sungjune Park, Hyunjun Kim, Yong Man Ro* 

  Large language models (LLMs) have shown their capability in understanding
contextual and semantic information regarding appearance knowledge of
instances. In this paper, we introduce a novel approach to utilize the strength
of an LLM in understanding contextual appearance variations and to leverage its
knowledge into a vision model (here, pedestrian detection). While pedestrian
detection is considered one of crucial tasks directly related with our safety
(e.g., intelligent driving system), it is challenging because of varying
appearances and poses in diverse scenes. Therefore, we propose to formulate
language-driven appearance knowledge units and incorporate them with visual
cues in pedestrian detection. To this end, we establish description corpus
which includes numerous narratives describing various appearances of
pedestrians and others. By feeding them through an LLM, we extract appearance
knowledge sets that contain the representations of appearance variations. After
that, we perform a task-prompting process to obtain appearance knowledge units
which are representative appearance knowledge guided to be relevant to a
downstream pedestrian detection task. Finally, we provide plentiful appearance
information by integrating the language-driven knowledge units with visual
cues. Through comprehensive experiments with various pedestrian detectors, we
verify the effectiveness of our method showing noticeable performance gains and
achieving state-of-the-art detection performance.

---------------

### 21 Nov 2023 | [Can Large Language Models Understand Content and Propagation for  Misinformation Detection: An Empirical Study](https://arxiv.org/abs/2311.12699) | [⬇️](https://arxiv.org/pdf/2311.12699)
*Mengyang Chen, Lingwei Wei, Han Cao, Wei Zhou, Songlin Hu* 

  Large Language Models (LLMs) have garnered significant attention for their
powerful ability in natural language understanding and reasoning. In this
paper, we present a comprehensive empirical study to explore the performance of
LLMs on misinformation detection tasks. This study stands as the pioneering
investigation into the understanding capabilities of multiple LLMs regarding
both content and propagation across social media platforms. Our empirical
studies on five misinformation detection datasets show that LLMs with diverse
prompts achieve comparable performance in text-based misinformation detection
but exhibit notably constrained capabilities in comprehending propagation
structure compared to existing models in propagation-based misinformation
detection. Besides, we further design four instruction-tuned strategies to
enhance LLMs for both content and propagation-based misinformation detection.
These strategies boost LLMs to actively learn effective features from multiple
instances or hard instances, and eliminate irrelevant propagation structures,
thereby achieving better detection performance. Extensive experiments further
demonstrate LLMs would play a better capacity in content and propagation
structure under these proposed strategies and achieve promising detection
performance. These findings highlight the potential ability of LLMs to detect
misinformation.

---------------

### 14 Feb 2024 | [Ten Words Only Still Help: Improving Black-Box AI-Generated Text  Detection via Proxy-Guided Efficient Re-Sampling](https://arxiv.org/abs/2402.09199) | [⬇️](https://arxiv.org/pdf/2402.09199)
*Yuhui Shi, Qiang Sheng, Juan Cao, Hao Mi, Beizhe Hu, Danding Wang* 

  With the rapidly increasing application of large language models (LLMs),
their abuse has caused many undesirable societal problems such as fake news,
academic dishonesty, and information pollution. This makes AI-generated text
(AIGT) detection of great importance. Among existing methods, white-box methods
are generally superior to black-box methods in terms of performance and
generalizability, but they require access to LLMs' internal states and are not
applicable to black-box settings. In this paper, we propose to estimate word
generation probabilities as pseudo white-box features via multiple re-sampling
to help improve AIGT detection under the black-box setting. Specifically, we
design POGER, a proxy-guided efficient re-sampling method, which selects a
small subset of representative words (e.g., 10 words) for performing multiple
re-sampling in black-box AIGT detection. Experiments on datasets containing
texts from humans and seven LLMs show that POGER outperforms all baselines in
macro F1 under black-box, partial white-box, and out-of-distribution settings
and maintains lower re-sampling costs than its existing counterparts.

---------------

### 24 Oct 2023 | [A Survey on LLM-generated Text Detection: Necessity, Methods, and Future  Directions](https://arxiv.org/abs/2310.14724) | [⬇️](https://arxiv.org/pdf/2310.14724)
*Junchao Wu, Shu Yang, Runzhe Zhan, Yulin Yuan, Derek F. Wong, Lidia S.  Chao* 

  The powerful ability to understand, follow, and generate complex language
emerging from large language models (LLMs) makes LLM-generated text flood many
areas of our daily lives at an incredible speed and is widely accepted by
humans. As LLMs continue to expand, there is an imperative need to develop
detectors that can detect LLM-generated text. This is crucial to mitigate
potential misuse of LLMs and safeguard realms like artistic expression and
social networks from harmful influence of LLM-generated content. The
LLM-generated text detection aims to discern if a piece of text was produced by
an LLM, which is essentially a binary classification task. The detector
techniques have witnessed notable advancements recently, propelled by
innovations in watermarking techniques, zero-shot methods, fine-turning LMs
methods, adversarial learning methods, LLMs as detectors, and human-assisted
methods. In this survey, we collate recent research breakthroughs in this area
and underscore the pressing need to bolster detector research. We also delve
into prevalent datasets, elucidating their limitations and developmental
requirements. Furthermore, we analyze various LLM-generated text detection
paradigms, shedding light on challenges like out-of-distribution problems,
potential attacks, and data ambiguity. Conclusively, we highlight interesting
directions for future research in LLM-generated text detection to advance the
implementation of responsible artificial intelligence (AI). Our aim with this
survey is to provide a clear and comprehensive introduction for newcomers while
also offering seasoned researchers a valuable update in the field of
LLM-generated text detection. The useful resources are publicly available at:
https://github.com/NLP2CT/LLM-generated-Text-Detection.

---------------
**Date:** 15 Dec 2023

**Title:** SeqXGPT: Sentence-Level AI-Generated Text Detection

**Abstract Link:** [https://arxiv.org/abs/2310.08903](https://arxiv.org/abs/2310.08903)

**PDF Link:** [https://arxiv.org/pdf/2310.08903](https://arxiv.org/pdf/2310.08903)

---

**Date:** 28 Aug 2023

**Title:** Fine-Tuning Llama 2 Large Language Models for Detecting Online Sexual  Predatory Chats and Abusive Texts

**Abstract Link:** [https://arxiv.org/abs/2308.14683](https://arxiv.org/abs/2308.14683)

**PDF Link:** [https://arxiv.org/pdf/2308.14683](https://arxiv.org/pdf/2308.14683)

---

**Date:** 16 Oct 2023

**Title:** Stance Detection with Collaborative Role-Infused LLM-Based Agents

**Abstract Link:** [https://arxiv.org/abs/2310.10467](https://arxiv.org/abs/2310.10467)

**PDF Link:** [https://arxiv.org/pdf/2310.10467](https://arxiv.org/pdf/2310.10467)

---

**Date:** 26 May 2023

**Title:** Efficient Detection of LLM-generated Texts with a Bayesian Surrogate  Model

**Abstract Link:** [https://arxiv.org/abs/2305.16617](https://arxiv.org/abs/2305.16617)

**PDF Link:** [https://arxiv.org/pdf/2305.16617](https://arxiv.org/pdf/2305.16617)

---

**Date:** 24 Jan 2024

**Title:** Research about the Ability of LLM in the Tamper-Detection Area

**Abstract Link:** [https://arxiv.org/abs/2401.13504](https://arxiv.org/abs/2401.13504)

**PDF Link:** [https://arxiv.org/pdf/2401.13504](https://arxiv.org/pdf/2401.13504)

---

**Date:** 01 Mar 2024

**Title:** How Good Are Large Language Models at Out-of-Distribution Detection?

**Abstract Link:** [https://arxiv.org/abs/2308.10261](https://arxiv.org/abs/2308.10261)

**PDF Link:** [https://arxiv.org/pdf/2308.10261](https://arxiv.org/pdf/2308.10261)

---

**Date:** 12 Feb 2024

**Title:** Large language models can enhance persuasion through linguistic feature  alignment

**Abstract Link:** [https://arxiv.org/abs/2311.16466](https://arxiv.org/abs/2311.16466)

**PDF Link:** [https://arxiv.org/pdf/2311.16466](https://arxiv.org/pdf/2311.16466)

---

**Date:** 04 Mar 2024

**Title:** Beyond the Known: Investigating LLMs Performance on Out-of-Domain Intent  Detection

**Abstract Link:** [https://arxiv.org/abs/2402.17256](https://arxiv.org/abs/2402.17256)

**PDF Link:** [https://arxiv.org/pdf/2402.17256](https://arxiv.org/pdf/2402.17256)

---

**Date:** 03 Mar 2024

**Title:** GPTSee: Enhancing Moment Retrieval and Highlight Detection via  Description-Based Similarity Features

**Abstract Link:** [https://arxiv.org/abs/2403.01437](https://arxiv.org/abs/2403.01437)

**PDF Link:** [https://arxiv.org/pdf/2403.01437](https://arxiv.org/pdf/2403.01437)

---

**Date:** 06 Feb 2024

**Title:** INSIDE: LLMs' Internal States Retain the Power of Hallucination  Detection

**Abstract Link:** [https://arxiv.org/abs/2402.03744](https://arxiv.org/abs/2402.03744)

**PDF Link:** [https://arxiv.org/pdf/2402.03744](https://arxiv.org/pdf/2402.03744)

---

**Date:** 24 Oct 2023

**Title:** A Survey on Detection of LLMs-Generated Content

**Abstract Link:** [https://arxiv.org/abs/2310.15654](https://arxiv.org/abs/2310.15654)

**PDF Link:** [https://arxiv.org/pdf/2310.15654](https://arxiv.org/pdf/2310.15654)

---

**Date:** 12 Nov 2023

**Title:** An Improved Transformer-based Model for Detecting Phishing, Spam, and  Ham: A Large Language Model Approach

**Abstract Link:** [https://arxiv.org/abs/2311.04913](https://arxiv.org/abs/2311.04913)

**PDF Link:** [https://arxiv.org/pdf/2311.04913](https://arxiv.org/pdf/2311.04913)

---

**Date:** 12 Oct 2023

**Title:** Exploring Large Language Models for Multi-Modal Out-of-Distribution  Detection

**Abstract Link:** [https://arxiv.org/abs/2310.08027](https://arxiv.org/abs/2310.08027)

**PDF Link:** [https://arxiv.org/pdf/2310.08027](https://arxiv.org/pdf/2310.08027)

---

**Date:** 23 Jul 2023

**Title:** DetectGPT: Zero-Shot Machine-Generated Text Detection using Probability  Curvature

**Abstract Link:** [https://arxiv.org/abs/2301.11305](https://arxiv.org/abs/2301.11305)

**PDF Link:** [https://arxiv.org/pdf/2301.11305](https://arxiv.org/pdf/2301.11305)

---

**Date:** 22 Feb 2024

**Title:** Fast-DetectGPT: Efficient Zero-Shot Detection of Machine-Generated Text  via Conditional Probability Curvature

**Abstract Link:** [https://arxiv.org/abs/2310.05130](https://arxiv.org/abs/2310.05130)

**PDF Link:** [https://arxiv.org/pdf/2310.05130](https://arxiv.org/pdf/2310.05130)

---

**Date:** 04 Aug 2023

**Title:** G3Detector: General GPT-Generated Text Detector

**Abstract Link:** [https://arxiv.org/abs/2305.12680](https://arxiv.org/abs/2305.12680)

**PDF Link:** [https://arxiv.org/pdf/2305.12680](https://arxiv.org/pdf/2305.12680)

---

**Date:** 02 Nov 2023

**Title:** Incorporating Language-Driven Appearance Knowledge Units with Visual  Cues in Pedestrian Detection

**Abstract Link:** [https://arxiv.org/abs/2311.01025](https://arxiv.org/abs/2311.01025)

**PDF Link:** [https://arxiv.org/pdf/2311.01025](https://arxiv.org/pdf/2311.01025)

---

**Date:** 21 Nov 2023

**Title:** Can Large Language Models Understand Content and Propagation for  Misinformation Detection: An Empirical Study

**Abstract Link:** [https://arxiv.org/abs/2311.12699](https://arxiv.org/abs/2311.12699)

**PDF Link:** [https://arxiv.org/pdf/2311.12699](https://arxiv.org/pdf/2311.12699)

---

**Date:** 14 Feb 2024

**Title:** Ten Words Only Still Help: Improving Black-Box AI-Generated Text  Detection via Proxy-Guided Efficient Re-Sampling

**Abstract Link:** [https://arxiv.org/abs/2402.09199](https://arxiv.org/abs/2402.09199)

**PDF Link:** [https://arxiv.org/pdf/2402.09199](https://arxiv.org/pdf/2402.09199)

---

**Date:** 24 Oct 2023

**Title:** A Survey on LLM-generated Text Detection: Necessity, Methods, and Future  Directions

**Abstract Link:** [https://arxiv.org/abs/2310.14724](https://arxiv.org/abs/2310.14724)

**PDF Link:** [https://arxiv.org/pdf/2310.14724](https://arxiv.org/pdf/2310.14724)

---

