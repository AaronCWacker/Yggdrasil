LLM Personality Development 🎪

### 🔎 LLM Personality Development 🎪



Personality development is a lifelong process that involves building on one's strengths and overcoming weaknesses to become a well-rounded individual. It is the process of developing one's character, values, and attitudes to become the best version of oneself.

Here are some tips for personality development:

1. Set goals: Setting goals is an important step in personality development. It helps you to focus on what you want to achieve and gives you a sense of direction.
2. Learn new skills: Learning new skills can help you to build confidence and improve your abilities. It can also help you to discover new interests and passions.
3. Practice self-reflection: Self-reflection is the process of examining your thoughts, feelings, and behaviors. It can help you to understand yourself better and make positive changes in your life.
4. Build positive relationships: Building positive relationships with others can help you to develop your social skills and improve your emotional intelligence.
5. Take care of your physical health: Taking care of your physical health is important for your overall well-being. Regular exercise, a healthy diet, and adequate sleep can help you to feel your best and have more energy.
6. Seek out new experiences: Trying new things and having new experiences can help you to broaden your horizons and develop a more open-minded perspective.
7. Practice gratitude: Practicing gratitude can help you to focus on the positive aspects of your life and improve your overall happiness.
8. Seek out mentors and role models: Mentors and role models can provide guidance and inspiration as you work on developing your personality.
9. Be open to feedback: Constructive feedback can help you to identify areas for improvement and make positive changes in your life.
10. Have a positive attitude: A positive attitude can help you to approach challenges with confidence and resilience. It can also help you to build stronger relationships and improve your overall well-being.</s>
# 🩺🔍 Search Results
### 21 Feb 2024 | [Driving Generative Agents With Their Personality](https://arxiv.org/abs/2402.14879) | [⬇️](https://arxiv.org/pdf/2402.14879)
*Lawrence J. Klinkert, Stephanie Buongiorno, and Corey Clark* 

  This research explores the potential of Large Language Models (LLMs) to
utilize psychometric values, specifically personality information, within the
context of video game character development. Affective Computing (AC) systems
quantify a Non-Player character's (NPC) psyche, and an LLM can take advantage
of the system's information by using the values for prompt generation. The
research shows an LLM can consistently represent a given personality profile,
thereby enhancing the human-like characteristics of game characters.
Repurposing a human examination, the International Personality Item Pool (IPIP)
questionnaire, to evaluate an LLM shows that the model can accurately generate
content concerning the personality provided. Results show that the improvement
of LLM, such as the latest GPT-4 model, can consistently utilize and interpret
a personality to represent behavior.

---------------

### 24 May 2023 | [Have Large Language Models Developed a Personality?: Applicability of  Self-Assessment Tests in Measuring Personality in LLMs](https://arxiv.org/abs/2305.14693) | [⬇️](https://arxiv.org/pdf/2305.14693)
*Xiaoyang Song, Akshat Gupta, Kiyan Mohebbizadeh, Shujie Hu, Anant  Singh* 

  Have Large Language Models (LLMs) developed a personality? The short answer
is a resounding "We Don't Know!". In this paper, we show that we do not yet
have the right tools to measure personality in language models. Personality is
an important characteristic that influences behavior. As LLMs emulate
human-like intelligence and performance in various tasks, a natural question to
ask is whether these models have developed a personality. Previous works have
evaluated machine personality through self-assessment personality tests, which
are a set of multiple-choice questions created to evaluate personality in
humans. A fundamental assumption here is that human personality tests can
accurately measure personality in machines. In this paper, we investigate the
emergence of personality in five LLMs of different sizes ranging from 1.5B to
30B. We propose the Option-Order Symmetry property as a necessary condition for
the reliability of these self-assessment tests. Under this condition, the
answer to self-assessment questions is invariant to the order in which the
options are presented. We find that many LLMs personality test responses do not
preserve option-order symmetry. We take a deeper look at LLMs test responses
where option-order symmetry is preserved to find that in these cases, LLMs do
not take into account the situational statement being tested and produce the
exact same answer irrespective of the situation being tested. We also identify
the existence of inherent biases in these LLMs which is the root cause of the
aforementioned phenomenon and makes self-assessment tests unreliable. These
observations indicate that self-assessment tests are not the correct tools to
measure personality in LLMs. Through this paper, we hope to draw attention to
the shortcomings of current literature in measuring personality in LLMs and
call for developing tools for machine personality measurement.

---------------

### 05 Jan 2024 | [AFSPP: Agent Framework for Shaping Preference and Personality with Large  Language Models](https://arxiv.org/abs/2401.02870) | [⬇️](https://arxiv.org/pdf/2401.02870)
*Zihong He, Changwang Zhang* 

  The evolution of Large Language Models (LLMs) has introduced a new paradigm
for investigating human behavior emulation. Recent research has employed
LLM-based Agents to create a sociological research environment, in which agents
exhibit behavior based on the unfiltered characteristics of large language
models. However, these studies overlook the iterative development within a
human-like setting - Human preferences and personalities are complex, shaped by
various factors and subject to ongoing change as a result of environmental and
subjective influences. In light of this observation, we propose Agent Framework
for Shaping Preference and Personality (AFSPP), exploring the multifaceted
impact of social networks and subjective consciousness on LLM-based Agents'
preference and personality formation. With AFSPP, we have, for the first time,
successfully replicated several key findings from human personality
experiments. And other AFSPP-based experimental results indicate that plan
making, sensory perceptions and social networking with subjective information,
wield the most pronounced influence on preference shaping. AFSPP can
significantly enhance the efficiency and scope of psychological experiments,
while yielding valuable insights for Trustworthy Artificial Intelligence
research for strategies to prevent undesirable preference and personality
development.

---------------

### 30 Dec 2023 | [Machine Mindset: An MBTI Exploration of Large Language Models](https://arxiv.org/abs/2312.12999) | [⬇️](https://arxiv.org/pdf/2312.12999)
*Jiaxi Cui, Liuzhenghao Lv, Jing Wen, Rongsheng Wang, Jing Tang,  YongHong Tian, Li Yuan* 

  We present a novel approach for integrating Myers-Briggs Type Indicator
(MBTI) personality traits into large language models (LLMs), addressing the
challenges of personality consistency in personalized AI. Our method, "Machine
Mindset," involves a two-phase fine-tuning and Direct Preference Optimization
(DPO) to embed MBTI traits into LLMs. This approach ensures that models
internalize these traits, offering a stable and consistent personality profile.
We demonstrate the effectiveness of our models across various domains, showing
alignment between model performance and their respective MBTI traits. The paper
highlights significant contributions in the development of personality datasets
and a new training methodology for personality integration in LLMs, enhancing
the potential for personalized AI applications. We also open-sourced our model
and part of the data at \url{https://github.com/PKU-YuanGroup/Machine-Mindset}.

---------------

### 14 Jan 2024 | [PersonalityChat: Conversation Distillation for Personalized Dialog  Modeling with Facts and Traits](https://arxiv.org/abs/2401.07363) | [⬇️](https://arxiv.org/pdf/2401.07363)
*Ehsan Lotfi, Maxime De Bruyn, Jeska Buhmann, Walter Daelemans* 

  The new wave of Large Language Models (LLM) has offered an efficient tool to
curate sizeable conversational datasets. So far studies have mainly focused on
task-oriented or generic open-domain dialogs, and have not fully explored the
ability of LLMs in following complicated prompts. In this work, we focus on
personalization, and employ LLMs to curate a dataset which is difficult and
costly to crowd-source: PersonalityChat is a synthetic conversational dataset
based upon the popular PersonaChat dataset, but conditioned on both personas
and (Big-5) personality traits. Evaluating models fine-tuned on this dataset,
we show that the personality trait labels can be used for trait-based
personalization of generative dialogue models. We also perform a head-to-head
comparison between PersonalityChat and PersonaChat, and show that training on
the distilled dataset results in more fluent and coherent dialog agents in the
small-model regime.

---------------

### 23 Jan 2024 | [Assessing and Understanding Creativity in Large Language Models](https://arxiv.org/abs/2401.12491) | [⬇️](https://arxiv.org/pdf/2401.12491)
*Yunpu Zhao, Rui Zhang, Wenyi Li, Di Huang, Jiaming Guo, Shaohui Peng,  Yifan Hao, Yuanbo Wen, Xing Hu, Zidong Du, Qi Guo, Ling Li and Yunji Chen* 

  In the field of natural language processing, the rapid development of large
language model (LLM) has attracted more and more attention. LLMs have shown a
high level of creativity in various tasks, but the methods for assessing such
creativity are inadequate. The assessment of LLM creativity needs to consider
differences from humans, requiring multi-dimensional measurement while
balancing accuracy and efficiency. This paper aims to establish an efficient
framework for assessing the level of creativity in LLMs. By adapting the
modified Torrance Tests of Creative Thinking, the research evaluates the
creative performance of various LLMs across 7 tasks, emphasizing 4 criteria
including Fluency, Flexibility, Originality, and Elaboration. In this context,
we develop a comprehensive dataset of 700 questions for testing and an
LLM-based evaluation method. In addition, this study presents a novel analysis
of LLMs' responses to diverse prompts and role-play situations. We found that
the creativity of LLMs primarily falls short in originality, while excelling in
elaboration. Besides, the use of prompts and the role-play settings of the
model significantly influence creativity. Additionally, the experimental
results also indicate that collaboration among multiple LLMs can enhance
originality. Notably, our findings reveal a consensus between human evaluations
and LLMs regarding the personality traits that influence creativity. The
findings underscore the significant impact of LLM design on creativity and
bridges artificial intelligence and human creativity, offering insights into
LLMs' creativity and potential applications.

---------------

### 19 Feb 2024 | [LLM Agents for Psychology: A Study on Gamified Assessments](https://arxiv.org/abs/2402.12326) | [⬇️](https://arxiv.org/pdf/2402.12326)
*Qisen Yang, Zekun Wang, Honghui Chen, Shenzhi Wang, Yifan Pu, Xin Gao,  Wenhao Huang, Shiji Song, Gao Huang* 

  Psychological measurement is essential for mental health, self-understanding,
and personal development. Traditional methods, such as self-report scales and
psychologist interviews, often face challenges with engagement and
accessibility. While game-based and LLM-based tools have been explored to
improve user interest and automate assessment, they struggle to balance
engagement with generalizability. In this work, we propose PsychoGAT
(Psychological Game AgenTs) to achieve a generic gamification of psychological
assessment. The main insight is that powerful LLMs can function both as adept
psychologists and innovative game designers. By incorporating LLM agents into
designated roles and carefully managing their interactions, PsychoGAT can
transform any standardized scales into personalized and engaging interactive
fiction games. To validate the proposed method, we conduct psychometric
evaluations to assess its effectiveness and employ human evaluators to examine
the generated content across various psychological constructs, including
depression, cognitive distortions, and personality traits. Results demonstrate
that PsychoGAT serves as an effective assessment tool, achieving statistically
significant excellence in psychometric metrics such as reliability, convergent
validity, and discriminant validity. Moreover, human evaluations confirm
PsychoGAT's enhancements in content coherence, interactivity, interest,
immersion, and satisfaction.

---------------

### 21 Sep 2023 | [Personality Traits in Large Language Models](https://arxiv.org/abs/2307.00184) | [⬇️](https://arxiv.org/pdf/2307.00184)
*Greg Serapio-Garc\'ia, Mustafa Safdari, Cl\'ement Crepy, Luning Sun,  Stephen Fitz, Peter Romero, Marwa Abdulhai, Aleksandra Faust, Maja Matari\'c* 

  The advent of large language models (LLMs) has revolutionized natural
language processing, enabling the generation of coherent and contextually
relevant human-like text. As LLMs increasingly power conversational agents used
by the general public world-wide, the synthetic personality embedded in these
models, by virtue of training on large amounts of human data, is becoming
increasingly important. Since personality is a key factor determining the
effectiveness of communication, we present a comprehensive method for
administering and validating personality tests on widely-used LLMs, as well as
for shaping personality in the generated text of such LLMs. Applying this
method, we found: 1) personality measurements in the outputs of some LLMs under
specific prompting configurations are reliable and valid; 2) evidence of
reliability and validity of synthetic LLM personality is stronger for larger
and instruction fine-tuned models; and 3) personality in LLM outputs can be
shaped along desired dimensions to mimic specific human personality profiles.
We discuss application and ethical implications of the measurement and shaping
method, in particular regarding responsible AI.

---------------

### 13 Dec 2023 | [Finetuning an LLM on Contextual Knowledge of Classics for Q&A](https://arxiv.org/abs/2312.07848) | [⬇️](https://arxiv.org/pdf/2312.07848)
*Shane Storm Strachan* 

  The open-source publishing of large language models (LLMs) has created many
possibilities for how anyone who understands language and has access to a
computer can interact with significant tools of artificial intelligence,
particularly in the context of learning and knowledge dissemination. However,
the utility of these models in specialized fields like Classics is still
largely unexplored. This project is an attempt to merge the knowledge of
Classics with the capabilities of artificial intelligence by finetuning an LLM
to cater to the specific needs of learners and professionals. The goal of this
project is to develop an LLM that not only reproduces contextual knowledge
accurately but also exhibits a consistent "personality" - and, indeed, has
consistent propriety - to appeal to a diverse audience who possess differing
levels of knowledge. A significant portion of this project was dedicated to
refining the dataset, following the principle of "garbage in, garbage out," to
ensure the model generates relevant, useful, and creative responses when given
a prompt (a statement, question, or single word). After training and
evaluation, my model's ability to handle a vast array of different types of
inputs and prompting exceeded expectations for a 355M parameter model, though
its occasional hallucinations (especially when set with a high temperature),
particularly in its assertions about historical events or its own identity,
make it seem somewhat capricious and more work in the form of continuous
finetuning will be undertaken.

---------------

### 31 Jan 2024 | [LLMs Simulate Big Five Personality Traits: Further Evidence](https://arxiv.org/abs/2402.01765) | [⬇️](https://arxiv.org/pdf/2402.01765)
*Aleksandra Sorokovikova, Natalia Fedorova, Sharwin Rezagholi, Ivan P.  Yamshchikov* 

  An empirical investigation into the simulation of the Big Five personality
traits by large language models (LLMs), namely Llama2, GPT4, and Mixtral, is
presented. We analyze the personality traits simulated by these models and
their stability. This contributes to the broader understanding of the
capabilities of LLMs to simulate personality traits and the respective
implications for personalized human-computer interaction.

---------------

### 22 Feb 2024 | [Is Cognition and Action Consistent or Not: Investigating Large Language  Model's Personality](https://arxiv.org/abs/2402.14679) | [⬇️](https://arxiv.org/pdf/2402.14679)
*Yiming Ai, Zhiwei He, Ziyin Zhang, Wenhong Zhu, Hongkun Hao, Kai Yu,  Lingjun Chen and Rui Wang* 

  In this study, we investigate the reliability of Large Language Models (LLMs)
in professing human-like personality traits through responses to personality
questionnaires. Our goal is to evaluate the consistency between LLMs' professed
personality inclinations and their actual "behavior", examining the extent to
which these models can emulate human-like personality patterns. Through a
comprehensive analysis of LLM outputs against established human benchmarks, we
seek to understand the cognition-action divergence in LLMs and propose
hypotheses for the observed results based on psychological theories and
metrics.

---------------

### 28 Dec 2023 | [Revisiting the Reliability of Psychological Scales on Large Language  Models](https://arxiv.org/abs/2305.19926) | [⬇️](https://arxiv.org/pdf/2305.19926)
*Jen-tse Huang, Wenxuan Wang, Man Ho Lam, Eric John Li, Wenxiang Jiao,  Michael R. Lyu* 

  Recent research has extended beyond assessing the performance of Large
Language Models (LLMs) to examining their characteristics from a psychological
standpoint, acknowledging the necessity of understanding their behavioral
characteristics. The administration of personality tests to LLMs has emerged as
a noteworthy area in this context. However, the suitability of employing
psychological scales, initially devised for humans, on LLMs is a matter of
ongoing debate. Our study aims to determine the reliability of applying
personality assessments to LLMs, explicitly investigating whether LLMs
demonstrate consistent personality traits. Analyzing responses under 2,500
settings reveals that gpt-3.5-turbo shows consistency in responses to the Big
Five Inventory, indicating a high degree of reliability. Furthermore, our
research explores the potential of gpt-3.5-turbo to emulate diverse
personalities and represent various groups, which is a capability increasingly
sought after in social sciences for substituting human participants with LLMs
to reduce costs. Our findings reveal that LLMs have the potential to represent
different personalities with specific prompt instructions. By shedding light on
the personalization of LLMs, our study endeavors to pave the way for future
explorations in this field. We have made our experimental results and the
corresponding code openly accessible via
https://github.com/CUHK-ARISE/LLMPersonality.

---------------

### 02 Jan 2024 | [Self-Assessment Tests are Unreliable Measures of LLM Personality](https://arxiv.org/abs/2309.08163) | [⬇️](https://arxiv.org/pdf/2309.08163)
*Akshat Gupta, Xiaoyang Song, Gopala Anumanchipalli* 

  As large language models (LLM) evolve in their capabilities, various recent
studies have tried to quantify their behavior using psychological tools created
to study human behavior. One such example is the measurement of "personality"
of LLMs using self-assessment personality tests developed to measure human
personality. Yet almost none of these works verify the applicability of these
tests on LLMs. In this paper, we analyze the reliability of LLM personality
scores obtained from self-assessment personality tests using two simple
experiments. We first introduce the property of prompt sensitivity, where three
semantically equivalent prompts representing three intuitive ways of
administering self-assessment tests on LLMs are used to measure the personality
of the same LLM. We find that all three prompts lead to very different
personality scores, a difference that is statistically significant for all
traits in a large majority of scenarios. We then introduce the property of
option-order symmetry for personality measurement of LLMs. Since most of the
self-assessment tests exist in the form of multiple choice question (MCQ)
questions, we argue that the scores should also be robust to not just the
prompt template but also the order in which the options are presented. This
test unsurprisingly reveals that the self-assessment test scores are not robust
to the order of the options. These simple tests, done on ChatGPT and three
Llama2 models of different sizes, show that self-assessment personality tests
created for humans are unreliable measures of personality in LLMs.

---------------

### 06 Jan 2024 | [Tailoring Personality Traits in Large Language Models via  Unsupervisedly-Built Personalized Lexicons](https://arxiv.org/abs/2310.16582) | [⬇️](https://arxiv.org/pdf/2310.16582)
*Tianlong Li, Shihan Dou, Changze Lv, Wenhao Liu, Jianhan Xu, Muling  Wu, Zixuan Ling, Xiaoqing Zheng and Xuanjing Huang* 

  Personality plays a pivotal role in shaping human expression patterns, thus
regulating the personality of large language models (LLMs) holds significant
potential in enhancing the user experience of LLMs. Previous methods either
relied on fine-tuning LLMs on specific corpora or necessitated manually crafted
prompts to elicit specific personalities from LLMs. However, the former
approach is inefficient and costly, while the latter cannot precisely
manipulate personality traits at a fine-grained level. To address the above
challenges, we have employed a novel Unsupervisedly-Built Personalized Lexicons
(UBPL) in a pluggable manner during the decoding phase of LLMs to manipulate
their personality traits. UBPL is a lexicon built through an unsupervised
approach from a situational judgment test dataset (SJTs4LLM). Users can utilize
UBPL to adjust the probability vectors of predicted words in the decoding phase
of LLMs, thus influencing the personality expression of LLMs. Extensive
experimentation demonstrates the remarkable effectiveness and pluggability of
our method for fine-grained manipulation of LLM's personality.

---------------

### 21 Nov 2023 | [Editing Personality for LLMs](https://arxiv.org/abs/2310.02168) | [⬇️](https://arxiv.org/pdf/2310.02168)
*Shengyu Mao, Ningyu Zhang, Xiaohan Wang, Mengru Wang, Yunzhi Yao, Yong  Jiang, Pengjun Xie, Fei Huang, Huajun Chen* 

  This paper introduces an innovative task focused on editing the personality
traits of Large Language Models (LLMs). This task seeks to adjust the models'
responses to opinion-related questions on specified topics since an
individual's personality often manifests in the form of their expressed
opinions, thereby showcasing different personality traits. Specifically, we
construct a new benchmark dataset PersonalityEdit to address this task. Drawing
on the theory in Social Psychology, we isolate three representative traits,
namely Neuroticism, Extraversion, and Agreeableness, as the foundation for our
benchmark. We then gather data using GPT-4, generating responses that not only
align with a specified topic but also embody the targeted personality trait. We
conduct comprehensive experiments involving various baselines and discuss the
representation of personality behavior in LLMs. Our intriguing findings uncover
potential challenges of the proposed task, illustrating several remaining
issues. We anticipate that our work can provide the NLP community with
insights. Code and datasets will be released at
https://github.com/zjunlp/EasyEdit.

---------------

### 19 Feb 2024 | [Your Large Language Model is Secretly a Fairness Proponent and You  Should Prompt it Like One](https://arxiv.org/abs/2402.12150) | [⬇️](https://arxiv.org/pdf/2402.12150)
*Tianlin Li, Xiaoyu Zhang, Chao Du, Tianyu Pang, Qian Liu, Qing Guo,  Chao Shen, Yang Liu* 

  The widespread adoption of large language models (LLMs) underscores the
urgent need to ensure their fairness. However, LLMs frequently present dominant
viewpoints while ignoring alternative perspectives from minority parties,
resulting in potential biases. We hypothesize that these fairness-violating
behaviors occur because LLMs express their viewpoints using a human personality
that represents the majority of training data. In response to this, we validate
that prompting LLMs with specific roles can allow LLMs to express diverse
viewpoints. Building on this insight and observation, we develop FairThinking,
a pipeline designed to automatically generate roles that enable LLMs to
articulate diverse perspectives for fair expressions. To evaluate FairThinking,
we create a dataset with a thousand items covering three fairness-related
topics and conduct experiments on GPT-3.5, GPT-4, Llama2, and Mistral to
demonstrate its superior performance.

---------------

### 05 Nov 2023 | [PsyCoT: Psychological Questionnaire as Powerful Chain-of-Thought for  Personality Detection](https://arxiv.org/abs/2310.20256) | [⬇️](https://arxiv.org/pdf/2310.20256)
*Tao Yang, Tianyuan Shi, Fanqi Wan, Xiaojun Quan, Qifan Wang, Bingzhe  Wu, Jiaxiang Wu* 

  Recent advances in large language models (LLMs), such as ChatGPT, have
showcased remarkable zero-shot performance across various NLP tasks. However,
the potential of LLMs in personality detection, which involves identifying an
individual's personality from their written texts, remains largely unexplored.
Drawing inspiration from Psychological Questionnaires, which are carefully
designed by psychologists to evaluate individual personality traits through a
series of targeted items, we argue that these items can be regarded as a
collection of well-structured chain-of-thought (CoT) processes. By
incorporating these processes, LLMs can enhance their capabilities to make more
reasonable inferences on personality from textual input. In light of this, we
propose a novel personality detection method, called PsyCoT, which mimics the
way individuals complete psychological questionnaires in a multi-turn dialogue
manner. In particular, we employ a LLM as an AI assistant with a specialization
in text analysis. We prompt the assistant to rate individual items at each turn
and leverage the historical rating results to derive a conclusive personality
preference. Our experiments demonstrate that PsyCoT significantly improves the
performance and robustness of GPT-3.5 in personality detection, achieving an
average F1 score improvement of 4.23/10.63 points on two benchmark datasets
compared to the standard prompting method. Our code is available at
https://github.com/TaoYang225/PsyCoT.

---------------

### 10 Jan 2024 | [A General-purpose AI Avatar in Healthcare](https://arxiv.org/abs/2401.12981) | [⬇️](https://arxiv.org/pdf/2401.12981)
*Nicholas Yan, Gil Alterovitz* 

  Recent advancements in machine learning and natural language processing have
led to the rapid development of artificial intelligence (AI) as a valuable tool
in the healthcare industry. Using large language models (LLMs) as
conversational agents or chatbots has the potential to assist doctors in
diagnosing patients, detecting early symptoms of diseases, and providing health
advice to patients. This paper focuses on the role of chatbots in healthcare
and explores the use of avatars to make AI interactions more appealing to
patients. A framework of a general-purpose AI avatar application is
demonstrated by using a three-category prompt dictionary and prompt improvement
mechanism. A two-phase approach is suggested to fine-tune a general-purpose AI
language model and create different AI avatars to discuss medical issues with
users. Prompt engineering enhances the chatbot's conversational abilities and
personality traits, fostering a more human-like interaction with patients.
Ultimately, the injection of personality into the chatbot could potentially
increase patient engagement. Future directions for research include
investigating ways to improve chatbots' understanding of context and ensuring
the accuracy of their outputs through fine-tuning with specialized medical data
sets.

---------------

### 13 Sep 2023 | [Large Language Models Can Infer Psychological Dispositions of Social  Media Users](https://arxiv.org/abs/2309.08631) | [⬇️](https://arxiv.org/pdf/2309.08631)
*Heinrich Peters and Sandra Matz* 

  As Large Language Models (LLMs) demonstrate increasingly human-like abilities
in various natural language processing (NLP) tasks that are bound to become
integral to personalized technologies, understanding their capabilities and
inherent biases is crucial. Our study investigates the potential of LLMs like
ChatGPT to infer psychological dispositions of individuals from their digital
footprints. Specifically, we assess the ability of GPT-3.5 and GPT-4 to derive
the Big Five personality traits from users' Facebook status updates in a
zero-shot learning scenario. Our results show an average correlation of r = .29
(range = [.22, .33]) between LLM-inferred and self-reported trait scores.
Furthermore, our findings suggest biases in personality inferences with regard
to gender and age: inferred scores demonstrated smaller errors for women and
younger individuals on several traits, suggesting a potential systematic bias
stemming from the underlying training data or differences in online
self-expression.

---------------

### 03 Dec 2023 | [Personality of AI](https://arxiv.org/abs/2312.02998) | [⬇️](https://arxiv.org/pdf/2312.02998)
*Byunggu Yu and Junwhan Kim* 

  This research paper delves into the evolving landscape of fine-tuning large
language models (LLMs) to align with human users, extending beyond basic
alignment to propose "personality alignment" for language models in
organizational settings. Acknowledging the impact of training methods on the
formation of undefined personality traits in AI models, the study draws
parallels with human fitting processes using personality tests. Through an
original case study, we demonstrate the necessity of personality fine-tuning
for AIs and raise intriguing questions about applying human-designed tests to
AIs, engineering specialized AI personality tests, and shaping AI personalities
to suit organizational roles. The paper serves as a starting point for
discussions and developments in the burgeoning field of AI personality
alignment, offering a foundational anchor for future exploration in
human-machine teaming and co-existence.

---------------
**Date:** 21 Feb 2024

**Title:** Driving Generative Agents With Their Personality

**Abstract Link:** [https://arxiv.org/abs/2402.14879](https://arxiv.org/abs/2402.14879)

**PDF Link:** [https://arxiv.org/pdf/2402.14879](https://arxiv.org/pdf/2402.14879)

---

**Date:** 24 May 2023

**Title:** Have Large Language Models Developed a Personality?: Applicability of  Self-Assessment Tests in Measuring Personality in LLMs

**Abstract Link:** [https://arxiv.org/abs/2305.14693](https://arxiv.org/abs/2305.14693)

**PDF Link:** [https://arxiv.org/pdf/2305.14693](https://arxiv.org/pdf/2305.14693)

---

**Date:** 05 Jan 2024

**Title:** AFSPP: Agent Framework for Shaping Preference and Personality with Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.02870](https://arxiv.org/abs/2401.02870)

**PDF Link:** [https://arxiv.org/pdf/2401.02870](https://arxiv.org/pdf/2401.02870)

---

**Date:** 30 Dec 2023

**Title:** Machine Mindset: An MBTI Exploration of Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2312.12999](https://arxiv.org/abs/2312.12999)

**PDF Link:** [https://arxiv.org/pdf/2312.12999](https://arxiv.org/pdf/2312.12999)

---

**Date:** 14 Jan 2024

**Title:** PersonalityChat: Conversation Distillation for Personalized Dialog  Modeling with Facts and Traits

**Abstract Link:** [https://arxiv.org/abs/2401.07363](https://arxiv.org/abs/2401.07363)

**PDF Link:** [https://arxiv.org/pdf/2401.07363](https://arxiv.org/pdf/2401.07363)

---

**Date:** 23 Jan 2024

**Title:** Assessing and Understanding Creativity in Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.12491](https://arxiv.org/abs/2401.12491)

**PDF Link:** [https://arxiv.org/pdf/2401.12491](https://arxiv.org/pdf/2401.12491)

---

**Date:** 19 Feb 2024

**Title:** LLM Agents for Psychology: A Study on Gamified Assessments

**Abstract Link:** [https://arxiv.org/abs/2402.12326](https://arxiv.org/abs/2402.12326)

**PDF Link:** [https://arxiv.org/pdf/2402.12326](https://arxiv.org/pdf/2402.12326)

---

**Date:** 21 Sep 2023

**Title:** Personality Traits in Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2307.00184](https://arxiv.org/abs/2307.00184)

**PDF Link:** [https://arxiv.org/pdf/2307.00184](https://arxiv.org/pdf/2307.00184)

---

**Date:** 13 Dec 2023

**Title:** Finetuning an LLM on Contextual Knowledge of Classics for Q&A

**Abstract Link:** [https://arxiv.org/abs/2312.07848](https://arxiv.org/abs/2312.07848)

**PDF Link:** [https://arxiv.org/pdf/2312.07848](https://arxiv.org/pdf/2312.07848)

---

**Date:** 31 Jan 2024

**Title:** LLMs Simulate Big Five Personality Traits: Further Evidence

**Abstract Link:** [https://arxiv.org/abs/2402.01765](https://arxiv.org/abs/2402.01765)

**PDF Link:** [https://arxiv.org/pdf/2402.01765](https://arxiv.org/pdf/2402.01765)

---

**Date:** 22 Feb 2024

**Title:** Is Cognition and Action Consistent or Not: Investigating Large Language  Model's Personality

**Abstract Link:** [https://arxiv.org/abs/2402.14679](https://arxiv.org/abs/2402.14679)

**PDF Link:** [https://arxiv.org/pdf/2402.14679](https://arxiv.org/pdf/2402.14679)

---

**Date:** 28 Dec 2023

**Title:** Revisiting the Reliability of Psychological Scales on Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2305.19926](https://arxiv.org/abs/2305.19926)

**PDF Link:** [https://arxiv.org/pdf/2305.19926](https://arxiv.org/pdf/2305.19926)

---

**Date:** 02 Jan 2024

**Title:** Self-Assessment Tests are Unreliable Measures of LLM Personality

**Abstract Link:** [https://arxiv.org/abs/2309.08163](https://arxiv.org/abs/2309.08163)

**PDF Link:** [https://arxiv.org/pdf/2309.08163](https://arxiv.org/pdf/2309.08163)

---

**Date:** 06 Jan 2024

**Title:** Tailoring Personality Traits in Large Language Models via  Unsupervisedly-Built Personalized Lexicons

**Abstract Link:** [https://arxiv.org/abs/2310.16582](https://arxiv.org/abs/2310.16582)

**PDF Link:** [https://arxiv.org/pdf/2310.16582](https://arxiv.org/pdf/2310.16582)

---

**Date:** 21 Nov 2023

**Title:** Editing Personality for LLMs

**Abstract Link:** [https://arxiv.org/abs/2310.02168](https://arxiv.org/abs/2310.02168)

**PDF Link:** [https://arxiv.org/pdf/2310.02168](https://arxiv.org/pdf/2310.02168)

---

**Date:** 19 Feb 2024

**Title:** Your Large Language Model is Secretly a Fairness Proponent and You  Should Prompt it Like One

**Abstract Link:** [https://arxiv.org/abs/2402.12150](https://arxiv.org/abs/2402.12150)

**PDF Link:** [https://arxiv.org/pdf/2402.12150](https://arxiv.org/pdf/2402.12150)

---

**Date:** 05 Nov 2023

**Title:** PsyCoT: Psychological Questionnaire as Powerful Chain-of-Thought for  Personality Detection

**Abstract Link:** [https://arxiv.org/abs/2310.20256](https://arxiv.org/abs/2310.20256)

**PDF Link:** [https://arxiv.org/pdf/2310.20256](https://arxiv.org/pdf/2310.20256)

---

**Date:** 10 Jan 2024

**Title:** A General-purpose AI Avatar in Healthcare

**Abstract Link:** [https://arxiv.org/abs/2401.12981](https://arxiv.org/abs/2401.12981)

**PDF Link:** [https://arxiv.org/pdf/2401.12981](https://arxiv.org/pdf/2401.12981)

---

**Date:** 13 Sep 2023

**Title:** Large Language Models Can Infer Psychological Dispositions of Social  Media Users

**Abstract Link:** [https://arxiv.org/abs/2309.08631](https://arxiv.org/abs/2309.08631)

**PDF Link:** [https://arxiv.org/pdf/2309.08631](https://arxiv.org/pdf/2309.08631)

---

**Date:** 03 Dec 2023

**Title:** Personality of AI

**Abstract Link:** [https://arxiv.org/abs/2312.02998](https://arxiv.org/abs/2312.02998)

**PDF Link:** [https://arxiv.org/pdf/2312.02998](https://arxiv.org/pdf/2312.02998)

---

