Research Leaders 🎯

### 🔎 Research Leaders 🎯

💡🔬🔭

# Research Leaders 🎯💡🔬🔭

## Research Leaders 🎯💡🔬🔭

Research Leaders is a series of interviews with researchers from all over the world. We want to know what they are working on, what inspires them, and what they are passionate about.

We believe that research is not only about data and facts, but also about people and their stories. That's why we want to share these stories with you, to inspire and motivate you to learn more about the world and yourself.

If you want to be featured in our series, please contact us at [email protected] We would love to hear from you!

## Research Leaders 🎯💡🔬🔭

Research Leaders is a series of interviews with researchers from all over the world. We want to know what they are working on, what inspires them, and what they are passionate about.

We believe that research is not only about data and facts, but also about people and their stories. That's why we want to share these stories with you, to inspire and motivate you to learn more about the world and yourself.

If you want to be featured in our series, please contact us at [email protected] We would love to hear from you!

## Research Leaders 🎯💡🔬🔭

Research Leaders is a series of interviews with researchers from all over the world. We want to know what they are working on, what inspires them, and what they are passionate about.

We believe that research is not only about data and facts, but also about people and their stories. That's why we want to share these stories with you, to inspire and motivate you to learn more about the world and yourself.

If you want to be featured in our series, please contact us at [email protected] We would love to hear from you!

## Research Leaders 🎯💡🔬🔭

Research Leaders is a series of interviews with researchers from all over the world. We want to know what they are working on
# 🩺🔍 Search Results
### 16 Apr 2014 | [Partially Observed, Multi-objective Markov Games](https://arxiv.org/abs/1404.4388) | [⬇️](https://arxiv.org/pdf/1404.4388)
*Yanling Chang, Alan L. Erera, and Chelsea C. White III* 

  The intent of this research is to generate a set of non-dominated policies
from which one of two agents (the leader) can select a most preferred policy to
control a dynamic system that is also affected by the control decisions of the
other agent (the follower). The problem is described by an infinite horizon,
partially observed Markov game (POMG). At each decision epoch, each agent
knows: its past and present states, its past actions, and noise corrupted
observations of the other agent's past and present states. The actions of each
agent are determined at each decision epoch based on these data. The leader
considers multiple objectives in selecting its policy. The follower considers a
single objective in selecting its policy with complete knowledge of and in
response to the policy selected by the leader. This leader-follower assumption
allows the POMG to be transformed into a specially structured, partially
observed Markov decision process (POMDP). This POMDP is used to determine the
follower's best response policy. A multi-objective genetic algorithm (MOGA) is
used to create the next generation of leader policies based on the fitness
measures of each leader policy in the current generation. Computing a fitness
measure for a leader policy requires a value determination calculation, given
the leader policy and the follower's best response policy. The policies from
which the leader can select a most preferred policy are the non-dominated
policies of the final generation of leader policies created by the MOGA. An
example is presented that illustrates how these results can be used to support
a manager of a liquid egg production process (the leader) in selecting a
sequence of actions to best control this process over time, given that there is
an attacker (the follower) who seeks to contaminate the liquid egg production
process with a chemical or biological toxin.

---------------

### 10 May 2023 | [ORKG-Leaderboards: A Systematic Workflow for Mining Leaderboards as a  Knowledge Graph](https://arxiv.org/abs/2305.11068) | [⬇️](https://arxiv.org/pdf/2305.11068)
*Salomon Kabongo, Jennifer D'Souza and S\"oren Auer* 

  The purpose of this work is to describe the Orkg-Leaderboard software
designed to extract leaderboards defined as Task-Dataset-Metric tuples
automatically from large collections of empirical research papers in Artificial
Intelligence (AI). The software can support both the main workflows of
scholarly publishing, viz. as LaTeX files or as PDF files. Furthermore, the
system is integrated with the Open Research Knowledge Graph (ORKG) platform,
which fosters the machine-actionable publishing of scholarly findings. Thus the
system output, when integrated within the ORKG's supported Semantic Web
infrastructure of representing machine-actionable 'resources' on the Web,
enables: 1) broadly, the integration of empirical results of researchers across
the world, thus enabling transparency in empirical research with the potential
to also being complete contingent on the underlying data source(s) of
publications; and 2) specifically, enables researchers to track the progress in
AI with an overview of the state-of-the-art (SOTA) across the most common AI
tasks and their corresponding datasets via dynamic ORKG frontend views
leveraging tables and visualization charts over the machine-actionable data.
Our best model achieves performances above 90% F1 on the \textit{leaderboard}
extraction task, thus proving Orkg-Leaderboards a practically viable tool for
real-world usage. Going forward, in a sense, Orkg-Leaderboards transforms the
leaderboard extraction task to an automated digitalization task, which has
been, for a long time in the community, a crowdsourced endeavor.

---------------

### 31 Aug 2021 | [Automated Mining of Leaderboards for Empirical AI Research](https://arxiv.org/abs/2109.13089) | [⬇️](https://arxiv.org/pdf/2109.13089)
*Salomon Kabongo, Jennifer D'Souza, and S\"oren Auer* 

  With the rapid growth of research publications, empowering scientists to keep
oversight over the scientific progress is of paramount importance. In this
regard, the Leaderboards facet of information organization provides an overview
on the state-of-the-art by aggregating empirical results from various studies
addressing the same research challenge. Crowdsourcing efforts like
PapersWithCode among others are devoted to the construction of Leaderboards
predominantly for various subdomains in Artificial Intelligence. Leaderboards
provide machine-readable scholarly knowledge that has proven to be directly
useful for scientists to keep track of research progress. The construction of
Leaderboards could be greatly expedited with automated text mining.
  This study presents a comprehensive approach for generating Leaderboards for
knowledge-graph-based scholarly information organization. Specifically, we
investigate the problem of automated Leaderboard construction using
state-of-the-art transformer models, viz. Bert, SciBert, and XLNet. Our
analysis reveals an optimal approach that significantly outperforms existing
baselines for the task with evaluation scores above 90% in F1. This, in turn,
offers new state-of-the-art results for Leaderboard extraction. As a result, a
vast share of empirical AI research can be organized in the next-generation
digital libraries as knowledge graphs.

---------------

### 12 Aug 2023 | [Robot formation control in nonlinear manifold using Koopman operator  theory](https://arxiv.org/abs/2205.04052) | [⬇️](https://arxiv.org/pdf/2205.04052)
*Yanran Wang, Tatsuya Baba, Takashi Hikihara* 

  Formation control of multi-agent systems has been a prominent research topic,
spanning both theoretical and practical domains over the past two decades. Our
study delves into the leader-follower framework, addressing two critical,
previously overlooked aspects. Firstly, we investigate the impact of an unknown
nonlinear manifold, introducing added complexity to the formation control
challenge. Secondly, we address the practical constraint of limited follower
sensing range, posing difficulties in accurately localizing the leader for
followers. Our core objective revolves around employing Koopman operator theory
and Extended Dynamic Mode Decomposition to craft a reliable prediction
algorithm for the follower robot to anticipate the leader's position
effectively. Our experimentation on an elliptical paraboloid manifold,
utilizing two omni-directional wheeled robots, validates the prediction
algorithm's effectiveness.

---------------

### 15 May 2020 | [Uncovering Gender Bias in Media Coverage of Politicians with Machine  Learning](https://arxiv.org/abs/2005.07734) | [⬇️](https://arxiv.org/pdf/2005.07734)
*Susan Leavy* 

  This paper presents research uncovering systematic gender bias in the
representation of political leaders in the media, using artificial
intelligence. Newspaper coverage of Irish ministers over a fifteen year period
was gathered and analysed with natural language processing techniques and
machine learning. Findings demonstrate evidence of gender bias in the portrayal
of female politicians, the kind of policies they were associated with and how
they were evaluated in terms of their performance as political leaders. This
paper also sets out a methodology whereby media content may be analysed on a
large scale utilising techniques from artificial intelligence within a
theoretical framework founded in gender theory and feminist linguistics.

---------------

### 20 Sep 2018 | [Architecture of Text Mining Application in Analyzing Public Sentiments  of West Java Governor Election using Naive Bayes Classification](https://arxiv.org/abs/1810.07767) | [⬇️](https://arxiv.org/pdf/1810.07767)
*Suryanto Nugroho, Prihandoko* 

  The selection of West Java governor is one event that seizes the attention of
the public is no exception to social media users. Public opinion on a
prospective regional leader can help predict electability and tendency of
voters. Data that can be used by the opinion mining process can be obtained
from Twitter. Because the data is very varied form and very unstructured, it
must be managed and uninformed using data pre-processing techniques into
semi-structured data. This semi-structured information is followed by a
classification stage to categorize the opinion into negative or positive
opinions. The research methodology uses a literature study where the research
will examine previous research on a similar topic. The purpose of this study is
to find the right architecture to develop it into the application of twitter
opinion mining to know public sentiments toward the election of the governor of
west java. The result of this research is that Twitter opinion mining is part
of text mining where opinions in Twitter if they want to be classified, must go
through the preprocessing text stage first. The preprocessing step required
from twitter data is cleansing, case folding, POS Tagging and stemming. The
resulting text mining architecture is an architecture that can be used for text
mining research with different topics.

---------------

### 20 Mar 2023 | [Self-Improving-Leaderboard(SIL): A Call for Real-World Centric Natural  Language Processing Leaderboards](https://arxiv.org/abs/2303.10888) | [⬇️](https://arxiv.org/pdf/2303.10888)
*Chanjun Park, Hyeonseok Moon, Seolhwa Lee, Jaehyung Seo, Sugyeong Eo  and Heuiseok Lim* 

  Leaderboard systems allow researchers to objectively evaluate Natural
Language Processing (NLP) models and are typically used to identify models that
exhibit superior performance on a given task in a predetermined setting.
However, we argue that evaluation on a given test dataset is just one of many
performance indications of the model. In this paper, we claim leaderboard
competitions should also aim to identify models that exhibit the best
performance in a real-world setting. We highlight three issues with current
leaderboard systems: (1) the use of a single, static test set, (2) discrepancy
between testing and real-world application (3) the tendency for
leaderboard-centric competition to be biased towards the test set. As a
solution, we propose a new paradigm of leaderboard systems that addresses these
issues of current leaderboard system. Through this study, we hope to induce a
paradigm shift towards more real -world-centric leaderboard competitions.

---------------

### 29 May 2017 | [Human-Robot Collaboration: From Psychology to Social Robotics](https://arxiv.org/abs/1705.10146) | [⬇️](https://arxiv.org/pdf/1705.10146)
*Judith B\"utepage, Danica Kragic* 

  With the advances in robotic technology, research in human-robot
collaboration (HRC) has gained in importance. For robots to interact with
humans autonomously they need active decision making that takes human partners
into account. However, state-of-the-art research in HRC does often assume a
leader-follower division, in which one agent leads the interaction. We believe
that this is caused by the lack of a reliable representation of the human and
the environment to allow autonomous decision making. This problem can be
overcome by an embodied approach to HRC which is inspired by psychological
studies of human-human interaction (HHI). In this survey, we review
neuroscientific and psychological findings of the sensorimotor patterns that
govern HHI and view them in a robotics context. Additionally, we study the
advances made by the robotic community into the direction of embodied HRC. We
focus on the mechanisms that are required for active, physical human-robot
collaboration. Finally, we discuss the similarities and differences in the two
fields of study which pinpoint directions of future research.

---------------

### 12 Jun 2023 | [On building machine learning pipelines for Android malware detection: a  procedural survey of practices, challenges and opportunities](https://arxiv.org/abs/2306.07118) | [⬇️](https://arxiv.org/pdf/2306.07118)
*Masoud Mehrabi Koushki, Ibrahim AbuAlhaol, Anandharaju Durai Raju,  Yang Zhou, Ronnie Salvador Giagone and Huang Shengqiang* 

  As the smartphone market leader, Android has been a prominent target for
malware attacks. The number of malicious applications (apps) identified for it
has increased continually over the past decade, creating an immense challenge
for all parties involved. For market holders and researchers, in particular,
the large number of samples has made manual malware detection unfeasible,
leading to an influx of research that investigate Machine Learning (ML)
approaches to automate this process. However, while some of the proposed
approaches achieve high performance, rapidly evolving Android malware has made
them unable to maintain their accuracy over time. This has created a need in
the community to conduct further research, and build more flexible ML
pipelines. Doing so, however, is currently hindered by a lack of systematic
overview of the existing literature, to learn from and improve upon the
existing solutions. Existing survey papers often focus only on parts of the ML
process (e.g., data collection or model deployment), while omitting other
important stages, such as model evaluation and explanation. In this paper, we
address this problem with a review of 42 highly-cited papers, spanning a decade
of research (from 2011 to 2021). We introduce a novel procedural taxonomy of
the published literature, covering how they have used ML algorithms, what
features they have engineered, which dimensionality reduction techniques they
have employed, what datasets they have employed for training, and what their
evaluation and explanation strategies are. Drawing from this taxonomy, we also
identify gaps in knowledge and provide ideas for improvement and future work.

---------------

### 05 Nov 2019 | [Response to NITRD, NCO, NSF Request for Information on "Update to the  2016 National Artificial Intelligence Research and Development Strategic  Plan"](https://arxiv.org/abs/1911.05796) | [⬇️](https://arxiv.org/pdf/1911.05796)
*J. Amundson, J. Annis, C. Avestruz, D. Bowring, J. Caldeira, G.  Cerati, C. Chang, S. Dodelson, D. Elvira, A. Farahi, K. Genser, L. Gray, O.  Gutsche, P. Harris, J. Kinney, J. B. Kowalkowski, R. Kutschke, S. Mrenna, B.  Nord, A. Para, K. Pedro, G. N. Perdue, A. Scheinker, P. Spentzouris, J. St.  John, N. Tran, S. Trivedi, L. Trouille, W. L. K. Wu, C. R. Bom* 

  We present a response to the 2018 Request for Information (RFI) from the
NITRD, NCO, NSF regarding the "Update to the 2016 National Artificial
Intelligence Research and Development Strategic Plan." Through this document,
we provide a response to the question of whether and how the National
Artificial Intelligence Research and Development Strategic Plan (NAIRDSP)
should be updated from the perspective of Fermilab, America's premier national
laboratory for High Energy Physics (HEP). We believe the NAIRDSP should be
extended in light of the rapid pace of development and innovation in the field
of Artificial Intelligence (AI) since 2016, and present our recommendations
below. AI has profoundly impacted many areas of human life, promising to
dramatically reshape society --- e.g., economy, education, science --- in the
coming years. We are still early in this process. It is critical to invest now
in this technology to ensure it is safe and deployed ethically. Science and
society both have a strong need for accuracy, efficiency, transparency, and
accountability in algorithms, making investments in scientific AI particularly
valuable. Thus far the US has been a leader in AI technologies, and we believe
as a national Laboratory it is crucial to help maintain and extend this
leadership. Moreover, investments in AI will be important for maintaining US
leadership in the physical sciences.

---------------

### 21 Apr 2020 | [What Question Answering can Learn from Trivia Nerds](https://arxiv.org/abs/1910.14464) | [⬇️](https://arxiv.org/pdf/1910.14464)
*Jordan Boyd-Graber, Benjamin B\"orschinger* 

  In addition to the traditional task of getting machines to answer questions,
a major research question in question answering is to create interesting,
challenging questions that can help systems learn how to answer questions and
also reveal which systems are the best at answering questions. We argue that
creating a question answering dataset -- and the ubiquitous leaderboard that
goes with it -- closely resembles running a trivia tournament: you write
questions, have agents (either humans or machines) answer the questions, and
declare a winner. However, the research community has ignored the decades of
hard-learned lessons from decades of the trivia community creating vibrant,
fair, and effective question answering competitions. After detailing problems
with existing QA datasets, we outline the key lessons -- removing ambiguity,
discriminating skill, and adjudicating disputes -- that can transfer to QA
research and how they might be implemented for the QA community.

---------------

### 21 Jun 2019 | [Identification of Tasks, Datasets, Evaluation Metrics, and Numeric  Scores for Scientific Leaderboards Construction](https://arxiv.org/abs/1906.09317) | [⬇️](https://arxiv.org/pdf/1906.09317)
*Yufang Hou, Charles Jochim, Martin Gleize, Francesca Bonin and Debasis  Ganguly* 

  While the fast-paced inception of novel tasks and new datasets helps foster
active research in a community towards interesting directions, keeping track of
the abundance of research activity in different areas on different datasets is
likely to become increasingly difficult. The community could greatly benefit
from an automatic system able to summarize scientific results, e.g., in the
form of a leaderboard. In this paper we build two datasets and develop a
framework (TDMS-IE) aimed at automatically extracting task, dataset, metric and
score from NLP papers, towards the automatic construction of leaderboards.
Experiments show that our model outperforms several baselines by a large
margin. Our model is a first step towards automatic leaderboard construction,
e.g., in the NLP domain.

---------------

### 12 Apr 2022 | [Sentiment Analysis of Political Tweets for Israel using Machine Learning](https://arxiv.org/abs/2204.06515) | [⬇️](https://arxiv.org/pdf/2204.06515)
*Amisha Gangwar, Tanvi Mehta* 

  Sentiment Analysis is a vital research topic in the field of Computer
Science. With the accelerated development of Information Technology and social
networks, a massive amount of data related to comment texts has been generated
on web applications or social media platforms like Twitter. Due to this, people
have actively started proliferating general information and the information
related to political opinions, which becomes an important reason for analyzing
public reactions. Most researchers have used social media specifics or contents
to analyze and predict public opinion concerning political events. This
research proposes an analytical study using Israeli political Twitter data to
interpret public opinion towards the Palestinian-Israeli conflict. The
attitudes of ethnic groups and opinion leaders in the form of tweets are
analyzed using Machine Learning algorithms like Support Vector Classifier
(SVC), Decision Tree (DT), and Naive Bayes (NB). Finally, a comparative
analysis is done based on experimental results from different models.

---------------

### 10 Dec 2021 | [Practical and Private (Deep) Learning without Sampling or Shuffling](https://arxiv.org/abs/2103.00039) | [⬇️](https://arxiv.org/pdf/2103.00039)
*Peter Kairouz, Brendan McMahan, Shuang Song, Om Thakkar, Abhradeep  Thakurta, Zheng Xu* 

  We consider training models with differential privacy (DP) using mini-batch
gradients. The existing state-of-the-art, Differentially Private Stochastic
Gradient Descent (DP-SGD), requires privacy amplification by sampling or
shuffling to obtain the best privacy/accuracy/computation trade-offs.
Unfortunately, the precise requirements on exact sampling and shuffling can be
hard to obtain in important practical scenarios, particularly federated
learning (FL). We design and analyze a DP variant of
Follow-The-Regularized-Leader (DP-FTRL) that compares favorably (both
theoretically and empirically) to amplified DP-SGD, while allowing for much
more flexible data access patterns. DP-FTRL does not use any form of privacy
amplification.
  The code is available at
https://github.com/google-research/federated/tree/master/dp_ftrl and
https://github.com/google-research/DP-FTRL .

---------------

### 26 Jan 2024 | [Techniques to Detect Crime Leaders within a Criminal Network: A Survey,  Experimental, and Comparative Evaluations](https://arxiv.org/abs/2402.03355) | [⬇️](https://arxiv.org/pdf/2402.03355)
*Kamal Taha and Abdulhadi Shoufan* 

  This survey paper offers a thorough analysis of techniques and algorithms
used in the identification of crime leaders within criminal networks. For each
technique, the paper examines its effectiveness, limitations, potential for
improvement, and future prospects. The main challenge faced by existing survey
papers focusing on algorithms for identifying crime leaders and predicting
crimes is effectively categorizing these algorithms. To address this
limitation, this paper proposes a new methodological taxonomy that
hierarchically classifies algorithms into more detailed categories and specific
techniques. The paper includes empirical and experimental evaluations to rank
the different techniques. The combination of the methodological taxonomy,
empirical evaluations, and experimental comparisons allows for a nuanced and
comprehensive understanding of the techniques and algorithms for identifying
crime leaders, assisting researchers in making informed decisions. Moreover,
the paper offers valuable insights into the future prospects of techniques for
identifying crime leaders, emphasizing potential advancements and opportunities
for further research. Here's an overview of our empirical analysis findings and
experimental insights, along with the solution we've devised: (1) PageRank and
Eigenvector centrality are reliable for mapping network connections, (2) Katz
Centrality can effectively identify influential criminals through indirect
links, stressing their significance in criminal networks, (3) current models
fail to account for the specific impacts of criminal influence levels, the
importance of socio-economic context, and the dynamic nature of criminal
networks and hierarchies, and (4) we propose enhancements, such as
incorporating temporal dynamics and sentiment analysis to reflect the fluidity
of criminal activities and relationships, which could improve the detection of
key criminals .

---------------

### 11 Aug 2022 | [Overview of CTC 2021: Chinese Text Correction for Native Speakers](https://arxiv.org/abs/2208.05681) | [⬇️](https://arxiv.org/pdf/2208.05681)
*Honghong Zhao, Baoxin Wang, Dayong Wu, Wanxiang Che, Zhigang Chen,  Shijin Wang* 

  In this paper, we present an overview of the CTC 2021, a Chinese text
correction task for native speakers. We give detailed descriptions of the task
definition and the data for training as well as evaluation. We also summarize
the approaches investigated by the participants of this task. We hope the data
sets collected and annotated for this task can facilitate and expedite future
development in this research area. Therefore, the pseudo training data, gold
standards validation data, and entire leaderboard is publicly available online
at https://destwang.github.io/CTC2021-explorer/.

---------------

### 17 Jun 2019 | [Machine Learning Software Engineering in Practice: An Industrial Case  Study](https://arxiv.org/abs/1906.07154) | [⬇️](https://arxiv.org/pdf/1906.07154)
*Md Saidur Rahman, Emilio Rivera, Foutse Khomh, Yann-Ga\"el  Gu\'eh\'eneuc, and Bernd Lehnert* 

  SAP is the market leader in enterprise software offering an end-to-end suite
of applications and services to enable their customers worldwide to operate
their business. Especially, retail customers of SAP deal with millions of sales
transactions for their day-to-day business. Transactions are created during
retail sales at the point of sale (POS) terminals and then sent to some central
servers for validations and other business operations. A considerable
proportion of the retail transactions may have inconsistencies due to many
technical and human errors. SAP provides an automated process for error
detection but still requires a manual process by dedicated employees using
workbench software for correction. However, manual corrections of these errors
are time-consuming, labor-intensive, and may lead to further errors due to
incorrect modifications. This is not only a performance overhead on the
customers' business workflow but it also incurs high operational costs. Thus,
automated detection and correction of transaction errors are very important
regarding their potential business values and the improvement in the business
workflow. In this paper, we present an industrial case study where we apply
machine learning (ML) to automatically detect transaction errors and propose
corrections. We identify and discuss the challenges that we faced during this
collaborative research and development project, from three distinct
perspectives: Software Engineering, Machine Learning, and industry-academia
collaboration. We report on our experience and insights from the project with
guidelines for the identified challenges. We believe that our findings and
recommendations can help researchers and practitioners embarking into similar
endeavors.

---------------

### 20 May 2023 | [Executive Voiced Laughter and Social Approval: An Explorative Machine  Learning Study](https://arxiv.org/abs/2305.09485) | [⬇️](https://arxiv.org/pdf/2305.09485)
*Niklas Mueller, Steffen Klug, Andreas Koenig, Alexander Kathan, Lukas  Christ, Bjoern Schuller, Shahin Amiriparian* 

  We study voiced laughter in executive communication and its effect on social
approval. Integrating research on laughter, affect-as-information, and
infomediaries' social evaluations of firms, we hypothesize that voiced laughter
in executive communication positively affects social approval, defined as
audience perceptions of affinity towards an organization. We surmise that the
effect of laughter is especially strong for joint laughter, i.e., the number of
instances in a given communication venue for which the focal executive and the
audience laugh simultaneously. Finally, combining the notions of
affect-as-information and negativity bias in human cognition, we hypothesize
that the positive effect of laughter on social approval increases with bad
organizational performance. We find partial support for our ideas when testing
them on panel data comprising 902 German Bundesliga soccer press conferences
and media tenor, applying state-of-the-art machine learning approaches for
laughter detection as well as sentiment analysis. Our findings contribute to
research at the nexus of executive communication, strategic leadership, and
social evaluations, especially by introducing laughter as a highly
consequential potential, but understudied social lubricant at the
executive-infomediary interface. Our research is unique by focusing on
reflexive microprocesses of social evaluations, rather than the
infomediary-routines perspectives in infomediaries' evaluations. We also make
methodological contributions.

---------------

### 22 Feb 2024 | [Efficient and Effective Vocabulary Expansion Towards Multilingual Large  Language Models](https://arxiv.org/abs/2402.14714) | [⬇️](https://arxiv.org/pdf/2402.14714)
*Seungduk Kim, Seungtaek Choi, Myeongho Jeong* 

  This report introduces \texttt{EEVE-Korean-v1.0}, a Korean adaptation of
large language models that exhibit remarkable capabilities across English and
Korean text understanding. Building on recent highly capable but
English-centric LLMs, such as SOLAR-10.7B and Phi-2, where non-English texts
are inefficiently processed with English-centric tokenizers, we present an
efficient and effective vocabulary expansion (EEVE) method, which encompasses
parameter freezing and subword initialization. In contrast to previous efforts
that believe new embeddings require trillions of training tokens, we show that
our method can significantly boost non-English proficiency within just 2
billion tokens. Surpassing most instruction-tuned LLMs on the Open Ko-LLM
Leaderboard, as of January 2024, our model \texttt{EEVE-Korean-10.8B-v1.0}
ranks as the leading Korean pre-trained model in the open-source community,
according to Hugging Face's leaderboard. We open-source our models on
Huggingface to empower the open research community in various languages.

---------------

### 21 Feb 2024 | [LEGOBench: Scientific Leaderboard Generation Benchmark](https://arxiv.org/abs/2401.06233) | [⬇️](https://arxiv.org/pdf/2401.06233)
*Shruti Singh, Shoaib Alam, Husain Malwat and Mayank Singh* 

  The ever-increasing volume of paper submissions makes it difficult to stay
informed about the latest state-of-the-art research. To address this challenge,
we introduce LEGOBench, a benchmark for evaluating systems that generate
scientific leaderboards. LEGOBench is curated from 22 years of preprint
submission data on arXiv and more than 11k machine learning leaderboards on the
PapersWithCode portal. We present four graph-based and two language model-based
leaderboard generation task configurations. We evaluate popular encoder-only
scientific language models as well as decoder-only large language models across
these task configurations. State-of-the-art models showcase significant
performance gaps in automatic leaderboard generation on LEGOBench. The code is
available on GitHub ( https://github.com/lingo-iitgn/LEGOBench ) and the
dataset is hosted on OSF (
https://osf.io/9v2py/?view_only=6f91b0b510df498ba01595f8f278f94c ).

---------------
**Date:** 16 Apr 2014

**Title:** Partially Observed, Multi-objective Markov Games

**Abstract Link:** [https://arxiv.org/abs/1404.4388](https://arxiv.org/abs/1404.4388)

**PDF Link:** [https://arxiv.org/pdf/1404.4388](https://arxiv.org/pdf/1404.4388)

---

**Date:** 10 May 2023

**Title:** ORKG-Leaderboards: A Systematic Workflow for Mining Leaderboards as a  Knowledge Graph

**Abstract Link:** [https://arxiv.org/abs/2305.11068](https://arxiv.org/abs/2305.11068)

**PDF Link:** [https://arxiv.org/pdf/2305.11068](https://arxiv.org/pdf/2305.11068)

---

**Date:** 31 Aug 2021

**Title:** Automated Mining of Leaderboards for Empirical AI Research

**Abstract Link:** [https://arxiv.org/abs/2109.13089](https://arxiv.org/abs/2109.13089)

**PDF Link:** [https://arxiv.org/pdf/2109.13089](https://arxiv.org/pdf/2109.13089)

---

**Date:** 12 Aug 2023

**Title:** Robot formation control in nonlinear manifold using Koopman operator  theory

**Abstract Link:** [https://arxiv.org/abs/2205.04052](https://arxiv.org/abs/2205.04052)

**PDF Link:** [https://arxiv.org/pdf/2205.04052](https://arxiv.org/pdf/2205.04052)

---

**Date:** 15 May 2020

**Title:** Uncovering Gender Bias in Media Coverage of Politicians with Machine  Learning

**Abstract Link:** [https://arxiv.org/abs/2005.07734](https://arxiv.org/abs/2005.07734)

**PDF Link:** [https://arxiv.org/pdf/2005.07734](https://arxiv.org/pdf/2005.07734)

---

**Date:** 20 Sep 2018

**Title:** Architecture of Text Mining Application in Analyzing Public Sentiments  of West Java Governor Election using Naive Bayes Classification

**Abstract Link:** [https://arxiv.org/abs/1810.07767](https://arxiv.org/abs/1810.07767)

**PDF Link:** [https://arxiv.org/pdf/1810.07767](https://arxiv.org/pdf/1810.07767)

---

**Date:** 20 Mar 2023

**Title:** Self-Improving-Leaderboard(SIL): A Call for Real-World Centric Natural  Language Processing Leaderboards

**Abstract Link:** [https://arxiv.org/abs/2303.10888](https://arxiv.org/abs/2303.10888)

**PDF Link:** [https://arxiv.org/pdf/2303.10888](https://arxiv.org/pdf/2303.10888)

---

**Date:** 29 May 2017

**Title:** Human-Robot Collaboration: From Psychology to Social Robotics

**Abstract Link:** [https://arxiv.org/abs/1705.10146](https://arxiv.org/abs/1705.10146)

**PDF Link:** [https://arxiv.org/pdf/1705.10146](https://arxiv.org/pdf/1705.10146)

---

**Date:** 12 Jun 2023

**Title:** On building machine learning pipelines for Android malware detection: a  procedural survey of practices, challenges and opportunities

**Abstract Link:** [https://arxiv.org/abs/2306.07118](https://arxiv.org/abs/2306.07118)

**PDF Link:** [https://arxiv.org/pdf/2306.07118](https://arxiv.org/pdf/2306.07118)

---

**Date:** 05 Nov 2019

**Title:** Response to NITRD, NCO, NSF Request for Information on "Update to the  2016 National Artificial Intelligence Research and Development Strategic  Plan"

**Abstract Link:** [https://arxiv.org/abs/1911.05796](https://arxiv.org/abs/1911.05796)

**PDF Link:** [https://arxiv.org/pdf/1911.05796](https://arxiv.org/pdf/1911.05796)

---

**Date:** 21 Apr 2020

**Title:** What Question Answering can Learn from Trivia Nerds

**Abstract Link:** [https://arxiv.org/abs/1910.14464](https://arxiv.org/abs/1910.14464)

**PDF Link:** [https://arxiv.org/pdf/1910.14464](https://arxiv.org/pdf/1910.14464)

---

**Date:** 21 Jun 2019

**Title:** Identification of Tasks, Datasets, Evaluation Metrics, and Numeric  Scores for Scientific Leaderboards Construction

**Abstract Link:** [https://arxiv.org/abs/1906.09317](https://arxiv.org/abs/1906.09317)

**PDF Link:** [https://arxiv.org/pdf/1906.09317](https://arxiv.org/pdf/1906.09317)

---

**Date:** 12 Apr 2022

**Title:** Sentiment Analysis of Political Tweets for Israel using Machine Learning

**Abstract Link:** [https://arxiv.org/abs/2204.06515](https://arxiv.org/abs/2204.06515)

**PDF Link:** [https://arxiv.org/pdf/2204.06515](https://arxiv.org/pdf/2204.06515)

---

**Date:** 10 Dec 2021

**Title:** Practical and Private (Deep) Learning without Sampling or Shuffling

**Abstract Link:** [https://arxiv.org/abs/2103.00039](https://arxiv.org/abs/2103.00039)

**PDF Link:** [https://arxiv.org/pdf/2103.00039](https://arxiv.org/pdf/2103.00039)

---

**Date:** 26 Jan 2024

**Title:** Techniques to Detect Crime Leaders within a Criminal Network: A Survey,  Experimental, and Comparative Evaluations

**Abstract Link:** [https://arxiv.org/abs/2402.03355](https://arxiv.org/abs/2402.03355)

**PDF Link:** [https://arxiv.org/pdf/2402.03355](https://arxiv.org/pdf/2402.03355)

---

**Date:** 11 Aug 2022

**Title:** Overview of CTC 2021: Chinese Text Correction for Native Speakers

**Abstract Link:** [https://arxiv.org/abs/2208.05681](https://arxiv.org/abs/2208.05681)

**PDF Link:** [https://arxiv.org/pdf/2208.05681](https://arxiv.org/pdf/2208.05681)

---

**Date:** 17 Jun 2019

**Title:** Machine Learning Software Engineering in Practice: An Industrial Case  Study

**Abstract Link:** [https://arxiv.org/abs/1906.07154](https://arxiv.org/abs/1906.07154)

**PDF Link:** [https://arxiv.org/pdf/1906.07154](https://arxiv.org/pdf/1906.07154)

---

**Date:** 20 May 2023

**Title:** Executive Voiced Laughter and Social Approval: An Explorative Machine  Learning Study

**Abstract Link:** [https://arxiv.org/abs/2305.09485](https://arxiv.org/abs/2305.09485)

**PDF Link:** [https://arxiv.org/pdf/2305.09485](https://arxiv.org/pdf/2305.09485)

---

**Date:** 22 Feb 2024

**Title:** Efficient and Effective Vocabulary Expansion Towards Multilingual Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.14714](https://arxiv.org/abs/2402.14714)

**PDF Link:** [https://arxiv.org/pdf/2402.14714](https://arxiv.org/pdf/2402.14714)

---

**Date:** 21 Feb 2024

**Title:** LEGOBench: Scientific Leaderboard Generation Benchmark

**Abstract Link:** [https://arxiv.org/abs/2401.06233](https://arxiv.org/abs/2401.06233)

**PDF Link:** [https://arxiv.org/pdf/2401.06233](https://arxiv.org/pdf/2401.06233)

---

