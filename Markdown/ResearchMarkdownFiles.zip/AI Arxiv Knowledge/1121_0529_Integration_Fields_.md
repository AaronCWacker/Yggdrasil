Integration Fields 🎡

### 🔎 Integration Fields 🎡


=====================

Integration Fields are a way to add custom fields to your integration.

These fields can be used to store any additional information that you need to pass along with your integration.

For example, you might want to store the name of the person who created the integration, or the date that the integration was created.

To add an Integration Field, go to the Integration Fields tab in your integration's settings.

From there, you can add a new field by clicking the "Add Field" button.

You'll need to give your field a name and a type.

The name is what you'll use to refer to the field in your code, and the type is the data type of the field (e.g. string, integer, date, etc.).

Once you've added a field, you can use it in your integration by referencing it by name.

For example, if you have a field called "created\_by", you can use it like this:

```
integration.created_by = "John Doe"
```

Integration Fields are a powerful way to add custom functionality to your integration.

They can be used to store any additional information that you need to pass along with your integration, and they can be used in your code to customize the behavior of your integration.

So if you need to store some extra data with your integration, be sure to check out Integration Fields!</s>
# 🩺🔍 Search Results
### 11 Jun 2001 | [Information Integration and Computational Logic](https://arxiv.org/abs/cs/0106025) | [⬇️](https://arxiv.org/pdf/cs/0106025)
*Yannis Dimopoulos and Antonis Kakas* 

  Information Integration is a young and exciting field with enormous research
and commercial significance in the new world of the Information Society. It
stands at the crossroad of Databases and Artificial Intelligence requiring
novel techniques that bring together different methods from these fields.
Information from disparate heterogeneous sources often with no a-priori common
schema needs to be synthesized in a flexible, transparent and intelligent way
in order to respond to the demands of a query thus enabling a more informed
decision by the user or application program. The field although relatively
young has already found many practical applications particularly for
integrating information over the World Wide Web. This paper gives a brief
introduction of the field highlighting some of the main current and future
research issues and application areas. It attempts to evaluate the current and
potential role of Computational Logic in this and suggests some of the problems
where logic-based techniques could be used.

---------------

### 17 Sep 2020 | [A Generalization of Spatial Monte Carlo Integration](https://arxiv.org/abs/2009.02165) | [⬇️](https://arxiv.org/pdf/2009.02165)
*Muneki Yasuda and Kei Uchizawa* 

  Spatial Monte Carlo integration (SMCI) is an extension of standard Monte
Carlo integration and can approximate expectations on Markov random fields with
high accuracy. SMCI was applied to pairwise Boltzmann machine (PBM) learning,
with superior results to those from some existing methods. The approximation
level of SMCI can be changed, and it was proved that a higher-order
approximation of SMCI is statistically more accurate than a lower-order
approximation. However, SMCI as proposed in the previous studies suffers from a
limitation that prevents the application of a higher-order method to dense
systems.
  This study makes two different contributions as follows. A generalization of
SMCI (called generalized SMCI (GSMCI)) is proposed, which allows relaxation of
the above-mentioned limitation; moreover, a statistical accuracy bound of GSMCI
is proved. This is the first contribution of this study. A new PBM learning
method based on SMCI is proposed, which is obtained by combining SMCI and the
persistent contrastive divergence. The proposed learning method greatly
improves the accuracy of learning. This is the second contribution of this
study.

---------------

### 18 Sep 2017 | [Variational Methods for Normal Integration](https://arxiv.org/abs/1709.05965) | [⬇️](https://arxiv.org/pdf/1709.05965)
*Yvain Qu\'eau, Jean-Denis Durou and Jean-Fran\c{c}ois Aujol* 

  The need for an efficient method of integration of a dense normal field is
inspired by several computer vision tasks, such as shape-from-shading,
photometric stereo, deflectometry, etc. Inspired by edge-preserving methods
from image processing, we study in this paper several variational approaches
for normal integration, with a focus on non-rectangular domains, free boundary
and depth discontinuities. We first introduce a new discretization for
quadratic integration, which is designed to ensure both fast recovery and the
ability to handle non-rectangular domains with a free boundary. Yet, with this
solver, discontinuous surfaces can be handled only if the scene is first
segmented into pieces without discontinuity. Hence, we then discuss several
discontinuity-preserving strategies. Those inspired, respectively, by the
Mumford-Shah segmentation method and by anisotropic diffusion, are shown to be
the most effective for recovering discontinuities.

---------------

### 15 Dec 2023 | [ColNeRF: Collaboration for Generalizable Sparse Input Neural Radiance  Field](https://arxiv.org/abs/2312.09095) | [⬇️](https://arxiv.org/pdf/2312.09095)
*Zhangkai Ni, Peiqi Yang, Wenhan Yang, Hanli Wang, Lin Ma, Sam Kwong* 

  Neural Radiance Fields (NeRF) have demonstrated impressive potential in
synthesizing novel views from dense input, however, their effectiveness is
challenged when dealing with sparse input. Existing approaches that incorporate
additional depth or semantic supervision can alleviate this issue to an extent.
However, the process of supervision collection is not only costly but also
potentially inaccurate, leading to poor performance and generalization ability
in diverse scenarios. In our work, we introduce a novel model: the
Collaborative Neural Radiance Fields (ColNeRF) designed to work with sparse
input. The collaboration in ColNeRF includes both the cooperation between
sparse input images and the cooperation between the output of the neural
radiation field. Through this, we construct a novel collaborative module that
aligns information from various views and meanwhile imposes self-supervised
constraints to ensure multi-view consistency in both geometry and appearance. A
Collaborative Cross-View Volume Integration module (CCVI) is proposed to
capture complex occlusions and implicitly infer the spatial location of
objects. Moreover, we introduce self-supervision of target rays projected in
multiple directions to ensure geometric and color consistency in adjacent
regions. Benefiting from the collaboration at the input and output ends,
ColNeRF is capable of capturing richer and more generalized scene
representation, thereby facilitating higher-quality results of the novel view
synthesis. Extensive experiments demonstrate that ColNeRF outperforms
state-of-the-art sparse input generalizable NeRF methods. Furthermore, our
approach exhibits superiority in fine-tuning towards adapting to new scenes,
achieving competitive performance compared to per-scene optimized NeRF-based
methods while significantly reducing computational costs. Our code is available
at: https://github.com/eezkni/ColNeRF.

---------------

### 09 Mar 2021 | [Symbolic integration by integrating learning models with different  strengths and weaknesses](https://arxiv.org/abs/2103.05497) | [⬇️](https://arxiv.org/pdf/2103.05497)
*Hazumi Kubota, Yuta Tokuoka, Takahiro G. Yamada and Akira Funahashi* 

  Integration is indispensable, not only in mathematics, but also in a wide
range of other fields. A deep learning method has recently been developed and
shown to be capable of integrating mathematical functions that could not
previously be integrated on a computer. However, that method treats integration
as equivalent to natural language translation and does not reflect mathematical
information. In this study, we adjusted the learning model to take mathematical
information into account and developed a wide range of learning models that
learn the order of numerical operations more robustly. In this way, we achieved
a 98.80% correct answer rate with symbolic integration, a higher rate than that
of any existing method. We judged the correctness of the integration based on
whether the derivative of the primitive function was consistent with the
integrand. By building an integrated model based on this strategy, we achieved
a 99.79% rate of correct answers with symbolic integration.

---------------

### 18 Oct 2023 | [Uncertainty in Automated Ontology Matching: Lessons Learned from an  Empirical Experimentation](https://arxiv.org/abs/2310.11723) | [⬇️](https://arxiv.org/pdf/2310.11723)
*In\`es Osman, Salvatore F. Pileggi, Sadok Ben Yahia* 

  Data integration is considered a classic research field and a pressing need
within the information science community. Ontologies play a critical role in
such a process by providing well-consolidated support to link and semantically
integrate datasets via interoperability. This paper approaches data integration
from an application perspective, looking at techniques based on ontology
matching. An ontology-based process may only be considered adequate by assuming
manual matching of different sources of information. However, since the
approach becomes unrealistic once the system scales up, automation of the
matching process becomes a compelling need. Therefore, we have conducted
experiments on actual data with the support of existing tools for automatic
ontology matching from the scientific community. Even considering a relatively
simple case study (i.e., the spatio-temporal alignment of global indicators),
outcomes clearly show significant uncertainty resulting from errors and
inaccuracies along the automated matching process. More concretely, this paper
aims to test on real-world data a bottom-up knowledge-building approach,
discuss the lessons learned from the experimental results of the case study,
and draw conclusions about uncertainty and uncertainty management in an
automated ontology matching process. While the most common evaluation metrics
clearly demonstrate the unreliability of fully automated matching solutions,
properly designed semi-supervised approaches seem to be mature for a more
generalized application.

---------------

### 21 Feb 2024 | [AutoML in the Age of Large Language Models: Current Challenges, Future  Opportunities and Risks](https://arxiv.org/abs/2306.08107) | [⬇️](https://arxiv.org/pdf/2306.08107)
*Alexander Tornede, Difan Deng, Theresa Eimer, Joseph Giovanelli,  Aditya Mohan, Tim Ruhkopf, Sarah Segel, Daphne Theodorakopoulos, Tanja  Tornede, Henning Wachsmuth, Marius Lindauer* 

  The fields of both Natural Language Processing (NLP) and Automated Machine
Learning (AutoML) have achieved remarkable results over the past years. In NLP,
especially Large Language Models (LLMs) have experienced a rapid series of
breakthroughs very recently. We envision that the two fields can radically push
the boundaries of each other through tight integration. To showcase this
vision, we explore the potential of a symbiotic relationship between AutoML and
LLMs, shedding light on how they can benefit each other. In particular, we
investigate both the opportunities to enhance AutoML approaches with LLMs from
different perspectives and the challenges of leveraging AutoML to further
improve LLMs. To this end, we survey existing work, and we critically assess
risks. We strongly believe that the integration of the two fields has the
potential to disrupt both fields, NLP and AutoML. By highlighting conceivable
synergies, but also risks, we aim to foster further exploration at the
intersection of AutoML and LLMs.

---------------

### 29 Mar 2018 | [Structured Attention Guided Convolutional Neural Fields for Monocular  Depth Estimation](https://arxiv.org/abs/1803.11029) | [⬇️](https://arxiv.org/pdf/1803.11029)
*Dan Xu, Wei Wang, Hao Tang, Hong Liu, Nicu Sebe, Elisa Ricci* 

  Recent works have shown the benefit of integrating Conditional Random Fields
(CRFs) models into deep architectures for improving pixel-level prediction
tasks. Following this line of research, in this paper we introduce a novel
approach for monocular depth estimation. Similarly to previous works, our
method employs a continuous CRF to fuse multi-scale information derived from
different layers of a front-end Convolutional Neural Network (CNN). Differently
from past works, our approach benefits from a structured attention model which
automatically regulates the amount of information transferred between
corresponding features at different scales. Importantly, the proposed attention
model is seamlessly integrated into the CRF, allowing end-to-end training of
the entire architecture. Our extensive experimental evaluation demonstrates the
effectiveness of the proposed method which is competitive with previous methods
on the KITTI benchmark and outperforms the state of the art on the NYU Depth V2
dataset.

---------------

### 18 Sep 2017 | [Embodied Artificial Intelligence through Distributed Adaptive Control:  An Integrated Framework](https://arxiv.org/abs/1704.01407) | [⬇️](https://arxiv.org/pdf/1704.01407)
*Cl\'ement Moulin-Frier, Jordi-Ysard Puigb\`o, Xerxes D. Arsiwalla,  Mart\`i Sanchez-Fibla, Paul F. M. J. Verschure* 

  In this paper, we argue that the future of Artificial Intelligence research
resides in two keywords: integration and embodiment. We support this claim by
analyzing the recent advances of the field. Regarding integration, we note that
the most impactful recent contributions have been made possible through the
integration of recent Machine Learning methods (based in particular on Deep
Learning and Recurrent Neural Networks) with more traditional ones (e.g.
Monte-Carlo tree search, goal babbling exploration or addressable memory
systems). Regarding embodiment, we note that the traditional benchmark tasks
(e.g. visual classification or board games) are becoming obsolete as
state-of-the-art learning algorithms approach or even surpass human performance
in most of them, having recently encouraged the development of first-person 3D
game platforms embedding realistic physics. Building upon this analysis, we
first propose an embodied cognitive architecture integrating heterogenous
sub-fields of Artificial Intelligence into a unified framework. We demonstrate
the utility of our approach by showing how major contributions of the field can
be expressed within the proposed framework. We then claim that benchmarking
environments need to reproduce ecologically-valid conditions for bootstrapping
the acquisition of increasingly complex cognitive skills through the concept of
a cognitive arms race between embodied agents.

---------------

### 13 Jul 2023 | [A Comprehensive Analysis of Blockchain Applications for Securing  Computer Vision Systems](https://arxiv.org/abs/2307.06659) | [⬇️](https://arxiv.org/pdf/2307.06659)
*Ramalingam M, Chemmalar Selvi, Nancy Victor, Rajeswari Chengoden,  Sweta Bhattacharya, Praveen Kumar Reddy Maddikunta, Duehee Lee, Md. Jalil  Piran, Neelu Khare, Gokul Yendri, Thippa Reddy Gadekallu* 

  Blockchain (BC) and Computer Vision (CV) are the two emerging fields with the
potential to transform various sectors.The ability of BC can help in offering
decentralized and secure data storage, while CV allows machines to learn and
understand visual data. This integration of the two technologies holds massive
promise for developing innovative applications that can provide solutions to
the challenges in various sectors such as supply chain management, healthcare,
smart cities, and defense. This review explores a comprehensive analysis of the
integration of BC and CV by examining their combination and potential
applications. It also provides a detailed analysis of the fundamental concepts
of both technologies, highlighting their strengths and limitations. This paper
also explores current research efforts that make use of the benefits offered by
this combination. The effort includes how BC can be used as an added layer of
security in CV systems and also ensure data integrity, enabling decentralized
image and video analytics using BC. The challenges and open issues associated
with this integration are also identified, and appropriate potential future
directions are also proposed.

---------------

### 07 Apr 2017 | [Multi-Scale Continuous CRFs as Sequential Deep Networks for Monocular  Depth Estimation](https://arxiv.org/abs/1704.02157) | [⬇️](https://arxiv.org/pdf/1704.02157)
*Dan Xu, Elisa Ricci, Wanli Ouyang, Xiaogang Wang, Nicu Sebe* 

  This paper addresses the problem of depth estimation from a single still
image. Inspired by recent works on multi- scale convolutional neural networks
(CNN), we propose a deep model which fuses complementary information derived
from multiple CNN side outputs. Different from previous methods, the
integration is obtained by means of continuous Conditional Random Fields
(CRFs). In particular, we propose two different variations, one based on a
cascade of multiple CRFs, the other on a unified graphical model. By designing
a novel CNN implementation of mean-field updates for continuous CRFs, we show
that both proposed models can be regarded as sequential deep networks and that
training can be performed end-to-end. Through extensive experimental evaluation
we demonstrate the effective- ness of the proposed approach and establish new
state of the art results on publicly available datasets.

---------------

### 25 Mar 2016 | [A Novel Biologically Mechanism-Based Visual Cognition Model--Automatic  Extraction of Semantics, Formation of Integrated Concepts and Re-selection  Features for Ambiguity](https://arxiv.org/abs/1603.07886) | [⬇️](https://arxiv.org/pdf/1603.07886)
*Peijie Yin, Hong Qiao, Wei Wu, Lu Qi, YinLin Li, Shanlin Zhong, Bo  Zhang* 

  Integration between biology and information science benefits both fields.
Many related models have been proposed, such as computational visual cognition
models, computational motor control models, integrations of both and so on. In
general, the robustness and precision of recognition is one of the key problems
for object recognition models.
  In this paper, inspired by features of human recognition process and their
biological mechanisms, a new integrated and dynamic framework is proposed to
mimic the semantic extraction, concept formation and feature re-selection in
human visual processing. The main contributions of the proposed model are as
follows:
  (1) Semantic feature extraction: Local semantic features are learnt from
episodic features that are extracted from raw images through a deep neural
network;
  (2) Integrated concept formation: Concepts are formed with local semantic
information and structural information learnt through network.
  (3) Feature re-selection: When ambiguity is detected during recognition
process, distinctive features according to the difference between ambiguous
candidates are re-selected for recognition.
  Experimental results on hand-written digits and facial shape dataset show
that, compared with other methods, the new proposed model exhibits higher
robustness and precision for visual recognition, especially in the condition
when input samples are smantic ambiguous. Meanwhile, the introduced biological
mechanisms further strengthen the interaction between neuroscience and
information science.

---------------

### 18 Sep 2017 | [Normal Integration: A Survey](https://arxiv.org/abs/1709.05940) | [⬇️](https://arxiv.org/pdf/1709.05940)
*Yvain Qu\'eau, Jean-Denis Durou and Jean-Fran\c{c}ois Aujol* 

  The need for efficient normal integration methods is driven by several
computer vision tasks such as shape-from-shading, photometric stereo,
deflectometry, etc. In the first part of this survey, we select the most
important properties that one may expect from a normal integration method,
based on a thorough study of two pioneering works by Horn and Brooks [28] and
by Frankot and Chellappa [19]. Apart from accuracy, an integration method
should at least be fast and robust to a noisy normal field. In addition, it
should be able to handle several types of boundary condition, including the
case of a free boundary, and a reconstruction domain of any shape i.e., which
is not necessarily rectangular. It is also much appreciated that a minimum
number of parameters have to be tuned, or even no parameter at all. Finally, it
should preserve the depth discontinuities. In the second part of this survey,
we review most of the existing methods in view of this analysis, and conclude
that none of them satisfies all of the required properties. This work is
complemented by a companion paper entitled Variational Methods for Normal
Integration, in which we focus on the problem of normal integration in the
presence of depth discontinuities, a problem which occurs as soon as there are
occlusions.

---------------

### 04 Oct 2023 | [Efficient Graph Field Integrators Meet Point Clouds](https://arxiv.org/abs/2302.00942) | [⬇️](https://arxiv.org/pdf/2302.00942)
*Krzysztof Choromanski, Arijit Sehanobish, Han Lin, Yunfan Zhao, Eli  Berger, Tetiana Parshakova, Alvin Pan, David Watkins, Tianyi Zhang, Valerii  Likhosherstov, Somnath Basu Roy Chowdhury, Avinava Dubey, Deepali Jain, Tamas  Sarlos, Snigdha Chaturvedi, Adrian Weller* 

  We present two new classes of algorithms for efficient field integration on
graphs encoding point clouds. The first class, SeparatorFactorization(SF),
leverages the bounded genus of point cloud mesh graphs, while the second class,
RFDiffusion(RFD), uses popular epsilon-nearest-neighbor graph representations
for point clouds. Both can be viewed as providing the functionality of Fast
Multipole Methods (FMMs), which have had a tremendous impact on efficient
integration, but for non-Euclidean spaces. We focus on geometries induced by
distributions of walk lengths between points (e.g., shortest-path distance). We
provide an extensive theoretical analysis of our algorithms, obtaining new
results in structural graph theory as a byproduct. We also perform exhaustive
empirical evaluation, including on-surface interpolation for rigid and
deformable objects (particularly for mesh-dynamics modeling), Wasserstein
distance computations for point clouds, and the Gromov-Wasserstein variant.

---------------

### 24 Mar 2023 | [Grid-guided Neural Radiance Fields for Large Urban Scenes](https://arxiv.org/abs/2303.14001) | [⬇️](https://arxiv.org/pdf/2303.14001)
*Linning Xu, Yuanbo Xiangli, Sida Peng, Xingang Pan, Nanxuan Zhao,  Christian Theobalt, Bo Dai, Dahua Lin* 

  Purely MLP-based neural radiance fields (NeRF-based methods) often suffer
from underfitting with blurred renderings on large-scale scenes due to limited
model capacity. Recent approaches propose to geographically divide the scene
and adopt multiple sub-NeRFs to model each region individually, leading to
linear scale-up in training costs and the number of sub-NeRFs as the scene
expands. An alternative solution is to use a feature grid representation, which
is computationally efficient and can naturally scale to a large scene with
increased grid resolutions. However, the feature grid tends to be less
constrained and often reaches suboptimal solutions, producing noisy artifacts
in renderings, especially in regions with complex geometry and texture. In this
work, we present a new framework that realizes high-fidelity rendering on large
urban scenes while being computationally efficient. We propose to use a compact
multiresolution ground feature plane representation to coarsely capture the
scene, and complement it with positional encoding inputs through another NeRF
branch for rendering in a joint learning fashion. We show that such an
integration can utilize the advantages of two alternative solutions: a
light-weighted NeRF is sufficient, under the guidance of the feature grid
representation, to render photorealistic novel views with fine details; and the
jointly optimized ground feature planes, can meanwhile gain further
refinements, forming a more accurate and compact feature space and output much
more natural rendering results.

---------------

### 02 Jan 2024 | [From Statistical Relational to Neurosymbolic Artificial Intelligence: a  Survey](https://arxiv.org/abs/2108.11451) | [⬇️](https://arxiv.org/pdf/2108.11451)
*Giuseppe Marra and Sebastijan Duman\v{c}i\'c and Robin Manhaeve and  Luc De Raedt* 

  This survey explores the integration of learning and reasoning in two
different fields of artificial intelligence: neurosymbolic and statistical
relational artificial intelligence. Neurosymbolic artificial intelligence
(NeSy) studies the integration of symbolic reasoning and neural networks, while
statistical relational artificial intelligence (StarAI) focuses on integrating
logic with probabilistic graphical models. This survey identifies seven shared
dimensions between these two subfields of AI. These dimensions can be used to
characterize different NeSy and StarAI systems. They are concerned with (1) the
approach to logical inference, whether model or proof-based; (2) the syntax of
the used logical theories; (3) the logical semantics of the systems and their
extensions to facilitate learning; (4) the scope of learning, encompassing
either parameter or structure learning; (5) the presence of symbolic and
subsymbolic representations; (6) the degree to which systems capture the
original logic, probabilistic, and neural paradigms; and (7) the classes of
learning tasks the systems are applied to. By positioning various NeSy and
StarAI systems along these dimensions and pointing out similarities and
differences between them, this survey contributes fundamental concepts for
understanding the integration of learning and reasoning.

---------------

### 26 Apr 2022 | [Joint Progressive and Coarse-to-fine Registration of Brain MRI via  Deformation Field Integration and Non-Rigid Feature Fusion](https://arxiv.org/abs/2109.12384) | [⬇️](https://arxiv.org/pdf/2109.12384)
*Jinxin Lv, Zhiwei Wang, Hongkuan Shi, Haobo Zhang, Sheng Wang, Yilang  Wang, and Qiang Li* 

  Registration of brain MRI images requires to solve a deformation field, which
is extremely difficult in aligning intricate brain tissues, e.g., subcortical
nuclei, etc. Existing efforts resort to decomposing the target deformation
field into intermediate sub-fields with either tiny motions, i.e., progressive
registration stage by stage, or lower resolutions, i.e., coarse-to-fine
estimation of the full-size deformation field. In this paper, we argue that
those efforts are not mutually exclusive, and propose a unified framework for
robust brain MRI registration in both progressive and coarse-to-fine manners
simultaneously. Specifically, building on a dual-encoder U-Net, the
fixed-moving MRI pair is encoded and decoded into multi-scale deformation
sub-fields from coarse to fine. Each decoding block contains two proposed novel
modules: i) in Deformation Field Integration (DFI), a single integrated
sub-field is calculated, warping by which is equivalent to warping
progressively by sub-fields from all previous decoding blocks, and ii) in
Non-rigid Feature Fusion (NFF), features of the fixed-moving pair are aligned
by DFI-integrated sub-field, and then fused to predict a finer sub-field.
Leveraging both DFI and NFF, the target deformation field is factorized into
multi-scale sub-fields, where the coarser fields alleviate the estimate of a
finer one and the finer field learns to make up those misalignments insolvable
by previous coarser ones. The extensive and comprehensive experimental results
on both private and public datasets demonstrate a superior registration
performance of brain MRI images over progressive registration only and
coarse-to-fine estimation only, with an increase by at most 8% in the average
Dice.

---------------

### 22 Sep 2023 | [DMF-TONN: Direct Mesh-free Topology Optimization using Neural Networks](https://arxiv.org/abs/2305.04107) | [⬇️](https://arxiv.org/pdf/2305.04107)
*Aditya Joglekar, Hongrui Chen, Levent Burak Kara* 

  We propose a direct mesh-free method for performing topology optimization by
integrating a density field approximation neural network with a displacement
field approximation neural network. We show that this direct integration
approach can give comparable results to conventional topology optimization
techniques, with an added advantage of enabling seamless integration with
post-processing software, and a potential of topology optimization with
objectives where meshing and Finite Element Analysis (FEA) may be expensive or
not suitable. Our approach (DMF-TONN) takes in as inputs the boundary
conditions and domain coordinates and finds the optimum density field for
minimizing the loss function of compliance and volume fraction constraint
violation. The mesh-free nature is enabled by a physics-informed displacement
field approximation neural network to solve the linear elasticity partial
differential equation and replace the FEA conventionally used for calculating
the compliance. We show that using a suitable Fourier Features neural network
architecture and hyperparameters, the density field approximation neural
network can learn the weights to represent the optimal density field for the
given domain and boundary conditions, by directly backpropagating the loss
gradient through the displacement field approximation neural network, and
unlike prior work there is no requirement of a sensitivity filter, optimality
criterion method, or a separate training of density network in each topology
optimization iteration.

---------------

### 03 Mar 2023 | [An Integrated Real-time UAV Trajectory Optimization with Potential Field  Approach for Dynamic Collision Avoidance](https://arxiv.org/abs/2303.02043) | [⬇️](https://arxiv.org/pdf/2303.02043)
*D. M. K. K. Venkateswara Rao, Hamed Habibi, Jose Luis Sanchez-Lopez,  and Holger Voos* 

  This paper presents an integrated approach that combines trajectory
optimization and Artificial Potential Field (APF) method for real-time optimal
Unmanned Aerial Vehicle (UAV) trajectory planning and dynamic collision
avoidance. A minimum-time trajectory optimization problem is formulated with
initial and final positions as boundary conditions and collision avoidance as
constraints. It is transcribed into a nonlinear programming problem using
Chebyshev pseudospectral method. The state and control histories are
approximated by using Lagrange polynomials and the collocation points are used
to satisfy constraints. A novel sigmoid-type collision avoidance constraint is
proposed to overcome the drawbacks of Lagrange polynomial approximation in
pseudospectral methods that only guarantees inequality constraint satisfaction
only at nodal points. Automatic differentiation of cost function and
constraints is used to quickly determine their gradient and Jacobian,
respectively. An APF method is used to update the optimal control inputs for
guaranteeing collision avoidance. The trajectory optimization and APF method
are implemented in a closed-loop fashion continuously, but in parallel at
moderate and high frequencies, respectively. The initial guess for the
optimization is provided based on the previous solution. The proposed approach
is tested and validated through indoor experiments.

---------------

### 22 May 2020 | [An Integrated Framework of Decision Making and Motion Planning for  Autonomous Vehicles Considering Social Behaviors](https://arxiv.org/abs/2005.11059) | [⬇️](https://arxiv.org/pdf/2005.11059)
*Peng Hang, Chen Lv, Chao Huang, Jiacheng Cai, Zhongxu Hu, Yang Xing* 

  This paper presents a novel integrated approach to deal with the decision
making and motion planning for lane-change maneuvers of autonomous vehicle (AV)
considering social behaviors of surrounding traffic occupants. Reflected by
driving styles and intentions of surrounding vehicles, the social behaviors are
taken into consideration during the modelling process. Then, the Stackelberg
Game theory is applied to solve the decision-making, which is formulated as a
non-cooperative game problem. Besides, potential field is adopted in the motion
planning model, which uses different potential functions to describe
surrounding vehicles with different behaviors and road constrains. Then, Model
Predictive Control (MPC) is utilized to predict the state and trajectory of the
autonomous vehicle. Finally, the decision-making and motion planning is then
integrated into a constrained multi-objective optimization problem. Three
testing scenarios considering different social behaviors of surrounding
vehicles are carried out to validate the performance of the proposed approach.
Testing results show that the integrated approach is able to address different
social interactions with other traffic participants, and make proper and safe
decisions and planning for autonomous vehicles, demonstrating its feasibility
and effectiveness.

---------------
