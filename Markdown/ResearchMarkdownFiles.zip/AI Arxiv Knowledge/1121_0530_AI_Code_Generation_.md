AI Code Generation 🤹

### 🔎 AI Code Generation 🤹

‍♂️

# AI Code Generation 🤹‍♂️

AI Code Generation is a powerful tool that can help developers save time and effort by automatically generating code based on natural language descriptions or high-level abstractions. With the help of AI, developers can focus on the logic and functionality of their code, rather than getting bogged down in the details of syntax and formatting.

There are several AI Code Generation tools available, each with its own strengths and weaknesses. Some popular options include Kite, DeepCode, and Tabnine. These tools use machine learning algorithms to analyze code patterns and suggest optimal solutions, making them ideal for tasks such as code completion, refactoring, and debugging.

One of the key benefits of AI Code Generation is its ability to learn from large codebases and suggest best practices and optimized solutions. This can help developers write more efficient, secure, and maintainable code, while also reducing the risk of errors and bugs.

However, it's important to note that AI Code Generation is not a replacement for human developers. While these tools can be incredibly useful for automating repetitive tasks and suggesting optimal solutions, they still require human oversight and validation to ensure that the generated code meets the desired specifications and requirements.

Overall, AI Code Generation is a powerful tool that can help developers save time and effort, while also improving the quality and efficiency of their code. By leveraging the power of AI, developers can focus on the creative and strategic aspects of their work, while leaving the tedious and repetitive tasks to the machines.</s>
# 🩺🔍 Search Results
### 28 Jul 2020 | [Formal Fields: A Framework to Automate Code Generation Across Domains](https://arxiv.org/abs/2007.14075) | [⬇️](https://arxiv.org/pdf/2007.14075)
*Jacques Basald\'ua* 

  Code generation, defined as automatically writing a piece of code to solve a
given problem for which an evaluation function exists, is a classic hard AI
problem. Its general form, writing code using a general language used by human
programmers from scratch is thought to be impractical. Adding constraints to
the code grammar, implementing domain specific concepts as primitives and
providing examples for the algorithm to learn, makes it practical. Formal
fields is a framework to do code generation across domains using the same
algorithms and language structure. Its ultimate goal is not just solving
different narrow problems, but providing necessary abstractions to integrate
many working solutions as a single lifelong reasoning system. It provides a
common grammar to define: a domain language, a problem and its evaluation. The
framework learns from examples of code snippets about the structure of the
domain language and searches completely new code snippets to solve unseen
problems in the same field. Formal fields abstract the search algorithm away
from the problem. The search algorithm is taken from existing reinforcement
learning algorithms. In our implementation it is an apropos Monte-Carlo Tree
Search (MCTS). We have implemented formal fields as a fully documented open
source project applied to the Abstract Reasoning Challenge (ARC). The
implementation found code snippets solving twenty two previously unsolved ARC
problems.

---------------

### 30 Jan 2024 | [Are ChatGPT and Other Similar Systems the Modern Lernaean Hydras of AI?](https://arxiv.org/abs/2306.09267) | [⬇️](https://arxiv.org/pdf/2306.09267)
*Dimitrios Ioannidis, Jeremy Kepner, Andrew Bowne, Harriet S. Bryant* 

  The rise of Generative Artificial Intelligence systems ("AI systems") has
created unprecedented social engagement. AI code generation systems provide
responses (output) to questions or requests by accessing the vast library of
open-source code created by developers over the past few decades. However, they
do so by allegedly stealing the open-source code stored in virtual libraries,
known as repositories. This Article focuses on how this happens and whether
there is a solution that protects innovation and avoids years of litigation. We
also touch upon the array of issues raised by the relationship between AI and
copyright. Looking ahead, we propose the following: (a) immediate changes to
the licenses for open-source code created by developers that will limit access
and/or use of any open-source code to humans only; (b) we suggest revisions to
the Massachusetts Institute of Technology ("MIT") license so that AI systems
are required to procure appropriate licenses from open-source code developers,
which we believe will harmonize standards and build social consensus for the
benefit of all of humanity, rather than promote profit-driven centers of
innovation; (c) we call for urgent legislative action to protect the future of
AI systems while also promoting innovation; and (d) we propose a shift in the
burden of proof to AI systems in obfuscation cases.

---------------

### 25 Apr 2023 | [AI-assisted coding: Experiments with GPT-4](https://arxiv.org/abs/2304.13187) | [⬇️](https://arxiv.org/pdf/2304.13187)
*Russell A Poldrack, Thomas Lu, and Ga\v{s}per Begu\v{s}* 

  Artificial intelligence (AI) tools based on large language models have
acheived human-level performance on some computer programming tasks. We report
several experiments using GPT-4 to generate computer code. These experiments
demonstrate that AI code generation using the current generation of tools,
while powerful, requires substantial human validation to ensure accurate
performance. We also demonstrate that GPT-4 refactoring of existing code can
significantly improve that code along several established metrics for code
quality, and we show that GPT-4 can generate tests with substantial coverage,
but that many of the tests fail when applied to the associated code. These
findings suggest that while AI coding tools are very powerful, they still
require humans in the loop to ensure validity and accuracy of the results.

---------------

### 25 Sep 2023 | [Case Study: Using AI-Assisted Code Generation In Mobile Teams](https://arxiv.org/abs/2308.04736) | [⬇️](https://arxiv.org/pdf/2308.04736)
*Mircea-Serban Vasiliniuc, Adrian Groza* 

  The aim of this study is to evaluate the performance of AI-assisted
programming in actual mobile development teams that are focused on native
mobile languages like Kotlin and Swift. The extensive case study involves 16
participants and 2 technical reviewers, from a software development department
designed to understand the impact of using LLMs trained for code generation in
specific phases of the team, more specifically, technical onboarding and
technical stack switch. The study uses technical problems dedicated to each
phase and requests solutions from the participants with and without using
AI-Code generators. It measures time, correctness, and technical integration
using ReviewerScore, a metric specific to the paper and extracted from actual
industry standards, the code reviewers of merge requests. The output is
converted and analyzed together with feedback from the participants in an
attempt to determine if using AI-assisted programming tools will have an impact
on getting developers onboard in a project or helping them with a smooth
transition between the two native development environments of mobile
development, Android and iOS. The study was performed between May and June 2023
with members of the mobile department of a software development company based
in Cluj-Napoca, with Romanian ownership and management.

---------------

### 23 Aug 2021 | [CGEMs: A Metric Model for Automatic Code Generation using GPT-3](https://arxiv.org/abs/2108.10168) | [⬇️](https://arxiv.org/pdf/2108.10168)
*Aishwarya Narasimhan (1), Krishna Prasad Agara Venkatesha Rao (2),  Veena M B (1) ((1) B M S College of Engineering, (2) Sony India Software  Centre Pvt. Ltd.)* 

  Today, AI technology is showing its strengths in almost every industry and
walks of life. From text generation, text summarization, chatbots, NLP is being
used widely. One such paradigm is automatic code generation. An AI could be
generating anything; hence the output space is unconstrained. A self-driving
car is driven for 100 million miles to validate its safety, but tests cannot be
written to monitor and cover an unconstrained space. One of the solutions to
validate AI-generated content is to constrain the problem and convert it from
abstract to realistic, and this can be accomplished by either validating the
unconstrained algorithm using theoretical proofs or by using Monte-Carlo
simulation methods. In this case, we use the latter approach to test/validate a
statistically significant number of samples. This hypothesis of validating the
AI-generated code is the main motive of this work and to know if AI-generated
code is reliable, a metric model CGEMs is proposed. This is an extremely
challenging task as programs can have different logic with different naming
conventions, but the metrics must capture the structure and logic of the
program. This is similar to the importance grammar carries in AI-based text
generation, Q&A, translations, etc. The various metrics that are garnered in
this work to support the evaluation of generated code are as follows:
Compilation, NL description to logic conversion, number of edits needed, some
of the commonly used static-code metrics and NLP metrics. These metrics are
applied to 80 codes generated using OpenAI's GPT-3. Post which a Neural network
is designed for binary classification (acceptable/not acceptable quality of the
generated code). The inputs to this network are the values of the features
obtained from the metrics. The model achieves a classification accuracy of
76.92% and an F1 score of 55.56%. XAI is augmented for model interpretability.

---------------

### 23 Oct 2023 | [CodeLMSec Benchmark: Systematically Evaluating and Finding Security  Vulnerabilities in Black-Box Code Language Models](https://arxiv.org/abs/2302.04012) | [⬇️](https://arxiv.org/pdf/2302.04012)
*Hossein Hajipour, Keno Hassler, Thorsten Holz, Lea Sch\"onherr, Mario  Fritz* 

  Large language models (LLMs) for automatic code generation have achieved
breakthroughs in several programming tasks. Their advances in competition-level
programming problems have made them an essential pillar of AI-assisted pair
programming, and tools such as GitHub Copilot have emerged as part of the daily
programming workflow used by millions of developers. The training data for
these models is usually collected from the Internet (e.g., from open-source
repositories) and is likely to contain faults and security vulnerabilities.
This unsanitized training data can cause the language models to learn these
vulnerabilities and propagate them during the code generation procedure. While
these models have been extensively assessed for their ability to produce
functionally correct programs, there remains a lack of comprehensive
investigations and benchmarks addressing the security aspects of these models.
  In this work, we propose a method to systematically study the security issues
of code language models to assess their susceptibility to generating vulnerable
code. To this end, we introduce the first approach to automatically find
generated code that contains vulnerabilities in black-box code generation
models. To achieve this, we present an approach to approximate inversion of the
black-box code generation models based on few-shot prompting. We evaluate the
effectiveness of our approach by examining code language models in generating
high-risk security weaknesses. Furthermore, we establish a collection of
diverse non-secure prompts for various vulnerability scenarios using our
method. This dataset forms a benchmark for evaluating and comparing the
security weaknesses in code language models.

---------------

### 09 Feb 2024 | [Vulnerabilities in AI Code Generators: Exploring Targeted Data Poisoning  Attacks](https://arxiv.org/abs/2308.04451) | [⬇️](https://arxiv.org/pdf/2308.04451)
*Domenico Cotroneo, Cristina Improta, Pietro Liguori, Roberto Natella* 

  AI-based code generators have become pivotal in assisting developers in
writing software starting from natural language (NL). However, they are trained
on large amounts of data, often collected from unsanitized online sources
(e.g., GitHub, HuggingFace). As a consequence, AI models become an easy target
for data poisoning, i.e., an attack that injects malicious samples into the
training data to generate vulnerable code.
  To address this threat, this work investigates the security of AI code
generators by devising a targeted data poisoning strategy. We poison the
training data by injecting increasing amounts of code containing security
vulnerabilities and assess the attack's success on different state-of-the-art
models for code generation. Our study shows that AI code generators are
vulnerable to even a small amount of poison. Notably, the attack success
strongly depends on the model architecture and poisoning rate, whereas it is
not influenced by the type of vulnerabilities. Moreover, since the attack does
not impact the correctness of code generated by pre-trained models, it is hard
to detect. Lastly, our work offers practical insights into understanding and
potentially mitigating this threat.

---------------

### 05 Oct 2021 | [A toolbox for neuromorphic sensing in robotics](https://arxiv.org/abs/2103.02751) | [⬇️](https://arxiv.org/pdf/2103.02751)
*Julien Dupeyroux, Stein Stroobants, Guido de Croon* 

  The third generation of artificial intelligence (AI) introduced by
neuromorphic computing is revolutionizing the way robots and autonomous systems
can sense the world, process the information, and interact with their
environment. The promises of high flexibility, energy efficiency, and
robustness of neuromorphic systems is widely supported by software tools for
simulating spiking neural networks, and hardware integration (neuromorphic
processors). Yet, while efforts have been made on neuromorphic vision
(event-based cameras), it is worth noting that most of the sensors available
for robotics remain inherently incompatible with neuromorphic computing, where
information is encoded into spikes. To facilitate the use of traditional
sensors, we need to convert the output signals into streams of spikes, i.e., a
series of events (+1, -1) along with their corresponding timestamps. In this
paper, we propose a review of the coding algorithms from a robotics perspective
and further supported by a benchmark to assess their performance. We also
introduce a ROS (Robot Operating System) toolbox to encode and decode input
signals coming from any type of sensor available on a robot. This initiative is
meant to stimulate and facilitate robotic integration of neuromorphic AI, with
the opportunity to adapt traditional off-the-shelf sensors to spiking neural
nets within one of the most powerful robotic tools, ROS.

---------------

### 30 Dec 2020 | [LAIF: AI, Deep Learning for Germany Suetterlin Letter Recognition and  Generation](https://arxiv.org/abs/2101.10450) | [⬇️](https://arxiv.org/pdf/2101.10450)
*Enkhtogtokh Togootogtokh, Christian Klasen* 

  One of the successful early implementation of deep learning AI technology was
on letter recognition. With the recent breakthrough of artificial intelligence
(AI) brings more solid technology for complex problems like handwritten letter
recognition and even automatic generation of them. In this research, we
proposed deep learning framework called Ludwig AI Framework(LAIF) for Germany
Suetterlin letter recognition and generation. To recognize Suetterlin letter,
we proposed deep convolutional neural network. Since lack of big amount of data
to train for the deep models and huge cost to label existing hard copy of
handwritten letters, we also introduce the methodology with deep generative
adversarial network to generate handwritten letters as synthetic data. Main
source code is in https://github.com/enkhtogtokh/LAIF repository.

---------------

### 19 Aug 2023 | [An Empirical Study of AI-based Smart Contract Creation](https://arxiv.org/abs/2308.02955) | [⬇️](https://arxiv.org/pdf/2308.02955)
*Rabimba Karanjai, Edward Li, Lei Xu, Weidong Shi* 

  The introduction of large language models (LLMs) like ChatGPT and Google
Palm2 for smart contract generation seems to be the first well-established
instance of an AI pair programmer. LLMs have access to a large number of
open-source smart contracts, enabling them to utilize more extensive code in
Solidity than other code generation tools. Although the initial and informal
assessments of LLMs for smart contract generation are promising, a systematic
evaluation is needed to explore the limits and benefits of these models. The
main objective of this study is to assess the quality of generated code
provided by LLMs for smart contracts. We also aim to evaluate the impact of the
quality and variety of input parameters fed to LLMs. To achieve this aim, we
created an experimental setup for evaluating the generated code in terms of
validity, correctness, and efficiency. Our study finds crucial evidence of
security bugs getting introduced in the generated smart contracts as well as
the overall quality and correctness of the code getting impacted. However, we
also identified the areas where it can be improved. The paper also proposes
several potential research directions to improve the process, quality and
safety of generated smart contract codes.

---------------

### 13 Feb 2023 | [GPTScore: Evaluate as You Desire](https://arxiv.org/abs/2302.04166) | [⬇️](https://arxiv.org/pdf/2302.04166)
*Jinlan Fu, See-Kiong Ng, Zhengbao Jiang, Pengfei Liu* 

  Generative Artificial Intelligence (AI) has enabled the development of
sophisticated models that are capable of producing high-caliber text, images,
and other outputs through the utilization of large pre-trained models.
Nevertheless, assessing the quality of the generation is an even more arduous
task than the generation itself, and this issue has not been given adequate
consideration recently. This paper proposes a novel evaluation framework,
GPTScore, which utilizes the emergent abilities (e.g., zero-shot instruction)
of generative pre-trained models to score generated texts. There are 19
pre-trained models explored in this paper, ranging in size from 80M (e.g.,
FLAN-T5-small) to 175B (e.g., GPT3). Experimental results on four text
generation tasks, 22 evaluation aspects, and corresponding 37 datasets
demonstrate that this approach can effectively allow us to achieve what one
desires to evaluate for texts simply by natural language instructions. This
nature helps us overcome several long-standing challenges in text
evaluation--how to achieve customized, multi-faceted evaluation without the
need for annotated samples. We make our code publicly available at
https://github.com/jinlanfu/GPTScore.

---------------

### 07 Oct 2023 | [EasyPhoto: Your Smart AI Photo Generator](https://arxiv.org/abs/2310.04672) | [⬇️](https://arxiv.org/pdf/2310.04672)
*Ziheng Wu, Jiaqi Xu, Xinyi Zou, Kunzhe Huang, Xing Shi, Jun Huang* 

  Stable Diffusion web UI (SD-WebUI) is a comprehensive project that provides a
browser interface based on Gradio library for Stable Diffusion models. In this
paper, We propose a novel WebUI plugin called EasyPhoto, which enables the
generation of AI portraits. By training a digital doppelganger of a specific
user ID using 5 to 20 relevant images, the finetuned model (according to the
trained LoRA model) allows for the generation of AI photos using arbitrary
templates. Our current implementation supports the modification of multiple
persons and different photo styles. Furthermore, we allow users to generate
fantastic template image with the strong SDXL model, enhancing EasyPhoto's
capabilities to deliver more diverse and satisfactory results. The source code
for EasyPhoto is available at: https://github.com/aigc-apps/sd-webui-EasyPhoto.
We also support a webui-free version by using diffusers:
https://github.com/aigc-apps/EasyPhoto. We are continuously enhancing our
efforts to expand the EasyPhoto pipeline, making it suitable for any
identification (not limited to just the face), and we enthusiastically welcome
any intriguing ideas or suggestions.

---------------

### 16 Dec 2021 | [Asleep at the Keyboard? Assessing the Security of GitHub Copilot's Code  Contributions](https://arxiv.org/abs/2108.09293) | [⬇️](https://arxiv.org/pdf/2108.09293)
*Hammond Pearce, Baleegh Ahmad, Benjamin Tan, Brendan Dolan-Gavitt,  Ramesh Karri* 

  There is burgeoning interest in designing AI-based systems to assist humans
in designing computing systems, including tools that automatically generate
computer code. The most notable of these comes in the form of the first
self-described `AI pair programmer', GitHub Copilot, a language model trained
over open-source GitHub code. However, code often contains bugs - and so, given
the vast quantity of unvetted code that Copilot has processed, it is certain
that the language model will have learned from exploitable, buggy code. This
raises concerns on the security of Copilot's code contributions. In this work,
we systematically investigate the prevalence and conditions that can cause
GitHub Copilot to recommend insecure code. To perform this analysis we prompt
Copilot to generate code in scenarios relevant to high-risk CWEs (e.g. those
from MITRE's "Top 25" list). We explore Copilot's performance on three distinct
code generation axes -- examining how it performs given diversity of
weaknesses, diversity of prompts, and diversity of domains. In total, we
produce 89 different scenarios for Copilot to complete, producing 1,689
programs. Of these, we found approximately 40% to be vulnerable.

---------------

### 23 Jan 2024 | [AIGCBench: Comprehensive Evaluation of Image-to-Video Content Generated  by AI](https://arxiv.org/abs/2401.01651) | [⬇️](https://arxiv.org/pdf/2401.01651)
*Fanda Fan, Chunjie Luo, Wanling Gao, Jianfeng Zhan* 

  The burgeoning field of Artificial Intelligence Generated Content (AIGC) is
witnessing rapid advancements, particularly in video generation. This paper
introduces AIGCBench, a pioneering comprehensive and scalable benchmark
designed to evaluate a variety of video generation tasks, with a primary focus
on Image-to-Video (I2V) generation. AIGCBench tackles the limitations of
existing benchmarks, which suffer from a lack of diverse datasets, by including
a varied and open-domain image-text dataset that evaluates different
state-of-the-art algorithms under equivalent conditions. We employ a novel text
combiner and GPT-4 to create rich text prompts, which are then used to generate
images via advanced Text-to-Image models. To establish a unified evaluation
framework for video generation tasks, our benchmark includes 11 metrics
spanning four dimensions to assess algorithm performance. These dimensions are
control-video alignment, motion effects, temporal consistency, and video
quality. These metrics are both reference video-dependent and video-free,
ensuring a comprehensive evaluation strategy. The evaluation standard proposed
correlates well with human judgment, providing insights into the strengths and
weaknesses of current I2V algorithms. The findings from our extensive
experiments aim to stimulate further research and development in the I2V field.
AIGCBench represents a significant step toward creating standardized benchmarks
for the broader AIGC landscape, proposing an adaptable and equitable framework
for future assessments of video generation tasks. We have open-sourced the
dataset and evaluation code on the project website:
https://www.benchcouncil.org/AIGCBench.

---------------

### 02 Dec 2022 | [Programming Is Hard -- Or at Least It Used to Be: Educational  Opportunities And Challenges of AI Code Generation](https://arxiv.org/abs/2212.01020) | [⬇️](https://arxiv.org/pdf/2212.01020)
*Brett A. Becker and Paul Denny and James Finnie-Ansley and Andrew  Luxton-Reilly and James Prather and Eddie Antonio Santos* 

  The introductory programming sequence has been the focus of much research in
computing education. The recent advent of several viable and freely-available
AI-driven code generation tools present several immediate opportunities and
challenges in this domain. In this position paper we argue that the community
needs to act quickly in deciding what possible opportunities can and should be
leveraged and how, while also working on how to overcome or otherwise mitigate
the possible challenges. Assuming that the effectiveness and proliferation of
these tools will continue to progress rapidly, without quick, deliberate, and
concerted efforts, educators will lose advantage in helping shape what
opportunities come to be, and what challenges will endure. With this paper we
aim to seed this discussion within the computing education community.

---------------

### 10 Oct 2021 | [An In-depth Summary of Recent Artificial Intelligence Applications in  Drug Design](https://arxiv.org/abs/2110.05478) | [⬇️](https://arxiv.org/pdf/2110.05478)
*Yi Zhang* 

  As a promising tool to navigate in the vast chemical space, artificial
intelligence (AI) is leveraged for drug design. From the year 2017 to 2021, the
number of applications of several recent AI models (i.e. graph neural network
(GNN), recurrent neural network (RNN), variation autoencoder (VAE), generative
adversarial network (GAN), flow and reinforcement learning (RL)) in drug design
increases significantly. Many relevant literature reviews exist. However, none
of them provides an in-depth summary of many applications of the recent AI
models in drug design. To complement the existing literature, this survey
includes the theoretical development of the previously mentioned AI models and
detailed summaries of 42 recent applications of AI in drug design. Concretely,
13 of them leverage GNN for molecular property prediction and 29 of them use RL
and/or deep generative models for molecule generation and optimization. In most
cases, the focus of the summary is the models, their variants, and
modifications for specific tasks in drug design. Moreover, 60 additional
applications of AI in molecule generation and optimization are briefly
summarized in a table. Finally, this survey provides a holistic discussion of
the abundant applications so that the tasks, potential solutions, and
challenges in AI-based drug design become evident.

---------------

### 19 Oct 2021 | [GenNI: Human-AI Collaboration for Data-Backed Text Generation](https://arxiv.org/abs/2110.10185) | [⬇️](https://arxiv.org/pdf/2110.10185)
*Hendrik Strobelt, Jambay Kinley, Robert Krueger, Johanna Beyer,  Hanspeter Pfister, Alexander M. Rush* 

  Table2Text systems generate textual output based on structured data utilizing
machine learning. These systems are essential for fluent natural language
interfaces in tools such as virtual assistants; however, left to generate
freely these ML systems often produce misleading or unexpected outputs. GenNI
(Generation Negotiation Interface) is an interactive visual system for
high-level human-AI collaboration in producing descriptive text. The tool
utilizes a deep learning model designed with explicit control states. These
controls allow users to globally constrain model generations, without
sacrificing the representation power of the deep learning models. The visual
interface makes it possible for users to interact with AI systems following a
Refine-Forecast paradigm to ensure that the generation system acts in a manner
human users find suitable. We report multiple use cases on two experiments that
improve over uncontrolled generation approaches, while at the same time
providing fine-grained control. A demo and source code are available at
https://genni.vizhub.ai .

---------------

### 08 May 2023 | [Artificial Intelligence in 3GPP 5G-Advanced: A Survey](https://arxiv.org/abs/2305.05092) | [⬇️](https://arxiv.org/pdf/2305.05092)
*Xingqin Lin* 

  Industries worldwide are being transformed by artificial intelligence (AI),
and the telecom industry is no different. Standardization is critical for
industry alignment to achieve widespread adoption of AI in telecom. The 3rd
generation partnership project (3GPP) Release 18 is the first release of
5G-Advanced, which includes a diverse set of study and work items dedicated to
AI. This article provides a holistic overview of the state of the art in the
3GPP work on AI in 5G-Advanced, by presenting the various 3GPP Release-18
activities on AI as an organic whole, explaining in detail the design aspects,
and sharing various design rationales influencing standardization.

---------------

### 22 Feb 2024 | [RoboScript: Code Generation for Free-Form Manipulation Tasks across Real  and Simulation](https://arxiv.org/abs/2402.14623) | [⬇️](https://arxiv.org/pdf/2402.14623)
*Junting Chen, Yao Mu, Qiaojun Yu, Tianming Wei, Silang Wu, Zhecheng  Yuan, Zhixuan Liang, Chao Yang, Kaipeng Zhang, Wenqi Shao, Yu Qiao, Huazhe  Xu, Mingyu Ding, Ping Luo* 

  Rapid progress in high-level task planning and code generation for open-world
robot manipulation has been witnessed in Embodied AI. However, previous studies
put much effort into general common sense reasoning and task planning
capabilities of large-scale language or multi-modal models, relatively little
effort on ensuring the deployability of generated code on real robots, and
other fundamental components of autonomous robot systems including robot
perception, motion planning, and control. To bridge this ``ideal-to-real'' gap,
this paper presents \textbf{RobotScript}, a platform for 1) a deployable robot
manipulation pipeline powered by code generation; and 2) a code generation
benchmark for robot manipulation tasks in free-form natural language. The
RobotScript platform addresses this gap by emphasizing the unified interface
with both simulation and real robots, based on abstraction from the Robot
Operating System (ROS), ensuring syntax compliance and simulation validation
with Gazebo. We demonstrate the adaptability of our code generation framework
across multiple robot embodiments, including the Franka and UR5 robot arms, and
multiple grippers. Additionally, our benchmark assesses reasoning abilities for
physical space and constraints, highlighting the differences between GPT-3.5,
GPT-4, and Gemini in handling complex physical interactions. Finally, we
present a thorough evaluation on the whole system, exploring how each module in
the pipeline: code generation, perception, motion planning, and even object
geometric properties, impact the overall performance of the system.

---------------

### 05 Nov 2023 | [Assessing the Promise and Pitfalls of ChatGPT for Automated Code  Generation](https://arxiv.org/abs/2311.02640) | [⬇️](https://arxiv.org/pdf/2311.02640)
*Muhammad Fawad Akbar Khan, Max Ramsdell, Erik Falor, Hamid Karimi* 

  This paper presents a comprehensive evaluation of the code generation
capabilities of ChatGPT, a prominent large language model, compared to human
programmers. A novel dataset of 131 code-generation prompts across 5 categories
was curated to enable robust analysis. Code solutions were generated by both
ChatGPT and humans for all prompts, resulting in 262 code samples. A meticulous
manual assessment methodology prioritized evaluating correctness,
comprehensibility, and security using 14 established code quality metrics. The
key findings reveal ChatGPT's strengths in crafting concise, efficient code
with advanced constructs, showcasing strengths in data analysis tasks (93.1%
accuracy) but limitations in visual-graphical challenges. Comparative analysis
with human code highlights ChatGPT's inclination towards modular design and
superior error handling. Additionally, machine learning models effectively
distinguished ChatGPT from human code with up to 88% accuracy, suggesting
detectable coding style disparities. By providing profound insights into
ChatGPT's code generation capabilities and limitations through quantitative
metrics and qualitative analysis, this study makes valuable contributions
toward advancing AI-based programming assistants. The curated dataset and
methodology offer a robust foundation for future research in this nascent
domain. All data and codes are available on
https://github.com/DSAatUSU/ChatGPT-promises-and-pitfalls.

---------------
**Date:** 28 Jul 2020

**Title:** Formal Fields: A Framework to Automate Code Generation Across Domains

**Abstract Link:** [https://arxiv.org/abs/2007.14075](https://arxiv.org/abs/2007.14075)

**PDF Link:** [https://arxiv.org/pdf/2007.14075](https://arxiv.org/pdf/2007.14075)

---

**Date:** 30 Jan 2024

**Title:** Are ChatGPT and Other Similar Systems the Modern Lernaean Hydras of AI?

**Abstract Link:** [https://arxiv.org/abs/2306.09267](https://arxiv.org/abs/2306.09267)

**PDF Link:** [https://arxiv.org/pdf/2306.09267](https://arxiv.org/pdf/2306.09267)

---

**Date:** 25 Apr 2023

**Title:** AI-assisted coding: Experiments with GPT-4

**Abstract Link:** [https://arxiv.org/abs/2304.13187](https://arxiv.org/abs/2304.13187)

**PDF Link:** [https://arxiv.org/pdf/2304.13187](https://arxiv.org/pdf/2304.13187)

---

**Date:** 25 Sep 2023

**Title:** Case Study: Using AI-Assisted Code Generation In Mobile Teams

**Abstract Link:** [https://arxiv.org/abs/2308.04736](https://arxiv.org/abs/2308.04736)

**PDF Link:** [https://arxiv.org/pdf/2308.04736](https://arxiv.org/pdf/2308.04736)

---

**Date:** 23 Aug 2021

**Title:** CGEMs: A Metric Model for Automatic Code Generation using GPT-3

**Abstract Link:** [https://arxiv.org/abs/2108.10168](https://arxiv.org/abs/2108.10168)

**PDF Link:** [https://arxiv.org/pdf/2108.10168](https://arxiv.org/pdf/2108.10168)

---

**Date:** 23 Oct 2023

**Title:** CodeLMSec Benchmark: Systematically Evaluating and Finding Security  Vulnerabilities in Black-Box Code Language Models

**Abstract Link:** [https://arxiv.org/abs/2302.04012](https://arxiv.org/abs/2302.04012)

**PDF Link:** [https://arxiv.org/pdf/2302.04012](https://arxiv.org/pdf/2302.04012)

---

**Date:** 09 Feb 2024

**Title:** Vulnerabilities in AI Code Generators: Exploring Targeted Data Poisoning  Attacks

**Abstract Link:** [https://arxiv.org/abs/2308.04451](https://arxiv.org/abs/2308.04451)

**PDF Link:** [https://arxiv.org/pdf/2308.04451](https://arxiv.org/pdf/2308.04451)

---

**Date:** 05 Oct 2021

**Title:** A toolbox for neuromorphic sensing in robotics

**Abstract Link:** [https://arxiv.org/abs/2103.02751](https://arxiv.org/abs/2103.02751)

**PDF Link:** [https://arxiv.org/pdf/2103.02751](https://arxiv.org/pdf/2103.02751)

---

**Date:** 30 Dec 2020

**Title:** LAIF: AI, Deep Learning for Germany Suetterlin Letter Recognition and  Generation

**Abstract Link:** [https://arxiv.org/abs/2101.10450](https://arxiv.org/abs/2101.10450)

**PDF Link:** [https://arxiv.org/pdf/2101.10450](https://arxiv.org/pdf/2101.10450)

---

**Date:** 19 Aug 2023

**Title:** An Empirical Study of AI-based Smart Contract Creation

**Abstract Link:** [https://arxiv.org/abs/2308.02955](https://arxiv.org/abs/2308.02955)

**PDF Link:** [https://arxiv.org/pdf/2308.02955](https://arxiv.org/pdf/2308.02955)

---

**Date:** 13 Feb 2023

**Title:** GPTScore: Evaluate as You Desire

**Abstract Link:** [https://arxiv.org/abs/2302.04166](https://arxiv.org/abs/2302.04166)

**PDF Link:** [https://arxiv.org/pdf/2302.04166](https://arxiv.org/pdf/2302.04166)

---

**Date:** 07 Oct 2023

**Title:** EasyPhoto: Your Smart AI Photo Generator

**Abstract Link:** [https://arxiv.org/abs/2310.04672](https://arxiv.org/abs/2310.04672)

**PDF Link:** [https://arxiv.org/pdf/2310.04672](https://arxiv.org/pdf/2310.04672)

---

**Date:** 16 Dec 2021

**Title:** Asleep at the Keyboard? Assessing the Security of GitHub Copilot's Code  Contributions

**Abstract Link:** [https://arxiv.org/abs/2108.09293](https://arxiv.org/abs/2108.09293)

**PDF Link:** [https://arxiv.org/pdf/2108.09293](https://arxiv.org/pdf/2108.09293)

---

**Date:** 23 Jan 2024

**Title:** AIGCBench: Comprehensive Evaluation of Image-to-Video Content Generated  by AI

**Abstract Link:** [https://arxiv.org/abs/2401.01651](https://arxiv.org/abs/2401.01651)

**PDF Link:** [https://arxiv.org/pdf/2401.01651](https://arxiv.org/pdf/2401.01651)

---

**Date:** 02 Dec 2022

**Title:** Programming Is Hard -- Or at Least It Used to Be: Educational  Opportunities And Challenges of AI Code Generation

**Abstract Link:** [https://arxiv.org/abs/2212.01020](https://arxiv.org/abs/2212.01020)

**PDF Link:** [https://arxiv.org/pdf/2212.01020](https://arxiv.org/pdf/2212.01020)

---

**Date:** 10 Oct 2021

**Title:** An In-depth Summary of Recent Artificial Intelligence Applications in  Drug Design

**Abstract Link:** [https://arxiv.org/abs/2110.05478](https://arxiv.org/abs/2110.05478)

**PDF Link:** [https://arxiv.org/pdf/2110.05478](https://arxiv.org/pdf/2110.05478)

---

**Date:** 19 Oct 2021

**Title:** GenNI: Human-AI Collaboration for Data-Backed Text Generation

**Abstract Link:** [https://arxiv.org/abs/2110.10185](https://arxiv.org/abs/2110.10185)

**PDF Link:** [https://arxiv.org/pdf/2110.10185](https://arxiv.org/pdf/2110.10185)

---

**Date:** 08 May 2023

**Title:** Artificial Intelligence in 3GPP 5G-Advanced: A Survey

**Abstract Link:** [https://arxiv.org/abs/2305.05092](https://arxiv.org/abs/2305.05092)

**PDF Link:** [https://arxiv.org/pdf/2305.05092](https://arxiv.org/pdf/2305.05092)

---

**Date:** 22 Feb 2024

**Title:** RoboScript: Code Generation for Free-Form Manipulation Tasks across Real  and Simulation

**Abstract Link:** [https://arxiv.org/abs/2402.14623](https://arxiv.org/abs/2402.14623)

**PDF Link:** [https://arxiv.org/pdf/2402.14623](https://arxiv.org/pdf/2402.14623)

---

**Date:** 05 Nov 2023

**Title:** Assessing the Promise and Pitfalls of ChatGPT for Automated Code  Generation

**Abstract Link:** [https://arxiv.org/abs/2311.02640](https://arxiv.org/abs/2311.02640)

**PDF Link:** [https://arxiv.org/pdf/2311.02640](https://arxiv.org/pdf/2311.02640)

---

