Training Loss Optimization 🎨

### 🔎 Training Loss Optimization 🎨



Training a model is an iterative process. We start with a random model and then update it iteratively to minimize the training loss.

The training loss is the average loss over all the training examples.

The training loss is a function of the model parameters.

The goal of training is to find the model parameters that minimize the training loss.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a function of the model parameters.

The training loss is a
# 🩺🔍 Search Results
### 25 Jan 2024 | [Incorporating Exemplar Optimization into Training with Dual Networks for  Human Mesh Recovery](https://arxiv.org/abs/2401.14121) | [⬇️](https://arxiv.org/pdf/2401.14121)
*Yongwei Nie, Mingxian Fan, Chengjiang Long, Qing Zhang, Jian Zhu,  Xuemiao Xu* 

  We propose a novel optimization-based human mesh recovery method from a
single image. Given a test exemplar, previous approaches optimize the
pre-trained regression network to minimize the 2D re-projection loss, which
however suffer from over-/under-fitting problems. This is because the
``exemplar optimization'' at testing time has too weak relation to the
pre-training process, and the exemplar optimization loss function is different
from the training loss function. (1) We incorporate exemplar optimization into
the training stage. During training, our method first executes exemplar
optimization and subsequently proceeds with training-time optimization. The
exemplar optimization may run into a wrong direction, while the subsequent
training optimization serves to correct the deviation. Involved in training,
the exemplar optimization learns to adapt its behavior to training data,
thereby acquires generalibility to test exemplars. (2) We devise a dual-network
architecture to convey the novel training paradigm, which is composed of a main
regression network and an auxiliary network, in which we can formulate the
exemplar optimization loss function in the same form as the training loss
function. This further enhances the compatibility between the exemplar and
training optimizations. Experiments demonstrate that our exemplar optimization
after the novel training scheme significantly outperforms state-of-the-art
approaches.

---------------

### 29 Dec 2023 | [Multi-stage feature decorrelation constraints for improving CNN  classification performance](https://arxiv.org/abs/2308.12880) | [⬇️](https://arxiv.org/pdf/2308.12880)
*Qiuyu Zhu and Hao Wang and Xuewen Zu and Chengfei Liu* 

  For the convolutional neural network (CNN) used for pattern classification,
the training loss function is usually applied to the final output of the
network, except for some regularization constraints on the network parameters.
However, with the increasing of the number of network layers, the influence of
the loss function on the network front layers gradually decreases, and the
network parameters tend to fall into local optimization. At the same time, it
is found that the trained network has significant information redundancy at all
stages of features, which reduces the effectiveness of feature mapping at all
stages and is not conducive to the change of the subsequent parameters of the
network in the direction of optimality. Therefore, it is possible to obtain a
more optimized solution of the network and further improve the classification
accuracy of the network by designing a loss function for restraining the front
stage features and eliminating the information redundancy of the front stage
features .For CNN, this article proposes a multi-stage feature decorrelation
loss (MFD Loss), which refines effective features and eliminates information
redundancy by constraining the correlation of features at all stages.
Considering that there are many layers in CNN, through experimental comparison
and analysis, MFD Loss acts on multiple front layers of CNN, constrains the
output features of each layer and each channel, and performs supervision
training jointly with classification loss function during network training.
Compared with the single Softmax Loss supervised learning, the experiments on
several commonly used datasets on several typical CNNs prove that the
classification performance of Softmax Loss+MFD Loss is significantly better.
Meanwhile, the comparison experiments before and after the combination of MFD
Loss and some other typical loss functions verify its good universality.

---------------

### 08 Apr 2020 | [Gradient Centralization: A New Optimization Technique for Deep Neural  Networks](https://arxiv.org/abs/2004.01461) | [⬇️](https://arxiv.org/pdf/2004.01461)
*Hongwei Yong, Jianqiang Huang, Xiansheng Hua and Lei Zhang* 

  Optimization techniques are of great importance to effectively and
efficiently train a deep neural network (DNN). It has been shown that using the
first and second order statistics (e.g., mean and variance) to perform Z-score
standardization on network activations or weight vectors, such as batch
normalization (BN) and weight standardization (WS), can improve the training
performance. Different from these existing methods that mostly operate on
activations or weights, we present a new optimization technique, namely
gradient centralization (GC), which operates directly on gradients by
centralizing the gradient vectors to have zero mean. GC can be viewed as a
projected gradient descent method with a constrained loss function. We show
that GC can regularize both the weight space and output feature space so that
it can boost the generalization performance of DNNs. Moreover, GC improves the
Lipschitzness of the loss function and its gradient so that the training
process becomes more efficient and stable. GC is very simple to implement and
can be easily embedded into existing gradient based DNN optimizers with only
one line of code. It can also be directly used to fine-tune the pre-trained
DNNs. Our experiments on various applications, including general image
classification, fine-grained image classification, detection and segmentation,
demonstrate that GC can consistently improve the performance of DNN learning.
The code of GC can be found at
https://github.com/Yonghongwei/Gradient-Centralization.

---------------

### 02 Oct 2020 | [Optimizing Loss Functions Through Multivariate Taylor Polynomial  Parameterization](https://arxiv.org/abs/2002.00059) | [⬇️](https://arxiv.org/pdf/2002.00059)
*Santiago Gonzalez and Risto Miikkulainen* 

  Metalearning of deep neural network (DNN) architectures and hyperparameters
has become an increasingly important area of research. Loss functions are a
type of metaknowledge that is crucial to effective training of DNNs, however,
their potential role in metalearning has not yet been fully explored. Whereas
early work focused on genetic programming (GP) on tree representations, this
paper proposes continuous CMA-ES optimization of multivariate Taylor polynomial
parameterizations. This approach, TaylorGLO, makes it possible to represent and
search useful loss functions more effectively. In MNIST, CIFAR-10, and SVHN
benchmark tasks, TaylorGLO finds new loss functions that outperform functions
previously discovered through GP, as well as the standard cross-entropy loss,
in fewer generations. These functions serve to regularize the learning task by
discouraging overfitting to the labels, which is particularly useful in tasks
where limited training data is available. The results thus demonstrate that
loss function optimization is a productive new avenue for metalearning.

---------------

### 23 Nov 2022 | [Gradient Descent on Neural Networks Typically Occurs at the Edge of  Stability](https://arxiv.org/abs/2103.00065) | [⬇️](https://arxiv.org/pdf/2103.00065)
*Jeremy M. Cohen, Simran Kaur, Yuanzhi Li, J. Zico Kolter, Ameet  Talwalkar* 

  We empirically demonstrate that full-batch gradient descent on neural network
training objectives typically operates in a regime we call the Edge of
Stability. In this regime, the maximum eigenvalue of the training loss Hessian
hovers just above the numerical value $2 / \text{(step size)}$, and the
training loss behaves non-monotonically over short timescales, yet consistently
decreases over long timescales. Since this behavior is inconsistent with
several widespread presumptions in the field of optimization, our findings
raise questions as to whether these presumptions are relevant to neural network
training. We hope that our findings will inspire future efforts aimed at
rigorously understanding optimization at the Edge of Stability. Code is
available at https://github.com/locuslab/edge-of-stability.

---------------

### 22 Apr 2022 | [On Feature Learning in Neural Networks with Global Convergence  Guarantees](https://arxiv.org/abs/2204.10782) | [⬇️](https://arxiv.org/pdf/2204.10782)
*Zhengdao Chen, Eric Vanden-Eijnden and Joan Bruna* 

  We study the optimization of wide neural networks (NNs) via gradient flow
(GF) in setups that allow feature learning while admitting non-asymptotic
global convergence guarantees. First, for wide shallow NNs under the mean-field
scaling and with a general class of activation functions, we prove that when
the input dimension is no less than the size of the training set, the training
loss converges to zero at a linear rate under GF. Building upon this analysis,
we study a model of wide multi-layer NNs whose second-to-last layer is trained
via GF, for which we also prove a linear-rate convergence of the training loss
to zero, but regardless of the input dimension. We also show empirically that,
unlike in the Neural Tangent Kernel (NTK) regime, our multi-layer model
exhibits feature learning and can achieve better generalization performance
than its NTK counterpart.

---------------

### 25 Jun 2020 | [MTAdam: Automatic Balancing of Multiple Training Loss Terms](https://arxiv.org/abs/2006.14683) | [⬇️](https://arxiv.org/pdf/2006.14683)
*Itzik Malkiel, Lior Wolf* 

  When training neural models, it is common to combine multiple loss terms. The
balancing of these terms requires considerable human effort and is
computationally demanding. Moreover, the optimal trade-off between the loss
term can change as training progresses, especially for adversarial terms. In
this work, we generalize the Adam optimization algorithm to handle multiple
loss terms. The guiding principle is that for every layer, the gradient
magnitude of the terms should be balanced. To this end, the Multi-Term Adam
(MTAdam) computes the derivative of each loss term separately, infers the first
and second moments per parameter and loss term, and calculates a first moment
for the magnitude per layer of the gradients arising from each loss. This
magnitude is used to continuously balance the gradients across all layers, in a
manner that both varies from one layer to the next and dynamically changes over
time. Our results show that training with the new method leads to fast recovery
from suboptimal initial loss weighting and to training outcomes that match
conventional training with the prescribed hyperparameters of each method.

---------------

### 16 Jul 2020 | [Semi-Siamese Training for Shallow Face Learning](https://arxiv.org/abs/2007.08398) | [⬇️](https://arxiv.org/pdf/2007.08398)
*Hang Du, Hailin Shi, Yuchi Liu, Jun Wang, Zhen Lei, Dan Zeng, Tao Mei* 

  Most existing public face datasets, such as MS-Celeb-1M and VGGFace2, provide
abundant information in both breadth (large number of IDs) and depth
(sufficient number of samples) for training. However, in many real-world
scenarios of face recognition, the training dataset is limited in depth, i.e.
only two face images are available for each ID. $\textit{We define this
situation as Shallow Face Learning, and find it problematic with existing
training methods.}$ Unlike deep face data, the shallow face data lacks
intra-class diversity. As such, it can lead to collapse of feature dimension
and consequently the learned network can easily suffer from degeneration and
over-fitting in the collapsed dimension. In this paper, we aim to address the
problem by introducing a novel training method named Semi-Siamese Training
(SST). A pair of Semi-Siamese networks constitute the forward propagation
structure, and the training loss is computed with an updating gallery queue,
conducting effective optimization on shallow training data. Our method is
developed without extra-dependency, thus can be flexibly integrated with the
existing loss functions and network architectures. Extensive experiments on
various benchmarks of face recognition show the proposed method significantly
improves the training, not only in shallow face learning, but also for
conventional deep face data.

---------------

### 29 Apr 2021 | [Sharpness-Aware Minimization for Efficiently Improving Generalization](https://arxiv.org/abs/2010.01412) | [⬇️](https://arxiv.org/pdf/2010.01412)
*Pierre Foret, Ariel Kleiner, Hossein Mobahi, Behnam Neyshabur* 

  In today's heavily overparameterized models, the value of the training loss
provides few guarantees on model generalization ability. Indeed, optimizing
only the training loss value, as is commonly done, can easily lead to
suboptimal model quality. Motivated by prior work connecting the geometry of
the loss landscape and generalization, we introduce a novel, effective
procedure for instead simultaneously minimizing loss value and loss sharpness.
In particular, our procedure, Sharpness-Aware Minimization (SAM), seeks
parameters that lie in neighborhoods having uniformly low loss; this
formulation results in a min-max optimization problem on which gradient descent
can be performed efficiently. We present empirical results showing that SAM
improves model generalization across a variety of benchmark datasets (e.g.,
CIFAR-10, CIFAR-100, ImageNet, finetuning tasks) and models, yielding novel
state-of-the-art performance for several. Additionally, we find that SAM
natively provides robustness to label noise on par with that provided by
state-of-the-art procedures that specifically target learning with noisy
labels. We open source our code at
\url{https://github.com/google-research/sam}.

---------------

### 02 Dec 2021 | [On the Stability Properties and the Optimization Landscape of Training  Problems with Squared Loss for Neural Networks and General Nonlinear Conic  Approximation Schemes](https://arxiv.org/abs/2011.03293) | [⬇️](https://arxiv.org/pdf/2011.03293)
*Constantin Christof* 

  We study the optimization landscape and the stability properties of training
problems with squared loss for neural networks and general nonlinear conic
approximation schemes. It is demonstrated that, if a nonlinear conic
approximation scheme is considered that is (in an appropriately defined sense)
more expressive than a classical linear approximation approach and if there
exist unrealizable label vectors, then a training problem with squared loss is
necessarily unstable in the sense that its solution set depends discontinuously
on the label vector in the training data. We further prove that the same
effects that are responsible for these instability properties are also the
reason for the emergence of saddle points and spurious local minima, which may
be arbitrarily far away from global solutions, and that neither the instability
of the training problem nor the existence of spurious local minima can, in
general, be overcome by adding a regularization term to the objective function
that penalizes the size of the parameters in the approximation scheme. The
latter results are shown to be true regardless of whether the assumption of
realizability is satisfied or not. We demonstrate that our analysis in
particular applies to training problems for free-knot interpolation schemes and
deep and shallow neural networks with variable widths that involve an arbitrary
mixture of various activation functions (e.g., binary, sigmoid, tanh, arctan,
soft-sign, ISRU, soft-clip, SQNL, ReLU, leaky ReLU, soft-plus, bent identity,
SILU, ISRLU, and ELU). In summary, the findings of this paper illustrate that
the improved approximation properties of neural networks and general nonlinear
conic approximation instruments are linked in a direct and quantifiable way to
undesirable properties of the optimization problems that have to be solved in
order to train them.

---------------

### 01 Nov 2021 | [Adversarial Attack Generation Empowered by Min-Max Optimization](https://arxiv.org/abs/1906.03563) | [⬇️](https://arxiv.org/pdf/1906.03563)
*Jingkang Wang, Tianyun Zhang, Sijia Liu, Pin-Yu Chen, Jiacen Xu, Makan  Fardad, Bo Li* 

  The worst-case training principle that minimizes the maximal adversarial
loss, also known as adversarial training (AT), has shown to be a
state-of-the-art approach for enhancing adversarial robustness. Nevertheless,
min-max optimization beyond the purpose of AT has not been rigorously explored
in the adversarial context. In this paper, we show how a general framework of
min-max optimization over multiple domains can be leveraged to advance the
design of different types of adversarial attacks. In particular, given a set of
risk sources, minimizing the worst-case attack loss can be reformulated as a
min-max problem by introducing domain weights that are maximized over the
probability simplex of the domain set. We showcase this unified framework in
three attack generation problems -- attacking model ensembles, devising
universal perturbation under multiple inputs, and crafting attacks resilient to
data transformations. Extensive experiments demonstrate that our approach leads
to substantial attack improvement over the existing heuristic strategies as
well as robustness improvement over state-of-the-art defense methods trained to
be robust against multiple perturbation types. Furthermore, we find that the
self-adjusted domain weights learned from our min-max framework can provide a
holistic tool to explain the difficulty level of attack across domains. Code is
available at https://github.com/wangjksjtu/minmax-adv.

---------------

### 27 Dec 2018 | [Stochastic Gradient Descent Optimizes Over-parameterized Deep ReLU  Networks](https://arxiv.org/abs/1811.08888) | [⬇️](https://arxiv.org/pdf/1811.08888)
*Difan Zou, Yuan Cao, Dongruo Zhou, Quanquan Gu* 

  We study the problem of training deep neural networks with Rectified Linear
Unit (ReLU) activation function using gradient descent and stochastic gradient
descent. In particular, we study the binary classification problem and show
that for a broad family of loss functions, with proper random weight
initialization, both gradient descent and stochastic gradient descent can find
the global minima of the training loss for an over-parameterized deep ReLU
network, under mild assumption on the training data. The key idea of our proof
is that Gaussian random initialization followed by (stochastic) gradient
descent produces a sequence of iterates that stay inside a small perturbation
region centering around the initial weights, in which the empirical loss
function of deep ReLU networks enjoys nice local curvature properties that
ensure the global convergence of (stochastic) gradient descent. Our theoretical
results shed light on understanding the optimization for deep learning, and
pave the way for studying the optimization dynamics of training modern deep
neural networks.

---------------

### 24 Aug 2021 | [Cumulant GAN](https://arxiv.org/abs/2006.06625) | [⬇️](https://arxiv.org/pdf/2006.06625)
*Yannis Pantazis, Dipjyoti Paul, Michail Fasoulakis, Yannis Stylianou  and Markos Katsoulakis* 

  In this paper, we propose a novel loss function for training Generative
Adversarial Networks (GANs) aiming towards deeper theoretical understanding as
well as improved stability and performance for the underlying optimization
problem. The new loss function is based on cumulant generating functions giving
rise to \emph{Cumulant GAN}. Relying on a recently-derived variational formula,
we show that the corresponding optimization problem is equivalent to R{\'e}nyi
divergence minimization, thus offering a (partially) unified perspective of GAN
losses: the R{\'e}nyi family encompasses Kullback-Leibler divergence (KLD),
reverse KLD, Hellinger distance and $\chi^2$-divergence. Wasserstein GAN is
also a member of cumulant GAN. In terms of stability, we rigorously prove the
linear convergence of cumulant GAN to the Nash equilibrium for a linear
discriminator, Gaussian distributions and the standard gradient descent ascent
algorithm. Finally, we experimentally demonstrate that image generation is more
robust relative to Wasserstein GAN and it is substantially improved in terms of
both inception score and Fr\'echet inception distance when both weaker and
stronger discriminators are considered.

---------------

### 20 Nov 2020 | [Adversarial Training for EM Classification Networks](https://arxiv.org/abs/2011.10615) | [⬇️](https://arxiv.org/pdf/2011.10615)
*Tom Grimes, Eric Church, William Pitts, Lynn Wood, Eva Brayfindley,  Luke Erikson, Mark Greaves* 

  We present a novel variant of Domain Adversarial Networks with impactful
improvements to the loss functions, training paradigm, and hyperparameter
optimization. New loss functions are defined for both forks of the DANN
network, the label predictor and domain classifier, in order to facilitate more
rapid gradient descent, provide more seamless integration into modern neural
networking frameworks, and allow previously unavailable inferences into network
behavior. Using these loss functions, it is possible to extend the concept of
'domain' to include arbitrary user defined labels applicable to subsets of the
training data, the test data, or both. As such, the network can be operated in
either 'On the Fly' mode where features provided by the feature extractor
indicative of differences between 'domain' labels in the training data are
removed or in 'Test Collection Informed' mode where features indicative of
difference between 'domain' labels in the combined training and test data are
removed (without needing to know or provide test activity labels to the
network). This work also draws heavily from previous works on Robust Training
which draws training examples from a L_inf ball around the training data in
order to remove fragile features induced by random fluctuations in the data. On
these networks we explore the process of hyperparameter optimization for both
the domain adversarial and robust hyperparameters. Finally, this network is
applied to the construction of a binary classifier used to identify the
presence of EM signal emitted by a turbopump. For this example, the effect of
the robust and domain adversarial training is to remove features indicative of
the difference in background between instances of operation of the device -
providing highly discriminative features on which to construct the classifier.

---------------

### 13 Feb 2023 | [On the Role of Fixed Points of Dynamical Systems in Training  Physics-Informed Neural Networks](https://arxiv.org/abs/2203.13648) | [⬇️](https://arxiv.org/pdf/2203.13648)
*Franz M. Rohrhofer, Stefan Posch, Clemens G\"o{\ss}nitzer, Bernhard C.  Geiger* 

  This paper empirically studies commonly observed training difficulties of
Physics-Informed Neural Networks (PINNs) on dynamical systems. Our results
indicate that fixed points which are inherent to these systems play a key role
in the optimization of the in PINNs embedded physics loss function. We observe
that the loss landscape exhibits local optima that are shaped by the presence
of fixed points. We find that these local optima contribute to the complexity
of the physics loss optimization which can explain common training difficulties
and resulting nonphysical predictions. Under certain settings, e.g., initial
conditions close to fixed points or long simulations times, we show that those
optima can even become better than that of the desired solution.

---------------

### 27 Apr 2020 | [Improved Training Speed, Accuracy, and Data Utilization Through Loss  Function Optimization](https://arxiv.org/abs/1905.11528) | [⬇️](https://arxiv.org/pdf/1905.11528)
*Santiago Gonzalez and Risto Miikkulainen* 

  As the complexity of neural network models has grown, it has become
increasingly important to optimize their design automatically through
metalearning. Methods for discovering hyperparameters, topologies, and learning
rate schedules have lead to significant increases in performance. This paper
shows that loss functions can be optimized with metalearning as well, and
result in similar improvements. The method, Genetic Loss-function Optimization
(GLO), discovers loss functions de novo, and optimizes them for a target task.
Leveraging techniques from genetic programming, GLO builds loss functions
hierarchically from a set of operators and leaf nodes. These functions are
repeatedly recombined and mutated to find an optimal structure, and then a
covariance-matrix adaptation evolutionary strategy (CMA-ES) is used to find
optimal coefficients. Networks trained with GLO loss functions are found to
outperform the standard cross-entropy loss on standard image classification
tasks. Training with these new loss functions requires fewer steps, results in
lower test error, and allows for smaller datasets to be used. Loss-function
optimization thus provides a new dimension of metalearning, and constitutes an
important step towards AutoML.

---------------

### 28 Oct 2021 | [Effective Regularization Through Loss-Function Metalearning](https://arxiv.org/abs/2010.00788) | [⬇️](https://arxiv.org/pdf/2010.00788)
*Santiago Gonzalez and Risto Miikkulainen* 

  Evolutionary optimization, such as the TaylorGLO method, can be used to
discover novel, customized loss functions for deep neural networks, resulting
in improved performance, faster training, and improved data utilization. A
likely explanation is that such functions discourage overfitting, leading to
effective regularization. This paper demonstrates theoretically that this is
indeed the case for TaylorGLO: Decomposition of learning rules makes it
possible to characterize the training dynamics and show that the loss functions
evolved by TaylorGLO balance the pull to zero error, and a push away from it to
avoid overfitting. They may also automatically take advantage of label
smoothing. This analysis leads to an invariant that can be utilized to make the
metalearning process more efficient in practice; the mechanism also results in
networks that are robust against adversarial attacks. Loss-function evolution
can thus be seen as a well-founded new aspect of metalearning in neural
networks.

---------------

### 27 Mar 2023 | [Generalization and Stability of Interpolating Neural Networks with  Minimal Width](https://arxiv.org/abs/2302.09235) | [⬇️](https://arxiv.org/pdf/2302.09235)
*Hossein Taheri, Christos Thrampoulidis* 

  We investigate the generalization and optimization properties of shallow
neural-network classifiers trained by gradient descent in the interpolating
regime. Specifically, in a realizable scenario where model weights can achieve
arbitrarily small training error $\epsilon$ and their distance from
initialization is $g(\epsilon)$, we demonstrate that gradient descent with $n$
training data achieves training error $O(g(1/T)^2 /T)$ and generalization error
$O(g(1/T)^2 /n)$ at iteration $T$, provided there are at least
$m=\Omega(g(1/T)^4)$ hidden neurons. We then show that our realizable setting
encompasses a special case where data are separable by the model's neural
tangent kernel. For this and logistic-loss minimization, we prove the training
loss decays at a rate of $\tilde O(1/ T)$ given polylogarithmic number of
neurons $m=\Omega(\log^4 (T))$. Moreover, with $m=\Omega(\log^{4} (n))$ neurons
and $T\approx n$ iterations, we bound the test loss by $\tilde{O}(1/n)$. Our
results differ from existing generalization outcomes using the
algorithmic-stability framework, which necessitate polynomial width and yield
suboptimal generalization rates. Central to our analysis is the use of a new
self-bounded weak-convexity property, which leads to a generalized local
quasi-convexity property for sufficiently parameterized neural-network
classifiers. Eventually, despite the objective's non-convexity, this leads to
convergence and generalization-gap bounds that resemble those found in the
convex setting of linear logistic regression.

---------------

### 26 Feb 2020 | [Deep Active Learning: Unified and Principled Method for Query and  Training](https://arxiv.org/abs/1911.09162) | [⬇️](https://arxiv.org/pdf/1911.09162)
*Changjian Shui, Fan Zhou, Christian Gagn\'e, Boyu Wang* 

  In this paper, we are proposing a unified and principled method for both the
querying and training processes in deep batch active learning. We are providing
theoretical insights from the intuition of modeling the interactive procedure
in active learning as distribution matching, by adopting the Wasserstein
distance. As a consequence, we derived a new training loss from the theoretical
analysis, which is decomposed into optimizing deep neural network parameters
and batch query selection through alternative optimization. In addition, the
loss for training a deep neural network is naturally formulated as a min-max
optimization problem through leveraging the unlabeled data information.
Moreover, the proposed principles also indicate an explicit
uncertainty-diversity trade-off in the query batch selection. Finally, we
evaluate our proposed method on different benchmarks, consistently showing
better empirical performances and a better time-efficient query strategy
compared to the baselines.

---------------

### 25 Aug 2017 | [A General Distributed Dual Coordinate Optimization Framework for  Regularized Loss Minimization](https://arxiv.org/abs/1604.03763) | [⬇️](https://arxiv.org/pdf/1604.03763)
*Shun Zheng, Jialei Wang, Fen Xia, Wei Xu, Tong Zhang* 

  In modern large-scale machine learning applications, the training data are
often partitioned and stored on multiple machines. It is customary to employ
the "data parallelism" approach, where the aggregated training loss is
minimized without moving data across machines. In this paper, we introduce a
novel distributed dual formulation for regularized loss minimization problems
that can directly handle data parallelism in the distributed setting. This
formulation allows us to systematically derive dual coordinate optimization
procedures, which we refer to as Distributed Alternating Dual Maximization
(DADM). The framework extends earlier studies described in (Boyd et al., 2011;
Ma et al., 2015a; Jaggi et al., 2014; Yang, 2013) and has rigorous theoretical
analyses. Moreover with the help of the new formulation, we develop the
accelerated version of DADM (Acc-DADM) by generalizing the acceleration
technique from (Shalev-Shwartz and Zhang, 2014) to the distributed setting. We
also provide theoretical results for the proposed accelerated version and the
new result improves previous ones (Yang, 2013; Ma et al., 2015a) whose runtimes
grow linearly on the condition number. Our empirical studies validate our
theory and show that our accelerated approach significantly improves the
previous state-of-the-art distributed dual coordinate optimization algorithms.

---------------
**Date:** 25 Jan 2024

**Title:** Incorporating Exemplar Optimization into Training with Dual Networks for  Human Mesh Recovery

**Abstract Link:** [https://arxiv.org/abs/2401.14121](https://arxiv.org/abs/2401.14121)

**PDF Link:** [https://arxiv.org/pdf/2401.14121](https://arxiv.org/pdf/2401.14121)

---

**Date:** 29 Dec 2023

**Title:** Multi-stage feature decorrelation constraints for improving CNN  classification performance

**Abstract Link:** [https://arxiv.org/abs/2308.12880](https://arxiv.org/abs/2308.12880)

**PDF Link:** [https://arxiv.org/pdf/2308.12880](https://arxiv.org/pdf/2308.12880)

---

**Date:** 08 Apr 2020

**Title:** Gradient Centralization: A New Optimization Technique for Deep Neural  Networks

**Abstract Link:** [https://arxiv.org/abs/2004.01461](https://arxiv.org/abs/2004.01461)

**PDF Link:** [https://arxiv.org/pdf/2004.01461](https://arxiv.org/pdf/2004.01461)

---

**Date:** 02 Oct 2020

**Title:** Optimizing Loss Functions Through Multivariate Taylor Polynomial  Parameterization

**Abstract Link:** [https://arxiv.org/abs/2002.00059](https://arxiv.org/abs/2002.00059)

**PDF Link:** [https://arxiv.org/pdf/2002.00059](https://arxiv.org/pdf/2002.00059)

---

**Date:** 23 Nov 2022

**Title:** Gradient Descent on Neural Networks Typically Occurs at the Edge of  Stability

**Abstract Link:** [https://arxiv.org/abs/2103.00065](https://arxiv.org/abs/2103.00065)

**PDF Link:** [https://arxiv.org/pdf/2103.00065](https://arxiv.org/pdf/2103.00065)

---

**Date:** 22 Apr 2022

**Title:** On Feature Learning in Neural Networks with Global Convergence  Guarantees

**Abstract Link:** [https://arxiv.org/abs/2204.10782](https://arxiv.org/abs/2204.10782)

**PDF Link:** [https://arxiv.org/pdf/2204.10782](https://arxiv.org/pdf/2204.10782)

---

**Date:** 25 Jun 2020

**Title:** MTAdam: Automatic Balancing of Multiple Training Loss Terms

**Abstract Link:** [https://arxiv.org/abs/2006.14683](https://arxiv.org/abs/2006.14683)

**PDF Link:** [https://arxiv.org/pdf/2006.14683](https://arxiv.org/pdf/2006.14683)

---

**Date:** 16 Jul 2020

**Title:** Semi-Siamese Training for Shallow Face Learning

**Abstract Link:** [https://arxiv.org/abs/2007.08398](https://arxiv.org/abs/2007.08398)

**PDF Link:** [https://arxiv.org/pdf/2007.08398](https://arxiv.org/pdf/2007.08398)

---

**Date:** 29 Apr 2021

**Title:** Sharpness-Aware Minimization for Efficiently Improving Generalization

**Abstract Link:** [https://arxiv.org/abs/2010.01412](https://arxiv.org/abs/2010.01412)

**PDF Link:** [https://arxiv.org/pdf/2010.01412](https://arxiv.org/pdf/2010.01412)

---

**Date:** 02 Dec 2021

**Title:** On the Stability Properties and the Optimization Landscape of Training  Problems with Squared Loss for Neural Networks and General Nonlinear Conic  Approximation Schemes

**Abstract Link:** [https://arxiv.org/abs/2011.03293](https://arxiv.org/abs/2011.03293)

**PDF Link:** [https://arxiv.org/pdf/2011.03293](https://arxiv.org/pdf/2011.03293)

---

**Date:** 01 Nov 2021

**Title:** Adversarial Attack Generation Empowered by Min-Max Optimization

**Abstract Link:** [https://arxiv.org/abs/1906.03563](https://arxiv.org/abs/1906.03563)

**PDF Link:** [https://arxiv.org/pdf/1906.03563](https://arxiv.org/pdf/1906.03563)

---

**Date:** 27 Dec 2018

**Title:** Stochastic Gradient Descent Optimizes Over-parameterized Deep ReLU  Networks

**Abstract Link:** [https://arxiv.org/abs/1811.08888](https://arxiv.org/abs/1811.08888)

**PDF Link:** [https://arxiv.org/pdf/1811.08888](https://arxiv.org/pdf/1811.08888)

---

**Date:** 24 Aug 2021

**Title:** Cumulant GAN

**Abstract Link:** [https://arxiv.org/abs/2006.06625](https://arxiv.org/abs/2006.06625)

**PDF Link:** [https://arxiv.org/pdf/2006.06625](https://arxiv.org/pdf/2006.06625)

---

**Date:** 20 Nov 2020

**Title:** Adversarial Training for EM Classification Networks

**Abstract Link:** [https://arxiv.org/abs/2011.10615](https://arxiv.org/abs/2011.10615)

**PDF Link:** [https://arxiv.org/pdf/2011.10615](https://arxiv.org/pdf/2011.10615)

---

**Date:** 13 Feb 2023

**Title:** On the Role of Fixed Points of Dynamical Systems in Training  Physics-Informed Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2203.13648](https://arxiv.org/abs/2203.13648)

**PDF Link:** [https://arxiv.org/pdf/2203.13648](https://arxiv.org/pdf/2203.13648)

---

**Date:** 27 Apr 2020

**Title:** Improved Training Speed, Accuracy, and Data Utilization Through Loss  Function Optimization

**Abstract Link:** [https://arxiv.org/abs/1905.11528](https://arxiv.org/abs/1905.11528)

**PDF Link:** [https://arxiv.org/pdf/1905.11528](https://arxiv.org/pdf/1905.11528)

---

**Date:** 28 Oct 2021

**Title:** Effective Regularization Through Loss-Function Metalearning

**Abstract Link:** [https://arxiv.org/abs/2010.00788](https://arxiv.org/abs/2010.00788)

**PDF Link:** [https://arxiv.org/pdf/2010.00788](https://arxiv.org/pdf/2010.00788)

---

**Date:** 27 Mar 2023

**Title:** Generalization and Stability of Interpolating Neural Networks with  Minimal Width

**Abstract Link:** [https://arxiv.org/abs/2302.09235](https://arxiv.org/abs/2302.09235)

**PDF Link:** [https://arxiv.org/pdf/2302.09235](https://arxiv.org/pdf/2302.09235)

---

**Date:** 26 Feb 2020

**Title:** Deep Active Learning: Unified and Principled Method for Query and  Training

**Abstract Link:** [https://arxiv.org/abs/1911.09162](https://arxiv.org/abs/1911.09162)

**PDF Link:** [https://arxiv.org/pdf/1911.09162](https://arxiv.org/pdf/1911.09162)

---

**Date:** 25 Aug 2017

**Title:** A General Distributed Dual Coordinate Optimization Framework for  Regularized Loss Minimization

**Abstract Link:** [https://arxiv.org/abs/1604.03763](https://arxiv.org/abs/1604.03763)

**PDF Link:** [https://arxiv.org/pdf/1604.03763](https://arxiv.org/pdf/1604.03763)

---

