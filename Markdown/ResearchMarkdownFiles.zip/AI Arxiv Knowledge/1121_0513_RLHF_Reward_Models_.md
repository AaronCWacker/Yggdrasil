RLHF Reward Models 🤝

### 🔎 RLHF Reward Models 🤝


=====================

This repository contains the code for the RLHF Reward Models project.

The project is a collaboration between [Anthropic](https://www.anthropic.com/), [DeepMind](https://deepmind.com/), [Mozilla](https://www.mozilla.org/), and [OpenAI](https://openai.com/).

The goal of the project is to develop and evaluate reward models for use in reinforcement learning with human feedback (RLHF).

The project is divided into two main parts:

1. **Reward Model Training**: This part of the project focuses on training reward models on human feedback data.
2. **Reward Model Evaluation**: This part of the project focuses on evaluating reward models on a variety of tasks and metrics.

The code for each part of the project is contained in a separate directory:

- [`reward_model_training`](reward_model_training): Code for training reward models.
- [`reward_model_evaluation`](reward_model_evaluation): Code for evaluating reward models.

## Reward Model Training

The [`reward_model_training`](reward_model_training) directory contains the code for training reward models.

The code is organized into the following subdirectories:

- [`data`](reward_model_training/data): Code for processing and loading human feedback data.
- [`models`](reward_model_training/models): Code for defining and training reward models.
- [`training`](reward_model_training/training): Code for running reward model training experiments.

### Data

The [`data`](reward_model_training/data) directory contains the code for processing and loading human feedback data.

The data is stored in the `data/` directory and is organized into the following subdirectories:

- `raw/`: Raw human feedback data.
- `processed/`: Processed human feedback data.

The code for processing and loading the data is contained in the following files:

- [`data_loader.py`](reward_model_training/data/data_loader.py): Code for loading processed human feedback data.
- [`data_processor.py`](re
# 🩺🔍 Search Results
### 12 Jan 2024 | [Secrets of RLHF in Large Language Models Part II: Reward Modeling](https://arxiv.org/abs/2401.06080) | [⬇️](https://arxiv.org/pdf/2401.06080)
*Binghai Wang, Rui Zheng, Lu Chen, Yan Liu, Shihan Dou, Caishuang  Huang, Wei Shen, Senjie Jin, Enyu Zhou, Chenyu Shi, Songyang Gao, Nuo Xu,  Yuhao Zhou, Xiaoran Fan, Zhiheng Xi, Jun Zhao, Xiao Wang, Tao Ji, Hang Yan,  Lixing Shen, Zhan Chen, Tao Gui, Qi Zhang, Xipeng Qiu, Xuanjing Huang, Zuxuan  Wu, Yu-Gang Jiang* 

  Reinforcement Learning from Human Feedback (RLHF) has become a crucial
technology for aligning language models with human values and intentions,
enabling models to produce more helpful and harmless responses. Reward models
are trained as proxies for human preferences to drive reinforcement learning
optimization. While reward models are often considered central to achieving
high performance, they face the following challenges in practical applications:
(1) Incorrect and ambiguous preference pairs in the dataset may hinder the
reward model from accurately capturing human intent. (2) Reward models trained
on data from a specific distribution often struggle to generalize to examples
outside that distribution and are not suitable for iterative RLHF training.
  In this report, we attempt to address these two issues. (1) From a data
perspective, we propose a method to measure the strength of preferences within
the data, based on a voting mechanism of multiple reward models. Experimental
results confirm that data with varying preference strengths have different
impacts on reward model performance. We introduce a series of novel methods to
mitigate the influence of incorrect and ambiguous preferences in the dataset
and fully leverage high-quality preference data. (2) From an algorithmic
standpoint, we introduce contrastive learning to enhance the ability of reward
models to distinguish between chosen and rejected responses, thereby improving
model generalization. Furthermore, we employ meta-learning to enable the reward
model to maintain the ability to differentiate subtle differences in
out-of-distribution samples, and this approach can be utilized for iterative
RLHF optimization.

---------------

### 30 Jan 2024 | [Improving Reinforcement Learning from Human Feedback with Efficient  Reward Model Ensemble](https://arxiv.org/abs/2401.16635) | [⬇️](https://arxiv.org/pdf/2401.16635)
*Shun Zhang, Zhenfang Chen, Sunli Chen, Yikang Shen, Zhiqing Sun,  Chuang Gan* 

  Reinforcement Learning from Human Feedback (RLHF) is a widely adopted
approach for aligning large language models with human values. However, RLHF
relies on a reward model that is trained with a limited amount of human
preference data, which could lead to inaccurate predictions. As a result, RLHF
may produce outputs that are misaligned with human values. To mitigate this
issue, we contribute a reward ensemble method that allows the reward model to
make more accurate predictions. As using an ensemble of large language
model-based reward models can be computationally and resource-expensive, we
explore efficient ensemble methods including linear-layer ensemble and
LoRA-based ensemble. Empirically, we run Best-of-$n$ and Proximal Policy
Optimization with our ensembled reward models, and verify that our ensemble
methods help improve the alignment performance of RLHF outputs.

---------------

### 29 Jan 2024 | [Iterative Data Smoothing: Mitigating Reward Overfitting and  Overoptimization in RLHF](https://arxiv.org/abs/2401.16335) | [⬇️](https://arxiv.org/pdf/2401.16335)
*Banghua Zhu, Michael I. Jordan and Jiantao Jiao* 

  Reinforcement Learning from Human Feedback (RLHF) is a pivotal technique that
aligns language models closely with human-centric values. The initial phase of
RLHF involves learning human values using a reward model from ranking data. It
is observed that the performance of the reward model degrades after one epoch
of training, and optimizing too much against the learned reward model
eventually hinders the true objective. This paper delves into these issues,
leveraging the theoretical insights to design improved reward learning
algorithm termed 'Iterative Data Smoothing' (IDS). The core idea is that during
each training epoch, we not only update the model with the data, but also
update the date using the model, replacing hard labels with soft labels. Our
empirical findings highlight the superior performance of this approach over the
traditional methods.

---------------

### 04 Oct 2023 | [Reward Model Ensembles Help Mitigate Overoptimization](https://arxiv.org/abs/2310.02743) | [⬇️](https://arxiv.org/pdf/2310.02743)
*Thomas Coste, Usman Anwar, Robert Kirk, David Krueger* 

  Reinforcement learning from human feedback (RLHF) is a standard approach for
fine-tuning large language models to follow instructions. As part of this
process, learned reward models are used to approximately model human
preferences. However, as imperfect representations of the "true" reward, these
learned reward models are susceptible to \textit{overoptimization}. Gao et al.
(2023) studied this phenomenon in a synthetic human feedback setup with a
significantly larger "gold" reward model acting as the true reward (instead of
humans) and showed that overoptimization remains a persistent problem
regardless of the size of the proxy reward model and training data used. Using
a similar setup, we conduct a systematic study to evaluate the efficacy of
using ensemble-based conservative optimization objectives, specifically
worst-case optimization (WCO) and uncertainty-weighted optimization (UWO), for
mitigating reward model overoptimization when using two optimization methods:
(a) best-of-n sampling (BoN) (b) proximal policy optimization (PPO). We
additionally extend the setup of Gao et al. (2023) to include 25% label noise
to better mirror real-world conditions. Both with and without label noise, we
find that conservative optimization practically eliminates overoptimization and
improves performance by up to 70% for BoN sampling. For PPO, ensemble-based
conservative optimization always reduces overoptimization and outperforms
single reward model optimization. Moreover, combining it with a small KL
penalty successfully prevents overoptimization at no performance cost. Overall,
our results demonstrate that ensemble-based conservative optimization can
effectively counter overoptimization.

---------------

### 24 Jan 2024 | [A Baseline Analysis of Reward Models' Ability To Accurately Analyze  Foundation Models Under Distribution Shift](https://arxiv.org/abs/2311.14743) | [⬇️](https://arxiv.org/pdf/2311.14743)
*Will LeVine, Benjamin Pikus, Anthony Chen, Sean Hendryx* 

  Foundation models, specifically Large Language Models (LLMs), have lately
gained wide-spread attention and adoption. Reinforcement Learning with Human
Feedback (RLHF) involves training a reward model to capture desired behaviors,
which is then used to align LLM's. These reward models are additionally used at
inference-time to estimate LLM responses' adherence to those desired behaviors.
However, there is little work measuring how robust these reward models are to
distribution shifts. In this work, we evaluate how reward model performance -
measured via accuracy and calibration (i.e. alignment between accuracy and
confidence) - is affected by distribution shift. We show novel calibration
patterns and accuracy drops due to OOD prompts and responses, and that the
reward model is more sensitive to shifts in responses than prompts.
Additionally, we adapt an OOD detection technique commonly used in
classification to the reward model setting to detect these distribution shifts
in prompts and responses.

---------------

### 22 Jan 2024 | [West-of-N: Synthetic Preference Generation for Improved Reward Modeling](https://arxiv.org/abs/2401.12086) | [⬇️](https://arxiv.org/pdf/2401.12086)
*Aliz\'ee Pace, Jonathan Mallinson, Eric Malmi, Sebastian Krause,  Aliaksei Severyn* 

  The success of reinforcement learning from human feedback (RLHF) in language
model alignment is strongly dependent on the quality of the underlying reward
model. In this paper, we present a novel approach to improve reward model
quality by generating synthetic preference data, thereby augmenting the
training dataset with on-policy, high-quality preference pairs. Motivated by
the promising results of Best-of-N sampling strategies in language model
training, we extend their application to reward model training. This results in
a self-training strategy to generate preference pairs by selecting the best and
worst candidates in a pool of responses to a given query. Empirically, we find
that this approach improves the performance of any reward model, with an effect
comparable to the addition of a similar quantity of human preference data. This
work opens up new avenues of research for improving RLHF for language model
alignment, by offering synthetic preference generation as a solution to reward
modeling challenges.

---------------

### 15 Nov 2023 | [Aligning Neural Machine Translation Models: Human Feedback in Training  and Inference](https://arxiv.org/abs/2311.09132) | [⬇️](https://arxiv.org/pdf/2311.09132)
*Miguel Moura Ramos, Patrick Fernandes, Ant\'onio Farinhas, Andr\'e F.  T. Martins* 

  Reinforcement learning from human feedback (RLHF) is a recent technique to
improve the quality of the text generated by a language model, making it closer
to what humans would generate. A core ingredient in RLHF's success in aligning
and improving large language models (LLMs) is its reward model, trained using
human feedback on model outputs. In machine translation (MT), where metrics
trained from human annotations can readily be used as reward models, recent
methods using minimum Bayes risk decoding and reranking have succeeded in
improving the final quality of translation. In this study, we comprehensively
explore and compare techniques for integrating quality metrics as reward models
into the MT pipeline. This includes using the reward model for data filtering,
during the training phase through RL, and at inference time by employing
reranking techniques, and we assess the effects of combining these in a unified
approach. Our experimental results, conducted across multiple translation
tasks, underscore the crucial role of effective data filtering, based on
estimated quality, in harnessing the full potential of RL in enhancing MT
quality. Furthermore, our findings demonstrate the effectiveness of combining
RL training with reranking techniques, showcasing substantial improvements in
translation quality.

---------------

### 11 Feb 2024 | [Tool-Augmented Reward Modeling](https://arxiv.org/abs/2310.01045) | [⬇️](https://arxiv.org/pdf/2310.01045)
*Lei Li, Yekun Chai, Shuohuan Wang, Yu Sun, Hao Tian, Ningyu Zhang, Hua  Wu* 

  Reward modeling (a.k.a., preference modeling) is instrumental for aligning
large language models with human preferences, particularly within the context
of reinforcement learning from human feedback (RLHF). While conventional reward
models (RMs) have exhibited remarkable scalability, they oft struggle with
fundamental functionality such as arithmetic computation, code execution, and
factual lookup. In this paper, we propose a tool-augmented preference modeling
approach, named Themis, to address these limitations by empowering RMs with
access to external environments, including calculators and search engines. This
approach not only fosters synergy between tool utilization and reward grading
but also enhances interpretive capacity and scoring reliability. Our study
delves into the integration of external tools into RMs, enabling them to
interact with diverse external sources and construct task-specific tool
engagement and reasoning traces in an autoregressive manner. We validate our
approach across a wide range of domains, incorporating seven distinct external
tools. Our experimental results demonstrate a noteworthy overall improvement of
17.7% across eight tasks in preference ranking. Furthermore, our approach
outperforms Gopher 280B by 7.3% on TruthfulQA task in zero-shot evaluation. In
human evaluations, RLHF trained with Themis attains an average win rate of 32%
when compared to baselines across four distinct tasks. Additionally, we provide
a comprehensive collection of tool-related RM datasets, incorporating data from
seven distinct tool APIs, totaling 15,000 instances. We have made the code,
data, and model checkpoints publicly available to facilitate and inspire
further research
advancements\footnote{\url{https://github.com/ernie-research/Tool-Augmented-Reward-Model}}.

---------------

### 23 Feb 2024 | [Leveraging Domain Knowledge for Efficient Reward Modelling in RLHF: A  Case-Study in E-Commerce Opinion Summarization](https://arxiv.org/abs/2402.15473) | [⬇️](https://arxiv.org/pdf/2402.15473)
*Swaroop Nath, Tejpalsingh Siledar, Sankara Sri Raghava Ravindra Muddu,  Rupasai Rangaraju, Harshad Khadilkar, Pushpak Bhattacharyya, Suman Banerjee,  Amey Patil, Sudhanshu Shekhar Singh, Muthusamy Chelliah, Nikesh Garera* 

  Reinforcement Learning from Human Feedback (RLHF) has become a dominating
strategy in steering Language Models (LMs) towards human values/goals. The key
to the strategy is employing a reward model ({$\varphi$}) which can reflect a
latent reward model with humans. While this strategy has proven to be
effective, the training methodology requires a lot of human preference
annotation (usually of the order of tens of thousands) to train {$\varphi$}.
Such large-scale preference annotations can be achievable if the reward model
can be ubiquitously used. However, human values/goals are subjective and depend
on the nature of the task. This poses a challenge in collecting diverse
preferences for downstream applications. To address this, we propose a novel
methodology to infuse domain knowledge into {$\varphi$}, which reduces the size
of preference annotation required. We validate our approach in E-Commerce
Opinion Summarization, with a significant reduction in dataset size (just $940$
samples) while advancing the state-of-the-art. Our contributions include a
novel Reward Modelling technique, a new dataset (PromptOpinSumm) for Opinion
Summarization, and a human preference dataset (OpinPref). The proposed
methodology opens avenues for efficient RLHF, making it more adaptable to
diverse applications with varying human values. We release the artifacts for
usage under MIT License.

---------------

### 10 Aug 2023 | [Proximal Policy Optimization Actual Combat: Manipulating Output  Tokenizer Length](https://arxiv.org/abs/2308.05585) | [⬇️](https://arxiv.org/pdf/2308.05585)
*Miao Fan, Chen Hu, Shuchang Zhou* 

  The Reinforcement Learning from Human Feedback (RLHF) plays a pivotal role in
shaping the impact of large language models (LLMs), contributing significantly
to controlling output toxicity and selecting output styles, particularly as
LLMs often harbor misleading content, highlighting the urgency to align them
with human values for secure AI systems. The RLHF, characterized by complexity,
instability, and sensitivity to hyperparameters, makes the evaluation of the
reward model for complex tasks challenging, thereby further complicating the
use of Proximal Policy Optimization (PPO). In this paper, we introduce a simple
task designed to employ Gloden as a reward model that validates the
effectiveness of PPO and inspires it, primarily explaining the task of
utilizing PPO to manipulate the tokenizer length of the output generated by the
model. Experiments confirm that PPO is not only effective in manipulating the
output tokenizer length to a certain extent in this type of task but also
exhibits facilitated training once the influence of the reward model effect is
excluded, making it an exciting development.

---------------

### 02 Feb 2024 | [The Alignment Ceiling: Objective Mismatch in Reinforcement Learning from  Human Feedback](https://arxiv.org/abs/2311.00168) | [⬇️](https://arxiv.org/pdf/2311.00168)
*Nathan Lambert and Roberto Calandra* 

  Reinforcement learning from human feedback (RLHF) has emerged as a powerful
technique to make large language models (LLMs) more capable in complex
settings. RLHF proceeds as collecting human preference data, training a reward
model on said data, and optimizing a base ML model with respect to said reward
for extrinsic evaluation metrics (e.g. MMLU, GSM8k). RLHF relies on many
assumptions about how the various pieces fit together, such as a reward model
capturing human preferences and an RL optimizer extracting the right signal
from a reward model. As the RLHF process involves many distinct design
decisions, it is easy to assume that multiple processes are correlated and
therefore numerically linked. This apparent correlation is often not true,
where reward models are easily overoptimized or RL optimizers can reduce
performance on tasks not modeled in the data. Notable manifestations of models
trained with imperfect RLHF systems are those that are prone to refusing basic
requests for safety reasons or appearing lazy in generations. As chat model
evaluation becomes increasingly nuanced, the reliance on a perceived link
between reward model training, RL scores, and downstream performance drives
these issues, which we describe as an objective mismatch. In this paper, we
illustrate the causes of this issue, reviewing relevant literature from
model-based reinforcement learning, and argue for solutions. By solving
objective mismatch in RLHF, the ML models of the future will be more precisely
aligned to user instructions for both safety and helpfulness.

---------------

### 05 Oct 2023 | [A Long Way to Go: Investigating Length Correlations in RLHF](https://arxiv.org/abs/2310.03716) | [⬇️](https://arxiv.org/pdf/2310.03716)
*Prasann Singhal, Tanya Goyal, Jiacheng Xu, Greg Durrett* 

  Great successes have been reported using Reinforcement Learning from Human
Feedback (RLHF) to align large language models. Open-source preference datasets
and reward models have enabled wider experimentation beyond generic chat
settings, particularly to make systems more "helpful" for tasks like web
question answering, summarization, and multi-turn dialogue. When optimizing for
helpfulness, RLHF has been consistently observed to drive models to produce
longer outputs. This paper demonstrates that optimizing for response length is
a significant factor behind RLHF's reported improvements in these settings.
First, we study the relationship between reward and length for reward models
trained on three open-source preference datasets for helpfulness. Here, length
correlates strongly with reward, and improvements in reward score are driven in
large part by shifting the distribution over output lengths. We then explore
interventions during both RL and reward model learning to see if we can achieve
the same downstream improvements as RLHF without increasing length. While our
interventions mitigate length increases, they aren't uniformly effective across
settings. Furthermore, we find that even running RLHF with a reward based
solely on length can reproduce most of the downstream improvements over the
initial policy model, showing that reward models in these settings have a long
way to go.

---------------

### 19 May 2023 | [Shattering the Agent-Environment Interface for Fine-Tuning Inclusive  Language Models](https://arxiv.org/abs/2305.11455) | [⬇️](https://arxiv.org/pdf/2305.11455)
*Wanqiao Xu, Shi Dong, Dilip Arumugam, Benjamin Van Roy* 

  A centerpiece of the ever-popular reinforcement learning from human feedback
(RLHF) approach to fine-tuning autoregressive language models is the explicit
training of a reward model to emulate human feedback, distinct from the
language model itself. This reward model is then coupled with policy-gradient
methods to dramatically improve the alignment between language model outputs
and desired responses. In this work, we adopt a novel perspective wherein a
pre-trained language model is itself simultaneously a policy, reward function,
and transition function. An immediate consequence of this is that reward
learning and language model fine-tuning can be performed jointly and directly,
without requiring any further downstream policy optimization. While this
perspective does indeed break the traditional agent-environment interface, we
nevertheless maintain that there can be enormous statistical benefits afforded
by bringing to bear traditional algorithmic concepts from reinforcement
learning. Our experiments demonstrate one concrete instance of this through
efficient exploration based on the representation and resolution of epistemic
uncertainty. In order to illustrate these ideas in a transparent manner, we
restrict attention to a simple didactic data generating process and leave for
future work extension to systems of practical scale.

---------------

### 20 Feb 2024 | [Rethinking Information Structures in RLHF: Reward Generalization from a  Graph Theory Perspective](https://arxiv.org/abs/2402.10184) | [⬇️](https://arxiv.org/pdf/2402.10184)
*Tianyi Qiu, Fanzhi Zeng, Jiaming Ji, Dong Yan, Kaile Wang, Jiayi Zhou,  Han Yang, Josef Dai, Xuehai Pan, Yaodong Yang* 

  There is a trilemma in reinforcement learning from human feedback (RLHF): the
incompatibility between highly diverse contexts, low labeling cost, and
reliable alignment performance. Here we aim to mitigate such incompatibility
through the design of dataset information structures during reward modeling,
and meanwhile propose new, generalizable methods of analysis that have wider
applications, including potentially shedding light on goal misgeneralization.
Specifically, we first reexamine the RLHF process and propose a theoretical
framework portraying it as an autoencoding process over text distributions. Our
framework formalizes the RLHF objective of ensuring distributional consistency
between human preference and large language model (LLM) behavior. Based on this
framework, we introduce a new method to model generalization in the reward
modeling stage of RLHF, the induced Bayesian network (IBN). Drawing from random
graph theory and causal analysis, it enables empirically grounded derivation of
generalization error bounds, a key improvement over classical methods of
generalization analysis. An insight from our analysis is the superiority of the
tree-based information structure in reward modeling, compared to chain-based
baselines in conventional RLHF methods. We derive that in complex contexts with
limited data, the tree-based reward model (RM) induces up to $\Theta(\log
n/\log\log n)$ times less variance than chain-based RM where $n$ is the dataset
size. As validation, we demonstrate that on three NLP tasks, the tree-based RM
achieves 65% win rate on average against chain-based baselines. Looking ahead,
we hope to extend the IBN analysis to help understand the phenomenon of goal
misgeneralization.

---------------

### 06 Dec 2023 | [Nash Learning from Human Feedback](https://arxiv.org/abs/2312.00886) | [⬇️](https://arxiv.org/pdf/2312.00886)
*R\'emi Munos, Michal Valko, Daniele Calandriello, Mohammad Gheshlaghi  Azar, Mark Rowland, Zhaohan Daniel Guo, Yunhao Tang, Matthieu Geist, Thomas  Mesnard, Andrea Michi, Marco Selvi, Sertan Girgin, Nikola Momchev, Olivier  Bachem, Daniel J. Mankowitz, Doina Precup, Bilal Piot* 

  Reinforcement learning from human feedback (RLHF) has emerged as the main
paradigm for aligning large language models (LLMs) with human preferences.
Typically, RLHF involves the initial step of learning a reward model from human
feedback, often expressed as preferences between pairs of text generations
produced by a pre-trained LLM. Subsequently, the LLM's policy is fine-tuned by
optimizing it to maximize the reward model through a reinforcement learning
algorithm. However, an inherent limitation of current reward models is their
inability to fully represent the richness of human preferences and their
dependency on the sampling distribution.
  In this study, we introduce an alternative pipeline for the fine-tuning of
LLMs using pairwise human feedback. Our approach entails the initial learning
of a preference model, which is conditioned on two inputs given a prompt,
followed by the pursuit of a policy that consistently generates responses
preferred over those generated by any competing policy, thus defining the Nash
equilibrium of this preference model. We term this approach Nash learning from
human feedback (NLHF).
  In the context of a tabular policy representation, we present a novel
algorithmic solution, Nash-MD, founded on the principles of mirror descent.
This algorithm produces a sequence of policies, with the last iteration
converging to the regularized Nash equilibrium. Additionally, we explore
parametric representations of policies and introduce gradient descent
algorithms for deep-learning architectures. To demonstrate the effectiveness of
our approach, we present experimental results involving the fine-tuning of a
LLM for a text summarization task. We believe NLHF offers a compelling avenue
for preference learning and policy optimization with the potential of advancing
the field of aligning LLMs with human preferences.

---------------

### 07 Feb 2024 | [Beyond Training Objectives: Interpreting Reward Model Divergence in  Large Language Models](https://arxiv.org/abs/2310.08164) | [⬇️](https://arxiv.org/pdf/2310.08164)
*Luke Marks, Amir Abdullah, Clement Neo, Rauno Arike, Philip Torr, Fazl  Barez* 

  Large language models (LLMs) fine-tuned by reinforcement learning from human
feedback (RLHF) are becoming more widely deployed. We coin the term
$\textit{Implicit Reward Model}$ (IRM) to refer to the changes that occur to an
LLM during RLHF that result in high-reward generations. We interpret IRMs, and
measure their divergence from the RLHF reward model used in the fine-tuning
process that induced them. By fitting a linear function to an LLM's IRM, a
reward model with the same type signature as the RLHF reward model is
constructed, allowing for direct comparison. Additionally, we validate our
construction of the IRM through cross-comparison with classifications of
features generated by an LLM based on their relevance to the RLHF reward model.
Better comprehending IRMs can help minimize discrepencies between LLM behavior
and training objectives, which we believe to be an essential component of the
$\textit{safety}$ and $\textit{alignment}$ of LLMs.

---------------

### 28 Sep 2023 | [The Trickle-down Impact of Reward (In-)consistency on RLHF](https://arxiv.org/abs/2309.16155) | [⬇️](https://arxiv.org/pdf/2309.16155)
*Lingfeng Shen and Sihao Chen and Linfeng Song and Lifeng Jin and  Baolin Peng and Haitao Mi and Daniel Khashabi and Dong Yu* 

  Standard practice within Reinforcement Learning from Human Feedback (RLHF)
involves optimizing against a Reward Model (RM), which itself is trained to
reflect human preferences for desirable generations. A notable subject that is
understudied is the (in-)consistency of RMs -- whether they can recognize the
semantic changes to different prompts and appropriately adapt their reward
assignments -- and their impact on the downstream RLHF model.
  In this paper, we visit a series of research questions relevant to RM
inconsistency: (1) How can we measure the consistency of reward models? (2) How
consistent are the existing RMs and how can we improve them? (3) In what ways
does reward inconsistency influence the chatbots resulting from the RLHF model
training?
  We propose Contrast Instructions -- a benchmarking strategy for the
consistency of RM. Each example in Contrast Instructions features a pair of
lexically similar instructions with different ground truth responses. A
consistent RM is expected to rank the corresponding instruction and response
higher than other combinations. We observe that current RMs trained with the
standard ranking objective fail miserably on Contrast Instructions compared to
average humans. To show that RM consistency can be improved efficiently without
using extra training budget, we propose two techniques ConvexDA and
RewardFusion, which enhance reward consistency through extrapolation during the
RM training and inference stage, respectively. We show that RLHF models trained
with a more consistent RM yield more useful responses, suggesting that reward
inconsistency exhibits a trickle-down effect on the downstream RLHF process.

---------------

### 11 Feb 2024 | [A Theoretical Analysis of Nash Learning from Human Feedback under  General KL-Regularized Preference](https://arxiv.org/abs/2402.07314) | [⬇️](https://arxiv.org/pdf/2402.07314)
*Chenlu Ye, Wei Xiong, Yuheng Zhang, Nan Jiang, Tong Zhang* 

  Reinforcement Learning from Human Feedback (RLHF) learns from the preference
signal provided by a probabilistic preference model, which takes a prompt and
two responses as input, and produces a score indicating the preference of one
response against another. So far, the most popular RLHF paradigm is
reward-based, which starts with an initial step of reward modeling, and the
constructed reward is then used to provide a reward signal for the subsequent
reward optimization stage. However, the existence of a reward function is a
strong assumption and the reward-based RLHF is limited in expressivity and
cannot capture the real-world complicated human preference.
  In this work, we provide theoretical insights for a recently proposed
learning paradigm, Nash learning from human feedback (NLHF), which considered a
general preference model and formulated the alignment process as a game between
two competitive LLMs. The learning objective is to find a policy that
consistently generates responses preferred over any competing policy while
staying close to the initial model. The objective is defined as the Nash
equilibrium (NE) of the KL-regularized preference model. We aim to make the
first attempt to study the theoretical learnability of the KL-regularized NLHF
by considering both offline and online settings. For the offline learning from
a pre-collected dataset, we propose algorithms that are efficient under
suitable coverage conditions of the dataset. For batch online learning from
iterative interactions with a preference oracle, our proposed algorithm enjoys
a finite sample guarantee under the structural condition of the underlying
preference model. Our results connect the new NLHF paradigm with traditional RL
theory, and validate the potential of reward-model-free learning under general
preference.

---------------

### 25 Oct 2023 | [SuperHF: Supervised Iterative Learning from Human Feedback](https://arxiv.org/abs/2310.16763) | [⬇️](https://arxiv.org/pdf/2310.16763)
*Gabriel Mukobi, Peter Chatain, Su Fong, Robert Windesheim, Gitta  Kutyniok, Kush Bhatia, Silas Alberti* 

  While large language models demonstrate remarkable capabilities, they often
present challenges in terms of safety, alignment with human values, and
stability during training. Here, we focus on two prevalent methods used to
align these models, Supervised Fine-Tuning (SFT) and Reinforcement Learning
from Human Feedback (RLHF). SFT is simple and robust, powering a host of
open-source models, while RLHF is a more sophisticated method used in top-tier
models like ChatGPT but also suffers from instability and susceptibility to
reward hacking. We propose a novel approach, Supervised Iterative Learning from
Human Feedback (SuperHF), which seeks to leverage the strengths of both
methods. Our hypothesis is two-fold: that the reward model used in RLHF is
critical for efficient data use and model generalization and that the use of
Proximal Policy Optimization (PPO) in RLHF may not be necessary and could
contribute to instability issues. SuperHF replaces PPO with a simple supervised
loss and a Kullback-Leibler (KL) divergence prior. It creates its own training
data by repeatedly sampling a batch of model outputs and filtering them through
the reward model in an online learning regime. We then break down the reward
optimization problem into three components: robustly optimizing the training
rewards themselves, preventing reward hacking-exploitation of the reward model
that degrades model performance-as measured by a novel METEOR similarity
metric, and maintaining good performance on downstream evaluations. Our
experimental results show SuperHF exceeds PPO-based RLHF on the training
objective, easily and favorably trades off high reward with low reward hacking,
improves downstream calibration, and performs the same on our GPT-4 based
qualitative evaluation scheme all the while being significantly simpler to
implement, highlighting SuperHF's potential as a competitive language model
alignment technique.

---------------

### 06 Sep 2023 | [Deep Reinforcement Learning from Hierarchical Weak Preference Feedback](https://arxiv.org/abs/2309.02632) | [⬇️](https://arxiv.org/pdf/2309.02632)
*Alexander Bukharin, Yixiao Li, Pengcheng He, Weizhu Chen, Tuo Zhao* 

  Reward design is a fundamental, yet challenging aspect of practical
reinforcement learning (RL). For simple tasks, researchers typically handcraft
the reward function, e.g., using a linear combination of several reward
factors. However, such reward engineering is subject to approximation bias,
incurs large tuning cost, and often cannot provide the granularity required for
complex tasks. To avoid these difficulties, researchers have turned to
reinforcement learning from human feedback (RLHF), which learns a reward
function from human preferences between pairs of trajectory sequences. By
leveraging preference-based reward modeling, RLHF learns complex rewards that
are well aligned with human preferences, allowing RL to tackle increasingly
difficult problems. Unfortunately, the applicability of RLHF is limited due to
the high cost and difficulty of obtaining human preference data. In light of
this cost, we investigate learning reward functions for complex tasks with less
human effort; simply by ranking the importance of the reward factors. More
specifically, we propose a new RL framework -- HERON, which compares
trajectories using a hierarchical decision tree induced by the given ranking.
These comparisons are used to train a preference-based reward model, which is
then used for policy learning. We find that our framework can not only train
high performing agents on a variety of difficult tasks, but also provide
additional benefits such as improved sample efficiency and robustness. Our code
is available at https://github.com/abukharin3/HERON.

---------------
**Date:** 12 Jan 2024

**Title:** Secrets of RLHF in Large Language Models Part II: Reward Modeling

**Abstract Link:** [https://arxiv.org/abs/2401.06080](https://arxiv.org/abs/2401.06080)

**PDF Link:** [https://arxiv.org/pdf/2401.06080](https://arxiv.org/pdf/2401.06080)

---

**Date:** 30 Jan 2024

**Title:** Improving Reinforcement Learning from Human Feedback with Efficient  Reward Model Ensemble

**Abstract Link:** [https://arxiv.org/abs/2401.16635](https://arxiv.org/abs/2401.16635)

**PDF Link:** [https://arxiv.org/pdf/2401.16635](https://arxiv.org/pdf/2401.16635)

---

**Date:** 29 Jan 2024

**Title:** Iterative Data Smoothing: Mitigating Reward Overfitting and  Overoptimization in RLHF

**Abstract Link:** [https://arxiv.org/abs/2401.16335](https://arxiv.org/abs/2401.16335)

**PDF Link:** [https://arxiv.org/pdf/2401.16335](https://arxiv.org/pdf/2401.16335)

---

**Date:** 04 Oct 2023

**Title:** Reward Model Ensembles Help Mitigate Overoptimization

**Abstract Link:** [https://arxiv.org/abs/2310.02743](https://arxiv.org/abs/2310.02743)

**PDF Link:** [https://arxiv.org/pdf/2310.02743](https://arxiv.org/pdf/2310.02743)

---

**Date:** 24 Jan 2024

**Title:** A Baseline Analysis of Reward Models' Ability To Accurately Analyze  Foundation Models Under Distribution Shift

**Abstract Link:** [https://arxiv.org/abs/2311.14743](https://arxiv.org/abs/2311.14743)

**PDF Link:** [https://arxiv.org/pdf/2311.14743](https://arxiv.org/pdf/2311.14743)

---

**Date:** 22 Jan 2024

**Title:** West-of-N: Synthetic Preference Generation for Improved Reward Modeling

**Abstract Link:** [https://arxiv.org/abs/2401.12086](https://arxiv.org/abs/2401.12086)

**PDF Link:** [https://arxiv.org/pdf/2401.12086](https://arxiv.org/pdf/2401.12086)

---

**Date:** 15 Nov 2023

**Title:** Aligning Neural Machine Translation Models: Human Feedback in Training  and Inference

**Abstract Link:** [https://arxiv.org/abs/2311.09132](https://arxiv.org/abs/2311.09132)

**PDF Link:** [https://arxiv.org/pdf/2311.09132](https://arxiv.org/pdf/2311.09132)

---

**Date:** 11 Feb 2024

**Title:** Tool-Augmented Reward Modeling

**Abstract Link:** [https://arxiv.org/abs/2310.01045](https://arxiv.org/abs/2310.01045)

**PDF Link:** [https://arxiv.org/pdf/2310.01045](https://arxiv.org/pdf/2310.01045)

---

**Date:** 23 Feb 2024

**Title:** Leveraging Domain Knowledge for Efficient Reward Modelling in RLHF: A  Case-Study in E-Commerce Opinion Summarization

**Abstract Link:** [https://arxiv.org/abs/2402.15473](https://arxiv.org/abs/2402.15473)

**PDF Link:** [https://arxiv.org/pdf/2402.15473](https://arxiv.org/pdf/2402.15473)

---

**Date:** 10 Aug 2023

**Title:** Proximal Policy Optimization Actual Combat: Manipulating Output  Tokenizer Length

**Abstract Link:** [https://arxiv.org/abs/2308.05585](https://arxiv.org/abs/2308.05585)

**PDF Link:** [https://arxiv.org/pdf/2308.05585](https://arxiv.org/pdf/2308.05585)

---

**Date:** 02 Feb 2024

**Title:** The Alignment Ceiling: Objective Mismatch in Reinforcement Learning from  Human Feedback

**Abstract Link:** [https://arxiv.org/abs/2311.00168](https://arxiv.org/abs/2311.00168)

**PDF Link:** [https://arxiv.org/pdf/2311.00168](https://arxiv.org/pdf/2311.00168)

---

**Date:** 05 Oct 2023

**Title:** A Long Way to Go: Investigating Length Correlations in RLHF

**Abstract Link:** [https://arxiv.org/abs/2310.03716](https://arxiv.org/abs/2310.03716)

**PDF Link:** [https://arxiv.org/pdf/2310.03716](https://arxiv.org/pdf/2310.03716)

---

**Date:** 19 May 2023

**Title:** Shattering the Agent-Environment Interface for Fine-Tuning Inclusive  Language Models

**Abstract Link:** [https://arxiv.org/abs/2305.11455](https://arxiv.org/abs/2305.11455)

**PDF Link:** [https://arxiv.org/pdf/2305.11455](https://arxiv.org/pdf/2305.11455)

---

**Date:** 20 Feb 2024

**Title:** Rethinking Information Structures in RLHF: Reward Generalization from a  Graph Theory Perspective

**Abstract Link:** [https://arxiv.org/abs/2402.10184](https://arxiv.org/abs/2402.10184)

**PDF Link:** [https://arxiv.org/pdf/2402.10184](https://arxiv.org/pdf/2402.10184)

---

**Date:** 06 Dec 2023

**Title:** Nash Learning from Human Feedback

**Abstract Link:** [https://arxiv.org/abs/2312.00886](https://arxiv.org/abs/2312.00886)

**PDF Link:** [https://arxiv.org/pdf/2312.00886](https://arxiv.org/pdf/2312.00886)

---

**Date:** 07 Feb 2024

**Title:** Beyond Training Objectives: Interpreting Reward Model Divergence in  Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.08164](https://arxiv.org/abs/2310.08164)

**PDF Link:** [https://arxiv.org/pdf/2310.08164](https://arxiv.org/pdf/2310.08164)

---

**Date:** 28 Sep 2023

**Title:** The Trickle-down Impact of Reward (In-)consistency on RLHF

**Abstract Link:** [https://arxiv.org/abs/2309.16155](https://arxiv.org/abs/2309.16155)

**PDF Link:** [https://arxiv.org/pdf/2309.16155](https://arxiv.org/pdf/2309.16155)

---

**Date:** 11 Feb 2024

**Title:** A Theoretical Analysis of Nash Learning from Human Feedback under  General KL-Regularized Preference

**Abstract Link:** [https://arxiv.org/abs/2402.07314](https://arxiv.org/abs/2402.07314)

**PDF Link:** [https://arxiv.org/pdf/2402.07314](https://arxiv.org/pdf/2402.07314)

---

**Date:** 25 Oct 2023

**Title:** SuperHF: Supervised Iterative Learning from Human Feedback

**Abstract Link:** [https://arxiv.org/abs/2310.16763](https://arxiv.org/abs/2310.16763)

**PDF Link:** [https://arxiv.org/pdf/2310.16763](https://arxiv.org/pdf/2310.16763)

---

**Date:** 06 Sep 2023

**Title:** Deep Reinforcement Learning from Hierarchical Weak Preference Feedback

**Abstract Link:** [https://arxiv.org/abs/2309.02632](https://arxiv.org/abs/2309.02632)

**PDF Link:** [https://arxiv.org/pdf/2309.02632](https://arxiv.org/pdf/2309.02632)

---

