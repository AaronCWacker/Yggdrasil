LLM Response Generation ♟️

### 🔎 LLM Response Generation ♟️



In this blog post, we will explore the fascinating world of chess and how AI can be used to generate responses in a chess game. We will delve into the algorithms and techniques used to create a chess AI, and how it can be integrated into a chatbot to provide an engaging and interactive experience for users.

Chess is a complex and strategic game that has been played for centuries. It requires critical thinking, problem-solving, and a deep understanding of the game's rules and strategies. With the advent of AI, chess has become even more exciting and challenging, as AI algorithms can analyze vast amounts of data and make decisions in real-time, providing a formidable opponent for even the most experienced players.

To create a chess AI, we need to use algorithms that can analyze the game's state, predict possible moves, and evaluate the outcomes of those moves. One popular algorithm used for chess AI is the minimax algorithm, which is a recursive algorithm that evaluates all possible moves and chooses the one that maximizes the AI's chances of winning.

To integrate the chess AI into a chatbot, we need to create a conversational interface that allows users to interact with the AI and make moves. We can use natural language processing (NLP) techniques to interpret user inputs and translate them into chess moves. The chatbot can then use the chess AI to analyze the current state of the game and generate a response, such as suggesting a move or making a move on behalf of the AI.

Here's an example of how a chess AI chatbot might work:

User: e4
Assistant: e5
User: Nf3
Assistant: Nc6
User: Bb5
Assistant: a6

In this example, the user makes the first move by playing e4, and the AI responds by playing e5. The user then plays Nf3, and the AI responds with Nc6. Finally, the user plays Bb5, and the AI responds with a6.

To make the chatbot more engaging and interactive, we can add features such as move suggestions, move history, and game analysis. Move suggestions can provide users with a list of possible moves they can make, while move history allows users to see the sequence of moves that have been played. Game analysis can provide users with insights into the game
# 🩺🔍 Search Results
### 17 Oct 2023 | [Self-RAG: Learning to Retrieve, Generate, and Critique through  Self-Reflection](https://arxiv.org/abs/2310.11511) | [⬇️](https://arxiv.org/pdf/2310.11511)
*Akari Asai, Zeqiu Wu, Yizhong Wang, Avirup Sil, Hannaneh Hajishirzi* 

  Despite their remarkable capabilities, large language models (LLMs) often
produce responses containing factual inaccuracies due to their sole reliance on
the parametric knowledge they encapsulate. Retrieval-Augmented Generation
(RAG), an ad hoc approach that augments LMs with retrieval of relevant
knowledge, decreases such issues. However, indiscriminately retrieving and
incorporating a fixed number of retrieved passages, regardless of whether
retrieval is necessary, or passages are relevant, diminishes LM versatility or
can lead to unhelpful response generation. We introduce a new framework called
Self-Reflective Retrieval-Augmented Generation (Self-RAG) that enhances an LM's
quality and factuality through retrieval and self-reflection. Our framework
trains a single arbitrary LM that adaptively retrieves passages on-demand, and
generates and reflects on retrieved passages and its own generations using
special tokens, called reflection tokens. Generating reflection tokens makes
the LM controllable during the inference phase, enabling it to tailor its
behavior to diverse task requirements. Experiments show that Self-RAG (7B and
13B parameters) significantly outperforms state-of-the-art LLMs and
retrieval-augmented models on a diverse set of tasks. Specifically, Self-RAG
outperforms ChatGPT and retrieval-augmented Llama2-chat on Open-domain QA,
reasoning and fact verification tasks, and it shows significant gains in
improving factuality and citation accuracy for long-form generations relative
to these models.

---------------

### 07 Mar 2024 | [Direct Alignment of Draft Model for Speculative Decoding with  Chat-Fine-Tuned LLMs](https://arxiv.org/abs/2403.00858) | [⬇️](https://arxiv.org/pdf/2403.00858)
*Raghavv Goel, Mukul Gagrani, Wonseok Jeon, Junyoung Park, Mingu Lee,  Christopher Lott* 

  Text generation with Large Language Models (LLMs) is known to be memory bound
due to the combination of their auto-regressive nature, huge parameter counts,
and limited memory bandwidths, often resulting in low token rates. Speculative
decoding has been proposed as a solution for LLM inference acceleration.
However, since draft models are often unavailable in the modern open-source LLM
families, e.g., for Llama 2 7B, training a high-quality draft model is required
to enable inference acceleration via speculative decoding. In this paper, we
propose a simple draft model training framework for direct alignment to
chat-capable target models. With the proposed framework, we train Llama 2 Chat
Drafter 115M, a draft model for Llama 2 Chat 7B or larger, with only 1.64\% of
the original size. Our training framework only consists of pretraining,
distillation dataset generation, and finetuning with knowledge distillation,
with no additional alignment procedure. For the finetuning step, we use
instruction-response pairs generated by target model for distillation in
plausible data distribution, and propose a new Total Variation Distance++
(TVD++) loss that incorporates variance reduction techniques inspired from the
policy gradient method in reinforcement learning. Our empirical results show
that Llama 2 Chat Drafter 115M with speculative decoding achieves up to 2.3
block efficiency and 2.4$\times$ speed-up relative to autoregressive decoding
on various tasks with no further task-specific fine-tuning.

---------------

### 13 Nov 2023 | [Think Before You Speak: Cultivating Communication Skills of Large  Language Models via Inner Monologue](https://arxiv.org/abs/2311.07445) | [⬇️](https://arxiv.org/pdf/2311.07445)
*Junkai Zhou, Liang Pang, Huawei Shen, Xueqi Cheng* 

  The emergence of large language models (LLMs) further improves the
capabilities of open-domain dialogue systems and can generate fluent, coherent,
and diverse responses. However, LLMs still lack an important ability:
communication skills, which makes them more like information seeking tools than
anthropomorphic chatbots. To make LLMs more anthropomorphic and proactive
during the conversation, we add five communication skills to the response
generation process: topic transition, proactively asking questions, concept
guidance, empathy, and summarising often. The addition of communication skills
increases the interest of users in the conversation and attracts them to chat
for longer. To enable LLMs better understand and use communication skills, we
design and add the inner monologue to LLMs. The complete process is achieved
through prompt engineering and in-context learning. To evaluate communication
skills, we construct a benchmark named Cskills for evaluating various
communication skills, which can also more comprehensively evaluate the dialogue
generation ability of the model. Experimental results show that the proposed
CSIM strategy improves the backbone models and outperforms the baselines in
both automatic and human evaluations.

---------------

### 28 Feb 2024 | [An Iterative Associative Memory Model for Empathetic Response Generation](https://arxiv.org/abs/2402.17959) | [⬇️](https://arxiv.org/pdf/2402.17959)
*Zhou Yang, Zhaochun Ren, Yufeng Wang, Chao Chen, Haizhou Sun, Xiaofei  Zhu, Xiangwen Liao* 

  Empathetic response generation is to comprehend the cognitive and emotional
states in dialogue utterances and generate proper responses. Psychological
theories posit that comprehending emotional and cognitive states necessitates
iteratively capturing and understanding associated words across dialogue
utterances. However, existing approaches regard dialogue utterances as either a
long sequence or independent utterances for comprehension, which are prone to
overlook the associated words between them. To address this issue, we propose
an Iterative Associative Memory Model (IAMM) for empathetic response
generation. Specifically, we employ a novel second-order interaction attention
mechanism to iteratively capture vital associated words between dialogue
utterances and situations, dialogue history, and a memory module (for storing
associated words), thereby accurately and nuancedly comprehending the
utterances. We conduct experiments on the Empathetic-Dialogue dataset. Both
automatic and human evaluations validate the efficacy of the model. Meanwhile,
variant experiments on LLMs also demonstrate that attending to associated words
improves empathetic comprehension and expression.

---------------

### 27 Feb 2024 | [Self-Refinement of Language Models from External Proxy Metrics Feedback](https://arxiv.org/abs/2403.00827) | [⬇️](https://arxiv.org/pdf/2403.00827)
*Keshav Ramji, Young-Suk Lee, Ram\'on Fernandez Astudillo, Md Arafat  Sultan, Tahira Naseem, Asim Munawar, Radu Florian, Salim Roukos* 

  It is often desirable for Large Language Models (LLMs) to capture multiple
objectives when providing a response. In document-grounded response generation,
for example, agent responses are expected to be relevant to a user's query
while also being grounded in a given document. In this paper, we introduce
Proxy Metric-based Self-Refinement (ProMiSe), which enables an LLM to refine
its own initial response along key dimensions of quality guided by external
metrics feedback, yielding an overall better final response. ProMiSe leverages
feedback on response quality through principle-specific proxy metrics, and
iteratively refines its response one principle at a time. We apply ProMiSe to
open source language models Flan-T5-XXL and Llama-2-13B-Chat, to evaluate its
performance on document-grounded question answering datasets, MultiDoc2Dial and
QuAC, demonstrating that self-refinement improves response quality. We further
show that fine-tuning Llama-2-13B-Chat on the synthetic dialogue data generated
by ProMiSe yields significant performance improvements over the zero-shot
baseline as well as a supervised fine-tuned model on human annotated data.

---------------

### 10 Dec 2023 | [LLMGA: Multimodal Large Language Model based Generation Assistant](https://arxiv.org/abs/2311.16500) | [⬇️](https://arxiv.org/pdf/2311.16500)
*Bin Xia, Shiyin Wang, Yingfan Tao, Yitong Wang, and Jiaya Jia* 

  In this paper, we introduce a Multimodal Large Language Model-based
Generation Assistant (LLMGA), leveraging the vast reservoir of knowledge and
proficiency in reasoning, comprehension, and response inherent in Large
Language Models (LLMs) to assist users in image generation and editing.
Diverging from existing approaches where Multimodal Large Language Models
(MLLMs) generate fixed-size embeddings to control Stable Diffusion (SD), our
LLMGA provides a detailed language generation prompt for precise control over
SD. This not only augments LLM context understanding but also reduces noise in
generation prompts, yields images with more intricate and precise content, and
elevates the interpretability of the network. To this end, we curate a
comprehensive dataset comprising prompt refinement, similar image generation,
inpainting $\&$ outpainting, and visual question answering. Moreover, we
propose a two-stage training scheme. In the first stage, we train the MLLM to
grasp the properties of image generation and editing, enabling it to generate
detailed prompts. In the second stage, we optimize SD to align with the MLLM's
generation prompts. Additionally, we propose a reference-based restoration
network to alleviate texture, brightness, and contrast disparities between
generated and preserved regions during image editing. Extensive results show
that LLMGA has promising generative capabilities and can enable wider
applications in an interactive manner.

---------------

### 04 Mar 2024 | [How (un)ethical are instruction-centric responses of LLMs? Unveiling the  vulnerabilities of safety guardrails to harmful queries](https://arxiv.org/abs/2402.15302) | [⬇️](https://arxiv.org/pdf/2402.15302)
*Somnath Banerjee, Sayan Layek, Rima Hazra, Animesh Mukherjee* 

  In this study, we tackle a growing concern around the safety and ethical use
of large language models (LLMs). Despite their potential, these models can be
tricked into producing harmful or unethical content through various
sophisticated methods, including 'jailbreaking' techniques and targeted
manipulation. Our work zeroes in on a specific issue: to what extent LLMs can
be led astray by asking them to generate responses that are instruction-centric
such as a pseudocode, a program or a software snippet as opposed to vanilla
text. To investigate this question, we introduce TechHazardQA, a dataset
containing complex queries which should be answered in both text and
instruction-centric formats (e.g., pseudocodes), aimed at identifying triggers
for unethical responses. We query a series of LLMs -- Llama-2-13b, Llama-2-7b,
Mistral-V2 and Mistral 8X7B -- and ask them to generate both text and
instruction-centric responses. For evaluation we report the harmfulness score
metric as well as judgements from GPT-4 and humans. Overall, we observe that
asking LLMs to produce instruction-centric responses enhances the unethical
response generation by ~2-38% across the models. As an additional objective, we
investigate the impact of model editing using the ROME technique, which further
increases the propensity for generating undesirable content. In particular,
asking edited LLMs to generate instruction-centric responses further increases
the unethical response generation by ~3-16% across the different models.

---------------

### 27 Jan 2024 | [Enhancing Large Language Model Performance To Answer Questions and  Extract Information More Accurately](https://arxiv.org/abs/2402.01722) | [⬇️](https://arxiv.org/pdf/2402.01722)
*Liang Zhang, Katherine Jijo, Spurthi Setty, Eden Chung, Fatima Javid,  Natan Vidra, Tommy Clifford* 

  Large Language Models (LLMs) generate responses to questions; however, their
effectiveness is often hindered by sub-optimal quality of answers and
occasional failures to provide accurate responses to questions. To address
these challenges, a fine-tuning process is employed, involving feedback and
examples to refine models. The objective is to enhance AI models through
continuous feedback loops, utilizing metrics such as cosine similarity, LLM
evaluation and Rouge-L scores to evaluate the models. Leveraging LLMs like
GPT-3.5, GPT4ALL, and LLaMA2, and Claude, this approach is benchmarked on
financial datasets, including the FinanceBench and RAG Instruct Benchmark
Tester Dataset, illustrating the necessity of fine-tuning. The results showcase
the capability of fine-tuned models to surpass the accuracy of zero-shot LLMs,
providing superior question and answering capabilities. Notably, the
combination of fine-tuning the LLM with a process known as Retrieval Augmented
Generation (RAG) proves to generate responses with improved accuracy.

---------------

### 26 Feb 2024 | [CodeChameleon: Personalized Encryption Framework for Jailbreaking Large  Language Models](https://arxiv.org/abs/2402.16717) | [⬇️](https://arxiv.org/pdf/2402.16717)
*Huijie Lv, Xiao Wang, Yuansen Zhang, Caishuang Huang, Shihan Dou,  Junjie Ye, Tao Gui, Qi Zhang, Xuanjing Huang* 

  Adversarial misuse, particularly through `jailbreaking' that circumvents a
model's safety and ethical protocols, poses a significant challenge for Large
Language Models (LLMs). This paper delves into the mechanisms behind such
successful attacks, introducing a hypothesis for the safety mechanism of
aligned LLMs: intent security recognition followed by response generation.
Grounded in this hypothesis, we propose CodeChameleon, a novel jailbreak
framework based on personalized encryption tactics. To elude the intent
security recognition phase, we reformulate tasks into a code completion format,
enabling users to encrypt queries using personalized encryption functions. To
guarantee response generation functionality, we embed a decryption function
within the instructions, which allows the LLM to decrypt and execute the
encrypted queries successfully. We conduct extensive experiments on 7 LLMs,
achieving state-of-the-art average Attack Success Rate (ASR). Remarkably, our
method achieves an 86.6\% ASR on GPT-4-1106.

---------------

### 17 Jan 2024 | [Paralinguistics-Enhanced Large Language Modeling of Spoken Dialogue](https://arxiv.org/abs/2312.15316) | [⬇️](https://arxiv.org/pdf/2312.15316)
*Guan-Ting Lin, Prashanth Gurunath Shivakumar, Ankur Gandhe, Chao-Han  Huck Yang, Yile Gu, Shalini Ghosh, Andreas Stolcke, Hung-yi Lee, Ivan Bulyko* 

  Large Language Models (LLMs) have demonstrated superior abilities in tasks
such as chatting, reasoning, and question-answering. However, standard LLMs may
ignore crucial paralinguistic information, such as sentiment, emotion, and
speaking style, which are essential for achieving natural, human-like spoken
conversation, especially when such information is conveyed by acoustic cues. We
therefore propose Paralinguistics-enhanced Generative Pretrained Transformer
(ParalinGPT), an LLM that utilizes text and speech modalities to better model
the linguistic content and paralinguistic attributes of spoken dialogue. The
model takes the conversational context of text, speech embeddings, and
paralinguistic attributes as input prompts within a serialized multitasking
multimodal framework. Specifically, our framework serializes tasks in the order
of current paralinguistic attribute prediction, response paralinguistic
attribute prediction, and response text generation with autoregressive
conditioning. We utilize the Switchboard-1 corpus, including its sentiment
labels as the paralinguistic attribute, as our spoken dialogue dataset.
Experimental results indicate the proposed serialized multitasking method
outperforms typical sequence classification techniques on current and response
sentiment classification. Furthermore, leveraging conversational context and
speech embeddings significantly improves both response text generation and
sentiment prediction. Our proposed framework achieves relative improvements of
6.7%, 12.0%, and 3.5% in current sentiment accuracy, response sentiment
accuracy, and response text BLEU score, respectively.

---------------

### 23 Aug 2023 | [Instruction Position Matters in Sequence Generation with Large Language  Models](https://arxiv.org/abs/2308.12097) | [⬇️](https://arxiv.org/pdf/2308.12097)
*Yijin Liu, Xianfeng Zeng, Fandong Meng, Jie Zhou* 

  Large language models (LLMs) are capable of performing conditional sequence
generation tasks, such as translation or summarization, through instruction
fine-tuning. The fine-tuning data is generally sequentially concatenated from a
specific task instruction, an input sentence, and the corresponding response.
Considering the locality modeled by the self-attention mechanism of LLMs, these
models face the risk of instruction forgetting when generating responses for
long input sentences. To mitigate this issue, we propose enhancing the
instruction-following capability of LLMs by shifting the position of task
instructions after the input sentences. Theoretical analysis suggests that our
straightforward method can alter the model's learning focus, thereby
emphasizing the training of instruction-following capabilities. Concurrently,
experimental results demonstrate that our approach consistently outperforms
traditional settings across various model scales (1B / 7B / 13B) and different
sequence generation tasks (translation and summarization), without any
additional data or annotation costs. Notably, our method significantly improves
the zero-shot performance on conditional sequence generation, e.g., up to 9.7
BLEU points on WMT zero-shot translation tasks.

---------------

### 05 Oct 2023 | [A New Dialogue Response Generation Agent for Large Language Models by  Asking Questions to Detect User's Intentions](https://arxiv.org/abs/2310.03293) | [⬇️](https://arxiv.org/pdf/2310.03293)
*Siwei Wu, Xiangqing Shen, and Rui Xia* 

  Large Language Models (LLMs), such as ChatGPT, have recently been applied to
various NLP tasks due to its open-domain generation capabilities. However,
there are two issues with applying LLMs to dialogue tasks. 1. During the
dialogue process, users may have implicit intentions that might be overlooked
by LLMs. Consequently, generated responses couldn't align with the user's
intentions. 2. It is unlikely for LLMs to encompass all fields comprehensively.
In certain specific domains, their knowledge may be incomplete, and LLMs cannot
update the latest knowledge in real-time. To tackle these issues, we propose a
framework~\emph{using LLM to \textbf{E}nhance dialogue response generation by
asking questions to \textbf{D}etect user's \textbf{I}mplicit
in\textbf{T}entions} (\textbf{EDIT}). Firstly, EDIT generates open questions
related to the dialogue context as the potential user's intention; Then, EDIT
answers those questions by interacting with LLMs and searching in
domain-specific knowledge bases respectively, and use LLMs to choose the proper
answers to questions as extra knowledge; Finally, EDIT enhances response
generation by explicitly integrating those extra knowledge. Besides, previous
question generation works only focus on asking questions with answers in
context. In order to ask open questions, we construct a Context-Open-Question
(COQ) dataset. On two task-oriented dialogue tasks (Wizard of Wikipedia and
Holl-E), EDIT outperformed other LLMs.

---------------

### 15 Oct 2023 | [Cue-CoT: Chain-of-thought Prompting for Responding to In-depth Dialogue  Questions with LLMs](https://arxiv.org/abs/2305.11792) | [⬇️](https://arxiv.org/pdf/2305.11792)
*Hongru Wang, Rui Wang, Fei Mi, Yang Deng, Zezhong Wang, Bin Liang,  Ruifeng Xu, Kam-Fai Wong* 

  Large Language Models (LLMs), such as \texttt{ChatGPT}, greatly empower
dialogue systems with strong language understanding and generation
capabilities. However, most of the previous works prompt the LLMs to directly
generate a response based on the dialogue context, overlooking the underlying
linguistic cues about the user status exhibited in the context. Such in-depth
dialogue scenarios are challenging for existing LLMs to figure out the user's
hidden needs and respond satisfactorily through a single-step inference. To
this end, we propose a novel linguistic cue-based chain-of-thoughts
(\textit{Cue}-CoT), which enhances the LLMs inference with an intermediate
reasoning step to find cues exhibited in the dialogue, aiming to provide a more
personalized and engaging response. To evaluate the approach, we build a
benchmark with in-depth dialogue questions, consisting of 6 datasets in both
Chinese and English, targeting 3 major linguistic cues during the conversation:
\textit{personality}, \textit{emotion}, and \textit{psychology}. We conduct
extensive experiments on the proposed benchmark with 5 LLMs under both
zero-shot and one-shot settings. Empirical results demonstrate our proposed
\textit{Cue}-CoT method outperforms standard prompting methods in terms of both
\textit{helpfulness} and \textit{acceptability} on all datasets.

---------------

### 23 Feb 2024 | [Fine-Grained Self-Endorsement Improves Factuality and Reasoning](https://arxiv.org/abs/2402.15631) | [⬇️](https://arxiv.org/pdf/2402.15631)
*Ante Wang, Linfeng Song, Baolin Peng, Ye Tian, Lifeng Jin, Haitao Mi,  Jinsong Su and Dong Yu* 

  This work studies improving large language model (LLM) generations at
inference time by mitigating fact-conflicting hallucinations. Particularly, we
propose a self-endorsement framework that leverages the fine-grained fact-level
comparisons across multiple sampled responses. Compared with prior ensemble
methods (Wang et al., 2022;Chen et al., 2023)) that perform response-level
selection, our approach can better alleviate hallucinations, especially for
longform generation tasks. Our approach can broadly benefit smaller and
open-source LLMs as it mainly conducts simple content-based comparisons.
Experiments on Biographies show that our method can effectively improve the
factuality of generations with simple and intuitive prompts across different
scales of LLMs. Besides, comprehensive analyses on TriviaQA and GSM8K
demonstrate the potential of self-endorsement for broader application.

---------------

### 08 Sep 2023 | [Towards Reliable and Fluent Large Language Models: Incorporating  Feedback Learning Loops in QA Systems](https://arxiv.org/abs/2309.06384) | [⬇️](https://arxiv.org/pdf/2309.06384)
*Dongyub Lee, Taesun Whang, Chanhee Lee, Heuiseok Lim* 

  Large language models (LLMs) have emerged as versatile tools in various daily
applications. However, they are fraught with issues that undermine their
utility and trustworthiness. These include the incorporation of erroneous
references (citation), the generation of hallucinated information
(correctness), and the inclusion of superfluous or omission of crucial details
(fluency). To ameliorate these concerns, this study makes several key
contributions. First, we build a dataset to train a critic model capable of
evaluating the citation, correctness, and fluency of responses generated by
LLMs in QA systems. Second, we propose an automated feedback mechanism that
leverages the critic model to offer real-time feedback on heterogeneous aspects
of generated text. Third, we introduce a feedback learning loop that uses this
critic model to iteratively improve the performance of the LLM responsible for
response generation. Experimental results demonstrate the efficacy of our
approach, showing substantial improvements in citation and fluency metrics for
ChatGPT, including a 4% precision increase in citation and an approximately 8%
enhancement in the MAUVE metric for fluency, while maintaining high levels of
correctness.

---------------

### 27 Jan 2024 | [MultiHop-RAG: Benchmarking Retrieval-Augmented Generation for Multi-Hop  Queries](https://arxiv.org/abs/2401.15391) | [⬇️](https://arxiv.org/pdf/2401.15391)
*Yixuan Tang and Yi Yang* 

  Retrieval-augmented generation (RAG) augments large language models (LLM) by
retrieving relevant knowledge, showing promising potential in mitigating LLM
hallucinations and enhancing response quality, thereby facilitating the great
adoption of LLMs in practice. However, we find that existing RAG systems are
inadequate in answering multi-hop queries, which require retrieving and
reasoning over multiple pieces of supporting evidence. Furthermore, to our
knowledge, no existing RAG benchmarking dataset focuses on multi-hop queries.
In this paper, we develop a novel dataset, MultiHop-RAG, which consists of a
knowledge base, a large collection of multi-hop queries, their ground-truth
answers, and the associated supporting evidence. We detail the procedure of
building the dataset, utilizing an English news article dataset as the
underlying RAG knowledge base. We demonstrate the benchmarking utility of
MultiHop-RAG in two experiments. The first experiment compares different
embedding models for retrieving evidence for multi-hop queries. In the second
experiment, we examine the capabilities of various state-of-the-art LLMs,
including GPT-4, PaLM, and Llama2-70B, in reasoning and answering multi-hop
queries given the evidence. Both experiments reveal that existing RAG methods
perform unsatisfactorily in retrieving and answering multi-hop queries. We hope
MultiHop-RAG will be a valuable resource for the community in developing
effective RAG systems, thereby facilitating greater adoption of LLMs in
practice. The MultiHop-RAG and implemented RAG system is publicly available at
https://github.com/yixuantt/MultiHop-RAG/.

---------------

### 29 Jan 2024 | [Development and Testing of Retrieval Augmented Generation in Large  Language Models -- A Case Study Report](https://arxiv.org/abs/2402.01733) | [⬇️](https://arxiv.org/pdf/2402.01733)
*YuHe Ke, Liyuan Jin, Kabilan Elangovan, Hairil Rizal Abdullah, Nan  Liu, Alex Tiong Heng Sia, Chai Rick Soh, Joshua Yi Min Tung, Jasmine Chiat  Ling Ong, Daniel Shu Wei Ting* 

  Purpose: Large Language Models (LLMs) hold significant promise for medical
applications. Retrieval Augmented Generation (RAG) emerges as a promising
approach for customizing domain knowledge in LLMs. This case study presents the
development and evaluation of an LLM-RAG pipeline tailored for healthcare,
focusing specifically on preoperative medicine.
  Methods: We developed an LLM-RAG model using 35 preoperative guidelines and
tested it against human-generated responses, with a total of 1260 responses
evaluated. The RAG process involved converting clinical documents into text
using Python-based frameworks like LangChain and Llamaindex, and processing
these texts into chunks for embedding and retrieval. Vector storage techniques
and selected embedding models to optimize data retrieval, using Pinecone for
vector storage with a dimensionality of 1536 and cosine similarity for loss
metrics. Human-generated answers, provided by junior doctors, were used as a
comparison.
  Results: The LLM-RAG model generated answers within an average of 15-20
seconds, significantly faster than the 10 minutes typically required by humans.
Among the basic LLMs, GPT4.0 exhibited the best accuracy of 80.1%. This
accuracy was further increased to 91.4% when the model was enhanced with RAG.
Compared to the human-generated instructions, which had an accuracy of 86.3%,
the performance of the GPT4.0 RAG model demonstrated non-inferiority (p=0.610).
  Conclusions: In this case study, we demonstrated a LLM-RAG model for
healthcare implementation. The pipeline shows the advantages of grounded
knowledge, upgradability, and scalability as important aspects of healthcare
LLM deployment.

---------------

### 20 Jan 2024 | [Prompt-RAG: Pioneering Vector Embedding-Free Retrieval-Augmented  Generation in Niche Domains, Exemplified by Korean Medicine](https://arxiv.org/abs/2401.11246) | [⬇️](https://arxiv.org/pdf/2401.11246)
*Bongsu Kang, Jundong Kim, Tae-Rim Yun, Chang-Eop Kim* 

  We propose a natural language prompt-based retrieval augmented generation
(Prompt-RAG), a novel approach to enhance the performance of generative large
language models (LLMs) in niche domains. Conventional RAG methods mostly
require vector embeddings, yet the suitability of generic LLM-based embedding
representations for specialized domains remains uncertain. To explore and
exemplify this point, we compared vector embeddings from Korean Medicine (KM)
and Conventional Medicine (CM) documents, finding that KM document embeddings
correlated more with token overlaps and less with human-assessed document
relatedness, in contrast to CM embeddings. Prompt-RAG, distinct from
conventional RAG models, operates without the need for embedding vectors. Its
performance was assessed through a Question-Answering (QA) chatbot application,
where responses were evaluated for relevance, readability, and informativeness.
The results showed that Prompt-RAG outperformed existing models, including
ChatGPT and conventional vector embedding-based RAGs, in terms of relevance and
informativeness. Despite challenges like content structuring and response
latency, the advancements in LLMs are expected to encourage the use of
Prompt-RAG, making it a promising tool for other domains in need of RAG
methods.

---------------

### 14 Oct 2023 | [Lion: Adversarial Distillation of Proprietary Large Language Models](https://arxiv.org/abs/2305.12870) | [⬇️](https://arxiv.org/pdf/2305.12870)
*Yuxin Jiang, Chunkit Chan, Mingyang Chen, Wei Wang* 

  The practice of transferring knowledge from a sophisticated, proprietary
large language model (LLM) to a compact, open-source LLM has garnered
considerable attention. Previous works have focused on a unidirectional
knowledge distillation way by aligning the responses of the student model with
those of the teacher model to a set of instructions. Nevertheless, they
overlooked the possibility of incorporating any reciprocal
"feedback"--identifying challenging instructions where the student model's
performance falls short--to boost the student model's proficiency iteratively.
To this end, we propose a novel adversarial distillation framework for a more
efficient knowledge transfer. Leveraging the versatile role adaptability of
LLMs, we prompt the teacher model to identify "hard" instructions and generate
new "hard" instructions for the student model, creating a three-stage
adversarial loop of imitation, discrimination, and generation. By applying this
adversarial framework, we successfully transfer knowledge from ChatGPT to a
student model (named Lion), using a mere 70k training data. Our results show
that Lion-13B not only achieves comparable open-ended generation capabilities
to ChatGPT but surpasses conventional state-of-the-art (SOTA) instruction-tuned
models like Vicuna-13B by 55.4% in challenging zero-shot reasoning benchmarks
such as BIG-Bench Hard (BBH) and 16.7% on AGIEval. Code and model can be found
at https://github.com/YJiangcm/Lion.

---------------

### 13 Nov 2023 | [MART: Improving LLM Safety with Multi-round Automatic Red-Teaming](https://arxiv.org/abs/2311.07689) | [⬇️](https://arxiv.org/pdf/2311.07689)
*Suyu Ge, Chunting Zhou, Rui Hou, Madian Khabsa, Yi-Chia Wang, Qifan  Wang, Jiawei Han, Yuning Mao* 

  Red-teaming is a common practice for mitigating unsafe behaviors in Large
Language Models (LLMs), which involves thoroughly assessing LLMs to identify
potential flaws and addressing them with responsible and accurate responses.
While effective, manual red-teaming is costly, and existing automatic
red-teaming typically discovers safety risks without addressing them. In this
paper, we propose a Multi-round Automatic Red-Teaming (MART) method, which
incorporates both automatic adversarial prompt writing and safe response
generation, significantly increasing red-teaming scalability and the safety of
the target LLM. Specifically, an adversarial LLM and a target LLM interplay
with each other in an iterative manner, where the adversarial LLM aims to
generate challenging prompts that elicit unsafe responses from the target LLM,
while the target LLM is fine-tuned with safety aligned data on these
adversarial prompts. In each round, the adversarial LLM crafts better attacks
on the updated target LLM, while the target LLM also improves itself through
safety fine-tuning. On adversarial prompt benchmarks, the violation rate of an
LLM with limited safety alignment reduces up to 84.7% after 4 rounds of MART,
achieving comparable performance to LLMs with extensive adversarial prompt
writing. Notably, model helpfulness on non-adversarial prompts remains stable
throughout iterations, indicating the target LLM maintains strong performance
on instruction following.

---------------
**Date:** 17 Oct 2023

**Title:** Self-RAG: Learning to Retrieve, Generate, and Critique through  Self-Reflection

**Abstract Link:** [https://arxiv.org/abs/2310.11511](https://arxiv.org/abs/2310.11511)

**PDF Link:** [https://arxiv.org/pdf/2310.11511](https://arxiv.org/pdf/2310.11511)

---

**Date:** 07 Mar 2024

**Title:** Direct Alignment of Draft Model for Speculative Decoding with  Chat-Fine-Tuned LLMs

**Abstract Link:** [https://arxiv.org/abs/2403.00858](https://arxiv.org/abs/2403.00858)

**PDF Link:** [https://arxiv.org/pdf/2403.00858](https://arxiv.org/pdf/2403.00858)

---

**Date:** 13 Nov 2023

**Title:** Think Before You Speak: Cultivating Communication Skills of Large  Language Models via Inner Monologue

**Abstract Link:** [https://arxiv.org/abs/2311.07445](https://arxiv.org/abs/2311.07445)

**PDF Link:** [https://arxiv.org/pdf/2311.07445](https://arxiv.org/pdf/2311.07445)

---

**Date:** 28 Feb 2024

**Title:** An Iterative Associative Memory Model for Empathetic Response Generation

**Abstract Link:** [https://arxiv.org/abs/2402.17959](https://arxiv.org/abs/2402.17959)

**PDF Link:** [https://arxiv.org/pdf/2402.17959](https://arxiv.org/pdf/2402.17959)

---

**Date:** 27 Feb 2024

**Title:** Self-Refinement of Language Models from External Proxy Metrics Feedback

**Abstract Link:** [https://arxiv.org/abs/2403.00827](https://arxiv.org/abs/2403.00827)

**PDF Link:** [https://arxiv.org/pdf/2403.00827](https://arxiv.org/pdf/2403.00827)

---

**Date:** 10 Dec 2023

**Title:** LLMGA: Multimodal Large Language Model based Generation Assistant

**Abstract Link:** [https://arxiv.org/abs/2311.16500](https://arxiv.org/abs/2311.16500)

**PDF Link:** [https://arxiv.org/pdf/2311.16500](https://arxiv.org/pdf/2311.16500)

---

**Date:** 04 Mar 2024

**Title:** How (un)ethical are instruction-centric responses of LLMs? Unveiling the  vulnerabilities of safety guardrails to harmful queries

**Abstract Link:** [https://arxiv.org/abs/2402.15302](https://arxiv.org/abs/2402.15302)

**PDF Link:** [https://arxiv.org/pdf/2402.15302](https://arxiv.org/pdf/2402.15302)

---

**Date:** 27 Jan 2024

**Title:** Enhancing Large Language Model Performance To Answer Questions and  Extract Information More Accurately

**Abstract Link:** [https://arxiv.org/abs/2402.01722](https://arxiv.org/abs/2402.01722)

**PDF Link:** [https://arxiv.org/pdf/2402.01722](https://arxiv.org/pdf/2402.01722)

---

**Date:** 26 Feb 2024

**Title:** CodeChameleon: Personalized Encryption Framework for Jailbreaking Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.16717](https://arxiv.org/abs/2402.16717)

**PDF Link:** [https://arxiv.org/pdf/2402.16717](https://arxiv.org/pdf/2402.16717)

---

**Date:** 17 Jan 2024

**Title:** Paralinguistics-Enhanced Large Language Modeling of Spoken Dialogue

**Abstract Link:** [https://arxiv.org/abs/2312.15316](https://arxiv.org/abs/2312.15316)

**PDF Link:** [https://arxiv.org/pdf/2312.15316](https://arxiv.org/pdf/2312.15316)

---

**Date:** 23 Aug 2023

**Title:** Instruction Position Matters in Sequence Generation with Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2308.12097](https://arxiv.org/abs/2308.12097)

**PDF Link:** [https://arxiv.org/pdf/2308.12097](https://arxiv.org/pdf/2308.12097)

---

**Date:** 05 Oct 2023

**Title:** A New Dialogue Response Generation Agent for Large Language Models by  Asking Questions to Detect User's Intentions

**Abstract Link:** [https://arxiv.org/abs/2310.03293](https://arxiv.org/abs/2310.03293)

**PDF Link:** [https://arxiv.org/pdf/2310.03293](https://arxiv.org/pdf/2310.03293)

---

**Date:** 15 Oct 2023

**Title:** Cue-CoT: Chain-of-thought Prompting for Responding to In-depth Dialogue  Questions with LLMs

**Abstract Link:** [https://arxiv.org/abs/2305.11792](https://arxiv.org/abs/2305.11792)

**PDF Link:** [https://arxiv.org/pdf/2305.11792](https://arxiv.org/pdf/2305.11792)

---

**Date:** 23 Feb 2024

**Title:** Fine-Grained Self-Endorsement Improves Factuality and Reasoning

**Abstract Link:** [https://arxiv.org/abs/2402.15631](https://arxiv.org/abs/2402.15631)

**PDF Link:** [https://arxiv.org/pdf/2402.15631](https://arxiv.org/pdf/2402.15631)

---

**Date:** 08 Sep 2023

**Title:** Towards Reliable and Fluent Large Language Models: Incorporating  Feedback Learning Loops in QA Systems

**Abstract Link:** [https://arxiv.org/abs/2309.06384](https://arxiv.org/abs/2309.06384)

**PDF Link:** [https://arxiv.org/pdf/2309.06384](https://arxiv.org/pdf/2309.06384)

---

**Date:** 27 Jan 2024

**Title:** MultiHop-RAG: Benchmarking Retrieval-Augmented Generation for Multi-Hop  Queries

**Abstract Link:** [https://arxiv.org/abs/2401.15391](https://arxiv.org/abs/2401.15391)

**PDF Link:** [https://arxiv.org/pdf/2401.15391](https://arxiv.org/pdf/2401.15391)

---

**Date:** 29 Jan 2024

**Title:** Development and Testing of Retrieval Augmented Generation in Large  Language Models -- A Case Study Report

**Abstract Link:** [https://arxiv.org/abs/2402.01733](https://arxiv.org/abs/2402.01733)

**PDF Link:** [https://arxiv.org/pdf/2402.01733](https://arxiv.org/pdf/2402.01733)

---

**Date:** 20 Jan 2024

**Title:** Prompt-RAG: Pioneering Vector Embedding-Free Retrieval-Augmented  Generation in Niche Domains, Exemplified by Korean Medicine

**Abstract Link:** [https://arxiv.org/abs/2401.11246](https://arxiv.org/abs/2401.11246)

**PDF Link:** [https://arxiv.org/pdf/2401.11246](https://arxiv.org/pdf/2401.11246)

---

**Date:** 14 Oct 2023

**Title:** Lion: Adversarial Distillation of Proprietary Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2305.12870](https://arxiv.org/abs/2305.12870)

**PDF Link:** [https://arxiv.org/pdf/2305.12870](https://arxiv.org/pdf/2305.12870)

---

**Date:** 13 Nov 2023

**Title:** MART: Improving LLM Safety with Multi-round Automatic Red-Teaming

**Abstract Link:** [https://arxiv.org/abs/2311.07689](https://arxiv.org/abs/2311.07689)

**PDF Link:** [https://arxiv.org/pdf/2311.07689](https://arxiv.org/pdf/2311.07689)

---

