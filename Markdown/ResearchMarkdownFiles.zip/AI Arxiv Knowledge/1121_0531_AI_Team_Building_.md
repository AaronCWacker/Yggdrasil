AI Team Building 🏢

### 🔎 AI Team Building 🏢



# AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 🏢

AI Team Building 🏢

## AI Team Building 
# 🩺🔍 Search Results
### 08 Jun 2023 | [The ADAIO System at the BEA-2023 Shared Task on Generating AI Teacher  Responses in Educational Dialogues](https://arxiv.org/abs/2306.05360) | [⬇️](https://arxiv.org/pdf/2306.05360)
*Adaeze Adigwe (1), Zheng Yuan (2 and 3)((1) University of Edinburgh,  United Kingdom, (2) Istituto Italiano di Tecnologia, Italy, (3) Universit\`a  di Ferrara, Italy)* 

  This paper presents the ADAIO team's system entry in the Building Educational
Applications (BEA) 2023 Shared Task on Generating AI Teacher Responses in
Educational Dialogues. The task aims to assess the performance of
state-of-the-art generative models as AI teachers in producing suitable
responses within a student-teacher dialogue. Our system comprises evaluating
various baseline models using OpenAI GPT-3 and designing diverse prompts to
prompt the OpenAI models for teacher response generation. After the challenge,
our system achieved second place by employing a few-shot prompt-based approach
with the OpenAI text-davinci-003 model. The results highlight the few-shot
learning capabilities of large-language models, particularly OpenAI's GPT-3, in
the role of AI teachers.

---------------

### 01 Sep 1997 | [Towards Flexible Teamwork](https://arxiv.org/abs/cs/9709101) | [⬇️](https://arxiv.org/pdf/cs/9709101)
*M. Tambe* 

  Many AI researchers are today striving to build agent teams for complex,
dynamic multi-agent domains, with intended applications in arenas such as
education, training, entertainment, information integration, and collective
robotics. Unfortunately, uncertainties in these complex, dynamic domains
obstruct coherent teamwork. In particular, team members often encounter
differing, incomplete, and possibly inconsistent views of their environment.
Furthermore, team members can unexpectedly fail in fulfilling responsibilities
or discover unexpected opportunities. Highly flexible coordination and
communication is key in addressing such uncertainties. Simply fitting
individual agents with precomputed coordination plans will not do, for their
inflexibility can cause severe failures in teamwork, and their
domain-specificity hinders reusability. Our central hypothesis is that the key
to such flexibility and reusability is providing agents with general models of
teamwork. Agents exploit such models to autonomously reason about coordination
and communication, providing requisite flexibility. Furthermore, the models
enable reuse across domains, both saving implementation effort and enforcing
consistency. This article presents one general, implemented model of teamwork,
called STEAM. The basic building block of teamwork in STEAM is joint intentions
(Cohen & Levesque, 1991b); teamwork in STEAM is based on agents' building up a
(partial) hierarchy of joint intentions (this hierarchy is seen to parallel
Grosz & Kraus's partial SharedPlans, 1996). Furthermore, in STEAM, team members
monitor the team's and individual members' performance, reorganizing the team
as necessary. Finally, decision-theoretic communication selectivity in STEAM
ensures reduction in communication overheads of teamwork, with appropriate
sensitivity to the environmental conditions. This article describes STEAM's
application in three different complex domains, and presents detailed empirical
results.

---------------

### 28 Nov 2022 | [ULTRA: A Data-driven Approach for Recommending Team Formation in  Response to Proposal Calls](https://arxiv.org/abs/2201.05646) | [⬇️](https://arxiv.org/pdf/2201.05646)
*Biplav Srivastava, Tarmo Koppel, Sai Teja Paladi, Siva Likitha  Valluru, Rohit Sharma, Owen Bond* 

  We introduce an emerging AI-based approach and prototype system for assisting
team formation when researchers respond to calls for proposals from funding
agencies. This is an instance of the general problem of building teams when
demand opportunities come periodically and potential members may vary over
time. The novelties of our approach are that we: (a) extract technical skills
needed about researchers and calls from multiple data sources and normalize
them using Natural Language Processing (NLP) techniques, (b) build a prototype
solution based on matching and teaming based on constraints, (c) describe
initial feedback about system from researchers at a University to deploy, and
(d) create and publish a dataset that others can use.

---------------

### 25 Jan 2024 | [Promoting Research Collaboration with Open Data Driven Team  Recommendation in Response to Call for Proposals](https://arxiv.org/abs/2309.09404) | [⬇️](https://arxiv.org/pdf/2309.09404)
*Siva Likitha Valluru, Biplav Srivastava, Sai Teja Paladi, Siwen Yan,  Sriraam Natarajan* 

  Building teams and promoting collaboration are two very common business
activities. An example of these are seen in the TeamingForFunding problem,
where research institutions and researchers are interested to identify
collaborative opportunities when applying to funding agencies in response to
latter's calls for proposals. We describe a novel system to recommend teams
using a variety of AI methods, such that (1) each team achieves the highest
possible skill coverage that is demanded by the opportunity, and (2) the
workload of distributing the opportunities is balanced amongst the candidate
members. We address these questions by extracting skills latent in open data of
proposal calls (demand) and researcher profiles (supply), normalizing them
using taxonomies, and creating efficient algorithms that match demand to
supply. We create teams to maximize goodness along a novel metric balancing
short- and long-term objectives. We validate the success of our algorithms (1)
quantitatively, by evaluating the recommended teams using a goodness score and
find that more informed methods lead to recommendations of smaller number of
teams but higher goodness, and (2) qualitatively, by conducting a large-scale
user study at a college-wide level, and demonstrate that users overall found
the tool very useful and relevant. Lastly, we evaluate our system in two
diverse settings in US and India (of researchers and proposal calls) to
establish generality of our approach, and deploy it at a major US university
for routine use.

---------------

### 18 May 2023 | [Requirements Engineering Framework for Human-centered Artificial  Intelligence Software Systems](https://arxiv.org/abs/2303.02920) | [⬇️](https://arxiv.org/pdf/2303.02920)
*Khlood Ahmad, Mohamed Abdelrazek, Chetan Arora, Arbind Agrahari  Baniya, Muneera Bano, John Grundy* 

  [Context] Artificial intelligence (AI) components used in building software
solutions have substantially increased in recent years. However, many of these
solutions focus on technical aspects and ignore critical human-centered
aspects. [Objective] Including human-centered aspects during requirements
engineering (RE) when building AI-based software can help achieve more
responsible, unbiased, and inclusive AI-based software solutions. [Method] In
this paper, we present a new framework developed based on human-centered AI
guidelines and a user survey to aid in collecting requirements for
human-centered AI-based software. We provide a catalog to elicit these
requirements and a conceptual model to present them visually. [Results] The
framework is applied to a case study to elicit and model requirements for
enhancing the quality of 360 degree~videos intended for virtual reality (VR)
users. [Conclusion] We found that our proposed approach helped the project team
fully understand the human-centered needs of the project to deliver.
Furthermore, the framework helped to understand what requirements need to be
captured at the initial stages against later stages in the engineering process
of AI-based software.

---------------

### 04 Mar 2024 | [Brilla AI: AI Contestant for the National Science and Maths Quiz](https://arxiv.org/abs/2403.01699) | [⬇️](https://arxiv.org/pdf/2403.01699)
*George Boateng, Jonathan Abrefah Mensah, Kevin Takyi Yeboah, William  Edor, Andrew Kojo Mensah-Onumah, Naafi Dasana Ibrahim, and Nana Sam Yeboah* 

  The African continent lacks enough qualified teachers which hampers the
provision of adequate learning support. An AI could potentially augment the
efforts of the limited number of teachers, leading to better learning outcomes.
Towards that end, this work describes and evaluates the first key output for
the NSMQ AI Grand Challenge, which proposes a robust, real-world benchmark for
such an AI: "Build an AI to compete live in Ghana's National Science and Maths
Quiz (NSMQ) competition and win - performing better than the best contestants
in all rounds and stages of the competition". The NSMQ is an annual live
science and mathematics competition for senior secondary school students in
Ghana in which 3 teams of 2 students compete by answering questions across
biology, chemistry, physics, and math in 5 rounds over 5 progressive stages
until a winning team is crowned for that year. In this work, we built Brilla
AI, an AI contestant that we deployed to unofficially compete remotely and live
in the Riddles round of the 2023 NSMQ Grand Finale, the first of its kind in
the 30-year history of the competition. Brilla AI is currently available as a
web app that livestreams the Riddles round of the contest, and runs 4 machine
learning systems: (1) speech to text (2) question extraction (3) question
answering and (4) text to speech that work together in real-time to quickly and
accurately provide an answer, and then say it with a Ghanaian accent. In its
debut, our AI answered one of the 4 riddles ahead of the 3 human contesting
teams, unofficially placing second (tied). Improvements and extensions of this
AI could potentially be deployed to offer science tutoring to students and
eventually enable millions across Africa to have one-on-one learning
interactions, democratizing science education.

---------------

### 08 Aug 2023 | [Towards an AI to Win Ghana's National Science and Maths Quiz](https://arxiv.org/abs/2308.04333) | [⬇️](https://arxiv.org/pdf/2308.04333)
*George Boateng, Jonathan Abrefah Mensah, Kevin Takyi Yeboah, William  Edor, Andrew Kojo Mensah-Onumah, Naafi Dasana Ibrahim, Nana Sam Yeboah* 

  Can an AI win Ghana's National Science and Maths Quiz (NSMQ)? That is the
question we seek to answer in the NSMQ AI project, an open-source project that
is building AI to compete live in the NSMQ and win. The NSMQ is an annual live
science and mathematics competition for senior secondary school students in
Ghana in which 3 teams of 2 students compete by answering questions across
biology, chemistry, physics, and math in 5 rounds over 5 progressive stages
until a winning team is crowned for that year. The NSMQ is an exciting live
quiz competition with interesting technical challenges across speech-to-text,
text-to-speech, question-answering, and human-computer interaction. In this
ongoing work that began in January 2023, we give an overview of the project,
describe each of the teams, progress made thus far, and the next steps toward
our planned launch and debut of the AI in October for NSMQ 2023. An AI that
conquers this grand challenge can have real-world impact on education such as
enabling millions of students across Africa to have one-on-one learning support
from this AI.

---------------

### 30 Jan 2023 | [Can an AI Win Ghana's National Science and Maths Quiz? An AI Grand  Challenge for Education](https://arxiv.org/abs/2301.13089) | [⬇️](https://arxiv.org/pdf/2301.13089)
*George Boateng, Victor Kumbol, Elsie Effah Kaufmann* 

  There is a lack of enough qualified teachers across Africa which hampers
efforts to provide adequate learning support such as educational question
answering (EQA) to students. An AI system that can enable students to ask
questions via text or voice and get instant answers will make high-quality
education accessible. Despite advances in the field of AI, there exists no
robust benchmark or challenge to enable building such an (EQA) AI within the
African context. Ghana's National Science and Maths Quiz competition (NSMQ) is
the perfect competition to evaluate the potential of such an AI due to its wide
coverage of scientific fields, variety of question types, highly competitive
nature, and live, real-world format. The NSMQ is a Jeopardy-style annual live
quiz competition in which 3 teams of 2 students compete by answering questions
across biology, chemistry, physics, and math in 5 rounds over 5 progressive
stages until a winning team is crowned for that year. In this position paper,
we propose the NSMQ AI Grand Challenge, an AI Grand Challenge for Education
using Ghana's National Science and Maths Quiz competition (NSMQ) as a case
study. Our proposed grand challenge is to "Build an AI to compete live in
Ghana's National Science and Maths Quiz (NSMQ) competition and win - performing
better than the best contestants in all rounds and stages of the competition."
We describe the competition, and key technical challenges to address along with
ideas from recent advances in machine learning that could be leveraged to solve
this challenge. This position paper is a first step towards conquering such a
challenge and importantly, making advances in AI for education in the African
context towards democratizing high-quality education across Africa.

---------------

### 02 Apr 2023 | [Data-centric AI: Perspectives and Challenges](https://arxiv.org/abs/2301.04819) | [⬇️](https://arxiv.org/pdf/2301.04819)
*Daochen Zha, Zaid Pervaiz Bhat, Kwei-Herng Lai, Fan Yang, Xia Hu* 

  The role of data in building AI systems has recently been significantly
magnified by the emerging concept of data-centric AI (DCAI), which advocates a
fundamental shift from model advancements to ensuring data quality and
reliability. Although our community has continuously invested efforts into
enhancing data in different aspects, they are often isolated initiatives on
specific tasks. To facilitate the collective initiative in our community and
push forward DCAI, we draw a big picture and bring together three general
missions: training data development, inference data development, and data
maintenance. We provide a top-level discussion on representative DCAI tasks and
share perspectives. Finally, we list open challenges. More resources are
summarized at https://github.com/daochenzha/data-centric-AI

---------------

### 27 Jul 2023 | [Introducing Tales of Tribute AI Competition](https://arxiv.org/abs/2305.08234) | [⬇️](https://arxiv.org/pdf/2305.08234)
*Jakub Kowalski, Rados{\l}aw Miernik, Katarzyna Polak, Dominik Budzki,  Damian Kowalik* 

  This paper presents a new AI challenge, the Tales of Tribute AI Competition
(TOTAIC), based on a two-player deck-building card game released with the High
Isle chapter of The Elder Scrolls Online. Currently, there is no other AI
competition covering Collectible Card Games (CCG) genre, and there has never
been one that targets a deck-building game. Thus, apart from usual CCG-related
obstacles to overcome, like randomness, hidden information, and large branching
factor, the successful approach additionally requires long-term planning and
versatility. The game can be tackled with multiple approaches, including
classic adversarial search, single-player planning, and Neural Networks-based
algorithms. This paper introduces the competition framework, describes the
rules of the game, and presents the results of a tournament between sample AI
agents. The first edition of TOTAIC is hosted at the IEEE Conference on Games
2023.

---------------

### 17 Aug 2017 | [General AI Challenge - Round One: Gradual Learning](https://arxiv.org/abs/1708.05346) | [⬇️](https://arxiv.org/pdf/1708.05346)
*Jan Feyereisl, Matej Nikl, Martin Poliak, Martin Stransky, Michal  Vlasak* 

  The General AI Challenge is an initiative to encourage the wider artificial
intelligence community to focus on important problems in building intelligent
machines with more general scope than is currently possible. The challenge
comprises of multiple rounds, with the first round focusing on gradual
learning, i.e. the ability to re-use already learned knowledge for efficiently
learning to solve subsequent problems. In this article, we will present details
of the first round of the challenge, its inspiration and aims. We also outline
a more formal description of the challenge and present a preliminary analysis
of its curriculum, based on ideas from computational mechanics. We believe,
that such formalism will allow for a more principled approach towards
investigating tasks in the challenge, building new curricula and for
potentially improving consequent challenge rounds.

---------------

### 23 Oct 2017 | [Human-in-the-loop Artificial Intelligence](https://arxiv.org/abs/1710.08191) | [⬇️](https://arxiv.org/pdf/1710.08191)
*Fabio Massimo Zanzotto* 

  Little by little, newspapers are revealing the bright future that Artificial
Intelligence (AI) is building. Intelligent machines will help everywhere.
However, this bright future has a dark side: a dramatic job market contraction
before its unpredictable transformation. Hence, in a near future, large numbers
of job seekers will need financial support while catching up with these novel
unpredictable jobs. This possible job market crisis has an antidote inside. In
fact, the rise of AI is sustained by the biggest knowledge theft of the recent
years. Learning AI machines are extracting knowledge from unaware skilled or
unskilled workers by analyzing their interactions. By passionately doing their
jobs, these workers are digging their own graves.
  In this paper, we propose Human-in-the-loop Artificial Intelligence (HIT-AI)
as a fairer paradigm for Artificial Intelligence systems. HIT-AI will reward
aware and unaware knowledge producers with a different scheme: decisions of AI
systems generating revenues will repay the legitimate owners of the knowledge
used for taking those decisions. As modern Robin Hoods, HIT-AI researchers
should fight for a fairer Artificial Intelligence that gives back what it
steals.

---------------

### 22 Sep 2022 | [Collaborative Artificial Intelligence Needs Stronger Assurances Driven  by Risks](https://arxiv.org/abs/2112.00740) | [⬇️](https://arxiv.org/pdf/2112.00740)
*Jubril Gbolahan Adigun, Matteo Camilli, Michael Felderer, Andrea  Giusti, Dominik T Matt, Anna Perini, Barbara Russo, Angelo Susi* 

  Collaborative AI systems (CAISs) aim at working together with humans in a
shared space to achieve a common goal. This critical setting yields hazardous
circumstances that could harm human beings. Thus, building such systems with
strong assurances of compliance with requirements, domain-specific standards
and regulations is of greatest importance. Only few scale impact has been
reported so far for such systems since much work remains to manage possible
risks. We identify emerging problems in this context and then we report our
vision, as well as the progress of our multidisciplinary research team composed
of software/systems, and mechatronics engineers to develop a risk-driven
assurance process for CAISs.

---------------

### 08 Feb 2024 | [Improving Agent Interactions in Virtual Environments with Language  Models](https://arxiv.org/abs/2402.05440) | [⬇️](https://arxiv.org/pdf/2402.05440)
*Jack Zhang* 

  Enhancing AI systems with efficient communication skills for effective human
assistance necessitates proactive initiatives from the system side to discern
specific circumstances and interact aptly. This research focuses on a
collective building assignment in the Minecraft dataset, employing language
modeling to enhance task understanding through state-of-the-art methods. These
models focus on grounding multi-modal understanding and task-oriented dialogue
comprehension tasks, providing insights into their interpretative and
responsive capabilities. Our experimental results showcase a substantial
improvement over existing methods, indicating a promising direction for future
research in this domain.

---------------

### 07 Dec 2022 | [Artificial Intelligence Security Competition (AISC)](https://arxiv.org/abs/2212.03412) | [⬇️](https://arxiv.org/pdf/2212.03412)
*Yinpeng Dong, Peng Chen, Senyou Deng, Lianji L, Yi Sun, Hanyu Zhao,  Jiaxing Li, Yunteng Tan, Xinyu Liu, Yangyi Dong, Enhui Xu, Jincai Xu, Shu Xu,  Xuelin Fu, Changfeng Sun, Haoliang Han, Xuchong Zhang, Shen Chen, Zhimin Sun,  Junyi Cao, Taiping Yao, Shouhong Ding, Yu Wu, Jian Lin, Tianpeng Wu, Ye Wang,  Yu Fu, Lin Feng, Kangkang Gao, Zeyu Liu, Yuanzhe Pang, Chengqi Duan, Huipeng  Zhou, Yajie Wang, Yuhang Zhao, Shangbo Wu, Haoran Lyu, Zhiyu Lin, Yifei Gao,  Shuang Li, Haonan Wang, Jitao Sang, Chen Ma, Junhao Zheng, Yijia Li, Chao  Shen, Chenhao Lin, Zhichao Cui, Guoshuai Liu, Huafeng Shi, Kun Hu, Mengxin  Zhang* 

  The security of artificial intelligence (AI) is an important research area
towards safe, reliable, and trustworthy AI systems. To accelerate the research
on AI security, the Artificial Intelligence Security Competition (AISC) was
organized by the Zhongguancun Laboratory, China Industrial Control Systems
Cyber Emergency Response Team, Institute for Artificial Intelligence, Tsinghua
University, and RealAI as part of the Zhongguancun International Frontier
Technology Innovation Competition (https://www.zgc-aisc.com/en). The
competition consists of three tracks, including Deepfake Security Competition,
Autonomous Driving Security Competition, and Face Recognition Security
Competition. This report will introduce the competition rules of these three
tracks and the solutions of top-ranking teams in each track.

---------------

### 12 Dec 2023 | [Saturn Platform: Foundation Model Operations and Generative AI for  Financial Services](https://arxiv.org/abs/2312.07721) | [⬇️](https://arxiv.org/pdf/2312.07721)
*Antonio J. G. Busson, Rennan Gaio, Rafael H. Rocha, Francisco  Evangelista, Bruno Rizzi, Luan Carvalho, Rafael Miceli, Marcos Rabaioli,  David Favaro* 

  Saturn is an innovative platform that assists Foundation Model (FM) building
and its integration with IT operations (Ops). It is custom-made to meet the
requirements of data scientists, enabling them to effectively create and
implement FMs while enhancing collaboration within their technical domain. By
offering a wide range of tools and features, Saturn streamlines and automates
different stages of FM development, making it an invaluable asset for data
science teams. This white paper introduces prospective applications of
generative AI models derived from FMs in the financial sector.

---------------

### 09 Oct 2012 | [AI in arbitrary world](https://arxiv.org/abs/1210.2715) | [⬇️](https://arxiv.org/pdf/1210.2715)
*Dimiter Dobrev* 

  In order to build AI we have to create a program which copes well in an
arbitrary world. In this paper we will restrict our attention on one concrete
world, which represents the game Tick-Tack-Toe. This world is a very simple one
but it is sufficiently complicated for our task because most people cannot
manage with it. The main difficulty in this world is that the player cannot see
the entire internal state of the world so he has to build a model in order to
understand the world. The model which we will offer will consist of final
automata and first order formulas.

---------------

### 20 Jul 2020 | [Artificial Intelligence is stupid and causal reasoning won't fix it](https://arxiv.org/abs/2008.07371) | [⬇️](https://arxiv.org/pdf/2008.07371)
*John Mark Bishop* 

  Artificial Neural Networks have reached Grandmaster and even super-human
performance across a variety of games: from those involving perfect-information
(such as Go) to those involving imperfect-information (such as Starcraft). Such
technological developments from AI-labs have ushered concomitant applications
across the world of business - where an AI brand tag is fast becoming
ubiquitous. A corollary of such widespread commercial deployment is that when
AI gets things wrong - an autonomous vehicle crashes; a chatbot exhibits racist
behaviour; automated credit scoring processes discriminate on gender etc. -
there are often significant financial, legal and brand consequences and the
incident becomes major news. As Judea Pearl sees it, the underlying reason for
such mistakes is that, 'all the impressive achievements of deep learning amount
to just curve fitting'. The key, Judea Pearl suggests, is to replace reasoning
by association with causal-reasoning - the ability to infer causes from
observed phenomena. It is a point that was echoed by Gary Marcus and Ernest
Davis in a recent piece for the New York Times: 'we need to stop building
computer systems that merely get better and better at detecting statistical
patterns in data sets - often using an approach known as Deep Learning - and
start building computer systems that from the moment of their assembly innately
grasp three basic concepts: time, space and causality'. In this paper,
foregrounding what in 1949 Gilbert Ryle termed a category mistake, I will offer
an alternative explanation for AI errors: it is not so much that AI machinery
cannot grasp causality, but that AI machinery - qua computation - cannot
understand anything at all.

---------------

### 13 Feb 2024 | [Towards Equitable Agile Research and Development of AI and Robotics](https://arxiv.org/abs/2402.08242) | [⬇️](https://arxiv.org/pdf/2402.08242)
*Andrew Hundt, Julia Schuller, Severin Kacianka* 

  Machine Learning (ML) and 'Artificial Intelligence' ('AI') methods tend to
replicate and amplify existing biases and prejudices, as do Robots with AI. For
example, robots with facial recognition have failed to identify Black Women as
human, while others have categorized people, such as Black Men, as criminals
based on appearance alone. A 'culture of modularity' means harms are perceived
as 'out of scope', or someone else's responsibility, throughout employment
positions in the 'AI supply chain'. Incidents are routine enough
(incidentdatabase.ai lists over 2000 examples) to indicate that few
organizations are capable of completely respecting peoples' rights; meeting
claimed equity, diversity, and inclusion (EDI or DEI) goals; or recognizing and
then addressing such failures in their organizations and artifacts. We propose
a framework for adapting widely practiced Research and Development (R&D)
project management methodologies to build organizational equity capabilities
and better integrate known evidence-based best practices. We describe how
project teams can organize and operationalize the most promising practices,
skill sets, organizational cultures, and methods to detect and address
rights-based fairness, equity, accountability, and ethical problems as early as
possible when they are often less harmful and easier to mitigate; then monitor
for unforeseen incidents to adaptively and constructively address them. Our
primary example adapts an Agile development process based on Scrum, one of the
most widely adopted approaches to organizing R&D teams. We also discuss
limitations of our proposed framework and future research directions.

---------------

### 03 Jan 2023 | [Deep Learning from Parametrically Generated Virtual Buildings for  Real-World Object Recognition](https://arxiv.org/abs/2302.05283) | [⬇️](https://arxiv.org/pdf/2302.05283)
*Mohammad Alawadhi, Wei Yan* 

  We study the use of parametric building information modeling (BIM) to
automatically generate training data for artificial neural networks (ANNs) to
recognize building objects in photos. Teaching artificial intelligence (AI)
machines to detect building objects in images is the foundation toward
AI-assisted semantic 3D reconstruction of existing buildings. However, there
exists the challenge of acquiring training data which is typically
human-annotated, that is, unless a computer machine can generate high-quality
data to train itself for a certain task. In that vein, we trained ANNs solely
on realistic computer-generated images of 3D BIM models which were
parametrically and automatically generated using the BIMGenE program. The ANN
training result demonstrated generalizability and good semantic segmentation on
a test case as well as arbitrary photos of buildings that are outside the range
of the training data, which is significant for the future of training AI with
generated data for solving real-world architectural problems.

---------------
