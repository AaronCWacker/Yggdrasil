Transformer Models Attention Mechanisms 🧠

### 🔎 Transformer Models Attention Mechanisms 🧠



# Transformer Models

Transformer models are a type of neural network architecture that was introduced in the paper Attention is All You Need by Vaswani et al. They are designed to handle sequential data, such as text, and have been shown to be highly effective in a variety of natural language processing tasks, such as machine translation and text summarization.

One of the key features of Transformer models is the use of attention mechanisms, which allow the model to focus on different parts of the input sequence when producing an output. This is in contrast to traditional recurrent neural networks (RNNs), which process the input sequence one element at a time and maintain a hidden state that represents the entire sequence up to that point.

Transformer models consist of an encoder and a decoder, each of which is made up of a number of identical layers. The encoder takes the input sequence and generates a continuous representation of it, which is then passed to the decoder. The decoder generates the output sequence one element at a time, using the continuous representation of the input sequence and its own hidden state to inform each prediction.

One of the benefits of Transformer models is that they are able to process the input sequence in parallel, rather than sequentially like RNNs. This allows them to be much faster and more efficient, especially for long sequences. Additionally, Transformer models are able to capture longer-range dependencies in the input sequence more effectively than RNNs, which can be limited by their use of a hidden state that represents only the recent past.

Transformer models have been shown to be highly effective in a variety of natural language processing tasks, and have become the go-to architecture for many state-of-the-art models. However, they can be more computationally expensive than other types of neural networks, and may require more data and computational resources to train effectively.

# Attention Mechanisms

Attention mechanisms are a type of neural network component that allow a model to focus on different parts of the input when producing an output. They were first introduced in the context of machine translation, where they were used to allow the model to selectively attend to different words in the source sentence when generating each word in the target sentence.

Attention mechanisms work by computing a weighted sum of the input elements, where the weights represent the importance or relevance of each element. These weights are typically learned during training, and can be influenced
# 🩺🔍 Search Results
### 30 Dec 2019 | [Is Attention All What You Need? -- An Empirical Investigation on  Convolution-Based Active Memory and Self-Attention](https://arxiv.org/abs/1912.11959) | [⬇️](https://arxiv.org/pdf/1912.11959)
*Thomas Dowdell and Hongyu Zhang* 

  The key to a Transformer model is the self-attention mechanism, which allows
the model to analyze an entire sequence in a computationally efficient manner.
Recent work has suggested the possibility that general attention mechanisms
used by RNNs could be replaced by active-memory mechanisms. In this work, we
evaluate whether various active-memory mechanisms could replace self-attention
in a Transformer. Our experiments suggest that active-memory alone achieves
comparable results to the self-attention mechanism for language modelling, but
optimal results are mostly achieved by using both active-memory and
self-attention mechanisms together. We also note that, for some specific
algorithmic tasks, active-memory mechanisms alone outperform both
self-attention and a combination of the two.

---------------

### 18 Nov 2021 | [You Only Sample (Almost) Once: Linear Cost Self-Attention Via Bernoulli  Sampling](https://arxiv.org/abs/2111.09714) | [⬇️](https://arxiv.org/pdf/2111.09714)
*Zhanpeng Zeng, Yunyang Xiong, Sathya N. Ravi, Shailesh Acharya, Glenn  Fung, Vikas Singh* 

  Transformer-based models are widely used in natural language processing
(NLP). Central to the transformer model is the self-attention mechanism, which
captures the interactions of token pairs in the input sequences and depends
quadratically on the sequence length. Training such models on longer sequences
is expensive. In this paper, we show that a Bernoulli sampling attention
mechanism based on Locality Sensitive Hashing (LSH), decreases the quadratic
complexity of such models to linear. We bypass the quadratic cost by
considering self-attention as a sum of individual tokens associated with
Bernoulli random variables that can, in principle, be sampled at once by a
single hash (although in practice, this number may be a small constant). This
leads to an efficient sampling scheme to estimate self-attention which relies
on specific modifications of LSH (to enable deployment on GPU architectures).
We evaluate our algorithm on the GLUE benchmark with standard 512 sequence
length where we see favorable performance relative to a standard pretrained
Transformer. On the Long Range Arena (LRA) benchmark, for evaluating
performance on long sequences, our method achieves results consistent with
softmax self-attention but with sizable speed-ups and memory savings and often
outperforms other efficient self-attention methods. Our code is available at
https://github.com/mlpen/YOSO

---------------

### 12 Jun 2019 | [A Multiscale Visualization of Attention in the Transformer Model](https://arxiv.org/abs/1906.05714) | [⬇️](https://arxiv.org/pdf/1906.05714)
*Jesse Vig* 

  The Transformer is a sequence model that forgoes traditional recurrent
architectures in favor of a fully attention-based approach. Besides improving
performance, an advantage of using attention is that it can also help to
interpret a model by showing how the model assigns weight to different input
elements. However, the multi-layer, multi-head attention mechanism in the
Transformer model can be difficult to decipher. To make the model more
accessible, we introduce an open-source tool that visualizes attention at
multiple scales, each of which provides a unique perspective on the attention
mechanism. We demonstrate the tool on BERT and OpenAI GPT-2 and present three
example use cases: detecting model bias, locating relevant attention heads, and
linking neurons to model behavior.

---------------

### 16 May 2023 | [Fast-FNet: Accelerating Transformer Encoder Models via Efficient Fourier  Layers](https://arxiv.org/abs/2209.12816) | [⬇️](https://arxiv.org/pdf/2209.12816)
*Nurullah Sevim, Ege Ozan \"Ozyedek, Furkan \c{S}ahinu\c{c}, Aykut  Ko\c{c}* 

  Transformer-based language models utilize the attention mechanism for
substantial performance improvements in almost all natural language processing
(NLP) tasks. Similar attention structures are also extensively studied in
several other areas. Although the attention mechanism enhances the model
performances significantly, its quadratic complexity prevents efficient
processing of long sequences. Recent works focused on eliminating the
disadvantages of computational inefficiency and showed that transformer-based
models can still reach competitive results without the attention layer. A
pioneering study proposed the FNet, which replaces the attention layer with the
Fourier Transform (FT) in the transformer encoder architecture. FNet achieves
competitive performances concerning the original transformer encoder model
while accelerating training process by removing the computational burden of the
attention mechanism. However, the FNet model ignores essential properties of
the FT from the classical signal processing that can be leveraged to increase
model efficiency further. We propose different methods to deploy FT efficiently
in transformer encoder models. Our proposed architectures have smaller number
of model parameters, shorter training times, less memory usage, and some
additional performance improvements. We demonstrate these improvements through
extensive experiments on common benchmarks.

---------------

### 09 Aug 2023 | [AttentionViz: A Global View of Transformer Attention](https://arxiv.org/abs/2305.03210) | [⬇️](https://arxiv.org/pdf/2305.03210)
*Catherine Yeh, Yida Chen, Aoyu Wu, Cynthia Chen, Fernanda Vi\'egas,  Martin Wattenberg* 

  Transformer models are revolutionizing machine learning, but their inner
workings remain mysterious. In this work, we present a new visualization
technique designed to help researchers understand the self-attention mechanism
in transformers that allows these models to learn rich, contextual
relationships between elements of a sequence. The main idea behind our method
is to visualize a joint embedding of the query and key vectors used by
transformer models to compute attention. Unlike previous attention
visualization techniques, our approach enables the analysis of global patterns
across multiple input sequences. We create an interactive visualization tool,
AttentionViz (demo: http://attentionviz.com), based on these joint query-key
embeddings, and use it to study attention mechanisms in both language and
vision transformers. We demonstrate the utility of our approach in improving
model understanding and offering new insights about query-key interactions
through several application scenarios and expert feedback.

---------------

### 13 Oct 2022 | [LSG Attention: Extrapolation of pretrained Transformers to long  sequences](https://arxiv.org/abs/2210.15497) | [⬇️](https://arxiv.org/pdf/2210.15497)
*Charles Condevaux and S\'ebastien Harispe* 

  Transformer models achieve state-of-the-art performance on a wide range of
NLP tasks. They however suffer from a prohibitive limitation due to the
self-attention mechanism, inducing $O(n^2)$ complexity with regard to sequence
length. To answer this limitation we introduce the LSG architecture which
relies on Local, Sparse and Global attention. We show that LSG attention is
fast, efficient and competitive in classification and summarization tasks on
long documents. Interestingly, it can also be used to adapt existing pretrained
models to efficiently extrapolate to longer sequences with no additional
training. Along with the introduction of the LSG attention mechanism, we
propose tools to train new models and adapt existing ones based on this
mechanism.

---------------

### 01 Jul 2021 | [SparseBERT: Rethinking the Importance Analysis in Self-attention](https://arxiv.org/abs/2102.12871) | [⬇️](https://arxiv.org/pdf/2102.12871)
*Han Shi, Jiahui Gao, Xiaozhe Ren, Hang Xu, Xiaodan Liang, Zhenguo Li,  James T. Kwok* 

  Transformer-based models are popularly used in natural language processing
(NLP). Its core component, self-attention, has aroused widespread interest. To
understand the self-attention mechanism, a direct method is to visualize the
attention map of a pre-trained model. Based on the patterns observed, a series
of efficient Transformers with different sparse attention masks have been
proposed. From a theoretical perspective, universal approximability of
Transformer-based models is also recently proved. However, the above
understanding and analysis of self-attention is based on a pre-trained model.
To rethink the importance analysis in self-attention, we study the significance
of different positions in attention matrix during pre-training. A surprising
result is that diagonal elements in the attention map are the least important
compared with other attention positions. We provide a proof showing that these
diagonal elements can indeed be removed without deteriorating model
performance. Furthermore, we propose a Differentiable Attention Mask (DAM)
algorithm, which further guides the design of the SparseBERT. Extensive
experiments verify our interesting findings and illustrate the effect of the
proposed algorithm.

---------------

### 17 Jan 2023 | [3D-C2FT: Coarse-to-fine Transformer for Multi-view 3D Reconstruction](https://arxiv.org/abs/2205.14575) | [⬇️](https://arxiv.org/pdf/2205.14575)
*Leslie Ching Ow Tiong, Dick Sigmund, Andrew Beng Jin Teoh* 

  Recently, the transformer model has been successfully employed for the
multi-view 3D reconstruction problem. However, challenges remain on designing
an attention mechanism to explore the multiview features and exploit their
relations for reinforcing the encoding-decoding modules. This paper proposes a
new model, namely 3D coarse-to-fine transformer (3D-C2FT), by introducing a
novel coarse-to-fine(C2F) attention mechanism for encoding multi-view features
and rectifying defective 3D objects. C2F attention mechanism enables the model
to learn multi-view information flow and synthesize 3D surface correction in a
coarse to fine-grained manner. The proposed model is evaluated by ShapeNet and
Multi-view Real-life datasets. Experimental results show that 3D-C2FT achieves
notable results and outperforms several competing models on these datasets.

---------------

### 05 Jan 2024 | [A Cost-Efficient FPGA Implementation of Tiny Transformer Model using  Neural ODE](https://arxiv.org/abs/2401.02721) | [⬇️](https://arxiv.org/pdf/2401.02721)
*Ikumi Okubo, Keisuke Sugiura, Hiroki Matsutani* 

  Transformer is an emerging neural network model with attention mechanism. It
has been adopted to various tasks and achieved a favorable accuracy compared to
CNNs and RNNs. While the attention mechanism is recognized as a general-purpose
component, many of the Transformer models require a significant number of
parameters compared to the CNN-based ones. To mitigate the computational
complexity, recently, a hybrid approach has been proposed, which uses ResNet as
a backbone architecture and replaces a part of its convolution layers with an
MHSA (Multi-Head Self-Attention) mechanism. In this paper, we significantly
reduce the parameter size of such models by using Neural ODE (Ordinary
Differential Equation) as a backbone architecture instead of ResNet. The
proposed hybrid model reduces the parameter size by 94.6% compared to the
CNN-based ones without degrading the accuracy. We then deploy the proposed
model on a modest-sized FPGA device for edge computing. To further reduce FPGA
resource utilization, we quantize the model following QAT (Quantization Aware
Training) scheme instead of PTQ (Post Training Quantization) to suppress the
accuracy loss. As a result, an extremely lightweight Transformer-based model
can be implemented on resource-limited FPGAs. The weights of the feature
extraction network are stored on-chip to minimize the memory transfer overhead,
allowing faster inference. By eliminating the overhead of memory transfers,
inference can be executed seamlessly, leading to accelerated inference. The
proposed FPGA implementation achieves 12.8x speedup and 9.21x energy efficiency
compared to ARM Cortex-A53 CPU.

---------------

### 07 Nov 2022 | [How Much Does Attention Actually Attend? Questioning the Importance of  Attention in Pretrained Transformers](https://arxiv.org/abs/2211.03495) | [⬇️](https://arxiv.org/pdf/2211.03495)
*Michael Hassid, Hao Peng, Daniel Rotem, Jungo Kasai, Ivan Montero,  Noah A. Smith and Roy Schwartz* 

  The attention mechanism is considered the backbone of the widely-used
Transformer architecture. It contextualizes the input by computing
input-specific attention matrices. We find that this mechanism, while powerful
and elegant, is not as important as typically thought for pretrained language
models. We introduce PAPA, a new probing method that replaces the
input-dependent attention matrices with constant ones -- the average attention
weights over multiple inputs. We use PAPA to analyze several established
pretrained Transformers on six downstream tasks. We find that without any
input-dependent attention, all models achieve competitive performance -- an
average relative drop of only 8% from the probing baseline. Further, little or
no performance drop is observed when replacing half of the input-dependent
attention matrices with constant (input-independent) ones. Interestingly, we
show that better-performing models lose more from applying our method than
weaker models, suggesting that the utilization of the input-dependent attention
mechanism might be a factor in their success. Our results motivate research on
simpler alternatives to input-dependent attention, as well as on methods for
better utilization of this mechanism in the Transformer architecture.

---------------

### 10 Dec 2021 | [Couplformer:Rethinking Vision Transformer with Coupling Attention Map](https://arxiv.org/abs/2112.05425) | [⬇️](https://arxiv.org/pdf/2112.05425)
*Hai Lan, Xihao Wang, Xian Wei* 

  With the development of the self-attention mechanism, the Transformer model
has demonstrated its outstanding performance in the computer vision domain.
However, the massive computation brought from the full attention mechanism
became a heavy burden for memory consumption. Sequentially, the limitation of
memory reduces the possibility of improving the Transformer model. To remedy
this problem, we propose a novel memory economy attention mechanism named
Couplformer, which decouples the attention map into two sub-matrices and
generates the alignment scores from spatial information. A series of different
scale image classification tasks are applied to evaluate the effectiveness of
our model. The result of experiments shows that on the ImageNet-1k
classification task, the Couplformer can significantly decrease 28% memory
consumption compared with regular Transformer while accessing sufficient
accuracy requirements and outperforming 0.92% on Top-1 accuracy while occupying
the same memory footprint. As a result, the Couplformer can serve as an
efficient backbone in visual tasks, and provide a novel perspective on the
attention mechanism for researchers.

---------------

### 26 Jun 2020 | [Transformer based Grapheme-to-Phoneme Conversion](https://arxiv.org/abs/2004.06338) | [⬇️](https://arxiv.org/pdf/2004.06338)
*Sevinj Yolchuyeva, G\'eza N\'emeth, B\'alint Gyires-T\'oth* 

  Attention mechanism is one of the most successful techniques in deep learning
based Natural Language Processing (NLP). The transformer network architecture
is completely based on attention mechanisms, and it outperforms
sequence-to-sequence models in neural machine translation without recurrent and
convolutional layers. Grapheme-to-phoneme (G2P) conversion is a task of
converting letters (grapheme sequence) to their pronunciations (phoneme
sequence). It plays a significant role in text-to-speech (TTS) and automatic
speech recognition (ASR) systems. In this paper, we investigate the application
of transformer architecture to G2P conversion and compare its performance with
recurrent and convolutional neural network based approaches. Phoneme and word
error rates are evaluated on the CMUDict dataset for US English and the NetTalk
dataset. The results show that transformer based G2P outperforms the
convolutional-based approach in terms of word error rate and our results
significantly exceeded previous recurrent approaches (without attention)
regarding word and phoneme error rates on both datasets. Furthermore, the size
of the proposed model is much smaller than the size of the previous approaches.

---------------

### 05 Oct 2020 | [Fixed Encoder Self-Attention Patterns in Transformer-Based Machine  Translation](https://arxiv.org/abs/2002.10260) | [⬇️](https://arxiv.org/pdf/2002.10260)
*Alessandro Raganato, Yves Scherrer and J\"org Tiedemann* 

  Transformer-based models have brought a radical change to neural machine
translation. A key feature of the Transformer architecture is the so-called
multi-head attention mechanism, which allows the model to focus simultaneously
on different parts of the input. However, recent works have shown that most
attention heads learn simple, and often redundant, positional patterns. In this
paper, we propose to replace all but one attention head of each encoder layer
with simple fixed -- non-learnable -- attentive patterns that are solely based
on position and do not require any external knowledge. Our experiments with
different data sizes and multiple language pairs show that fixing the attention
heads on the encoder side of the Transformer at training time does not impact
the translation quality and even increases BLEU scores by up to 3 points in
low-resource scenarios.

---------------

### 30 Sep 2022 | [Adaptive Sparse and Monotonic Attention for Transformer-based Automatic  Speech Recognition](https://arxiv.org/abs/2209.15176) | [⬇️](https://arxiv.org/pdf/2209.15176)
*Chendong Zhao, Jianzong Wang, Wen qi Wei, Xiaoyang Qu, Haoqian Wang,  Jing Xiao* 

  The Transformer architecture model, based on self-attention and multi-head
attention, has achieved remarkable success in offline end-to-end Automatic
Speech Recognition (ASR). However, self-attention and multi-head attention
cannot be easily applied for streaming or online ASR. For self-attention in
Transformer ASR, the softmax normalization function-based attention mechanism
makes it impossible to highlight important speech information. For multi-head
attention in Transformer ASR, it is not easy to model monotonic alignments in
different heads. To overcome these two limits, we integrate sparse attention
and monotonic attention into Transformer-based ASR. The sparse mechanism
introduces a learned sparsity scheme to enable each self-attention structure to
fit the corresponding head better. The monotonic attention deploys
regularization to prune redundant heads for the multi-head attention structure.
The experiments show that our method can effectively improve the attention
mechanism on widely used benchmarks of speech recognition.

---------------

### 26 Feb 2024 | [Linear Log-Normal Attention with Unbiased Concentration](https://arxiv.org/abs/2311.13541) | [⬇️](https://arxiv.org/pdf/2311.13541)
*Yury Nahshan, Joseph Kampeas and Emir Haleva* 

  Transformer models have achieved remarkable results in a wide range of
applications. However, their scalability is hampered by the quadratic time and
memory complexity of the self-attention mechanism concerning the sequence
length. This limitation poses a substantial obstacle when dealing with long
documents or high-resolution images. In this work, we study the self-attention
mechanism by analyzing the distribution of the attention matrix and its
concentration ability. Furthermore, we propose instruments to measure these
quantities and introduce a novel self-attention mechanism, Linear Log-Normal
Attention, designed to emulate the distribution and concentration behavior of
the original self-attention. Our experimental results on popular natural
language benchmarks reveal that our proposed Linear Log-Normal Attention
outperforms other linearized attention alternatives, offering a promising
avenue for enhancing the scalability of transformer models.

---------------

### 19 Oct 2023 | [Efficient Long-Range Transformers: You Need to Attend More, but Not  Necessarily at Every Layer](https://arxiv.org/abs/2310.12442) | [⬇️](https://arxiv.org/pdf/2310.12442)
*Qingru Zhang, Dhananjay Ram, Cole Hawkins, Sheng Zha, Tuo Zhao* 

  Pretrained transformer models have demonstrated remarkable performance across
various natural language processing tasks. These models leverage the attention
mechanism to capture long- and short-range dependencies in the sequence.
However, the (full) attention mechanism incurs high computational cost -
quadratic in the sequence length, which is not affordable in tasks with long
sequences, e.g., inputs with 8k tokens. Although sparse attention can be used
to improve computational efficiency, as suggested in existing work, it has
limited modeling capacity and often fails to capture complicated dependencies
in long sequences. To tackle this challenge, we propose MASFormer, an
easy-to-implement transformer variant with Mixed Attention Spans. Specifically,
MASFormer is equipped with full attention to capture long-range dependencies,
but only at a small number of layers. For the remaining layers, MASformer only
employs sparse attention to capture short-range dependencies. Our experiments
on natural language modeling and generation tasks show that a decoder-only
MASFormer model of 1.3B parameters can achieve competitive performance to
vanilla transformers with full attention while significantly reducing
computational cost (up to 75%). Additionally, we investigate the effectiveness
of continual training with long sequence data and how sequence length impacts
downstream generation performance, which may be of independent interest.

---------------

### 26 Oct 2022 | [Human Guided Exploitation of Interpretable Attention Patterns in  Summarization and Topic Segmentation](https://arxiv.org/abs/2112.05364) | [⬇️](https://arxiv.org/pdf/2112.05364)
*Raymond Li, Wen Xiao, Linzi Xing, Lanjun Wang, Gabriel Murray,  Giuseppe Carenini* 

  The multi-head self-attention mechanism of the transformer model has been
thoroughly investigated recently. In one vein of study, researchers are
interested in understanding why and how transformers work. In another vein,
researchers propose new attention augmentation methods to make transformers
more accurate, efficient and interpretable. In this paper, we combine these two
lines of research in a human-in-the-loop pipeline to first discover important
task-specific attention patterns. Then those patterns are injected, not only to
smaller models, but also to the original model. The benefits of our pipeline
and discovered patterns are demonstrated in two case studies with extractive
summarization and topic segmentation. After discovering interpretable patterns
in BERT-based models fine-tuned for the two downstream tasks, experiments
indicate that when we inject the patterns into attention heads, the models show
considerable improvements in accuracy and efficiency.

---------------

### 26 Apr 2023 | [The Closeness of In-Context Learning and Weight Shifting for Softmax  Regression](https://arxiv.org/abs/2304.13276) | [⬇️](https://arxiv.org/pdf/2304.13276)
*Shuai Li, Zhao Song, Yu Xia, Tong Yu, Tianyi Zhou* 

  Large language models (LLMs) are known for their exceptional performance in
natural language processing, making them highly effective in many human
life-related or even job-related tasks. The attention mechanism in the
Transformer architecture is a critical component of LLMs, as it allows the
model to selectively focus on specific input parts. The softmax unit, which is
a key part of the attention mechanism, normalizes the attention scores. Hence,
the performance of LLMs in various NLP tasks depends significantly on the
crucial role played by the attention mechanism with the softmax unit.
  In-context learning, as one of the celebrated abilities of recent LLMs, is an
important concept in querying LLMs such as ChatGPT. Without further parameter
updates, Transformers can learn to predict based on few in-context examples.
However, the reason why Transformers becomes in-context learners is not well
understood. Recently, several works [ASA+22,GTLV22,ONR+22] have studied the
in-context learning from a mathematical perspective based on a linear
regression formulation $\min_x\| Ax - b \|_2$, which show Transformers'
capability of learning linear functions in context.
  In this work, we study the in-context learning based on a softmax regression
formulation $\min_{x} \| \langle \exp(Ax), {\bf 1}_n \rangle^{-1} \exp(Ax) - b
\|_2$ of Transformer's attention mechanism. We show the upper bounds of the
data transformations induced by a single self-attention layer and by
gradient-descent on a $\ell_2$ regression loss for softmax prediction function,
which imply that when training self-attention-only Transformers for fundamental
regression tasks, the models learned by gradient-descent and Transformers show
great similarity.

---------------

### 06 Nov 2019 | [A Tensorized Transformer for Language Modeling](https://arxiv.org/abs/1906.09777) | [⬇️](https://arxiv.org/pdf/1906.09777)
*Xindian Ma, Peng Zhang, Shuai Zhang, Nan Duan, Yuexian Hou, Dawei  Song, Ming Zhou* 

  Latest development of neural models has connected the encoder and decoder
through a self-attention mechanism. In particular, Transformer, which is solely
based on self-attention, has led to breakthroughs in Natural Language
Processing (NLP) tasks. However, the multi-head attention mechanism, as a key
component of Transformer, limits the effective deployment of the model to a
resource-limited setting. In this paper, based on the ideas of tensor
decomposition and parameters sharing, we propose a novel self-attention model
(namely Multi-linear attention) with Block-Term Tensor Decomposition (BTD). We
test and verify the proposed attention method on three language modeling tasks
(i.e., PTB, WikiText-103 and One-billion) and a neural machine translation task
(i.e., WMT-2016 English-German). Multi-linear attention can not only largely
compress the model parameters but also obtain performance improvements,
compared with a number of language modeling approaches, such as Transformer,
Transformer-XL, and Transformer with tensor train decomposition.

---------------

### 29 Sep 2020 | [Attention that does not Explain Away](https://arxiv.org/abs/2009.14308) | [⬇️](https://arxiv.org/pdf/2009.14308)
*Nan Ding, Xinjie Fan, Zhenzhong Lan, Dale Schuurmans, Radu Soricut* 

  Models based on the Transformer architecture have achieved better accuracy
than the ones based on competing architectures for a large set of tasks. A
unique feature of the Transformer is its universal application of a
self-attention mechanism, which allows for free information flow at arbitrary
distances. Following a probabilistic view of the attention via the Gaussian
mixture model, we find empirical evidence that the Transformer attention tends
to "explain away" certain input neurons. To compensate for this, we propose a
doubly-normalized attention scheme that is simple to implement and provides
theoretical guarantees for avoiding the "explaining away" effect without
introducing significant computational or memory cost. Empirically, we show that
the new attention schemes result in improved performance on several well-known
benchmarks.

---------------
**Date:** 30 Dec 2019

**Title:** Is Attention All What You Need? -- An Empirical Investigation on  Convolution-Based Active Memory and Self-Attention

**Abstract Link:** [https://arxiv.org/abs/1912.11959](https://arxiv.org/abs/1912.11959)

**PDF Link:** [https://arxiv.org/pdf/1912.11959](https://arxiv.org/pdf/1912.11959)

---

**Date:** 18 Nov 2021

**Title:** You Only Sample (Almost) Once: Linear Cost Self-Attention Via Bernoulli  Sampling

**Abstract Link:** [https://arxiv.org/abs/2111.09714](https://arxiv.org/abs/2111.09714)

**PDF Link:** [https://arxiv.org/pdf/2111.09714](https://arxiv.org/pdf/2111.09714)

---

**Date:** 12 Jun 2019

**Title:** A Multiscale Visualization of Attention in the Transformer Model

**Abstract Link:** [https://arxiv.org/abs/1906.05714](https://arxiv.org/abs/1906.05714)

**PDF Link:** [https://arxiv.org/pdf/1906.05714](https://arxiv.org/pdf/1906.05714)

---

**Date:** 16 May 2023

**Title:** Fast-FNet: Accelerating Transformer Encoder Models via Efficient Fourier  Layers

**Abstract Link:** [https://arxiv.org/abs/2209.12816](https://arxiv.org/abs/2209.12816)

**PDF Link:** [https://arxiv.org/pdf/2209.12816](https://arxiv.org/pdf/2209.12816)

---

**Date:** 09 Aug 2023

**Title:** AttentionViz: A Global View of Transformer Attention

**Abstract Link:** [https://arxiv.org/abs/2305.03210](https://arxiv.org/abs/2305.03210)

**PDF Link:** [https://arxiv.org/pdf/2305.03210](https://arxiv.org/pdf/2305.03210)

---

**Date:** 13 Oct 2022

**Title:** LSG Attention: Extrapolation of pretrained Transformers to long  sequences

**Abstract Link:** [https://arxiv.org/abs/2210.15497](https://arxiv.org/abs/2210.15497)

**PDF Link:** [https://arxiv.org/pdf/2210.15497](https://arxiv.org/pdf/2210.15497)

---

**Date:** 01 Jul 2021

**Title:** SparseBERT: Rethinking the Importance Analysis in Self-attention

**Abstract Link:** [https://arxiv.org/abs/2102.12871](https://arxiv.org/abs/2102.12871)

**PDF Link:** [https://arxiv.org/pdf/2102.12871](https://arxiv.org/pdf/2102.12871)

---

**Date:** 17 Jan 2023

**Title:** 3D-C2FT: Coarse-to-fine Transformer for Multi-view 3D Reconstruction

**Abstract Link:** [https://arxiv.org/abs/2205.14575](https://arxiv.org/abs/2205.14575)

**PDF Link:** [https://arxiv.org/pdf/2205.14575](https://arxiv.org/pdf/2205.14575)

---

**Date:** 05 Jan 2024

**Title:** A Cost-Efficient FPGA Implementation of Tiny Transformer Model using  Neural ODE

**Abstract Link:** [https://arxiv.org/abs/2401.02721](https://arxiv.org/abs/2401.02721)

**PDF Link:** [https://arxiv.org/pdf/2401.02721](https://arxiv.org/pdf/2401.02721)

---

**Date:** 07 Nov 2022

**Title:** How Much Does Attention Actually Attend? Questioning the Importance of  Attention in Pretrained Transformers

**Abstract Link:** [https://arxiv.org/abs/2211.03495](https://arxiv.org/abs/2211.03495)

**PDF Link:** [https://arxiv.org/pdf/2211.03495](https://arxiv.org/pdf/2211.03495)

---

**Date:** 10 Dec 2021

**Title:** Couplformer:Rethinking Vision Transformer with Coupling Attention Map

**Abstract Link:** [https://arxiv.org/abs/2112.05425](https://arxiv.org/abs/2112.05425)

**PDF Link:** [https://arxiv.org/pdf/2112.05425](https://arxiv.org/pdf/2112.05425)

---

**Date:** 26 Jun 2020

**Title:** Transformer based Grapheme-to-Phoneme Conversion

**Abstract Link:** [https://arxiv.org/abs/2004.06338](https://arxiv.org/abs/2004.06338)

**PDF Link:** [https://arxiv.org/pdf/2004.06338](https://arxiv.org/pdf/2004.06338)

---

**Date:** 05 Oct 2020

**Title:** Fixed Encoder Self-Attention Patterns in Transformer-Based Machine  Translation

**Abstract Link:** [https://arxiv.org/abs/2002.10260](https://arxiv.org/abs/2002.10260)

**PDF Link:** [https://arxiv.org/pdf/2002.10260](https://arxiv.org/pdf/2002.10260)

---

**Date:** 30 Sep 2022

**Title:** Adaptive Sparse and Monotonic Attention for Transformer-based Automatic  Speech Recognition

**Abstract Link:** [https://arxiv.org/abs/2209.15176](https://arxiv.org/abs/2209.15176)

**PDF Link:** [https://arxiv.org/pdf/2209.15176](https://arxiv.org/pdf/2209.15176)

---

**Date:** 26 Feb 2024

**Title:** Linear Log-Normal Attention with Unbiased Concentration

**Abstract Link:** [https://arxiv.org/abs/2311.13541](https://arxiv.org/abs/2311.13541)

**PDF Link:** [https://arxiv.org/pdf/2311.13541](https://arxiv.org/pdf/2311.13541)

---

**Date:** 19 Oct 2023

**Title:** Efficient Long-Range Transformers: You Need to Attend More, but Not  Necessarily at Every Layer

**Abstract Link:** [https://arxiv.org/abs/2310.12442](https://arxiv.org/abs/2310.12442)

**PDF Link:** [https://arxiv.org/pdf/2310.12442](https://arxiv.org/pdf/2310.12442)

---

**Date:** 26 Oct 2022

**Title:** Human Guided Exploitation of Interpretable Attention Patterns in  Summarization and Topic Segmentation

**Abstract Link:** [https://arxiv.org/abs/2112.05364](https://arxiv.org/abs/2112.05364)

**PDF Link:** [https://arxiv.org/pdf/2112.05364](https://arxiv.org/pdf/2112.05364)

---

**Date:** 26 Apr 2023

**Title:** The Closeness of In-Context Learning and Weight Shifting for Softmax  Regression

**Abstract Link:** [https://arxiv.org/abs/2304.13276](https://arxiv.org/abs/2304.13276)

**PDF Link:** [https://arxiv.org/pdf/2304.13276](https://arxiv.org/pdf/2304.13276)

---

**Date:** 06 Nov 2019

**Title:** A Tensorized Transformer for Language Modeling

**Abstract Link:** [https://arxiv.org/abs/1906.09777](https://arxiv.org/abs/1906.09777)

**PDF Link:** [https://arxiv.org/pdf/1906.09777](https://arxiv.org/pdf/1906.09777)

---

**Date:** 29 Sep 2020

**Title:** Attention that does not Explain Away

**Abstract Link:** [https://arxiv.org/abs/2009.14308](https://arxiv.org/abs/2009.14308)

**PDF Link:** [https://arxiv.org/pdf/2009.14308](https://arxiv.org/pdf/2009.14308)

---

