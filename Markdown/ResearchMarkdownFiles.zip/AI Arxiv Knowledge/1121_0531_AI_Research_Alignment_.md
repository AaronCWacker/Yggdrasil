AI Research Alignment 🎪

### 🔎 AI Research Alignment 🎪



# AI Research Alignment

AI Research Alignment is a research area that focuses on ensuring that AI systems behave in a manner that is beneficial to humans. This involves developing techniques for aligning the objectives of AI systems with the values and goals of human society.

Some key challenges in AI Research Alignment include:

* Defining and measuring the values and goals of human society in a way that can be used to guide AI development.
* Developing techniques for ensuring that AI systems are transparent and interpretable, so that humans can understand how they are making decisions.
* Developing techniques for ensuring that AI systems are robust and can handle unexpected situations without causing harm.
* Developing techniques for ensuring that AI systems are fair and do not discriminate against certain groups of people.
* Developing techniques for ensuring that AI systems are safe and do not pose a risk to human safety.

Some key research areas in AI Research Alignment include:

* Value alignment: Developing techniques for aligning the objectives of AI systems with the values and goals of human society.
* Interpretability: Developing techniques for making AI systems transparent and interpretable, so that humans can understand how they are making decisions.
* Robustness: Developing techniques for ensuring that AI systems are robust and can handle unexpected situations without causing harm.
* Fairness: Developing techniques for ensuring that AI systems are fair and do not discriminate against certain groups of people.
* Safety: Developing techniques for ensuring that AI systems are safe and do not pose a risk to human safety.

Some key organizations working on AI Research Alignment include:

* The Future of Life Institute
* The Center for Human-Compatible AI at UC Berkeley
* The AI Alignment Institute
* The Machine Intelligence Research Institute
* The Partnership on AI

Some key conferences and workshops on AI Research Alignment include:

* The AI Alignment Conference
* The Beneficial AI Conference
* The Fairness, Accountability, and Transparency Conference
* The Robust and Beneficial AI Workshop
* The AI Safety and Security Workshop

Some key papers on AI Research Alignment include:

* "Concrete Problems in AI Safety" by Stuart Russell, Danielle Fong, and Francesca Rossi
* "The Value Learning Problem" by Eliezer Yudkowsky
* "Interpretability vs. Trans
# 🩺🔍 Search Results
### 06 Jun 2022 | [Researching Alignment Research: Unsupervised Analysis](https://arxiv.org/abs/2206.02841) | [⬇️](https://arxiv.org/pdf/2206.02841)
*Jan H. Kirchner, Logan Smith, Jacques Thibodeau, Kyle McDonell, Laria  Reynolds* 

  AI alignment research is the field of study dedicated to ensuring that
artificial intelligence (AI) benefits humans. As machine intelligence gets more
advanced, this research is becoming increasingly important. Researchers in the
field share ideas across different media to speed up the exchange of
information. However, this focus on speed means that the research landscape is
opaque, making it difficult for young researchers to enter the field. In this
project, we collected and analyzed existing AI alignment research. We found
that the field is growing quickly, with several subfields emerging in parallel.
We looked at the subfields and identified the prominent researchers, recurring
topics, and different modes of communication in each. Furthermore, we found
that a classifier trained on AI alignment research articles can detect relevant
articles that we did not originally include in the dataset. We are sharing the
dataset with the research community and hope to develop tools in the future
that will help both established researchers and young researchers get more
involved in the field.

---------------

### 10 Dec 2023 | [Cross Fertilizing Empathy from Brain to Machine as a Value Alignment  Strategy](https://arxiv.org/abs/2312.07579) | [⬇️](https://arxiv.org/pdf/2312.07579)
*Devin Gonier, Adrian Adduci, Cassidy LoCascio* 

  AI Alignment research seeks to align human and AI goals to ensure independent
actions by a machine are always ethical. This paper argues empathy is necessary
for this task, despite being often neglected in favor of more deductive
approaches. We offer an inside-out approach that grounds morality within the
context of the brain as a basis for algorithmically understanding ethics and
empathy. These arguments are justified via a survey of relevant literature. The
paper concludes with a suggested experimental approach to future research and
some initial experimental observations.

---------------

### 23 Oct 2023 | [AI Alignment in the Design of Interactive AI: Specification Alignment,  Process Alignment, and Evaluation Support](https://arxiv.org/abs/2311.00710) | [⬇️](https://arxiv.org/pdf/2311.00710)
*Michael Terry, Chinmay Kulkarni, Martin Wattenberg, Lucas Dixon,  Meredith Ringel Morris* 

  AI alignment considers the overall problem of ensuring an AI produces desired
outcomes, without undesirable side effects. While often considered from the
perspectives of safety and human values, AI alignment can also be considered in
the context of designing and evaluating interfaces for interactive AI systems.
This paper maps concepts from AI alignment onto a basic, three step interaction
cycle, yielding a corresponding set of alignment objectives: 1) specification
alignment: ensuring the user can efficiently and reliably communicate
objectives to the AI, 2) process alignment: providing the ability to verify and
optionally control the AI's execution process, and 3) evaluation support:
ensuring the user can verify and understand the AI's output. We also introduce
the concepts of a surrogate process, defined as a simplified, separately
derived, but controllable representation of the AI's actual process; and the
notion of a Process Gulf, which highlights how differences between human and AI
processes can lead to challenges in AI control. To illustrate the value of this
framework, we describe commercial and research systems along each of the three
alignment dimensions, and show how interfaces that provide interactive
alignment mechanisms can lead to qualitatively different and improved user
experiences.

---------------

### 26 Feb 2024 | [AI Alignment: A Comprehensive Survey](https://arxiv.org/abs/2310.19852) | [⬇️](https://arxiv.org/pdf/2310.19852)
*Jiaming Ji, Tianyi Qiu, Boyuan Chen, Borong Zhang, Hantao Lou, Kaile  Wang, Yawen Duan, Zhonghao He, Jiayi Zhou, Zhaowei Zhang, Fanzhi Zeng, Kwan  Yee Ng, Juntao Dai, Xuehai Pan, Aidan O'Gara, Yingshan Lei, Hua Xu, Brian  Tse, Jie Fu, Stephen McAleer, Yaodong Yang, Yizhou Wang, Song-Chun Zhu, Yike  Guo, Wen Gao* 

  AI alignment aims to make AI systems behave in line with human intentions and
values. As AI systems grow more capable, so do risks from misalignment. To
provide a comprehensive and up-to-date overview of the alignment field, in this
survey, we delve into the core concepts, methodology, and practice of
alignment. First, we identify four principles as the key objectives of AI
alignment: Robustness, Interpretability, Controllability, and Ethicality
(RICE). Guided by these four principles, we outline the landscape of current
alignment research and decompose them into two key components: forward
alignment and backward alignment. The former aims to make AI systems aligned
via alignment training, while the latter aims to gain evidence about the
systems' alignment and govern them appropriately to avoid exacerbating
misalignment risks. On forward alignment, we discuss techniques for learning
from feedback and learning under distribution shift. On backward alignment, we
discuss assurance techniques and governance practices.
  We also release and continually update the website (www.alignmentsurvey.com)
which features tutorials, collections of papers, blog posts, and other
resources.

---------------

### 05 Oct 2023 | [AI Alignment Dialogues: An Interactive Approach to AI Alignment in  Support Agents](https://arxiv.org/abs/2301.06421) | [⬇️](https://arxiv.org/pdf/2301.06421)
*Pei-Yu Chen, Myrthe L. Tielman, Dirk K.J. Heylen, Catholijn M. Jonker,  M. Birna van Riemsdijk* 

  AI alignment is about ensuring AI systems only pursue goals and activities
that are beneficial to humans. Most of the current approach to AI alignment is
to learn what humans value from their behavioural data. This paper proposes a
different way of looking at the notion of alignment, namely by introducing AI
Alignment Dialogues: dialogues with which users and agents try to achieve and
maintain alignment via interaction. We argue that alignment dialogues have a
number of advantages in comparison to data-driven approaches, especially for
behaviour support agents, which aim to support users in achieving their desired
future behaviours rather than their current behaviours. The advantages of
alignment dialogues include allowing the users to directly convey higher-level
concepts to the agent, and making the agent more transparent and trustworthy.
In this paper we outline the concept and high-level structure of alignment
dialogues. Moreover, we conducted a qualitative focus group user study from
which we developed a model that describes how alignment dialogues affect users,
and created design suggestions for AI alignment dialogues. Through this we
establish foundations for AI alignment dialogues and shed light on what
requires further development and research.

---------------

### 25 Oct 2018 | [Mimetic vs Anchored Value Alignment in Artificial Intelligence](https://arxiv.org/abs/1810.11116) | [⬇️](https://arxiv.org/pdf/1810.11116)
*Tae Wan Kim, Thomas Donaldson, and John Hooker* 

  "Value alignment" (VA) is considered as one of the top priorities in AI
research. Much of the existing research focuses on the "A" part and not the "V"
part of "value alignment." This paper corrects that neglect by emphasizing the
"value" side of VA and analyzes VA from the vantage point of requirements in
value theory, in particular, of avoiding the "naturalistic fallacy"--a major
epistemic caveat. The paper begins by isolating two distinct forms of VA:
"mimetic" and "anchored." Then it discusses which VA approach better avoids the
naturalistic fallacy. The discussion reveals stumbling blocks for VA approaches
that neglect implications of the naturalistic fallacy. Such problems are more
serious in mimetic VA since the mimetic process imitates human behavior that
may or may not rise to the level of correct ethical behavior. Anchored VA,
including hybrid VA, in contrast, holds more promise for future VA since it
anchors alignment by normative concepts of intrinsic value.

---------------

### 22 Dec 2022 | [Methodological reflections for AI alignment research using human  feedback](https://arxiv.org/abs/2301.06859) | [⬇️](https://arxiv.org/pdf/2301.06859)
*Thilo Hagendorff, Sarah Fabi* 

  The field of artificial intelligence (AI) alignment aims to investigate
whether AI technologies align with human interests and values and function in a
safe and ethical manner. AI alignment is particularly relevant for large
language models (LLMs), which have the potential to exhibit unintended behavior
due to their ability to learn and adapt in ways that are difficult to predict.
In this paper, we discuss methodological challenges for the alignment problem
specifically in the context of LLMs trained to summarize texts. In particular,
we focus on methods for collecting reliable human feedback on summaries to
train a reward model which in turn improves the summarization model. We
conclude by suggesting specific improvements in the experimental design of
alignment studies for LLMs' summarization capabilities.

---------------

### 25 Jun 2022 | [Aligning Artificial Intelligence with Humans through Public Policy](https://arxiv.org/abs/2207.01497) | [⬇️](https://arxiv.org/pdf/2207.01497)
*John Nay, James Daily* 

  Given that Artificial Intelligence (AI) increasingly permeates our lives, it
is critical that we systematically align AI objectives with the goals and
values of humans. The human-AI alignment problem stems from the impracticality
of explicitly specifying the rewards that AI models should receive for all the
actions they could take in all relevant states of the world. One possible
solution, then, is to leverage the capabilities of AI models to learn those
rewards implicitly from a rich source of data describing human values in a wide
range of contexts. The democratic policy-making process produces just such data
by developing specific rules, flexible standards, interpretable guidelines, and
generalizable precedents that synthesize citizens' preferences over potential
actions taken in many states of the world. Therefore, computationally encoding
public policies to make them legible to AI systems should be an important part
of a socio-technical approach to the broader human-AI alignment puzzle. This
Essay outlines research on AI that learn structures in policy data that can be
leveraged for downstream tasks. As a demonstration of the ability of AI to
comprehend policy, we provide a case study of an AI system that predicts the
relevance of proposed legislation to any given publicly traded company and its
likely effect on that company. We believe this represents the "comprehension"
phase of AI and policy, but leveraging policy as a key source of human values
to align AI requires "understanding" policy. Solving the alignment problem is
crucial to ensuring that AI is beneficial both individually (to the person or
group deploying the AI) and socially. As AI systems are given increasing
responsibility in high-stakes contexts, integrating democratically-determined
policy into those systems could align their behavior with human goals in a way
that is responsive to a constantly evolving society.

---------------

### 02 Nov 2022 | [Goal Misgeneralization: Why Correct Specifications Aren't Enough For  Correct Goals](https://arxiv.org/abs/2210.01790) | [⬇️](https://arxiv.org/pdf/2210.01790)
*Rohin Shah, Vikrant Varma, Ramana Kumar, Mary Phuong, Victoria  Krakovna, Jonathan Uesato, Zac Kenton* 

  The field of AI alignment is concerned with AI systems that pursue unintended
goals. One commonly studied mechanism by which an unintended goal might arise
is specification gaming, in which the designer-provided specification is flawed
in a way that the designers did not foresee. However, an AI system may pursue
an undesired goal even when the specification is correct, in the case of goal
misgeneralization. Goal misgeneralization is a specific form of robustness
failure for learning algorithms in which the learned program competently
pursues an undesired goal that leads to good performance in training situations
but bad performance in novel test situations. We demonstrate that goal
misgeneralization can occur in practical systems by providing several examples
in deep learning systems across a variety of domains. Extrapolating forward to
more capable systems, we provide hypotheticals that illustrate how goal
misgeneralization could lead to catastrophic risk. We suggest several research
directions that could reduce the risk of goal misgeneralization for future
systems.

---------------

### 09 Jan 2024 | [Concept Alignment](https://arxiv.org/abs/2401.08672) | [⬇️](https://arxiv.org/pdf/2401.08672)
*Sunayana Rane, Polyphony J. Bruna, Ilia Sucholutsky, Christopher  Kello, Thomas L. Griffiths* 

  Discussion of AI alignment (alignment between humans and AI systems) has
focused on value alignment, broadly referring to creating AI systems that share
human values. We argue that before we can even attempt to align values, it is
imperative that AI systems and humans align the concepts they use to understand
the world. We integrate ideas from philosophy, cognitive science, and deep
learning to explain the need for concept alignment, not just value alignment,
between humans and machines. We summarize existing accounts of how humans and
machines currently learn concepts, and we outline opportunities and challenges
in the path towards shared concepts. Finally, we explain how we can leverage
the tools already being developed in cognitive science and AI research to
accelerate progress towards concept alignment.

---------------

### 02 Jul 2022 | [The Linguistic Blind Spot of Value-Aligned Agency, Natural and  Artificial](https://arxiv.org/abs/2207.00868) | [⬇️](https://arxiv.org/pdf/2207.00868)
*Travis LaCroix* 

  The value-alignment problem for artificial intelligence (AI) asks how we can
ensure that the 'values' (i.e., objective functions) of artificial systems are
aligned with the values of humanity. In this paper, I argue that linguistic
communication (natural language) is a necessary condition for robust value
alignment. I discuss the consequences that the truth of this claim would have
for research programmes that attempt to ensure value alignment for AI systems;
or, more loftily, designing robustly beneficial or ethical artificial agents.

---------------

### 20 Oct 2023 | [VisAlign: Dataset for Measuring the Degree of Alignment between AI and  Humans in Visual Perception](https://arxiv.org/abs/2308.01525) | [⬇️](https://arxiv.org/pdf/2308.01525)
*Jiyoung Lee, Seungho Kim, Seunghyun Won, Joonseok Lee, Marzyeh  Ghassemi, James Thorne, Jaeseok Choi, O-Kil Kwon, Edward Choi* 

  AI alignment refers to models acting towards human-intended goals,
preferences, or ethical principles. Given that most large-scale deep learning
models act as black boxes and cannot be manually controlled, analyzing the
similarity between models and humans can be a proxy measure for ensuring AI
safety. In this paper, we focus on the models' visual perception alignment with
humans, further referred to as AI-human visual alignment. Specifically, we
propose a new dataset for measuring AI-human visual alignment in terms of image
classification, a fundamental task in machine perception. In order to evaluate
AI-human visual alignment, a dataset should encompass samples with various
scenarios that may arise in the real world and have gold human perception
labels. Our dataset consists of three groups of samples, namely Must-Act (i.e.,
Must-Classify), Must-Abstain, and Uncertain, based on the quantity and clarity
of visual information in an image and further divided into eight categories.
All samples have a gold human perception label; even Uncertain (severely
blurry) sample labels were obtained via crowd-sourcing. The validity of our
dataset is verified by sampling theory, statistical theories related to survey
design, and experts in the related fields. Using our dataset, we analyze the
visual alignment and reliability of five popular visual perception models and
seven abstention methods. Our code and data is available at
https://github.com/jiyounglee-0523/VisAlign.

---------------

### 01 Jan 2019 | [Personal Universes: A Solution to the Multi-Agent Value Alignment  Problem](https://arxiv.org/abs/1901.01851) | [⬇️](https://arxiv.org/pdf/1901.01851)
*Roman V. Yampolskiy* 

  AI Safety researchers attempting to align values of highly capable
intelligent systems with those of humanity face a number of challenges
including personal value extraction, multi-agent value merger and finally
in-silico encoding. State-of-the-art research in value alignment shows
difficulties in every stage in this process, but merger of incompatible
preferences is a particularly difficult challenge to overcome. In this paper we
assume that the value extraction problem will be solved and propose a possible
way to implement an AI solution which optimally aligns with individual
preferences of each user. We conclude by analyzing benefits and limitations of
the proposed approach.

---------------

### 06 May 2022 | [A Benchmark and Comprehensive Survey on Knowledge Graph Entity Alignment  via Representation Learning](https://arxiv.org/abs/2103.15059) | [⬇️](https://arxiv.org/pdf/2103.15059)
*Rui Zhang, Bayu Distiawan Trisedy, Miao Li, Yong Jiang, Jianzhong Qi* 

  In the last few years, the interest in knowledge bases has grown
exponentially in both the research community and the industry due to their
essential role in AI applications. Entity alignment is an important task for
enriching knowledge bases. This paper provides a comprehensive tutorial-type
survey on representative entity alignment techniques that use the new approach
of representation learning. We present a framework for capturing the key
characteristics of these techniques, propose two datasets to address the
limitation of existing benchmark datasets, and conduct extensive experiments
using the proposed datasets. The framework gives a clear picture of how the
techniques work. The experiments yield important results about the empirical
performance of the techniques and how various factors affect the performance.
One important observation not stressed by previous work is that techniques
making good use of attribute triples and relation predicates as features stand
out as winners.

---------------

### 01 Aug 2023 | [SurveyLM: A platform to explore emerging value perspectives in augmented  language models' behaviors](https://arxiv.org/abs/2308.00521) | [⬇️](https://arxiv.org/pdf/2308.00521)
*Steve J. Bickley, Ho Fai Chan, Bang Dao, Benno Torgler, Son Tran* 

  This white paper presents our work on SurveyLM, a platform for analyzing
augmented language models' (ALMs) emergent alignment behaviors through their
dynamically evolving attitude and value perspectives in complex social
contexts. Social Artificial Intelligence (AI) systems, like ALMs, often
function within nuanced social scenarios where there is no singular correct
response, or where an answer is heavily dependent on contextual factors, thus
necessitating an in-depth understanding of their alignment dynamics. To address
this, we apply survey and experimental methodologies, traditionally used in
studying social behaviors, to evaluate ALMs systematically, thus providing
unprecedented insights into their alignment and emergent behaviors. Moreover,
the SurveyLM platform leverages the ALMs' own feedback to enhance survey and
experiment designs, exploiting an underutilized aspect of ALMs, which
accelerates the development and testing of high-quality survey frameworks while
conserving resources. Through SurveyLM, we aim to shed light on factors
influencing ALMs' emergent behaviors, facilitate their alignment with human
intentions and expectations, and thereby contributed to the responsible
development and deployment of advanced social AI systems. This white paper
underscores the platform's potential to deliver robust results, highlighting
its significance to alignment research and its implications for future social
AI systems.

---------------

### 26 Sep 2023 | [Large Language Model Alignment: A Survey](https://arxiv.org/abs/2309.15025) | [⬇️](https://arxiv.org/pdf/2309.15025)
*Tianhao Shen, Renren Jin, Yufei Huang, Chuang Liu, Weilong Dong,  Zishan Guo, Xinwei Wu, Yan Liu, Deyi Xiong* 

  Recent years have witnessed remarkable progress made in large language models
(LLMs). Such advancements, while garnering significant attention, have
concurrently elicited various concerns. The potential of these models is
undeniably vast; however, they may yield texts that are imprecise, misleading,
or even detrimental. Consequently, it becomes paramount to employ alignment
techniques to ensure these models to exhibit behaviors consistent with human
values.
  This survey endeavors to furnish an extensive exploration of alignment
methodologies designed for LLMs, in conjunction with the extant capability
research in this domain. Adopting the lens of AI alignment, we categorize the
prevailing methods and emergent proposals for the alignment of LLMs into outer
and inner alignment. We also probe into salient issues including the models'
interpretability, and potential vulnerabilities to adversarial attacks. To
assess LLM alignment, we present a wide variety of benchmarks and evaluation
methodologies. After discussing the state of alignment research for LLMs, we
finally cast a vision toward the future, contemplating the promising avenues of
research that lie ahead.
  Our aspiration for this survey extends beyond merely spurring research
interests in this realm. We also envision bridging the gap between the AI
alignment research community and the researchers engrossed in the capability
exploration of LLMs for both capable and safe LLMs.

---------------

### 03 Dec 2023 | [Personality of AI](https://arxiv.org/abs/2312.02998) | [⬇️](https://arxiv.org/pdf/2312.02998)
*Byunggu Yu and Junwhan Kim* 

  This research paper delves into the evolving landscape of fine-tuning large
language models (LLMs) to align with human users, extending beyond basic
alignment to propose "personality alignment" for language models in
organizational settings. Acknowledging the impact of training methods on the
formation of undefined personality traits in AI models, the study draws
parallels with human fitting processes using personality tests. Through an
original case study, we demonstrate the necessity of personality fine-tuning
for AIs and raise intriguing questions about applying human-designed tests to
AIs, engineering specialized AI personality tests, and shaping AI personalities
to suit organizational roles. The paper serves as a starting point for
discussions and developments in the burgeoning field of AI personality
alignment, offering a foundational anchor for future exploration in
human-machine teaming and co-existence.

---------------

### 08 Jan 2024 | [Polynomial Precision Dependence Solutions to Alignment Research Center  Matrix Completion Problems](https://arxiv.org/abs/2401.03999) | [⬇️](https://arxiv.org/pdf/2401.03999)
*Rico Angell* 

  We present solutions to the matrix completion problems proposed by the
Alignment Research Center that have a polynomial dependence on the precision
$\varepsilon$. The motivation for these problems is to enable efficient
computation of heuristic estimators to formally evaluate and reason about
different quantities of deep neural networks in the interest of AI alignment.
Our solutions involve reframing the matrix completion problems as a
semidefinite program (SDP) and using recent advances in spectral bundle methods
for fast, efficient, and scalable SDP solving.

---------------

### 30 Jun 2019 | [Requisite Variety in Ethical Utility Functions for AI Value Alignment](https://arxiv.org/abs/1907.00430) | [⬇️](https://arxiv.org/pdf/1907.00430)
*Nadisha-Marie Aliman and Leon Kester* 

  Being a complex subject of major importance in AI Safety research, value
alignment has been studied from various perspectives in the last years.
However, no final consensus on the design of ethical utility functions
facilitating AI value alignment has been achieved yet. Given the urgency to
identify systematic solutions, we postulate that it might be useful to start
with the simple fact that for the utility function of an AI not to violate
human ethical intuitions, it trivially has to be a model of these intuitions
and reflect their variety $ - $ whereby the most accurate models pertaining to
human entities being biological organisms equipped with a brain constructing
concepts like moral judgements, are scientific models. Thus, in order to better
assess the variety of human morality, we perform a transdisciplinary analysis
applying a security mindset to the issue and summarizing variety-relevant
background knowledge from neuroscience and psychology. We complement this
information by linking it to augmented utilitarianism as a suitable ethical
framework. Based on that, we propose first practical guidelines for the design
of approximate ethical goal functions that might better capture the variety of
human moral judgements. Finally, we conclude and address future possible
challenges.

---------------

### 06 Mar 2024 | [Negating Negatives: Alignment without Human Positive Samples via  Distributional Dispreference Optimization](https://arxiv.org/abs/2403.03419) | [⬇️](https://arxiv.org/pdf/2403.03419)
*Shitong Duan, Xiaoyuan Yi, Peng Zhang, Tun Lu, Xing Xie, Ning Gu* 

  Large language models (LLMs) have revolutionized the role of AI, yet also
pose potential risks of propagating unethical content. Alignment technologies
have been introduced to steer LLMs towards human preference, gaining increasing
attention. Despite notable breakthroughs in this direction, existing methods
heavily rely on high-quality positive-negative training pairs, suffering from
noisy labels and the marginal distinction between preferred and dispreferred
response data. Given recent LLMs' proficiency in generating helpful responses,
this work pivots towards a new research focus: achieving alignment using solely
human-annotated negative samples, preserving helpfulness while reducing
harmfulness. For this purpose, we propose Distributional Dispreference
Optimization (D$^2$O), which maximizes the discrepancy between the generated
responses and the dispreferred ones to effectively eschew harmful information.
We theoretically demonstrate that D$^2$O is equivalent to learning a
distributional instead of instance-level preference model reflecting human
dispreference against the distribution of negative responses. Besides, D$^2$O
integrates an implicit Jeffrey Divergence regularization to balance the
exploitation and exploration of reference policies and converges to a
non-negative one during training. Extensive experiments demonstrate that our
method achieves comparable generation quality and surpasses the latest
baselines in producing less harmful and more informative responses with better
training stability and faster convergence.

---------------
**Date:** 06 Jun 2022

**Title:** Researching Alignment Research: Unsupervised Analysis

**Abstract Link:** [https://arxiv.org/abs/2206.02841](https://arxiv.org/abs/2206.02841)

**PDF Link:** [https://arxiv.org/pdf/2206.02841](https://arxiv.org/pdf/2206.02841)

---

**Date:** 10 Dec 2023

**Title:** Cross Fertilizing Empathy from Brain to Machine as a Value Alignment  Strategy

**Abstract Link:** [https://arxiv.org/abs/2312.07579](https://arxiv.org/abs/2312.07579)

**PDF Link:** [https://arxiv.org/pdf/2312.07579](https://arxiv.org/pdf/2312.07579)

---

**Date:** 23 Oct 2023

**Title:** AI Alignment in the Design of Interactive AI: Specification Alignment,  Process Alignment, and Evaluation Support

**Abstract Link:** [https://arxiv.org/abs/2311.00710](https://arxiv.org/abs/2311.00710)

**PDF Link:** [https://arxiv.org/pdf/2311.00710](https://arxiv.org/pdf/2311.00710)

---

**Date:** 26 Feb 2024

**Title:** AI Alignment: A Comprehensive Survey

**Abstract Link:** [https://arxiv.org/abs/2310.19852](https://arxiv.org/abs/2310.19852)

**PDF Link:** [https://arxiv.org/pdf/2310.19852](https://arxiv.org/pdf/2310.19852)

---

**Date:** 05 Oct 2023

**Title:** AI Alignment Dialogues: An Interactive Approach to AI Alignment in  Support Agents

**Abstract Link:** [https://arxiv.org/abs/2301.06421](https://arxiv.org/abs/2301.06421)

**PDF Link:** [https://arxiv.org/pdf/2301.06421](https://arxiv.org/pdf/2301.06421)

---

**Date:** 25 Oct 2018

**Title:** Mimetic vs Anchored Value Alignment in Artificial Intelligence

**Abstract Link:** [https://arxiv.org/abs/1810.11116](https://arxiv.org/abs/1810.11116)

**PDF Link:** [https://arxiv.org/pdf/1810.11116](https://arxiv.org/pdf/1810.11116)

---

**Date:** 22 Dec 2022

**Title:** Methodological reflections for AI alignment research using human  feedback

**Abstract Link:** [https://arxiv.org/abs/2301.06859](https://arxiv.org/abs/2301.06859)

**PDF Link:** [https://arxiv.org/pdf/2301.06859](https://arxiv.org/pdf/2301.06859)

---

**Date:** 25 Jun 2022

**Title:** Aligning Artificial Intelligence with Humans through Public Policy

**Abstract Link:** [https://arxiv.org/abs/2207.01497](https://arxiv.org/abs/2207.01497)

**PDF Link:** [https://arxiv.org/pdf/2207.01497](https://arxiv.org/pdf/2207.01497)

---

**Date:** 02 Nov 2022

**Title:** Goal Misgeneralization: Why Correct Specifications Aren't Enough For  Correct Goals

**Abstract Link:** [https://arxiv.org/abs/2210.01790](https://arxiv.org/abs/2210.01790)

**PDF Link:** [https://arxiv.org/pdf/2210.01790](https://arxiv.org/pdf/2210.01790)

---

**Date:** 09 Jan 2024

**Title:** Concept Alignment

**Abstract Link:** [https://arxiv.org/abs/2401.08672](https://arxiv.org/abs/2401.08672)

**PDF Link:** [https://arxiv.org/pdf/2401.08672](https://arxiv.org/pdf/2401.08672)

---

**Date:** 02 Jul 2022

**Title:** The Linguistic Blind Spot of Value-Aligned Agency, Natural and  Artificial

**Abstract Link:** [https://arxiv.org/abs/2207.00868](https://arxiv.org/abs/2207.00868)

**PDF Link:** [https://arxiv.org/pdf/2207.00868](https://arxiv.org/pdf/2207.00868)

---

**Date:** 20 Oct 2023

**Title:** VisAlign: Dataset for Measuring the Degree of Alignment between AI and  Humans in Visual Perception

**Abstract Link:** [https://arxiv.org/abs/2308.01525](https://arxiv.org/abs/2308.01525)

**PDF Link:** [https://arxiv.org/pdf/2308.01525](https://arxiv.org/pdf/2308.01525)

---

**Date:** 01 Jan 2019

**Title:** Personal Universes: A Solution to the Multi-Agent Value Alignment  Problem

**Abstract Link:** [https://arxiv.org/abs/1901.01851](https://arxiv.org/abs/1901.01851)

**PDF Link:** [https://arxiv.org/pdf/1901.01851](https://arxiv.org/pdf/1901.01851)

---

**Date:** 06 May 2022

**Title:** A Benchmark and Comprehensive Survey on Knowledge Graph Entity Alignment  via Representation Learning

**Abstract Link:** [https://arxiv.org/abs/2103.15059](https://arxiv.org/abs/2103.15059)

**PDF Link:** [https://arxiv.org/pdf/2103.15059](https://arxiv.org/pdf/2103.15059)

---

**Date:** 01 Aug 2023

**Title:** SurveyLM: A platform to explore emerging value perspectives in augmented  language models' behaviors

**Abstract Link:** [https://arxiv.org/abs/2308.00521](https://arxiv.org/abs/2308.00521)

**PDF Link:** [https://arxiv.org/pdf/2308.00521](https://arxiv.org/pdf/2308.00521)

---

**Date:** 26 Sep 2023

**Title:** Large Language Model Alignment: A Survey

**Abstract Link:** [https://arxiv.org/abs/2309.15025](https://arxiv.org/abs/2309.15025)

**PDF Link:** [https://arxiv.org/pdf/2309.15025](https://arxiv.org/pdf/2309.15025)

---

**Date:** 03 Dec 2023

**Title:** Personality of AI

**Abstract Link:** [https://arxiv.org/abs/2312.02998](https://arxiv.org/abs/2312.02998)

**PDF Link:** [https://arxiv.org/pdf/2312.02998](https://arxiv.org/pdf/2312.02998)

---

**Date:** 08 Jan 2024

**Title:** Polynomial Precision Dependence Solutions to Alignment Research Center  Matrix Completion Problems

**Abstract Link:** [https://arxiv.org/abs/2401.03999](https://arxiv.org/abs/2401.03999)

**PDF Link:** [https://arxiv.org/pdf/2401.03999](https://arxiv.org/pdf/2401.03999)

---

**Date:** 30 Jun 2019

**Title:** Requisite Variety in Ethical Utility Functions for AI Value Alignment

**Abstract Link:** [https://arxiv.org/abs/1907.00430](https://arxiv.org/abs/1907.00430)

**PDF Link:** [https://arxiv.org/pdf/1907.00430](https://arxiv.org/pdf/1907.00430)

---

**Date:** 06 Mar 2024

**Title:** Negating Negatives: Alignment without Human Positive Samples via  Distributional Dispreference Optimization

**Abstract Link:** [https://arxiv.org/abs/2403.03419](https://arxiv.org/abs/2403.03419)

**PDF Link:** [https://arxiv.org/pdf/2403.03419](https://arxiv.org/pdf/2403.03419)

---

