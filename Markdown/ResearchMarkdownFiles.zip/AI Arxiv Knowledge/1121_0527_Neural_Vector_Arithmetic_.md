Neural Vector Arithmetic 🔢

### 🔎 Neural Vector Arithmetic 🔢



# Neural Vector Arithmetic

Neural Vector Arithmetic is a simple library for performing arithmetic operations on vectors of neural network weights.

## Installation

```
pip install neural-vector-arithmetic
```

## Usage

```
import torch
from neural_vector_arithmetic import VectorArithmetic

# Create a vector arithmetic object
va = VectorArithmetic(torch.nn.Linear(10, 10))

# Add two vectors
v1 = torch.randn(10, 10)
v2 = torch.randn(10, 10)
v3 = va.add(v1, v2)

# Subtract two vectors
v4 = va.subtract(v1, v2)

# Multiply two vectors
v5 = va.multiply(v1, v2)

# Divide two vectors
v6 = va.divide(v1, v2)

# Perform element-wise arithmetic on two vectors
v7 = va.elementwise_add(v1, v2)
v8 = va.elementwise_subtract(v1, v2)
v9 = va.elementwise_multiply(v1, v2)
v10 = va.elementwise_divide(v1, v2)

# Perform matrix multiplication on two vectors
v11 = va.matrix_multiply(v1, v2)

# Perform matrix multiplication on a vector and a matrix
v12 = va.matrix_multiply(v1, va.weights)

# Perform matrix multiplication on a matrix and a vector
v13 = va.matrix_multiply(va.weights, v1)

# Perform matrix multiplication on two matrices
v14 = va.matrix_multiply(va.weights, va.weights)

# Perform matrix addition on two matrices
v15 = va.matrix_add(va.weights, va.weights)

# Perform matrix subtraction on two matrices
v16 = va.matrix_subtract(va.weights, va.weights)

# Perform matrix multiplication
# 🩺🔍 Search Results
### 14 Jan 2020 | [Neural Arithmetic Units](https://arxiv.org/abs/2001.05016) | [⬇️](https://arxiv.org/pdf/2001.05016)
*Andreas Madsen, Alexander Rosenberg Johansen* 

  Neural networks can approximate complex functions, but they struggle to
perform exact arithmetic operations over real numbers. The lack of inductive
bias for arithmetic operations leaves neural networks without the underlying
logic necessary to extrapolate on tasks such as addition, subtraction, and
multiplication. We present two new neural network components: the Neural
Addition Unit (NAU), which can learn exact addition and subtraction; and the
Neural Multiplication Unit (NMU) that can multiply subsets of a vector. The NMU
is, to our knowledge, the first arithmetic neural network component that can
learn to multiply elements from a vector, when the hidden size is large. The
two new components draw inspiration from a theoretical analysis of recently
proposed arithmetic components. We find that careful initialization,
restricting parameter space, and regularizing for sparsity is important when
optimizing the NAU and NMU. Our proposed units NAU and NMU, compared with
previous neural units, converge more consistently, have fewer parameters, learn
faster, can converge for larger hidden sizes, obtain sparse and meaningful
weights, and can extrapolate to negative and small values.

---------------

### 16 Dec 2016 | [A Visual Embedding for the Unsupervised Extraction of Abstract Semantics](https://arxiv.org/abs/1507.08818) | [⬇️](https://arxiv.org/pdf/1507.08818)
*D. Garcia-Gasulla, J. B\'ejar, U. Cort\'es, E. Ayguad\'e, J. Labarta,  T. Suzumura and R. Chen* 

  Vector-space word representations obtained from neural network models have
been shown to enable semantic operations based on vector arithmetic. In this
paper, we explore the existence of similar information on vector
representations of images. For that purpose we define a methodology to obtain
large, sparse vector representations of image classes, and generate vectors
through the state-of-the-art deep learning architecture GoogLeNet for 20K
images obtained from ImageNet. We first evaluate the resultant vector-space
semantics through its correlation with WordNet distances, and find vector
distances to be strongly correlated with linguistic semantics. We then explore
the location of images within the vector space, finding elements close in
WordNet to be clustered together, regardless of significant visual variances
(e.g. 118 dog types). More surprisingly, we find that the space unsupervisedly
separates complex classes without prior knowledge (e.g. living things).
Afterwards, we consider vector arithmetics. Although we are unable to obtain
meaningful results on this regard, we discuss the various problem we
encountered, and how we consider to solve them. Finally, we discuss the impact
of our research for cognitive systems, focusing on the role of the architecture
being used.

---------------

### 28 Feb 2023 | [Hyperdimensional Computing with Spiking-Phasor Neurons](https://arxiv.org/abs/2303.00066) | [⬇️](https://arxiv.org/pdf/2303.00066)
*Jeff Orchard, Russell Jarvis* 

  Vector Symbolic Architectures (VSAs) are a powerful framework for
representing compositional reasoning. They lend themselves to neural-network
implementations, allowing us to create neural networks that can perform
cognitive functions, like spatial reasoning, arithmetic, symbol binding, and
logic. But the vectors involved can be quite large, hence the alternative label
Hyperdimensional (HD) computing. Advances in neuromorphic hardware hold the
promise of reducing the running time and energy footprint of neural networks by
orders of magnitude. In this paper, we extend some pioneering work to run VSA
algorithms on a substrate of spiking neurons that could be run efficiently on
neuromorphic hardware.

---------------

### 05 Mar 2019 | [TinBiNN: Tiny Binarized Neural Network Overlay in about 5,000 4-LUTs and  5mW](https://arxiv.org/abs/1903.06630) | [⬇️](https://arxiv.org/pdf/1903.06630)
*Guy G.F. Lemieux, Joe Edwards, Joel Vandergriendt, Aaron Severance,  Ryan De Iaco, Abdullah Raouf, Hussein Osman, Tom Watzka, Satwant Singh* 

  Reduced-precision arithmetic improves the size, cost, power and performance
of neural networks in digital logic. In convolutional neural networks, the use
of 1b weights can achieve state-of-the-art error rates while eliminating
multiplication, reducing storage and improving power efficiency. The
BinaryConnect binary-weighted system, for example, achieves 9.9% error using
floating-point activations on the CIFAR-10 dataset. In this paper, we introduce
TinBiNN, a lightweight vector processor overlay for accelerating inference
computations with 1b weights and 8b activations. The overlay is very small --
it uses about 5,000 4-input LUTs and fits into a low cost iCE40 UltraPlus FPGA
from Lattice Semiconductor. To show this can be useful, we build two embedded
'person detector' systems by shrinking the original BinaryConnect network. The
first is a 10-category classifier with a 89% smaller network that runs in
1,315ms and achieves 13.6% error. The other is a 1-category classifier that is
even smaller, runs in 195ms, and has only 0.4% error. In both classifiers, the
error can be attributed entirely to training and not reduced precision.

---------------

### 15 Oct 2020 | [Discrete Word Embedding for Logical Natural Language Understanding](https://arxiv.org/abs/2008.11649) | [⬇️](https://arxiv.org/pdf/2008.11649)
*Masataro Asai, Zilu Tang* 

  We propose an unsupervised neural model for learning a discrete embedding of
words. Unlike existing discrete embeddings, our binary embedding supports
vector arithmetic operations similar to continuous embeddings. Our embedding
represents each word as a set of propositional statements describing a
transition rule in classical/STRIPS planning formalism. This makes the
embedding directly compatible with symbolic, state of the art classical
planning solvers.

---------------

### 12 Dec 2019 | [Scalar Arithmetic Multiple Data: Customizable Precision for Deep Neural  Networks](https://arxiv.org/abs/1809.10572) | [⬇️](https://arxiv.org/pdf/1809.10572)
*Andrew Anderson, David Gregg* 

  Quantization of weights and activations in Deep Neural Networks (DNNs) is a
powerful technique for network compression, and has enjoyed significant
attention and success. However, much of the inference-time benefit of
quantization is accessible only through the use of customized hardware
accelerators or by providing an FPGA implementation of quantized arithmetic.
  Building on prior work, we show how to construct arbitrary bit-precise signed
and unsigned integer operations using a software technique which logically
\emph{embeds} a vector architecture with custom bit-width lanes in universally
available fixed-width scalar arithmetic.
  We evaluate our approach on a high-end Intel Haswell processor, and an
embedded ARM processor. Our approach yields very fast implementations of
bit-precise custom DNN operations, which often match or exceed the performance
of operations quantized to the sizes supported in native arithmetic. At the
strongest level of quantization, our approach yields a maximum speedup of
$\thicksim6\times$ on the Intel platform, and $\thicksim10\times$ on the ARM
platform versus quantization to native 8-bit integers.

---------------

### 28 Mar 2015 | [Some Further Evidence about Magnification and Shape in Neural Gas](https://arxiv.org/abs/1503.08322) | [⬇️](https://arxiv.org/pdf/1503.08322)
*Giacomo Parigi, Andrea Pedrini, Marco Piastra* 

  Neural gas (NG) is a robust vector quantization algorithm with a well-known
mathematical model. According to this, the neural gas samples the underlying
data distribution following a power law with a magnification exponent that
depends on data dimensionality only. The effects of shape in the input data
distribution, however, are not entirely covered by the NG model above, due to
the technical difficulties involved. The experimental work described here shows
that shape is indeed relevant in determining the overall NG behavior; in
particular, some experiments reveal richer and complex behaviors induced by
shape that cannot be explained by the power law alone. Although a more
comprehensive analytical model remains to be defined, the evidence collected in
these experiments suggests that the NG algorithm has an interesting potential
for detecting complex shapes in noisy datasets.

---------------

### 07 Nov 2019 | [Measuring Arithmetic Extrapolation Performance](https://arxiv.org/abs/1910.01888) | [⬇️](https://arxiv.org/pdf/1910.01888)
*Andreas Madsen, Alexander Rosenberg Johansen* 

  The Neural Arithmetic Logic Unit (NALU) is a neural network layer that can
learn exact arithmetic operations between the elements of a hidden state. The
goal of NALU is to learn perfect extrapolation, which requires learning the
exact underlying logic of an unknown arithmetic problem. Evaluating the
performance of the NALU is non-trivial as one arithmetic problem might have
many solutions. As a consequence, single-instance MSE has been used to evaluate
and compare performance between models. However, it can be hard to interpret
what magnitude of MSE represents a correct solution and models sensitivity to
initialization. We propose using a success-criterion to measure if and when a
model converges. Using a success-criterion we can summarize success-rate over
many initialization seeds and calculate confidence intervals. We contribute a
generalized version of the previous arithmetic benchmark to measure models
sensitivity under different conditions. This is, to our knowledge, the first
extensive evaluation with respect to convergence of the NALU and its sub-units.
Using a success-criterion to summarize 4800 experiments we find that
consistently learning arithmetic extrapolation is challenging, in particular
for multiplication.

---------------

### 17 Mar 2020 | [iNALU: Improved Neural Arithmetic Logic Unit](https://arxiv.org/abs/2003.07629) | [⬇️](https://arxiv.org/pdf/2003.07629)
*Daniel Schl\"or, Markus Ring, Andreas Hotho* 

  Neural networks have to capture mathematical relationships in order to learn
various tasks. They approximate these relations implicitly and therefore often
do not generalize well. The recently proposed Neural Arithmetic Logic Unit
(NALU) is a novel neural architecture which is able to explicitly represent the
mathematical relationships by the units of the network to learn operations such
as summation, subtraction or multiplication. Although NALUs have been shown to
perform well on various downstream tasks, an in-depth analysis reveals
practical shortcomings by design, such as the inability to multiply or divide
negative input values or training stability issues for deeper networks. We
address these issues and propose an improved model architecture. We evaluate
our model empirically in various settings from learning basic arithmetic
operations to more complex functions. Our experiments indicate that our model
solves stability issues and outperforms the original NALU model in means of
arithmetic precision and convergence.

---------------

### 10 Apr 2019 | [An Application-Specific VLIW Processor with Vector Instruction Set for  CNN Acceleration](https://arxiv.org/abs/1904.05106) | [⬇️](https://arxiv.org/pdf/1904.05106)
*Andreas Bytyn, Rainer Leupers and Gerd Ascheid* 

  In recent years, neural networks have surpassed classical algorithms in areas
such as object recognition, e.g. in the well-known ImageNet challenge. As a
result, great effort is being put into developing fast and efficient
accelerators, especially for Convolutional Neural Networks (CNNs). In this work
we present ConvAix, a fully C-programmable processor, which -- contrary to many
existing architectures -- does not rely on a hard-wired array of
multiply-and-accumulate (MAC) units. Instead it maps computations onto
independent vector lanes making use of a carefully designed vector instruction
set. The presented processor is targeted towards latency-sensitive applications
and is capable of executing up to 192 MAC operations per cycle. ConvAix
operates at a target clock frequency of 400 MHz in 28nm CMOS, thereby offering
state-of-the-art performance with proper flexibility within its target domain.
Simulation results for several 2D convolutional layers from well known CNNs
(AlexNet, VGG-16) show an average ALU utilization of 72.5% using vector
instructions with 16 bit fixed-point arithmetic. Compared to other well-known
designs which are less flexible, ConvAix offers competitive energy efficiency
of up to 497 GOP/s/W while even surpassing them in terms of area efficiency and
processing speed.

---------------

### 31 Mar 2023 | [Editing Models with Task Arithmetic](https://arxiv.org/abs/2212.04089) | [⬇️](https://arxiv.org/pdf/2212.04089)
*Gabriel Ilharco, Marco Tulio Ribeiro, Mitchell Wortsman, Suchin  Gururangan, Ludwig Schmidt, Hannaneh Hajishirzi, Ali Farhadi* 

  Changing how pre-trained models behave -- e.g., improving their performance
on a downstream task or mitigating biases learned during pre-training -- is a
common practice when developing machine learning systems. In this work, we
propose a new paradigm for steering the behavior of neural networks, centered
around \textit{task vectors}. A task vector specifies a direction in the weight
space of a pre-trained model, such that movement in that direction improves
performance on the task. We build task vectors by subtracting the weights of a
pre-trained model from the weights of the same model after fine-tuning on a
task. We show that these task vectors can be modified and combined together
through arithmetic operations such as negation and addition, and the behavior
of the resulting model is steered accordingly. Negating a task vector decreases
performance on the target task, with little change in model behavior on control
tasks. Moreover, adding task vectors together can improve performance on
multiple tasks at once. Finally, when tasks are linked by an analogy
relationship of the form ``A is to B as C is to D", combining task vectors from
three of the tasks can improve performance on the fourth, even when no data
from the fourth task is used for training. Overall, our experiments with
several models, modalities and tasks show that task arithmetic is a simple,
efficient and effective way of editing models.

---------------

### 11 Feb 2022 | [NITI: Training Integer Neural Networks Using Integer-only Arithmetic](https://arxiv.org/abs/2009.13108) | [⬇️](https://arxiv.org/pdf/2009.13108)
*Maolin Wang, Seyedramin Rasoulinezhad, Philip H.W. Leong, Hayden K.H.  So* 

  While integer arithmetic has been widely adopted for improved performance in
deep quantized neural network inference, training remains a task primarily
executed using floating point arithmetic. This is because both high dynamic
range and numerical accuracy are central to the success of most modern training
algorithms. However, due to its potential for computational, storage and energy
advantages in hardware accelerators, neural network training methods that can
be implemented with low precision integer-only arithmetic remains an active
research challenge. In this paper, we present NITI, an efficient deep neural
network training framework that stores all parameters and intermediate values
as integers, and computes exclusively with integer arithmetic. A pseudo
stochastic rounding scheme that eliminates the need for external random number
generation is proposed to facilitate conversion from wider intermediate results
to low precision storage. Furthermore, a cross-entropy loss backpropagation
scheme computed with integer-only arithmetic is proposed. A proof-of-concept
open-source software implementation of NITI that utilizes native 8-bit integer
operations in modern GPUs to achieve end-to-end training is presented. When
compared with an equivalent training setup implemented with floating point
storage and arithmetic, NITI achieves negligible accuracy degradation on the
MNIST and CIFAR10 datasets using 8-bit integer storage and computation. On
ImageNet, 16-bit integers are needed for weight accumulation with an 8-bit
datapath. This achieves training results comparable to all-floating-point
implementations.

---------------

### 05 Apr 2022 | [Scalable Verification of Quantized Neural Networks (Technical Report)](https://arxiv.org/abs/2012.08185) | [⬇️](https://arxiv.org/pdf/2012.08185)
*Thomas A. Henzinger, Mathias Lechner, {\DJ}or{\dj}e \v{Z}ikeli\'c* 

  Formal verification of neural networks is an active topic of research, and
recent advances have significantly increased the size of the networks that
verification tools can handle. However, most methods are designed for
verification of an idealized model of the actual network which works over real
arithmetic and ignores rounding imprecisions. This idealization is in stark
contrast to network quantization, which is a technique that trades numerical
precision for computational efficiency and is, therefore, often applied in
practice. Neglecting rounding errors of such low-bit quantized neural networks
has been shown to lead to wrong conclusions about the network's correctness.
Thus, the desired approach for verifying quantized neural networks would be one
that takes these rounding errors into account. In this paper, we show that
verifying the bit-exact implementation of quantized neural networks with
bit-vector specifications is PSPACE-hard, even though verifying idealized
real-valued networks and satisfiability of bit-vector specifications alone are
each in NP. Furthermore, we explore several practical heuristics toward closing
the complexity gap between idealized and bit-exact verification. In particular,
we propose three techniques for making SMT-based verification of quantized
neural networks more scalable. Our experiments demonstrate that our proposed
methods allow a speedup of up to three orders of magnitude over existing
approaches.

---------------

### 08 Aug 2022 | [A Primer for Neural Arithmetic Logic Modules](https://arxiv.org/abs/2101.09530) | [⬇️](https://arxiv.org/pdf/2101.09530)
*Bhumika Mistry, Katayoun Farrahi and Jonathon Hare* 

  Neural Arithmetic Logic Modules have become a growing area of interest,
though remain a niche field. These modules are neural networks which aim to
achieve systematic generalisation in learning arithmetic and/or logic
operations such as $\{+, -, \times, \div, \leq, \textrm{AND}\}$ while also
being interpretable. This paper is the first in discussing the current state of
progress of this field, explaining key works, starting with the Neural
Arithmetic Logic Unit (NALU). Focusing on the shortcomings of the NALU, we
provide an in-depth analysis to reason about design choices of recent modules.
A cross-comparison between modules is made on experiment setups and findings,
where we highlight inconsistencies in a fundamental experiment causing the
inability to directly compare across papers. To alleviate the existing
inconsistencies, we create a benchmark which compares all existing arithmetic
NALMs. We finish by providing a novel discussion of existing applications for
NALU and research directions requiring further exploration.

---------------

### 02 Mar 2023 | [Clifford Neural Layers for PDE Modeling](https://arxiv.org/abs/2209.04934) | [⬇️](https://arxiv.org/pdf/2209.04934)
*Johannes Brandstetter, Rianne van den Berg, Max Welling, Jayesh K.  Gupta* 

  Partial differential equations (PDEs) see widespread use in sciences and
engineering to describe simulation of physical processes as scalar and vector
fields interacting and coevolving over time. Due to the computationally
expensive nature of their standard solution methods, neural PDE surrogates have
become an active research topic to accelerate these simulations. However,
current methods do not explicitly take into account the relationship between
different fields and their internal components, which are often correlated.
Viewing the time evolution of such correlated fields through the lens of
multivector fields allows us to overcome these limitations. Multivector fields
consist of scalar, vector, as well as higher-order components, such as
bivectors and trivectors. Their algebraic properties, such as multiplication,
addition and other arithmetic operations can be described by Clifford algebras.
To our knowledge, this paper presents the first usage of such multivector
representations together with Clifford convolutions and Clifford Fourier
transforms in the context of deep learning. The resulting Clifford neural
layers are universally applicable and will find direct use in the areas of
fluid dynamics, weather forecasting, and the modeling of physical systems in
general. We empirically evaluate the benefit of Clifford neural layers by
replacing convolution and Fourier operations in common neural PDE surrogates by
their Clifford counterparts on 2D Navier-Stokes and weather modeling tasks, as
well as 3D Maxwell equations. For similar parameter count, Clifford neural
layers consistently improve generalization capabilities of the tested neural
PDE surrogates. Source code for our PyTorch implementation is available at
https://microsoft.github.io/cliffordlayers/.

---------------

### 26 Jun 2020 | [EVA: An Encrypted Vector Arithmetic Language and Compiler for Efficient  Homomorphic Computation](https://arxiv.org/abs/1912.11951) | [⬇️](https://arxiv.org/pdf/1912.11951)
*Roshan Dathathri, Blagovesta Kostova, Olli Saarikivi, Wei Dai, Kim  Laine, Madanlal Musuvathi* 

  Fully-Homomorphic Encryption (FHE) offers powerful capabilities by enabling
secure offloading of both storage and computation, and recent innovations in
schemes and implementations have made it all the more attractive. At the same
time, FHE is notoriously hard to use with a very constrained programming model,
a very unusual performance profile, and many cryptographic constraints.
Existing compilers for FHE either target simpler but less efficient FHE schemes
or only support specific domains where they can rely on expert-provided
high-level runtimes to hide complications.
  This paper presents a new FHE language called Encrypted Vector Arithmetic
(EVA), which includes an optimizing compiler that generates correct and secure
FHE programs, while hiding all the complexities of the target FHE scheme.
Bolstered by our optimizing compiler, programmers can develop efficient
general-purpose FHE applications directly in EVA. For example, we have
developed image processing applications using EVA, with a very few lines of
code.
  EVA is designed to also work as an intermediate representation that can be a
target for compiling higher-level domain-specific languages. To demonstrate
this, we have re-targeted CHET, an existing domain-specific compiler for neural
network inference, onto EVA. Due to the novel optimizations in EVA, its
programs are on average 5.3x faster than those generated by CHET. We believe
that EVA would enable a wider adoption of FHE by making it easier to develop
FHE applications and domain-specific FHE compilers.

---------------

### 09 Dec 2021 | [The Fundamental Limits of Interval Arithmetic for Neural Networks](https://arxiv.org/abs/2112.05235) | [⬇️](https://arxiv.org/pdf/2112.05235)
*Matthew Mirman, Maximilian Baader, Martin Vechev* 

  Interval analysis (or interval bound propagation, IBP) is a popular technique
for verifying and training provably robust deep neural networks, a fundamental
challenge in the area of reliable machine learning. However, despite
substantial efforts, progress on addressing this key challenge has stagnated,
calling into question whether interval arithmetic is a viable path forward.
  In this paper we present two fundamental results on the limitations of
interval arithmetic for analyzing neural networks. Our main impossibility
theorem states that for any neural network classifying just three points, there
is a valid specification over these points that interval analysis can not
prove. Further, in the restricted case of one-hidden-layer neural networks we
show a stronger impossibility result: given any radius $\alpha < 1$, there is a
set of $O(\alpha^{-1})$ points with robust radius $\alpha$, separated by
distance $2$, that no one-hidden-layer network can be proven to classify
robustly via interval analysis.

---------------

### 28 Feb 2021 | [HOBFLOPS CNNs: Hardware Optimized Bitslice-Parallel Floating-Point  Operations for Convolutional Neural Networks](https://arxiv.org/abs/2007.06563) | [⬇️](https://arxiv.org/pdf/2007.06563)
*James Garland, David Gregg* 

  Convolutional neural networks (CNNs) are typically trained using 16- or
32-bit floating-point (FP) and researchers show that low-precision
floating-point (FP) can be highly effective for inference. Low-precision FP can
be implemented in field programmable gate array (FPGA) and application-specific
integrated circuit (ASIC) accelerators, but existing processors do not
generally support custom precision FP. We propose hardware optimized
bitslice-parallel floating-point operators (HOBFLOPS), a method of generating
efficient custom-precision emulated bitslice-parallel software FP arithmetic.
We generate custom-precision FP routines optimized using a hardware synthesis
design flow to create circuits. We provide standard cell libraries matching the
bitwise operations on the target microprocessor architecture, and a
code-generator to translate the hardware circuits to bitslice software
equivalents. We exploit bitslice parallelism to create a very wide (32-512
element) vectorized convolutional neural network (CNN) convolution. Hardware
optimized bitslice-parallel floating-point operators (HOBFLOPS)
multiply-accumulate (MAC) performance in CNN convolution on Arm and Intel
processors are compared to Berkeley's SoftFP16 equivalent MAC. HOBFLOPS16
outperforms SoftFP16 by 8x on Intel AVX512. HOBFLOPS offers arbitrary-precision
FP with custom range and precision e.g., HOBFLOPS9 performs at 6x the
performance of HOBFLOPS16 on Arm Neon. HOBFLOPS allows researchers to prototype
different levels of custom FP precision in the arithmetic of software CNN
accelerators. Furthermore, HOBFLOPS fast custom-precision FP CNNs may be
valuable in cases where memory bandwidth is limited.

---------------

### 22 May 2023 | [Uncertainty and Structure in Neural Ordinary Differential Equations](https://arxiv.org/abs/2305.13290) | [⬇️](https://arxiv.org/pdf/2305.13290)
*Katharina Ott, Michael Tiemann, Philipp Hennig* 

  Neural ordinary differential equations (ODEs) are an emerging class of deep
learning models for dynamical systems. They are particularly useful for
learning an ODE vector field from observed trajectories (i.e., inverse
problems). We here consider aspects of these models relevant for their
application in science and engineering. Scientific predictions generally
require structured uncertainty estimates. As a first contribution, we show that
basic and lightweight Bayesian deep learning techniques like the Laplace
approximation can be applied to neural ODEs to yield structured and meaningful
uncertainty quantification. But, in the scientific domain, available
information often goes beyond raw trajectories, and also includes mechanistic
knowledge, e.g., in the form of conservation laws. We explore how mechanistic
knowledge and uncertainty quantification interact on two recently proposed
neural ODE frameworks - symplectic neural ODEs and physical models augmented
with neural ODEs. In particular, uncertainty reflects the effect of mechanistic
information more directly than the predictive power of the trained model could.
And vice versa, structure can improve the extrapolation abilities of neural
ODEs, a fact that can be best assessed in practice through uncertainty
estimates. Our experimental analysis demonstrates the effectiveness of the
Laplace approach on both low dimensional ODE problems and a high dimensional
partial differential equation.

---------------

### 15 Aug 2019 | [Disentangling Latent Emotions of Word Embeddings on Complex Emotional  Narratives](https://arxiv.org/abs/1908.07817) | [⬇️](https://arxiv.org/pdf/1908.07817)
*Zhengxuan Wu and Yueyi Jiang* 

  Word embedding models such as GloVe are widely used in natural language
processing (NLP) research to convert words into vectors. Here, we provide a
preliminary guide to probe latent emotions in text through GloVe word vectors.
First, we trained a neural network model to predict continuous emotion valence
ratings by taking linguistic inputs from Stanford Emotional Narratives Dataset
(SEND). After interpreting the weights in the model, we found that only a few
dimensions of the word vectors contributed to expressing emotions in text, and
words were clustered on the basis of their emotional polarities. Furthermore,
we performed a linear transformation that projected high dimensional embedded
vectors into an emotion space. Based on NRC Emotion Lexicon (EmoLex), we
visualized the entanglement of emotions in the lexicon by using both projected
and raw GloVe word vectors. We showed that, in the proposed emotion space, we
were able to better disentangle emotions than using raw GloVe vectors alone. In
addition, we found that the sum vectors of different pairs of emotion words
successfully captured expressed human feelings in the EmoLex. For example, the
sum of two embedded word vectors expressing Joy and Trust which express Love
shared high similarity (similarity score .62) with the embedded vector
expressing Optimism. On the contrary, this sum vector was dissimilar
(similarity score -.19) with the the embedded vector expressing Remorse. In
this paper, we argue that through the proposed emotion space, arithmetic of
emotions is preserved in the word vectors. The affective representation
uncovered in emotion vector space could shed some light on how to help machines
to disentangle emotion expressed in word embeddings.

---------------
**Date:** 14 Jan 2020

**Title:** Neural Arithmetic Units

**Abstract Link:** [https://arxiv.org/abs/2001.05016](https://arxiv.org/abs/2001.05016)

**PDF Link:** [https://arxiv.org/pdf/2001.05016](https://arxiv.org/pdf/2001.05016)

---

**Date:** 16 Dec 2016

**Title:** A Visual Embedding for the Unsupervised Extraction of Abstract Semantics

**Abstract Link:** [https://arxiv.org/abs/1507.08818](https://arxiv.org/abs/1507.08818)

**PDF Link:** [https://arxiv.org/pdf/1507.08818](https://arxiv.org/pdf/1507.08818)

---

**Date:** 28 Feb 2023

**Title:** Hyperdimensional Computing with Spiking-Phasor Neurons

**Abstract Link:** [https://arxiv.org/abs/2303.00066](https://arxiv.org/abs/2303.00066)

**PDF Link:** [https://arxiv.org/pdf/2303.00066](https://arxiv.org/pdf/2303.00066)

---

**Date:** 05 Mar 2019

**Title:** TinBiNN: Tiny Binarized Neural Network Overlay in about 5,000 4-LUTs and  5mW

**Abstract Link:** [https://arxiv.org/abs/1903.06630](https://arxiv.org/abs/1903.06630)

**PDF Link:** [https://arxiv.org/pdf/1903.06630](https://arxiv.org/pdf/1903.06630)

---

**Date:** 15 Oct 2020

**Title:** Discrete Word Embedding for Logical Natural Language Understanding

**Abstract Link:** [https://arxiv.org/abs/2008.11649](https://arxiv.org/abs/2008.11649)

**PDF Link:** [https://arxiv.org/pdf/2008.11649](https://arxiv.org/pdf/2008.11649)

---

**Date:** 12 Dec 2019

**Title:** Scalar Arithmetic Multiple Data: Customizable Precision for Deep Neural  Networks

**Abstract Link:** [https://arxiv.org/abs/1809.10572](https://arxiv.org/abs/1809.10572)

**PDF Link:** [https://arxiv.org/pdf/1809.10572](https://arxiv.org/pdf/1809.10572)

---

**Date:** 28 Mar 2015

**Title:** Some Further Evidence about Magnification and Shape in Neural Gas

**Abstract Link:** [https://arxiv.org/abs/1503.08322](https://arxiv.org/abs/1503.08322)

**PDF Link:** [https://arxiv.org/pdf/1503.08322](https://arxiv.org/pdf/1503.08322)

---

**Date:** 07 Nov 2019

**Title:** Measuring Arithmetic Extrapolation Performance

**Abstract Link:** [https://arxiv.org/abs/1910.01888](https://arxiv.org/abs/1910.01888)

**PDF Link:** [https://arxiv.org/pdf/1910.01888](https://arxiv.org/pdf/1910.01888)

---

**Date:** 17 Mar 2020

**Title:** iNALU: Improved Neural Arithmetic Logic Unit

**Abstract Link:** [https://arxiv.org/abs/2003.07629](https://arxiv.org/abs/2003.07629)

**PDF Link:** [https://arxiv.org/pdf/2003.07629](https://arxiv.org/pdf/2003.07629)

---

**Date:** 10 Apr 2019

**Title:** An Application-Specific VLIW Processor with Vector Instruction Set for  CNN Acceleration

**Abstract Link:** [https://arxiv.org/abs/1904.05106](https://arxiv.org/abs/1904.05106)

**PDF Link:** [https://arxiv.org/pdf/1904.05106](https://arxiv.org/pdf/1904.05106)

---

**Date:** 31 Mar 2023

**Title:** Editing Models with Task Arithmetic

**Abstract Link:** [https://arxiv.org/abs/2212.04089](https://arxiv.org/abs/2212.04089)

**PDF Link:** [https://arxiv.org/pdf/2212.04089](https://arxiv.org/pdf/2212.04089)

---

**Date:** 11 Feb 2022

**Title:** NITI: Training Integer Neural Networks Using Integer-only Arithmetic

**Abstract Link:** [https://arxiv.org/abs/2009.13108](https://arxiv.org/abs/2009.13108)

**PDF Link:** [https://arxiv.org/pdf/2009.13108](https://arxiv.org/pdf/2009.13108)

---

**Date:** 05 Apr 2022

**Title:** Scalable Verification of Quantized Neural Networks (Technical Report)

**Abstract Link:** [https://arxiv.org/abs/2012.08185](https://arxiv.org/abs/2012.08185)

**PDF Link:** [https://arxiv.org/pdf/2012.08185](https://arxiv.org/pdf/2012.08185)

---

**Date:** 08 Aug 2022

**Title:** A Primer for Neural Arithmetic Logic Modules

**Abstract Link:** [https://arxiv.org/abs/2101.09530](https://arxiv.org/abs/2101.09530)

**PDF Link:** [https://arxiv.org/pdf/2101.09530](https://arxiv.org/pdf/2101.09530)

---

**Date:** 02 Mar 2023

**Title:** Clifford Neural Layers for PDE Modeling

**Abstract Link:** [https://arxiv.org/abs/2209.04934](https://arxiv.org/abs/2209.04934)

**PDF Link:** [https://arxiv.org/pdf/2209.04934](https://arxiv.org/pdf/2209.04934)

---

**Date:** 26 Jun 2020

**Title:** EVA: An Encrypted Vector Arithmetic Language and Compiler for Efficient  Homomorphic Computation

**Abstract Link:** [https://arxiv.org/abs/1912.11951](https://arxiv.org/abs/1912.11951)

**PDF Link:** [https://arxiv.org/pdf/1912.11951](https://arxiv.org/pdf/1912.11951)

---

**Date:** 09 Dec 2021

**Title:** The Fundamental Limits of Interval Arithmetic for Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2112.05235](https://arxiv.org/abs/2112.05235)

**PDF Link:** [https://arxiv.org/pdf/2112.05235](https://arxiv.org/pdf/2112.05235)

---

**Date:** 28 Feb 2021

**Title:** HOBFLOPS CNNs: Hardware Optimized Bitslice-Parallel Floating-Point  Operations for Convolutional Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2007.06563](https://arxiv.org/abs/2007.06563)

**PDF Link:** [https://arxiv.org/pdf/2007.06563](https://arxiv.org/pdf/2007.06563)

---

**Date:** 22 May 2023

**Title:** Uncertainty and Structure in Neural Ordinary Differential Equations

**Abstract Link:** [https://arxiv.org/abs/2305.13290](https://arxiv.org/abs/2305.13290)

**PDF Link:** [https://arxiv.org/pdf/2305.13290](https://arxiv.org/pdf/2305.13290)

---

**Date:** 15 Aug 2019

**Title:** Disentangling Latent Emotions of Word Embeddings on Complex Emotional  Narratives

**Abstract Link:** [https://arxiv.org/abs/1908.07817](https://arxiv.org/abs/1908.07817)

**PDF Link:** [https://arxiv.org/pdf/1908.07817](https://arxiv.org/pdf/1908.07817)

---

