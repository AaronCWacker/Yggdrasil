Neural Sparse Autoencoders 🎭

### 🔎 Neural Sparse Autoencoders 🎭



# Neural Sparse Autoencoders

Neural Sparse Autoencoders (NSAE) are a type of neural network that can be used for dimensionality reduction, feature learning, and anomaly detection. They are similar to traditional autoencoders, but they include a sparsity constraint on the hidden layer activations. This constraint encourages the network to learn a more compact and interpretable representation of the input data.

In this post, we will explore the basics of NSAEs, how they differ from traditional autoencoders, and how they can be used for anomaly detection.

## Autoencoders

Before we dive into NSAEs, let's first review traditional autoencoders. An autoencoder is a neural network that is trained to reconstruct its input. It consists of two parts: an encoder and a decoder. The encoder maps the input to a lower-dimensional representation, called the bottleneck or latent representation. The decoder then maps the latent representation back to the original input space. The idea is to learn a compact and informative representation of the input data that can be used for various tasks, such as dimensionality reduction, feature learning, and anomaly detection.

The loss function of an autoencoder is typically the reconstruction error between the input and the output. The most common reconstruction error is the mean squared error (MSE) between the input and the output. The MSE is defined as:

MSE(x, x') = (1/n) \* sum((x_i - x'_i)^2)

where x is the input, x' is the output, and n is the number of dimensions.

## Sparse Autoencoders

Sparse autoencoders are a variant of autoencoders that include a sparsity constraint on the hidden layer activations. The sparsity constraint encourages the network to learn a more compact and interpretable representation of the input data.

The sparsity constraint can be implemented in several ways. One common approach is to add a KL-divergence term to the loss function. The KL-divergence measures the difference between two probability distributions. In the case of sparse autoencoders, the KL-divergence measures the difference between the average activation of the hidden units and a small target activation value
# 🩺🔍 Search Results
### 18 Oct 2020 | [Deep Residual Autoencoders for Expectation Maximization-inspired  Dictionary Learning](https://arxiv.org/abs/1904.08827) | [⬇️](https://arxiv.org/pdf/1904.08827)
*Bahareh Tolooshams, Sourav Dey, Demba Ba* 

  We introduce a neural-network architecture, termed the constrained recurrent
sparse autoencoder (CRsAE), that solves convolutional dictionary learning
problems, thus establishing a link between dictionary learning and neural
networks. Specifically, we leverage the interpretation of the
alternating-minimization algorithm for dictionary learning as an approximate
Expectation-Maximization algorithm to develop autoencoders that enable the
simultaneous training of the dictionary and regularization parameter (ReLU
bias). The forward pass of the encoder approximates the sufficient statistics
of the E-step as the solution to a sparse coding problem, using an iterative
proximal gradient algorithm called FISTA. The encoder can be interpreted either
as a recurrent neural network or as a deep residual network, with two-sided
ReLU non-linearities in both cases. The M-step is implemented via a two-stage
back-propagation. The first stage relies on a linear decoder applied to the
encoder and a norm-squared loss. It parallels the dictionary update step in
dictionary learning. The second stage updates the regularization parameter by
applying a loss function to the encoder that includes a prior on the parameter
motivated by Bayesian statistics. We demonstrate in an image-denoising task
that CRsAE learns Gabor-like filters, and that the EM-inspired approach for
learning biases is superior to the conventional approach. In an application to
recordings of electrical activity from the brain, we demonstrate that CRsAE
learns realistic spike templates and speeds up the process of identifying spike
times by 900x compared to algorithms based on convex optimization.

---------------

### 18 Aug 2020 | [Learning the Structure of Auto-Encoding Recommenders](https://arxiv.org/abs/2008.07956) | [⬇️](https://arxiv.org/pdf/2008.07956)
*Farhan Khawar, Leonard Kin Man Poon, Nevin Lianwen Zhang* 

  Autoencoder recommenders have recently shown state-of-the-art performance in
the recommendation task due to their ability to model non-linear item
relationships effectively. However, existing autoencoder recommenders use
fully-connected neural network layers and do not employ structure learning.
This can lead to inefficient training, especially when the data is sparse as
commonly found in collaborative filtering. The aforementioned results in lower
generalization ability and reduced performance. In this paper, we introduce
structure learning for autoencoder recommenders by taking advantage of the
inherent item groups present in the collaborative filtering domain. Due to the
nature of items in general, we know that certain items are more related to each
other than to other items. Based on this, we propose a method that first learns
groups of related items and then uses this information to determine the
connectivity structure of an auto-encoding neural network. This results in a
network that is sparsely connected. This sparse structure can be viewed as a
prior that guides the network training. Empirically we demonstrate that the
proposed structure learning enables the autoencoder to converge to a local
optimum with a much smaller spectral norm and generalization error bound than
the fully-connected network. The resultant sparse network considerably
outperforms the state-of-the-art methods like \textsc{Mult-vae/Mult-dae} on
multiple benchmarked datasets even when the same number of parameters and flops
are used. It also has a better cold-start performance.

---------------

### 30 Apr 2020 | [Binary autoencoder with random binary weights](https://arxiv.org/abs/2004.14717) | [⬇️](https://arxiv.org/pdf/2004.14717)
*Viacheslav Osaulenko* 

  Here is presented an analysis of an autoencoder with binary activations $\{0,
1\}$ and binary $\{0, 1\}$ random weights. Such set up puts this model at the
intersection of different fields: neuroscience, information theory, sparse
coding, and machine learning. It is shown that the sparse activation of the
hidden layer arises naturally in order to preserve information between layers.
Furthermore, with a large enough hidden layer, it is possible to get zero
reconstruction error for any input just by varying the thresholds of neurons.
The model preserves the similarity of inputs at the hidden layer that is
maximal for the dense hidden layer activation. By analyzing the mutual
information between layers it is shown that the difference between sparse and
dense representations is related to a memory-computation trade-off. The model
is similar to an olfactory perception system of a fruit fly, and the presented
theoretical results give useful insights toward understanding more complex
neural networks.

---------------

### 30 Nov 2023 | [Clustering Inductive Biases with Unrolled Networks](https://arxiv.org/abs/2402.10213) | [⬇️](https://arxiv.org/pdf/2402.10213)
*Jonathan Huml, Abiy Tasissa, Demba Ba* 

  The classical sparse coding (SC) model represents visual stimuli as a linear
combination of a handful of learned basis functions that are Gabor-like when
trained on natural image data. However, the Gabor-like filters learned by
classical sparse coding far overpredict well-tuned simple cell receptive field
profiles observed empirically. While neurons fire sparsely, neuronal
populations are also organized in physical space by their sensitivity to
certain features. In V1, this organization is a smooth progression of
orientations along the cortical sheet. A number of subsequent models have
either discarded the sparse dictionary learning framework entirely or whose
updates have yet to take advantage of the surge in unrolled, neural dictionary
learning architectures. A key missing theme of these updates is a stronger
notion of \emph{structured sparsity}. We propose an autoencoder architecture
(WLSC) whose latent representations are implicitly, locally organized for
spectral clustering through a Laplacian quadratic form of a bipartite graph,
which generates a diverse set of artificial receptive fields that match primate
data in V1 as faithfully as recent contrastive frameworks like Local Low
Dimensionality, or LLD \citep{lld} that discard sparse dictionary learning. By
unifying sparse and smooth coding in models of the early visual cortex through
our autoencoder, we also show that our regularization can be interpreted as
early-stage specialization of receptive fields to certain classes of stimuli;
that is, we induce a weak clustering bias for later stages of cortex where
functional and spatial segregation (i.e. topography) are known to occur. The
results show an imperative for \emph{spatial regularization} of both the
receptive fields and firing rates to begin to describe feature disentanglement
in V1 and beyond.

---------------

### 19 Jan 2013 | [Switched linear encoding with rectified linear autoencoders](https://arxiv.org/abs/1301.3753) | [⬇️](https://arxiv.org/pdf/1301.3753)
*Leif Johnson and Craig Corcoran* 

  Several recent results in machine learning have established formal
connections between autoencoders---artificial neural network models that
attempt to reproduce their inputs---and other coding models like sparse coding
and K-means. This paper explores in depth an autoencoder model that is
constructed using rectified linear activations on its hidden units. Our
analysis builds on recent results to further unify the world of sparse linear
coding models. We provide an intuitive interpretation of the behavior of these
coding models and demonstrate this intuition using small, artificial datasets
with known distributions.

---------------

### 22 Feb 2023 | [Sparse, Geometric Autoencoder Models of V1](https://arxiv.org/abs/2302.11162) | [⬇️](https://arxiv.org/pdf/2302.11162)
*Jonathan Huml, Abiy Tasissa, Demba Ba* 

  The classical sparse coding model represents visual stimuli as a linear
combination of a handful of learned basis functions that are Gabor-like when
trained on natural image data. However, the Gabor-like filters learned by
classical sparse coding far overpredict well-tuned simple cell receptive field
(SCRF) profiles. A number of subsequent models have either discarded the sparse
dictionary learning framework entirely or have yet to take advantage of the
surge in unrolled, neural dictionary learning architectures. A key missing
theme of these updates is a stronger notion of \emph{structured sparsity}. We
propose an autoencoder architecture whose latent representations are
implicitly, locally organized for spectral clustering, which begets artificial
neurons better matched to observed primate data. The weighted-$\ell_1$ (WL)
constraint in the autoencoder objective function maintains core ideas of the
sparse coding framework, yet also offers a promising path to describe the
differentiation of receptive fields in terms of a discriminative hierarchy in
future work.

---------------

### 23 Nov 2017 | [SPINE: SParse Interpretable Neural Embeddings](https://arxiv.org/abs/1711.08792) | [⬇️](https://arxiv.org/pdf/1711.08792)
*Anant Subramanian, Danish Pruthi, Harsh Jhamtani, Taylor  Berg-Kirkpatrick, Eduard Hovy* 

  Prediction without justification has limited utility. Much of the success of
neural models can be attributed to their ability to learn rich, dense and
expressive representations. While these representations capture the underlying
complexity and latent trends in the data, they are far from being
interpretable. We propose a novel variant of denoising k-sparse autoencoders
that generates highly efficient and interpretable distributed word
representations (word embeddings), beginning with existing word representations
from state-of-the-art methods like GloVe and word2vec. Through large scale
human evaluation, we report that our resulting word embedddings are much more
interpretable than the original GloVe and word2vec embeddings. Moreover, our
embeddings outperform existing popular word embeddings on a diverse suite of
benchmark downstream tasks.

---------------

### 17 Aug 2022 | [Deep Autoencoder Model Construction Based on Pytorch](https://arxiv.org/abs/2208.08231) | [⬇️](https://arxiv.org/pdf/2208.08231)
*Junan Pan, Zhihao Zhao* 

  This paper proposes a deep autoencoder model based on Pytorch. This algorithm
introduces the idea of Pytorch into the auto-encoder, and randomly clears the
input weights connected to the hidden layer neurons with a certain probability,
so as to achieve the effect of sparse network, which is similar to the starting
point of the sparse auto-encoder. The new algorithm effectively solves the
problem of possible overfitting of the model and improves the accuracy of image
classification. Finally, the experiment is carried out, and the experimental
results are compared with ELM, RELM, AE, SAE, DAE.

---------------

### 09 Mar 2021 | [Deep learning of thermodynamics-aware reduced-order models from data](https://arxiv.org/abs/2007.03758) | [⬇️](https://arxiv.org/pdf/2007.03758)
*Quercus Hernandez, Alberto Badias, David Gonzalez, Francisco Chinesta,  Elias Cueto* 

  We present an algorithm to learn the relevant latent variables of a
large-scale discretized physical system and predict its time evolution using
thermodynamically-consistent deep neural networks. Our method relies on sparse
autoencoders, which reduce the dimensionality of the full order model to a set
of sparse latent variables with no prior knowledge of the coded space
dimensionality. Then, a second neural network is trained to learn the
metriplectic structure of those reduced physical variables and predict its time
evolution with a so-called structure-preserving neural network. This data-based
integrator is guaranteed to conserve the total energy of the system and the
entropy inequality, and can be applied to both conservative and dissipative
systems. The integrated paths can then be decoded to the original
full-dimensional manifold and be compared to the ground truth solution. This
method is tested with two examples applied to fluid and solid mechanics.

---------------

### 01 Sep 2022 | [Variational Sparse Coding with Learned Thresholding](https://arxiv.org/abs/2205.03665) | [⬇️](https://arxiv.org/pdf/2205.03665)
*Kion Fallah and Christopher J. Rozell* 

  Sparse coding strategies have been lauded for their parsimonious
representations of data that leverage low dimensional structure. However,
inference of these codes typically relies on an optimization procedure with
poor computational scaling in high-dimensional problems. For example, sparse
inference in the representations learned in the high-dimensional intermediary
layers of deep neural networks (DNNs) requires an iterative minimization to be
performed at each training step. As such, recent, quick methods in variational
inference have been proposed to infer sparse codes by learning a distribution
over the codes with a DNN. In this work, we propose a new approach to
variational sparse coding that allows us to learn sparse distributions by
thresholding samples, avoiding the use of problematic relaxations. We first
evaluate and analyze our method by training a linear generator, showing that it
has superior performance, statistical efficiency, and gradient estimation
compared to other sparse distributions. We then compare to a standard
variational autoencoder using a DNN generator on the Fashion MNIST and CelebA
datasets

---------------

### 08 Mar 2022 | [Encoding Event-Based Data With a Hybrid SNN Guided Variational  Auto-encoder in Neuromorphic Hardware](https://arxiv.org/abs/2104.00165) | [⬇️](https://arxiv.org/pdf/2104.00165)
*Kenneth Stewart, Andreea Danielescu, Timothy Shea, Emre Neftci* 

  Neuromorphic hardware equipped with learning capabilities can adapt to new,
real-time data. While models of Spiking Neural Networks (SNNs) can now be
trained using gradient descent to reach an accuracy comparable to equivalent
conventional neural networks, such learning often relies on external labels.
However, real-world data is unlabeled which can make supervised methods
inapplicable. To solve this problem, we propose a Hybrid Guided Variational
Autoencoder (VAE) which encodes event based data sensed by a Dynamic Vision
Sensor (DVS) into a latent space representation using an SNN. These
representations can be used as an embedding to measure data similarity and
predict labels in real-world data. We show that the Hybrid Guided-VAE achieves
87% classification accuracy on the DVSGesture dataset and it can encode the
sparse, noisy inputs into an interpretable latent space representation,
visualized through T-SNE plots. We also implement the encoder component of the
model on neuromorphic hardware and discuss the potential for our algorithm to
enable real-time learning from real-world event data.

---------------

### 23 Mar 2018 | [Deep Convolutional Compressed Sensing for LiDAR Depth Completion](https://arxiv.org/abs/1803.08949) | [⬇️](https://arxiv.org/pdf/1803.08949)
*Nathaniel Chodosh, Chaoyang Wang, Simon Lucey* 

  In this paper we consider the problem of estimating a dense depth map from a
set of sparse LiDAR points. We use techniques from compressed sensing and the
recently developed Alternating Direction Neural Networks (ADNNs) to create a
deep recurrent auto-encoder for this task. Our architecture internally performs
an algorithm for extracting multi-level convolutional sparse codes from the
input which are then used to make a prediction. Our results demonstrate that
with only two layers and 1800 parameters we are able to out perform all
previously published results, including deep networks with orders of magnitude
more parameters.

---------------

### 28 May 2019 | [Image classification using quantum inference on the D-Wave 2X](https://arxiv.org/abs/1905.13215) | [⬇️](https://arxiv.org/pdf/1905.13215)
*Nga T.T. Nguyen and Garrett T. Kenyon* 

  We use a quantum annealing D-Wave 2X computer to obtain solutions to NP-hard
sparse coding problems. To reduce the dimensionality of the sparse coding
problem to fit on the quantum D-Wave 2X hardware, we passed downsampled MNIST
images through a bottleneck autoencoder. To establish a benchmark for
classification performance on this reduced dimensional data set, we used an
AlexNet-like architecture implemented in TensorFlow, obtaining a classification
score of $94.54 \pm 0.7 \%$. As a control, we showed that the same AlexNet-like
architecture produced near-state-of-the-art classification performance $(\sim
99\%)$ on the original MNIST images. To obtain a set of optimized features for
inferring sparse representations of the reduced dimensional MNIST dataset, we
imprinted on a random set of $47$ image patches followed by an off-line
unsupervised learning algorithm using stochastic gradient descent to optimize
for sparse coding. Our single-layer of sparse coding matched the stride and
patch size of the first convolutional layer of the AlexNet-like deep neural
network and contained $47$ fully-connected features, $47$ being the maximum
number of dictionary elements that could be embedded onto the D-Wave $2$X
hardware. Recent work suggests that the optimal level of sparsity corresponds
to a critical value of the trade-off parameter associated with a putative
second order phase transition, an observation supported by a free energy
analysis of D-Wave energy states. When the sparse representations inferred by
the D-Wave $2$X were passed to a linear support vector machine, we obtained a
classification score of $95.68\%$. Thus, on this problem, we find that a
single-layer of quantum inference is able to outperform a standard deep neural
network architecture.

---------------

### 07 Mar 2013 | [On Robust Face Recognition via Sparse Encoding: the Good, the Bad, and  the Ugly](https://arxiv.org/abs/1303.1624) | [⬇️](https://arxiv.org/pdf/1303.1624)
*Yongkang Wong, Mehrtash T. Harandi, Conrad Sanderson* 

  In the field of face recognition, Sparse Representation (SR) has received
considerable attention during the past few years. Most of the relevant
literature focuses on holistic descriptors in closed-set identification
applications. The underlying assumption in SR-based methods is that each class
in the gallery has sufficient samples and the query lies on the subspace
spanned by the gallery of the same class. Unfortunately, such assumption is
easily violated in the more challenging face verification scenario, where an
algorithm is required to determine if two faces (where one or both have not
been seen before) belong to the same person. In this paper, we first discuss
why previous attempts with SR might not be applicable to verification problems.
We then propose an alternative approach to face verification via SR.
Specifically, we propose to use explicit SR encoding on local image patches
rather than the entire face. The obtained sparse signals are pooled via
averaging to form multiple region descriptors, which are then concatenated to
form an overall face descriptor. Due to the deliberate loss spatial relations
within each region (caused by averaging), the resulting descriptor is robust to
misalignment & various image deformations. Within the proposed framework, we
evaluate several SR encoding techniques: l1-minimisation, Sparse Autoencoder
Neural Network (SANN), and an implicit probabilistic technique based on
Gaussian Mixture Models. Thorough experiments on AR, FERET, exYaleB, BANCA and
ChokePoint datasets show that the proposed local SR approach obtains
considerably better and more robust performance than several previous
state-of-the-art holistic SR methods, in both verification and closed-set
identification problems. The experiments also show that l1-minimisation based
encoding has a considerably higher computational than the other techniques, but
leads to higher recognition rates.

---------------

### 13 Mar 2015 | [Sparse Code Formation with Linear Inhibition](https://arxiv.org/abs/1503.04115) | [⬇️](https://arxiv.org/pdf/1503.04115)
*Nam Do-Hoang Le* 

  Sparse code formation in the primary visual cortex (V1) has been inspiration
for many state-of-the-art visual recognition systems. To stimulate this
behavior, networks are trained networks under mathematical constraint of
sparsity or selectivity. In this paper, the authors exploit another approach
which uses lateral interconnections in feature learning networks. However,
instead of adding direct lateral interconnections among neurons, we introduce
an inhibitory layer placed right after normal encoding layer. This idea
overcomes the challenge of computational cost and complexity on lateral
networks while preserving crucial objective of sparse code formation. To
demonstrate this idea, we use sparse autoencoder as normal encoding layer and
apply inhibitory layer. Early experiments in visual recognition show relative
improvements over traditional approach on CIFAR-10 dataset. Moreover, simple
installment and training process using Hebbian rule allow inhibitory layer to
be integrated into existing networks, which enables further analysis in the
future.

---------------

### 26 Jun 2023 | [Autoencoders for Real-Time SUEP Detection](https://arxiv.org/abs/2306.13595) | [⬇️](https://arxiv.org/pdf/2306.13595)
*Simranjit Singh Chhibra, Nadezda Chernyavskaya, Benedikt Maier,  Maurzio Pierini and Syed Hasan* 

  Confining dark sectors with pseudo-conformal dynamics can produce Soft
Unclustered Energy Patterns, or SUEPs, at the Large Hadron Collider: the
production of dark quarks in proton-proton collisions leading to a dark shower
and the high-multiplicity production of dark hadrons. The final experimental
signature is spherically-symmetric energy deposits by an anomalously large
number of soft Standard Model particles with a transverse energy of a few
hundred MeV. The dominant background for the SUEP search, if it gets produced
via gluon-gluon fusion, is multi-jet QCD events. We have developed a deep
learning-based Anomaly Detection technique to reject QCD jets and identify any
anomalous signature, including SUEP, in real-time in the High-Level Trigger
system of the Compact Muon Solenoid experiment at the Large Hadron Collider. A
deep convolutional neural autoencoder network has been trained using QCD events
by taking transverse energy deposits in the inner tracker, electromagnetic
calorimeter, and hadron calorimeter sub-detectors as 3-channel image data. To
tackle the biggest challenge of the task, due to the sparse nature of the data:
only ~0.5% of the total ~300 k image pixels have non-zero values, a
non-standard loss function, the inverse of the so-called Dice Loss, has been
exploited. The trained autoencoder with learned spatial features of QCD jets
can detect 40% of the SUEP events, with a QCD event mistagging rate as low as
2%. The model inference time has been measured using the Intel CoreTM i5-9600KF
processor and found to be ~20 ms, which perfectly satisfies the High-Level
Trigger system's latency of O(100) ms. Given the virtue of the unsupervised
learning of the autoencoders, the trained model can be applied to any new
physics model that predicts an experimental signature anomalous to QCD jets.

---------------

### 23 Jan 2021 | [Improved Training of Sparse Coding Variational Autoencoder via Weight  Normalization](https://arxiv.org/abs/2101.09453) | [⬇️](https://arxiv.org/pdf/2101.09453)
*Linxing Preston Jiang, Luciano de la Iglesia* 

  Learning a generative model of visual information with sparse and
compositional features has been a challenge for both theoretical neuroscience
and machine learning communities. Sparse coding models have achieved great
success in explaining the receptive fields of mammalian primary visual cortex
with sparsely activated latent representation. In this paper, we focus on a
recently proposed model, sparse coding variational autoencoder (SVAE) (Barello
et al., 2018), and show that the end-to-end training scheme of SVAE leads to a
large group of decoding filters not fully optimized with noise-like receptive
fields. We propose a few heuristics to improve the training of SVAE and show
that a unit $L_2$ norm constraint on the decoder is critical to produce sparse
coding filters. Such normalization can be considered as local lateral
inhibition in the cortex. We verify this claim empirically on both natural
image patches and MNIST dataset and show that projection of the filters onto
unit norm drastically increases the number of active filters. Our results
highlight the importance of weight normalization for learning sparse
representation from data and suggest a new way of reducing the number of
inactive latent components in VAE learning.

---------------

### 09 Feb 2018 | [Relational Autoencoder for Feature Extraction](https://arxiv.org/abs/1802.03145) | [⬇️](https://arxiv.org/pdf/1802.03145)
*Qinxue Meng, Daniel Catchpoole, David Skillicorn, Paul J. Kennedy* 

  Feature extraction becomes increasingly important as data grows high
dimensional. Autoencoder as a neural network based feature extraction method
achieves great success in generating abstract features of high dimensional
data. However, it fails to consider the relationships of data samples which may
affect experimental results of using original and new features. In this paper,
we propose a Relation Autoencoder model considering both data features and
their relationships. We also extend it to work with other major autoencoder
models including Sparse Autoencoder, Denoising Autoencoder and Variational
Autoencoder. The proposed relational autoencoder models are evaluated on a set
of benchmark datasets and the experimental results show that considering data
relationships can generate more robust features which achieve lower
construction loss and then lower error rate in further classification compared
to the other variants of autoencoders.

---------------

### 19 Nov 2022 | [Bayesian autoencoders for data-driven discovery of coordinates,  governing equations and fundamental constants](https://arxiv.org/abs/2211.10575) | [⬇️](https://arxiv.org/pdf/2211.10575)
*L. Mars Gao and J. Nathan Kutz* 

  Recent progress in autoencoder-based sparse identification of nonlinear
dynamics (SINDy) under $\ell_1$ constraints allows joint discoveries of
governing equations and latent coordinate systems from spatio-temporal data,
including simulated video frames. However, it is challenging for $\ell_1$-based
sparse inference to perform correct identification for real data due to the
noisy measurements and often limited sample sizes. To address the data-driven
discovery of physics in the low-data and high-noise regimes, we propose
Bayesian SINDy autoencoders, which incorporate a hierarchical Bayesian
sparsifying prior: Spike-and-slab Gaussian Lasso. Bayesian SINDy autoencoder
enables the joint discovery of governing equations and coordinate systems with
a theoretically guaranteed uncertainty estimate. To resolve the challenging
computational tractability of the Bayesian hierarchical setting, we adapt an
adaptive empirical Bayesian method with Stochatic gradient Langevin dynamics
(SGLD) which gives a computationally tractable way of Bayesian posterior
sampling within our framework. Bayesian SINDy autoencoder achieves better
physics discovery with lower data and fewer training epochs, along with valid
uncertainty quantification suggested by the experimental studies. The Bayesian
SINDy autoencoder can be applied to real video data, with accurate physics
discovery which correctly identifies the governing equation and provides a
close estimate for standard physics constants like gravity $g$, for example, in
videos of a pendulum.

---------------

### 19 Jun 2019 | [A Novel Deep Neural Network Based Approach for Sparse Code Multiple  Access](https://arxiv.org/abs/1906.03169) | [⬇️](https://arxiv.org/pdf/1906.03169)
*Jinzhi Lin, Shengzhong Feng, Zhile Yang, Yun Zhang, Yong Zhang* 

  Sparse code multiple access (SCMA) has been one of non-orthogonal multiple
access (NOMA) schemes aiming to support high spectral efficiency and ubiquitous
access requirements for 5G wireless communication networks. Conventional SCMA
approaches are confronting remarkable challenges in designing low complexity
high accuracy decoding algorithm and constructing optimum codebooks.
Fortunately, the recent spotlighted deep learning technologies are of
significant potentials in solving many communication engineering problems.
Inspired by this, we explore approaches to improve SCMA performances with the
help of deep learning methods. We propose and train a deep neural network (DNN)
called DL-SCMA to learn to decode SCMA modulated signals corrupted by additive
white Gaussian noise (AWGN). Putting encoding and decoding together, an
autoencoder called AE-SCMA is established and trained to generate optimal SCMA
codewords and reconstruct original bits. Furthermore, by manipulating the
mapping vectors, an autoencoder is able to generalize SCMA, thus a dense code
multiple access (DCMA) scheme is proposed. Simulations show that the DNN SCMA
decoder significantly outperforms the conventional message passing algorithm
(MPA) in terms of bit error rate (BER), symbol error rate (SER) and
computational complexity, and AE-SCMA also demonstrates better performances via
constructing better SCMA codebooks. The performance of deep learning aided DCMA
is superior to the SCMA.

---------------
**Date:** 18 Oct 2020

**Title:** Deep Residual Autoencoders for Expectation Maximization-inspired  Dictionary Learning

**Abstract Link:** [https://arxiv.org/abs/1904.08827](https://arxiv.org/abs/1904.08827)

**PDF Link:** [https://arxiv.org/pdf/1904.08827](https://arxiv.org/pdf/1904.08827)

---

**Date:** 18 Aug 2020

**Title:** Learning the Structure of Auto-Encoding Recommenders

**Abstract Link:** [https://arxiv.org/abs/2008.07956](https://arxiv.org/abs/2008.07956)

**PDF Link:** [https://arxiv.org/pdf/2008.07956](https://arxiv.org/pdf/2008.07956)

---

**Date:** 30 Apr 2020

**Title:** Binary autoencoder with random binary weights

**Abstract Link:** [https://arxiv.org/abs/2004.14717](https://arxiv.org/abs/2004.14717)

**PDF Link:** [https://arxiv.org/pdf/2004.14717](https://arxiv.org/pdf/2004.14717)

---

**Date:** 30 Nov 2023

**Title:** Clustering Inductive Biases with Unrolled Networks

**Abstract Link:** [https://arxiv.org/abs/2402.10213](https://arxiv.org/abs/2402.10213)

**PDF Link:** [https://arxiv.org/pdf/2402.10213](https://arxiv.org/pdf/2402.10213)

---

**Date:** 19 Jan 2013

**Title:** Switched linear encoding with rectified linear autoencoders

**Abstract Link:** [https://arxiv.org/abs/1301.3753](https://arxiv.org/abs/1301.3753)

**PDF Link:** [https://arxiv.org/pdf/1301.3753](https://arxiv.org/pdf/1301.3753)

---

**Date:** 22 Feb 2023

**Title:** Sparse, Geometric Autoencoder Models of V1

**Abstract Link:** [https://arxiv.org/abs/2302.11162](https://arxiv.org/abs/2302.11162)

**PDF Link:** [https://arxiv.org/pdf/2302.11162](https://arxiv.org/pdf/2302.11162)

---

**Date:** 23 Nov 2017

**Title:** SPINE: SParse Interpretable Neural Embeddings

**Abstract Link:** [https://arxiv.org/abs/1711.08792](https://arxiv.org/abs/1711.08792)

**PDF Link:** [https://arxiv.org/pdf/1711.08792](https://arxiv.org/pdf/1711.08792)

---

**Date:** 17 Aug 2022

**Title:** Deep Autoencoder Model Construction Based on Pytorch

**Abstract Link:** [https://arxiv.org/abs/2208.08231](https://arxiv.org/abs/2208.08231)

**PDF Link:** [https://arxiv.org/pdf/2208.08231](https://arxiv.org/pdf/2208.08231)

---

**Date:** 09 Mar 2021

**Title:** Deep learning of thermodynamics-aware reduced-order models from data

**Abstract Link:** [https://arxiv.org/abs/2007.03758](https://arxiv.org/abs/2007.03758)

**PDF Link:** [https://arxiv.org/pdf/2007.03758](https://arxiv.org/pdf/2007.03758)

---

**Date:** 01 Sep 2022

**Title:** Variational Sparse Coding with Learned Thresholding

**Abstract Link:** [https://arxiv.org/abs/2205.03665](https://arxiv.org/abs/2205.03665)

**PDF Link:** [https://arxiv.org/pdf/2205.03665](https://arxiv.org/pdf/2205.03665)

---

**Date:** 08 Mar 2022

**Title:** Encoding Event-Based Data With a Hybrid SNN Guided Variational  Auto-encoder in Neuromorphic Hardware

**Abstract Link:** [https://arxiv.org/abs/2104.00165](https://arxiv.org/abs/2104.00165)

**PDF Link:** [https://arxiv.org/pdf/2104.00165](https://arxiv.org/pdf/2104.00165)

---

**Date:** 23 Mar 2018

**Title:** Deep Convolutional Compressed Sensing for LiDAR Depth Completion

**Abstract Link:** [https://arxiv.org/abs/1803.08949](https://arxiv.org/abs/1803.08949)

**PDF Link:** [https://arxiv.org/pdf/1803.08949](https://arxiv.org/pdf/1803.08949)

---

**Date:** 28 May 2019

**Title:** Image classification using quantum inference on the D-Wave 2X

**Abstract Link:** [https://arxiv.org/abs/1905.13215](https://arxiv.org/abs/1905.13215)

**PDF Link:** [https://arxiv.org/pdf/1905.13215](https://arxiv.org/pdf/1905.13215)

---

**Date:** 07 Mar 2013

**Title:** On Robust Face Recognition via Sparse Encoding: the Good, the Bad, and  the Ugly

**Abstract Link:** [https://arxiv.org/abs/1303.1624](https://arxiv.org/abs/1303.1624)

**PDF Link:** [https://arxiv.org/pdf/1303.1624](https://arxiv.org/pdf/1303.1624)

---

**Date:** 13 Mar 2015

**Title:** Sparse Code Formation with Linear Inhibition

**Abstract Link:** [https://arxiv.org/abs/1503.04115](https://arxiv.org/abs/1503.04115)

**PDF Link:** [https://arxiv.org/pdf/1503.04115](https://arxiv.org/pdf/1503.04115)

---

**Date:** 26 Jun 2023

**Title:** Autoencoders for Real-Time SUEP Detection

**Abstract Link:** [https://arxiv.org/abs/2306.13595](https://arxiv.org/abs/2306.13595)

**PDF Link:** [https://arxiv.org/pdf/2306.13595](https://arxiv.org/pdf/2306.13595)

---

**Date:** 23 Jan 2021

**Title:** Improved Training of Sparse Coding Variational Autoencoder via Weight  Normalization

**Abstract Link:** [https://arxiv.org/abs/2101.09453](https://arxiv.org/abs/2101.09453)

**PDF Link:** [https://arxiv.org/pdf/2101.09453](https://arxiv.org/pdf/2101.09453)

---

**Date:** 09 Feb 2018

**Title:** Relational Autoencoder for Feature Extraction

**Abstract Link:** [https://arxiv.org/abs/1802.03145](https://arxiv.org/abs/1802.03145)

**PDF Link:** [https://arxiv.org/pdf/1802.03145](https://arxiv.org/pdf/1802.03145)

---

**Date:** 19 Nov 2022

**Title:** Bayesian autoencoders for data-driven discovery of coordinates,  governing equations and fundamental constants

**Abstract Link:** [https://arxiv.org/abs/2211.10575](https://arxiv.org/abs/2211.10575)

**PDF Link:** [https://arxiv.org/pdf/2211.10575](https://arxiv.org/pdf/2211.10575)

---

**Date:** 19 Jun 2019

**Title:** A Novel Deep Neural Network Based Approach for Sparse Code Multiple  Access

**Abstract Link:** [https://arxiv.org/abs/1906.03169](https://arxiv.org/abs/1906.03169)

**PDF Link:** [https://arxiv.org/pdf/1906.03169](https://arxiv.org/pdf/1906.03169)

---

