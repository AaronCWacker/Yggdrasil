AI Team Scaling 📊

### 🔎 AI Team Scaling 📊



# AI Scaling 📊

AI Scaling is the process of increasing the capacity of an AI system to handle larger amounts of data or more complex tasks. This can be done by adding more resources, such as computing power or memory, to the system, or by optimizing the algorithms and models used in the system to make them more efficient. AI scaling is important for businesses and organizations that need to process large amounts of data or perform complex AI tasks, as it allows them to do so more quickly and efficiently.

There are several ways to scale an AI system, including:

1. Vertical scaling: This involves adding more resources, such as CPU cores or memory, to a single machine. This can be useful for increasing the capacity of a system that is already running efficiently, but it can become expensive as the machine reaches its physical limits.
2. Horizontal scaling: This involves adding more machines to a system, either by adding more nodes to a cluster or by distributing the workload across multiple machines. This can be a more cost-effective way to scale an AI system, as it allows you to add resources incrementally as needed.
3. Optimization: This involves improving the efficiency of the algorithms and models used in the system. This can be done by using techniques such as pruning, quantization, or knowledge distillation to make the models smaller and faster, or by using more efficient algorithms or data structures.
4. Parallelization: This involves dividing the workload into smaller tasks that can be processed in parallel. This can be done using techniques such as data parallelism, model parallelism, or pipeline parallelism.

Overall, AI scaling is an important consideration for businesses and organizations that need to process large amounts of data or perform complex AI tasks. By scaling their AI systems, they can improve their performance, reduce their costs, and stay competitive in their industries.</s>
# 🩺🔍 Search Results
### 09 Feb 2024 | [Scalable Interactive Machine Learning for Future Command and Control](https://arxiv.org/abs/2402.06501) | [⬇️](https://arxiv.org/pdf/2402.06501)
*Anna Madison, Ellen Novoseller, Vinicius G. Goecks, Benjamin T. Files,  Nicholas Waytowich, Alfred Yu, Vernon J. Lawhern, Steven Thurman, Christopher  Kelshaw, Kaleb McDowell* 

  Future warfare will require Command and Control (C2) personnel to make
decisions at shrinking timescales in complex and potentially ill-defined
situations. Given the need for robust decision-making processes and
decision-support tools, integration of artificial and human intelligence holds
the potential to revolutionize the C2 operations process to ensure adaptability
and efficiency in rapidly changing operational environments. We propose to
leverage recent promising breakthroughs in interactive machine learning, in
which humans can cooperate with machine learning algorithms to guide machine
learning algorithm behavior. This paper identifies several gaps in
state-of-the-art science and technology that future work should address to
extend these approaches to function in complex C2 contexts. In particular, we
describe three research focus areas that together, aim to enable scalable
interactive machine learning (SIML): 1) developing human-AI interaction
algorithms to enable planning in complex, dynamic situations; 2) fostering
resilient human-AI teams through optimizing roles, configurations, and trust;
and 3) scaling algorithms and human-AI teams for flexibility across a range of
potential contexts and situations.

---------------

### 06 Nov 2023 | [A Theory for Emergence of Complex Skills in Language Models](https://arxiv.org/abs/2307.15936) | [⬇️](https://arxiv.org/pdf/2307.15936)
*Sanjeev Arora, Anirudh Goyal* 

  A major driver of AI products today is the fact that new skills emerge in
language models when their parameter set and training corpora are scaled up.
This phenomenon is poorly understood, and a mechanistic explanation via
mathematical analysis of gradient-based training seems difficult. The current
paper takes a different approach, analysing emergence using the famous (and
empirical) Scaling Laws of LLMs and a simple statistical framework.
Contributions include: (a) A statistical framework that relates cross-entropy
loss of LLMs to competence on the basic skills that underlie language tasks.
(b) Mathematical analysis showing that the Scaling Laws imply a strong form of
inductive bias that allows the pre-trained model to learn very efficiently. We
informally call this {\em slingshot generalization} since naively viewed it
appears to give competence levels at skills that violate usual generalization
theory. (c) A key example of slingshot generalization, that competence at
executing tasks involving $k$-tuples of skills emerges essentially at the same
scaling and same rate as competence on the elementary skills themselves.

---------------

### 28 Jun 2023 | [ViP: A Differentially Private Foundation Model for Computer Vision](https://arxiv.org/abs/2306.08842) | [⬇️](https://arxiv.org/pdf/2306.08842)
*Yaodong Yu and Maziar Sanjabi and Yi Ma and Kamalika Chaudhuri and  Chuan Guo* 

  Artificial intelligence (AI) has seen a tremendous surge in capabilities
thanks to the use of foundation models trained on internet-scale data. On the
flip side, the uncurated nature of internet-scale data also poses significant
privacy and legal risks, as they often contain personal information or
copyrighted material that should not be trained on without permission. In this
work, we propose as a mitigation measure a recipe to train foundation vision
models with differential privacy (DP) guarantee. We identify masked
autoencoders as a suitable learning algorithm that aligns well with DP-SGD, and
train ViP -- a Vision transformer with differential Privacy -- under a strict
privacy budget of $\epsilon=8$ on the LAION400M dataset. We evaluate the
quality of representation learned by ViP using standard downstream vision
tasks; in particular, ViP achieves a (non-private) linear probing accuracy of
$55.7\%$ on ImageNet, comparable to that of end-to-end trained AlexNet (trained
and evaluated on ImageNet). Our result suggests that scaling to internet-scale
data can be practical for private learning. Code is available at
\url{https://github.com/facebookresearch/ViP-MAE}.

---------------

### 05 Jul 2023 | [Scaling Laws Do Not Scale](https://arxiv.org/abs/2307.03201) | [⬇️](https://arxiv.org/pdf/2307.03201)
*Fernando Diaz and Michael Madaio* 

  Recent work has proposed a power law relationship, referred to as ``scaling
laws,'' between the performance of artificial intelligence (AI) models and
aspects of those models' design (e.g., dataset size). In other words, as the
size of a dataset (or model parameters, etc) increases, the performance of a
given model trained on that dataset will correspondingly increase. However,
while compelling in the aggregate, this scaling law relationship overlooks the
ways that metrics used to measure performance may be precarious and contested,
or may not correspond with how different groups of people may perceive the
quality of models' output. In this paper, we argue that as the size of datasets
used to train large AI models grows, the number of distinct communities
(including demographic groups) whose data is included in a given dataset is
likely to grow, each of whom may have different values. As a result, there is
an increased risk that communities represented in a dataset may have values or
preferences not captured by (or in the worst case, at odds with) the metrics
used to evaluate model performance for scaling laws. We end the paper with
implications for AI scaling laws -- that models may not, in fact, continue to
improve as the datasets get larger -- at least not for all people or
communities impacted by those models.

---------------

### 16 Mar 2021 | [Technical Report: Scalable Active Information Acquisition for  Multi-Robot Systems](https://arxiv.org/abs/2103.09364) | [⬇️](https://arxiv.org/pdf/2103.09364)
*Yiannis Kantaros, George J. Pappas* 

  This paper proposes a novel highly scalable non-myopic planning algorithm for
multi-robot Active Information Acquisition (AIA) tasks. AIA scenarios include
target localization and tracking, active SLAM, surveillance, environmental
monitoring and others. The objective is to compute control policies for
multiple robots which minimize the accumulated uncertainty of a static hidden
state over an a priori unknown horizon. The majority of existing AIA approaches
are centralized and, therefore, face scaling challenges. To mitigate this
issue, we propose an online algorithm that relies on decomposing the AIA task
into local tasks via a dynamic space-partitioning method. The local subtasks
are formulated online and require the robots to switch between exploration and
active information gathering roles depending on their functionality in the
environment. The switching process is tightly integrated with optimizing
information gathering giving rise to a hybrid control approach. We show that
the proposed decomposition-based algorithm is probabilistically complete for
homogeneous sensor teams and under linearity and Gaussian assumptions. We
provide extensive simulation results that show that the proposed algorithm can
address large-scale estimation tasks that are computationally challenging to
solve using existing centralized approaches.

---------------

### 06 Mar 2013 | [A Study of Scaling Issues in Bayesian Belief Networks for Ship  Classification](https://arxiv.org/abs/1303.1457) | [⬇️](https://arxiv.org/pdf/1303.1457)
*Scott A. Musman, L. W. Chang* 

  The problems associated with scaling involve active and challenging research
topics in the area of artificial intelligence. The purpose is to solve real
world problems by means of AI technologies, in cases where the complexity of
representation of the real world problem is potentially combinatorial. In this
paper, we present a novel approach to cope with the scaling issues in Bayesian
belief networks for ship classification. The proposed approach divides the
conceptual model of a complex ship classification problem into a set of small
modules that work together to solve the classification problem while preserving
the functionality of the original model. The possible ways of explaining sensor
returns (e.g., the evidence) for some features, such as portholes along the
length of a ship, are sometimes combinatorial. Thus, using an exhaustive
approach, which entails the enumeration of all possible explanations, is
impractical for larger problems. We present a network structure (referred to as
Sequential Decomposition, SD) in which each observation is associated with a
set of legitimate outcomes which are consistent with the explanation of each
observed piece of evidence. The results show that the SD approach allows one to
represent feature-observation relations in a manageable way and achieve the
same explanatory power as an exhaustive approach.

---------------

### 30 Apr 2020 | [The 4th AI City Challenge](https://arxiv.org/abs/2004.14619) | [⬇️](https://arxiv.org/pdf/2004.14619)
*Milind Naphade, Shuo Wang, David Anastasiu, Zheng Tang, Ming-Ching  Chang, Xiaodong Yang, Liang Zheng, Anuj Sharma, Rama Chellappa, Pranamesh  Chakraborty* 

  The AI City Challenge was created to accelerate intelligent video analysis
that helps make cities smarter and safer. Transportation is one of the largest
segments that can benefit from actionable insights derived from data captured
by sensors, where computer vision and deep learning have shown promise in
achieving large-scale practical deployment. The 4th annual edition of the AI
City Challenge has attracted 315 participating teams across 37 countries, who
leveraged city-scale real traffic data and high-quality synthetic data to
compete in four challenge tracks. Track 1 addressed video-based automatic
vehicle counting, where the evaluation is conducted on both algorithmic
effectiveness and computational efficiency. Track 2 addressed city-scale
vehicle re-identification with augmented synthetic data to substantially
increase the training set for the task. Track 3 addressed city-scale
multi-target multi-camera vehicle tracking. Track 4 addressed traffic anomaly
detection. The evaluation system shows two leader boards, in which a general
leader board shows all submitted results, and a public leader board shows
results limited to our contest participation rules, that teams are not allowed
to use external data in their work. The public leader board shows results more
close to real-world situations where annotated data are limited. Our results
show promise that AI technology can enable smarter and safer transportation
systems.

---------------

### 17 May 2023 | [The Jaseci Programming Paradigm and Runtime Stack: Building Scale-out  Production Applications Easy and Fast](https://arxiv.org/abs/2305.09864) | [⬇️](https://arxiv.org/pdf/2305.09864)
*Jason Mars, Yiping Kang, Roland Daynauth, Baichuan Li, Ashish  Mahendra, Krisztian Flautner, Lingjia Tang* 

  Today's production scale-out applications include many sub-application
components, such as storage backends, logging infrastructure and AI models.
These components have drastically different characteristics, are required to
work in collaboration, and interface with each other as microservices. This
leads to increasingly high complexity in developing, optimizing, configuring,
and deploying scale-out applications, raising the barrier to entry for most
individuals and small teams. We developed a novel co-designed runtime system,
Jaseci, and programming language, Jac, which aims to reduce this complexity.
The key design principle throughout Jaseci's design is to raise the level of
abstraction by moving as much of the scale-out data management, microservice
componentization, and live update complexity into the runtime stack to be
automated and optimized automatically. We use real-world AI applications to
demonstrate Jaseci's benefit for application performance and developer
productivity.

---------------

### 24 Feb 2021 | [Wirelessly Powered Federated Edge Learning: Optimal Tradeoffs Between  Convergence and Power Transfer](https://arxiv.org/abs/2102.12357) | [⬇️](https://arxiv.org/pdf/2102.12357)
*Qunsong Zeng, Yuqing Du, Kaibin Huang* 

  Federated edge learning (FEEL) is a widely adopted framework for training an
artificial intelligence (AI) model distributively at edge devices to leverage
their data while preserving their data privacy. The execution of a power-hungry
learning task at energy-constrained devices is a key challenge confronting the
implementation of FEEL. To tackle the challenge, we propose the solution of
powering devices using wireless power transfer (WPT). To derive guidelines on
deploying the resultant wirelessly powered FEEL (WP-FEEL) system, this work
aims at the derivation of the tradeoff between the model convergence and the
settings of power sources in two scenarios: 1) the transmission power and
density of power-beacons (dedicated charging stations) if they are deployed, or
otherwise 2) the transmission power of a server (access-point). The development
of the proposed analytical framework relates the accuracy of distributed
stochastic gradient estimation to the WPT settings, the randomness in both
communication and WPT links, and devices' computation capacities. Furthermore,
the local-computation at devices (i.e., mini-batch size and processor clock
frequency) is optimized to efficiently use the harvested energy for gradient
estimation. The resultant learning-WPT tradeoffs reveal the simple scaling laws
of the model-convergence rate with respect to the transferred energy as well as
the devices' computational energy efficiencies. The results provide useful
guidelines on WPT provisioning to provide a guaranteer on learning performance.
They are corroborated by experimental results using a real dataset.

---------------

### 16 Jan 2020 | [ScaIL: Classifier Weights Scaling for Class Incremental Learning](https://arxiv.org/abs/2001.05755) | [⬇️](https://arxiv.org/pdf/2001.05755)
*Eden Belouadah and Adrian Popescu* 

  Incremental learning is useful if an AI agent needs to integrate data from a
stream. The problem is non trivial if the agent runs on a limited computational
budget and has a bounded memory of past data. In a deep learning approach, the
constant computational budget requires the use of a fixed architecture for all
incremental states. The bounded memory generates data imbalance in favor of new
classes and a prediction bias toward them appears. This bias is commonly
countered by introducing a data balancing step in addition to the basic network
training. We depart from this approach and propose simple but efficient scaling
of past class classifier weights to make them more comparable to those of new
classes. Scaling exploits incremental state level statistics and is applied to
the classifiers learned in the initial state of classes in order to profit from
all their available data. We also question the utility of the widely used
distillation loss component of incremental learning algorithms by comparing it
to vanilla fine tuning in presence of a bounded memory. Evaluation is done
against competitive baselines using four public datasets. Results show that the
classifier weights scaling and the removal of the distillation are both
beneficial.

---------------

### 20 Mar 2023 | [PanGu-{\Sigma}: Towards Trillion Parameter Language Model with Sparse  Heterogeneous Computing](https://arxiv.org/abs/2303.10845) | [⬇️](https://arxiv.org/pdf/2303.10845)
*Xiaozhe Ren, Pingyi Zhou, Xinfan Meng, Xinjing Huang, Yadao Wang,  Weichao Wang, Pengfei Li, Xiaoda Zhang, Alexander Podolskiy, Grigory  Arshinov, Andrey Bout, Irina Piontkovskaya, Jiansheng Wei, Xin Jiang, Teng  Su, Qun Liu, Jun Yao* 

  The scaling of large language models has greatly improved natural language
understanding, generation, and reasoning. In this work, we develop a system
that trained a trillion-parameter language model on a cluster of Ascend 910 AI
processors and MindSpore framework, and present the language model with 1.085T
parameters named PanGu-{\Sigma}. With parameter inherent from PanGu-{\alpha},
we extend the dense Transformer model to sparse one with Random Routed Experts
(RRE), and efficiently train the model over 329B tokens by using Expert
Computation and Storage Separation(ECSS). This resulted in a 6.3x increase in
training throughput through heterogeneous computing. Our experimental findings
show that PanGu-{\Sigma} provides state-of-the-art performance in zero-shot
learning of various Chinese NLP downstream tasks. Moreover, it demonstrates
strong abilities when fine-tuned in application data of open-domain dialogue,
question answering, machine translation and code generation.

---------------

### 08 Dec 2021 | [An AI-based Solution for Enhancing Delivery of Digital Learning for  Future Teachers](https://arxiv.org/abs/2112.01229) | [⬇️](https://arxiv.org/pdf/2112.01229)
*Yong-Bin Kang, Abdur Rahim Mohammad Forkan, Prem Prakash Jayaraman,  Natalie Wieland, Elizabeth Kollias, Hung Du, Steven Thomson, Yuan-Fang Li* 

  There has been a recent and rapid shift to digital learning hastened by the
pandemic but also influenced by ubiquitous availability of digital tools and
platforms now, making digital learning ever more accessible. An integral and
one of the most difficult part of scaling digital learning and teaching is to
be able to assess learner's knowledge and competency. An educator can record a
lecture or create digital content that can be delivered to thousands of
learners but assessing learners is extremely time consuming. In the paper, we
propose an Artificial Intelligence (AI)-based solution namely VidVersityQG for
generating questions automatically from pre-recorded video lectures. The
solution can automatically generate different types of assessment questions
(including short answer, multiple choice, true/false and fill in the blank
questions) based on contextual and semantic information inferred from the
videos. The proposed solution takes a human-centred approach, wherein teachers
are provided the ability to modify/edit any AI generated questions. This
approach encourages trust and engagement of teachers in the use and
implementation of AI in education. The AI-based solution was evaluated for its
accuracy in generating questions by 7 experienced teaching professionals and
117 education videos from multiple domains provided to us by our industry
partner VidVersity. VidVersityQG solution showed promising results in
generating high-quality questions automatically from video thereby
significantly reducing the time and effort for educators in manual question
generation.

---------------

### 24 May 2021 | [The 5th AI City Challenge](https://arxiv.org/abs/2104.12233) | [⬇️](https://arxiv.org/pdf/2104.12233)
*Milind Naphade, Shuo Wang, David C. Anastasiu, Zheng Tang, Ming-Ching  Chang, Xiaodong Yang, Yue Yao, Liang Zheng, Pranamesh Chakraborty, Christian  E. Lopez, Anuj Sharma, Qi Feng, Vitaly Ablavsky, Stan Sclaroff* 

  The AI City Challenge was created with two goals in mind: (1) pushing the
boundaries of research and development in intelligent video analysis for
smarter cities use cases, and (2) assessing tasks where the level of
performance is enough to cause real-world adoption. Transportation is a segment
ripe for such adoption. The fifth AI City Challenge attracted 305 participating
teams across 38 countries, who leveraged city-scale real traffic data and
high-quality synthetic data to compete in five challenge tracks. Track 1
addressed video-based automatic vehicle counting, where the evaluation being
conducted on both algorithmic effectiveness and computational efficiency. Track
2 addressed city-scale vehicle re-identification with augmented synthetic data
to substantially increase the training set for the task. Track 3 addressed
city-scale multi-target multi-camera vehicle tracking. Track 4 addressed
traffic anomaly detection. Track 5 was a new track addressing vehicle retrieval
using natural language descriptions. The evaluation system shows a general
leader board of all submitted results, and a public leader board of results
limited to the contest participation rules, where teams are not allowed to use
external data in their work. The public leader board shows results more close
to real-world situations where annotated data is limited. Results show the
promise of AI in Smarter Transportation. State-of-the-art performance for some
tasks shows that these technologies are ready for adoption in real-world
systems.

---------------

### 10 Feb 2024 | [A Tale of Tails: Model Collapse as a Change of Scaling Laws](https://arxiv.org/abs/2402.07043) | [⬇️](https://arxiv.org/pdf/2402.07043)
*Elvis Dohmatob, Yunzhen Feng, Pu Yang, Francois Charton and Julia  Kempe* 

  As AI model size grows, neural scaling laws have become a crucial tool to
predict the improvements of large models when increasing capacity and the size
of original (human or natural) training data. Yet, the widespread use of
popular models means that the ecosystem of online data and text will co-evolve
to progressively contain increased amounts of synthesized data. In this paper
we ask: How will the scaling laws change in the inevitable regime where
synthetic data makes its way into the training corpus? Will future models,
still improve, or be doomed to degenerate up to total (model) collapse? We
develop a theoretical framework of model collapse through the lens of scaling
laws. We discover a wide range of decay phenomena, analyzing loss of scaling,
shifted scaling with number of generations, the ''un-learning" of skills, and
grokking when mixing human and synthesized data. Our theory is validated by
large-scale experiments with a transformer on an arithmetic task and text
generation using the large language model Llama2.

---------------

### 15 Mar 2021 | [AIPerf: Automated machine learning as an AI-HPC benchmark](https://arxiv.org/abs/2008.07141) | [⬇️](https://arxiv.org/pdf/2008.07141)
*Zhixiang Ren, Yongheng Liu, Tianhui Shi, Lei Xie, Yue Zhou, Jidong  Zhai, Youhui Zhang, Yunquan Zhang, Wenguang Chen* 

  The plethora of complex artificial intelligence (AI) algorithms and available
high performance computing (HPC) power stimulates the expeditious development
of AI components with heterogeneous designs. Consequently, the need for
cross-stack performance benchmarking of AI-HPC systems emerges rapidly. The de
facto HPC benchmark LINPACK can not reflect AI computing power and I/O
performance without representative workload. The current popular AI benchmarks
like MLPerf have fixed problem size therefore limited scalability. To address
these issues, we propose an end-to-end benchmark suite utilizing automated
machine learning (AutoML), which not only represents real AI scenarios, but
also is auto-adaptively scalable to various scales of machines. We implement
the algorithms in a highly parallel and flexible way to ensure the efficiency
and optimization potential on diverse systems with customizable configurations.
We utilize operations per second (OPS), which is measured in an analytical and
systematic approach, as the major metric to quantify the AI performance. We
perform evaluations on various systems to ensure the benchmark's stability and
scalability, from 4 nodes with 32 NVIDIA Tesla T4 (56.1 Tera-OPS measured), up
to 512 nodes with 4096 Huawei Ascend 910 (194.53 Peta-OPS measured), and the
results show near-linear weak scalability. With flexible workload and single
metric, our benchmark can scale and rank AI-HPC easily.

---------------

### 16 Dec 2022 | [GatorTron: A Large Clinical Language Model to Unlock Patient Information  from Unstructured Electronic Health Records](https://arxiv.org/abs/2203.03540) | [⬇️](https://arxiv.org/pdf/2203.03540)
*Xi Yang, Aokun Chen, Nima PourNejatian, Hoo Chang Shin, Kaleb E Smith,  Christopher Parisien, Colin Compas, Cheryl Martin, Mona G Flores, Ying Zhang,  Tanja Magoc, Christopher A Harle, Gloria Lipori, Duane A Mitchell, William R  Hogan, Elizabeth A Shenkman, Jiang Bian, Yonghui Wu* 

  There is an increasing interest in developing artificial intelligence (AI)
systems to process and interpret electronic health records (EHRs). Natural
language processing (NLP) powered by pretrained language models is the key
technology for medical AI systems utilizing clinical narratives. However, there
are few clinical language models, the largest of which trained in the clinical
domain is comparatively small at 110 million parameters (compared with billions
of parameters in the general domain). It is not clear how large clinical
language models with billions of parameters can help medical AI systems utilize
unstructured EHRs. In this study, we develop from scratch a large clinical
language model - GatorTron - using >90 billion words of text (including >82
billion words of de-identified clinical text) and systematically evaluate it on
5 clinical NLP tasks including clinical concept extraction, medical relation
extraction, semantic textual similarity, natural language inference (NLI), and
medical question answering (MQA). We examine how (1) scaling up the number of
parameters and (2) scaling up the size of the training data could benefit these
NLP tasks. GatorTron models scale up the clinical language model from 110
million to 8.9 billion parameters and improve 5 clinical NLP tasks (e.g., 9.6%
and 9.5% improvement in accuracy for NLI and MQA), which can be applied to
medical AI systems to improve healthcare delivery. The GatorTron models are
publicly available at:
https://catalog.ngc.nvidia.com/orgs/nvidia/teams/clara/models/gatortron_og.

---------------

### 04 Sep 2018 | [PFDet: 2nd Place Solution to Open Images Challenge 2018 Object Detection  Track](https://arxiv.org/abs/1809.00778) | [⬇️](https://arxiv.org/pdf/1809.00778)
*Takuya Akiba, Tommi Kerola, Yusuke Niitani, Toru Ogawa, Shotaro Sano  and Shuji Suzuki* 

  We present a large-scale object detection system by team PFDet. Our system
enables training with huge datasets using 512 GPUs, handles sparsely verified
classes, and massive class imbalance. Using our method, we achieved 2nd place
in the Google AI Open Images Object Detection Track 2018 on Kaggle.

---------------

### 23 Apr 2021 | [Elo Ratings for Large Tournaments of Software Agents in Asymmetric Games](https://arxiv.org/abs/2105.00839) | [⬇️](https://arxiv.org/pdf/2105.00839)
*Ben Wise* 

  The Elo rating system has been used world wide for individual sports and team
sports, as exemplified by the European Go Federation (EGF), International Chess
Federation (FIDE), International Federation of Association Football (FIFA), and
many others. To evaluate the performance of artificial intelligence agents, it
is natural to evaluate them on the same Elo scale as humans, such as the rating
of 5185 attributed to AlphaGo Zero.
  There are several fundamental differences between humans and AI that suggest
modifications to the system, which in turn require revisiting Elo's fundamental
rationale. AI is typically trained on many more games than humans play, and we
have little a-priori information on newly created AI agents. Further, AI is
being extended into games which are asymmetric between the players, and which
could even have large complex boards with different setup in every game, such
as commercial paper strategy games. We present a revised rating system, and
guidelines for tournaments, to reflect these differences.

---------------

### 23 Oct 2023 | [Fast and Accurate Factual Inconsistency Detection Over Long Documents](https://arxiv.org/abs/2310.13189) | [⬇️](https://arxiv.org/pdf/2310.13189)
*Barrett Martin Lattimer, Patrick Chen, Xinyuan Zhang, Yi Yang* 

  Generative AI models exhibit remarkable potential; however, hallucinations
across various tasks present a significant challenge, particularly for longer
inputs that current approaches struggle to address effectively. We introduce
SCALE (Source Chunking Approach for Large-scale inconsistency Evaluation), a
task-agnostic model for detecting factual inconsistencies using a novel
chunking strategy. Specifically, SCALE is a Natural Language Inference (NLI)
based model that uses large text chunks to condition over long texts. This
approach achieves state-of-the-art performance in factual inconsistency
detection for diverse tasks and long inputs. Additionally, we leverage the
chunking mechanism and employ a novel algorithm to explain SCALE's decisions
through relevant source sentence retrieval. Our evaluations reveal that SCALE
outperforms existing methods on both standard benchmarks and a new long-form
dialogue dataset ScreenEval we constructed. Moreover, SCALE surpasses
competitive systems in efficiency and model explanation evaluations. We have
released our code and data publicly to GitHub.

---------------

### 22 Apr 2022 | [FPGA-based AI Smart NICs for Scalable Distributed AI Training Systems](https://arxiv.org/abs/2204.10943) | [⬇️](https://arxiv.org/pdf/2204.10943)
*Rui Ma, Evangelos Georganas, Alexander Heinecke, Andrew Boutros, Eriko  Nurvitadhi* 

  Rapid advances in artificial intelligence (AI) technology have led to
significant accuracy improvements in a myriad of application domains at the
cost of larger and more compute-intensive models. Training such models on
massive amounts of data typically requires scaling to many compute nodes and
relies heavily on collective communication algorithms, such as all-reduce, to
exchange the weight gradients between different nodes. The overhead of these
collective communication operations in a distributed AI training system can
bottleneck its performance, with more pronounced effects as the number of nodes
increases. In this paper, we first characterize the all-reduce operation
overhead by profiling distributed AI training. Then, we propose a new smart
network interface card (NIC) for distributed AI training systems using
field-programmable gate arrays (FPGAs) to accelerate all-reduce operations and
optimize network bandwidth utilization via data compression. The AI smart NIC
frees up the system's compute resources to perform the more compute-intensive
tensor operations and increases the overall node-to-node communication
efficiency. We perform real measurements on a prototype distributed AI training
system comprised of 6 compute nodes to evaluate the performance gains of our
proposed FPGA-based AI smart NIC compared to a baseline system with regular
NICs. We also use these measurements to validate an analytical model that we
formulate to predict performance when scaling to larger systems. Our proposed
FPGA-based AI smart NIC enhances overall training performance by 1.6x at 6
nodes, with an estimated 2.5x performance improvement at 32 nodes, compared to
the baseline system using conventional NICs.

---------------
**Date:** 09 Feb 2024

**Title:** Scalable Interactive Machine Learning for Future Command and Control

**Abstract Link:** [https://arxiv.org/abs/2402.06501](https://arxiv.org/abs/2402.06501)

**PDF Link:** [https://arxiv.org/pdf/2402.06501](https://arxiv.org/pdf/2402.06501)

---

**Date:** 06 Nov 2023

**Title:** A Theory for Emergence of Complex Skills in Language Models

**Abstract Link:** [https://arxiv.org/abs/2307.15936](https://arxiv.org/abs/2307.15936)

**PDF Link:** [https://arxiv.org/pdf/2307.15936](https://arxiv.org/pdf/2307.15936)

---

**Date:** 28 Jun 2023

**Title:** ViP: A Differentially Private Foundation Model for Computer Vision

**Abstract Link:** [https://arxiv.org/abs/2306.08842](https://arxiv.org/abs/2306.08842)

**PDF Link:** [https://arxiv.org/pdf/2306.08842](https://arxiv.org/pdf/2306.08842)

---

**Date:** 05 Jul 2023

**Title:** Scaling Laws Do Not Scale

**Abstract Link:** [https://arxiv.org/abs/2307.03201](https://arxiv.org/abs/2307.03201)

**PDF Link:** [https://arxiv.org/pdf/2307.03201](https://arxiv.org/pdf/2307.03201)

---

**Date:** 16 Mar 2021

**Title:** Technical Report: Scalable Active Information Acquisition for  Multi-Robot Systems

**Abstract Link:** [https://arxiv.org/abs/2103.09364](https://arxiv.org/abs/2103.09364)

**PDF Link:** [https://arxiv.org/pdf/2103.09364](https://arxiv.org/pdf/2103.09364)

---

**Date:** 06 Mar 2013

**Title:** A Study of Scaling Issues in Bayesian Belief Networks for Ship  Classification

**Abstract Link:** [https://arxiv.org/abs/1303.1457](https://arxiv.org/abs/1303.1457)

**PDF Link:** [https://arxiv.org/pdf/1303.1457](https://arxiv.org/pdf/1303.1457)

---

**Date:** 30 Apr 2020

**Title:** The 4th AI City Challenge

**Abstract Link:** [https://arxiv.org/abs/2004.14619](https://arxiv.org/abs/2004.14619)

**PDF Link:** [https://arxiv.org/pdf/2004.14619](https://arxiv.org/pdf/2004.14619)

---

**Date:** 17 May 2023

**Title:** The Jaseci Programming Paradigm and Runtime Stack: Building Scale-out  Production Applications Easy and Fast

**Abstract Link:** [https://arxiv.org/abs/2305.09864](https://arxiv.org/abs/2305.09864)

**PDF Link:** [https://arxiv.org/pdf/2305.09864](https://arxiv.org/pdf/2305.09864)

---

**Date:** 24 Feb 2021

**Title:** Wirelessly Powered Federated Edge Learning: Optimal Tradeoffs Between  Convergence and Power Transfer

**Abstract Link:** [https://arxiv.org/abs/2102.12357](https://arxiv.org/abs/2102.12357)

**PDF Link:** [https://arxiv.org/pdf/2102.12357](https://arxiv.org/pdf/2102.12357)

---

**Date:** 16 Jan 2020

**Title:** ScaIL: Classifier Weights Scaling for Class Incremental Learning

**Abstract Link:** [https://arxiv.org/abs/2001.05755](https://arxiv.org/abs/2001.05755)

**PDF Link:** [https://arxiv.org/pdf/2001.05755](https://arxiv.org/pdf/2001.05755)

---

**Date:** 20 Mar 2023

**Title:** PanGu-{\Sigma}: Towards Trillion Parameter Language Model with Sparse  Heterogeneous Computing

**Abstract Link:** [https://arxiv.org/abs/2303.10845](https://arxiv.org/abs/2303.10845)

**PDF Link:** [https://arxiv.org/pdf/2303.10845](https://arxiv.org/pdf/2303.10845)

---

**Date:** 08 Dec 2021

**Title:** An AI-based Solution for Enhancing Delivery of Digital Learning for  Future Teachers

**Abstract Link:** [https://arxiv.org/abs/2112.01229](https://arxiv.org/abs/2112.01229)

**PDF Link:** [https://arxiv.org/pdf/2112.01229](https://arxiv.org/pdf/2112.01229)

---

**Date:** 24 May 2021

**Title:** The 5th AI City Challenge

**Abstract Link:** [https://arxiv.org/abs/2104.12233](https://arxiv.org/abs/2104.12233)

**PDF Link:** [https://arxiv.org/pdf/2104.12233](https://arxiv.org/pdf/2104.12233)

---

**Date:** 10 Feb 2024

**Title:** A Tale of Tails: Model Collapse as a Change of Scaling Laws

**Abstract Link:** [https://arxiv.org/abs/2402.07043](https://arxiv.org/abs/2402.07043)

**PDF Link:** [https://arxiv.org/pdf/2402.07043](https://arxiv.org/pdf/2402.07043)

---

**Date:** 15 Mar 2021

**Title:** AIPerf: Automated machine learning as an AI-HPC benchmark

**Abstract Link:** [https://arxiv.org/abs/2008.07141](https://arxiv.org/abs/2008.07141)

**PDF Link:** [https://arxiv.org/pdf/2008.07141](https://arxiv.org/pdf/2008.07141)

---

**Date:** 16 Dec 2022

**Title:** GatorTron: A Large Clinical Language Model to Unlock Patient Information  from Unstructured Electronic Health Records

**Abstract Link:** [https://arxiv.org/abs/2203.03540](https://arxiv.org/abs/2203.03540)

**PDF Link:** [https://arxiv.org/pdf/2203.03540](https://arxiv.org/pdf/2203.03540)

---

**Date:** 04 Sep 2018

**Title:** PFDet: 2nd Place Solution to Open Images Challenge 2018 Object Detection  Track

**Abstract Link:** [https://arxiv.org/abs/1809.00778](https://arxiv.org/abs/1809.00778)

**PDF Link:** [https://arxiv.org/pdf/1809.00778](https://arxiv.org/pdf/1809.00778)

---

**Date:** 23 Apr 2021

**Title:** Elo Ratings for Large Tournaments of Software Agents in Asymmetric Games

**Abstract Link:** [https://arxiv.org/abs/2105.00839](https://arxiv.org/abs/2105.00839)

**PDF Link:** [https://arxiv.org/pdf/2105.00839](https://arxiv.org/pdf/2105.00839)

---

**Date:** 23 Oct 2023

**Title:** Fast and Accurate Factual Inconsistency Detection Over Long Documents

**Abstract Link:** [https://arxiv.org/abs/2310.13189](https://arxiv.org/abs/2310.13189)

**PDF Link:** [https://arxiv.org/pdf/2310.13189](https://arxiv.org/pdf/2310.13189)

---

**Date:** 22 Apr 2022

**Title:** FPGA-based AI Smart NICs for Scalable Distributed AI Training Systems

**Abstract Link:** [https://arxiv.org/abs/2204.10943](https://arxiv.org/abs/2204.10943)

**PDF Link:** [https://arxiv.org/pdf/2204.10943](https://arxiv.org/pdf/2204.10943)

---

