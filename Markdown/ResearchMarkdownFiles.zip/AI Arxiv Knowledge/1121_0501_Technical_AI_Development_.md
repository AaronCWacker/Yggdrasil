Technical AI Development 🛠️

### 🔎 Technical AI Development 🛠️



# AI Development

## AI Development

Artificial Intelligence (AI) is a branch of computer science that aims to create systems capable of performing tasks that would normally require human intelligence. These tasks include learning and adapting to new information, understanding human language, recognizing patterns, solving problems and making decisions.

AI development involves the design, creation, testing and deployment of AI systems. This can include developing algorithms, creating machine learning models, building and training neural networks, and integrating AI systems into existing software and hardware.

AI development can be used in a wide range of applications, including:

* Natural language processing (NLP)
* Computer vision
* Robotics
* Expert systems
* Predictive analytics
* Autonomous vehicles

AI development requires a strong understanding of computer science, mathematics, and statistics. Developers must also have a deep understanding of the specific problem domain they are working in, as well as the ability to design and implement complex systems.

At AiSensum, we have a team of experienced AI developers who can help you build custom AI solutions to meet your specific needs. Contact us today to learn more about how we can help you leverage the power of AI in your business.

## AI Development Services

At AiSensum, we offer a wide range of AI development services to help you build custom AI solutions that meet your specific needs. Our services include:

* AI Strategy and Consulting: We can help you develop an AI strategy that aligns with your business goals and objectives. We can also provide consulting services to help you understand the potential benefits and risks of AI in your business.
* AI Algorithm Development: We can help you develop custom AI algorithms that are tailored to your specific problem domain. Our algorithms are designed to be scalable, efficient, and accurate.
* Machine Learning Model Development: We can help you build and train machine learning models that can learn and adapt to new information. Our models are designed to be accurate, robust, and scalable.
* Neural Network Development: We can help you build and train neural networks that can recognize patterns, solve problems, and make decisions. Our neural networks are designed to be efficient, accurate, and scalable.
* AI Integration: We can help you integrate AI systems into your existing software and hardware. Our integration services include API development, data integration, and system testing.
* AI
# 🩺🔍 Search Results
### 25 Sep 2023 | [Case Study: Using AI-Assisted Code Generation In Mobile Teams](https://arxiv.org/abs/2308.04736) | [⬇️](https://arxiv.org/pdf/2308.04736)
*Mircea-Serban Vasiliniuc, Adrian Groza* 

  The aim of this study is to evaluate the performance of AI-assisted
programming in actual mobile development teams that are focused on native
mobile languages like Kotlin and Swift. The extensive case study involves 16
participants and 2 technical reviewers, from a software development department
designed to understand the impact of using LLMs trained for code generation in
specific phases of the team, more specifically, technical onboarding and
technical stack switch. The study uses technical problems dedicated to each
phase and requests solutions from the participants with and without using
AI-Code generators. It measures time, correctness, and technical integration
using ReviewerScore, a metric specific to the paper and extracted from actual
industry standards, the code reviewers of merge requests. The output is
converted and analyzed together with feedback from the participants in an
attempt to determine if using AI-assisted programming tools will have an impact
on getting developers onboard in a project or helping them with a smooth
transition between the two native development environments of mobile
development, Android and iOS. The study was performed between May and June 2023
with members of the mobile department of a software development company based
in Cluj-Napoca, with Romanian ownership and management.

---------------

### 16 Jun 2023 | [Artificial Intelligence for Technical Debt Management in Software  Development](https://arxiv.org/abs/2306.10194) | [⬇️](https://arxiv.org/pdf/2306.10194)
*Srinivas Babu Pandi, Samia A. Binta, Savita Kaushal* 

  Technical debt is a well-known challenge in software development, and its
negative impact on software quality, maintainability, and performance is widely
recognized. In recent years, artificial intelligence (AI) has proven to be a
promising approach to assist in managing technical debt. This paper presents a
comprehensive literature review of existing research on the use of AI powered
tools for technical debt avoidance in software development. In this literature
review we analyzed 15 related research papers which covers various AI-powered
techniques, such as code analysis and review, automated testing, code
refactoring, predictive maintenance, code generation, and code documentation,
and explores their effectiveness in addressing technical debt. The review also
discusses the benefits and challenges of using AI for technical debt
management, provides insights into the current state of research, and
highlights gaps and opportunities for future research. The findings of this
review suggest that AI has the potential to significantly improve technical
debt management in software development, and that existing research provides
valuable insights into how AI can be leveraged to address technical debt
effectively and efficiently. However, the review also highlights several
challenges and limitations of current approaches, such as the need for
high-quality data and ethical considerations and underscores the importance of
further research to address these issues. The paper provides a comprehensive
overview of the current state of research on AI for technical debt avoidance
and offers practical guidance for software development teams seeking to
leverage AI in their development processes to mitigate technical debt
effectively

---------------

### 26 Aug 2021 | [AI at work -- Mitigating safety and discriminatory risk with technical  standards](https://arxiv.org/abs/2108.11844) | [⬇️](https://arxiv.org/pdf/2108.11844)
*Nikolas Becker, Pauline Junginger, Lukas Martinez, Daniel Krupka,  Leonie Beining* 

  The use of artificial intelligence (AI) and AI methods in the workplace holds
both great opportunities as well as risks to occupational safety and
discrimination. In addition to legal regulation, technical standards will play
a key role in mitigating such risk by defining technical requirements for
development and testing of AI systems. This paper provides an overview and
assessment of existing international, European and German standards as well as
those currently under development. The paper is part of the research project
"ExamAI - Testing and Auditing of AI systems" and focusses on the use of AI in
an industrial production environment as well as in the realm of human resource
management (HR).

---------------

### 30 May 2020 | [AI Research Considerations for Human Existential Safety (ARCHES)](https://arxiv.org/abs/2006.04948) | [⬇️](https://arxiv.org/pdf/2006.04948)
*Andrew Critch, David Krueger* 

  Framed in positive terms, this report examines how technical AI research
might be steered in a manner that is more attentive to humanity's long-term
prospects for survival as a species. In negative terms, we ask what existential
risks humanity might face from AI development in the next century, and by what
principles contemporary technical research might be directed to address those
risks.
  A key property of hypothetical AI technologies is introduced, called
\emph{prepotence}, which is useful for delineating a variety of potential
existential risks from artificial intelligence, even as AI paradigms might
shift. A set of \auxref{dirtot} contemporary research \directions are then
examined for their potential benefit to existential safety. Each research
direction is explained with a scenario-driven motivation, and examples of
existing work from which to build. The research directions present their own
risks and benefits to society that could occur at various scales of impact, and
in particular are not guaranteed to benefit existential safety if major
developments in them are deployed without adequate forethought and oversight.
As such, each direction is accompanied by a consideration of potentially
negative side effects.

---------------

### 08 May 2022 | [A Survey on AI Sustainability: Emerging Trends on Learning Algorithms  and Research Challenges](https://arxiv.org/abs/2205.03824) | [⬇️](https://arxiv.org/pdf/2205.03824)
*Zhenghua Chen, Min Wu, Alvin Chan, Xiaoli Li, Yew-Soon Ong* 

  Artificial Intelligence (AI) is a fast-growing research and development (R&D)
discipline which is attracting increasing attention because of its promises to
bring vast benefits for consumers and businesses, with considerable benefits
promised in productivity growth and innovation. To date it has reported
significant accomplishments in many areas that have been deemed as challenging
for machines, ranging from computer vision, natural language processing, audio
analysis to smart sensing and many others. The technical trend in realizing the
successes has been towards increasing complex and large size AI models so as to
solve more complex problems at superior performance and robustness. This rapid
progress, however, has taken place at the expense of substantial environmental
costs and resources. Besides, debates on the societal impacts of AI, such as
fairness, safety and privacy, have continued to grow in intensity. These issues
have presented major concerns pertaining to the sustainable development of AI.
In this work, we review major trends in machine learning approaches that can
address the sustainability problem of AI. Specifically, we examine emerging AI
methodologies and algorithms for addressing the sustainability issue of AI in
two major aspects, i.e., environmental sustainability and social sustainability
of AI. We will also highlight the major limitations of existing studies and
propose potential research challenges and directions for the development of
next generation of sustainable AI techniques. We believe that this technical
review can help to promote a sustainable development of AI R&D activities for
the research community.

---------------

### 31 May 2023 | [End-User Development for Artificial Intelligence: A Systematic  Literature Review](https://arxiv.org/abs/2304.09863) | [⬇️](https://arxiv.org/pdf/2304.09863)
*Andrea Esposito, Miriana Calvano, Antonio Curci, Giuseppe Desolda,  Rosa Lanzilotti, Claudia Lorusso and Antonio Piccinno* 

  In recent years, Artificial Intelligence has become more and more relevant in
our society. Creating AI systems is almost always the prerogative of IT and AI
experts. However, users may need to create intelligent solutions tailored to
their specific needs. In this way, AI systems can be enhanced if new approaches
are devised to allow non-technical users to be directly involved in the
definition and personalization of AI technologies. End-User Development (EUD)
can provide a solution to these problems, allowing people to create, customize,
or adapt AI-based systems to their own needs. This paper presents a systematic
literature review that aims to shed the light on the current landscape of EUD
for AI systems, i.e., how users, even without skills in AI and/or programming,
can customize the AI behavior to their needs. This study also discusses the
current challenges of EUD for AI, the potential benefits, and the future
implications of integrating EUD into the overall AI development process.

---------------

### 01 Jun 2023 | [The ethical ambiguity of AI data enrichment: Measuring gaps in research  ethics norms and practices](https://arxiv.org/abs/2306.01800) | [⬇️](https://arxiv.org/pdf/2306.01800)
*Will Hawkins and Brent Mittelstadt* 

  The technical progression of artificial intelligence (AI) research has been
built on breakthroughs in fields such as computer science, statistics, and
mathematics. However, in the past decade AI researchers have increasingly
looked to the social sciences, turning to human interactions to solve the
challenges of model development. Paying crowdsourcing workers to generate or
curate data, or data enrichment, has become indispensable for many areas of AI
research, from natural language processing to reinforcement learning from human
feedback (RLHF). Other fields that routinely interact with crowdsourcing
workers, such as Psychology, have developed common governance requirements and
norms to ensure research is undertaken ethically. This study explores how, and
to what extent, comparable research ethics requirements and norms have
developed for AI research and data enrichment. We focus on the approach taken
by two leading conferences: ICLR and NeurIPS, and journal publisher Springer.
In a longitudinal study of accepted papers, and via a comparison with
Psychology and CHI papers, this work finds that leading AI venues have begun to
establish protocols for human data collection, but these are are inconsistently
followed by authors. Whilst Psychology papers engaging with crowdsourcing
workers frequently disclose ethics reviews, payment data, demographic data and
other information, similar disclosures are far less common in leading AI venues
despite similar guidance. The work concludes with hypotheses to explain these
gaps in research ethics practices and considerations for its implications.

---------------

### 06 Mar 2023 | [Artificial Intelligence: 70 Years Down the Road](https://arxiv.org/abs/2303.02819) | [⬇️](https://arxiv.org/pdf/2303.02819)
*Lin Zhang* 

  Artificial intelligence (AI) has a history of nearly a century from its
inception to the present day. We have summarized the development trends and
discovered universal rules, including both success and failure. We have
analyzed the reasons from both technical and philosophical perspectives to help
understand the reasons behind the past failures and current successes of AI,
and to provide a basis for thinking and exploring future development.
Specifically, we have found that the development of AI in different fields,
including computer vision, natural language processing, and machine learning,
follows a pattern from rules to statistics to data-driven methods. In the face
of past failures and current successes, we need to think systematically about
the reasons behind them. Given the unity of AI between natural and social
sciences, it is necessary to incorporate philosophical thinking to understand
and solve AI problems, and we believe that starting from the dialectical method
of Marx is a feasible path. We have concluded that the sustainable development
direction of AI should be human-machine collaboration and a technology path
centered on computing power. Finally, we have summarized the impact of AI on
society from this trend.

---------------

### 14 Apr 2021 | [Towards a framework for evaluating the safety, acceptability and  efficacy of AI systems for health: an initial synthesis](https://arxiv.org/abs/2104.06910) | [⬇️](https://arxiv.org/pdf/2104.06910)
*Jessica Morley, Caroline Morton, Kassandra Karpathakis, Mariarosaria  Taddeo, Luciano Floridi* 

  The potential presented by Artificial Intelligence (AI) for healthcare has
long been recognised by the technical community. More recently, this potential
has been recognised by policymakers, resulting in considerable public and
private investment in the development of AI for healthcare across the globe.
Despite this, excepting limited success stories, real-world implementation of
AI systems into front-line healthcare has been limited. There are numerous
reasons for this, but a main contributory factor is the lack of internationally
accepted, or formalised, regulatory standards to assess AI safety and impact
and effectiveness. This is a well-recognised problem with numerous ongoing
research and policy projects to overcome it. Our intention here is to
contribute to this problem-solving effort by seeking to set out a minimally
viable framework for evaluating the safety, acceptability and efficacy of AI
systems for healthcare. We do this by conducting a systematic search across
Scopus, PubMed and Google Scholar to identify all the relevant literature
published between January 1970 and November 2020 related to the evaluation of:
output performance; efficacy; and real-world use of AI systems, and
synthesising the key themes according to the stages of evaluation: pre-clinical
(theoretical phase); exploratory phase; definitive phase; and post-market
surveillance phase (monitoring). The result is a framework to guide AI system
developers, policymakers, and regulators through a sufficient evaluation of an
AI system designed for use in healthcare.

---------------

### 24 Jan 2024 | [Design, Development, and Deployment of Context-Adaptive AI Systems for  Enhanced End-User Adoption](https://arxiv.org/abs/2401.13643) | [⬇️](https://arxiv.org/pdf/2401.13643)
*Christine P Lee* 

  My research centers on the development of context-adaptive AI systems to
improve end-user adoption through the integration of technical methods. I
deploy these AI systems across various interaction modalities, including user
interfaces and embodied agents like robots, to expand their practical
applicability. My research unfolds in three key stages: design, development,
and deployment. In the design phase, user-centered approaches were used to
understand user experiences with AI systems and create design tools for user
participation in crafting AI explanations. In the ongoing development stage, a
safety-guaranteed AI system for a robot agent was created to automatically
provide adaptive solutions and explanations for unforeseen scenarios. The next
steps will involve the implementation and evaluation of context-adaptive AI
systems in various interaction forms. I seek to prioritize human needs in
technology development, creating AI systems that tangibly benefit end-users in
real-world applications and enhance interaction experiences.

---------------

### 19 Sep 2023 | [Why We Don't Have AGI Yet](https://arxiv.org/abs/2308.03598) | [⬇️](https://arxiv.org/pdf/2308.03598)
*Peter Voss and Mladjan Jovanovic* 

  The original vision of AI was re-articulated in 2002 via the term 'Artificial
General Intelligence' or AGI. This vision is to build 'Thinking Machines' -
computer systems that can learn, reason, and solve problems similar to the way
humans do. This is in stark contrast to the 'Narrow AI' approach practiced by
almost everyone in the field over the many decades. While several large-scale
efforts have nominally been working on AGI (most notably DeepMind), the field
of pure focused AGI development has not been well funded or promoted. This is
surprising given the fantastic value that true AGI can bestow on humanity. In
addition to the dearth of effort in this field, there are also several
theoretical and methodical missteps that are hampering progress. We highlight
why purely statistical approaches are unlikely to lead to AGI, and identify
several crucial cognitive abilities required to achieve human-like adaptability
and autonomous learning. We conclude with a survey of socio-technical factors
that have undoubtedly slowed progress towards AGI.

---------------

### 15 Feb 2024 | [Moderating Model Marketplaces: Platform Governance Puzzles for AI  Intermediaries](https://arxiv.org/abs/2311.12573) | [⬇️](https://arxiv.org/pdf/2311.12573)
*Robert Gorwa and Michael Veale* 

  The AI development community is increasingly making use of hosting
intermediaries such as Hugging Face provide easy access to user-uploaded models
and training data. These model marketplaces lower technical deployment barriers
for hundreds of thousands of users, yet can be used in numerous potentially
harmful and illegal ways. In this article, we explain ways in which AI systems,
which can both `contain' content and be open-ended tools, present one of the
trickiest platform governance challenges seen to date. We provide case studies
of several incidents across three illustrative platforms -- Hugging Face,
GitHub and Civitai -- to examine how model marketplaces moderate models.
Building on this analysis, we outline important (and yet nevertheless limited)
practices that industry has been developing to respond to moderation demands:
licensing, access and use restrictions, automated content moderation, and open
policy development. While the policy challenge at hand is a considerable one,
we conclude with some ideas as to how platforms could better mobilize resources
to act as a careful, fair, and proportionate regulatory access point.

---------------

### 16 Mar 2022 | [Building AI Innovation Labs together with Companies](https://arxiv.org/abs/2203.08465) | [⬇️](https://arxiv.org/pdf/2203.08465)
*Jens Heidrich, Andreas Jedlitschka, Adam Trendowicz, Anna Maria  Vollmer* 

  In the future, most companies will be confronted with the topic of Artificial
Intelligence (AI) and will have to decide on their strategy in this regards.
Currently, a lot of companies are thinking about whether and how AI and the
usage of data will impact their business model and what potential use cases
could look like. One of the biggest challenges lies in coming up with
innovative solution ideas with a clear business value. This requires business
competencies on the one hand and technical competencies in AI and data
analytics on the other hand. In this article, we present the concept of AI
innovation labs and demonstrate a comprehensive framework, from coming up with
the right ideas to incrementally implementing and evaluating them regarding
their business value and their feasibility based on a company's capabilities.
The concept is the result of nine years of working on data-driven innovations
with companies from various domains. Furthermore, we share some lessons learned
from its practical applications. Even though a lot of technical publications
can be found in the literature regarding the development of AI models and many
consultancy companies provide corresponding services for building AI
innovations, we found very few publications sharing details about what an
end-to-end framework could look like.

---------------

### 14 Mar 2023 | [Artificial Intelligence Ethics and Safety: practical tools for creating  "good" models](https://arxiv.org/abs/2112.11208) | [⬇️](https://arxiv.org/pdf/2112.11208)
*Nicholas Kluge Corr\^ea* 

  The AI Robotics Ethics Society (AIRES) is a non-profit organization founded
in 2018 by Aaron Hui to promote awareness and the importance of ethical
implementation and regulation of AI. AIRES is now an organization with chapters
at universities such as UCLA (Los Angeles), USC (University of Southern
California), Caltech (California Institute of Technology), Stanford University,
Cornell University, Brown University, and the Pontifical Catholic University of
Rio Grande do Sul (Brazil). AIRES at PUCRS is the first international chapter
of AIRES, and as such, we are committed to promoting and enhancing the AIRES
Mission. Our mission is to focus on educating the AI leaders of tomorrow in
ethical principles to ensure that AI is created ethically and responsibly. As
there are still few proposals for how we should implement ethical principles
and normative guidelines in the practice of AI system development, the goal of
this work is to try to bridge this gap between discourse and praxis. Between
abstract principles and technical implementation. In this work, we seek to
introduce the reader to the topic of AI Ethics and Safety. At the same time, we
present several tools to help developers of intelligent systems develop "good"
models. This work is a developing guide published in English and Portuguese.
Contributions and suggestions are welcome.

---------------

### 15 Feb 2023 | [Invisible Users: Uncovering End-Users' Requirements for Explainable AI  via Explanation Forms and Goals](https://arxiv.org/abs/2302.06609) | [⬇️](https://arxiv.org/pdf/2302.06609)
*Weina Jin, Jianyu Fan, Diane Gromala, Philippe Pasquier, Ghassan  Hamarneh* 

  Non-technical end-users are silent and invisible users of the
state-of-the-art explainable artificial intelligence (XAI) technologies. Their
demands and requirements for AI explainability are not incorporated into the
design and evaluation of XAI techniques, which are developed to explain the
rationales of AI decisions to end-users and assist their critical decisions.
This makes XAI techniques ineffective or even harmful in high-stakes
applications, such as healthcare, criminal justice, finance, and autonomous
driving systems. To systematically understand end-users' requirements to
support the technical development of XAI, we conducted the EUCA user study with
32 layperson participants in four AI-assisted critical tasks. The study
identified comprehensive user requirements for feature-, example-, and
rule-based XAI techniques (manifested by the end-user-friendly explanation
forms) and XAI evaluation objectives (manifested by the explanation goals),
which were shown to be helpful to directly inspire the proposal of new XAI
algorithms and evaluation metrics. The EUCA study findings, the identified
explanation forms and goals for technical specification, and the EUCA study
dataset support the design and evaluation of end-user-centered XAI techniques
for accessible, safe, and accountable AI.

---------------

### 26 Jan 2024 | [On the Emergence of Symmetrical Reality](https://arxiv.org/abs/2401.15132) | [⬇️](https://arxiv.org/pdf/2401.15132)
*Zhenliang Zhang, Zeyu Zhang, Ziyuan Jiao, Yao Su, Hangxin Liu, Wei  Wang, Song-Chun Zhu* 

  Artificial intelligence (AI) has revolutionized human cognitive abilities and
facilitated the development of new AI entities capable of interacting with
humans in both physical and virtual environments. Despite the existence of
virtual reality, mixed reality, and augmented reality for several years,
integrating these technical fields remains a formidable challenge due to their
disparate application directions. The advent of AI agents, capable of
autonomous perception and action, further compounds this issue by exposing the
limitations of traditional human-centered research approaches. It is imperative
to establish a comprehensive framework that accommodates the dual perceptual
centers of humans and AI agents in both physical and virtual worlds. In this
paper, we introduce the symmetrical reality framework, which offers a unified
representation encompassing various forms of physical-virtual amalgamations.
This framework enables researchers to better comprehend how AI agents can
collaborate with humans and how distinct technical pathways of physical-virtual
integration can be consolidated from a broader perspective. We then delve into
the coexistence of humans and AI, demonstrating a prototype system that
exemplifies the operation of symmetrical reality systems for specific tasks,
such as pouring water. Subsequently, we propose an instance of an AI-driven
active assistance service that illustrates the potential applications of
symmetrical reality. This paper aims to offer beneficial perspectives and
guidance for researchers and practitioners in different fields, thus
contributing to the ongoing research about human-AI coexistence in both
physical and virtual environments.

---------------

### 11 Aug 2023 | [FUTURE-AI: International consensus guideline for trustworthy and  deployable artificial intelligence in healthcare](https://arxiv.org/abs/2309.12325) | [⬇️](https://arxiv.org/pdf/2309.12325)
*Karim Lekadir, Aasa Feragen, Abdul Joseph Fofanah, Alejandro F Frangi,  Alena Buyx, Anais Emelie, Andrea Lara, Antonio R Porras, An-Wen Chan, Arcadi  Navarro, Ben Glocker, Benard O Botwe, Bishesh Khanal, Brigit Beger, Carol C  Wu, Celia Cintas, Curtis P Langlotz, Daniel Rueckert, Deogratias Mzurikwao,  Dimitrios I Fotiadis, Doszhan Zhussupov, Enzo Ferrante, Erik Meijering, Eva  Weicken, Fabio A Gonz\'alez, Folkert W Asselbergs, Fred Prior, Gabriel P  Krestin, Gary Collins, Geletaw S Tegenaw, Georgios Kaissis, Gianluca  Misuraca, Gianna Tsakou, Girish Dwivedi, Haridimos Kondylakis, Harsha  Jayakody, Henry C Woodruf, Hugo JWL Aerts, Ian Walsh, Ioanna Chouvarda,  Ir\`ene Buvat, Islem Rekik, James Duncan, Jayashree Kalpathy-Cramer, Jihad  Zahir, Jinah Park, John Mongan, Judy W Gichoya, Julia A Schnabel, Kaisar  Kushibar, Katrine Riklund, Kensaku Mori, Kostas Marias, Lameck M Amugongo,  Lauren A Fromont, Lena Maier-Hein, Leonor Cerd\'a Alberich, Leticia Rittner,  Lighton Phiri, Linda Marrakchi-Kacem, Llu\'is Donoso-Bach, Luis  Mart\'i-Bonmat\'i, M Jorge Cardoso, Maciej Bobowicz, Mahsa Shabani, Manolis  Tsiknakis, Maria A Zuluaga, Maria Bielikova, Marie-Christine Fritzsche,  Marius George Linguraru, Markus Wenzel, Marleen De Bruijne, Martin G  Tolsgaard, Marzyeh Ghassemi, Md Ashrafuzzaman, Melanie Goisauf, Mohammad  Yaqub, Mohammed Ammar, M\'onica Cano Abad\'ia, Mukhtar M E Mahmoud, Mustafa  Elattar, Nicola Rieke, Nikolaos Papanikolaou, Noussair Lazrak, Oliver D\'iaz,  Olivier Salvado, Oriol Pujol, Ousmane Sall, Pamela Guevara, Peter Gordebeke,  Philippe Lambin, Pieta Brown, Purang Abolmaesumi, Qi Dou, Qinghua Lu, Richard  Osuala, Rose Nakasi, S Kevin Zhou, Sandy Napel, Sara Colantonio, Shadi  Albarqouni, Smriti Joshi, Stacy Carter, Stefan Klein, Steffen E Petersen,  Susanna Auss\'o, Suyash Awate, Tammy Riklin Raviv, Tessa Cook, Tinashe E M  Mutsvangwa, Wendy A Rogers, Wiro J Niessen, X\`enia Puig-Bosch, Yi Zeng,  Yunusa G Mohammed, Yves Saint James Aquino, Zohaib Salahuddin, Martijn P A  Starmans* 

  Despite major advances in artificial intelligence (AI) for medicine and
healthcare, the deployment and adoption of AI technologies remain limited in
real-world clinical practice. In recent years, concerns have been raised about
the technical, clinical, ethical and legal risks associated with medical AI. To
increase real world adoption, it is essential that medical AI tools are trusted
and accepted by patients, clinicians, health organisations and authorities.
This work describes the FUTURE-AI guideline as the first international
consensus framework for guiding the development and deployment of trustworthy
AI tools in healthcare. The FUTURE-AI consortium was founded in 2021 and
currently comprises 118 inter-disciplinary experts from 51 countries
representing all continents, including AI scientists, clinicians, ethicists,
and social scientists. Over a two-year period, the consortium defined guiding
principles and best practices for trustworthy AI through an iterative process
comprising an in-depth literature review, a modified Delphi survey, and online
consensus meetings. The FUTURE-AI framework was established based on 6 guiding
principles for trustworthy AI in healthcare, i.e. Fairness, Universality,
Traceability, Usability, Robustness and Explainability. Through consensus, a
set of 28 best practices were defined, addressing technical, clinical, legal
and socio-ethical dimensions. The recommendations cover the entire lifecycle of
medical AI, from design, development and validation to regulation, deployment,
and monitoring. FUTURE-AI is a risk-informed, assumption-free guideline which
provides a structured approach for constructing medical AI tools that will be
trusted, deployed and adopted in real-world practice. Researchers are
encouraged to take the recommendations into account in proof-of-concept stages
to facilitate future translation towards clinical practice of medical AI.

---------------

### 08 Nov 2019 | [AI Ethics for Systemic Issues: A Structural Approach](https://arxiv.org/abs/1911.03216) | [⬇️](https://arxiv.org/pdf/1911.03216)
*Agnes Schim van der Loeff, Iggy Bassi, Sachin Kapila, Jevgenij Gamper* 

  The debate on AI ethics largely focuses on technical improvements and
stronger regulation to prevent accidents or misuse of AI, with solutions
relying on holding individual actors accountable for responsible AI
development. While useful and necessary, we argue that this "agency" approach
disregards more indirect and complex risks resulting from AI's interaction with
the socio-economic and political context. This paper calls for a "structural"
approach to assessing AI's effects in order to understand and prevent such
systemic risks where no individual can be held accountable for the broader
negative impacts. This is particularly relevant for AI applied to systemic
issues such as climate change and food security which require political
solutions and global cooperation. To properly address the wide range of AI
risks and ensure 'AI for social good', agency-focused policies must be
complemented by policies informed by a structural approach.

---------------

### 01 Jun 2023 | [RHFedMTL: Resource-Aware Hierarchical Federated Multi-Task Learning](https://arxiv.org/abs/2306.00675) | [⬇️](https://arxiv.org/pdf/2306.00675)
*Xingfu Yi, Rongpeng Li, Chenghui Peng, Fei Wang, Jianjun Wu, and  Zhifeng Zhao* 

  The rapid development of artificial intelligence (AI) over massive
applications including Internet-of-things on cellular network raises the
concern of technical challenges such as privacy, heterogeneity and resource
efficiency.
  Federated learning is an effective way to enable AI over massive distributed
nodes with security.
  However, conventional works mostly focus on learning a single global model
for a unique task across the network, and are generally less competent to
handle multi-task learning (MTL) scenarios with stragglers at the expense of
acceptable computation and communication cost. Meanwhile, it is challenging to
ensure the privacy while maintain a coupled multi-task learning across multiple
base stations (BSs) and terminals. In this paper, inspired by the natural
cloud-BS-terminal hierarchy of cellular works, we provide a viable
resource-aware hierarchical federated MTL (RHFedMTL) solution to meet the
heterogeneity of tasks, by solving different tasks within the BSs and
aggregating the multi-task result in the cloud without compromising the
privacy. Specifically, a primal-dual method has been leveraged to effectively
transform the coupled MTL into some local optimization sub-problems within BSs.
Furthermore, compared with existing methods to reduce resource cost by simply
changing the aggregation frequency,
  we dive into the intricate relationship between resource consumption and
learning accuracy, and develop a resource-aware learning strategy for local
terminals and BSs to meet the resource budget. Extensive simulation results
demonstrate the effectiveness and superiority of RHFedMTL in terms of improving
the learning accuracy and boosting the convergence rate.

---------------

### 30 Aug 2019 | [Teaching AI, Ethics, Law and Policy](https://arxiv.org/abs/1904.12470) | [⬇️](https://arxiv.org/pdf/1904.12470)
*Asher Wilk* 

  The cyberspace and development of intelligent systems using Artificial
Intelligence (AI) creates new challenges to computer professionals, data
scientists, regulators and policy makers. For example, self-driving cars raise
new technical, ethical, legal and public policy issues. This paper proposes a
course named Computers, Ethics, Law, and Public Policy, and suggests a
curriculum for such a course. This paper presents ethical, legal, and public
policy issues relevant to building and using intelligent systems.

---------------
**Date:** 25 Sep 2023

**Title:** Case Study: Using AI-Assisted Code Generation In Mobile Teams

**Abstract Link:** [https://arxiv.org/abs/2308.04736](https://arxiv.org/abs/2308.04736)

**PDF Link:** [https://arxiv.org/pdf/2308.04736](https://arxiv.org/pdf/2308.04736)

---

**Date:** 16 Jun 2023

**Title:** Artificial Intelligence for Technical Debt Management in Software  Development

**Abstract Link:** [https://arxiv.org/abs/2306.10194](https://arxiv.org/abs/2306.10194)

**PDF Link:** [https://arxiv.org/pdf/2306.10194](https://arxiv.org/pdf/2306.10194)

---

**Date:** 26 Aug 2021

**Title:** AI at work -- Mitigating safety and discriminatory risk with technical  standards

**Abstract Link:** [https://arxiv.org/abs/2108.11844](https://arxiv.org/abs/2108.11844)

**PDF Link:** [https://arxiv.org/pdf/2108.11844](https://arxiv.org/pdf/2108.11844)

---

**Date:** 30 May 2020

**Title:** AI Research Considerations for Human Existential Safety (ARCHES)

**Abstract Link:** [https://arxiv.org/abs/2006.04948](https://arxiv.org/abs/2006.04948)

**PDF Link:** [https://arxiv.org/pdf/2006.04948](https://arxiv.org/pdf/2006.04948)

---

**Date:** 08 May 2022

**Title:** A Survey on AI Sustainability: Emerging Trends on Learning Algorithms  and Research Challenges

**Abstract Link:** [https://arxiv.org/abs/2205.03824](https://arxiv.org/abs/2205.03824)

**PDF Link:** [https://arxiv.org/pdf/2205.03824](https://arxiv.org/pdf/2205.03824)

---

**Date:** 31 May 2023

**Title:** End-User Development for Artificial Intelligence: A Systematic  Literature Review

**Abstract Link:** [https://arxiv.org/abs/2304.09863](https://arxiv.org/abs/2304.09863)

**PDF Link:** [https://arxiv.org/pdf/2304.09863](https://arxiv.org/pdf/2304.09863)

---

**Date:** 01 Jun 2023

**Title:** The ethical ambiguity of AI data enrichment: Measuring gaps in research  ethics norms and practices

**Abstract Link:** [https://arxiv.org/abs/2306.01800](https://arxiv.org/abs/2306.01800)

**PDF Link:** [https://arxiv.org/pdf/2306.01800](https://arxiv.org/pdf/2306.01800)

---

**Date:** 06 Mar 2023

**Title:** Artificial Intelligence: 70 Years Down the Road

**Abstract Link:** [https://arxiv.org/abs/2303.02819](https://arxiv.org/abs/2303.02819)

**PDF Link:** [https://arxiv.org/pdf/2303.02819](https://arxiv.org/pdf/2303.02819)

---

**Date:** 14 Apr 2021

**Title:** Towards a framework for evaluating the safety, acceptability and  efficacy of AI systems for health: an initial synthesis

**Abstract Link:** [https://arxiv.org/abs/2104.06910](https://arxiv.org/abs/2104.06910)

**PDF Link:** [https://arxiv.org/pdf/2104.06910](https://arxiv.org/pdf/2104.06910)

---

**Date:** 24 Jan 2024

**Title:** Design, Development, and Deployment of Context-Adaptive AI Systems for  Enhanced End-User Adoption

**Abstract Link:** [https://arxiv.org/abs/2401.13643](https://arxiv.org/abs/2401.13643)

**PDF Link:** [https://arxiv.org/pdf/2401.13643](https://arxiv.org/pdf/2401.13643)

---

**Date:** 19 Sep 2023

**Title:** Why We Don't Have AGI Yet

**Abstract Link:** [https://arxiv.org/abs/2308.03598](https://arxiv.org/abs/2308.03598)

**PDF Link:** [https://arxiv.org/pdf/2308.03598](https://arxiv.org/pdf/2308.03598)

---

**Date:** 15 Feb 2024

**Title:** Moderating Model Marketplaces: Platform Governance Puzzles for AI  Intermediaries

**Abstract Link:** [https://arxiv.org/abs/2311.12573](https://arxiv.org/abs/2311.12573)

**PDF Link:** [https://arxiv.org/pdf/2311.12573](https://arxiv.org/pdf/2311.12573)

---

**Date:** 16 Mar 2022

**Title:** Building AI Innovation Labs together with Companies

**Abstract Link:** [https://arxiv.org/abs/2203.08465](https://arxiv.org/abs/2203.08465)

**PDF Link:** [https://arxiv.org/pdf/2203.08465](https://arxiv.org/pdf/2203.08465)

---

**Date:** 14 Mar 2023

**Title:** Artificial Intelligence Ethics and Safety: practical tools for creating  "good" models

**Abstract Link:** [https://arxiv.org/abs/2112.11208](https://arxiv.org/abs/2112.11208)

**PDF Link:** [https://arxiv.org/pdf/2112.11208](https://arxiv.org/pdf/2112.11208)

---

**Date:** 15 Feb 2023

**Title:** Invisible Users: Uncovering End-Users' Requirements for Explainable AI  via Explanation Forms and Goals

**Abstract Link:** [https://arxiv.org/abs/2302.06609](https://arxiv.org/abs/2302.06609)

**PDF Link:** [https://arxiv.org/pdf/2302.06609](https://arxiv.org/pdf/2302.06609)

---

**Date:** 26 Jan 2024

**Title:** On the Emergence of Symmetrical Reality

**Abstract Link:** [https://arxiv.org/abs/2401.15132](https://arxiv.org/abs/2401.15132)

**PDF Link:** [https://arxiv.org/pdf/2401.15132](https://arxiv.org/pdf/2401.15132)

---

**Date:** 11 Aug 2023

**Title:** FUTURE-AI: International consensus guideline for trustworthy and  deployable artificial intelligence in healthcare

**Abstract Link:** [https://arxiv.org/abs/2309.12325](https://arxiv.org/abs/2309.12325)

**PDF Link:** [https://arxiv.org/pdf/2309.12325](https://arxiv.org/pdf/2309.12325)

---

**Date:** 08 Nov 2019

**Title:** AI Ethics for Systemic Issues: A Structural Approach

**Abstract Link:** [https://arxiv.org/abs/1911.03216](https://arxiv.org/abs/1911.03216)

**PDF Link:** [https://arxiv.org/pdf/1911.03216](https://arxiv.org/pdf/1911.03216)

---

**Date:** 01 Jun 2023

**Title:** RHFedMTL: Resource-Aware Hierarchical Federated Multi-Task Learning

**Abstract Link:** [https://arxiv.org/abs/2306.00675](https://arxiv.org/abs/2306.00675)

**PDF Link:** [https://arxiv.org/pdf/2306.00675](https://arxiv.org/pdf/2306.00675)

---

**Date:** 30 Aug 2019

**Title:** Teaching AI, Ethics, Law and Policy

**Abstract Link:** [https://arxiv.org/abs/1904.12470](https://arxiv.org/abs/1904.12470)

**PDF Link:** [https://arxiv.org/pdf/1904.12470](https://arxiv.org/pdf/1904.12470)

---

