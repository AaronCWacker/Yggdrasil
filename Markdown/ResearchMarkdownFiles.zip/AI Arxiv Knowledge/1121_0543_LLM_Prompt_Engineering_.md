LLM Prompt Engineering 📝

### 🔎 LLM Prompt Engineering 📝


================

This repository contains a collection of prompt engineering templates for various NLP tasks.

Prompt Engineering
------------------

Prompt engineering is the process of designing and optimizing prompts for large language models to perform specific tasks. The goal is to elicit the desired response from the model by providing it with a well-crafted input.

The templates in this repository are designed to be flexible and customizable, allowing you to adapt them to your specific use case.

### Template Structure

Each template consists of the following components:

-   **Task**: A brief description of the NLP task the template is designed for.
-   **Prompt**: The actual template, which can be filled in with specific details as needed.
-   **Example(s)**: One or more examples of how the template can be used, along with the expected output from a language model.

### Usage

To use a template, simply replace the placeholders in the prompt with the specific details of your task. For example, if you want to use the `Classification` template to classify a sentiment, you might fill in the template like this:

```
Prompt: "The sentiment of the following text is: {text}. The sentiment is {sentiment}."

Filled in: "The sentiment of the following text is: I love this product. The sentiment is positive."

Expected output: "The sentiment of the following text is: I love this product. The sentiment is positive."
```

### Contributing

If you have a prompt engineering template that you'd like to contribute, please submit a pull request! We welcome contributions from the community.

License
-------

This project is licensed under the terms of the MIT license.</s>
# 🩺🔍 Search Results
### 06 Jun 2023 | [Prompt Space Optimizing Few-shot Reasoning Success with Large Language  Models](https://arxiv.org/abs/2306.03799) | [⬇️](https://arxiv.org/pdf/2306.03799)
*Fobo Shi, Peijun Qing, Dong Yang, Nan Wang, Youbo Lei, Haonan Lu,  Xiaodong Lin* 

  Prompt engineering is an essential technique for enhancing the abilities of
large language models (LLMs) by providing explicit and specific instructions.
It enables LLMs to excel in various tasks, such as arithmetic reasoning,
question answering, summarization, relation extraction, machine translation,
and sentiment analysis. Researchers have been actively exploring different
prompt engineering strategies, such as Chain of Thought (CoT), Zero-CoT, and
In-context learning. However, an unresolved problem arises from the fact that
current approaches lack a solid theoretical foundation for determining optimal
prompts. To address this issue in prompt engineering, we propose a new and
effective approach called Prompt Space. Our methodology utilizes text
embeddings to obtain basis vectors by matrix decomposition, and then constructs
a space for representing all prompts. Prompt Space significantly outperforms
state-of-the-art prompt paradigms on ten public reasoning benchmarks. Notably,
without the help of the CoT method and the prompt "Let's think step by step",
Prompt Space shows superior performance over the few-shot method. Overall, our
approach provides a robust and fundamental theoretical framework for selecting
simple and effective prompts. This advancement marks a significant step towards
improving prompt engineering for a wide variety of applications in LLMs.

---------------

### 02 Oct 2023 | [SPELL: Semantic Prompt Evolution based on a LLM](https://arxiv.org/abs/2310.01260) | [⬇️](https://arxiv.org/pdf/2310.01260)
*Yujian Betterest Li, Kai Wu* 

  Prompt engineering is a new paradigm for enhancing the performance of trained
neural network models. For optimizing text-style prompts, existing methods
usually individually operate small portions of a text step by step, which
either breaks the fluency or could not globally adjust a prompt. Since large
language models (LLMs) have powerful ability of generating coherent texts token
by token, can we utilize LLMs for improving prompts? Based on this motivation,
in this paper, considering a trained LLM as a text generator, we attempt to
design a black-box evolution algorithm for automatically optimizing texts,
namely SPELL (Semantic Prompt Evolution based on a LLM). The proposed method is
evaluated with different LLMs and evolution parameters in different text tasks.
Experimental results show that SPELL could rapidly improve the prompts indeed.
We further explore the evolution process and discuss on the limitations,
potential possibilities and future work.

---------------

### 27 Oct 2023 | [Unleashing the potential of prompt engineering in Large Language Models:  a comprehensive review](https://arxiv.org/abs/2310.14735) | [⬇️](https://arxiv.org/pdf/2310.14735)
*Banghao Chen, Zhaofeng Zhang, Nicolas Langren\'e, Shengxin Zhu* 

  This paper delves into the pivotal role of prompt engineering in unleashing
the capabilities of Large Language Models (LLMs). Prompt engineering is the
process of structuring input text for LLMs and is a technique integral to
optimizing the efficacy of LLMs. This survey elucidates foundational principles
of prompt engineering, such as role-prompting, one-shot, and few-shot
prompting, as well as more advanced methodologies such as the chain-of-thought
and tree-of-thoughts prompting. The paper sheds light on how external
assistance in the form of plugins can assist in this task, and reduce machine
hallucination by retrieving external knowledge. We subsequently delineate
prospective directions in prompt engineering research, emphasizing the need for
a deeper understanding of structures and the role of agents in Artificial
Intelligence-Generated Content (AIGC) tools. We discuss how to assess the
efficacy of prompt methods from different perspectives and using different
methods. Finally, we gather information about the application of prompt
engineering in such fields as education and programming, showing its
transformative potential. This comprehensive survey aims to serve as a friendly
guide for anyone venturing through the big world of LLMs and prompt
engineering.

---------------

### 05 Feb 2024 | [Intent-based Prompt Calibration: Enhancing prompt optimization with  synthetic boundary cases](https://arxiv.org/abs/2402.03099) | [⬇️](https://arxiv.org/pdf/2402.03099)
*Elad Levi, Eli Brosh, Matan Friedmann* 

  Prompt engineering is a challenging and important task due to the high
sensitivity of Large Language Models (LLMs) to the given prompt and the
inherent ambiguity of a textual task instruction. Automatic prompt engineering
is essential to achieve optimized performance from LLMs. Recent studies have
demonstrated the capabilities of LLMs to automatically conduct prompt
engineering by employing a meta-prompt that incorporates the outcomes of the
last trials and proposes an improved prompt. However, this requires a
high-quality benchmark to compare different prompts, which is difficult and
expensive to acquire in many real-world use cases. In this work, we introduce a
new method for automatic prompt engineering, using a calibration process that
iteratively refines the prompt to the user intent. During the optimization
process, the system jointly generates synthetic data of boundary use cases and
optimizes the prompt according to the generated dataset. We demonstrate the
effectiveness of our method with respect to strong proprietary models on
real-world tasks such as moderation and generation. Our method outperforms
state-of-the-art methods with a limited number of annotated samples.
Furthermore, we validate the advantages of each one of the system's key
components. Our system is built in a modular way, facilitating easy adaptation
to other tasks. The code is available
$\href{https://github.com/Eladlev/AutoPrompt}{here}$.

---------------

### 21 Feb 2023 | [A Prompt Pattern Catalog to Enhance Prompt Engineering with ChatGPT](https://arxiv.org/abs/2302.11382) | [⬇️](https://arxiv.org/pdf/2302.11382)
*Jules White, Quchen Fu, Sam Hays, Michael Sandborn, Carlos Olea, Henry  Gilbert, Ashraf Elnashar, Jesse Spencer-Smith, Douglas C. Schmidt* 

  Prompt engineering is an increasingly important skill set needed to converse
effectively with large language models (LLMs), such as ChatGPT. Prompts are
instructions given to an LLM to enforce rules, automate processes, and ensure
specific qualities (and quantities) of generated output. Prompts are also a
form of programming that can customize the outputs and interactions with an
LLM. This paper describes a catalog of prompt engineering techniques presented
in pattern form that have been applied to solve common problems when conversing
with LLMs. Prompt patterns are a knowledge transfer method analogous to
software patterns since they provide reusable solutions to common problems
faced in a particular context, i.e., output generation and interaction when
working with LLMs. This paper provides the following contributions to research
on prompt engineering that apply LLMs to automate software development tasks.
First, it provides a framework for documenting patterns for structuring prompts
to solve a range of problems so that they can be adapted to different domains.
Second, it presents a catalog of patterns that have been applied successfully
to improve the outputs of LLM conversations. Third, it explains how prompts can
be built from multiple patterns and illustrates prompt patterns that benefit
from combination with other prompt patterns.

---------------

### 03 Nov 2023 | [Prompt Engineering Through the Lens of Optimal Control](https://arxiv.org/abs/2310.14201) | [⬇️](https://arxiv.org/pdf/2310.14201)
*Yifan Luo, Yiming Tang, Chengfeng Shen, Zhennan Zhou, Bin Dong* 

  Prompt Engineering (PE) has emerged as a critical technique for guiding Large
Language Models (LLMs) in solving intricate tasks. Its importance is
highlighted by its potential to significantly enhance the efficiency and
effectiveness of human-machine interaction. As tasks grow increasingly complex,
recent advanced PE methods have extended beyond the limitations of single-round
interactions to embrace multi-round interactions, which allows for a deeper and
more nuanced engagement with LLMs. In this paper, we propose an optimal control
framework tailored for multi-round interactions with LLMs. This framework
provides a unified mathematical structure that not only systematizes the
existing PE methods but also sets the stage for rigorous analytical
improvements. Furthermore, we extend this framework to include PE via ensemble
methods and multi-agent collaboration, thereby enlarging the scope of
applicability. By adopting an optimal control perspective, we offer fresh
insights into existing PE methods and highlight theoretical challenges that
warrant future research. Besides, our work lays a foundation for the
development of more effective and interpretable PE methods.

---------------

### 03 Jan 2024 | [What's the Magic Word? A Control Theory of LLM Prompting](https://arxiv.org/abs/2310.04444) | [⬇️](https://arxiv.org/pdf/2310.04444)
*Aman Bhargava, Cameron Witkowski, Manav Shah, Matt Thomson* 

  Prompt engineering is crucial for deploying LLMs but is poorly understood
mathematically. We formalize LLM systems as a class of discrete stochastic
dynamical systems to explore prompt engineering through the lens of control
theory. We investigate the reachable set of output token sequences $R_y(\mathbf
x_0)$ for which there exists a control input sequence $\mathbf u$ for each
$\mathbf y \in R_y(\mathbf x_0)$ that steers the LLM to output $\mathbf y$ from
initial state sequence $\mathbf x_0$. We offer analytic analysis on the
limitations on the controllability of self-attention in terms of reachable set,
where we prove an upper bound on the reachable set of outputs $R_y(\mathbf
x_0)$ as a function of the singular values of the parameter matrices. We
present complementary empirical analysis on the controllability of a panel of
LLMs, including Falcon-7b, Llama-7b, and Falcon-40b. Our results demonstrate a
lower bound on the reachable set of outputs $R_y(\mathbf x_0)$ w.r.t. initial
state sequences $\mathbf x_0$ sampled from the Wikitext dataset. We find that
the correct next Wikitext token following sequence $\mathbf x_0$ is reachable
over 97% of the time with prompts of $k\leq 10$ tokens. We also establish that
the top 75 most likely next tokens, as estimated by the LLM itself, are
reachable at least 85% of the time with prompts of $k\leq 10$ tokens.
Intriguingly, short prompt sequences can dramatically alter the likelihood of
specific outputs, even making the least likely tokens become the most likely
ones. This control-centric analysis of LLMs demonstrates the significant and
poorly understood role of input sequences in steering output probabilities,
offering a foundational perspective for enhancing language model system
capabilities.

---------------

### 20 Feb 2024 | [PRewrite: Prompt Rewriting with Reinforcement Learning](https://arxiv.org/abs/2401.08189) | [⬇️](https://arxiv.org/pdf/2401.08189)
*Weize Kong and Spurthi Amba Hombaiah and Mingyang Zhang and Qiaozhu  Mei and Michael Bendersky* 

  Prompt engineering is critical for the development of LLM-based applications.
However, it is usually done manually in a "trial and error" fashion that can be
time consuming, ineffective, and sub-optimal. Even for the prompts which
seemingly work well, there is always a lingering question: can the prompts be
made better with further modifications?
  To address these problems, we investigate automated prompt engineering in
this paper. Specifically, we propose PRewrite, an automated method to rewrite
an under-optimized prompt to a more effective prompt. We instantiate the prompt
rewriter using a LLM. The rewriter LLM is trained using reinforcement learning
to optimize the performance on a given downstream task. We conduct experiments
on diverse benchmark datasets, which demonstrates the effectiveness of
PRewrite.

---------------

### 07 Aug 2023 | [Revisiting Prompt Engineering via Declarative Crowdsourcing](https://arxiv.org/abs/2308.03854) | [⬇️](https://arxiv.org/pdf/2308.03854)
*Aditya G. Parameswaran, Shreya Shankar, Parth Asawa, Naman Jain, Yujie  Wang* 

  Large language models (LLMs) are incredibly powerful at comprehending and
generating data in the form of text, but are brittle and error-prone. There has
been an advent of toolkits and recipes centered around so-called prompt
engineering-the process of asking an LLM to do something via a series of
prompts. However, for LLM-powered data processing workflows, in particular,
optimizing for quality, while keeping cost bounded, is a tedious, manual
process. We put forth a vision for declarative prompt engineering. We view LLMs
like crowd workers and leverage ideas from the declarative crowdsourcing
literature-including leveraging multiple prompting strategies, ensuring
internal consistency, and exploring hybrid-LLM-non-LLM approaches-to make
prompt engineering a more principled process. Preliminary case studies on
sorting, entity resolution, and imputation demonstrate the promise of our
approach

---------------

### 25 Jan 2024 | [Wordflow: Social Prompt Engineering for Large Language Models](https://arxiv.org/abs/2401.14447) | [⬇️](https://arxiv.org/pdf/2401.14447)
*Zijie J. Wang, Aishwarya Chakravarthy, David Munechika, Duen Horng  Chau* 

  Large language models (LLMs) require well-crafted prompts for effective use.
Prompt engineering, the process of designing prompts, is challenging,
particularly for non-experts who are less familiar with AI technologies. While
researchers have proposed techniques and tools to assist LLM users in prompt
design, these works primarily target AI application developers rather than
non-experts. To address this research gap, we propose social prompt
engineering, a novel paradigm that leverages social computing techniques to
facilitate collaborative prompt design. To investigate social prompt
engineering, we introduce Wordflow, an open-source and social text editor that
enables everyday users to easily create, run, share, and discover LLM prompts.
Additionally, by leveraging modern web technologies, Wordflow allows users to
run LLMs locally and privately in their browsers. Two usage scenarios highlight
how social prompt engineering and our tool can enhance laypeople's interaction
with LLMs. Wordflow is publicly accessible at
https://poloclub.github.io/wordflow.

---------------

### 05 Dec 2022 | [Legal Prompt Engineering for Multilingual Legal Judgement Prediction](https://arxiv.org/abs/2212.02199) | [⬇️](https://arxiv.org/pdf/2212.02199)
*Dietrich Trautmann, Alina Petrova, Frank Schilder* 

  Legal Prompt Engineering (LPE) or Legal Prompting is a process to guide and
assist a large language model (LLM) with performing a natural legal language
processing (NLLP) skill. Our goal is to use LPE with LLMs over long legal
documents for the Legal Judgement Prediction (LJP) task. We investigate the
performance of zero-shot LPE for given facts in case-texts from the European
Court of Human Rights (in English) and the Federal Supreme Court of Switzerland
(in German, French and Italian). Our results show that zero-shot LPE is better
compared to the baselines, but it still falls short compared to current state
of the art supervised approaches. Nevertheless, the results are important,
since there was 1) no explicit domain-specific data used - so we show that the
transfer to the legal domain is possible for general-purpose LLMs, and 2) the
LLMs where directly applied without any further training or fine-tuning - which
in turn saves immensely in terms of additional computational costs.

---------------

### 05 Feb 2024 | [A Systematic Survey of Prompt Engineering in Large Language Models:  Techniques and Applications](https://arxiv.org/abs/2402.07927) | [⬇️](https://arxiv.org/pdf/2402.07927)
*Pranab Sahoo, Ayush Kumar Singh, Sriparna Saha, Vinija Jain, Samrat  Mondal, and Aman Chadha* 

  Prompt engineering has emerged as an indispensable technique for extending
the capabilities of large language models (LLMs) and vision-language models
(VLMs). This approach leverages task-specific instructions, known as prompts,
to enhance model efficacy without modifying the core model parameters. Rather
than updating the model parameters, prompts allow seamless integration of
pre-trained models into downstream tasks by eliciting desired model behaviors
solely based on the given prompt. Prompts can be natural language instructions
that provide context to guide the model or learned vector representations that
activate relevant knowledge. This burgeoning field has enabled success across
various applications, from question-answering to commonsense reasoning.
However, there remains a lack of systematic organization and understanding of
the diverse prompt engineering methods and techniques. This survey paper
addresses the gap by providing a structured overview of recent advancements in
prompt engineering, categorized by application area. For each prompting
approach, we provide a summary detailing the prompting methodology, its
applications, the models involved, and the datasets utilized. We also delve
into the strengths and limitations of each approach and include a taxonomy
diagram and table summarizing datasets, models, and critical points of each
prompting technique. This systematic analysis enables a better understanding of
this rapidly developing field and facilitates future research by illuminating
open challenges and opportunities for prompt engineering.

---------------

### 16 Nov 2023 | [More Samples or More Prompt Inputs? Exploring Effective In-Context  Sampling for LLM Few-Shot Prompt Engineering](https://arxiv.org/abs/2311.09782) | [⬇️](https://arxiv.org/pdf/2311.09782)
*Bingsheng Yao, Guiming Chen, Ruishi Zou, Yuxuan Lu, Jiachen Li, Shao  Zhang, Sijia Liu, James Hendler, Dakuo Wang* 

  While most existing works on LLM prompt-engineering focus only on how to
select a better set of data samples inside one single prompt input (In-Context
Learning or ICL), why can't we design and leverage multiple prompt inputs
together to further improve the LLM performance? In this work, we propose
In-Context Sampling (ICS), a low-resource LLM prompt-engineering technique to
produce the most confident prediction results by optimizing the construction of
multiple ICL prompt inputs. Extensive experiments with two SOTA LLMs (FlanT5-XL
and Mistral-7B) on three NLI datasets (e-SNLI, Multi-NLI, and ANLI) illustrate
that ICS can consistently enhance LLM's prediction performance and confidence.
An ablation study suggests that a diversity-based ICS strategy may further
improve LLM's performance, which sheds light on a new yet promising future
research direction.

---------------

### 05 Jan 2024 | [PromptBench: A Unified Library for Evaluation of Large Language Models](https://arxiv.org/abs/2312.07910) | [⬇️](https://arxiv.org/pdf/2312.07910)
*Kaijie Zhu, Qinlin Zhao, Hao Chen, Jindong Wang, Xing Xie* 

  The evaluation of large language models (LLMs) is crucial to assess their
performance and mitigate potential security risks. In this paper, we introduce
PromptBench, a unified library to evaluate LLMs. It consists of several key
components that are easily used and extended by researchers: prompt
construction, prompt engineering, dataset and model loading, adversarial prompt
attack, dynamic evaluation protocols, and analysis tools. PromptBench is
designed to be an open, general, and flexible codebase for research purposes
that can facilitate original study in creating new benchmarks, deploying
downstream applications, and designing new evaluation protocols. The code is
available at: https://github.com/microsoft/promptbench and will be continuously
supported.

---------------

### 25 Jan 2024 | [Towards Goal-oriented Large Language Model Prompting: A Survey](https://arxiv.org/abs/2401.14043) | [⬇️](https://arxiv.org/pdf/2401.14043)
*Haochen Li, Jonathan Leung, Zhiqi Shen* 

  Large Language Models (LLMs) have shown prominent performance in various
downstream tasks in which prompt engineering plays a pivotal role in optimizing
LLMs' performance. This paper, not as an overview of current prompt engineering
methods, aims to highlight the limitation of designing prompts while holding an
anthropomorphic assumption that expects LLMs to think like humans. From our
review of 35 representative studies, we demonstrate that a goal-oriented prompt
formulation, which guides LLMs to follow established human logical thinking,
significantly improves the performance of LLMs. Furthermore, We introduce a
novel taxonomy that categorizes goal-oriented prompting methods into five
interconnected stages and we demonstrate the broad applicability of our
framework by summarizing ten applicable tasks. With four future directions
proposed, we hope to further emphasize and promote goal-oriented prompt
engineering.

---------------

### 20 Feb 2024 | [Improving Knowledge Extraction from LLMs for Task Learning through Agent  Analysis](https://arxiv.org/abs/2306.06770) | [⬇️](https://arxiv.org/pdf/2306.06770)
*James R. Kirk, Robert E. Wray, Peter Lindes, John E. Laird* 

  Large language models (LLMs) offer significant promise as a knowledge source
for task learning. Prompt engineering has been shown to be effective for
eliciting knowledge from an LLM, but alone it is insufficient for acquiring
relevant, situationally grounded knowledge for an embodied agent learning novel
tasks. We describe a cognitive-agent approach, STARS, that extends and
complements prompt engineering, mitigating its limitations and thus enabling an
agent to acquire new task knowledge matched to its native language
capabilities, embodiment, environment, and user preferences. The STARS approach
is to increase the response space of LLMs and deploy general strategies,
embedded within the autonomous agent, to evaluate, repair, and select among
candidate responses produced by the LLM. We describe the approach and
experiments that show how an agent, by retrieving and evaluating a breadth of
responses from the LLM, can achieve 77-94% task completion in one-shot learning
without user oversight. The approach achieves 100% task completion when human
oversight (such as an indication of preference) is provided. Further, the type
of oversight largely shifts from explicit, natural language instruction to
simple confirmation/discomfirmation of high-quality responses that have been
vetted by the agent before presentation to a user.

---------------

### 16 Nov 2023 | [Automatic Engineering of Long Prompts](https://arxiv.org/abs/2311.10117) | [⬇️](https://arxiv.org/pdf/2311.10117)
*Cho-Jui Hsieh, Si Si, Felix X. Yu, Inderjit S. Dhillon* 

  Large language models (LLMs) have demonstrated remarkable capabilities in
solving complex open-domain tasks, guided by comprehensive instructions and
demonstrations provided in the form of prompts. However, these prompts can be
lengthy, often comprising hundreds of lines and thousands of tokens, and their
design often requires considerable human effort. Recent research has explored
automatic prompt engineering for short prompts, typically consisting of one or
a few sentences. However, the automatic design of long prompts remains a
challenging problem due to its immense search space. In this paper, we
investigate the performance of greedy algorithms and genetic algorithms for
automatic long prompt engineering. We demonstrate that a simple greedy approach
with beam search outperforms other methods in terms of search efficiency.
Moreover, we introduce two novel techniques that utilize search history to
enhance the effectiveness of LLM-based mutation in our search algorithm. Our
results show that the proposed automatic long prompt engineering algorithm
achieves an average of 9.2% accuracy gain on eight tasks in Big Bench Hard,
highlighting the significance of automating prompt designs to fully harness the
capabilities of LLMs.

---------------

### 13 Nov 2023 | [PROPANE: Prompt design as an inverse problem](https://arxiv.org/abs/2311.07064) | [⬇️](https://arxiv.org/pdf/2311.07064)
*Rimon Melamed, Lucas H. McCabe, Tanay Wakhare, Yejin Kim, H. Howie  Huang, Enric Boix-Adsera* 

  Carefully-designed prompts are key to inducing desired behavior in Large
Language Models (LLMs). As a result, great effort has been dedicated to
engineering prompts that guide LLMs toward particular behaviors. In this work,
we propose an automatic prompt optimization framework, PROPANE, which aims to
find a prompt that induces semantically similar outputs to a fixed set of
examples without user intervention. We further demonstrate that PROPANE can be
used to (a) improve existing prompts, and (b) discover semantically obfuscated
prompts that transfer between models.

---------------

### 08 Feb 2024 | [Prompt Design and Engineering: Introduction and Advanced Methods](https://arxiv.org/abs/2401.14423) | [⬇️](https://arxiv.org/pdf/2401.14423)
*Xavier Amatriain* 

  Prompt design and engineering has rapidly become essential for maximizing the
potential of large language models. In this paper, we introduce core concepts,
advanced techniques like Chain-of-Thought and Reflection, and the principles
behind building LLM-based agents. Finally, we provide a survey of tools for
prompt engineers.

---------------

### 10 Mar 2023 | [Large Language Models Are Human-Level Prompt Engineers](https://arxiv.org/abs/2211.01910) | [⬇️](https://arxiv.org/pdf/2211.01910)
*Yongchao Zhou, Andrei Ioan Muresanu, Ziwen Han, Keiran Paster, Silviu  Pitis, Harris Chan, Jimmy Ba* 

  By conditioning on natural language instructions, large language models
(LLMs) have displayed impressive capabilities as general-purpose computers.
However, task performance depends significantly on the quality of the prompt
used to steer the model, and most effective prompts have been handcrafted by
humans. Inspired by classical program synthesis and the human approach to
prompt engineering, we propose Automatic Prompt Engineer (APE) for automatic
instruction generation and selection. In our method, we treat the instruction
as the "program," optimized by searching over a pool of instruction candidates
proposed by an LLM in order to maximize a chosen score function. To evaluate
the quality of the selected instruction, we evaluate the zero-shot performance
of another LLM following the selected instruction. Experiments on 24 NLP tasks
show that our automatically generated instructions outperform the prior LLM
baseline by a large margin and achieve better or comparable performance to the
instructions generated by human annotators on 19/24 tasks. We conduct extensive
qualitative and quantitative analyses to explore the performance of APE. We
show that APE-engineered prompts can be applied to steer models toward
truthfulness and/or informativeness, as well as to improve few-shot learning
performance by simply prepending them to standard in-context learning prompts.
Please check out our webpage at
https://sites.google.com/view/automatic-prompt-engineer.

---------------
**Date:** 06 Jun 2023

**Title:** Prompt Space Optimizing Few-shot Reasoning Success with Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2306.03799](https://arxiv.org/abs/2306.03799)

**PDF Link:** [https://arxiv.org/pdf/2306.03799](https://arxiv.org/pdf/2306.03799)

---

**Date:** 02 Oct 2023

**Title:** SPELL: Semantic Prompt Evolution based on a LLM

**Abstract Link:** [https://arxiv.org/abs/2310.01260](https://arxiv.org/abs/2310.01260)

**PDF Link:** [https://arxiv.org/pdf/2310.01260](https://arxiv.org/pdf/2310.01260)

---

**Date:** 27 Oct 2023

**Title:** Unleashing the potential of prompt engineering in Large Language Models:  a comprehensive review

**Abstract Link:** [https://arxiv.org/abs/2310.14735](https://arxiv.org/abs/2310.14735)

**PDF Link:** [https://arxiv.org/pdf/2310.14735](https://arxiv.org/pdf/2310.14735)

---

**Date:** 05 Feb 2024

**Title:** Intent-based Prompt Calibration: Enhancing prompt optimization with  synthetic boundary cases

**Abstract Link:** [https://arxiv.org/abs/2402.03099](https://arxiv.org/abs/2402.03099)

**PDF Link:** [https://arxiv.org/pdf/2402.03099](https://arxiv.org/pdf/2402.03099)

---

**Date:** 21 Feb 2023

**Title:** A Prompt Pattern Catalog to Enhance Prompt Engineering with ChatGPT

**Abstract Link:** [https://arxiv.org/abs/2302.11382](https://arxiv.org/abs/2302.11382)

**PDF Link:** [https://arxiv.org/pdf/2302.11382](https://arxiv.org/pdf/2302.11382)

---

**Date:** 03 Nov 2023

**Title:** Prompt Engineering Through the Lens of Optimal Control

**Abstract Link:** [https://arxiv.org/abs/2310.14201](https://arxiv.org/abs/2310.14201)

**PDF Link:** [https://arxiv.org/pdf/2310.14201](https://arxiv.org/pdf/2310.14201)

---

**Date:** 03 Jan 2024

**Title:** What's the Magic Word? A Control Theory of LLM Prompting

**Abstract Link:** [https://arxiv.org/abs/2310.04444](https://arxiv.org/abs/2310.04444)

**PDF Link:** [https://arxiv.org/pdf/2310.04444](https://arxiv.org/pdf/2310.04444)

---

**Date:** 20 Feb 2024

**Title:** PRewrite: Prompt Rewriting with Reinforcement Learning

**Abstract Link:** [https://arxiv.org/abs/2401.08189](https://arxiv.org/abs/2401.08189)

**PDF Link:** [https://arxiv.org/pdf/2401.08189](https://arxiv.org/pdf/2401.08189)

---

**Date:** 07 Aug 2023

**Title:** Revisiting Prompt Engineering via Declarative Crowdsourcing

**Abstract Link:** [https://arxiv.org/abs/2308.03854](https://arxiv.org/abs/2308.03854)

**PDF Link:** [https://arxiv.org/pdf/2308.03854](https://arxiv.org/pdf/2308.03854)

---

**Date:** 25 Jan 2024

**Title:** Wordflow: Social Prompt Engineering for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.14447](https://arxiv.org/abs/2401.14447)

**PDF Link:** [https://arxiv.org/pdf/2401.14447](https://arxiv.org/pdf/2401.14447)

---

**Date:** 05 Dec 2022

**Title:** Legal Prompt Engineering for Multilingual Legal Judgement Prediction

**Abstract Link:** [https://arxiv.org/abs/2212.02199](https://arxiv.org/abs/2212.02199)

**PDF Link:** [https://arxiv.org/pdf/2212.02199](https://arxiv.org/pdf/2212.02199)

---

**Date:** 05 Feb 2024

**Title:** A Systematic Survey of Prompt Engineering in Large Language Models:  Techniques and Applications

**Abstract Link:** [https://arxiv.org/abs/2402.07927](https://arxiv.org/abs/2402.07927)

**PDF Link:** [https://arxiv.org/pdf/2402.07927](https://arxiv.org/pdf/2402.07927)

---

**Date:** 16 Nov 2023

**Title:** More Samples or More Prompt Inputs? Exploring Effective In-Context  Sampling for LLM Few-Shot Prompt Engineering

**Abstract Link:** [https://arxiv.org/abs/2311.09782](https://arxiv.org/abs/2311.09782)

**PDF Link:** [https://arxiv.org/pdf/2311.09782](https://arxiv.org/pdf/2311.09782)

---

**Date:** 05 Jan 2024

**Title:** PromptBench: A Unified Library for Evaluation of Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2312.07910](https://arxiv.org/abs/2312.07910)

**PDF Link:** [https://arxiv.org/pdf/2312.07910](https://arxiv.org/pdf/2312.07910)

---

**Date:** 25 Jan 2024

**Title:** Towards Goal-oriented Large Language Model Prompting: A Survey

**Abstract Link:** [https://arxiv.org/abs/2401.14043](https://arxiv.org/abs/2401.14043)

**PDF Link:** [https://arxiv.org/pdf/2401.14043](https://arxiv.org/pdf/2401.14043)

---

**Date:** 20 Feb 2024

**Title:** Improving Knowledge Extraction from LLMs for Task Learning through Agent  Analysis

**Abstract Link:** [https://arxiv.org/abs/2306.06770](https://arxiv.org/abs/2306.06770)

**PDF Link:** [https://arxiv.org/pdf/2306.06770](https://arxiv.org/pdf/2306.06770)

---

**Date:** 16 Nov 2023

**Title:** Automatic Engineering of Long Prompts

**Abstract Link:** [https://arxiv.org/abs/2311.10117](https://arxiv.org/abs/2311.10117)

**PDF Link:** [https://arxiv.org/pdf/2311.10117](https://arxiv.org/pdf/2311.10117)

---

**Date:** 13 Nov 2023

**Title:** PROPANE: Prompt design as an inverse problem

**Abstract Link:** [https://arxiv.org/abs/2311.07064](https://arxiv.org/abs/2311.07064)

**PDF Link:** [https://arxiv.org/pdf/2311.07064](https://arxiv.org/pdf/2311.07064)

---

**Date:** 08 Feb 2024

**Title:** Prompt Design and Engineering: Introduction and Advanced Methods

**Abstract Link:** [https://arxiv.org/abs/2401.14423](https://arxiv.org/abs/2401.14423)

**PDF Link:** [https://arxiv.org/pdf/2401.14423](https://arxiv.org/pdf/2401.14423)

---

**Date:** 10 Mar 2023

**Title:** Large Language Models Are Human-Level Prompt Engineers

**Abstract Link:** [https://arxiv.org/abs/2211.01910](https://arxiv.org/abs/2211.01910)

**PDF Link:** [https://arxiv.org/pdf/2211.01910](https://arxiv.org/pdf/2211.01910)

---

