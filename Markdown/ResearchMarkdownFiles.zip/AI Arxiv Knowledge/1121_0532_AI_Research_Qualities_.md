AI Research Qualities 🎓

### 🔎 AI Research Qualities 🎓



# AI Research Qualities

## AI Research Qualities

AI research is a rapidly growing field that involves the development of intelligent systems capable of performing tasks that typically require human intelligence. To ensure the success of AI research, it is essential to maintain high-quality research practices. In this article, we will discuss the key qualities that characterize high-quality AI research.

1. Clarity and Rigor

High-quality AI research should be clear, concise, and rigorous. Researchers should define their research questions and objectives clearly, and provide a detailed description of their methodology. They should also use appropriate statistical methods and provide sufficient evidence to support their claims.

2. Novelty and Originality

High-quality AI research should contribute something new to the field. Researchers should strive to develop novel algorithms, models, or techniques that can advance the state-of-the-art in AI. They should also be aware of related work in the field and cite relevant literature to demonstrate the originality of their contributions.

3. Reproducibility and Validity

High-quality AI research should be reproducible and valid. Researchers should provide enough details about their experiments, datasets, and code to allow other researchers to replicate their results. They should also use appropriate evaluation metrics and statistical tests to ensure the validity of their findings.

4. Ethical Considerations

High-quality AI research should consider the ethical implications of their work. Researchers should be aware of the potential risks and benefits of their research and take appropriate measures to mitigate any negative impacts. They should also consider issues related to fairness, accountability, and transparency in AI systems.

5. Interdisciplinary Collaboration

High-quality AI research often involves collaboration between researchers from different disciplines. Researchers should be open to working with experts from other fields, such as computer science, psychology, sociology, and philosophy, to develop more comprehensive and effective AI systems.

6. Communication and Dissemination

High-quality AI research should be communicated effectively to both academic and non-academic audiences. Researchers should use appropriate language and visual aids to convey their findings clearly and accurately. They should also disseminate their research through peer-reviewed journals, conferences, and other venues to reach a wider audience.

7. Long-term Impact
# 🩺🔍 Search Results
### 09 Oct 2023 | [AI Systems of Concern](https://arxiv.org/abs/2310.05876) | [⬇️](https://arxiv.org/pdf/2310.05876)
*Kayla Matteucci, Shahar Avin, Fazl Barez, Se\'an \'O h\'Eigeartaigh* 

  Concerns around future dangers from advanced AI often centre on systems
hypothesised to have intrinsic characteristics such as agent-like behaviour,
strategic awareness, and long-range planning. We label this cluster of
characteristics as "Property X". Most present AI systems are low in "Property
X"; however, in the absence of deliberate steering, current research directions
may rapidly lead to the emergence of highly capable AI systems that are also
high in "Property X". We argue that "Property X" characteristics are
intrinsically dangerous, and when combined with greater capabilities will
result in AI systems for which safety and control is difficult to guarantee.
Drawing on several scholars' alternative frameworks for possible AI research
trajectories, we argue that most of the proposed benefits of advanced AI can be
obtained by systems designed to minimise this property. We then propose
indicators and governance interventions to identify and limit the development
of systems with risky "Property X" characteristics.

---------------

### 26 Dec 2023 | [Can ChatGPT Read Who You Are?](https://arxiv.org/abs/2312.16070) | [⬇️](https://arxiv.org/pdf/2312.16070)
*Erik Derner, Dalibor Ku\v{c}era, Nuria Oliver, Jan Zah\'alka* 

  The interplay between artificial intelligence (AI) and psychology,
particularly in personality assessment, represents an important emerging area
of research. Accurate personality trait estimation is crucial not only for
enhancing personalization in human-computer interaction but also for a wide
variety of applications ranging from mental health to education. This paper
analyzes the capability of a generic chatbot, ChatGPT, to effectively infer
personality traits from short texts. We report the results of a comprehensive
user study featuring texts written in Czech by a representative population
sample of 155 participants. Their self-assessments based on the Big Five
Inventory (BFI) questionnaire serve as the ground truth. We compare the
personality trait estimations made by ChatGPT against those by human raters and
report ChatGPT's competitive performance in inferring personality traits from
text. We also uncover a 'positivity bias' in ChatGPT's assessments across all
personality dimensions and explore the impact of prompt composition on
accuracy. This work contributes to the understanding of AI capabilities in
psychological assessment, highlighting both the potential and limitations of
using large language models for personality inference. Our research underscores
the importance of responsible AI development, considering ethical implications
such as privacy, consent, autonomy, and bias in AI applications.

---------------

### 19 Dec 2023 | [Towards Human-centered Explainable AI: A Survey of User Studies for  Model Explanations](https://arxiv.org/abs/2210.11584) | [⬇️](https://arxiv.org/pdf/2210.11584)
*Yao Rong, Tobias Leemann, Thai-trang Nguyen, Lisa Fiedler, Peizhu  Qian, Vaibhav Unhelkar, Tina Seidel, Gjergji Kasneci, Enkelejda Kasneci* 

  Explainable AI (XAI) is widely viewed as a sine qua non for ever-expanding AI
research. A better understanding of the needs of XAI users, as well as
human-centered evaluations of explainable models are both a necessity and a
challenge. In this paper, we explore how HCI and AI researchers conduct user
studies in XAI applications based on a systematic literature review. After
identifying and thoroughly analyzing 97core papers with human-based XAI
evaluations over the past five years, we categorize them along the measured
characteristics of explanatory methods, namely trust, understanding, usability,
and human-AI collaboration performance. Our research shows that XAI is
spreading more rapidly in certain application domains, such as recommender
systems than in others, but that user evaluations are still rather sparse and
incorporate hardly any insights from cognitive or social sciences. Based on a
comprehensive discussion of best practices, i.e., common models, design
choices, and measures in user studies, we propose practical guidelines on
designing and conducting user studies for XAI researchers and practitioners.
Lastly, this survey also highlights several open research directions,
particularly linking psychological science and human-centered XAI.

---------------

### 17 Sep 2022 | [Artificial Intelligence in Concrete Materials: A Scientometric View](https://arxiv.org/abs/2209.09636) | [⬇️](https://arxiv.org/pdf/2209.09636)
*Zhanzhao Li, Aleksandra Radli\'nska* 

  Artificial intelligence (AI) has emerged as a transformative and versatile
tool, breaking new frontiers across scientific domains. Among its most
promising applications, AI research is blossoming in concrete science and
engineering, where it has offered new insights towards mixture design
optimization and service life prediction of cementitious systems. This chapter
aims to uncover the main research interests and knowledge structure of the
existing literature on AI for concrete materials. To begin with, a total of 389
journal articles published from 1990 to 2020 were retrieved from the Web of
Science. Scientometric tools such as keyword co-occurrence analysis and
documentation co-citation analysis were adopted to quantify features and
characteristics of the research field. The findings bring to light pressing
questions in data-driven concrete research and suggest future opportunities for
the concrete community to fully utilize the capabilities of AI techniques.

---------------

### 12 Mar 2023 | [Conceptual Modeling and Artificial Intelligence: A Systematic Mapping  Study](https://arxiv.org/abs/2303.06758) | [⬇️](https://arxiv.org/pdf/2303.06758)
*Dominik Bork and Syed Juned Ali and Ben Roelens* 

  In conceptual modeling (CM), humans apply abstraction to represent excerpts
of reality for means of understanding and communication, and processing by
machines. Artificial Intelligence (AI) is applied to vast amounts of data to
automatically identify patterns or classify entities. While CM produces
comprehensible and explicit knowledge representations, the outcome of AI
algorithms often lacks these qualities while being able to extract knowledge
from large and unstructured representations. Recently, a trend toward
intertwining CM and AI emerged. This systematic mapping study shows how this
interdisciplinary research field is structured, which mutual benefits are
gained by the intertwining, and future research directions.

---------------

### 07 Feb 2024 | [Position Paper: Against Spurious Sparks $-$ Dovelating Inflated AI  Claims](https://arxiv.org/abs/2402.03962) | [⬇️](https://arxiv.org/pdf/2402.03962)
*Patrick Altmeyer, Andrew M. Demetriou, Antony Bartlett, Cynthia C. S.  Liem* 

  Humans have a tendency to see 'human'-like qualities in objects around them.
We name our cars, and talk to pets and even household appliances, as if they
could understand us as other humans do. This behavior, called anthropomorphism,
is also seeing traction in Machine Learning (ML), where human-like intelligence
is claimed to be perceived in Large Language Models (LLMs). In this position
paper, considering professional incentives, human biases, and general
methodological setups, we discuss how the current search for Artificial General
Intelligence (AGI) is a perfect storm for over-attributing human-like qualities
to LLMs. In several experiments, we demonstrate that the discovery of
human-interpretable patterns in latent spaces should not be a surprising
outcome. Also in consideration of common AI portrayal in the media, we call for
the academic community to exercise extra caution, and to be extra aware of
principles of academic integrity, in interpreting and communicating about AI
research outcomes.

---------------

### 15 Dec 2023 | [Investigating Responsible AI for Scientific Research: An Empirical Study](https://arxiv.org/abs/2312.09561) | [⬇️](https://arxiv.org/pdf/2312.09561)
*Muneera Bano, Didar Zowghi, Pip Shea, Georgina Ibarra* 

  Scientific research organizations that are developing and deploying
Artificial Intelligence (AI) systems are at the intersection of technological
progress and ethical considerations. The push for Responsible AI (RAI) in such
institutions underscores the increasing emphasis on integrating ethical
considerations within AI design and development, championing core values like
fairness, accountability, and transparency. For scientific research
organizations, prioritizing these practices is paramount not just for
mitigating biases and ensuring inclusivity, but also for fostering trust in AI
systems among both users and broader stakeholders. In this paper, we explore
the practices at a research organization concerning RAI practices, aiming to
assess the awareness and preparedness regarding the ethical risks inherent in
AI design and development. We have adopted a mixed-method research approach,
utilising a comprehensive survey combined with follow-up in-depth interviews
with selected participants from AI-related projects. Our results have revealed
certain knowledge gaps concerning ethical, responsible, and inclusive AI, with
limitations in awareness of the available AI ethics frameworks. This revealed
an overarching underestimation of the ethical risks that AI technologies can
present, especially when implemented without proper guidelines and governance.
Our findings reveal the need for a holistic and multi-tiered strategy to uplift
capabilities and better support science research teams for responsible,
ethical, and inclusive AI development and deployment.

---------------

### 18 Feb 2022 | [Needs and Artificial Intelligence](https://arxiv.org/abs/2203.03715) | [⬇️](https://arxiv.org/pdf/2203.03715)
*Soheil Human and Ryan Watkins* 

  Throughout their history, homo sapiens have used technologies to better
satisfy their needs. The relation between needs and technology is so
fundamental that the US National Research Council defined the distinguishing
characteristic of technology as its goal "to make modifications in the world to
meet human needs". Artificial intelligence (AI) is one of the most promising
emerging technologies of our time. Similar to other technologies, AI is
expected "to meet [human] needs". In this article, we reflect on the
relationship between needs and AI, and call for the realisation of needs-aware
AI systems. We argue that re-thinking needs for, through, and by AI can be a
very useful means towards the development of realistic approaches for
Sustainable, Human-centric, Accountable, Lawful, and Ethical (HALE) AI systems.
We discuss some of the most critical gaps, barriers, enablers, and drivers of
co-creating future AI-based socio-technical systems in which [human] needs are
well considered and met. Finally, we provide an overview of potential threats
and HALE considerations that should be carefully taken into account, and call
for joint, immediate, and interdisciplinary efforts and collaborations.

---------------

### 13 Jan 2024 | [Artificial intelligence to automate the systematic review of scientific  literature](https://arxiv.org/abs/2401.10917) | [⬇️](https://arxiv.org/pdf/2401.10917)
*Jos\'e de la Torre-L\'opez and Aurora Ram\'irez and Jos\'e Ra\'ul  Romero* 

  Artificial intelligence (AI) has acquired notorious relevance in modern
computing as it effectively solves complex tasks traditionally done by humans.
AI provides methods to represent and infer knowledge, efficiently manipulate
texts and learn from vast amount of data. These characteristics are applicable
in many activities that human find laborious or repetitive, as is the case of
the analysis of scientific literature. Manually preparing and writing a
systematic literature review (SLR) takes considerable time and effort, since it
requires planning a strategy, conducting the literature search and analysis,
and reporting the findings. Depending on the area under study, the number of
papers retrieved can be of hundreds or thousands, meaning that filtering those
relevant ones and extracting the key information becomes a costly and
error-prone process. However, some of the involved tasks are repetitive and,
therefore, subject to automation by means of AI. In this paper, we present a
survey of AI techniques proposed in the last 15 years to help researchers
conduct systematic analyses of scientific literature. We describe the tasks
currently supported, the types of algorithms applied, and available tools
proposed in 34 primary studies. This survey also provides a historical
perspective of the evolution of the field and the role that humans can play in
an increasingly automated SLR process.

---------------

### 07 Dec 2022 | [Artificial Intelligence Security Competition (AISC)](https://arxiv.org/abs/2212.03412) | [⬇️](https://arxiv.org/pdf/2212.03412)
*Yinpeng Dong, Peng Chen, Senyou Deng, Lianji L, Yi Sun, Hanyu Zhao,  Jiaxing Li, Yunteng Tan, Xinyu Liu, Yangyi Dong, Enhui Xu, Jincai Xu, Shu Xu,  Xuelin Fu, Changfeng Sun, Haoliang Han, Xuchong Zhang, Shen Chen, Zhimin Sun,  Junyi Cao, Taiping Yao, Shouhong Ding, Yu Wu, Jian Lin, Tianpeng Wu, Ye Wang,  Yu Fu, Lin Feng, Kangkang Gao, Zeyu Liu, Yuanzhe Pang, Chengqi Duan, Huipeng  Zhou, Yajie Wang, Yuhang Zhao, Shangbo Wu, Haoran Lyu, Zhiyu Lin, Yifei Gao,  Shuang Li, Haonan Wang, Jitao Sang, Chen Ma, Junhao Zheng, Yijia Li, Chao  Shen, Chenhao Lin, Zhichao Cui, Guoshuai Liu, Huafeng Shi, Kun Hu, Mengxin  Zhang* 

  The security of artificial intelligence (AI) is an important research area
towards safe, reliable, and trustworthy AI systems. To accelerate the research
on AI security, the Artificial Intelligence Security Competition (AISC) was
organized by the Zhongguancun Laboratory, China Industrial Control Systems
Cyber Emergency Response Team, Institute for Artificial Intelligence, Tsinghua
University, and RealAI as part of the Zhongguancun International Frontier
Technology Innovation Competition (https://www.zgc-aisc.com/en). The
competition consists of three tracks, including Deepfake Security Competition,
Autonomous Driving Security Competition, and Face Recognition Security
Competition. This report will introduce the competition rules of these three
tracks and the solutions of top-ranking teams in each track.

---------------

### 01 Nov 2018 | [AI for the Common Good?! Pitfalls, challenges, and Ethics Pen-Testing](https://arxiv.org/abs/1810.12847) | [⬇️](https://arxiv.org/pdf/1810.12847)
*Bettina Berendt* 

  Recently, many AI researchers and practitioners have embarked on research
visions that involve doing AI for "Good". This is part of a general drive
towards infusing AI research and practice with ethical thinking. One frequent
theme in current ethical guidelines is the requirement that AI be good for all,
or: contribute to the Common Good. But what is the Common Good, and is it
enough to want to be good? Via four lead questions, I will illustrate
challenges and pitfalls when determining, from an AI point of view, what the
Common Good is and how it can be enhanced by AI. The questions are: What is the
problem / What is a problem?, Who defines the problem?, What is the role of
knowledge?, and What are important side effects and dynamics? The illustration
will use an example from the domain of "AI for Social Good", more specifically
"Data Science for Social Good". Even if the importance of these questions may
be known at an abstract level, they do not get asked sufficiently in practice,
as shown by an exploratory study of 99 contributions to recent conferences in
the field. Turning these challenges and pitfalls into a positive
recommendation, as a conclusion I will draw on another characteristic of
computer-science thinking and practice to make these impediments visible and
attenuate them: "attacks" as a method for improving design. This results in the
proposal of ethics pen-testing as a method for helping AI designs to better
contribute to the Common Good.

---------------

### 15 May 2019 | [Neural-Symbolic Computing: An Effective Methodology for Principled  Integration of Machine Learning and Reasoning](https://arxiv.org/abs/1905.06088) | [⬇️](https://arxiv.org/pdf/1905.06088)
*Artur d'Avila Garcez, Marco Gori, Luis C. Lamb, Luciano Serafini,  Michael Spranger, Son N. Tran* 

  Current advances in Artificial Intelligence and machine learning in general,
and deep learning in particular have reached unprecedented impact not only
across research communities, but also over popular media channels. However,
concerns about interpretability and accountability of AI have been raised by
influential thinkers. In spite of the recent impact of AI, several works have
identified the need for principled knowledge representation and reasoning
mechanisms integrated with deep learning-based systems to provide sound and
explainable models for such systems. Neural-symbolic computing aims at
integrating, as foreseen by Valiant, two most fundamental cognitive abilities:
the ability to learn from the environment, and the ability to reason from what
has been learned. Neural-symbolic computing has been an active topic of
research for many years, reconciling the advantages of robust learning in
neural networks and reasoning and interpretability of symbolic representation.
In this paper, we survey recent accomplishments of neural-symbolic computing as
a principled methodology for integrated machine learning and reasoning. We
illustrate the effectiveness of the approach by outlining the main
characteristics of the methodology: principled integration of neural learning
with symbolic knowledge representation and reasoning allowing for the
construction of explainable AI systems. The insights provided by
neural-symbolic computing shed new light on the increasingly prominent need for
interpretable and accountable AI systems.

---------------

### 14 Dec 2022 | [AI Explainability and Governance in Smart Energy Systems: A Review](https://arxiv.org/abs/2211.00069) | [⬇️](https://arxiv.org/pdf/2211.00069)
*Roba Alsaigh, Rashid Mehmood, Iyad Katib* 

  Traditional electrical power grids have long suffered from operational
unreliability, instability, inflexibility, and inefficiency. Smart grids (or
smart energy systems) continue to transform the energy sector with emerging
technologies, renewable energy sources, and other trends. Artificial
intelligence (AI) is being applied to smart energy systems to process massive
and complex data in this sector and make smart and timely decisions. However,
the lack of explainability and governability of AI is a major concern for
stakeholders hindering a fast uptake of AI in the energy sector. This paper
provides a review of AI explainability and governance in smart energy systems.
We collect 3,568 relevant papers from the Scopus database, automatically
discover 15 parameters or themes for AI governance in energy and elaborate the
research landscape by reviewing over 150 papers and providing temporal
progressions of the research. The methodology for discovering parameters or
themes is based on "deep journalism", our data-driven deep learning-based big
data analytics approach to automatically discover and analyse cross-sectional
multi-perspective information to enable better decision-making and develop
better instruments for governance. The findings show that research on AI
explainability in energy systems is segmented and narrowly focussed on a few AI
traits and energy system problems. This paper deepens our knowledge of AI
governance in energy and is expected to help governments, industry, academics,
energy prosumers, and other stakeholders to understand the landscape of AI in
the energy sector, leading to better design, operations, utilisation, and risk
management of energy systems.

---------------

### 04 Oct 2017 | [Intelligence Quotient and Intelligence Grade of Artificial Intelligence](https://arxiv.org/abs/1709.10242) | [⬇️](https://arxiv.org/pdf/1709.10242)
*Feng Liu, Yong Shi, Ying Liu* 

  Although artificial intelligence is currently one of the most interesting
areas in scientific research, the potential threats posed by emerging AI
systems remain a source of persistent controversy. To address the issue of AI
threat, this study proposes a standard intelligence model that unifies AI and
human characteristics in terms of four aspects of knowledge, i.e., input,
output, mastery, and creation. Using this model, we observe three challenges,
namely, expanding of the von Neumann architecture; testing and ranking the
intelligence quotient of naturally and artificially intelligent systems,
including humans, Google, Bing, Baidu, and Siri; and finally, the dividing of
artificially intelligent systems into seven grades from robots to Google Brain.
Based on this, we conclude that AlphaGo belongs to the third grade.

---------------

### 08 May 2022 | [A Survey on AI Sustainability: Emerging Trends on Learning Algorithms  and Research Challenges](https://arxiv.org/abs/2205.03824) | [⬇️](https://arxiv.org/pdf/2205.03824)
*Zhenghua Chen, Min Wu, Alvin Chan, Xiaoli Li, Yew-Soon Ong* 

  Artificial Intelligence (AI) is a fast-growing research and development (R&D)
discipline which is attracting increasing attention because of its promises to
bring vast benefits for consumers and businesses, with considerable benefits
promised in productivity growth and innovation. To date it has reported
significant accomplishments in many areas that have been deemed as challenging
for machines, ranging from computer vision, natural language processing, audio
analysis to smart sensing and many others. The technical trend in realizing the
successes has been towards increasing complex and large size AI models so as to
solve more complex problems at superior performance and robustness. This rapid
progress, however, has taken place at the expense of substantial environmental
costs and resources. Besides, debates on the societal impacts of AI, such as
fairness, safety and privacy, have continued to grow in intensity. These issues
have presented major concerns pertaining to the sustainable development of AI.
In this work, we review major trends in machine learning approaches that can
address the sustainability problem of AI. Specifically, we examine emerging AI
methodologies and algorithms for addressing the sustainability issue of AI in
two major aspects, i.e., environmental sustainability and social sustainability
of AI. We will also highlight the major limitations of existing studies and
propose potential research challenges and directions for the development of
next generation of sustainable AI techniques. We believe that this technical
review can help to promote a sustainable development of AI R&D activities for
the research community.

---------------

### 06 Oct 2021 | [A curated, ontology-based, large-scale knowledge graph of artificial  intelligence tasks and benchmarks](https://arxiv.org/abs/2110.01434) | [⬇️](https://arxiv.org/pdf/2110.01434)
*Kathrin Blagec, Adriano Barbosa-Silva, Simon Ott, Matthias Samwald* 

  Research in artificial intelligence (AI) is addressing a growing number of
tasks through a rapidly growing number of models and methodologies. This makes
it difficult to keep track of where novel AI methods are successfully -- or
still unsuccessfully -- applied, how progress is measured, how different
advances might synergize with each other, and how future research should be
prioritized.
  To help address these issues, we created the Intelligence Task Ontology and
Knowledge Graph (ITO), a comprehensive, richly structured and manually curated
resource on artificial intelligence tasks, benchmark results and performance
metrics. The current version of ITO contain 685,560 edges, 1,100 classes
representing AI processes and 1,995 properties representing performance
metrics.
  The goal of ITO is to enable precise and network-based analyses of the global
landscape of AI tasks and capabilities. ITO is based on technologies that allow
for easy integration and enrichment with external data, automated inference and
continuous, collaborative expert curation of underlying ontological models. We
make the ITO dataset and a collection of Jupyter notebooks utilising ITO openly
available.

---------------

### 06 Nov 2023 | [Inclusive Portraits: Race-Aware Human-in-the-Loop Technology](https://arxiv.org/abs/2311.03567) | [⬇️](https://arxiv.org/pdf/2311.03567)
*Claudia Flores-Saviaga, Christopher Curtis and Saiph Savage* 

  AI has revolutionized the processing of various services, including the
automatic facial verification of people. Automated approaches have demonstrated
their speed and efficiency in verifying a large volume of faces, but they can
face challenges when processing content from certain communities, including
communities of people of color. This challenge has prompted the adoption of
"human-in-the-loop" (HITL) approaches, where human workers collaborate with the
AI to minimize errors. However, most HITL approaches do not consider workers'
individual characteristics and backgrounds. This paper proposes a new approach,
called Inclusive Portraits (IP), that connects with social theories around race
to design a racially-aware human-in-the-loop system. Our experiments have
provided evidence that incorporating race into human-in-the-loop (HITL) systems
for facial verification can significantly enhance performance, especially for
services delivered to people of color. Our findings also highlight the
importance of considering individual worker characteristics in the design of
HITL systems, rather than treating workers as a homogenous group. Our research
has significant design implications for developing AI-enhanced services that
are more inclusive and equitable.

---------------

### 16 Jun 2020 | [Quality Management of Machine Learning Systems](https://arxiv.org/abs/2006.09529) | [⬇️](https://arxiv.org/pdf/2006.09529)
*P. Santhanam* 

  In the past decade, Artificial Intelligence (AI) has become a part of our
daily lives due to major advances in Machine Learning (ML) techniques. In spite
of an explosive growth in the raw AI technology and in consumer facing
applications on the internet, its adoption in business applications has
conspicuously lagged behind. For business/mission-critical systems, serious
concerns about reliability and maintainability of AI applications remain. Due
to the statistical nature of the output, software 'defects' are not well
defined. Consequently, many traditional quality management techniques such as
program debugging, static code analysis, functional testing, etc. have to be
reevaluated. Beyond the correctness of an AI model, many other new quality
attributes, such as fairness, robustness, explainability, transparency, etc.
become important in delivering an AI system. The purpose of this paper is to
present a view of a holistic quality management framework for ML applications
based on the current advances and identify new areas of software engineering
research to achieve a more trustworthy AI.

---------------

### 22 Jun 2018 | [The Foundations of Deep Learning with a Path Towards General  Intelligence](https://arxiv.org/abs/1806.08874) | [⬇️](https://arxiv.org/pdf/1806.08874)
*Eray \"Ozkural* 

  Like any field of empirical science, AI may be approached axiomatically. We
formulate requirements for a general-purpose, human-level AI system in terms of
postulates. We review the methodology of deep learning, examining the explicit
and tacit assumptions in deep learning research. Deep Learning methodology
seeks to overcome limitations in traditional machine learning research as it
combines facets of model richness, generality, and practical applicability. The
methodology so far has produced outstanding results due to a productive synergy
of function approximation, under plausible assumptions of irreducibility and
the efficiency of back-propagation family of algorithms. We examine these
winning traits of deep learning, and also observe the various known failure
modes of deep learning. We conclude by giving recommendations on how to extend
deep learning methodology to cover the postulates of general-purpose AI
including modularity, and cognitive architecture. We also relate deep learning
to advances in theoretical neuroscience research.

---------------

### 08 Mar 2022 | [Trust in AI and Implications for the AEC Research: A Literature Analysis](https://arxiv.org/abs/2203.03847) | [⬇️](https://arxiv.org/pdf/2203.03847)
*Newsha Emaminejad, Alexa Maria North, and Reza Akhavian* 

  Engendering trust in technically acceptable and psychologically embraceable
systems requires domain-specific research to capture unique characteristics of
the field of application. The architecture, engineering, and construction (AEC)
research community has been recently harnessing advanced solutions offered by
artificial intelligence (AI) to improve project workflows. Despite the unique
characteristics of work, workers, and workplaces in the AEC industry, the
concept of trust in AI has received very little attention in the literature.
This paper presents a comprehensive analysis of the academic literature in two
main areas of trust in AI and AI in the AEC, to explore the interplay between
AEC projects unique aspects and the sociotechnical concepts that lead to trust
in AI. A total of 490 peer-reviewed scholarly articles are analyzed in this
study. The main constituents of human trust in AI are identified from the
literature and are characterized within the AEC project types, processes, and
technologies.

---------------
**Date:** 09 Oct 2023

**Title:** AI Systems of Concern

**Abstract Link:** [https://arxiv.org/abs/2310.05876](https://arxiv.org/abs/2310.05876)

**PDF Link:** [https://arxiv.org/pdf/2310.05876](https://arxiv.org/pdf/2310.05876)

---

**Date:** 26 Dec 2023

**Title:** Can ChatGPT Read Who You Are?

**Abstract Link:** [https://arxiv.org/abs/2312.16070](https://arxiv.org/abs/2312.16070)

**PDF Link:** [https://arxiv.org/pdf/2312.16070](https://arxiv.org/pdf/2312.16070)

---

**Date:** 19 Dec 2023

**Title:** Towards Human-centered Explainable AI: A Survey of User Studies for  Model Explanations

**Abstract Link:** [https://arxiv.org/abs/2210.11584](https://arxiv.org/abs/2210.11584)

**PDF Link:** [https://arxiv.org/pdf/2210.11584](https://arxiv.org/pdf/2210.11584)

---

**Date:** 17 Sep 2022

**Title:** Artificial Intelligence in Concrete Materials: A Scientometric View

**Abstract Link:** [https://arxiv.org/abs/2209.09636](https://arxiv.org/abs/2209.09636)

**PDF Link:** [https://arxiv.org/pdf/2209.09636](https://arxiv.org/pdf/2209.09636)

---

**Date:** 12 Mar 2023

**Title:** Conceptual Modeling and Artificial Intelligence: A Systematic Mapping  Study

**Abstract Link:** [https://arxiv.org/abs/2303.06758](https://arxiv.org/abs/2303.06758)

**PDF Link:** [https://arxiv.org/pdf/2303.06758](https://arxiv.org/pdf/2303.06758)

---

**Date:** 07 Feb 2024

**Title:** Position Paper: Against Spurious Sparks $-$ Dovelating Inflated AI  Claims

**Abstract Link:** [https://arxiv.org/abs/2402.03962](https://arxiv.org/abs/2402.03962)

**PDF Link:** [https://arxiv.org/pdf/2402.03962](https://arxiv.org/pdf/2402.03962)

---

**Date:** 15 Dec 2023

**Title:** Investigating Responsible AI for Scientific Research: An Empirical Study

**Abstract Link:** [https://arxiv.org/abs/2312.09561](https://arxiv.org/abs/2312.09561)

**PDF Link:** [https://arxiv.org/pdf/2312.09561](https://arxiv.org/pdf/2312.09561)

---

**Date:** 18 Feb 2022

**Title:** Needs and Artificial Intelligence

**Abstract Link:** [https://arxiv.org/abs/2203.03715](https://arxiv.org/abs/2203.03715)

**PDF Link:** [https://arxiv.org/pdf/2203.03715](https://arxiv.org/pdf/2203.03715)

---

**Date:** 13 Jan 2024

**Title:** Artificial intelligence to automate the systematic review of scientific  literature

**Abstract Link:** [https://arxiv.org/abs/2401.10917](https://arxiv.org/abs/2401.10917)

**PDF Link:** [https://arxiv.org/pdf/2401.10917](https://arxiv.org/pdf/2401.10917)

---

**Date:** 07 Dec 2022

**Title:** Artificial Intelligence Security Competition (AISC)

**Abstract Link:** [https://arxiv.org/abs/2212.03412](https://arxiv.org/abs/2212.03412)

**PDF Link:** [https://arxiv.org/pdf/2212.03412](https://arxiv.org/pdf/2212.03412)

---

**Date:** 01 Nov 2018

**Title:** AI for the Common Good?! Pitfalls, challenges, and Ethics Pen-Testing

**Abstract Link:** [https://arxiv.org/abs/1810.12847](https://arxiv.org/abs/1810.12847)

**PDF Link:** [https://arxiv.org/pdf/1810.12847](https://arxiv.org/pdf/1810.12847)

---

**Date:** 15 May 2019

**Title:** Neural-Symbolic Computing: An Effective Methodology for Principled  Integration of Machine Learning and Reasoning

**Abstract Link:** [https://arxiv.org/abs/1905.06088](https://arxiv.org/abs/1905.06088)

**PDF Link:** [https://arxiv.org/pdf/1905.06088](https://arxiv.org/pdf/1905.06088)

---

**Date:** 14 Dec 2022

**Title:** AI Explainability and Governance in Smart Energy Systems: A Review

**Abstract Link:** [https://arxiv.org/abs/2211.00069](https://arxiv.org/abs/2211.00069)

**PDF Link:** [https://arxiv.org/pdf/2211.00069](https://arxiv.org/pdf/2211.00069)

---

**Date:** 04 Oct 2017

**Title:** Intelligence Quotient and Intelligence Grade of Artificial Intelligence

**Abstract Link:** [https://arxiv.org/abs/1709.10242](https://arxiv.org/abs/1709.10242)

**PDF Link:** [https://arxiv.org/pdf/1709.10242](https://arxiv.org/pdf/1709.10242)

---

**Date:** 08 May 2022

**Title:** A Survey on AI Sustainability: Emerging Trends on Learning Algorithms  and Research Challenges

**Abstract Link:** [https://arxiv.org/abs/2205.03824](https://arxiv.org/abs/2205.03824)

**PDF Link:** [https://arxiv.org/pdf/2205.03824](https://arxiv.org/pdf/2205.03824)

---

**Date:** 06 Oct 2021

**Title:** A curated, ontology-based, large-scale knowledge graph of artificial  intelligence tasks and benchmarks

**Abstract Link:** [https://arxiv.org/abs/2110.01434](https://arxiv.org/abs/2110.01434)

**PDF Link:** [https://arxiv.org/pdf/2110.01434](https://arxiv.org/pdf/2110.01434)

---

**Date:** 06 Nov 2023

**Title:** Inclusive Portraits: Race-Aware Human-in-the-Loop Technology

**Abstract Link:** [https://arxiv.org/abs/2311.03567](https://arxiv.org/abs/2311.03567)

**PDF Link:** [https://arxiv.org/pdf/2311.03567](https://arxiv.org/pdf/2311.03567)

---

**Date:** 16 Jun 2020

**Title:** Quality Management of Machine Learning Systems

**Abstract Link:** [https://arxiv.org/abs/2006.09529](https://arxiv.org/abs/2006.09529)

**PDF Link:** [https://arxiv.org/pdf/2006.09529](https://arxiv.org/pdf/2006.09529)

---

**Date:** 22 Jun 2018

**Title:** The Foundations of Deep Learning with a Path Towards General  Intelligence

**Abstract Link:** [https://arxiv.org/abs/1806.08874](https://arxiv.org/abs/1806.08874)

**PDF Link:** [https://arxiv.org/pdf/1806.08874](https://arxiv.org/pdf/1806.08874)

---

**Date:** 08 Mar 2022

**Title:** Trust in AI and Implications for the AEC Research: A Literature Analysis

**Abstract Link:** [https://arxiv.org/abs/2203.03847](https://arxiv.org/abs/2203.03847)

**PDF Link:** [https://arxiv.org/pdf/2203.03847](https://arxiv.org/pdf/2203.03847)

---

