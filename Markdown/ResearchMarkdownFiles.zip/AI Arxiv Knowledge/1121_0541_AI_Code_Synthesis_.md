AI Code Synthesis ⌨️

### 🔎 AI Code Synthesis ⌨️



# AI Code Synthesis ⌨️

AI Code Synthesis is a project that aims to generate code using AI.

## Getting Started

These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

### Prerequisites

What things you need to install the software and how to install them

```
Python 3.6+
Pip
```

### Installing

A step by step series of examples that tell you how to get a development environment running

```
git clone https://github.com/joshuamcginnis/ai-code-synthesis.git
cd ai-code-synthesis
pip install -r requirements.txt
```

## Running the tests

Explain how to run the automated tests for this system

```
python test.py
```

## Deployment

Add additional notes about how to deploy this on a live system

## Built With

* [Python](https://www.python.org/) - The programming language used
* [TensorFlow](https://www.tensorflow.org/) - The machine learning framework used
* [Keras](https://keras.io/) - The deep learning library used

## Contributing

Please read [CONTRIBUTING.md](https://gist.github.com/PurpleBooth/b24679402957c63ec426) for details on our code of conduct, and the process for submitting pull requests to us.

## Versioning

We use [SemVer](http://semver.org/) for versioning. For the versions available, see the [tags on this repository](https://github.com/your/project/tags).

## Authors

* **Joshua McGinnis** - *Initial work* - [joshuamcginnis](https://github.com/joshuamcginnis)

See also the list of [contributors](https://github.com/your/project/contributors) who participated in this project.

## License

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.
# 🩺🔍 Search Results
### 27 May 2023 | [Synthesizing a Progression of Subtasks for Block-Based Visual  Programming Tasks](https://arxiv.org/abs/2305.17518) | [⬇️](https://arxiv.org/pdf/2305.17518)
*Alperen Tercan, Ahana Ghosh, Hasan Ferit Eniser, Maria Christakis,  Adish Singla* 

  Block-based visual programming environments play an increasingly important
role in introducing computing concepts to K-12 students. In recent years, they
have also gained popularity in neuro-symbolic AI, serving as a benchmark to
evaluate general problem-solving and logical reasoning skills. The open-ended
and conceptual nature of these visual programming tasks make them challenging,
both for state-of-the-art AI agents as well as for novice programmers. A
natural approach to providing assistance for problem-solving is breaking down a
complex task into a progression of simpler subtasks; however, this is not
trivial given that the solution codes are typically nested and have non-linear
execution behavior. In this paper, we formalize the problem of synthesizing
such a progression for a given reference block-based visual programming task.
We propose a novel synthesis algorithm that generates a progression of subtasks
that are high-quality, well-spaced in terms of their complexity, and solving
this progression leads to solving the reference task. We show the utility of
our synthesis algorithm in improving the efficacy of AI agents (in this case,
neural program synthesizers) for solving tasks in the Karel programming
environment. Then, we conduct a user study to demonstrate that our synthesized
progression of subtasks can assist a novice programmer in solving tasks in the
Hour of Code: Maze Challenge by Code-dot-org.

---------------

### 13 Apr 2023 | [Who Evaluates the Evaluators? On Automatic Metrics for Assessing  AI-based Offensive Code Generators](https://arxiv.org/abs/2212.06008) | [⬇️](https://arxiv.org/pdf/2212.06008)
*Pietro Liguori, Cristina Improta, Roberto Natella, Bojan Cukic, and  Domenico Cotroneo* 

  AI-based code generators are an emerging solution for automatically writing
programs starting from descriptions in natural language, by using deep neural
networks (Neural Machine Translation, NMT). In particular, code generators have
been used for ethical hacking and offensive security testing by generating
proof-of-concept attacks. Unfortunately, the evaluation of code generators
still faces several issues. The current practice uses output similarity
metrics, i.e., automatic metrics that compute the textual similarity of
generated code with ground-truth references. However, it is not clear what
metric to use, and which metric is most suitable for specific contexts. This
work analyzes a large set of output similarity metrics on offensive code
generators. We apply the metrics on two state-of-the-art NMT models using two
datasets containing offensive assembly and Python code with their descriptions
in the English language. We compare the estimates from the automatic metrics
with human evaluation and provide practical insights into their strengths and
limitations.

---------------

### 23 May 2023 | [Generalizable Synthetic Image Detection via Language-guided Contrastive  Learning](https://arxiv.org/abs/2305.13800) | [⬇️](https://arxiv.org/pdf/2305.13800)
*Haiwei Wu and Jiantao Zhou and Shile Zhang* 

  The heightened realism of AI-generated images can be attributed to the rapid
development of synthetic models, including generative adversarial networks
(GANs) and diffusion models (DMs). The malevolent use of synthetic images, such
as the dissemination of fake news or the creation of fake profiles, however,
raises significant concerns regarding the authenticity of images. Though many
forensic algorithms have been developed for detecting synthetic images, their
performance, especially the generalization capability, is still far from being
adequate to cope with the increasing number of synthetic models. In this work,
we propose a simple yet very effective synthetic image detection method via a
language-guided contrastive learning and a new formulation of the detection
problem. We first augment the training images with carefully-designed textual
labels, enabling us to use a joint image-text contrastive learning for the
forensic feature extraction. In addition, we formulate the synthetic image
detection as an identification problem, which is vastly different from the
traditional classification-based approaches. It is shown that our proposed
LanguAge-guided SynThEsis Detection (LASTED) model achieves much improved
generalizability to unseen image generation models and delivers promising
performance that far exceeds state-of-the-art competitors by +22.66% accuracy
and +15.24% AUC. The code is available at https://github.com/HighwayWu/LASTED.

---------------

### 26 Jun 2023 | [Self-supervised novel 2D view synthesis of large-scale scenes with  efficient multi-scale voxel carving](https://arxiv.org/abs/2306.14709) | [⬇️](https://arxiv.org/pdf/2306.14709)
*Alexandra Budisteanu, Dragos Costea, Alina Marcu and Marius Leordeanu* 

  The task of generating novel views of real scenes is increasingly important
nowadays when AI models become able to create realistic new worlds. In many
practical applications, it is important for novel view synthesis methods to
stay grounded in the physical world as much as possible, while also being able
to imagine it from previously unseen views. While most current methods are
developed and tested in virtual environments with small scenes and no errors in
pose and depth information, we push the boundaries to the real-world domain of
large scales in the new context of UAVs. Our algorithmic contributions are two
folds. First, we manage to stay anchored in the real 3D world, by introducing
an efficient multi-scale voxel carving method, which is able to accommodate
significant noises in pose, depth, and illumination variations, while being
able to reconstruct the view of the world from drastically different poses at
test time. Second, our final high-resolution output is efficiently self-trained
on data automatically generated by the voxel carving module, which gives it the
flexibility to adapt efficiently to any scene. We demonstrated the
effectiveness of our method on highly complex and large-scale scenes in real
environments while outperforming the current state-of-the-art. Our code is
publicly available: https://github.com/onorabil/MSVC.

---------------

### 22 Nov 2022 | [Fusing Global and Local Features for Generalized AI-Synthesized Image  Detection](https://arxiv.org/abs/2203.13964) | [⬇️](https://arxiv.org/pdf/2203.13964)
*Yan Ju, Shan Jia, Lipeng Ke, Hongfei Xue, Koki Nagano, Siwei Lyu* 

  With the development of the Generative Adversarial Networks (GANs) and
DeepFakes, AI-synthesized images are now of such high quality that humans can
hardly distinguish them from real images. It is imperative for media forensics
to develop detectors to expose them accurately. Existing detection methods have
shown high performance in generated images detection, but they tend to
generalize poorly in the real-world scenarios, where the synthetic images are
usually generated with unseen models using unknown source data. In this work,
we emphasize the importance of combining information from the whole image and
informative patches in improving the generalization ability of AI-synthesized
image detection. Specifically, we design a two-branch model to combine global
spatial information from the whole image and local informative features from
multiple patches selected by a novel patch selection module. Multi-head
attention mechanism is further utilized to fuse the global and local features.
We collect a highly diverse dataset synthesized by 19 models with various
objects and resolutions to evaluate our model. Experimental results demonstrate
the high accuracy and good generalization ability of our method in detecting
generated images. Our code is available at
https://github.com/littlejuyan/FusingGlobalandLocal.

---------------

### 25 Feb 2024 | [RoboCodeX: Multimodal Code Generation for Robotic Behavior Synthesis](https://arxiv.org/abs/2402.16117) | [⬇️](https://arxiv.org/pdf/2402.16117)
*Yao Mu, Junting Chen, Qinglong Zhang, Shoufa Chen, Qiaojun Yu,  Chongjian Ge, Runjian Chen, Zhixuan Liang, Mengkang Hu, Chaofan Tao, Peize  Sun, Haibao Yu, Chao Yang, Wenqi Shao, Wenhai Wang, Jifeng Dai, Yu Qiao,  Mingyu Ding, Ping Luo* 

  Robotic behavior synthesis, the problem of understanding multimodal inputs
and generating precise physical control for robots, is an important part of
Embodied AI. Despite successes in applying multimodal large language models for
high-level understanding, it remains challenging to translate these conceptual
understandings into detailed robotic actions while achieving generalization
across various scenarios. In this paper, we propose a tree-structured
multimodal code generation framework for generalized robotic behavior
synthesis, termed RoboCodeX. RoboCodeX decomposes high-level human instructions
into multiple object-centric manipulation units consisting of physical
preferences such as affordance and safety constraints, and applies code
generation to introduce generalization ability across various robotics
platforms. To further enhance the capability to map conceptual and perceptual
understanding into control commands, a specialized multimodal reasoning dataset
is collected for pre-training and an iterative self-updating methodology is
introduced for supervised fine-tuning. Extensive experiments demonstrate that
RoboCodeX achieves state-of-the-art performance in both simulators and real
robots on four different kinds of manipulation tasks and one navigation task.

---------------

### 02 Feb 2024 | [Conditional Diffusion Models for Semantic 3D Brain MRI Synthesis](https://arxiv.org/abs/2305.18453) | [⬇️](https://arxiv.org/pdf/2305.18453)
*Zolnamar Dorjsembe, Hsing-Kuo Pao, Sodtavilan Odonchimed, Furen Xiao* 

  Artificial intelligence (AI) in healthcare, especially in medical imaging,
faces challenges due to data scarcity and privacy concerns. Addressing these,
we introduce Med-DDPM, a diffusion model designed for 3D semantic brain MRI
synthesis. This model effectively tackles data scarcity and privacy issues by
integrating semantic conditioning. This involves the channel-wise concatenation
of a conditioning image to the model input, enabling control in image
generation. Med-DDPM demonstrates superior stability and performance compared
to existing 3D brain imaging synthesis methods. It generates diverse,
anatomically coherent images with high visual fidelity. In terms of dice score
accuracy in the tumor segmentation task, Med-DDPM achieves 0.6207, close to the
0.6531 accuracy of real images, and outperforms baseline models. Combined with
real images, it further increases segmentation accuracy to 0.6675, showing the
potential of our proposed method for data augmentation. This model represents
the first use of a diffusion model in 3D semantic brain MRI synthesis,
producing high-quality images. Its semantic conditioning feature also shows
potential for image anonymization in biomedical imaging, addressing data and
privacy issues. We provide the code and model weights for Med-DDPM on our
GitHub repository (https://github.com/mobaidoctor/med-ddpm/) to support
reproducibility.

---------------

### 26 Jul 2022 | [Text-Guided Synthesis of Artistic Images with Retrieval-Augmented  Diffusion Models](https://arxiv.org/abs/2207.13038) | [⬇️](https://arxiv.org/pdf/2207.13038)
*Robin Rombach and Andreas Blattmann and Bj\"orn Ommer* 

  Novel architectures have recently improved generative image synthesis leading
to excellent visual quality in various tasks. Of particular note is the field
of ``AI-Art'', which has seen unprecedented growth with the emergence of
powerful multimodal models such as CLIP. By combining speech and image
synthesis models, so-called ``prompt-engineering'' has become established, in
which carefully selected and composed sentences are used to achieve a certain
visual style in the synthesized image. In this note, we present an alternative
approach based on retrieval-augmented diffusion models (RDMs). In RDMs, a set
of nearest neighbors is retrieved from an external database during training for
each training instance, and the diffusion model is conditioned on these
informative samples. During inference (sampling), we replace the retrieval
database with a more specialized database that contains, for example, only
images of a particular visual style. This provides a novel way to prompt a
general trained model after training and thereby specify a particular visual
style. As shown by our experiments, this approach is superior to specifying the
visual style within the text prompt. We open-source code and model weights at
https://github.com/CompVis/latent-diffusion .

---------------

### 26 Oct 2022 | [When Age-Invariant Face Recognition Meets Face Age Synthesis: A  Multi-Task Learning Framework and A New Benchmark](https://arxiv.org/abs/2210.09835) | [⬇️](https://arxiv.org/pdf/2210.09835)
*Zhizhong Huang and Junping Zhang and Hongming Shan* 

  To minimize the impact of age variation on face recognition, age-invariant
face recognition (AIFR) extracts identity-related discriminative features by
minimizing the correlation between identity- and age-related features while
face age synthesis (FAS) eliminates age variation by converting the faces in
different age groups to the same group. However, AIFR lacks visual results for
model interpretation and FAS compromises downstream recognition due to
artifacts. Therefore, we propose a unified, multi-task framework to jointly
handle these two tasks, termed MTLFace, which can learn the age-invariant
identity-related representation for face recognition while achieving pleasing
face synthesis for model interpretation. Specifically, we propose an
attention-based feature decomposition to decompose the mixed face features into
two uncorrelated components -- identity- and age-related features -- in a
spatially constrained way. Unlike the conventional one-hot encoding that
achieves group-level FAS, we propose a novel identity conditional module to
achieve identity-level FAS, which can improve the age smoothness of synthesized
faces through a weight-sharing strategy. Benefiting from the proposed
multi-task framework, we then leverage those high-quality synthesized faces
from FAS to further boost AIFR via a novel selective fine-tuning strategy.
Furthermore, to advance both AIFR and FAS, we collect and release a large
cross-age face dataset with age and gender annotations, and a new benchmark
specifically designed for tracing long-missing children. Extensive experimental
results on five benchmark cross-age datasets demonstrate that MTLFace yields
superior performance for both AIFR and FAS. We further validate MTLFace on two
popular general face recognition datasets, obtaining competitive performance on
face recognition in the wild. Code is available at
http://hzzone.github.io/MTLFace.

---------------

### 21 Oct 2021 | [OpenABC-D: A Large-Scale Dataset For Machine Learning Guided Integrated  Circuit Synthesis](https://arxiv.org/abs/2110.11292) | [⬇️](https://arxiv.org/pdf/2110.11292)
*Animesh Basak Chowdhury and Benjamin Tan and Ramesh Karri and  Siddharth Garg* 

  Logic synthesis is a challenging and widely-researched combinatorial
optimization problem during integrated circuit (IC) design. It transforms a
high-level description of hardware in a programming language like Verilog into
an optimized digital circuit netlist, a network of interconnected Boolean logic
gates, that implements the function. Spurred by the success of ML in solving
combinatorial and graph problems in other domains, there is growing interest in
the design of ML-guided logic synthesis tools. Yet, there are no standard
datasets or prototypical learning tasks defined for this problem domain. Here,
we describe OpenABC-D,a large-scale, labeled dataset produced by synthesizing
open source designs with a leading open-source logic synthesis tool and
illustrate its use in developing, evaluating and benchmarking ML-guided logic
synthesis. OpenABC-D has intermediate and final outputs in the form of 870,000
And-Inverter-Graphs (AIGs) produced from 1500 synthesis runs plus labels such
as the optimized node counts, and de-lay. We define a generic learning problem
on this dataset and benchmark existing solutions for it. The codes related to
dataset creation and benchmark models are available
athttps://github.com/NYU-MLDA/OpenABC.git. The dataset generated is available
athttps://archive.nyu.edu/handle/2451/63311

---------------

### 11 Sep 2011 | [Breaking Instance-Independent Symmetries In Exact Graph Coloring](https://arxiv.org/abs/1109.2347) | [⬇️](https://arxiv.org/pdf/1109.2347)
*F. A. Aloul, I. L. Markov, A. Ramani, K. A. Sakallah* 

  Code optimization and high level synthesis can be posed as constraint
satisfaction and optimization problems, such as graph coloring used in register
allocation. Graph coloring is also used to model more traditional CSPs relevant
to AI, such as planning, time-tabling and scheduling. Provably optimal
solutions may be desirable for commercial and defense applications.
Additionally, for applications such as register allocation and code
optimization, naturally-occurring instances of graph coloring are often small
and can be solved optimally. A recent wave of improvements in algorithms for
Boolean satisfiability (SAT) and 0-1 Integer Linear Programming (ILP) suggests
generic problem-reduction methods, rather than problem-specific heuristics,
because (1) heuristics may be upset by new constraints, (2) heuristics tend to
ignore structure, and (3) many relevant problems are provably inapproximable.
  Problem reductions often lead to highly symmetric SAT instances, and
symmetries are known to slow down SAT solvers. In this work, we compare several
avenues for symmetry breaking, in particular when certain kinds of symmetry are
present in all generated instances. Our focus on reducing CSPs to SAT allows us
to leverage recent dramatic improvement in SAT solvers and automatically
benefit from future progress. We can use a variety of black-box SAT solvers
without modifying their source code because our symmetry-breaking techniques
are static, i.e., we detect symmetries and add symmetry breaking predicates
(SBPs) during pre-processing.
  An important result of our work is that among the types of
instance-independent SBPs we studied and their combinations, the simplest and
least complete constructions are the most effective. Our experiments also
clearly indicate that instance-independent symmetries should mostly be
processed together with instance-specific symmetries rather than at the
specification level, contrary to what has been suggested in the literature.

---------------

### 20 Nov 2023 | [Nepotistically Trained Generative-AI Models Collapse](https://arxiv.org/abs/2311.12202) | [⬇️](https://arxiv.org/pdf/2311.12202)
*Matyas Bohacek and Hany Farid* 

  Trained on massive amounts of human-generated content, AI (artificial
intelligence) image synthesis is capable of reproducing semantically coherent
images that match the visual appearance of its training data. We show that when
retrained on even small amounts of their own creation, these generative-AI
models produce highly distorted images. We also show that this distortion
extends beyond the text prompts used in retraining, and that once poisoned, the
models struggle to fully heal even after retraining on only real images.

---------------

### 20 Feb 2024 | [An Autonomous Large Language Model Agent for Chemical Literature Data  Mining](https://arxiv.org/abs/2402.12993) | [⬇️](https://arxiv.org/pdf/2402.12993)
*Kexin Chen, Hanqun Cao, Junyou Li, Yuyang Du, Menghao Guo, Xin Zeng,  Lanqing Li, Jiezhong Qiu, Pheng Ann Heng, Guangyong Chen* 

  Chemical synthesis, which is crucial for advancing material synthesis and
drug discovery, impacts various sectors including environmental science and
healthcare. The rise of technology in chemistry has generated extensive
chemical data, challenging researchers to discern patterns and refine synthesis
processes. Artificial intelligence (AI) helps by analyzing data to optimize
synthesis and increase yields. However, AI faces challenges in processing
literature data due to the unstructured format and diverse writing style of
chemical literature. To overcome these difficulties, we introduce an end-to-end
AI agent framework capable of high-fidelity extraction from extensive chemical
literature. This AI agent employs large language models (LLMs) for prompt
generation and iterative optimization. It functions as a chemistry assistant,
automating data collection and analysis, thereby saving manpower and enhancing
performance. Our framework's efficacy is evaluated using accuracy, recall, and
F1 score of reaction condition data, and we compared our method with human
experts in terms of content correctness and time efficiency. The proposed
approach marks a significant advancement in automating chemical literature
extraction and demonstrates the potential for AI to revolutionize data
management and utilization in chemistry.

---------------

### 01 May 2020 | [An Efficient Integration of Disentangled Attended Expression and  Identity FeaturesFor Facial Expression Transfer andSynthesis](https://arxiv.org/abs/2005.00499) | [⬇️](https://arxiv.org/pdf/2005.00499)
*Kamran Ali and Charles E. Hughes* 

  In this paper, we present an Attention-based Identity Preserving Generative
Adversarial Network (AIP-GAN) to overcome the identity leakage problem from a
source image to a generated face image, an issue that is encountered in a
cross-subject facial expression transfer and synthesis process. Our key insight
is that the identity preserving network should be able to disentangle and
compose shape, appearance, and expression information for efficient facial
expression transfer and synthesis. Specifically, the expression encoder of our
AIP-GAN disentangles the expression information from the input source image by
predicting its facial landmarks using our supervised spatial and channel-wise
attention module. Similarly, the disentangled expression-agnostic identity
features are extracted from the input target image by inferring its combined
intrinsic-shape and appearance image employing our self-supervised spatial and
channel-wise attention mod-ule. To leverage the expression and identity
information encoded by the intermediate layers of both of our encoders, we
combine these features with the features learned by the intermediate layers of
our decoder using a cross-encoder bilinear pooling operation. Experimental
results show the promising performance of our AIP-GAN based technique.

---------------

### 03 Nov 2022 | [CodeRL: Mastering Code Generation through Pretrained Models and Deep  Reinforcement Learning](https://arxiv.org/abs/2207.01780) | [⬇️](https://arxiv.org/pdf/2207.01780)
*Hung Le, Yue Wang, Akhilesh Deepak Gotmare, Silvio Savarese, Steven  C.H. Hoi* 

  Program synthesis or code generation aims to generate a program that
satisfies a problem specification. Recent approaches using large-scale
pretrained language models (LMs) have shown promising results, yet they have
some critical limitations. In particular, they often follow a standard
supervised fine-tuning procedure to train a code generation model only from the
pairs of natural-language problem descriptions and ground-truth programs. Such
paradigm largely ignores some important but potentially useful signals in the
problem specification such as unit tests, which thus often results in poor
performance when solving complex unseen coding tasks. To address the
limitations, we propose "CodeRL", a new framework for program synthesis tasks
through pretrained LMs and deep reinforcement learning (RL). Specifically,
during training, we treat the code-generating LM as an actor network, and
introduce a critic network that is trained to predict the functional
correctness of generated programs and provide dense feedback signals to the
actor. During inference, we introduce a new generation procedure with a
critical sampling strategy that allows a model to automatically regenerate
programs based on feedback from example unit tests and critic scores. For the
model backbones, we extended the encoder-decoder architecture of CodeT5 with
enhanced learning objectives, larger model sizes, and better pretraining data.
Our method not only achieves new SOTA results on the challenging APPS
benchmark, but also shows strong zero-shot transfer capability with new SOTA
results on the simpler MBPP benchmark.

---------------

### 09 Feb 2024 | [Vulnerabilities in AI Code Generators: Exploring Targeted Data Poisoning  Attacks](https://arxiv.org/abs/2308.04451) | [⬇️](https://arxiv.org/pdf/2308.04451)
*Domenico Cotroneo, Cristina Improta, Pietro Liguori, Roberto Natella* 

  AI-based code generators have become pivotal in assisting developers in
writing software starting from natural language (NL). However, they are trained
on large amounts of data, often collected from unsanitized online sources
(e.g., GitHub, HuggingFace). As a consequence, AI models become an easy target
for data poisoning, i.e., an attack that injects malicious samples into the
training data to generate vulnerable code.
  To address this threat, this work investigates the security of AI code
generators by devising a targeted data poisoning strategy. We poison the
training data by injecting increasing amounts of code containing security
vulnerabilities and assess the attack's success on different state-of-the-art
models for code generation. Our study shows that AI code generators are
vulnerable to even a small amount of poison. Notably, the attack success
strongly depends on the model architecture and poisoning rate, whereas it is
not influenced by the type of vulnerabilities. Moreover, since the attack does
not impact the correctness of code generated by pre-trained models, it is hard
to detect. Lastly, our work offers practical insights into understanding and
potentially mitigating this threat.

---------------

### 11 Oct 2023 | [DisCo: Disentangled Control for Realistic Human Dance Generation](https://arxiv.org/abs/2307.00040) | [⬇️](https://arxiv.org/pdf/2307.00040)
*Tan Wang, Linjie Li, Kevin Lin, Yuanhao Zhai, Chung-Ching Lin,  Zhengyuan Yang, Hanwang Zhang, Zicheng Liu, Lijuan Wang* 

  Generative AI has made significant strides in computer vision, particularly
in text-driven image/video synthesis (T2I/T2V). Despite the notable
advancements, it remains challenging in human-centric content synthesis such as
realistic dance generation. Current methodologies, primarily tailored for human
motion transfer, encounter difficulties when confronted with real-world dance
scenarios (e.g., social media dance) which require to generalize across a wide
spectrum of poses and intricate human details. In this paper, we depart from
the traditional paradigm of human motion transfer and emphasize two additional
critical attributes for the synthesis of human dance content in social media
contexts: (i) Generalizability: the model should be able to generalize beyond
generic human viewpoints as well as unseen human subjects, backgrounds, and
poses; (ii) Compositionality: it should allow for composition of seen/unseen
subjects, backgrounds, and poses from different sources seamlessly. To address
these challenges, we introduce DisCo, which includes a novel model architecture
with disentangled control to improve the compositionality of dance synthesis,
and an effective human attribute pre-training for better generalizability to
unseen humans. Extensive qualitative and quantitative results demonstrate that
DisCo can generate high-quality human dance images and videos with diverse
appearances and flexible motions. Code, demo, video and visualization are
available at: https://disco-dance.github.io/.

---------------

### 15 Jun 2023 | [The pop song generator: designing an online course to teach  collaborative, creative AI](https://arxiv.org/abs/2306.10069) | [⬇️](https://arxiv.org/pdf/2306.10069)
*Matthew Yee-king and Andrea Fiorucci and Mark d'Inverno* 

  This article describes and evaluates a new online AI-creativity course. The
course is based around three near-state-of-the-art AI models combined into a
pop song generating system. A fine-tuned GPT-2 model writes lyrics, Music-VAE
composes musical scores and instrumentation and Diffsinger synthesises a
singing voice. We explain the decisions made in designing the course which is
based on Piagetian, constructivist 'learning-by-doing'. We present details of
the five-week course design with learning objectives, technical concepts, and
creative and technical activities. We explain how we overcame technical
challenges to build a complete pop song generator system, consisting of Python
scripts, pre-trained models, and Javascript code that runs in a dockerised
Linux container via a web-based IDE. A quantitative analysis of student
activity provides evidence on engagement and a benchmark for future
improvements. A qualitative analysis of a workshop with experts validated the
overall course design, it suggested the need for a stronger creative brief and
ethical and legal content.

---------------

### 23 Jan 2022 | [ULSA: Unified Language of Synthesis Actions for Representation of  Synthesis Protocols](https://arxiv.org/abs/2201.09329) | [⬇️](https://arxiv.org/pdf/2201.09329)
*Zheren Wang, Kevin Cruse, Yuxing Fei, Ann Chia, Yan Zeng, Haoyan Huo,  Tanjin He, Bowen Deng, Olga Kononova and Gerbrand Ceder* 

  Applying AI power to predict syntheses of novel materials requires
high-quality, large-scale datasets. Extraction of synthesis information from
scientific publications is still challenging, especially for extracting
synthesis actions, because of the lack of a comprehensive labeled dataset using
a solid, robust, and well-established ontology for describing synthesis
procedures. In this work, we propose the first Unified Language of Synthesis
Actions (ULSA) for describing ceramics synthesis procedures. We created a
dataset of 3,040 synthesis procedures annotated by domain experts according to
the proposed ULSA scheme. To demonstrate the capabilities of ULSA, we built a
neural network-based model to map arbitrary ceramics synthesis paragraphs into
ULSA and used it to construct synthesis flowcharts for synthesis procedures.
Analysis for the flowcharts showed that (a) ULSA covers essential vocabulary
used by researchers when describing synthesis procedures and (b) it can capture
important features of synthesis protocols. This work is an important step
towards creating a synthesis ontology and a solid foundation for autonomous
robotic synthesis.

---------------

### 13 Jan 2024 | [Exploiting Modality-Specific Features For Multi-Modal Manipulation  Detection And Grounding](https://arxiv.org/abs/2309.12657) | [⬇️](https://arxiv.org/pdf/2309.12657)
*Jiazhen Wang, Bin Liu, Changtao Miao, Zhiwei Zhao, Wanyi Zhuang, Qi  Chu, Nenghai Yu* 

  AI-synthesized text and images have gained significant attention,
particularly due to the widespread dissemination of multi-modal manipulations
on the internet, which has resulted in numerous negative impacts on society.
Existing methods for multi-modal manipulation detection and grounding primarily
focus on fusing vision-language features to make predictions, while overlooking
the importance of modality-specific features, leading to sub-optimal results.
In this paper, we construct a simple and novel transformer-based framework for
multi-modal manipulation detection and grounding tasks. Our framework
simultaneously explores modality-specific features while preserving the
capability for multi-modal alignment. To achieve this, we introduce
visual/language pre-trained encoders and dual-branch cross-attention (DCA) to
extract and fuse modality-unique features. Furthermore, we design decoupled
fine-grained classifiers (DFC) to enhance modality-specific feature mining and
mitigate modality competition. Moreover, we propose an implicit manipulation
query (IMQ) that adaptively aggregates global contextual cues within each
modality using learnable queries, thereby improving the discovery of forged
details. Extensive experiments on the $\rm DGM^4$ dataset demonstrate the
superior performance of our proposed model compared to state-of-the-art
approaches.

---------------
**Date:** 27 May 2023

**Title:** Synthesizing a Progression of Subtasks for Block-Based Visual  Programming Tasks

**Abstract Link:** [https://arxiv.org/abs/2305.17518](https://arxiv.org/abs/2305.17518)

**PDF Link:** [https://arxiv.org/pdf/2305.17518](https://arxiv.org/pdf/2305.17518)

---

**Date:** 13 Apr 2023

**Title:** Who Evaluates the Evaluators? On Automatic Metrics for Assessing  AI-based Offensive Code Generators

**Abstract Link:** [https://arxiv.org/abs/2212.06008](https://arxiv.org/abs/2212.06008)

**PDF Link:** [https://arxiv.org/pdf/2212.06008](https://arxiv.org/pdf/2212.06008)

---

**Date:** 23 May 2023

**Title:** Generalizable Synthetic Image Detection via Language-guided Contrastive  Learning

**Abstract Link:** [https://arxiv.org/abs/2305.13800](https://arxiv.org/abs/2305.13800)

**PDF Link:** [https://arxiv.org/pdf/2305.13800](https://arxiv.org/pdf/2305.13800)

---

**Date:** 26 Jun 2023

**Title:** Self-supervised novel 2D view synthesis of large-scale scenes with  efficient multi-scale voxel carving

**Abstract Link:** [https://arxiv.org/abs/2306.14709](https://arxiv.org/abs/2306.14709)

**PDF Link:** [https://arxiv.org/pdf/2306.14709](https://arxiv.org/pdf/2306.14709)

---

**Date:** 22 Nov 2022

**Title:** Fusing Global and Local Features for Generalized AI-Synthesized Image  Detection

**Abstract Link:** [https://arxiv.org/abs/2203.13964](https://arxiv.org/abs/2203.13964)

**PDF Link:** [https://arxiv.org/pdf/2203.13964](https://arxiv.org/pdf/2203.13964)

---

**Date:** 25 Feb 2024

**Title:** RoboCodeX: Multimodal Code Generation for Robotic Behavior Synthesis

**Abstract Link:** [https://arxiv.org/abs/2402.16117](https://arxiv.org/abs/2402.16117)

**PDF Link:** [https://arxiv.org/pdf/2402.16117](https://arxiv.org/pdf/2402.16117)

---

**Date:** 02 Feb 2024

**Title:** Conditional Diffusion Models for Semantic 3D Brain MRI Synthesis

**Abstract Link:** [https://arxiv.org/abs/2305.18453](https://arxiv.org/abs/2305.18453)

**PDF Link:** [https://arxiv.org/pdf/2305.18453](https://arxiv.org/pdf/2305.18453)

---

**Date:** 26 Jul 2022

**Title:** Text-Guided Synthesis of Artistic Images with Retrieval-Augmented  Diffusion Models

**Abstract Link:** [https://arxiv.org/abs/2207.13038](https://arxiv.org/abs/2207.13038)

**PDF Link:** [https://arxiv.org/pdf/2207.13038](https://arxiv.org/pdf/2207.13038)

---

**Date:** 26 Oct 2022

**Title:** When Age-Invariant Face Recognition Meets Face Age Synthesis: A  Multi-Task Learning Framework and A New Benchmark

**Abstract Link:** [https://arxiv.org/abs/2210.09835](https://arxiv.org/abs/2210.09835)

**PDF Link:** [https://arxiv.org/pdf/2210.09835](https://arxiv.org/pdf/2210.09835)

---

**Date:** 21 Oct 2021

**Title:** OpenABC-D: A Large-Scale Dataset For Machine Learning Guided Integrated  Circuit Synthesis

**Abstract Link:** [https://arxiv.org/abs/2110.11292](https://arxiv.org/abs/2110.11292)

**PDF Link:** [https://arxiv.org/pdf/2110.11292](https://arxiv.org/pdf/2110.11292)

---

**Date:** 11 Sep 2011

**Title:** Breaking Instance-Independent Symmetries In Exact Graph Coloring

**Abstract Link:** [https://arxiv.org/abs/1109.2347](https://arxiv.org/abs/1109.2347)

**PDF Link:** [https://arxiv.org/pdf/1109.2347](https://arxiv.org/pdf/1109.2347)

---

**Date:** 20 Nov 2023

**Title:** Nepotistically Trained Generative-AI Models Collapse

**Abstract Link:** [https://arxiv.org/abs/2311.12202](https://arxiv.org/abs/2311.12202)

**PDF Link:** [https://arxiv.org/pdf/2311.12202](https://arxiv.org/pdf/2311.12202)

---

**Date:** 20 Feb 2024

**Title:** An Autonomous Large Language Model Agent for Chemical Literature Data  Mining

**Abstract Link:** [https://arxiv.org/abs/2402.12993](https://arxiv.org/abs/2402.12993)

**PDF Link:** [https://arxiv.org/pdf/2402.12993](https://arxiv.org/pdf/2402.12993)

---

**Date:** 01 May 2020

**Title:** An Efficient Integration of Disentangled Attended Expression and  Identity FeaturesFor Facial Expression Transfer andSynthesis

**Abstract Link:** [https://arxiv.org/abs/2005.00499](https://arxiv.org/abs/2005.00499)

**PDF Link:** [https://arxiv.org/pdf/2005.00499](https://arxiv.org/pdf/2005.00499)

---

**Date:** 03 Nov 2022

**Title:** CodeRL: Mastering Code Generation through Pretrained Models and Deep  Reinforcement Learning

**Abstract Link:** [https://arxiv.org/abs/2207.01780](https://arxiv.org/abs/2207.01780)

**PDF Link:** [https://arxiv.org/pdf/2207.01780](https://arxiv.org/pdf/2207.01780)

---

**Date:** 09 Feb 2024

**Title:** Vulnerabilities in AI Code Generators: Exploring Targeted Data Poisoning  Attacks

**Abstract Link:** [https://arxiv.org/abs/2308.04451](https://arxiv.org/abs/2308.04451)

**PDF Link:** [https://arxiv.org/pdf/2308.04451](https://arxiv.org/pdf/2308.04451)

---

**Date:** 11 Oct 2023

**Title:** DisCo: Disentangled Control for Realistic Human Dance Generation

**Abstract Link:** [https://arxiv.org/abs/2307.00040](https://arxiv.org/abs/2307.00040)

**PDF Link:** [https://arxiv.org/pdf/2307.00040](https://arxiv.org/pdf/2307.00040)

---

**Date:** 15 Jun 2023

**Title:** The pop song generator: designing an online course to teach  collaborative, creative AI

**Abstract Link:** [https://arxiv.org/abs/2306.10069](https://arxiv.org/abs/2306.10069)

**PDF Link:** [https://arxiv.org/pdf/2306.10069](https://arxiv.org/pdf/2306.10069)

---

**Date:** 23 Jan 2022

**Title:** ULSA: Unified Language of Synthesis Actions for Representation of  Synthesis Protocols

**Abstract Link:** [https://arxiv.org/abs/2201.09329](https://arxiv.org/abs/2201.09329)

**PDF Link:** [https://arxiv.org/pdf/2201.09329](https://arxiv.org/pdf/2201.09329)

---

**Date:** 13 Jan 2024

**Title:** Exploiting Modality-Specific Features For Multi-Modal Manipulation  Detection And Grounding

**Abstract Link:** [https://arxiv.org/abs/2309.12657](https://arxiv.org/abs/2309.12657)

**PDF Link:** [https://arxiv.org/pdf/2309.12657](https://arxiv.org/pdf/2309.12657)

---

