Mechanistic Interpretability 🔬

### 🔎 Mechanistic Interpretability 🔬



# Mechanistic Interpretability

Mechanistic interpretability is a subfield of interpretability that focuses on understanding the internal mechanics of a model. It is concerned with understanding how the model works, what it has learned, and how it makes predictions. This is in contrast to post-hoc interpretability, which focuses on explaining a model's predictions after the fact.

Mechanistic interpretability is often used to understand the behavior of complex models, such as deep neural networks. It can help to identify bugs, biases, and other issues in the model, and can also provide insights into the underlying data and relationships that the model has learned.

There are several approaches to mechanistic interpretability, including:

1. Visualization: Visualizing the internal workings of a model can help to understand how it makes predictions. This can be done using techniques such as saliency maps, activation maximization, and layer-wise relevance propagation.
2. Analysis: Analyzing the model's weights, activations, and other internal components can provide insights into what the model has learned. This can be done using techniques such as linear regression, principal component analysis, and t-SNE.
3. Simulation: Simulating the model's behavior can help to understand how it responds to different inputs and conditions. This can be done using techniques such as adversarial attacks, input perturbation, and model inversion.
4. Intervention: Intervening in the model's internal workings can help to understand how it makes predictions. This can be done using techniques such as ablation, pruning, and regularization.

Mechanistic interpretability is an important tool for building trust in AI systems, as it allows us to understand how the system works and how it makes decisions. It is also a key component of model debugging, as it can help to identify and fix issues in the model. However, mechanistic interpretability can be challenging to apply to very complex models, and it may not always be possible to fully understand the internal workings of a model. In such cases, post-hoc interpretability may be a more practical option.</s>
# 🩺🔍 Search Results
### 06 Feb 2024 | [Position Paper: Toward New Frameworks for Studying Model Representations](https://arxiv.org/abs/2402.03855) | [⬇️](https://arxiv.org/pdf/2402.03855)
*Satvik Golechha, James Dao* 

  Mechanistic interpretability (MI) aims to understand AI models by
reverse-engineering the exact algorithms neural networks learn. Most works in
MI so far have studied behaviors and capabilities that are trivial and
token-aligned. However, most capabilities are not that trivial, which advocates
for the study of hidden representations inside these networks as the unit of
analysis. We do a literature review, formalize representations for features and
behaviors, highlight their importance and evaluation, and perform some basic
exploration in the mechanistic interpretability of representations. With
discussion and exploratory results, we justify our position that studying
representations is an important and under-studied field, and that currently
established methods in MI are not sufficient to understand representations,
thus pushing for the research community to work toward new frameworks for
studying representations.

---------------

### 27 Aug 2023 | [Towards Vision-Language Mechanistic Interpretability: A Causal Tracing  Tool for BLIP](https://arxiv.org/abs/2308.14179) | [⬇️](https://arxiv.org/pdf/2308.14179)
*Vedant Palit and Rohan Pandey and Aryaman Arora and Paul Pu Liang* 

  Mechanistic interpretability seeks to understand the neural mechanisms that
enable specific behaviors in Large Language Models (LLMs) by leveraging
causality-based methods. While these approaches have identified neural circuits
that copy spans of text, capture factual knowledge, and more, they remain
unusable for multimodal models since adapting these tools to the
vision-language domain requires considerable architectural changes. In this
work, we adapt a unimodal causal tracing tool to BLIP to enable the study of
the neural mechanisms underlying image-conditioned text generation. We
demonstrate our approach on a visual question answering dataset, highlighting
the causal relevance of later layer representations for all tokens.
Furthermore, we release our BLIP causal tracing tool as open source to enable
further experimentation in vision-language mechanistic interpretability by the
community. Our code is available at
https://github.com/vedantpalit/Towards-Vision-Language-Mechanistic-Interpretability.

---------------

### 06 Dec 2023 | [Is This the Subspace You Are Looking for? An Interpretability Illusion  for Subspace Activation Patching](https://arxiv.org/abs/2311.17030) | [⬇️](https://arxiv.org/pdf/2311.17030)
*Aleksandar Makelov, Georg Lange, Neel Nanda* 

  Mechanistic interpretability aims to understand model behaviors in terms of
specific, interpretable features, often hypothesized to manifest as
low-dimensional subspaces of activations. Specifically, recent studies have
explored subspace interventions (such as activation patching) as a way to
simultaneously manipulate model behavior and attribute the features behind it
to given subspaces.
  In this work, we demonstrate that these two aims diverge, potentially leading
to an illusory sense of interpretability. Counterintuitively, even if a
subspace intervention makes the model's output behave as if the value of a
feature was changed, this effect may be achieved by activating a dormant
parallel pathway leveraging another subspace that is causally disconnected from
model outputs. We demonstrate this phenomenon in a distilled mathematical
example, in two real-world domains (the indirect object identification task and
factual recall), and present evidence for its prevalence in practice. In the
context of factual recall, we further show a link to rank-1 fact editing,
providing a mechanistic explanation for previous work observing an
inconsistency between fact editing performance and fact localization.
  However, this does not imply that activation patching of subspaces is
intrinsically unfit for interpretability. To contextualize our findings, we
also show what a success case looks like in a task (indirect object
identification) where prior manual circuit analysis informs an understanding of
the location of a feature. We explore the additional evidence needed to argue
that a patched subspace is faithful.

---------------

### 19 Apr 2023 | [Disentangling Neuron Representations with Concept Vectors](https://arxiv.org/abs/2304.09707) | [⬇️](https://arxiv.org/pdf/2304.09707)
*Laura O'Mahony, Vincent Andrearczyk, Henning Muller, Mara Graziani* 

  Mechanistic interpretability aims to understand how models store
representations by breaking down neural networks into interpretable units.
However, the occurrence of polysemantic neurons, or neurons that respond to
multiple unrelated features, makes interpreting individual neurons challenging.
This has led to the search for meaningful vectors, known as concept vectors, in
activation space instead of individual neurons. The main contribution of this
paper is a method to disentangle polysemantic neurons into concept vectors
encapsulating distinct features. Our method can search for fine-grained
concepts according to the user's desired level of concept separation. The
analysis shows that polysemantic neurons can be disentangled into directions
consisting of linear combinations of neurons. Our evaluations show that the
concept vectors found encode coherent, human-understandable features.

---------------

### 22 Nov 2022 | [Interpreting Neural Networks through the Polytope Lens](https://arxiv.org/abs/2211.12312) | [⬇️](https://arxiv.org/pdf/2211.12312)
*Sid Black, Lee Sharkey, Leo Grinsztajn, Eric Winsor, Dan Braun, Jacob  Merizian, Kip Parker, Carlos Ram\'on Guevara, Beren Millidge, Gabriel Alfour,  Connor Leahy* 

  Mechanistic interpretability aims to explain what a neural network has
learned at a nuts-and-bolts level. What are the fundamental primitives of
neural network representations? Previous mechanistic descriptions have used
individual neurons or their linear combinations to understand the
representations a network has learned. But there are clues that neurons and
their linear combinations are not the correct fundamental units of description:
directions cannot describe how neural networks use nonlinearities to structure
their representations. Moreover, many instances of individual neurons and their
combinations are polysemantic (i.e. they have multiple unrelated meanings).
Polysemanticity makes interpreting the network in terms of neurons or
directions challenging since we can no longer assign a specific feature to a
neural unit. In order to find a basic unit of description that does not suffer
from these problems, we zoom in beyond just directions to study the way that
piecewise linear activation functions (such as ReLU) partition the activation
space into numerous discrete polytopes. We call this perspective the polytope
lens. The polytope lens makes concrete predictions about the behavior of neural
networks, which we evaluate through experiments on both convolutional image
classifiers and language models. Specifically, we show that polytopes can be
used to identify monosemantic regions of activation space (while directions are
not in general monosemantic) and that the density of polytope boundaries
reflect semantic boundaries. We also outline a vision for what mechanistic
interpretability might look like through the polytope lens.

---------------

### 17 Jan 2024 | [Towards Best Practices of Activation Patching in Language Models:  Metrics and Methods](https://arxiv.org/abs/2309.16042) | [⬇️](https://arxiv.org/pdf/2309.16042)
*Fred Zhang and Neel Nanda* 

  Mechanistic interpretability seeks to understand the internal mechanisms of
machine learning models, where localization -- identifying the important model
components -- is a key step. Activation patching, also known as causal tracing
or interchange intervention, is a standard technique for this task (Vig et al.,
2020), but the literature contains many variants with little consensus on the
choice of hyperparameters or methodology. In this work, we systematically
examine the impact of methodological details in activation patching, including
evaluation metrics and corruption methods. In several settings of localization
and circuit discovery in language models, we find that varying these
hyperparameters could lead to disparate interpretability results. Backed by
empirical observations, we give conceptual arguments for why certain metrics or
methods may be preferred. Finally, we provide recommendations for the best
practices of activation patching going forwards.

---------------

### 01 Nov 2022 | [Interpretability in the Wild: a Circuit for Indirect Object  Identification in GPT-2 small](https://arxiv.org/abs/2211.00593) | [⬇️](https://arxiv.org/pdf/2211.00593)
*Kevin Wang, Alexandre Variengien, Arthur Conmy, Buck Shlegeris and  Jacob Steinhardt* 

  Research in mechanistic interpretability seeks to explain behaviors of
machine learning models in terms of their internal components. However, most
previous work either focuses on simple behaviors in small models, or describes
complicated behaviors in larger models with broad strokes. In this work, we
bridge this gap by presenting an explanation for how GPT-2 small performs a
natural language task called indirect object identification (IOI). Our
explanation encompasses 26 attention heads grouped into 7 main classes, which
we discovered using a combination of interpretability approaches relying on
causal interventions. To our knowledge, this investigation is the largest
end-to-end attempt at reverse-engineering a natural behavior "in the wild" in a
language model. We evaluate the reliability of our explanation using three
quantitative criteria--faithfulness, completeness and minimality. Though these
criteria support our explanation, they also point to remaining gaps in our
understanding. Our work provides evidence that a mechanistic understanding of
large ML models is feasible, opening opportunities to scale our understanding
to both larger models and more complex tasks.

---------------

### 22 Jan 2024 | [Universal Neurons in GPT2 Language Models](https://arxiv.org/abs/2401.12181) | [⬇️](https://arxiv.org/pdf/2401.12181)
*Wes Gurnee, Theo Horsley, Zifan Carl Guo, Tara Rezaei Kheirkhah, Qinyi  Sun, Will Hathaway, Neel Nanda, Dimitris Bertsimas* 

  A basic question within the emerging field of mechanistic interpretability is
the degree to which neural networks learn the same underlying mechanisms. In
other words, are neural mechanisms universal across different models? In this
work, we study the universality of individual neurons across GPT2 models
trained from different initial random seeds, motivated by the hypothesis that
universal neurons are likely to be interpretable. In particular, we compute
pairwise correlations of neuron activations over 100 million tokens for every
neuron pair across five different seeds and find that 1-5\% of neurons are
universal, that is, pairs of neurons which consistently activate on the same
inputs. We then study these universal neurons in detail, finding that they
usually have clear interpretations and taxonomize them into a small number of
neuron families. We conclude by studying patterns in neuron weights to
establish several universal functional roles of neurons in simple circuits:
deactivating attention heads, changing the entropy of the next token
distribution, and predicting the next token to (not) be within a particular
set.

---------------

### 31 Jan 2024 | [Real Sparks of Artificial Intelligence and the Importance of Inner  Interpretability](https://arxiv.org/abs/2402.00901) | [⬇️](https://arxiv.org/pdf/2402.00901)
*Alex Grzankowski* 

  The present paper looks at one of the most thorough articles on the
intelligence of GPT, research conducted by engineers at Microsoft. Although
there is a great deal of value in their work, I will argue that, for familiar
philosophical reasons, their methodology, !Blackbox Interpretability"#is
wrongheaded. But there is a better way. There is an exciting and emerging
discipline of !Inner Interpretability"#(and specifically Mechanistic
Interpretability) that aims to uncover the internal activations and weights of
models in order to understand what they represent and the algorithms they
implement. In my view, a crucial mistake in Black-box Interpretability is the
failure to appreciate that how processes are carried out matters when it comes
to intelligence and understanding. I can#t pretend to have a full story that
provides both necessary and sufficient conditions for being intelligent, but I
do think that Inner Interpretability dovetails nicely with plausible
philosophical views of what intelligence requires. So the conclusion is modest,
but the important point in my view is seeing how to get the research on the
right track. Towards the end of the paper, I will show how some of the
philosophical concepts can be used to further refine how Inner Interpretability
is approached, so the paper helps draw out a profitable, future two-way
exchange between Philosophers and Computer Scientists.

---------------

### 08 Jan 2024 | [Evaluating Brain-Inspired Modular Training in Automated Circuit  Discovery for Mechanistic Interpretability](https://arxiv.org/abs/2401.03646) | [⬇️](https://arxiv.org/pdf/2401.03646)
*Jatin Nainani* 

  Large Language Models (LLMs) have experienced a rapid rise in AI, changing a
wide range of applications with their advanced capabilities. As these models
become increasingly integral to decision-making, the need for thorough
interpretability has never been more critical. Mechanistic Interpretability
offers a pathway to this understanding by identifying and analyzing specific
sub-networks or 'circuits' within these complex systems. A crucial aspect of
this approach is Automated Circuit Discovery, which facilitates the study of
large models like GPT4 or LLAMA in a feasible manner. In this context, our
research evaluates a recent method, Brain-Inspired Modular Training (BIMT),
designed to enhance the interpretability of neural networks. We demonstrate how
BIMT significantly improves the efficiency and quality of Automated Circuit
Discovery, overcoming the limitations of manual methods. Our comparative
analysis further reveals that BIMT outperforms existing models in terms of
circuit quality, discovery time, and sparsity. Additionally, we provide a
comprehensive computational analysis of BIMT, including aspects such as
training duration, memory allocation requirements, and inference speed. This
study advances the larger objective of creating trustworthy and transparent AI
systems in addition to demonstrating how well BIMT works to make neural
networks easier to understand.

---------------

### 31 Oct 2023 | [Learning Transformer Programs](https://arxiv.org/abs/2306.01128) | [⬇️](https://arxiv.org/pdf/2306.01128)
*Dan Friedman, Alexander Wettig, Danqi Chen* 

  Recent research in mechanistic interpretability has attempted to
reverse-engineer Transformer models by carefully inspecting network weights and
activations. However, these approaches require considerable manual effort and
still fall short of providing complete, faithful descriptions of the underlying
algorithms. In this work, we introduce a procedure for training Transformers
that are mechanistically interpretable by design. We build on RASP [Weiss et
al., 2021], a programming language that can be compiled into Transformer
weights. Instead of compiling human-written programs into Transformers, we
design a modified Transformer that can be trained using gradient-based
optimization and then automatically converted into a discrete, human-readable
program. We refer to these models as Transformer Programs. To validate our
approach, we learn Transformer Programs for a variety of problems, including an
in-context learning task, a suite of algorithmic problems (e.g. sorting,
recognizing Dyck languages), and NLP tasks including named entity recognition
and text classification. The Transformer Programs can automatically find
reasonable solutions, performing on par with standard Transformers of
comparable size; and, more importantly, they are easy to interpret. To
demonstrate these advantages, we convert Transformers into Python programs and
use off-the-shelf code analysis tools to debug model errors and identify the
"circuits" used to solve different sub-problems. We hope that Transformer
Programs open a new path toward the goal of intrinsically interpretable machine
learning.

---------------

### 05 Dec 2023 | [Generating Interpretable Networks using Hypernetworks](https://arxiv.org/abs/2312.03051) | [⬇️](https://arxiv.org/pdf/2312.03051)
*Isaac Liao, Ziming Liu, Max Tegmark* 

  An essential goal in mechanistic interpretability to decode a network, i.e.,
to convert a neural network's raw weights to an interpretable algorithm. Given
the difficulty of the decoding problem, progress has been made to understand
the easier encoding problem, i.e., to convert an interpretable algorithm into
network weights. Previous works focus on encoding existing algorithms into
networks, which are interpretable by definition. However, focusing on encoding
limits the possibility of discovering new algorithms that humans have never
stumbled upon, but that are nevertheless interpretable. In this work, we
explore the possibility of using hypernetworks to generate interpretable
networks whose underlying algorithms are not yet known. The hypernetwork is
carefully designed such that it can control network complexity, leading to a
diverse family of interpretable algorithms ranked by their complexity. All of
them are interpretable in hindsight, although some of them are less intuitive
to humans, hence providing new insights regarding how to "think" like a neural
network. For the task of computing L1 norms, hypernetworks find three
algorithms: (a) the double-sided algorithm, (b) the convexity algorithm, (c)
the pudding algorithm, although only the first algorithm was expected by the
authors before experiments. We automatically classify these algorithms and
analyze how these algorithmic phases develop during training, as well as how
they are affected by complexity control. Furthermore, we show that a trained
hypernetwork can correctly construct models for input dimensions not seen in
training, demonstrating systematic generalization.

---------------

### 26 Dec 2023 | [Observable Propagation: A Data-Efficient Approach to Uncover Feature  Vectors in Transformers](https://arxiv.org/abs/2312.16291) | [⬇️](https://arxiv.org/pdf/2312.16291)
*Jacob Dunefsky and Arman Cohan* 

  A key goal of current mechanistic interpretability research in NLP is to find
linear features (also called "feature vectors") for transformers: directions in
activation space corresponding to concepts that are used by a given model in
its computation. Present state-of-the-art methods for finding linear features
require large amounts of labelled data -- both laborious to acquire and
computationally expensive to utilize. In this work, we introduce a novel
method, called "observable propagation" (in short: ObsProp), for finding linear
features used by transformer language models in computing a given task -- using
almost no data. Our paradigm centers on the concept of observables, linear
functionals corresponding to given tasks. We then introduce a mathematical
theory for the analysis of feature vectors: we provide theoretical motivation
for why LayerNorm nonlinearities do not affect the direction of feature
vectors; we also introduce a similarity metric between feature vectors called
the coupling coefficient which estimates the degree to which one feature's
output correlates with another's. We use ObsProp to perform extensive
qualitative investigations into several tasks, including gendered occupational
bias, political party prediction, and programming language detection. Our
results suggest that ObsProp surpasses traditional approaches for finding
feature vectors in the low-data regime, and that ObsProp can be used to better
understand the mechanisms responsible for bias in large language models. Code
for experiments can be found at github.com/jacobdunefsky/ObservablePropagation.

---------------

### 16 Feb 2024 | [Opening the Black Box of Large Language Models: Two Views on Holistic  Interpretability](https://arxiv.org/abs/2402.10688) | [⬇️](https://arxiv.org/pdf/2402.10688)
*Haiyan Zhao, Fan Yang, Himabindu Lakkaraju, Mengnan Du* 

  As large language models (LLMs) grow more powerful, concerns around potential
harms like toxicity, unfairness, and hallucination threaten user trust.
Ensuring beneficial alignment of LLMs with human values through model alignment
is thus critical yet challenging, requiring a deeper understanding of LLM
behaviors and mechanisms. We propose opening the black box of LLMs through a
framework of holistic interpretability encompassing complementary bottom-up and
top-down perspectives. The bottom-up view, enabled by mechanistic
interpretability, focuses on component functionalities and training dynamics.
The top-down view utilizes representation engineering to analyze behaviors
through hidden representations. In this paper, we review the landscape around
mechanistic interpretability and representation engineering, summarizing
approaches, discussing limitations and applications, and outlining future
challenges in using these techniques to achieve ethical, honest, and reliable
reasoning aligned with human values.

---------------

### 22 Apr 2023 | [N2G: A Scalable Approach for Quantifying Interpretable Neuron  Representations in Large Language Models](https://arxiv.org/abs/2304.12918) | [⬇️](https://arxiv.org/pdf/2304.12918)
*Alex Foote, Neel Nanda, Esben Kran, Ionnis Konstas, Fazl Barez* 

  Understanding the function of individual neurons within language models is
essential for mechanistic interpretability research. We propose $\textbf{Neuron
to Graph (N2G)}$, a tool which takes a neuron and its dataset examples, and
automatically distills the neuron's behaviour on those examples to an
interpretable graph. This presents a less labour intensive approach to
interpreting neurons than current manual methods, that will better scale these
methods to Large Language Models (LLMs). We use truncation and saliency methods
to only present the important tokens, and augment the dataset examples with
more diverse samples to better capture the extent of neuron behaviour. These
graphs can be visualised to aid manual interpretation by researchers, but can
also output token activations on text to compare to the neuron's ground truth
activations for automatic validation. N2G represents a step towards scalable
interpretability methods by allowing us to convert neurons in an LLM to
interpretable representations of measurable quality.

---------------

### 24 May 2023 | [A Toy Model of Universality: Reverse Engineering How Networks Learn  Group Operations](https://arxiv.org/abs/2302.03025) | [⬇️](https://arxiv.org/pdf/2302.03025)
*Bilal Chughtai, Lawrence Chan, Neel Nanda* 

  Universality is a key hypothesis in mechanistic interpretability -- that
different models learn similar features and circuits when trained on similar
tasks. In this work, we study the universality hypothesis by examining how
small neural networks learn to implement group composition. We present a novel
algorithm by which neural networks may implement composition for any finite
group via mathematical representation theory. We then show that networks
consistently learn this algorithm by reverse engineering model logits and
weights, and confirm our understanding using ablations. By studying networks of
differing architectures trained on various groups, we find mixed evidence for
universality: using our algorithm, we can completely characterize the family of
circuits and features that networks learn on this task, but for a given network
the precise circuits learned -- as well as the order they develop -- are
arbitrary.

---------------

### 17 Jan 2024 | [Circuit Component Reuse Across Tasks in Transformer Language Models](https://arxiv.org/abs/2310.08744) | [⬇️](https://arxiv.org/pdf/2310.08744)
*Jack Merullo, Carsten Eickhoff, Ellie Pavlick* 

  Recent work in mechanistic interpretability has shown that behaviors in
language models can be successfully reverse-engineered through circuit
analysis. A common criticism, however, is that each circuit is task-specific,
and thus such analysis cannot contribute to understanding the models at a
higher level. In this work, we present evidence that insights (both low-level
findings about specific heads and higher-level findings about general
algorithms) can indeed generalize across tasks. Specifically, we study the
circuit discovered in Wang et al. (2022) for the Indirect Object Identification
(IOI) task and 1.) show that it reproduces on a larger GPT2 model, and 2.) that
it is mostly reused to solve a seemingly different task: Colored Objects
(Ippolito & Callison-Burch, 2023). We provide evidence that the process
underlying both tasks is functionally very similar, and contains about a 78%
overlap in in-circuit attention heads. We further present a proof-of-concept
intervention experiment, in which we adjust four attention heads in middle
layers in order to 'repair' the Colored Objects circuit and make it behave like
the IOI circuit. In doing so, we boost accuracy from 49.6% to 93.7% on the
Colored Objects task and explain most sources of error. The intervention
affects downstream attention heads in specific ways predicted by their
interactions in the IOI circuit, indicating that this subcircuit behavior is
invariant to the different task inputs. Overall, our results provide evidence
that it may yet be possible to explain large language models' behavior in terms
of a relatively small number of interpretable task-general algorithmic building
blocks and computational components.

---------------

### 11 Jul 2023 | [Scale Alone Does not Improve Mechanistic Interpretability in Vision  Models](https://arxiv.org/abs/2307.05471) | [⬇️](https://arxiv.org/pdf/2307.05471)
*Roland S. Zimmermann, Thomas Klein, Wieland Brendel* 

  In light of the recent widespread adoption of AI systems, understanding the
internal information processing of neural networks has become increasingly
critical. Most recently, machine vision has seen remarkable progress by scaling
neural networks to unprecedented levels in dataset and model size. We here ask
whether this extraordinary increase in scale also positively impacts the field
of mechanistic interpretability. In other words, has our understanding of the
inner workings of scaled neural networks improved as well? We here use a
psychophysical paradigm to quantify mechanistic interpretability for a diverse
suite of models and find no scaling effect for interpretability - neither for
model nor dataset size. Specifically, none of the nine investigated
state-of-the-art models are easier to interpret than the GoogLeNet model from
almost a decade ago. Latest-generation vision models appear even less
interpretable than older architectures, hinting at a regression rather than
improvement, with modern models sacrificing interpretability for accuracy.
These results highlight the need for models explicitly designed to be
mechanistically interpretable and the need for more helpful interpretability
methods to increase our understanding of networks at an atomic level. We
release a dataset containing more than 120'000 human responses from our
psychophysical evaluation of 767 units across nine models. This dataset is
meant to facilitate research on automated instead of human-based
interpretability evaluations that can ultimately be leveraged to directly
optimize the mechanistic interpretability of models.

---------------

### 19 Feb 2024 | [Dictionary Learning Improves Patch-Free Circuit Discovery in Mechanistic  Interpretability: A Case Study on Othello-GPT](https://arxiv.org/abs/2402.12201) | [⬇️](https://arxiv.org/pdf/2402.12201)
*Zhengfu He, Xuyang Ge, Qiong Tang, Tianxiang Sun, Qinyuan Cheng,  Xipeng Qiu* 

  Sparse dictionary learning has been a rapidly growing technique in
mechanistic interpretability to attack superposition and extract more
human-understandable features from model activations. We ask a further question
based on the extracted more monosemantic features: How do we recognize circuits
connecting the enormous amount of dictionary features? We propose a circuit
discovery framework alternative to activation patching. Our framework suffers
less from out-of-distribution and proves to be more efficient in terms of
asymptotic complexity. The basic unit in our framework is dictionary features
decomposed from all modules writing to the residual stream, including
embedding, attention output and MLP output. Starting from any logit, dictionary
feature or attention score, we manage to trace down to lower-level dictionary
features of all tokens and compute their contribution to these more
interpretable and local model behaviors. We dig in a small transformer trained
on a synthetic task named Othello and find a number of human-understandable
fine-grained circuits inside of it.

---------------

### 28 Oct 2023 | [Towards Automated Circuit Discovery for Mechanistic Interpretability](https://arxiv.org/abs/2304.14997) | [⬇️](https://arxiv.org/pdf/2304.14997)
*Arthur Conmy, Augustine N. Mavor-Parker, Aengus Lynch, Stefan  Heimersheim, Adri\`a Garriga-Alonso* 

  Through considerable effort and intuition, several recent works have
reverse-engineered nontrivial behaviors of transformer models. This paper
systematizes the mechanistic interpretability process they followed. First,
researchers choose a metric and dataset that elicit the desired model behavior.
Then, they apply activation patching to find which abstract neural network
units are involved in the behavior. By varying the dataset, metric, and units
under investigation, researchers can understand the functionality of each
component. We automate one of the process' steps: to identify the circuit that
implements the specified behavior in the model's computational graph. We
propose several algorithms and reproduce previous interpretability results to
validate them. For example, the ACDC algorithm rediscovered 5/5 of the
component types in a circuit in GPT-2 Small that computes the Greater-Than
operation. ACDC selected 68 of the 32,000 edges in GPT-2 Small, all of which
were manually found by previous work. Our code is available at
https://github.com/ArthurConmy/Automatic-Circuit-Discovery.

---------------
**Date:** 06 Feb 2024

**Title:** Position Paper: Toward New Frameworks for Studying Model Representations

**Abstract Link:** [https://arxiv.org/abs/2402.03855](https://arxiv.org/abs/2402.03855)

**PDF Link:** [https://arxiv.org/pdf/2402.03855](https://arxiv.org/pdf/2402.03855)

---

**Date:** 27 Aug 2023

**Title:** Towards Vision-Language Mechanistic Interpretability: A Causal Tracing  Tool for BLIP

**Abstract Link:** [https://arxiv.org/abs/2308.14179](https://arxiv.org/abs/2308.14179)

**PDF Link:** [https://arxiv.org/pdf/2308.14179](https://arxiv.org/pdf/2308.14179)

---

**Date:** 06 Dec 2023

**Title:** Is This the Subspace You Are Looking for? An Interpretability Illusion  for Subspace Activation Patching

**Abstract Link:** [https://arxiv.org/abs/2311.17030](https://arxiv.org/abs/2311.17030)

**PDF Link:** [https://arxiv.org/pdf/2311.17030](https://arxiv.org/pdf/2311.17030)

---

**Date:** 19 Apr 2023

**Title:** Disentangling Neuron Representations with Concept Vectors

**Abstract Link:** [https://arxiv.org/abs/2304.09707](https://arxiv.org/abs/2304.09707)

**PDF Link:** [https://arxiv.org/pdf/2304.09707](https://arxiv.org/pdf/2304.09707)

---

**Date:** 22 Nov 2022

**Title:** Interpreting Neural Networks through the Polytope Lens

**Abstract Link:** [https://arxiv.org/abs/2211.12312](https://arxiv.org/abs/2211.12312)

**PDF Link:** [https://arxiv.org/pdf/2211.12312](https://arxiv.org/pdf/2211.12312)

---

**Date:** 17 Jan 2024

**Title:** Towards Best Practices of Activation Patching in Language Models:  Metrics and Methods

**Abstract Link:** [https://arxiv.org/abs/2309.16042](https://arxiv.org/abs/2309.16042)

**PDF Link:** [https://arxiv.org/pdf/2309.16042](https://arxiv.org/pdf/2309.16042)

---

**Date:** 01 Nov 2022

**Title:** Interpretability in the Wild: a Circuit for Indirect Object  Identification in GPT-2 small

**Abstract Link:** [https://arxiv.org/abs/2211.00593](https://arxiv.org/abs/2211.00593)

**PDF Link:** [https://arxiv.org/pdf/2211.00593](https://arxiv.org/pdf/2211.00593)

---

**Date:** 22 Jan 2024

**Title:** Universal Neurons in GPT2 Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.12181](https://arxiv.org/abs/2401.12181)

**PDF Link:** [https://arxiv.org/pdf/2401.12181](https://arxiv.org/pdf/2401.12181)

---

**Date:** 31 Jan 2024

**Title:** Real Sparks of Artificial Intelligence and the Importance of Inner  Interpretability

**Abstract Link:** [https://arxiv.org/abs/2402.00901](https://arxiv.org/abs/2402.00901)

**PDF Link:** [https://arxiv.org/pdf/2402.00901](https://arxiv.org/pdf/2402.00901)

---

**Date:** 08 Jan 2024

**Title:** Evaluating Brain-Inspired Modular Training in Automated Circuit  Discovery for Mechanistic Interpretability

**Abstract Link:** [https://arxiv.org/abs/2401.03646](https://arxiv.org/abs/2401.03646)

**PDF Link:** [https://arxiv.org/pdf/2401.03646](https://arxiv.org/pdf/2401.03646)

---

**Date:** 31 Oct 2023

**Title:** Learning Transformer Programs

**Abstract Link:** [https://arxiv.org/abs/2306.01128](https://arxiv.org/abs/2306.01128)

**PDF Link:** [https://arxiv.org/pdf/2306.01128](https://arxiv.org/pdf/2306.01128)

---

**Date:** 05 Dec 2023

**Title:** Generating Interpretable Networks using Hypernetworks

**Abstract Link:** [https://arxiv.org/abs/2312.03051](https://arxiv.org/abs/2312.03051)

**PDF Link:** [https://arxiv.org/pdf/2312.03051](https://arxiv.org/pdf/2312.03051)

---

**Date:** 26 Dec 2023

**Title:** Observable Propagation: A Data-Efficient Approach to Uncover Feature  Vectors in Transformers

**Abstract Link:** [https://arxiv.org/abs/2312.16291](https://arxiv.org/abs/2312.16291)

**PDF Link:** [https://arxiv.org/pdf/2312.16291](https://arxiv.org/pdf/2312.16291)

---

**Date:** 16 Feb 2024

**Title:** Opening the Black Box of Large Language Models: Two Views on Holistic  Interpretability

**Abstract Link:** [https://arxiv.org/abs/2402.10688](https://arxiv.org/abs/2402.10688)

**PDF Link:** [https://arxiv.org/pdf/2402.10688](https://arxiv.org/pdf/2402.10688)

---

**Date:** 22 Apr 2023

**Title:** N2G: A Scalable Approach for Quantifying Interpretable Neuron  Representations in Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2304.12918](https://arxiv.org/abs/2304.12918)

**PDF Link:** [https://arxiv.org/pdf/2304.12918](https://arxiv.org/pdf/2304.12918)

---

**Date:** 24 May 2023

**Title:** A Toy Model of Universality: Reverse Engineering How Networks Learn  Group Operations

**Abstract Link:** [https://arxiv.org/abs/2302.03025](https://arxiv.org/abs/2302.03025)

**PDF Link:** [https://arxiv.org/pdf/2302.03025](https://arxiv.org/pdf/2302.03025)

---

**Date:** 17 Jan 2024

**Title:** Circuit Component Reuse Across Tasks in Transformer Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.08744](https://arxiv.org/abs/2310.08744)

**PDF Link:** [https://arxiv.org/pdf/2310.08744](https://arxiv.org/pdf/2310.08744)

---

**Date:** 11 Jul 2023

**Title:** Scale Alone Does not Improve Mechanistic Interpretability in Vision  Models

**Abstract Link:** [https://arxiv.org/abs/2307.05471](https://arxiv.org/abs/2307.05471)

**PDF Link:** [https://arxiv.org/pdf/2307.05471](https://arxiv.org/pdf/2307.05471)

---

**Date:** 19 Feb 2024

**Title:** Dictionary Learning Improves Patch-Free Circuit Discovery in Mechanistic  Interpretability: A Case Study on Othello-GPT

**Abstract Link:** [https://arxiv.org/abs/2402.12201](https://arxiv.org/abs/2402.12201)

**PDF Link:** [https://arxiv.org/pdf/2402.12201](https://arxiv.org/pdf/2402.12201)

---

**Date:** 28 Oct 2023

**Title:** Towards Automated Circuit Discovery for Mechanistic Interpretability

**Abstract Link:** [https://arxiv.org/abs/2304.14997](https://arxiv.org/abs/2304.14997)

**PDF Link:** [https://arxiv.org/pdf/2304.14997](https://arxiv.org/pdf/2304.14997)

---

