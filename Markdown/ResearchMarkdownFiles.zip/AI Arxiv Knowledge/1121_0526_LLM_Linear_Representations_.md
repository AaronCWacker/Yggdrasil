LLM Linear Representations ➡️

### 🔎 LLM Linear Representations ➡️

 Group Actions

- A linear representation of a group G is a homomorphism from G to GL(V), the group of invertible linear transformations of a vector space V.
- A group action of G on a set X is a homomorphism from G to S(X), the group of permutations of X.
- Every linear representation of G gives rise to a group action of G on the vector space V.
- Conversely, every group action of G on a set X gives rise to a linear representation of G if X has the structure of a vector space and the group action is linear.

Group Actions ➡️ Linear Representations

- Let G be a group acting on a set X.
- If X has the structure of a vector space and the group action is linear, then the group action gives rise to a linear representation of G on X.
- The linear representation is given by the map ρ: G → GL(X) defined by ρ(g)(x) = gx for all g in G and x in X.
- The map ρ is a homomorphism because the group action is a homomorphism.
- The map ρ is a linear representation because the group action is linear.

Examples

- The group G = {1, -1} acts on the set X = {1, 2, 3} by 1x = x and (-1)x = 6-x for all x in X.
- The group G = {1, -1} acts on the vector space V = R^2 by 1(x, y) = (x, y) and (-1)(x, y) = (-x, -y) for all (x, y) in V.
- The group G = {1, -1} acts on the vector space V = C^2 by 1(z, w) = (z, w) and (-1)(z, w) = (w, z) for all (z, w) in V.
- The group G = {1, -1} acts on the vector space V = M_2(R) by 1A = A and (-1)A = -A for all A in V.
- The group G = {1, -1} acts on the vector space V = M_2(C
# 🩺🔍 Search Results
### 08 Dec 2023 | [The Geometry of Truth: Emergent Linear Structure in Large Language Model  Representations of True/False Datasets](https://arxiv.org/abs/2310.06824) | [⬇️](https://arxiv.org/pdf/2310.06824)
*Samuel Marks and Max Tegmark* 

  Large Language Models (LLMs) have impressive capabilities, but are also prone
to outputting falsehoods. Recent work has developed techniques for inferring
whether a LLM is telling the truth by training probes on the LLM's internal
activations. However, this line of work is controversial, with some authors
pointing out failures of these probes to generalize in basic ways, among other
conceptual issues. In this work, we curate high-quality datasets of true/false
statements and use them to study in detail the structure of LLM representations
of truth, drawing on three lines of evidence: 1. Visualizations of LLM
true/false statement representations, which reveal clear linear structure. 2.
Transfer experiments in which probes trained on one dataset generalize to
different datasets. 3. Causal evidence obtained by surgically intervening in a
LLM's forward pass, causing it to treat false statements as true and vice
versa. Overall, we present evidence that language models linearly represent the
truth or falsehood of factual statements. We also introduce a novel technique,
mass-mean probing, which generalizes better and is more causally implicated in
model outputs than other probing techniques.

---------------

### 21 Feb 2024 | [Decoding In-Context Learning: Neuroscience-inspired Analysis of  Representations in Large Language Models](https://arxiv.org/abs/2310.00313) | [⬇️](https://arxiv.org/pdf/2310.00313)
*Safoora Yousefi, Leo Betthauser, Hosein Hasanbeig, Rapha\"el  Milli\`ere, Ida Momennejad* 

  Large language models (LLMs) exhibit remarkable performance improvement
through in-context learning (ICL) by leveraging task-specific examples in the
input. However, the mechanisms behind this improvement remain elusive. In this
work, we investigate how LLM embeddings and attention representations change
following in-context-learning, and how these changes mediate improvement in
behavior. We employ neuroscience-inspired techniques such as representational
similarity analysis (RSA) and propose novel methods for parameterized probing
and measuring ratio of attention to relevant vs. irrelevant information in
Llama-2 70B and Vicuna 13B. We designed two tasks with a priori relationships
among their conditions: linear regression and reading comprehension. We formed
hypotheses about expected similarities in task representations and measured
hypothesis alignment of LLM representations before and after ICL as well as
changes in attention. Our analyses revealed a meaningful correlation between
improvements in behavior after ICL and changes in both embeddings and attention
weights across LLM layers. This empirical framework empowers a nuanced
understanding of how latent representations shape LLM behavior, offering
valuable tools and insights for future research and practical applications.

---------------

### 04 Mar 2024 | [Language Models Represent Space and Time](https://arxiv.org/abs/2310.02207) | [⬇️](https://arxiv.org/pdf/2310.02207)
*Wes Gurnee, Max Tegmark* 

  The capabilities of large language models (LLMs) have sparked debate over
whether such systems just learn an enormous collection of superficial
statistics or a set of more coherent and grounded representations that reflect
the real world. We find evidence for the latter by analyzing the learned
representations of three spatial datasets (world, US, NYC places) and three
temporal datasets (historical figures, artworks, news headlines) in the Llama-2
family of models. We discover that LLMs learn linear representations of space
and time across multiple scales. These representations are robust to prompting
variations and unified across different entity types (e.g. cities and
landmarks). In addition, we identify individual "space neurons" and "time
neurons" that reliably encode spatial and temporal coordinates. While further
investigation is needed, our results suggest modern LLMs learn rich
spatiotemporal representations of the real world and possess basic ingredients
of a world model.

---------------

### 26 Dec 2023 | [More than Correlation: Do Large Language Models Learn Causal  Representations of Space?](https://arxiv.org/abs/2312.16257) | [⬇️](https://arxiv.org/pdf/2312.16257)
*Yida Chen, Yixian Gan, Sijia Li, Li Yao, Xiaohan Zhao* 

  Recent work found high mutual information between the learned representations
of large language models (LLMs) and the geospatial property of its input,
hinting an emergent internal model of space. However, whether this internal
space model has any causal effects on the LLMs' behaviors was not answered by
that work, led to criticism of these findings as mere statistical correlation.
Our study focused on uncovering the causality of the spatial representations in
LLMs. In particular, we discovered the potential spatial representations in
DeBERTa, GPT-Neo using representational similarity analysis and linear and
non-linear probing. Our casual intervention experiments showed that the spatial
representations influenced the model's performance on next word prediction and
a downstream task that relies on geospatial information. Our experiments
suggested that the LLMs learn and use an internal model of space in solving
geospatial related tasks.

---------------

### 05 Mar 2024 | [Evaluating Spatial Understanding of Large Language Models](https://arxiv.org/abs/2310.14540) | [⬇️](https://arxiv.org/pdf/2310.14540)
*Yutaro Yamada, Yihan Bao, Andrew K. Lampinen, Jungo Kasai, Ilker  Yildirim* 

  Large language models (LLMs) show remarkable capabilities across a variety of
tasks. Despite the models only seeing text in training, several recent studies
suggest that LLM representations implicitly capture aspects of the underlying
grounded concepts. Here, we explore LLM representations of a particularly
salient kind of grounded knowledge -- spatial relationships. We design
natural-language navigation tasks and evaluate the ability of LLMs, in
particular GPT-3.5-turbo, GPT-4, and Llama2 series models, to represent and
reason about spatial structures. These tasks reveal substantial variability in
LLM performance across different spatial structures, including square,
hexagonal, and triangular grids, rings, and trees. In extensive error analysis,
we find that LLMs' mistakes reflect both spatial and non-spatial factors. These
findings suggest that LLMs appear to capture certain aspects of spatial
structure implicitly, but room for improvement remains.

---------------

### 02 Jun 2023 | [Finding Neurons in a Haystack: Case Studies with Sparse Probing](https://arxiv.org/abs/2305.01610) | [⬇️](https://arxiv.org/pdf/2305.01610)
*Wes Gurnee, Neel Nanda, Matthew Pauly, Katherine Harvey, Dmitrii  Troitskii, Dimitris Bertsimas* 

  Despite rapid adoption and deployment of large language models (LLMs), the
internal computations of these models remain opaque and poorly understood. In
this work, we seek to understand how high-level human-interpretable features
are represented within the internal neuron activations of LLMs. We train
$k$-sparse linear classifiers (probes) on these internal activations to predict
the presence of features in the input; by varying the value of $k$ we study the
sparsity of learned representations and how this varies with model scale. With
$k=1$, we localize individual neurons which are highly relevant for a
particular feature, and perform a number of case studies to illustrate general
properties of LLMs. In particular, we show that early layers make use of sparse
combinations of neurons to represent many features in superposition, that
middle layers have seemingly dedicated neurons to represent higher-level
contextual features, and that increasing scale causes representational sparsity
to increase on average, but there are multiple types of scaling dynamics. In
all, we probe for over 100 unique features comprising 10 different categories
in 7 different models spanning 70 million to 6.9 billion parameters.

---------------

### 12 Jan 2024 | [Patchscopes: A Unifying Framework for Inspecting Hidden Representations  of Language Models](https://arxiv.org/abs/2401.06102) | [⬇️](https://arxiv.org/pdf/2401.06102)
*Asma Ghandeharioun, Avi Caciularu, Adam Pearce, Lucas Dixon, Mor Geva* 

  Inspecting the information encoded in hidden representations of large
language models (LLMs) can explain models' behavior and verify their alignment
with human values. Given the capabilities of LLMs in generating
human-understandable text, we propose leveraging the model itself to explain
its internal representations in natural language. We introduce a framework
called Patchscopes and show how it can be used to answer a wide range of
questions about an LLM's computation. We show that prior interpretability
methods based on projecting representations into the vocabulary space and
intervening on the LLM computation can be viewed as instances of this
framework. Moreover, several of their shortcomings such as failure in
inspecting early layers or lack of expressivity can be mitigated by
Patchscopes. Beyond unifying prior inspection techniques, Patchscopes also
opens up new possibilities such as using a more capable model to explain the
representations of a smaller model, and unlocks new applications such as
self-correction in multi-hop reasoning.

---------------

### 25 Dec 2023 | [Multiple Representation Transfer from Large Language Models to  End-to-End ASR Systems](https://arxiv.org/abs/2309.04031) | [⬇️](https://arxiv.org/pdf/2309.04031)
*Takuma Udagawa, Masayuki Suzuki, Gakuto Kurata, Masayasu Muraoka,  George Saon* 

  Transferring the knowledge of large language models (LLMs) is a promising
technique to incorporate linguistic knowledge into end-to-end automatic speech
recognition (ASR) systems. However, existing works only transfer a single
representation of LLM (e.g. the last layer of pretrained BERT), while the
representation of a text is inherently non-unique and can be obtained variously
from different layers, contexts and models. In this work, we explore a wide
range of techniques to obtain and transfer multiple representations of LLMs
into a transducer-based ASR system. While being conceptually simple, we show
that transferring multiple representations of LLMs can be an effective
alternative to transferring only a single representation.

---------------

### 29 Feb 2024 | [Language Models Represent Beliefs of Self and Others](https://arxiv.org/abs/2402.18496) | [⬇️](https://arxiv.org/pdf/2402.18496)
*Wentao Zhu, Zhining Zhang, Yizhou Wang* 

  Understanding and attributing mental states, known as Theory of Mind (ToM),
emerges as a fundamental capability for human social reasoning. While Large
Language Models (LLMs) appear to possess certain ToM abilities, the mechanisms
underlying these capabilities remain elusive. In this study, we discover that
it is possible to linearly decode the belief status from the perspectives of
various agents through neural activations of language models, indicating the
existence of internal representations of self and others' beliefs. By
manipulating these representations, we observe dramatic changes in the models'
ToM performance, underscoring their pivotal role in the social reasoning
process. Additionally, our findings extend to diverse social reasoning tasks
that involve different causal inference patterns, suggesting the potential
generalizability of these representations.

---------------

### 21 Dec 2023 | [Deep de Finetti: Recovering Topic Distributions from Large Language  Models](https://arxiv.org/abs/2312.14226) | [⬇️](https://arxiv.org/pdf/2312.14226)
*Liyi Zhang, R. Thomas McCoy, Theodore R. Sumers, Jian-Qiao Zhu, Thomas  L. Griffiths* 

  Large language models (LLMs) can produce long, coherent passages of text,
suggesting that LLMs, although trained on next-word prediction, must represent
the latent structure that characterizes a document. Prior work has found that
internal representations of LLMs encode one aspect of latent structure, namely
syntax; here we investigate a complementary aspect, namely the document's topic
structure. We motivate the hypothesis that LLMs capture topic structure by
connecting LLM optimization to implicit Bayesian inference. De Finetti's
theorem shows that exchangeable probability distributions can be represented as
a mixture with respect to a latent generating distribution. Although text is
not exchangeable at the level of syntax, exchangeability is a reasonable
starting assumption for topic structure. We thus hypothesize that predicting
the next token in text will lead LLMs to recover latent topic distributions. We
examine this hypothesis using Latent Dirichlet Allocation (LDA), an
exchangeable probabilistic topic model, as a target, and we show that the
representations formed by LLMs encode both the topics used to generate
synthetic data and those used to explain natural corpus data.

---------------

### 29 Sep 2023 | [Stable Anisotropic Regularization](https://arxiv.org/abs/2305.19358) | [⬇️](https://arxiv.org/pdf/2305.19358)
*William Rudman and Carsten Eickhoff* 

  Given the success of Large Language Models (LLMs), there has been
considerable interest in studying the properties of model activations. The
literature overwhelmingly agrees that LLM representations are dominated by a
few ``outlier dimensions'' with exceedingly high variance and magnitude.
Several studies in Natural Language Processing (NLP) have sought to mitigate
the impact of such outlier dimensions and force LLMs to be isotropic (i.e.,
have uniform variance across all dimensions in embedding space). Isotropy is
thought to be a desirable property for LLMs that improves model performance and
more closely aligns textual representations with human intuition. However, many
of the claims regarding isotropy in NLP have been based on the average cosine
similarity of embeddings, which has recently been shown to be a flawed measure
of isotropy. In this paper, we propose I-STAR: IsoScore*-based STable
Anisotropic Regularization, a novel regularization method that can be used to
increase or decrease levels of isotropy in embedding space during training.
I-STAR uses IsoScore*, the first accurate measure of isotropy that is both
differentiable and stable on mini-batch computations. In contrast to several
previous works, we find that decreasing isotropy in contextualized embeddings
improves performance on the majority of tasks and models considered in this
paper.

---------------

### 05 Feb 2024 | [Enhancing the Stability of LLM-based Speech Generation Systems through  Self-Supervised Representations](https://arxiv.org/abs/2402.03407) | [⬇️](https://arxiv.org/pdf/2402.03407)
*\'Alvaro Mart\'in-Cortinas, Daniel S\'aez-Trigueros, Iv\'an  Vall\'es-P\'erez, Biel Tura-Vecino, Piotr Bili\'nski, Mateusz Lajszczak,  Grzegorz Beringer, Roberto Barra-Chicote, Jaime Lorenzo-Trueba* 

  Large Language Models (LLMs) are one of the most promising technologies for
the next era of speech generation systems, due to their scalability and
in-context learning capabilities. Nevertheless, they suffer from multiple
stability issues at inference time, such as hallucinations, content skipping or
speech repetitions. In this work, we introduce a new self-supervised Voice
Conversion (VC) architecture which can be used to learn to encode transitory
features, such as content, separately from stationary ones, such as speaker ID
or recording conditions, creating speaker-disentangled representations. Using
speaker-disentangled codes to train LLMs for text-to-speech (TTS) allows the
LLM to generate the content and the style of the speech only from the text,
similarly to humans, while the speaker identity is provided by the decoder of
the VC model. Results show that LLMs trained over speaker-disentangled
self-supervised representations provide an improvement of 4.7pp in speaker
similarity over SOTA entangled representations, and a word error rate (WER)
5.4pp lower. Furthermore, they achieve higher naturalness than human recordings
of the LibriTTS test-other dataset. Finally, we show that using explicit
reference embedding negatively impacts intelligibility (stability), with WER
increasing by 14pp compared to the model that only uses text to infer the
style.

---------------

### 10 Oct 2023 | [NEWTON: Are Large Language Models Capable of Physical Reasoning?](https://arxiv.org/abs/2310.07018) | [⬇️](https://arxiv.org/pdf/2310.07018)
*Yi Ru Wang, Jiafei Duan, Dieter Fox, Siddhartha Srinivasa* 

  Large Language Models (LLMs), through their contextualized representations,
have been empirically proven to encapsulate syntactic, semantic, word sense,
and common-sense knowledge. However, there has been limited exploration of
their physical reasoning abilities, specifically concerning the crucial
attributes for comprehending everyday objects. To address this gap, we
introduce NEWTON, a repository and benchmark for evaluating the physics
reasoning skills of LLMs. Further, to enable domain-specific adaptation of this
benchmark, we present a pipeline to enable researchers to generate a variant of
this benchmark that has been customized to the objects and attributes relevant
for their application. The NEWTON repository comprises a collection of 2800
object-attribute pairs, providing the foundation for generating infinite-scale
assessment templates. The NEWTON benchmark consists of 160K QA questions,
curated using the NEWTON repository to investigate the physical reasoning
capabilities of several mainstream language models across foundational,
explicit, and implicit reasoning tasks. Through extensive empirical analysis,
our results highlight the capabilities of LLMs for physical reasoning. We find
that LLMs like GPT-4 demonstrate strong reasoning capabilities in
scenario-based tasks but exhibit less consistency in object-attribute reasoning
compared to humans (50% vs. 84%). Furthermore, the NEWTON platform demonstrates
its potential for evaluating and enhancing language models, paving the way for
their integration into physically grounded settings, such as robotic
manipulation. Project site: https://newtonreasoning.github.io

---------------

### 09 Jun 2023 | [Leveraging Large Language Models for Scalable Vector Graphics-Driven  Image Understanding](https://arxiv.org/abs/2306.06094) | [⬇️](https://arxiv.org/pdf/2306.06094)
*Mu Cai, Zeyi Huang, Yuheng Li, Haohan Wang, Yong Jae Lee* 

  Recently, large language models (LLMs) have made significant advancements in
natural language understanding and generation. However, their potential in
computer vision remains largely unexplored. In this paper, we introduce a new,
exploratory approach that enables LLMs to process images using the Scalable
Vector Graphics (SVG) format. By leveraging the XML-based textual descriptions
of SVG representations instead of raster images, we aim to bridge the gap
between the visual and textual modalities, allowing LLMs to directly understand
and manipulate images without the need for parameterized visual components. Our
method facilitates simple image classification, generation, and in-context
learning using only LLM capabilities. We demonstrate the promise of our
approach across discriminative and generative tasks, highlighting its (i)
robustness against distribution shift, (ii) substantial improvements achieved
by tapping into the in-context learning abilities of LLMs, and (iii) image
understanding and generation capabilities with human guidance. Our code, data,
and models can be found here https://github.com/mu-cai/svg-llm.

---------------

### 23 Jan 2024 | [Outlier Dimensions Encode Task-Specific Knowledge](https://arxiv.org/abs/2310.17715) | [⬇️](https://arxiv.org/pdf/2310.17715)
*William Rudman, Catherine Chen, and Carsten Eickhoff* 

  Representations from large language models (LLMs) are known to be dominated
by a small subset of dimensions with exceedingly high variance. Previous works
have argued that although ablating these outlier dimensions in LLM
representations hurts downstream performance, outlier dimensions are
detrimental to the representational quality of embeddings. In this study, we
investigate how fine-tuning impacts outlier dimensions and show that 1) outlier
dimensions that occur in pre-training persist in fine-tuned models and 2) a
single outlier dimension can complete downstream tasks with a minimal error
rate. Our results suggest that outlier dimensions can encode crucial
task-specific knowledge and that the value of a representation in a single
outlier dimension drives downstream model decisions.

---------------

### 29 Nov 2023 | [Hyperpolyglot LLMs: Cross-Lingual Interpretability in Token Embeddings](https://arxiv.org/abs/2311.18034) | [⬇️](https://arxiv.org/pdf/2311.18034)
*Andrea W Wen-Yi, David Mimno* 

  Cross-lingual transfer learning is an important property of multilingual
large language models (LLMs). But how do LLMs represent relationships between
languages? Every language model has an input layer that maps tokens to vectors.
This ubiquitous layer of language models is often overlooked. We find that
similarities between these input embeddings are highly interpretable and that
the geometry of these embeddings differs between model families. In one case
(XLM-RoBERTa), embeddings encode language: tokens in different writing systems
can be linearly separated with an average of 99.2% accuracy. Another family
(mT5) represents cross-lingual semantic similarity: the 50 nearest neighbors
for any token represent an average of 7.61 writing systems, and are frequently
translations. This result is surprising given that there is no explicit
parallel cross-lingual training corpora and no explicit incentive for
translations in pre-training objectives. Our research opens the door for
investigations in 1) The effect of pre-training and model architectures on
representations of languages and 2) The applications of cross-lingual
representations embedded in language models.

---------------

### 08 Nov 2023 | [Human Behavioral Benchmarking: Numeric Magnitude Comparison Effects in  Large Language Models](https://arxiv.org/abs/2305.10782) | [⬇️](https://arxiv.org/pdf/2305.10782)
*Raj Sanjay Shah, Vijay Marupudi, Reba Koenen, Khushi Bhardwaj, Sashank  Varma* 

  Large Language Models (LLMs) do not differentially represent numbers, which
are pervasive in text. In contrast, neuroscience research has identified
distinct neural representations for numbers and words. In this work, we
investigate how well popular LLMs capture the magnitudes of numbers (e.g., that
$4 < 5$) from a behavioral lens. Prior research on the representational
capabilities of LLMs evaluates whether they show human-level performance, for
instance, high overall accuracy on standard benchmarks. Here, we ask a
different question, one inspired by cognitive science: How closely do the
number representations of LLMscorrespond to those of human language users, who
typically demonstrate the distance, size, and ratio effects? We depend on a
linking hypothesis to map the similarities among the model embeddings of number
words and digits to human response times. The results reveal surprisingly
human-like representations across language models of different architectures,
despite the absence of the neural circuitry that directly supports these
representations in the human brain. This research shows the utility of
understanding LLMs using behavioral benchmarks and points the way to future
work on the number representations of LLMs and their cognitive plausibility.

---------------

### 04 Jul 2023 | [The Inner Sentiments of a Thought](https://arxiv.org/abs/2307.01784) | [⬇️](https://arxiv.org/pdf/2307.01784)
*Chris Gagne and Peter Dayan* 

  Transformer-based large-scale language models (LLMs) are able to generate
highly realistic text. They are duly able to express, and at least implicitly
represent, a wide range of sentiments and color, from the obvious, such as
valence and arousal to the subtle, such as determination and admiration. We
provide a first exploration of these representations and how they can be used
for understanding the inner sentimental workings of single sentences. We train
predictors of the quantiles of the distributions of final sentiments of
sentences from the hidden representations of an LLM applied to prefixes of
increasing lengths. After showing that predictors of distributions of valence,
determination, admiration, anxiety and annoyance are well calibrated, we
provide examples of using these predictors for analyzing sentences,
illustrating, for instance, how even ordinary conjunctions (e.g., "but") can
dramatically alter the emotional trajectory of an utterance. We then show how
to exploit the distributional predictions to generate sentences with sentiments
in the tails of distributions. We discuss the implications of our results for
the inner workings of thoughts, for instance for psychiatric dysfunction.

---------------

### 07 Nov 2023 | [The Linear Representation Hypothesis and the Geometry of Large Language  Models](https://arxiv.org/abs/2311.03658) | [⬇️](https://arxiv.org/pdf/2311.03658)
*Kiho Park, Yo Joong Choe, Victor Veitch* 

  Informally, the 'linear representation hypothesis' is the idea that
high-level concepts are represented linearly as directions in some
representation space. In this paper, we address two closely related questions:
What does "linear representation" actually mean? And, how do we make sense of
geometric notions (e.g., cosine similarity or projection) in the representation
space? To answer these, we use the language of counterfactuals to give two
formalizations of "linear representation", one in the output (word)
representation space, and one in the input (sentence) space. We then prove
these connect to linear probing and model steering, respectively. To make sense
of geometric notions, we use the formalization to identify a particular
(non-Euclidean) inner product that respects language structure in a sense we
make precise. Using this causal inner product, we show how to unify all notions
of linear representation. In particular, this allows the construction of probes
and steering vectors using counterfactual pairs. Experiments with LLaMA-2
demonstrate the existence of linear representations of concepts, the connection
to interpretation and control, and the fundamental role of the choice of inner
product.

---------------

### 27 Feb 2024 | [Distinguishing the Knowable from the Unknowable with Language Models](https://arxiv.org/abs/2402.03563) | [⬇️](https://arxiv.org/pdf/2402.03563)
*Gustaf Ahdritz, Tian Qin, Nikhil Vyas, Boaz Barak, Benjamin L. Edelman* 

  We study the feasibility of identifying epistemic uncertainty (reflecting a
lack of knowledge), as opposed to aleatoric uncertainty (reflecting entropy in
the underlying distribution), in the outputs of large language models (LLMs)
over free-form text. In the absence of ground-truth probabilities, we explore a
setting where, in order to (approximately) disentangle a given LLM's
uncertainty, a significantly larger model stands in as a proxy for the ground
truth. We show that small linear probes trained on the embeddings of frozen,
pretrained models accurately predict when larger models will be more confident
at the token level and that probes trained on one text domain generalize to
others. Going further, we propose a fully unsupervised method that achieves
non-trivial accuracy on the same task. Taken together, we interpret these
results as evidence that LLMs naturally contain internal representations of
different types of uncertainty that could potentially be leveraged to devise
more informative indicators of model confidence in diverse practical settings.

---------------
**Date:** 08 Dec 2023

**Title:** The Geometry of Truth: Emergent Linear Structure in Large Language Model  Representations of True/False Datasets

**Abstract Link:** [https://arxiv.org/abs/2310.06824](https://arxiv.org/abs/2310.06824)

**PDF Link:** [https://arxiv.org/pdf/2310.06824](https://arxiv.org/pdf/2310.06824)

---

**Date:** 21 Feb 2024

**Title:** Decoding In-Context Learning: Neuroscience-inspired Analysis of  Representations in Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.00313](https://arxiv.org/abs/2310.00313)

**PDF Link:** [https://arxiv.org/pdf/2310.00313](https://arxiv.org/pdf/2310.00313)

---

**Date:** 04 Mar 2024

**Title:** Language Models Represent Space and Time

**Abstract Link:** [https://arxiv.org/abs/2310.02207](https://arxiv.org/abs/2310.02207)

**PDF Link:** [https://arxiv.org/pdf/2310.02207](https://arxiv.org/pdf/2310.02207)

---

**Date:** 26 Dec 2023

**Title:** More than Correlation: Do Large Language Models Learn Causal  Representations of Space?

**Abstract Link:** [https://arxiv.org/abs/2312.16257](https://arxiv.org/abs/2312.16257)

**PDF Link:** [https://arxiv.org/pdf/2312.16257](https://arxiv.org/pdf/2312.16257)

---

**Date:** 05 Mar 2024

**Title:** Evaluating Spatial Understanding of Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.14540](https://arxiv.org/abs/2310.14540)

**PDF Link:** [https://arxiv.org/pdf/2310.14540](https://arxiv.org/pdf/2310.14540)

---

**Date:** 02 Jun 2023

**Title:** Finding Neurons in a Haystack: Case Studies with Sparse Probing

**Abstract Link:** [https://arxiv.org/abs/2305.01610](https://arxiv.org/abs/2305.01610)

**PDF Link:** [https://arxiv.org/pdf/2305.01610](https://arxiv.org/pdf/2305.01610)

---

**Date:** 12 Jan 2024

**Title:** Patchscopes: A Unifying Framework for Inspecting Hidden Representations  of Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.06102](https://arxiv.org/abs/2401.06102)

**PDF Link:** [https://arxiv.org/pdf/2401.06102](https://arxiv.org/pdf/2401.06102)

---

**Date:** 25 Dec 2023

**Title:** Multiple Representation Transfer from Large Language Models to  End-to-End ASR Systems

**Abstract Link:** [https://arxiv.org/abs/2309.04031](https://arxiv.org/abs/2309.04031)

**PDF Link:** [https://arxiv.org/pdf/2309.04031](https://arxiv.org/pdf/2309.04031)

---

**Date:** 29 Feb 2024

**Title:** Language Models Represent Beliefs of Self and Others

**Abstract Link:** [https://arxiv.org/abs/2402.18496](https://arxiv.org/abs/2402.18496)

**PDF Link:** [https://arxiv.org/pdf/2402.18496](https://arxiv.org/pdf/2402.18496)

---

**Date:** 21 Dec 2023

**Title:** Deep de Finetti: Recovering Topic Distributions from Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2312.14226](https://arxiv.org/abs/2312.14226)

**PDF Link:** [https://arxiv.org/pdf/2312.14226](https://arxiv.org/pdf/2312.14226)

---

**Date:** 29 Sep 2023

**Title:** Stable Anisotropic Regularization

**Abstract Link:** [https://arxiv.org/abs/2305.19358](https://arxiv.org/abs/2305.19358)

**PDF Link:** [https://arxiv.org/pdf/2305.19358](https://arxiv.org/pdf/2305.19358)

---

**Date:** 05 Feb 2024

**Title:** Enhancing the Stability of LLM-based Speech Generation Systems through  Self-Supervised Representations

**Abstract Link:** [https://arxiv.org/abs/2402.03407](https://arxiv.org/abs/2402.03407)

**PDF Link:** [https://arxiv.org/pdf/2402.03407](https://arxiv.org/pdf/2402.03407)

---

**Date:** 10 Oct 2023

**Title:** NEWTON: Are Large Language Models Capable of Physical Reasoning?

**Abstract Link:** [https://arxiv.org/abs/2310.07018](https://arxiv.org/abs/2310.07018)

**PDF Link:** [https://arxiv.org/pdf/2310.07018](https://arxiv.org/pdf/2310.07018)

---

**Date:** 09 Jun 2023

**Title:** Leveraging Large Language Models for Scalable Vector Graphics-Driven  Image Understanding

**Abstract Link:** [https://arxiv.org/abs/2306.06094](https://arxiv.org/abs/2306.06094)

**PDF Link:** [https://arxiv.org/pdf/2306.06094](https://arxiv.org/pdf/2306.06094)

---

**Date:** 23 Jan 2024

**Title:** Outlier Dimensions Encode Task-Specific Knowledge

**Abstract Link:** [https://arxiv.org/abs/2310.17715](https://arxiv.org/abs/2310.17715)

**PDF Link:** [https://arxiv.org/pdf/2310.17715](https://arxiv.org/pdf/2310.17715)

---

**Date:** 29 Nov 2023

**Title:** Hyperpolyglot LLMs: Cross-Lingual Interpretability in Token Embeddings

**Abstract Link:** [https://arxiv.org/abs/2311.18034](https://arxiv.org/abs/2311.18034)

**PDF Link:** [https://arxiv.org/pdf/2311.18034](https://arxiv.org/pdf/2311.18034)

---

**Date:** 08 Nov 2023

**Title:** Human Behavioral Benchmarking: Numeric Magnitude Comparison Effects in  Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2305.10782](https://arxiv.org/abs/2305.10782)

**PDF Link:** [https://arxiv.org/pdf/2305.10782](https://arxiv.org/pdf/2305.10782)

---

**Date:** 04 Jul 2023

**Title:** The Inner Sentiments of a Thought

**Abstract Link:** [https://arxiv.org/abs/2307.01784](https://arxiv.org/abs/2307.01784)

**PDF Link:** [https://arxiv.org/pdf/2307.01784](https://arxiv.org/pdf/2307.01784)

---

**Date:** 07 Nov 2023

**Title:** The Linear Representation Hypothesis and the Geometry of Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2311.03658](https://arxiv.org/abs/2311.03658)

**PDF Link:** [https://arxiv.org/pdf/2311.03658](https://arxiv.org/pdf/2311.03658)

---

**Date:** 27 Feb 2024

**Title:** Distinguishing the Knowable from the Unknowable with Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.03563](https://arxiv.org/abs/2402.03563)

**PDF Link:** [https://arxiv.org/pdf/2402.03563](https://arxiv.org/pdf/2402.03563)

---

