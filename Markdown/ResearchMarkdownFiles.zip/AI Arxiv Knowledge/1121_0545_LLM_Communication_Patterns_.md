LLM Communication Patterns 🗣️

### 🔎 LLM Communication Patterns 🗣️



# Communication Patterns 🗣️

Communication patterns are the ways in which people communicate with each other. They can be formal or informal, verbal or nonverbal, and can take many different forms. Some common communication patterns include:

1. One-way communication: This is when one person speaks and the other person listens, without any feedback or response. This can be useful in situations where a clear message needs to be conveyed, such as in a lecture or presentation.
2. Two-way communication: This is when both people speak and listen to each other, exchanging ideas and information. This is the most common form of communication and is essential for building relationships and resolving conflicts.
3. Active listening: This is when one person listens carefully to what the other person is saying, paying attention to their words, tone of voice, and body language. This helps to build trust and understanding, and can help to prevent misunderstandings.
4. Nonverbal communication: This is when people use body language, facial expressions, or gestures to communicate. This can be useful in situations where words are not necessary, such as in a crowded room or in a silent agreement.
5. Passive communication: This is when people do not speak up or express their thoughts and feelings, often because they are afraid of conflict or rejection. This can lead to misunderstandings and resentment.
6. Aggressive communication: This is when people speak loudly and forcefully, often to intimidate or dominate others. This can be harmful and can lead to conflict and hurt feelings.
7. Assertive communication: This is when people express their thoughts and feelings in a clear and respectful way, standing up for themselves without being aggressive. This is the most effective form of communication and can help to build strong and healthy relationships.

It is important to be aware of your own communication patterns and to try to use assertive communication as much as possible. This can help to build trust, understanding, and respect in your relationships, and can help to prevent misunderstandings and conflicts.</s>
# 🩺🔍 Search Results
### 14 Sep 2023 | [SayTap: Language to Quadrupedal Locomotion](https://arxiv.org/abs/2306.07580) | [⬇️](https://arxiv.org/pdf/2306.07580)
*Yujin Tang, Wenhao Yu, Jie Tan, Heiga Zen, Aleksandra Faust, Tatsuya  Harada* 

  Large language models (LLMs) have demonstrated the potential to perform
high-level planning. Yet, it remains a challenge for LLMs to comprehend
low-level commands, such as joint angle targets or motor torques. This paper
proposes an approach to use foot contact patterns as an interface that bridges
human commands in natural language and a locomotion controller that outputs
these low-level commands. This results in an interactive system for quadrupedal
robots that allows the users to craft diverse locomotion behaviors flexibly. We
contribute an LLM prompt design, a reward function, and a method to expose the
controller to the feasible distribution of contact patterns. The results are a
controller capable of achieving diverse locomotion patterns that can be
transferred to real robot hardware. Compared with other design choices, the
proposed approach enjoys more than 50% success rate in predicting the correct
contact patterns and can solve 10 more tasks out of a total of 30 tasks. Our
project site is: https://saytap.github.io.

---------------

### 10 Oct 2023 | [Adapting LLM Agents Through Communication](https://arxiv.org/abs/2310.01444) | [⬇️](https://arxiv.org/pdf/2310.01444)
*Kuan Wang, Yadong Lu, Michael Santacroce, Yeyun Gong, Chao Zhang,  Yelong Shen* 

  Recent advancements in large language models (LLMs) have shown potential for
human-like agents. To help these agents adapt to new tasks without extensive
human supervision, we propose the Learning through Communication (LTC)
paradigm, a novel training approach enabling LLM agents to improve continuously
through interactions with their environments and other agents. Recent
advancements in large language models (LLMs) have shown potential for
human-like agents. To help these agents adapt to new tasks without extensive
human supervision, we propose the Learning through Communication (LTC)
paradigm, a novel training approach enabling LLM agents to improve continuously
through interactions with their environments and other agents. Through
iterative exploration and PPO training, LTC empowers the agent to assimilate
short-term experiences into long-term memory. To optimize agent interactions
for task-specific learning, we introduce three structured communication
patterns: Monologue, Dialogue, and Analogue-tailored for common tasks such as
decision-making, knowledge-intensive reasoning, and numerical reasoning. We
evaluated LTC on three datasets: ALFWorld (decision-making), HotpotQA
(knowledge-intensive reasoning), and GSM8k (numerical reasoning). On ALFWorld,
it exceeds the instruction tuning baseline by 12% in success rate. On HotpotQA,
LTC surpasses the instruction-tuned LLaMA-7B agent by 5.1% in EM score, and it
outperforms the instruction-tuned 9x larger PaLM-62B agent by 0.6%. On GSM8k,
LTC outperforms the CoT-Tuning baseline by 3.6% in accuracy. The results
showcase the versatility and efficiency of the LTC approach across diverse
domains. We will open-source our code to promote further development of the
community.

---------------

### 23 Oct 2023 | [Machine Psychology: Investigating Emergent Capabilities and Behavior in  Large Language Models Using Psychological Methods](https://arxiv.org/abs/2303.13988) | [⬇️](https://arxiv.org/pdf/2303.13988)
*Thilo Hagendorff* 

  Large language models (LLMs) are currently at the forefront of intertwining
AI systems with human communication and everyday life. Due to rapid
technological advances and their extreme versatility, LLMs nowadays have
millions of users and are at the cusp of being the main go-to technology for
information retrieval, content generation, problem-solving, etc. Therefore, it
is of great importance to thoroughly assess and scrutinize their capabilities.
Due to increasingly complex and novel behavioral patterns in current LLMs, this
can be done by treating them as participants in psychology experiments that
were originally designed to test humans. For this purpose, the paper introduces
a new field of research called "machine psychology". The paper outlines how
different subfields of psychology can inform behavioral tests for LLMs. It
defines methodological standards for machine psychology research, especially by
focusing on policies for prompt designs. Additionally, it describes how
behavioral patterns discovered in LLMs are to be interpreted. In sum, machine
psychology aims to discover emergent abilities in LLMs that cannot be detected
by most traditional natural language processing benchmarks.

---------------

### 01 Nov 2023 | [How to Build Low-cost Networks for Large Language Models (without  Sacrificing Performance)?](https://arxiv.org/abs/2307.12169) | [⬇️](https://arxiv.org/pdf/2307.12169)
*Weiyang Wang, Manya Ghobadi, Kayvon Shakeri, Ying Zhang, Naader Hasani* 

  This paper challenges the well-established paradigm for building any-to-any
networks for training Large Language Models (LLMs). We show that LLMs exhibit a
unique communication pattern where only small groups of GPUs require
high-bandwidth communication to achieve near-optimal training performance.
Across these groups of GPUs, the communication is insignificant and
homogeneous. We propose a new network architecture that resembles the
communication requirement of LLMs. Our architecture partitions the cluster into
sets of GPUs interconnected with non-blocking any-to-any high-bandwidth
interconnects that we call HB domains. Across the HB domains, the network only
connects GPUs with non-zero communication demands. We develop an analytical
formulation of the training iteration time to evaluate our proposal. Our
formulation closely estimates the hardware floating-point utilization within
0.15\% from the ground truth established in prior studies for larger models. We
show that our proposed architecture reduces the network cost by 37% to 75%
compared to the state-of-the-art any-to-any Clos networks without compromising
the performance of LLM training.

---------------

### 16 Feb 2024 | [Threads of Subtlety: Detecting Machine-Generated Texts Through Discourse  Motifs](https://arxiv.org/abs/2402.10586) | [⬇️](https://arxiv.org/pdf/2402.10586)
*Zae Myung Kim and Kwang Hee Lee and Preston Zhu and Vipul Raheja and  Dongyeop Kang* 

  With the advent of large language models (LLM), the line between
human-crafted and machine-generated texts has become increasingly blurred. This
paper delves into the inquiry of identifying discernible and unique linguistic
properties in texts that were written by humans, particularly uncovering the
underlying discourse structures of texts beyond their surface structures.
Introducing a novel methodology, we leverage hierarchical parse trees and
recursive hypergraphs to unveil distinctive discourse patterns in texts
produced by both LLMs and humans. Empirical findings demonstrate that, although
both LLMs and humans generate distinct discourse patterns influenced by
specific domains, human-written texts exhibit more structural variability,
reflecting the nuanced nature of human writing in different domains. Notably,
incorporating hierarchical discourse features enhances binary classifiers'
overall performance in distinguishing between human-written and
machine-generated texts, even on out-of-distribution and paraphrased samples.
This underscores the significance of incorporating hierarchical discourse
features in the analysis of text patterns. The code and dataset will be
available at [TBA].

---------------

### 05 Dec 2023 | [Weakly Supervised Detection of Hallucinations in LLM Activations](https://arxiv.org/abs/2312.02798) | [⬇️](https://arxiv.org/pdf/2312.02798)
*Miriam Rateike, Celia Cintas, John Wamburu, Tanya Akumu, Skyler  Speakman* 

  We propose an auditing method to identify whether a large language model
(LLM) encodes patterns such as hallucinations in its internal states, which may
propagate to downstream tasks. We introduce a weakly supervised auditing
technique using a subset scanning approach to detect anomalous patterns in LLM
activations from pre-trained models. Importantly, our method does not need
knowledge of the type of patterns a-priori. Instead, it relies on a reference
dataset devoid of anomalies during testing. Further, our approach enables the
identification of pivotal nodes responsible for encoding these patterns, which
may offer crucial insights for fine-tuning specific sub-networks for bias
mitigation. We introduce two new scanning methods to handle LLM activations for
anomalous sentences that may deviate from the expected distribution in either
direction. Our results confirm prior findings of BERT's limited internal
capacity for encoding hallucinations, while OPT appears capable of encoding
hallucination information internally. Importantly, our scanning approach,
without prior exposure to false statements, performs comparably to a fully
supervised out-of-distribution classifier.

---------------

### 09 Feb 2024 | [Exploring Interaction Patterns for Debugging: Enhancing Conversational  Capabilities of AI-assistants](https://arxiv.org/abs/2402.06229) | [⬇️](https://arxiv.org/pdf/2402.06229)
*Bhavya Chopra, Yasharth Bajpai, Param Biyani, Gustavo Soares, Arjun  Radhakrishna, Chris Parnin, Sumit Gulwani* 

  The widespread availability of Large Language Models (LLMs) within Integrated
Development Environments (IDEs) has led to their speedy adoption.
Conversational interactions with LLMs enable programmers to obtain natural
language explanations for various software development tasks. However, LLMs
often leap to action without sufficient context, giving rise to implicit
assumptions and inaccurate responses. Conversations between developers and LLMs
are primarily structured as question-answer pairs, where the developer is
responsible for asking the the right questions and sustaining conversations
across multiple turns. In this paper, we draw inspiration from interaction
patterns and conversation analysis -- to design Robin, an enhanced
conversational AI-assistant for debugging. Through a within-subjects user study
with 12 industry professionals, we find that equipping the LLM to -- (1)
leverage the insert expansion interaction pattern, (2) facilitate turn-taking,
and (3) utilize debugging workflows -- leads to lowered conversation barriers,
effective fault localization, and 5x improvement in bug resolution rates.

---------------

### 26 Oct 2023 | [Event knowledge in large language models: the gap between the impossible  and the unlikely](https://arxiv.org/abs/2212.01488) | [⬇️](https://arxiv.org/pdf/2212.01488)
*Carina Kauf, Anna A. Ivanova, Giulia Rambelli, Emmanuele Chersoni,  Jingyuan Selena She, Zawad Chowdhury, Evelina Fedorenko, Alessandro Lenci* 

  Word co-occurrence patterns in language corpora contain a surprising amount
of conceptual knowledge. Large language models (LLMs), trained to predict words
in context, leverage these patterns to achieve impressive performance on
diverse semantic tasks requiring world knowledge. An important but understudied
question about LLMs' semantic abilities is whether they acquire generalized
knowledge of common events. Here, we test whether five pre-trained LLMs (from
2018's BERT to 2023's MPT) assign higher likelihood to plausible descriptions
of agent-patient interactions than to minimally different implausible versions
of the same event. Using three curated sets of minimal sentence pairs (total
n=1,215), we found that pre-trained LLMs possess substantial event knowledge,
outperforming other distributional language models. In particular, they almost
always assign higher likelihood to possible vs. impossible events (The teacher
bought the laptop vs. The laptop bought the teacher). However, LLMs show less
consistent preferences for likely vs. unlikely events (The nanny tutored the
boy vs. The boy tutored the nanny). In follow-up analyses, we show that (i) LLM
scores are driven by both plausibility and surface-level sentence features,
(ii) LLM scores generalize well across syntactic variants (active vs. passive
constructions) but less well across semantic variants (synonymous sentences),
(iii) some LLM errors mirror human judgment ambiguity, and (iv) sentence
plausibility serves as an organizing dimension in internal LLM representations.
Overall, our results show that important aspects of event knowledge naturally
emerge from distributional linguistic patterns, but also highlight a gap
between representations of possible/impossible and likely/unlikely events.

---------------

### 01 Mar 2024 | [Leveraging Prompt-Based Large Language Models: Predicting Pandemic  Health Decisions and Outcomes Through Social Media Language](https://arxiv.org/abs/2403.00994) | [⬇️](https://arxiv.org/pdf/2403.00994)
*Xiaohan Ding, Buse Carik, Uma Sushmitha Gunturi, Valerie Reyna, and  Eugenia H. Rho* 

  We introduce a multi-step reasoning framework using prompt-based LLMs to
examine the relationship between social media language patterns and trends in
national health outcomes. Grounded in fuzzy-trace theory, which emphasizes the
importance of gists of causal coherence in effective health communication, we
introduce Role-Based Incremental Coaching (RBIC), a prompt-based LLM framework,
to identify gists at-scale. Using RBIC, we systematically extract gists from
subreddit discussions opposing COVID-19 health measures (Study 1). We then
track how these gists evolve across key events (Study 2) and assess their
influence on online engagement (Study 3). Finally, we investigate how the
volume of gists is associated with national health trends like vaccine uptake
and hospitalizations (Study 4). Our work is the first to empirically link
social media linguistic patterns to real-world public health trends,
highlighting the potential of prompt-based LLMs in identifying critical online
discussion patterns that can form the basis of public health communication
strategies.

---------------

### 26 Feb 2024 | [Unraveling Babel: Exploring Multilingual Activation Patterns within  Large Language Models](https://arxiv.org/abs/2402.16367) | [⬇️](https://arxiv.org/pdf/2402.16367)
*Weize Liu, Yinlong Xu, Hongxia Xu, Jintai Chen, Xuming Hu, Jian Wu* 

  Recently, large language models (LLMs) have achieved tremendous breakthroughs
in the field of language processing, yet their mechanisms in processing
multiple languages remain agnostic. Therefore, in this work we study the
multilingual activation patterns of LLMs. By transforming the original Large
Language Models (LLMs) into a Mixture of Experts (MoE) architecture, we analyze
the expert activation patterns when processing various languages and
demonstrate the connections of these activation patterns at the level of
language families. We discover the existence of non-language-specific neurons
as well as language-specific activation neurons. Further exploration even
showcases that merely leveraging high-frequency activation neurons can
accelerate inference while maintaining comparable performance. These findings
shed light on the LLMs' multilingual processing mechanism, and are of
significant importance in guiding the multilingual training and model pruning
of LLMs.

---------------

### 07 Oct 2023 | [Large Language Models for Spatial Trajectory Patterns Mining](https://arxiv.org/abs/2310.04942) | [⬇️](https://arxiv.org/pdf/2310.04942)
*Zheng Zhang, Hossein Amiri, Zhenke Liu, Andreas Z\"ufle, Liang Zhao* 

  Identifying anomalous human spatial trajectory patterns can indicate dynamic
changes in mobility behavior with applications in domains like infectious
disease monitoring and elderly care. Recent advancements in large language
models (LLMs) have demonstrated their ability to reason in a manner akin to
humans. This presents significant potential for analyzing temporal patterns in
human mobility. In this paper, we conduct empirical studies to assess the
capabilities of leading LLMs like GPT-4 and Claude-2 in detecting anomalous
behaviors from mobility data, by comparing to specialized methods. Our key
findings demonstrate that LLMs can attain reasonable anomaly detection
performance even without any specific cues. In addition, providing contextual
clues about potential irregularities could further enhances their prediction
efficacy. Moreover, LLMs can provide reasonable explanations for their
judgments, thereby improving transparency. Our work provides insights on the
strengths and limitations of LLMs for human spatial trajectory analysis.

---------------

### 30 Jan 2024 | [Security and Privacy Challenges of Large Language Models: A Survey](https://arxiv.org/abs/2402.00888) | [⬇️](https://arxiv.org/pdf/2402.00888)
*Badhan Chandra Das, M. Hadi Amini, Yanzhao Wu* 

  Large Language Models (LLMs) have demonstrated extraordinary capabilities and
contributed to multiple fields, such as generating and summarizing text,
language translation, and question-answering. Nowadays, LLM is becoming a very
popular tool in computerized language processing tasks, with the capability to
analyze complicated linguistic patterns and provide relevant and appropriate
responses depending on the context. While offering significant advantages,
these models are also vulnerable to security and privacy attacks, such as
jailbreaking attacks, data poisoning attacks, and Personally Identifiable
Information (PII) leakage attacks. This survey provides a thorough review of
the security and privacy challenges of LLMs for both training data and users,
along with the application-based risks in various domains, such as
transportation, education, and healthcare. We assess the extent of LLM
vulnerabilities, investigate emerging security and privacy attacks for LLMs,
and review the potential defense mechanisms. Additionally, the survey outlines
existing research gaps in this domain and highlights future research
directions.

---------------

### 13 Feb 2024 | [How do Large Language Models Navigate Conflicts between Honesty and  Helpfulness?](https://arxiv.org/abs/2402.07282) | [⬇️](https://arxiv.org/pdf/2402.07282)
*Ryan Liu, Theodore R. Sumers, Ishita Dasgupta, Thomas L. Griffiths* 

  In day-to-day communication, people often approximate the truth - for
example, rounding the time or omitting details - in order to be maximally
helpful to the listener. How do large language models (LLMs) handle such
nuanced trade-offs? To address this question, we use psychological models and
experiments designed to characterize human behavior to analyze LLMs. We test a
range of LLMs and explore how optimization for human preferences or
inference-time reasoning affects these trade-offs. We find that reinforcement
learning from human feedback improves both honesty and helpfulness, while
chain-of-thought prompting skews LLMs towards helpfulness over honesty.
Finally, GPT-4 Turbo demonstrates human-like response patterns including
sensitivity to the conversational framing and listener's decision context. Our
findings reveal the conversational values internalized by LLMs and suggest that
even these abstract values can, to a degree, be steered by zero-shot prompting.

---------------

### 28 Jul 2023 | [Emotional Intelligence of Large Language Models](https://arxiv.org/abs/2307.09042) | [⬇️](https://arxiv.org/pdf/2307.09042)
*Xuena Wang, Xueting Li, Zi Yin, Yue Wu and Liu Jia* 

  Large Language Models (LLMs) have demonstrated remarkable abilities across
numerous disciplines, primarily assessed through tasks in language generation,
knowledge utilization, and complex reasoning. However, their alignment with
human emotions and values, which is critical for real-world applications, has
not been systematically evaluated. Here, we assessed LLMs' Emotional
Intelligence (EI), encompassing emotion recognition, interpretation, and
understanding, which is necessary for effective communication and social
interactions. Specifically, we first developed a novel psychometric assessment
focusing on Emotion Understanding (EU), a core component of EI, suitable for
both humans and LLMs. This test requires evaluating complex emotions (e.g.,
surprised, joyful, puzzled, proud) in realistic scenarios (e.g., despite
feeling underperformed, John surprisingly achieved a top score). With a
reference frame constructed from over 500 adults, we tested a variety of
mainstream LLMs. Most achieved above-average EQ scores, with GPT-4 exceeding
89% of human participants with an EQ of 117. Interestingly, a multivariate
pattern analysis revealed that some LLMs apparently did not reply on the
human-like mechanism to achieve human-level performance, as their
representational patterns were qualitatively distinct from humans. In addition,
we discussed the impact of factors such as model size, training method, and
architecture on LLMs' EQ. In summary, our study presents one of the first
psychometric evaluations of the human-like characteristics of LLMs, which may
shed light on the future development of LLMs aiming for both high intellectual
and emotional intelligence. Project website:
https://emotional-intelligence.github.io/

---------------

### 22 Sep 2023 | [TopRoBERTa: Topology-Aware Authorship Attribution of Deepfake Texts](https://arxiv.org/abs/2309.12934) | [⬇️](https://arxiv.org/pdf/2309.12934)
*Adaku Uchendu, Thai Le, Dongwon Lee* 

  Recent advances in Large Language Models (LLMs) have enabled the generation
of open-ended high-quality texts, that are non-trivial to distinguish from
human-written texts. We refer to such LLM-generated texts as \emph{deepfake
texts}. There are currently over 11K text generation models in the huggingface
model repo. As such, users with malicious intent can easily use these
open-sourced LLMs to generate harmful texts and misinformation at scale. To
mitigate this problem, a computational method to determine if a given text is a
deepfake text or not is desired--i.e., Turing Test (TT). In particular, in this
work, we investigate the more general version of the problem, known as
\emph{Authorship Attribution (AA)}, in a multi-class setting--i.e., not only
determining if a given text is a deepfake text or not but also being able to
pinpoint which LLM is the author. We propose \textbf{TopRoBERTa} to improve
existing AA solutions by capturing more linguistic patterns in deepfake texts
by including a Topological Data Analysis (TDA) layer in the RoBERTa model. We
show the benefits of having a TDA layer when dealing with noisy, imbalanced,
and heterogeneous datasets, by extracting TDA features from the reshaped
$pooled\_output$ of RoBERTa as input. We use RoBERTa to capture contextual
representations (i.e., semantic and syntactic linguistic features), while using
TDA to capture the shape and structure of data (i.e., linguistic structures).
Finally, \textbf{TopRoBERTa}, outperforms the vanilla RoBERTa in 2/3 datasets,
achieving up to 7\% increase in Macro F1 score.

---------------

### 26 May 2023 | [Large Language Models Are Partially Primed in Pronoun Interpretation](https://arxiv.org/abs/2305.16917) | [⬇️](https://arxiv.org/pdf/2305.16917)
*Suet-Ying Lam, Qingcheng Zeng, Kexun Zhang, Chenyu You, Rob Voigt* 

  While a large body of literature suggests that large language models (LLMs)
acquire rich linguistic representations, little is known about whether they
adapt to linguistic biases in a human-like way. The present study probes this
question by asking whether LLMs display human-like referential biases using
stimuli and procedures from real psycholinguistic experiments. Recent
psycholinguistic studies suggest that humans adapt their referential biases
with recent exposure to referential patterns; closely replicating three
relevant psycholinguistic experiments from Johnson & Arnold (2022) in an
in-context learning (ICL) framework, we found that InstructGPT adapts its
pronominal interpretations in response to the frequency of referential patterns
in the local discourse, though in a limited fashion: adaptation was only
observed relative to syntactic but not semantic biases. By contrast, FLAN-UL2
fails to generate meaningful patterns. Our results provide further evidence
that contemporary LLMs discourse representations are sensitive to syntactic
patterns in the local context but less so to semantic patterns. Our data and
code are available at \url{https://github.com/zkx06111/llm_priming}.

---------------

### 07 Mar 2024 | [Can Small Language Models be Good Reasoners for Sequential  Recommendation?](https://arxiv.org/abs/2403.04260) | [⬇️](https://arxiv.org/pdf/2403.04260)
*Yuling Wang, Changxin Tian, Binbin Hu, Yanhua Yu, Ziqi Liu, Zhiqiang  Zhang, Jun Zhou, Liang Pang, Xiao Wang* 

  Large language models (LLMs) open up new horizons for sequential
recommendations, owing to their remarkable language comprehension and
generation capabilities. However, there are still numerous challenges that
should be addressed to successfully implement sequential recommendations
empowered by LLMs. Firstly, user behavior patterns are often complex, and
relying solely on one-step reasoning from LLMs may lead to incorrect or
task-irrelevant responses. Secondly, the prohibitively resource requirements of
LLM (e.g., ChatGPT-175B) are overwhelmingly high and impractical for real
sequential recommender systems. In this paper, we propose a novel Step-by-step
knowLedge dIstillation fraMework for recommendation (SLIM), paving a promising
path for sequential recommenders to enjoy the exceptional reasoning
capabilities of LLMs in a "slim" (i.e., resource-efficient) manner. We
introduce CoT prompting based on user behavior sequences for the larger teacher
model. The rationales generated by the teacher model are then utilized as
labels to distill the downstream smaller student model (e.g., LLaMA2-7B). In
this way, the student model acquires the step-by-step reasoning capabilities in
recommendation tasks. We encode the generated rationales from the student model
into a dense vector, which empowers recommendation in both ID-based and
ID-agnostic scenarios. Extensive experiments demonstrate the effectiveness of
SLIM over state-of-the-art baselines, and further analysis showcasing its
ability to generate meaningful recommendation reasoning at affordable costs.

---------------

### 25 Feb 2023 | [On pitfalls (and advantages) of sophisticated large language models](https://arxiv.org/abs/2303.17511) | [⬇️](https://arxiv.org/pdf/2303.17511)
*Anna Strasser* 

  Natural language processing based on large language models (LLMs) is a
booming field of AI research. After neural networks have proven to outperform
humans in games and practical domains based on pattern recognition, we might
stand now at a road junction where artificial entities might eventually enter
the realm of human communication. However, this comes with serious risks. Due
to the inherent limitations regarding the reliability of neural networks,
overreliance on LLMs can have disruptive consequences. Since it will be
increasingly difficult to distinguish between human-written and
machine-generated text, one is confronted with new ethical challenges. This
begins with the no longer undoubtedly verifiable human authorship and continues
with various types of fraud, such as a new form of plagiarism. This also
concerns the violation of privacy rights, the possibility of circulating
counterfeits of humans, and, last but not least, it makes a massive spread of
misinformation possible.

---------------

### 11 Mar 2023 | [ChatGPT Prompt Patterns for Improving Code Quality, Refactoring,  Requirements Elicitation, and Software Design](https://arxiv.org/abs/2303.07839) | [⬇️](https://arxiv.org/pdf/2303.07839)
*Jules White, Sam Hays, Quchen Fu, Jesse Spencer-Smith, Douglas C.  Schmidt* 

  This paper presents prompt design techniques for software engineering, in the
form of patterns, to solve common problems when using large language models
(LLMs), such as ChatGPT to automate common software engineering activities,
such as ensuring code is decoupled from third-party libraries and simulating a
web application API before it is implemented. This paper provides two
contributions to research on using LLMs for software engineering. First, it
provides a catalog of patterns for software engineering that classifies
patterns according to the types of problems they solve. Second, it explores
several prompt patterns that have been applied to improve requirements
elicitation, rapid prototyping, code quality, refactoring, and system design.

---------------

### 20 Jul 2023 | [PatternGPT :A Pattern-Driven Framework for Large Language Model Text  Generation](https://arxiv.org/abs/2307.00470) | [⬇️](https://arxiv.org/pdf/2307.00470)
*Le Xiao and Xin Shan* 

  Large language models(LLMS)have shown excellent text generation capabilities,
capable of generating fluent human-like responses for many downstream tasks.
However, applying large language models to real-world critical tasks remains
challenging due to their susceptibility to hallucinations and inability to
directly use external knowledge. To cope with the above challenges, this paper
proposes PatternGPT, a pattern-driven text generation framework for Large
Language Models. Firstly, the framework utilizes the extraction capability of
Large Language Models to generate rich and diversified structured and
formalized patterns, which facilitates the introduction of external knowledge
to do the computation, and then draws on the idea of federated learning to use
multiple agents to achieve the sharing in order to obtain more diversified
patterns, and finally uses judgment criteria and optimization algorithm to
search for high-quality patterns to guide the generation of models. Finally,
external knowledge such as judgment criteria and optimization algorithms are
used to search for high-quality patterns, and the searched patterns are used to
guide model generation. This framework has the advantages of generating
diversified patterns, protecting data privacy, combining external knowledge,
and improving the quality of generation, which provides an effective method to
optimize the text generation capability of large language models, and make it
better applied to the field of intelligent dialogue and content generation.

---------------
**Date:** 14 Sep 2023

**Title:** SayTap: Language to Quadrupedal Locomotion

**Abstract Link:** [https://arxiv.org/abs/2306.07580](https://arxiv.org/abs/2306.07580)

**PDF Link:** [https://arxiv.org/pdf/2306.07580](https://arxiv.org/pdf/2306.07580)

---

**Date:** 10 Oct 2023

**Title:** Adapting LLM Agents Through Communication

**Abstract Link:** [https://arxiv.org/abs/2310.01444](https://arxiv.org/abs/2310.01444)

**PDF Link:** [https://arxiv.org/pdf/2310.01444](https://arxiv.org/pdf/2310.01444)

---

**Date:** 23 Oct 2023

**Title:** Machine Psychology: Investigating Emergent Capabilities and Behavior in  Large Language Models Using Psychological Methods

**Abstract Link:** [https://arxiv.org/abs/2303.13988](https://arxiv.org/abs/2303.13988)

**PDF Link:** [https://arxiv.org/pdf/2303.13988](https://arxiv.org/pdf/2303.13988)

---

**Date:** 01 Nov 2023

**Title:** How to Build Low-cost Networks for Large Language Models (without  Sacrificing Performance)?

**Abstract Link:** [https://arxiv.org/abs/2307.12169](https://arxiv.org/abs/2307.12169)

**PDF Link:** [https://arxiv.org/pdf/2307.12169](https://arxiv.org/pdf/2307.12169)

---

**Date:** 16 Feb 2024

**Title:** Threads of Subtlety: Detecting Machine-Generated Texts Through Discourse  Motifs

**Abstract Link:** [https://arxiv.org/abs/2402.10586](https://arxiv.org/abs/2402.10586)

**PDF Link:** [https://arxiv.org/pdf/2402.10586](https://arxiv.org/pdf/2402.10586)

---

**Date:** 05 Dec 2023

**Title:** Weakly Supervised Detection of Hallucinations in LLM Activations

**Abstract Link:** [https://arxiv.org/abs/2312.02798](https://arxiv.org/abs/2312.02798)

**PDF Link:** [https://arxiv.org/pdf/2312.02798](https://arxiv.org/pdf/2312.02798)

---

**Date:** 09 Feb 2024

**Title:** Exploring Interaction Patterns for Debugging: Enhancing Conversational  Capabilities of AI-assistants

**Abstract Link:** [https://arxiv.org/abs/2402.06229](https://arxiv.org/abs/2402.06229)

**PDF Link:** [https://arxiv.org/pdf/2402.06229](https://arxiv.org/pdf/2402.06229)

---

**Date:** 26 Oct 2023

**Title:** Event knowledge in large language models: the gap between the impossible  and the unlikely

**Abstract Link:** [https://arxiv.org/abs/2212.01488](https://arxiv.org/abs/2212.01488)

**PDF Link:** [https://arxiv.org/pdf/2212.01488](https://arxiv.org/pdf/2212.01488)

---

**Date:** 01 Mar 2024

**Title:** Leveraging Prompt-Based Large Language Models: Predicting Pandemic  Health Decisions and Outcomes Through Social Media Language

**Abstract Link:** [https://arxiv.org/abs/2403.00994](https://arxiv.org/abs/2403.00994)

**PDF Link:** [https://arxiv.org/pdf/2403.00994](https://arxiv.org/pdf/2403.00994)

---

**Date:** 26 Feb 2024

**Title:** Unraveling Babel: Exploring Multilingual Activation Patterns within  Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.16367](https://arxiv.org/abs/2402.16367)

**PDF Link:** [https://arxiv.org/pdf/2402.16367](https://arxiv.org/pdf/2402.16367)

---

**Date:** 07 Oct 2023

**Title:** Large Language Models for Spatial Trajectory Patterns Mining

**Abstract Link:** [https://arxiv.org/abs/2310.04942](https://arxiv.org/abs/2310.04942)

**PDF Link:** [https://arxiv.org/pdf/2310.04942](https://arxiv.org/pdf/2310.04942)

---

**Date:** 30 Jan 2024

**Title:** Security and Privacy Challenges of Large Language Models: A Survey

**Abstract Link:** [https://arxiv.org/abs/2402.00888](https://arxiv.org/abs/2402.00888)

**PDF Link:** [https://arxiv.org/pdf/2402.00888](https://arxiv.org/pdf/2402.00888)

---

**Date:** 13 Feb 2024

**Title:** How do Large Language Models Navigate Conflicts between Honesty and  Helpfulness?

**Abstract Link:** [https://arxiv.org/abs/2402.07282](https://arxiv.org/abs/2402.07282)

**PDF Link:** [https://arxiv.org/pdf/2402.07282](https://arxiv.org/pdf/2402.07282)

---

**Date:** 28 Jul 2023

**Title:** Emotional Intelligence of Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2307.09042](https://arxiv.org/abs/2307.09042)

**PDF Link:** [https://arxiv.org/pdf/2307.09042](https://arxiv.org/pdf/2307.09042)

---

**Date:** 22 Sep 2023

**Title:** TopRoBERTa: Topology-Aware Authorship Attribution of Deepfake Texts

**Abstract Link:** [https://arxiv.org/abs/2309.12934](https://arxiv.org/abs/2309.12934)

**PDF Link:** [https://arxiv.org/pdf/2309.12934](https://arxiv.org/pdf/2309.12934)

---

**Date:** 26 May 2023

**Title:** Large Language Models Are Partially Primed in Pronoun Interpretation

**Abstract Link:** [https://arxiv.org/abs/2305.16917](https://arxiv.org/abs/2305.16917)

**PDF Link:** [https://arxiv.org/pdf/2305.16917](https://arxiv.org/pdf/2305.16917)

---

**Date:** 07 Mar 2024

**Title:** Can Small Language Models be Good Reasoners for Sequential  Recommendation?

**Abstract Link:** [https://arxiv.org/abs/2403.04260](https://arxiv.org/abs/2403.04260)

**PDF Link:** [https://arxiv.org/pdf/2403.04260](https://arxiv.org/pdf/2403.04260)

---

**Date:** 25 Feb 2023

**Title:** On pitfalls (and advantages) of sophisticated large language models

**Abstract Link:** [https://arxiv.org/abs/2303.17511](https://arxiv.org/abs/2303.17511)

**PDF Link:** [https://arxiv.org/pdf/2303.17511](https://arxiv.org/pdf/2303.17511)

---

**Date:** 11 Mar 2023

**Title:** ChatGPT Prompt Patterns for Improving Code Quality, Refactoring,  Requirements Elicitation, and Software Design

**Abstract Link:** [https://arxiv.org/abs/2303.07839](https://arxiv.org/abs/2303.07839)

**PDF Link:** [https://arxiv.org/pdf/2303.07839](https://arxiv.org/pdf/2303.07839)

---

**Date:** 20 Jul 2023

**Title:** PatternGPT :A Pattern-Driven Framework for Large Language Model Text  Generation

**Abstract Link:** [https://arxiv.org/abs/2307.00470](https://arxiv.org/abs/2307.00470)

**PDF Link:** [https://arxiv.org/pdf/2307.00470](https://arxiv.org/pdf/2307.00470)

---

