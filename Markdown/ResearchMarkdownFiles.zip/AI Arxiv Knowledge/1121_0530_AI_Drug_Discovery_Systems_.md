AI Drug Discovery Systems 💊

### 🔎 AI Drug Discovery Systems 💊



# AI Drug Discovery Systems 💊

AI drug discovery systems are a type of artificial intelligence that is used to discover new drugs. These systems use machine learning algorithms to analyze large amounts of data, such as genetic information, to identify potential drug targets. Once a potential target has been identified, the system can then design and test potential drugs using computer simulations. This process can significantly reduce the time and cost of drug discovery, making it possible to bring new drugs to market more quickly.

There are several different types of AI drug discovery systems, each with its own strengths and weaknesses. Some systems focus on identifying potential drug targets, while others focus on designing and testing potential drugs. Some systems use a combination of both approaches.

One of the key benefits of AI drug discovery systems is their ability to analyze large amounts of data quickly and accurately. Traditional drug discovery methods rely on manual analysis of data, which can be time-consuming and prone to errors. AI drug discovery systems, on the other hand, can analyze data much more quickly and accurately, allowing researchers to identify potential drug targets and test potential drugs more efficiently.

Another benefit of AI drug discovery systems is their ability to design and test potential drugs using computer simulations. This can significantly reduce the time and cost of drug development, as it eliminates the need for expensive and time-consuming laboratory experiments. Instead, researchers can use computer simulations to predict how a potential drug will interact with a target protein, allowing them to identify potential problems and make adjustments before moving on to laboratory testing.

Despite their many benefits, AI drug discovery systems are not without their challenges. One of the biggest challenges is the need for large amounts of high-quality data. In order for these systems to work effectively, they need access to large datasets that contain accurate and relevant information. This can be difficult to obtain, as many healthcare organizations are reluctant to share their data due to privacy concerns.

Another challenge is the need for specialized expertise. AI drug discovery systems require a deep understanding of both artificial intelligence and drug development. This can make it difficult for organizations to find qualified personnel, as there are relatively few people who have expertise in both areas.

Despite these challenges, AI drug discovery systems are becoming increasingly popular in the pharmaceutical industry. They offer a powerful new tool for drug discovery, one that has the potential to significantly reduce the time and cost of bringing new drugs to market. As these systems continue
# 🩺🔍 Search Results
### 13 Jul 2023 | [Artificial Intelligence for Drug Discovery: Are We There Yet?](https://arxiv.org/abs/2307.06521) | [⬇️](https://arxiv.org/pdf/2307.06521)
*Catrin Hasselgren and Tudor I. Oprea* 

  Drug discovery is adapting to novel technologies such as data science,
informatics, and artificial intelligence (AI) to accelerate effective treatment
development while reducing costs and animal experiments. AI is transforming
drug discovery, as indicated by increasing interest from investors, industrial
and academic scientists, and legislators. Successful drug discovery requires
optimizing properties related to pharmacodynamics, pharmacokinetics, and
clinical outcomes. This review discusses the use of AI in the three pillars of
drug discovery: diseases, targets, and therapeutic modalities, with a focus on
small molecule drugs. AI technologies, such as generative chemistry, machine
learning, and multi-property optimization, have enabled several compounds to
enter clinical trials. The scientific community must carefully vet known
information to address the reproducibility crisis. The full potential of AI in
drug discovery can only be realized with sufficient ground truth and
appropriate human intervention at later pipeline stages.

---------------

### 24 Jan 2022 | [DrugOOD: Out-of-Distribution (OOD) Dataset Curator and Benchmark for  AI-aided Drug Discovery -- A Focus on Affinity Prediction Problems with Noise  Annotations](https://arxiv.org/abs/2201.09637) | [⬇️](https://arxiv.org/pdf/2201.09637)
*Yuanfeng Ji, Lu Zhang, Jiaxiang Wu, Bingzhe Wu, Long-Kai Huang,  Tingyang Xu, Yu Rong, Lanqing Li, Jie Ren, Ding Xue, Houtim Lai, Shaoyong Xu,  Jing Feng, Wei Liu, Ping Luo, Shuigeng Zhou, Junzhou Huang, Peilin Zhao,  Yatao Bian* 

  AI-aided drug discovery (AIDD) is gaining increasing popularity due to its
promise of making the search for new pharmaceuticals quicker, cheaper and more
efficient. In spite of its extensive use in many fields, such as ADMET
prediction, virtual screening, protein folding and generative chemistry, little
has been explored in terms of the out-of-distribution (OOD) learning problem
with \emph{noise}, which is inevitable in real world AIDD applications.
  In this work, we present DrugOOD, a systematic OOD dataset curator and
benchmark for AI-aided drug discovery, which comes with an open-source Python
package that fully automates the data curation and OOD benchmarking processes.
We focus on one of the most crucial problems in AIDD: drug target binding
affinity prediction, which involves both macromolecule (protein target) and
small-molecule (drug compound). In contrast to only providing fixed datasets,
DrugOOD offers automated dataset curator with user-friendly customization
scripts, rich domain annotations aligned with biochemistry knowledge, realistic
noise annotations and rigorous benchmarking of state-of-the-art OOD algorithms.
Since the molecular data is often modeled as irregular graphs using graph
neural network (GNN) backbones, DrugOOD also serves as a valuable testbed for
\emph{graph OOD learning} problems. Extensive empirical studies have shown a
significant performance gap between in-distribution and out-of-distribution
experiments, which highlights the need to develop better schemes that can allow
for OOD generalization under noise for AIDD.

---------------

### 02 Nov 2021 | [Artificial Intelligence in Drug Discovery: Applications and Techniques](https://arxiv.org/abs/2106.05386) | [⬇️](https://arxiv.org/pdf/2106.05386)
*Jianyuan Deng, Zhibo Yang, Iwao Ojima, Dimitris Samaras, Fusheng Wang* 

  Artificial intelligence (AI) has been transforming the practice of drug
discovery in the past decade. Various AI techniques have been used in a wide
range of applications, such as virtual screening and drug design. In this
survey, we first give an overview on drug discovery and discuss related
applications, which can be reduced to two major tasks, i.e., molecular property
prediction and molecule generation. We then discuss common data resources,
molecule representations and benchmark platforms. Furthermore, to summarize the
progress of AI in drug discovery, we present the relevant AI techniques
including model architectures and learning paradigms in the papers surveyed. We
expect that this survey will serve as a guide for researchers who are
interested in working at the interface of artificial intelligence and drug
discovery. We also provide a GitHub repository
(https://github.com/dengjianyuan/Survey_AI_Drug_Discovery) with the collection
of papers and codes, if applicable, as a learning resource, which is regularly
updated.

---------------

### 26 Dec 2022 | [Structure-based drug discovery with deep learning](https://arxiv.org/abs/2212.13295) | [⬇️](https://arxiv.org/pdf/2212.13295)
*R{\i}za \"Oz\c{c}elik, Derek van Tilborg, Jos\'e Jim\'enez-Luna,  Francesca Grisoni* 

  Artificial intelligence (AI) in the form of deep learning bears promise for
drug discovery and chemical biology, $\textit{e.g.}$, to predict protein
structure and molecular bioactivity, plan organic synthesis, and design
molecules $\textit{de novo}$. While most of the deep learning efforts in drug
discovery have focused on ligand-based approaches, structure-based drug
discovery has the potential to tackle unsolved challenges, such as affinity
prediction for unexplored protein targets, binding-mechanism elucidation, and
the rationalization of related chemical kinetic properties. Advances in deep
learning methodologies and the availability of accurate predictions for protein
tertiary structure advocate for a $\textit{renaissance}$ in structure-based
approaches for drug discovery guided by AI. This review summarizes the most
prominent algorithmic concepts in structure-based deep learning for drug
discovery, and forecasts opportunities, applications, and challenges ahead.

---------------

### 07 Mar 2023 | [Knowledge-augmented Graph Machine Learning for Drug Discovery: A Survey  from Precision to Interpretability](https://arxiv.org/abs/2302.08261) | [⬇️](https://arxiv.org/pdf/2302.08261)
*Zhiqiang Zhong and Anastasia Barkova and Davide Mottin* 

  The integration of Artificial Intelligence (AI) into the field of drug
discovery has been a growing area of interdisciplinary scientific research.
However, conventional AI models are heavily limited in handling complex
biomedical structures (such as 2D or 3D protein and molecule structures) and
providing interpretations for outputs, which hinders their practical
application. As of late, Graph Machine Learning (GML) has gained considerable
attention for its exceptional ability to model graph-structured biomedical data
and investigate their properties and functional relationships. Despite
extensive efforts, GML methods still suffer from several deficiencies, such as
the limited ability to handle supervision sparsity and provide interpretability
in learning and inference processes, and their ineffectiveness in utilising
relevant domain knowledge. In response, recent studies have proposed
integrating external biomedical knowledge into the GML pipeline to realise more
precise and interpretable drug discovery with limited training instances.
However, a systematic definition for this burgeoning research direction is yet
to be established. This survey presents a comprehensive overview of
long-standing drug discovery principles, provides the foundational concepts and
cutting-edge techniques for graph-structured data and knowledge databases, and
formally summarises Knowledge-augmented Graph Machine Learning (KaGML) for drug
discovery. we propose a thorough review of related KaGML works, collected
following a carefully designed search methodology, and organise them into four
categories following a novel-defined taxonomy. To facilitate research in this
promptly emerging field, we also share collected practical resources that are
valuable for intelligent drug discovery and provide an in-depth discussion of
the potential avenues for future advancements.

---------------

### 14 Oct 2023 | [Towards Unified AI Drug Discovery with Multiple Knowledge Modalities](https://arxiv.org/abs/2305.01523) | [⬇️](https://arxiv.org/pdf/2305.01523)
*Yizhen Luo, Xing Yi Liu, Kai Yang, Kui Huang, Massimo Hong, Jiahuan  Zhang, Yushuai Wu, Zaiqing Nie* 

  In recent years, AI models that mine intrinsic patterns from molecular
structures and protein sequences have shown promise in accelerating drug
discovery. However, these methods partly lag behind real-world pharmaceutical
approaches of human experts that additionally grasp structured knowledge from
knowledge bases and unstructured knowledge from biomedical literature. To
bridge this gap, we propose KEDD, a unified, end-to-end, and multimodal deep
learning framework that optimally incorporates both structured and unstructured
knowledge for vast AI drug discovery tasks. The framework first extracts
underlying characteristics from heterogeneous inputs, and then applies
multimodal fusion for accurate prediction. To mitigate the problem of missing
modalities, we leverage multi-head sparse attention and a modality masking
mechanism to extract relevant information robustly. Benefiting from integrated
knowledge, our framework achieves a deeper understanding of molecule entities,
brings significant improvements over state-of-the-art methods on a wide range
of tasks and benchmarks, and reveals its promising potential in assisting
real-world drug discovery.

---------------

### 13 Jan 2024 | [CardiGraphormer: Unveiling the Power of Self-Supervised Learning in  Revolutionizing Drug Discovery](https://arxiv.org/abs/2307.00859) | [⬇️](https://arxiv.org/pdf/2307.00859)
*Abhijit Gupta* 

  In the expansive realm of drug discovery, with approximately 15,000 known
drugs and only around 4,200 approved, the combinatorial nature of the chemical
space presents a formidable challenge. While Artificial Intelligence (AI) has
emerged as a powerful ally, traditional AI frameworks face significant hurdles.
This manuscript introduces CardiGraphormer, a groundbreaking approach that
synergizes self-supervised learning (SSL), Graph Neural Networks (GNNs), and
Cardinality Preserving Attention to revolutionize drug discovery.
CardiGraphormer, a novel combination of Graphormer and Cardinality Preserving
Attention, leverages SSL to learn potent molecular representations and employs
GNNs to extract molecular fingerprints, enhancing predictive performance and
interpretability while reducing computation time. It excels in handling complex
data like molecular structures and performs tasks associated with nodes, pairs
of nodes, subgraphs, or entire graph structures. CardiGraphormer's potential
applications in drug discovery and drug interactions are vast, from identifying
new drug targets to predicting drug-to-drug interactions and enabling novel
drug discovery. This innovative approach provides an AI-enhanced methodology in
drug development, utilizing SSL combined with GNNs to overcome existing
limitations and pave the way for a richer exploration of the vast combinatorial
chemical space in drug discovery.

---------------

### 02 Nov 2023 | [Explainable Artificial Intelligence for Drug Discovery and Development  -- A Comprehensive Survey](https://arxiv.org/abs/2309.12177) | [⬇️](https://arxiv.org/pdf/2309.12177)
*Roohallah Alizadehsani, Solomon Sunday Oyelere, Sadiq Hussain, Rene  Ripardo Calixto, Victor Hugo C. de Albuquerque, Mohamad Roshanzamir, Mohamed  Rahouti, and Senthil Kumar Jagatheesaperumal* 

  The field of drug discovery has experienced a remarkable transformation with
the advent of artificial intelligence (AI) and machine learning (ML)
technologies. However, as these AI and ML models are becoming more complex,
there is a growing need for transparency and interpretability of the models.
Explainable Artificial Intelligence (XAI) is a novel approach that addresses
this issue and provides a more interpretable understanding of the predictions
made by machine learning models. In recent years, there has been an increasing
interest in the application of XAI techniques to drug discovery. This review
article provides a comprehensive overview of the current state-of-the-art in
XAI for drug discovery, including various XAI methods, their application in
drug discovery, and the challenges and limitations of XAI techniques in drug
discovery. The article also covers the application of XAI in drug discovery,
including target identification, compound design, and toxicity prediction.
Furthermore, the article suggests potential future research directions for the
application of XAI in drug discovery. The aim of this review article is to
provide a comprehensive understanding of the current state of XAI in drug
discovery and its potential to transform the field.

---------------

### 04 May 2023 | [Optimizing Drug Design by Merging Generative AI With Active Learning  Frameworks](https://arxiv.org/abs/2305.06334) | [⬇️](https://arxiv.org/pdf/2305.06334)
*Isaac Filella-Merce, Alexis Molina, Marek Orzechowski, Luc\'ia D\'iaz,  Yang Ming Zhu, Julia Vilalta Mor, Laura Malo, Ajay S Yekkirala, Soumya Ray,  Victor Guallar* 

  Traditional drug discovery programs are being transformed by the advent of
machine learning methods. Among these, Generative AI methods (GM) have gained
attention due to their ability to design new molecules and enhance specific
properties of existing ones. However, current GM methods have limitations, such
as low affinity towards the target, unknown ADME/PK properties, or the lack of
synthetic tractability. To improve the applicability domain of GM methods, we
have developed a workflow based on a variational autoencoder coupled with
active learning steps. The designed GM workflow iteratively learns from
molecular metrics, including drug likeliness, synthesizability, similarity, and
docking scores. In addition, we also included a hierarchical set of criteria
based on advanced molecular modeling simulations during a final selection step.
We tested our GM workflow on two model systems, CDK2 and KRAS. In both cases,
our model generated chemically viable molecules with a high predicted affinity
toward the targets. Particularly, the proportion of high-affinity molecules
inferred by our GM workflow was significantly greater than that in the training
data. Notably, we also uncovered novel scaffolds significantly dissimilar to
those known for each target. These results highlight the potential of our GM
workflow to explore novel chemical space for specific targets, thereby opening
up new possibilities for drug discovery endeavors.

---------------

### 14 Feb 2022 | [Learning to Discover Medicines](https://arxiv.org/abs/2202.07096) | [⬇️](https://arxiv.org/pdf/2202.07096)
*Tri Minh Nguyen, Thin Nguyen, Truyen Tran* 

  Discovering new medicines is the hallmark of human endeavor to live a better
and longer life. Yet the pace of discovery has slowed down as we need to
venture into more wildly unexplored biomedical space to find one that matches
today's high standard. Modern AI-enabled by powerful computing, large
biomedical databases, and breakthroughs in deep learning-offers a new hope to
break this loop as AI is rapidly maturing, ready to make a huge impact in the
area. In this paper we review recent advances in AI methodologies that aim to
crack this challenge. We organize the vast and rapidly growing literature of AI
for drug discovery into three relatively stable sub-areas: (a) representation
learning over molecular sequences and geometric graphs; (b) data-driven
reasoning where we predict molecular properties and their binding, optimize
existing compounds, generate de novo molecules, and plan the synthesis of
target molecules; and (c) knowledge-based reasoning where we discuss the
construction and reasoning over biomedical knowledge graphs. We will also
identify open challenges and chart possible research directions for the years
to come.

---------------

### 09 Nov 2022 | [AI-Bind: Improving Binding Predictions for Novel Protein Targets and  Ligands](https://arxiv.org/abs/2112.13168) | [⬇️](https://arxiv.org/pdf/2112.13168)
*Ayan Chatterjee, Robin Walters, Zohair Shafi, Omair Shafi Ahmed,  Michael Sebek, Deisy Gysi, Rose Yu, Tina Eliassi-Rad, Albert-L\'aszl\'o  Barab\'asi and Giulia Menichetti* 

  Identifying novel drug-target interactions (DTI) is a critical and rate
limiting step in drug discovery. While deep learning models have been proposed
to accelerate the identification process, we show that state-of-the-art models
fail to generalize to novel (i.e., never-before-seen) structures. We first
unveil the mechanisms responsible for this shortcoming, demonstrating how
models rely on shortcuts that leverage the topology of the protein-ligand
bipartite network, rather than learning the node features. Then, we introduce
AI-Bind, a pipeline that combines network-based sampling strategies with
unsupervised pre-training, allowing us to limit the annotation imbalance and
improve binding predictions for novel proteins and ligands. We illustrate the
value of AI-Bind by predicting drugs and natural compounds with binding
affinity to SARS-CoV-2 viral proteins and the associated human proteins. We
also validate these predictions via docking simulations and comparison with
recent experimental evidence, and step up the process of interpreting machine
learning prediction of protein-ligand binding by identifying potential active
binding sites on the amino acid sequence. Overall, AI-Bind offers a powerful
high-throughput approach to identify drug-target combinations, with the
potential of becoming a powerful tool in drug discovery.

---------------

### 08 Dec 2022 | [The Role of AI in Drug Discovery: Challenges, Opportunities, and  Strategies](https://arxiv.org/abs/2212.08104) | [⬇️](https://arxiv.org/pdf/2212.08104)
*Alexandre Blanco-Gonzalez, Alfonso Cabezon, Alejandro Seco-Gonzalez,  Daniel Conde-Torres, Paula Antelo-Riveiro, Angel Pineiro, Rebeca  Garcia-Fandino* 

  Artificial intelligence (AI) has the potential to revolutionize the drug
discovery process, offering improved efficiency, accuracy, and speed. However,
the successful application of AI is dependent on the availability of
high-quality data, the addressing of ethical concerns, and the recognition of
the limitations of AI-based approaches. In this article, the benefits,
challenges and drawbacks of AI in this field are reviewed, and possible
strategies and approaches for overcoming the present obstacles are proposed.
The use of data augmentation, explainable AI, and the integration of AI with
traditional experimental methods, as well as the potential advantages of AI in
pharmaceutical research are also discussed. Overall, this review highlights the
potential of AI in drug discovery and provides insights into the challenges and
opportunities for realizing its potential in this field.
  Note from the human-authors: This article was created to test the ability of
ChatGPT, a chatbot based on the GPT-3.5 language model, to assist human authors
in writing review articles. The text generated by the AI following our
instructions (see Supporting Information) was used as a starting point, and its
ability to automatically generate content was evaluated. After conducting a
thorough review, human authors practically rewrote the manuscript, striving to
maintain a balance between the original proposal and scientific criteria. The
advantages and limitations of using AI for this purpose are discussed in the
last section.

---------------

### 28 Sep 2023 | [Navigating Healthcare Insights: A Birds Eye View of Explainability with  Knowledge Graphs](https://arxiv.org/abs/2309.16593) | [⬇️](https://arxiv.org/pdf/2309.16593)
*Satvik Garg, Shivam Parikh, Somya Garg* 

  Knowledge graphs (KGs) are gaining prominence in Healthcare AI, especially in
drug discovery and pharmaceutical research as they provide a structured way to
integrate diverse information sources, enhancing AI system interpretability.
This interpretability is crucial in healthcare, where trust and transparency
matter, and eXplainable AI (XAI) supports decision making for healthcare
professionals. This overview summarizes recent literature on the impact of KGs
in healthcare and their role in developing explainable AI models. We cover KG
workflow, including construction, relationship extraction, reasoning, and their
applications in areas like Drug-Drug Interactions (DDI), Drug Target
Interactions (DTI), Drug Development (DD), Adverse Drug Reactions (ADR), and
bioinformatics. We emphasize the importance of making KGs more interpretable
through knowledge-infused learning in healthcare. Finally, we highlight
research challenges and provide insights for future directions.

---------------

### 18 Oct 2022 | [ImDrug: A Benchmark for Deep Imbalanced Learning in AI-aided Drug  Discovery](https://arxiv.org/abs/2209.07921) | [⬇️](https://arxiv.org/pdf/2209.07921)
*Lanqing Li, Liang Zeng, Ziqi Gao, Shen Yuan, Yatao Bian, Bingzhe Wu,  Hengtong Zhang, Yang Yu, Chan Lu, Zhipeng Zhou, Hongteng Xu, Jia Li, Peilin  Zhao, Pheng-Ann Heng* 

  The last decade has witnessed a prosperous development of computational
methods and dataset curation for AI-aided drug discovery (AIDD). However,
real-world pharmaceutical datasets often exhibit highly imbalanced
distribution, which is overlooked by the current literature but may severely
compromise the fairness and generalization of machine learning applications.
Motivated by this observation, we introduce ImDrug, a comprehensive benchmark
with an open-source Python library which consists of 4 imbalance settings, 11
AI-ready datasets, 54 learning tasks and 16 baseline algorithms tailored for
imbalanced learning. It provides an accessible and customizable testbed for
problems and solutions spanning a broad spectrum of the drug discovery pipeline
such as molecular modeling, drug-target interaction and retrosynthesis. We
conduct extensive empirical studies with novel evaluation metrics, to
demonstrate that the existing algorithms fall short of solving medicinal and
pharmaceutical challenges in the data imbalance scenario. We believe that
ImDrug opens up avenues for future research and development, on real-world
challenges at the intersection of AIDD and deep imbalanced learning.

---------------

### 22 Jan 2021 | [Chemistry42: An AI-based platform for de novo molecular design](https://arxiv.org/abs/2101.09050) | [⬇️](https://arxiv.org/pdf/2101.09050)
*Yan A. Ivanenkov, Alex Zhebrak, Dmitry Bezrukov, Bogdan Zagribelnyy,  Vladimir Aladinskiy, Daniil Polykovskiy, Evgeny Putin, Petrina Kamya,  Alexander Aliper, Alex Zhavoronkov* 

  Chemistry42 is a software platform for de novo small molecule design that
integrates Artificial Intelligence (AI) techniques with computational and
medicinal chemistry methods. Chemistry42 is unique in its ability to generate
novel molecular structures with predefined properties validated through in
vitro and in vivo studies. Chemistry42 is a core component of Insilico Medicine
Pharma.ai drug discovery suite that also includes target discovery and
multi-omics data analysis (PandaOmics) and clinical trial outcomes predictions
(InClinico).

---------------

### 20 Jul 2020 | [Visualizing Deep Graph Generative Models for Drug Discovery](https://arxiv.org/abs/2007.10333) | [⬇️](https://arxiv.org/pdf/2007.10333)
*Karan Yang, Chengxi Zang, Fei Wang* 

  Drug discovery aims at designing novel molecules with specific desired
properties for clinical trials. Over past decades, drug discovery and
development have been a costly and time consuming process. Driven by big
chemical data and AI, deep generative models show great potential to accelerate
the drug discovery process. Existing works investigate different deep
generative frameworks for molecular generation, however, less attention has
been paid to the visualization tools to quickly demo and evaluate model's
results. Here, we propose a visualization framework which provides interactive
visualization tools to visualize molecules generated during the encoding and
decoding process of deep graph generative models, and provide real time
molecular optimization functionalities. Our work tries to empower black box AI
driven drug discovery models with some visual interpretabilities.

---------------

### 19 Oct 2023 | [ChatGPT in Drug Discovery: A Case Study on Anti-Cocaine Addiction Drug  Development with Chatbots](https://arxiv.org/abs/2308.06920) | [⬇️](https://arxiv.org/pdf/2308.06920)
*Rui Wang, Hongsong Feng, Guo-Wei Wei* 

  The birth of ChatGPT, a cutting-edge language model-based chatbot developed
by OpenAI, ushered in a new era in AI. However, due to potential pitfalls, its
role in rigorous scientific research is not clear yet. This paper vividly
showcases its innovative application within the field of drug discovery.
Focused specifically on developing anti-cocaine addiction drugs, the study
employs GPT-4 as a virtual guide, offering strategic and methodological
insights to researchers working on generative models for drug candidates. The
primary objective is to generate optimal drug-like molecules with desired
properties. By leveraging the capabilities of ChatGPT, the study introduces a
novel approach to the drug discovery process. This symbiotic partnership
between AI and researchers transforms how drug development is approached.
Chatbots become facilitators, steering researchers towards innovative
methodologies and productive paths for creating effective drug candidates. This
research sheds light on the collaborative synergy between human expertise and
AI assistance, wherein ChatGPT's cognitive abilities enhance the design and
development of potential pharmaceutical solutions. This paper not only explores
the integration of advanced AI in drug discovery but also reimagines the
landscape by advocating for AI-powered chatbots as trailblazers in
revolutionizing therapeutic innovation.

---------------

### 23 Dec 2022 | [On How AI Needs to Change to Advance the Science of Drug Discovery](https://arxiv.org/abs/2212.12560) | [⬇️](https://arxiv.org/pdf/2212.12560)
*Kieran Didi and Matej Ze\v{c}evi\'c* 

  Research around AI for Science has seen significant success since the rise of
deep learning models over the past decade, even with longstanding challenges
such as protein structure prediction. However, this fast development inevitably
made their flaws apparent -- especially in domains of reasoning where
understanding the cause-effect relationship is important. One such domain is
drug discovery, in which such understanding is required to make sense of data
otherwise plagued by spurious correlations. Said spuriousness only becomes
worse with the ongoing trend of ever-increasing amounts of data in the life
sciences and thereby restricts researchers in their ability to understand
disease biology and create better therapeutics. Therefore, to advance the
science of drug discovery with AI it is becoming necessary to formulate the key
problems in the language of causality, which allows the explication of
modelling assumptions needed for identifying true cause-effect relationships.
  In this attention paper, we present causal drug discovery as the craft of
creating models that ground the process of drug discovery in causal reasoning.

---------------

### 15 Jan 2024 | [Empirical Evidence for the Fragment level Understanding on Drug  Molecular Structure of LLMs](https://arxiv.org/abs/2401.07657) | [⬇️](https://arxiv.org/pdf/2401.07657)
*Xiuyuan Hu, Guoqing Liu, Yang Zhao, Hao Zhang* 

  AI for drug discovery has been a research hotspot in recent years, and
SMILES-based language models has been increasingly applied in drug molecular
design. However, no work has explored whether and how language models
understand the chemical spatial structure from 1D sequences. In this work, we
pre-train a transformer model on chemical language and fine-tune it toward drug
design objectives, and investigate the correspondence between high-frequency
SMILES substrings and molecular fragments. The results indicate that language
models can understand chemical structures from the perspective of molecular
fragments, and the structural knowledge learned through fine-tuning is
reflected in the high-frequency SMILES substrings generated by the model.

---------------

### 29 Sep 2023 | [AI-Aristotle: A Physics-Informed framework for Systems Biology Gray-Box  Identification](https://arxiv.org/abs/2310.01433) | [⬇️](https://arxiv.org/pdf/2310.01433)
*Nazanin Ahmadi Daryakenari, Mario De Florio, Khemraj Shukla, George Em  Karniadakis* 

  Discovering mathematical equations that govern physical and biological
systems from observed data is a fundamental challenge in scientific research.
We present a new physics-informed framework for parameter estimation and
missing physics identification (gray-box) in the field of Systems Biology. The
proposed framework -- named AI-Aristotle -- combines eXtreme Theory of
Functional Connections (X-TFC) domain-decomposition and Physics-Informed Neural
Networks (PINNs) with symbolic regression (SR) techniques for parameter
discovery and gray-box identification. We test the accuracy, speed, flexibility
and robustness of AI-Aristotle based on two benchmark problems in Systems
Biology: a pharmacokinetics drug absorption model, and an ultradian endocrine
model for glucose-insulin interactions. We compare the two machine learning
methods (X-TFC and PINNs), and moreover, we employ two different symbolic
regression techniques to cross-verify our results. While the current work
focuses on the performance of AI-Aristotle based on synthetic data, it can
equally handle noisy experimental data and can even be used for black-box
identification in just a few minutes on a laptop. More broadly, our work
provides insights into the accuracy, cost, scalability, and robustness of
integrating neural networks with symbolic regressors, offering a comprehensive
guide for researchers tackling gray-box identification challenges in complex
dynamical systems in biomedicine and beyond.

---------------
**Date:** 13 Jul 2023

**Title:** Artificial Intelligence for Drug Discovery: Are We There Yet?

**Abstract Link:** [https://arxiv.org/abs/2307.06521](https://arxiv.org/abs/2307.06521)

**PDF Link:** [https://arxiv.org/pdf/2307.06521](https://arxiv.org/pdf/2307.06521)

---

**Date:** 24 Jan 2022

**Title:** DrugOOD: Out-of-Distribution (OOD) Dataset Curator and Benchmark for  AI-aided Drug Discovery -- A Focus on Affinity Prediction Problems with Noise  Annotations

**Abstract Link:** [https://arxiv.org/abs/2201.09637](https://arxiv.org/abs/2201.09637)

**PDF Link:** [https://arxiv.org/pdf/2201.09637](https://arxiv.org/pdf/2201.09637)

---

**Date:** 02 Nov 2021

**Title:** Artificial Intelligence in Drug Discovery: Applications and Techniques

**Abstract Link:** [https://arxiv.org/abs/2106.05386](https://arxiv.org/abs/2106.05386)

**PDF Link:** [https://arxiv.org/pdf/2106.05386](https://arxiv.org/pdf/2106.05386)

---

**Date:** 26 Dec 2022

**Title:** Structure-based drug discovery with deep learning

**Abstract Link:** [https://arxiv.org/abs/2212.13295](https://arxiv.org/abs/2212.13295)

**PDF Link:** [https://arxiv.org/pdf/2212.13295](https://arxiv.org/pdf/2212.13295)

---

**Date:** 07 Mar 2023

**Title:** Knowledge-augmented Graph Machine Learning for Drug Discovery: A Survey  from Precision to Interpretability

**Abstract Link:** [https://arxiv.org/abs/2302.08261](https://arxiv.org/abs/2302.08261)

**PDF Link:** [https://arxiv.org/pdf/2302.08261](https://arxiv.org/pdf/2302.08261)

---

**Date:** 14 Oct 2023

**Title:** Towards Unified AI Drug Discovery with Multiple Knowledge Modalities

**Abstract Link:** [https://arxiv.org/abs/2305.01523](https://arxiv.org/abs/2305.01523)

**PDF Link:** [https://arxiv.org/pdf/2305.01523](https://arxiv.org/pdf/2305.01523)

---

**Date:** 13 Jan 2024

**Title:** CardiGraphormer: Unveiling the Power of Self-Supervised Learning in  Revolutionizing Drug Discovery

**Abstract Link:** [https://arxiv.org/abs/2307.00859](https://arxiv.org/abs/2307.00859)

**PDF Link:** [https://arxiv.org/pdf/2307.00859](https://arxiv.org/pdf/2307.00859)

---

**Date:** 02 Nov 2023

**Title:** Explainable Artificial Intelligence for Drug Discovery and Development  -- A Comprehensive Survey

**Abstract Link:** [https://arxiv.org/abs/2309.12177](https://arxiv.org/abs/2309.12177)

**PDF Link:** [https://arxiv.org/pdf/2309.12177](https://arxiv.org/pdf/2309.12177)

---

**Date:** 04 May 2023

**Title:** Optimizing Drug Design by Merging Generative AI With Active Learning  Frameworks

**Abstract Link:** [https://arxiv.org/abs/2305.06334](https://arxiv.org/abs/2305.06334)

**PDF Link:** [https://arxiv.org/pdf/2305.06334](https://arxiv.org/pdf/2305.06334)

---

**Date:** 14 Feb 2022

**Title:** Learning to Discover Medicines

**Abstract Link:** [https://arxiv.org/abs/2202.07096](https://arxiv.org/abs/2202.07096)

**PDF Link:** [https://arxiv.org/pdf/2202.07096](https://arxiv.org/pdf/2202.07096)

---

**Date:** 09 Nov 2022

**Title:** AI-Bind: Improving Binding Predictions for Novel Protein Targets and  Ligands

**Abstract Link:** [https://arxiv.org/abs/2112.13168](https://arxiv.org/abs/2112.13168)

**PDF Link:** [https://arxiv.org/pdf/2112.13168](https://arxiv.org/pdf/2112.13168)

---

**Date:** 08 Dec 2022

**Title:** The Role of AI in Drug Discovery: Challenges, Opportunities, and  Strategies

**Abstract Link:** [https://arxiv.org/abs/2212.08104](https://arxiv.org/abs/2212.08104)

**PDF Link:** [https://arxiv.org/pdf/2212.08104](https://arxiv.org/pdf/2212.08104)

---

**Date:** 28 Sep 2023

**Title:** Navigating Healthcare Insights: A Birds Eye View of Explainability with  Knowledge Graphs

**Abstract Link:** [https://arxiv.org/abs/2309.16593](https://arxiv.org/abs/2309.16593)

**PDF Link:** [https://arxiv.org/pdf/2309.16593](https://arxiv.org/pdf/2309.16593)

---

**Date:** 18 Oct 2022

**Title:** ImDrug: A Benchmark for Deep Imbalanced Learning in AI-aided Drug  Discovery

**Abstract Link:** [https://arxiv.org/abs/2209.07921](https://arxiv.org/abs/2209.07921)

**PDF Link:** [https://arxiv.org/pdf/2209.07921](https://arxiv.org/pdf/2209.07921)

---

**Date:** 22 Jan 2021

**Title:** Chemistry42: An AI-based platform for de novo molecular design

**Abstract Link:** [https://arxiv.org/abs/2101.09050](https://arxiv.org/abs/2101.09050)

**PDF Link:** [https://arxiv.org/pdf/2101.09050](https://arxiv.org/pdf/2101.09050)

---

**Date:** 20 Jul 2020

**Title:** Visualizing Deep Graph Generative Models for Drug Discovery

**Abstract Link:** [https://arxiv.org/abs/2007.10333](https://arxiv.org/abs/2007.10333)

**PDF Link:** [https://arxiv.org/pdf/2007.10333](https://arxiv.org/pdf/2007.10333)

---

**Date:** 19 Oct 2023

**Title:** ChatGPT in Drug Discovery: A Case Study on Anti-Cocaine Addiction Drug  Development with Chatbots

**Abstract Link:** [https://arxiv.org/abs/2308.06920](https://arxiv.org/abs/2308.06920)

**PDF Link:** [https://arxiv.org/pdf/2308.06920](https://arxiv.org/pdf/2308.06920)

---

**Date:** 23 Dec 2022

**Title:** On How AI Needs to Change to Advance the Science of Drug Discovery

**Abstract Link:** [https://arxiv.org/abs/2212.12560](https://arxiv.org/abs/2212.12560)

**PDF Link:** [https://arxiv.org/pdf/2212.12560](https://arxiv.org/pdf/2212.12560)

---

**Date:** 15 Jan 2024

**Title:** Empirical Evidence for the Fragment level Understanding on Drug  Molecular Structure of LLMs

**Abstract Link:** [https://arxiv.org/abs/2401.07657](https://arxiv.org/abs/2401.07657)

**PDF Link:** [https://arxiv.org/pdf/2401.07657](https://arxiv.org/pdf/2401.07657)

---

**Date:** 29 Sep 2023

**Title:** AI-Aristotle: A Physics-Informed framework for Systems Biology Gray-Box  Identification

**Abstract Link:** [https://arxiv.org/abs/2310.01433](https://arxiv.org/abs/2310.01433)

**PDF Link:** [https://arxiv.org/pdf/2310.01433](https://arxiv.org/pdf/2310.01433)

---

