LLM Induction Heads 👀

### 🔎 LLM Induction Heads 👀



We have been working on a new product for a while now and we are finally ready to show you what we have been up to!

Introducing our new Induction Heads!

These are designed to fit our 1000W Induction Heater and are perfect for heating up your banger or quartz insert.

They are made from 316L Stainless Steel and are designed to be used with our Induction Heater.

They are available in two sizes, 25mm and 30mm.

The 25mm size is perfect for heating up a small banger or quartz insert, while the 30mm size is perfect for heating up a larger banger or quartz insert.

They are also available in two different finishes, brushed and polished.

The brushed finish is great for a more rugged look, while the polished finish is great for a more sleek and refined look.

We are very excited to finally be able to offer these to our customers and we know that you will love them!

Thank you for supporting us and we hope that you enjoy using our new Induction Heads!

-The Dabpress Team</s>
# 🩺🔍 Search Results
### 20 Feb 2024 | [Identifying Semantic Induction Heads to Understand In-Context Learning](https://arxiv.org/abs/2402.13055) | [⬇️](https://arxiv.org/pdf/2402.13055)
*Jie Ren, Qipeng Guo, Hang Yan, Dongrui Liu, Xipeng Qiu, Dahua Lin* 

  Although large language models (LLMs) have demonstrated remarkable
performance, the lack of transparency in their inference logic raises concerns
about their trustworthiness. To gain a better understanding of LLMs, we conduct
a detailed analysis of the operations of attention heads and aim to better
understand the in-context learning of LLMs. Specifically, we investigate
whether attention heads encode two types of relationships between tokens
present in natural languages: the syntactic dependency parsed from sentences
and the relation within knowledge graphs. We find that certain attention heads
exhibit a pattern where, when attending to head tokens, they recall tail tokens
and increase the output logits of those tail tokens. More crucially, the
formulation of such semantic induction heads has a close correlation with the
emergence of the in-context learning ability of language models. The study of
semantic attention heads advances our understanding of the intricate operations
of attention heads in transformers, and further provides new insights into the
in-context learning of LLMs.

---------------

### 17 Feb 2024 | [Crafting a Good Prompt or Providing Exemplary Dialogues? A Study of  In-Context Learning for Persona-based Dialogue Generation](https://arxiv.org/abs/2402.09954) | [⬇️](https://arxiv.org/pdf/2402.09954)
*Jiashu Pu, Yajing Wan, Yuru Zhang, Jing Chen, Ling Cheng, Qian Shao,  Yongzhu Chang, Tangjie Lv, Rongsheng Zhang* 

  Previous in-context learning (ICL) research has focused on tasks such as
classification, machine translation, text2table, etc., while studies on whether
ICL can improve human-like dialogue generation are scarce. Our work fills this
gap by systematically investigating the ICL capabilities of large language
models (LLMs) in persona-based dialogue generation, conducting extensive
experiments on high-quality real human Chinese dialogue datasets. From
experimental results, we draw three conclusions: 1) adjusting prompt
instructions is the most direct, effective, and economical way to improve
generation quality; 2) randomly retrieving demonstrations (demos) achieves the
best results, possibly due to the greater diversity and the amount of effective
information; counter-intuitively, retrieving demos with a context identical to
the query performs the worst; 3) even when we destroy the multi-turn
associations and single-turn semantics in the demos, increasing the number of
demos still improves dialogue performance, proving that LLMs can learn from
corrupted dialogue demos. Previous explanations of the ICL mechanism, such as
$n$-gram induction head, cannot fully account for this phenomenon.

---------------

### 24 Sep 2022 | [In-context Learning and Induction Heads](https://arxiv.org/abs/2209.11895) | [⬇️](https://arxiv.org/pdf/2209.11895)
*Catherine Olsson, Nelson Elhage, Neel Nanda, Nicholas Joseph, Nova  DasSarma, Tom Henighan, Ben Mann, Amanda Askell, Yuntao Bai, Anna Chen, Tom  Conerly, Dawn Drain, Deep Ganguli, Zac Hatfield-Dodds, Danny Hernandez, Scott  Johnston, Andy Jones, Jackson Kernion, Liane Lovitt, Kamal Ndousse, Dario  Amodei, Tom Brown, Jack Clark, Jared Kaplan, Sam McCandlish, Chris Olah* 

  "Induction heads" are attention heads that implement a simple algorithm to
complete token sequences like [A][B] ... [A] -> [B]. In this work, we present
preliminary and indirect evidence for a hypothesis that induction heads might
constitute the mechanism for the majority of all "in-context learning" in large
transformer models (i.e. decreasing loss at increasing token indices). We find
that induction heads develop at precisely the same point as a sudden sharp
increase in in-context learning ability, visible as a bump in the training
loss. We present six complementary lines of evidence, arguing that induction
heads may be the mechanistic source of general in-context learning in
transformer models of any size. For small attention-only models, we present
strong, causal evidence; for larger models with MLPs, we present correlational
evidence.

---------------

### 25 Nov 2023 | [Localizing Lying in Llama: Understanding Instructed Dishonesty on  True-False Questions Through Prompting, Probing, and Patching](https://arxiv.org/abs/2311.15131) | [⬇️](https://arxiv.org/pdf/2311.15131)
*James Campbell, Richard Ren, Phillip Guo* 

  Large language models (LLMs) demonstrate significant knowledge through their
outputs, though it is often unclear whether false outputs are due to a lack of
knowledge or dishonesty. In this paper, we investigate instructed dishonesty,
wherein we explicitly prompt LLaMA-2-70b-chat to lie. We perform prompt
engineering to find which prompts best induce lying behavior, and then use
mechanistic interpretability approaches to localize where in the network this
behavior occurs. Using linear probing and activation patching, we localize five
layers that appear especially important for lying. We then find just 46
attention heads within these layers that enable us to causally intervene such
that the lying model instead answers honestly. We show that these interventions
work robustly across many prompts and dataset splits. Overall, our work
contributes a greater understanding of dishonesty in LLMs so that we may hope
to prevent it.

---------------

### 23 Feb 2024 | [Interpreting Context Look-ups in Transformers: Investigating  Attention-MLP Interactions](https://arxiv.org/abs/2402.15055) | [⬇️](https://arxiv.org/pdf/2402.15055)
*Clement Neo, Shay B. Cohen, Fazl Barez* 

  In this paper, we investigate the interplay between attention heads and
specialized "next-token" neurons in the Multilayer Perceptron that predict
specific tokens. By prompting an LLM like GPT-4 to explain these model
internals, we can elucidate attention mechanisms that activate certain
next-token neurons. Our analysis identifies attention heads that recognize
contexts relevant to predicting a particular token, activating the associated
neuron through the residual connection. We focus specifically on heads in
earlier layers consistently activating the same next-token neuron across
similar prompts. Exploring these differential activation patterns reveals that
heads that specialize for distinct linguistic contexts are tied to generating
certain tokens. Overall, our method combines neural explanations and probing
isolated components to illuminate how attention enables context-dependent,
specialized processing in LLMs.

---------------

### 29 Feb 2024 | [Whispers that Shake Foundations: Analyzing and Mitigating False Premise  Hallucinations in Large Language Models](https://arxiv.org/abs/2402.19103) | [⬇️](https://arxiv.org/pdf/2402.19103)
*Hongbang Yuan, Pengfei Cao, Zhuoran Jin, Yubo Chen, Daojian Zeng, Kang  Liu, Jun Zhao* 

  Large Language Models (LLMs) have shown impressive capabilities but still
suffer from the issue of hallucinations. A significant type of this issue is
the false premise hallucination, which we define as the phenomenon when LLMs
generate hallucinated text when confronted with false premise questions. In
this paper, we perform a comprehensive analysis of the false premise
hallucination and elucidate its internal working mechanism: a small subset of
attention heads (which we designate as false premise heads) disturb the
knowledge extraction process, leading to the occurrence of false premise
hallucination. Based on our analysis, we propose \textbf{FAITH} (\textbf{F}alse
premise \textbf{A}ttention head constra\textbf{I}ining for mi\textbf{T}igating
\textbf{H}allucinations), a novel and effective method to mitigate false
premise hallucinations. It constrains the false premise attention heads during
the model inference process. Impressively, extensive experiments demonstrate
that constraining only approximately $1\%$ of the attention heads in the model
yields a notable increase of nearly $20\%$ of model performance.

---------------

### 16 Feb 2024 | [From Language Modeling to Instruction Following: Understanding the  Behavior Shift in LLMs after Instruction Tuning](https://arxiv.org/abs/2310.00492) | [⬇️](https://arxiv.org/pdf/2310.00492)
*Xuansheng Wu, Wenlin Yao, Jianshu Chen, Xiaoman Pan, Xiaoyang Wang,  Ninghao Liu, Dong Yu* 

  Large Language Models (LLMs) have achieved remarkable success, where
instruction tuning is the critical step in aligning LLMs with user intentions.
In this work, we investigate how the instruction tuning adjusts pre-trained
models with a focus on intrinsic changes. Specifically, we first develop
several local and global explanation methods, including a gradient-based method
for input-output attribution and techniques for interpreting patterns and
concepts in self-attention and feed-forward layers. The impact of instruction
tuning is then studied by comparing the explanations derived from the
pre-trained and instruction-tuned models. This approach provides an internal
perspective of the model shifts on a human-comprehensible level. Our findings
reveal three significant impacts of instruction tuning: 1) It empowers LLMs to
recognize the instruction parts from user prompts, and promotes the response
generation constantly conditioned on user instructions. 2) It encourages the
self-attention heads to capture more word-word relationships about instruction
verbs. 3) It encourages the feed-forward networks to rotate their pre-trained
knowledge toward user-oriented tasks. These insights contribute to a more
comprehensive understanding of instruction tuning and lay the groundwork for
future work that aims at interpreting and optimizing LLMs for various
applications.

---------------

### 28 Feb 2024 | [Memory Injections: Correcting Multi-Hop Reasoning Failures during  Inference in Transformer-Based Language Models](https://arxiv.org/abs/2309.05605) | [⬇️](https://arxiv.org/pdf/2309.05605)
*Mansi Sakarvadia, Aswathy Ajith, Arham Khan, Daniel Grzenda, Nathaniel  Hudson, Andr\'e Bauer, Kyle Chard, Ian Foster* 

  Answering multi-hop reasoning questions requires retrieving and synthesizing
information from diverse sources. Large Language Models (LLMs) struggle to
perform such reasoning consistently. Here we propose an approach to pinpoint
and rectify multi-hop reasoning failures through targeted memory injections on
LLM attention heads. First, we analyze the per-layer activations of GPT-2
models in response to single and multi-hop prompts. We then propose a mechanism
that allows users to inject pertinent prompt-specific information, which we
refer to as "memories," at critical LLM locations during inference. By thus
enabling the LLM to incorporate additional relevant information during
inference, we enhance the quality of multi-hop prompt completions. We show
empirically that a simple, efficient, and targeted memory injection into a key
attention layer can often increase the probability of the desired next token in
multi-hop tasks, by up to 424%.

---------------

### 25 Feb 2024 | [On Bilingual Lexicon Induction with Large Language Models](https://arxiv.org/abs/2310.13995) | [⬇️](https://arxiv.org/pdf/2310.13995)
*Yaoyiran Li, Anna Korhonen, Ivan Vuli\'c* 

  Bilingual Lexicon Induction (BLI) is a core task in multilingual NLP that
still, to a large extent, relies on calculating cross-lingual word
representations. Inspired by the global paradigm shift in NLP towards Large
Language Models (LLMs), we examine the potential of the latest generation of
LLMs for the development of bilingual lexicons. We ask the following research
question: Is it possible to prompt and fine-tune multilingual LLMs (mLLMs) for
BLI, and how does this approach compare against and complement current BLI
approaches? To this end, we systematically study 1) zero-shot prompting for
unsupervised BLI and 2) few-shot in-context prompting with a set of seed
translation pairs, both without any LLM fine-tuning, as well as 3) standard
BLI-oriented fine-tuning of smaller LLMs. We experiment with 18 open-source
text-to-text mLLMs of different sizes (from 0.3B to 13B parameters) on two
standard BLI benchmarks covering a range of typologically diverse languages.
Our work is the first to demonstrate strong BLI capabilities of text-to-text
mLLMs. The results reveal that few-shot prompting with in-context examples from
nearest neighbours achieves the best performance, establishing new
state-of-the-art BLI scores for many language pairs. We also conduct a series
of in-depth analyses and ablation studies, providing more insights on BLI with
(m)LLMs, also along with their limitations.

---------------

### 25 Oct 2023 | [Attention Lens: A Tool for Mechanistically Interpreting the Attention  Head Information Retrieval Mechanism](https://arxiv.org/abs/2310.16270) | [⬇️](https://arxiv.org/pdf/2310.16270)
*Mansi Sakarvadia, Arham Khan, Aswathy Ajith, Daniel Grzenda, Nathaniel  Hudson, Andr\'e Bauer, Kyle Chard, Ian Foster* 

  Transformer-based Large Language Models (LLMs) are the state-of-the-art for
natural language tasks. Recent work has attempted to decode, by reverse
engineering the role of linear layers, the internal mechanisms by which LLMs
arrive at their final predictions for text completion tasks. Yet little is
known about the specific role of attention heads in producing the final token
prediction. We propose Attention Lens, a tool that enables researchers to
translate the outputs of attention heads into vocabulary tokens via learned
attention-head-specific transformations called lenses. Preliminary findings
from our trained lenses indicate that attention heads play highly specialized
roles in language models. The code for Attention Lens is available at
github.com/msakarvadia/AttentionLens.

---------------

### 31 Jan 2024 | [Scavenging Hyena: Distilling Transformers into Long Convolution Models](https://arxiv.org/abs/2401.17574) | [⬇️](https://arxiv.org/pdf/2401.17574)
*Tokiniaina Raharison Ralambomihanta, Shahrad Mohammadzadeh, Mohammad  Sami Nur Islam, Wassim Jabbour, Laurence Liang* 

  The rapid evolution of Large Language Models (LLMs), epitomized by
architectures like GPT-4, has reshaped the landscape of natural language
processing. This paper introduces a pioneering approach to address the
efficiency concerns associated with LLM pre-training, proposing the use of
knowledge distillation for cross-architecture transfer. Leveraging insights
from the efficient Hyena mechanism, our method replaces attention heads in
transformer models by Hyena, offering a cost-effective alternative to
traditional pre-training while confronting the challenge of processing long
contextual information, inherent in quadratic attention mechanisms. Unlike
conventional compression-focused methods, our technique not only enhances
inference speed but also surpasses pre-training in terms of both accuracy and
efficiency. In the era of evolving LLMs, our work contributes to the pursuit of
sustainable AI solutions, striking a balance between computational power and
environmental impact.

---------------

### 02 Feb 2024 | [KB-Plugin: A Plug-and-play Framework for Large Language Models to Induce  Programs over Low-resourced Knowledge Bases](https://arxiv.org/abs/2402.01619) | [⬇️](https://arxiv.org/pdf/2402.01619)
*Jiajie Zhang, Shulin Cao, Linmei Hu, Ling Feng, Lei Hou, Juanzi Li* 

  Program induction (PI) has become a promising paradigm for using knowledge
bases (KBs) to help large language models (LLMs) answer complex
knowledge-intensive questions. Nonetheless, PI typically relies on a large
number of parallel question-program pairs to make the LLM aware of the schema
of the given KB, and is thus challenging for many low-resourced KBs that lack
annotated data. To this end, we propose KB-Plugin, a plug-and-play framework
that enables LLMs to induce programs over any low-resourced KB. Firstly,
KB-Plugin adopts self-supervised learning to encode the detailed schema
information of a given KB into a pluggable module, namely schema plugin.
Secondly, KB-Plugin utilizes abundant annotated data from a rich-resourced KB
to train another pluggable module, namely PI plugin, which can help the LLM
extract question-relevant schema information from the schema plugin of any KB
and utilize this information to induce programs over this KB. Experiments on
five heterogeneous KBQA datasets show that KB-Plugin achieves better or
comparable performance with 25$\times$ smaller backbone LLM compared to SoTA PI
methods for low-resourced KBs, and even approaches the performance of
supervised methods. Our code and data are available at
https://github.com/THU-KEG/KB-Plugin.

---------------

### 14 Dec 2023 | [Successor Heads: Recurring, Interpretable Attention Heads In The Wild](https://arxiv.org/abs/2312.09230) | [⬇️](https://arxiv.org/pdf/2312.09230)
*Rhys Gould, Euan Ong, George Ogden, Arthur Conmy* 

  In this work we present successor heads: attention heads that increment
tokens with a natural ordering, such as numbers, months, and days. For example,
successor heads increment 'Monday' into 'Tuesday'. We explain the successor
head behavior with an approach rooted in mechanistic interpretability, the
field that aims to explain how models complete tasks in human-understandable
terms. Existing research in this area has found interpretable language model
components in small toy models. However, results in toy models have not yet led
to insights that explain the internals of frontier models and little is
currently understood about the internal operations of large language models. In
this paper, we analyze the behavior of successor heads in large language models
(LLMs) and find that they implement abstract representations that are common to
different architectures. They form in LLMs with as few as 31 million
parameters, and at least as many as 12 billion parameters, such as GPT-2,
Pythia, and Llama-2. We find a set of 'mod-10 features' that underlie how
successor heads increment in LLMs across different architectures and sizes. We
perform vector arithmetic with these features to edit head behavior and provide
insights into numeric representations within LLMs. Additionally, we study the
behavior of successor heads on natural language data, identifying interpretable
polysemanticity in a Pythia successor head.

---------------

### 19 Jan 2024 | [Medusa: Simple LLM Inference Acceleration Framework with Multiple  Decoding Heads](https://arxiv.org/abs/2401.10774) | [⬇️](https://arxiv.org/pdf/2401.10774)
*Tianle Cai, Yuhong Li, Zhengyang Geng, Hongwu Peng, Jason D. Lee,  Deming Chen, Tri Dao* 

  The inference process in Large Language Models (LLMs) is often limited due to
the absence of parallelism in the auto-regressive decoding process, resulting
in most operations being restricted by the memory bandwidth of accelerators.
While methods such as speculative decoding have been suggested to address this
issue, their implementation is impeded by the challenges associated with
acquiring and maintaining a separate draft model. In this paper, we present
Medusa, an efficient method that augments LLM inference by adding extra
decoding heads to predict multiple subsequent tokens in parallel. Using a
tree-based attention mechanism, Medusa constructs multiple candidate
continuations and verifies them simultaneously in each decoding step. By
leveraging parallel processing, Medusa introduces only minimal overhead in
terms of single-step latency while substantially reducing the number of
decoding steps required.
  We present two levels of fine-tuning procedures for Medusa to meet the needs
of different use cases: Medusa-1: Medusa is directly fine-tuned on top of a
frozen backbone LLM, enabling lossless inference acceleration. Medusa-2: Medusa
is fine-tuned together with the backbone LLM, enabling better prediction
accuracy of Medusa heads and higher speedup but needing a special training
recipe that preserves the backbone model's capabilities.
  Moreover, we propose several extensions that improve or expand the utility of
Medusa, including a self-distillation to handle situations where no training
data is available and a typical acceptance scheme to boost the acceptance rate
while maintaining generation quality. We evaluate Medusa on models of various
sizes and training procedures. Our experiments demonstrate that Medusa-1 can
achieve over 2.2x speedup without compromising generation quality, while
Medusa-2 further improves the speedup to 2.3-3.6x.

---------------

### 24 Feb 2024 | [Chimera: A Lossless Decoding Method for Accelerating Large Language  Models Inference by Fusing all Tokens](https://arxiv.org/abs/2402.15758) | [⬇️](https://arxiv.org/pdf/2402.15758)
*Ziqian Zeng, Jiahong Yu, Qianshi Pang, Zihao Wang, Huiping Zhuang, Cen  Chen* 

  Large language models (LLMs) have demonstrated remarkable capabilities across
various tasks. However, their widespread application is hindered by the
resource-intensive decoding process. To address this challenge, current
approaches have incorporated additional decoding heads to enable parallel
prediction of multiple subsequent tokens, thereby achieving inference
acceleration. Nevertheless, the accuracy of these decoding heads falls short of
the auto-regressive decoding approach.
  In light of these limitations, we propose Chimera, a novel framework
specifically designed for speculative sampling. Within this framework, we
introduce a lightweight draft model that effectively utilizes previously
generated tokens to predict subsequent words. To ensure both accuracy and
efficiency, we present two strategies within the lightweight draft model.
Firstly, we focus on capturing short-range dependencies at the bottom layer.
Secondly, we leverage the readily available representations from the original
LLM.Through empirical evaluation on the Vicuna and LlaMA-2 series, Chimera
demonstrates impressive results, achieving an average latency speedup ratio of
2.7x compared to the vanilla auto-regressive decoding approach. This highlights
the potential of our proposed framework in significantly improving the
efficiency of large language models during the decoding process.

---------------

### 07 Feb 2024 | [Hydra: Sequentially-Dependent Draft Heads for Medusa Decoding](https://arxiv.org/abs/2402.05109) | [⬇️](https://arxiv.org/pdf/2402.05109)
*Zachary Ankner, Rishab Parthasarathy, Aniruddha Nrusimha, Christopher  Rinard, Jonathan Ragan-Kelley, William Brandon* 

  To combat the memory bandwidth-bound nature of autoregressive LLM inference,
previous research has proposed the speculative decoding framework. To perform
speculative decoding, a small draft model proposes candidate continuations of
the input sequence, that are then verified in parallel by the base model. One
way to specify the draft model, as used in the recent Medusa decoding
framework, is as a collection of light-weight heads, called draft heads, that
operate on the base model's hidden states. To date, all existing draft heads
have been sequentially independent, meaning that they speculate tokens in the
candidate continuation independently of any preceding tokens in the candidate
continuation. In this work, we propose Hydra heads, a sequentially dependent,
drop-in replacement for standard draft heads that significantly improves
speculation accuracy. Decoding with Hydra heads improves throughput compared to
Medusa decoding with standard draft heads. We further explore the design space
of Hydra head training objectives and architectures, and propose a
carefully-tuned Hydra head recipe, which we call Hydra++, that improves
decoding throughput by 1.31x and 2.71x compared to Medusa decoding and
autoregressive decoding, respectively. Overall, Hydra heads are a simple
intervention on standard draft heads that significantly improve the end-to-end
speed of draft head based speculative decoding.

---------------

### 17 Jan 2024 | [LLMs for Relational Reasoning: How Far are We?](https://arxiv.org/abs/2401.09042) | [⬇️](https://arxiv.org/pdf/2401.09042)
*Zhiming Li, Yushi Cao, Xiufeng Xu, Junzhe Jiang, Xu Liu, Yon Shin Teo,  Shang-wei Lin, Yang Liu* 

  Large language models (LLMs) have revolutionized many areas (e.g. natural
language processing, software engineering, etc.) by achieving state-of-the-art
performance on extensive downstream tasks. Aiming to achieve robust and general
artificial intelligence, there has been a surge of interest in investigating
the reasoning ability of the LLMs. Whereas the textual and numerical reasoning
benchmarks adopted by previous works are rather shallow and simple, it is hard
to conclude that the LLMs possess strong reasoning ability by merely achieving
positive results on these benchmarks. Recent efforts have demonstrated that the
LLMs are poor at solving sequential decision-making problems that require
common-sense planning by evaluating their performance on the reinforcement
learning benchmarks. In this work, we conduct an in-depth assessment of several
state-of-the-art LLMs' reasoning ability based on the inductive logic
programming (ILP) benchmark, which is broadly recognized as a representative
and challenging measurement for evaluating logic program induction/synthesis
systems as it requires inducing strict cause-effect logic to achieve robust
deduction on independent and identically distributed (IID) and
out-of-distribution (OOD) test samples. Our evaluations illustrate that
compared with the neural program induction systems which are much smaller in
model size, the state-of-the-art LLMs are much poorer in terms of reasoning
ability by achieving much lower performance and generalization using either
natural language prompting or truth-value matrix prompting.

---------------

### 15 Feb 2024 | [Self-Augmented In-Context Learning for Unsupervised Word Translation](https://arxiv.org/abs/2402.10024) | [⬇️](https://arxiv.org/pdf/2402.10024)
*Yaoyiran Li, Anna Korhonen, Ivan Vuli\'c* 

  Recent work has shown that, while large language models (LLMs) demonstrate
strong word translation or bilingual lexicon induction (BLI) capabilities in
few-shot setups, they still cannot match the performance of 'traditional'
mapping-based approaches in the unsupervised scenario where no seed translation
pairs are available, especially for lower-resource languages. To address this
challenge with LLMs, we propose self-augmented in-context learning (SAIL) for
unsupervised BLI: starting from a zero-shot prompt, SAIL iteratively induces a
set of high-confidence word translation pairs for in-context learning (ICL)
from an LLM, which it then reapplies to the same LLM in the ICL fashion. Our
method shows substantial gains over zero-shot prompting of LLMs on two
established BLI benchmarks spanning a wide range of language pairs, also
outperforming mapping-based baselines across the board. In addition to
achieving state-of-the-art unsupervised BLI performance, we also conduct
comprehensive analyses on SAIL and discuss its limitations.

---------------

### 08 Aug 2023 | [AutoHint: Automatic Prompt Optimization with Hint Generation](https://arxiv.org/abs/2307.07415) | [⬇️](https://arxiv.org/pdf/2307.07415)
*Hong Sun, Xue Li, Yinchuan Xu, Youkow Homma, Qi Cao, Min Wu, Jian  Jiao, Denis Charles* 

  This paper presents AutoHint, a novel framework for automatic prompt
engineering and optimization for Large Language Models (LLM). While LLMs have
demonstrated remarkable ability in achieving high-quality annotation in various
tasks, the key to applying this ability to specific tasks lies in developing
high-quality prompts. Thus we propose a framework to inherit the merits of both
in-context learning and zero-shot learning by incorporating enriched
instructions derived from input-output demonstrations to optimize original
prompt. We refer to the enrichment as the hint and propose a framework to
automatically generate the hint from labeled data. More concretely, starting
from an initial prompt, our method first instructs a LLM to deduce new hints
for selected samples from incorrect predictions, and then summarizes from
per-sample hints and adds the results back to the initial prompt to form a new,
enriched instruction. The proposed method is evaluated on the BIG-Bench
Instruction Induction dataset for both zero-shot and few-short prompts, where
experiments demonstrate our method is able to significantly boost accuracy for
multiple tasks.

---------------

### 31 Oct 2023 | [A Vision-free Baseline for Multimodal Grammar Induction](https://arxiv.org/abs/2212.10564) | [⬇️](https://arxiv.org/pdf/2212.10564)
*Boyi Li and Rodolfo Corona and Karttikeya Mangalam and Catherine Chen  and Daniel Flaherty and Serge Belongie and Kilian Q. Weinberger and Jitendra  Malik and Trevor Darrell and Dan Klein* 

  Past work has shown that paired vision-language signals substantially improve
grammar induction in multimodal datasets such as MSCOCO. We investigate whether
advancements in large language models (LLMs) that are only trained with text
could provide strong assistance for grammar induction in multimodal settings.
We find that our text-only approach, an LLM-based C-PCFG (LC-PCFG), outperforms
previous multi-modal methods, and achieves state-of-the-art grammar induction
performance for various multimodal datasets. Compared to image-aided grammar
induction, LC-PCFG outperforms the prior state-of-the-art by 7.9 Corpus-F1
points, with an 85% reduction in parameter count and 1.7x faster training
speed. Across three video-assisted grammar induction benchmarks, LC-PCFG
outperforms prior state-of-the-art by up to 7.7 Corpus-F1, with 8.8x faster
training. These results shed light on the notion that text-only language models
might include visually grounded cues that aid in grammar induction in
multimodal contexts. Moreover, our results emphasize the importance of
establishing a robust vision-free baseline when evaluating the benefit of
multimodal approaches.

---------------
**Date:** 20 Feb 2024

**Title:** Identifying Semantic Induction Heads to Understand In-Context Learning

**Abstract Link:** [https://arxiv.org/abs/2402.13055](https://arxiv.org/abs/2402.13055)

**PDF Link:** [https://arxiv.org/pdf/2402.13055](https://arxiv.org/pdf/2402.13055)

---

**Date:** 17 Feb 2024

**Title:** Crafting a Good Prompt or Providing Exemplary Dialogues? A Study of  In-Context Learning for Persona-based Dialogue Generation

**Abstract Link:** [https://arxiv.org/abs/2402.09954](https://arxiv.org/abs/2402.09954)

**PDF Link:** [https://arxiv.org/pdf/2402.09954](https://arxiv.org/pdf/2402.09954)

---

**Date:** 24 Sep 2022

**Title:** In-context Learning and Induction Heads

**Abstract Link:** [https://arxiv.org/abs/2209.11895](https://arxiv.org/abs/2209.11895)

**PDF Link:** [https://arxiv.org/pdf/2209.11895](https://arxiv.org/pdf/2209.11895)

---

**Date:** 25 Nov 2023

**Title:** Localizing Lying in Llama: Understanding Instructed Dishonesty on  True-False Questions Through Prompting, Probing, and Patching

**Abstract Link:** [https://arxiv.org/abs/2311.15131](https://arxiv.org/abs/2311.15131)

**PDF Link:** [https://arxiv.org/pdf/2311.15131](https://arxiv.org/pdf/2311.15131)

---

**Date:** 23 Feb 2024

**Title:** Interpreting Context Look-ups in Transformers: Investigating  Attention-MLP Interactions

**Abstract Link:** [https://arxiv.org/abs/2402.15055](https://arxiv.org/abs/2402.15055)

**PDF Link:** [https://arxiv.org/pdf/2402.15055](https://arxiv.org/pdf/2402.15055)

---

**Date:** 29 Feb 2024

**Title:** Whispers that Shake Foundations: Analyzing and Mitigating False Premise  Hallucinations in Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.19103](https://arxiv.org/abs/2402.19103)

**PDF Link:** [https://arxiv.org/pdf/2402.19103](https://arxiv.org/pdf/2402.19103)

---

**Date:** 16 Feb 2024

**Title:** From Language Modeling to Instruction Following: Understanding the  Behavior Shift in LLMs after Instruction Tuning

**Abstract Link:** [https://arxiv.org/abs/2310.00492](https://arxiv.org/abs/2310.00492)

**PDF Link:** [https://arxiv.org/pdf/2310.00492](https://arxiv.org/pdf/2310.00492)

---

**Date:** 28 Feb 2024

**Title:** Memory Injections: Correcting Multi-Hop Reasoning Failures during  Inference in Transformer-Based Language Models

**Abstract Link:** [https://arxiv.org/abs/2309.05605](https://arxiv.org/abs/2309.05605)

**PDF Link:** [https://arxiv.org/pdf/2309.05605](https://arxiv.org/pdf/2309.05605)

---

**Date:** 25 Feb 2024

**Title:** On Bilingual Lexicon Induction with Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.13995](https://arxiv.org/abs/2310.13995)

**PDF Link:** [https://arxiv.org/pdf/2310.13995](https://arxiv.org/pdf/2310.13995)

---

**Date:** 25 Oct 2023

**Title:** Attention Lens: A Tool for Mechanistically Interpreting the Attention  Head Information Retrieval Mechanism

**Abstract Link:** [https://arxiv.org/abs/2310.16270](https://arxiv.org/abs/2310.16270)

**PDF Link:** [https://arxiv.org/pdf/2310.16270](https://arxiv.org/pdf/2310.16270)

---

**Date:** 31 Jan 2024

**Title:** Scavenging Hyena: Distilling Transformers into Long Convolution Models

**Abstract Link:** [https://arxiv.org/abs/2401.17574](https://arxiv.org/abs/2401.17574)

**PDF Link:** [https://arxiv.org/pdf/2401.17574](https://arxiv.org/pdf/2401.17574)

---

**Date:** 02 Feb 2024

**Title:** KB-Plugin: A Plug-and-play Framework for Large Language Models to Induce  Programs over Low-resourced Knowledge Bases

**Abstract Link:** [https://arxiv.org/abs/2402.01619](https://arxiv.org/abs/2402.01619)

**PDF Link:** [https://arxiv.org/pdf/2402.01619](https://arxiv.org/pdf/2402.01619)

---

**Date:** 14 Dec 2023

**Title:** Successor Heads: Recurring, Interpretable Attention Heads In The Wild

**Abstract Link:** [https://arxiv.org/abs/2312.09230](https://arxiv.org/abs/2312.09230)

**PDF Link:** [https://arxiv.org/pdf/2312.09230](https://arxiv.org/pdf/2312.09230)

---

**Date:** 19 Jan 2024

**Title:** Medusa: Simple LLM Inference Acceleration Framework with Multiple  Decoding Heads

**Abstract Link:** [https://arxiv.org/abs/2401.10774](https://arxiv.org/abs/2401.10774)

**PDF Link:** [https://arxiv.org/pdf/2401.10774](https://arxiv.org/pdf/2401.10774)

---

**Date:** 24 Feb 2024

**Title:** Chimera: A Lossless Decoding Method for Accelerating Large Language  Models Inference by Fusing all Tokens

**Abstract Link:** [https://arxiv.org/abs/2402.15758](https://arxiv.org/abs/2402.15758)

**PDF Link:** [https://arxiv.org/pdf/2402.15758](https://arxiv.org/pdf/2402.15758)

---

**Date:** 07 Feb 2024

**Title:** Hydra: Sequentially-Dependent Draft Heads for Medusa Decoding

**Abstract Link:** [https://arxiv.org/abs/2402.05109](https://arxiv.org/abs/2402.05109)

**PDF Link:** [https://arxiv.org/pdf/2402.05109](https://arxiv.org/pdf/2402.05109)

---

**Date:** 17 Jan 2024

**Title:** LLMs for Relational Reasoning: How Far are We?

**Abstract Link:** [https://arxiv.org/abs/2401.09042](https://arxiv.org/abs/2401.09042)

**PDF Link:** [https://arxiv.org/pdf/2401.09042](https://arxiv.org/pdf/2401.09042)

---

**Date:** 15 Feb 2024

**Title:** Self-Augmented In-Context Learning for Unsupervised Word Translation

**Abstract Link:** [https://arxiv.org/abs/2402.10024](https://arxiv.org/abs/2402.10024)

**PDF Link:** [https://arxiv.org/pdf/2402.10024](https://arxiv.org/pdf/2402.10024)

---

**Date:** 08 Aug 2023

**Title:** AutoHint: Automatic Prompt Optimization with Hint Generation

**Abstract Link:** [https://arxiv.org/abs/2307.07415](https://arxiv.org/abs/2307.07415)

**PDF Link:** [https://arxiv.org/pdf/2307.07415](https://arxiv.org/pdf/2307.07415)

---

**Date:** 31 Oct 2023

**Title:** A Vision-free Baseline for Multimodal Grammar Induction

**Abstract Link:** [https://arxiv.org/abs/2212.10564](https://arxiv.org/abs/2212.10564)

**PDF Link:** [https://arxiv.org/pdf/2212.10564](https://arxiv.org/pdf/2212.10564)

---

