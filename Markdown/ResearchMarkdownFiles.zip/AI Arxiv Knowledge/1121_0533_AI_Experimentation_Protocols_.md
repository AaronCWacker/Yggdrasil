AI Experimentation Protocols 🗝️

### 🔎 AI Experimentation Protocols 🗝️



# AI Experimentation Protocols

AI Experimentation Protocols (AIEP) is a Python library for managing and tracking machine learning experiments.

## Installation

```
pip install aiep
```

## Usage

### Experiment

An experiment is a collection of trials.

```
from aiep import Experiment

experiment = Experiment(name="My Experiment")
```

### Trial

A trial is a single run of a machine learning model.

```
from aiep import Trial

trial = Trial(name="My Trial")
```

### Parameters

Parameters are the hyperparameters of your machine learning model.

```
from aiep import Parameter

learning_rate = Parameter(name="Learning Rate", value=0.01)
batch_size = Parameter(name="Batch Size", value=32)

trial.add_parameters(learning_rate, batch_size)
```

### Metrics

Metrics are the performance measures of your machine learning model.

```
from aiep import Metric

accuracy = Metric(name="Accuracy", value=0.95)
loss = Metric(name="Loss", value=0.1)

trial.add_metrics(accuracy, loss)
```

### Artifacts

Artifacts are the output files of your machine learning model.

```
from aiep import Artifact

model = Artifact(name="My Model", path="model.pth")
summary = Artifact(name="Summary", path="summary.txt")

trial.add_artifacts(model, summary)
```

### Logging

You can log your experiments to a SQLite database.

```
from aiep import SQLiteLogger

logger = SQLiteLogger(database="experiments.db")
logger.log(experiment)
```

### Visualization

You can visualize your experiments using TensorBoard.

```
from aiep import TensorBoardLogger

logger = TensorBoardLogger(log_dir="logs")
logger.log(exper
# 🩺🔍 Search Results
### 11 Aug 2023 | [Assessing Student Errors in Experimentation Using Artificial  Intelligence and Large Language Models: A Comparative Study with Human Raters](https://arxiv.org/abs/2308.06088) | [⬇️](https://arxiv.org/pdf/2308.06088)
*Arne Bewersdorff, Kathrin Se{\ss}ler, Armin Baur, Enkelejda Kasneci,  Claudia Nerdel* 

  Identifying logical errors in complex, incomplete or even contradictory and
overall heterogeneous data like students' experimentation protocols is
challenging. Recognizing the limitations of current evaluation methods, we
investigate the potential of Large Language Models (LLMs) for automatically
identifying student errors and streamlining teacher assessments. Our aim is to
provide a foundation for productive, personalized feedback. Using a dataset of
65 student protocols, an Artificial Intelligence (AI) system based on the
GPT-3.5 and GPT-4 series was developed and tested against human raters. Our
results indicate varying levels of accuracy in error detection between the AI
system and human raters. The AI system can accurately identify many fundamental
student errors, for instance, the AI system identifies when a student is
focusing the hypothesis not on the dependent variable but solely on an expected
observation (acc. = 0.90), when a student modifies the trials in an ongoing
investigation (acc. = 1), and whether a student is conducting valid test trials
(acc. = 0.82) reliably. The identification of other, usually more complex
errors, like whether a student conducts a valid control trial (acc. = .60),
poses a greater challenge. This research explores not only the utility of AI in
educational settings, but also contributes to the understanding of the
capabilities of LLMs in error detection in inquiry-based learning like
experimentation.

---------------

### 09 Nov 2020 | [An Experimentation Platform for Explainable Coalition Situational  Understanding](https://arxiv.org/abs/2010.14388) | [⬇️](https://arxiv.org/pdf/2010.14388)
*Katie Barrett-Powell, Jack Furby, Liam Hiley, Marc Roig Vilamala,  Harrison Taylor, Federico Cerutti, Alun Preece, Tianwei Xing, Luis Garcia,  Mani Srivastava, Dave Braines* 

  We present an experimentation platform for coalition situational
understanding research that highlights capabilities in explainable artificial
intelligence/machine learning (AI/ML) and integration of symbolic and
subsymbolic AI/ML approaches for event processing. The Situational
Understanding Explorer (SUE) platform is designed to be lightweight, to easily
facilitate experiments and demonstrations, and open. We discuss our
requirements to support coalition multi-domain operations with emphasis on
asset interoperability and ad hoc human-machine teaming in a dense urban
terrain setting. We describe the interface functionality and give examples of
SUE applied to coalition situational understanding tasks.

---------------

### 14 Sep 2021 | [Post-Selections in AI and How to Avoid Them](https://arxiv.org/abs/2106.13233) | [⬇️](https://arxiv.org/pdf/2106.13233)
*Juyang Weng* 

  Neural network based Artificial Intelligence (AI) has reported increasing
scales in experiments. However, this paper raises a rarely reported stage in
such experiments called Post-Selection alter the reader to several possible
protocol flaws that may result in misleading results. All AI methods fall into
two broad schools, connectionist and symbolic. The Post-Selection fall into two
kinds, Post-Selection Using Validation Sets (PSUVS) and Post-Selection Using
Test Sets (PSUTS). Each kind has two types of post-selectors, machines and
humans. The connectionist school received criticisms for its "black box" and
now the Post-Selection; but the seemingly "clean" symbolic school seems more
brittle because of its human PSUTS. This paper first presents a controversial
view: all static "big data" are non-scalable. We then analyze why
error-backprop from randomly initialized weights suffers from severe local
minima, why PSUVS lacks cross-validation, why PSUTS violates well-established
protocols, and why every paper involved should transparently report the
Post-Selection stage. To avoid future pitfalls in AI competitions, this paper
proposes a new AI metrics, called developmental errors for all networks
trained, under Three Learning Conditions: (1) an incremental learning
architecture (due to a "big data" flaw), (2) a training experience and (3) a
limited amount of computational resources. Developmental Networks avoid
Post-Selections because they automatically discover context-rules on the fly by
generating emergent Turing machines (not black boxes) that are optimal in the
sense of maximum-likelihood across lifetime, conditioned on the Three Learning
Conditions.

---------------

### 19 Dec 2021 | [Autonomous synthesis of metastable materials](https://arxiv.org/abs/2101.07385) | [⬇️](https://arxiv.org/pdf/2101.07385)
*Sebastian Ament, Maximilian Amsler, Duncan R. Sutherland, Ming-Chiang  Chang, Dan Guevarra, Aine B. Connolly, John M. Gregoire, Michael O. Thompson,  Carla P. Gomes, R. Bruce van Dover* 

  Autonomous experimentation enabled by artificial intelligence (AI) offers a
new paradigm for accelerating scientific discovery. Non-equilibrium materials
synthesis is emblematic of complex, resource-intensive experimentation whose
acceleration would be a watershed for materials discovery and development. The
mapping of non-equilibrium synthesis phase diagrams has recently been
accelerated via high throughput experimentation but still limits materials
research because the parameter space is too vast to be exhaustively explored.
We demonstrate accelerated synthesis and exploration of metastable materials
through hierarchical autonomous experimentation governed by the Scientific
Autonomous Reasoning Agent (SARA). SARA integrates robotic materials synthesis
and characterization along with a hierarchy of AI methods that efficiently
reveal the structure of processing phase diagrams. SARA designs lateral
gradient laser spike annealing (lg-LSA) experiments for parallel materials
synthesis and employs optical spectroscopy to rapidly identify phase
transitions. Efficient exploration of the multi-dimensional parameter space is
achieved with nested active learning (AL) cycles built upon advanced machine
learning models that incorporate the underlying physics of the experiments as
well as end-to-end uncertainty quantification. With this, and the coordination
of AL at multiple scales, SARA embodies AI harnessing of complex scientific
tasks. We demonstrate its performance by autonomously mapping synthesis phase
boundaries for the Bi$_2$O$_3$ system, leading to orders-of-magnitude
acceleration in establishment of a synthesis phase diagram that includes
conditions for kinetically stabilizing $\delta$-Bi$_2$O$_3$ at room
temperature, a critical development for electrochemical technologies such as
solid oxide fuel cells.

---------------

### 07 Dec 2023 | [Evaluating Zero-Shot Scoring for In Vitro Antibody Binding Prediction  with Experimental Validation](https://arxiv.org/abs/2312.05273) | [⬇️](https://arxiv.org/pdf/2312.05273)
*Divya Nori and Simon V. Mathis and Amir Shanehsazzadeh* 

  The success of therapeutic antibodies relies on their ability to selectively
bind antigens. AI-based antibody design protocols have shown promise in
generating epitope-specific designs. Many of these protocols use an inverse
folding step to generate diverse sequences given a backbone structure. Due to
prohibitive screening costs, it is key to identify candidate sequences likely
to bind in vitro. Here, we compare the efficacy of 8 common scoring paradigms
based on open-source models to classify antibody designs as binders or
non-binders. We evaluate these approaches on a novel surface plasmon resonance
(SPR) dataset, spanning 5 antigens. Our results show that existing methods
struggle to detect binders, and performance is highly variable across antigens.
We find that metrics computed on flexibly docked antibody-antigen complexes are
more robust, and ensembles scores are more consistent than individual metrics.
We provide experimental insight to analyze current scoring techniques,
highlighting that the development of robust, zero-shot filters is an important
research gap.

---------------

### 05 Oct 2023 | [Benchmarking Large Language Models As AI Research Agents](https://arxiv.org/abs/2310.03302) | [⬇️](https://arxiv.org/pdf/2310.03302)
*Qian Huang, Jian Vora, Percy Liang, Jure Leskovec* 

  Scientific experimentation involves an iterative process of creating
hypotheses, designing experiments, running experiments, and analyzing the
results. Can we build AI research agents to perform these long-horizon tasks?
To take a step towards building and evaluating research agents on such
open-ended decision-making tasks, we focus on the problem of machine learning
engineering: given a task description and a dataset, build a high-performing
model. In this paper, we propose MLAgentBench, a suite of ML tasks for
benchmarking AI research agents. Agents can perform actions like
reading/writing files, executing code, and inspecting outputs. With these
actions, agents could run experiments, analyze the results, and modify the code
of entire machine learning pipelines, such as data processing, architecture,
training processes, etc. The benchmark then automatically evaluates the agent's
performance objectively over various metrics related to performance and
efficiency. We also design an LLM-based research agent to automatically perform
experimentation loops in such an environment. Empirically, we find that a
GPT-4-based research agent can feasibly build compelling ML models over many
tasks in MLAgentBench, displaying highly interpretable plans and actions.
However, the success rates vary considerably; they span from almost 90\% on
well-established older datasets to as low as 10\% on recent Kaggle Challenges
-- unavailable during the LLM model's pretraining -- and even 0\% on newer
research challenges like BabyLM. Finally, we identify several key challenges
for LLM-based research agents such as long-term planning and hallucination. Our
code is released at https://github.com/snap-stanford/MLAgentBench.

---------------

### 14 Sep 2023 | [Preventing Unauthorized AI Over-Analysis by Medical Image Adversarial  Watermarking](https://arxiv.org/abs/2303.09858) | [⬇️](https://arxiv.org/pdf/2303.09858)
*Xingxing Wei, Bangzheng Pu, Shiji Zhao, Chen Chi and Huazhu Fu* 

  The advancement of deep learning has facilitated the integration of
Artificial Intelligence (AI) into clinical practices, particularly in
computer-aided diagnosis. Given the pivotal role of medical images in various
diagnostic procedures, it becomes imperative to ensure the responsible and
secure utilization of AI techniques. However, the unauthorized utilization of
AI for image analysis raises significant concerns regarding patient privacy and
potential infringement on the proprietary rights of data custodians.
Consequently, the development of pragmatic and cost-effective strategies that
safeguard patient privacy and uphold medical image copyrights emerges as a
critical necessity. In direct response to this pressing demand, we present a
pioneering solution named Medical Image Adversarial watermarking (MIAD-MARK).
Our approach introduces watermarks that strategically mislead unauthorized AI
diagnostic models, inducing erroneous predictions without compromising the
integrity of the visual content. Importantly, our method integrates an
authorization protocol tailored for legitimate users, enabling the removal of
the MIAD-MARK through encryption-generated keys. Through extensive experiments,
we validate the efficacy of MIAD-MARK across three prominent medical image
datasets. The empirical outcomes demonstrate the substantial impact of our
approach, notably reducing the accuracy of standard AI diagnostic models to a
mere 8.57% under white box conditions and 45.83% in the more challenging black
box scenario. Additionally, our solution effectively mitigates unauthorized
exploitation of medical images even in the presence of sophisticated watermark
removal networks. Notably, those AI diagnosis networks exhibit a meager average
accuracy of 38.59% when applied to images protected by MIAD-MARK, underscoring
the robustness of our safeguarding mechanism.

---------------

### 20 Dec 2023 | [Agglomerative Federated Learning: Empowering Larger Model Training via  End-Edge-Cloud Collaboration](https://arxiv.org/abs/2312.11489) | [⬇️](https://arxiv.org/pdf/2312.11489)
*Zhiyuan Wu, Sheng Sun, Yuwei Wang, Min Liu, Bo Gao, Quyang Pan,  Tianliu He, Xuefeng Jiang* 

  Federated Learning (FL) enables training Artificial Intelligence (AI) models
over end devices without compromising their privacy. As computing tasks are
increasingly performed by a combination of cloud, edge, and end devices, FL can
benefit from this End-Edge-Cloud Collaboration (EECC) paradigm to achieve
collaborative device-scale expansion with real-time access. Although
Hierarchical Federated Learning (HFL) supports multi-tier model aggregation
suitable for EECC, prior works assume the same model structure on all computing
nodes, constraining the model scale by the weakest end devices. To address this
issue, we propose Agglomerative Federated Learning (FedAgg), which is a novel
EECC-empowered FL framework that allows the trained models from end, edge, to
cloud to grow larger in size and stronger in generalization ability. FedAgg
recursively organizes computing nodes among all tiers based on Bridge Sample
Based Online Distillation Protocol (BSBODP), which enables every pair of
parent-child computing nodes to mutually transfer and distill knowledge
extracted from generated bridge samples. This design enhances the performance
by exploiting the potential of larger models, with privacy constraints of FL
and flexibility requirements of EECC both satisfied. Experiments under various
settings demonstrate that FedAgg outperforms state-of-the-art methods by an
average of 4.53\% accuracy gains and remarkable improvements in convergence
rate.

---------------

### 08 Sep 2022 | [Contextualizing Artificially Intelligent Morality: A Meta-Ethnography of  Top-Down, Bottom-Up, and Hybrid Models for Theoretical and Applied Ethics in  Artificial Intelligence](https://arxiv.org/abs/2204.07612) | [⬇️](https://arxiv.org/pdf/2204.07612)
*Jennafer S. Roberts and Laura N. Montoya* 

  In this meta-ethnography, we explore three different angles of ethical
artificial intelligence (AI) design implementation including the philosophical
ethical viewpoint, the technical perspective, and framing through a political
lens. Our qualitative research includes a literature review that highlights the
cross-referencing of these angles by discussing the value and drawbacks of
contrastive top-down, bottom-up, and hybrid approaches previously published.
The novel contribution to this framework is the political angle, which
constitutes ethics in AI either being determined by corporations and
governments and imposed through policies or law (coming from the top), or
ethics being called for by the people (coming from the bottom), as well as
top-down, bottom-up, and hybrid technicalities of how AI is developed within a
moral construct and in consideration of its users, with expected and unexpected
consequences and long-term impact in the world. There is a focus on
reinforcement learning as an example of a bottom-up applied technical approach
and AI ethics principles as a practical top-down approach. This investigation
includes real-world case studies to impart a global perspective, as well as
philosophical debate on the ethics of AI and theoretical future thought
experimentation based on historical facts, current world circumstances, and
possible ensuing realities.

---------------

### 01 Feb 2024 | [The whack-a-mole governance challenge for AI-enabled synthetic biology:  literature review and emerging frameworks](https://arxiv.org/abs/2402.00312) | [⬇️](https://arxiv.org/pdf/2402.00312)
*Trond Arne Undheim* 

  AI-enabled synthetic biology has tremendous potential but also significantly
increases biorisks and brings about a new set of dual use concerns. The picture
is complicated given the vast innovations envisioned to emerge by combining
emerging technologies, as AI-enabled synthetic biology potentially scales up
bioengineering into industrial biomanufacturing. However, the literature review
indicates that goals such as maintaining a reasonable scope for innovation, or
more ambitiously to foster a huge bioeconomy don't necessarily contrast with
biosafety, but need to go hand in hand. This paper presents a literature review
of the issues and describes emerging frameworks for policy and practice that
transverse the options of command-and control, stewardship, bottom-up, and
laissez-faire governance. How to achieve early warning systems that enable
prevention and mitigation of future AI-enabled biohazards from the lab, from
deliberate misuse, or from the public realm, will constantly need to evolve,
and adaptive, interactive approaches should emerge. Although biorisk is subject
to an established governance regime, and scientists generally adhere to
biosafety protocols, even experimental, but legitimate use by scientists could
lead to unexpected developments. Recent advances in chatbots enabled by
generative AI have revived fears that advanced biological insight can more
easily get into the hands of malignant individuals or organizations. Given
these sets of issues, society needs to rethink how AI-enabled synthetic biology
should be governed. The suggested way to visualize the challenge at hand is
whack-a-mole governance, although the emerging solutions are perhaps not so
different either.

---------------

### 18 Dec 2023 | [Human-Machine Teaming for UAVs: An Experimentation Platform](https://arxiv.org/abs/2312.11718) | [⬇️](https://arxiv.org/pdf/2312.11718)
*Laila El Moujtahid and Sai Krishna Gottipati and Clod\'eric Mars and  Matthew E. Taylor* 

  Full automation is often not achievable or desirable in critical systems with
high-stakes decisions. Instead, human-AI teams can achieve better results. To
research, develop, evaluate, and validate algorithms suited for such teaming,
lightweight experimentation platforms that enable interactions between humans
and multiple AI agents are necessary. However, there are limited examples of
such platforms for defense environments. To address this gap, we present the
Cogment human-machine teaming experimentation platform, which implements
human-machine teaming (HMT) use cases that features heterogeneous multi-agent
systems and can involve learning AI agents, static AI agents, and humans. It is
built on the Cogment platform and has been used for academic research,
including work presented at the ALA workshop at AAMAS this year [1]. With this
platform, we hope to facilitate further research on human-machine teaming in
critical systems and defense environments.

---------------

### 04 Nov 2017 | [Emergence of Language with Multi-agent Games: Learning to Communicate  with Sequences of Symbols](https://arxiv.org/abs/1705.11192) | [⬇️](https://arxiv.org/pdf/1705.11192)
*Serhii Havrylov, Ivan Titov* 

  Learning to communicate through interaction, rather than relying on explicit
supervision, is often considered a prerequisite for developing a general AI. We
study a setting where two agents engage in playing a referential game and, from
scratch, develop a communication protocol necessary to succeed in this game.
Unlike previous work, we require that messages they exchange, both at train and
test time, are in the form of a language (i.e. sequences of discrete symbols).
We compare a reinforcement learning approach and one using a differentiable
relaxation (straight-through Gumbel-softmax estimator) and observe that the
latter is much faster to converge and it results in more effective protocols.
Interestingly, we also observe that the protocol we induce by optimizing the
communication success exhibits a degree of compositionality and variability
(i.e. the same information can be phrased in different ways), both properties
characteristic of natural languages. As the ultimate goal is to ensure that
communication is accomplished in natural language, we also perform experiments
where we inject prior information about natural language into our model and
study properties of the resulting protocol.

---------------

### 26 Jan 2022 | [SCAI-QReCC Shared Task on Conversational Question Answering](https://arxiv.org/abs/2201.11094) | [⬇️](https://arxiv.org/pdf/2201.11094)
*Svitlana Vakulenko, Johannes Kiesel, Maik Fr\"obe* 

  Search-Oriented Conversational AI (SCAI) is an established venue that
regularly puts a spotlight upon the recent work advancing the field of
conversational search. SCAI'21 was organised as an independent on-line event
and featured a shared task on conversational question answering. Since all of
the participant teams experimented with answer generation models for this task,
we identified evaluation of answer correctness in this settings as the major
challenge and a current research gap. Alongside the automatic evaluation, we
conducted two crowdsourcing experiments to collect annotations for answer
plausibility and faithfulness. As a result of this shared task, the original
conversational QA dataset used for evaluation was further extended with
alternative correct answers produced by the participant systems.

---------------

### 29 Apr 2022 | [Altruist: Argumentative Explanations through Local Interpretations of  Predictive Models](https://arxiv.org/abs/2010.07650) | [⬇️](https://arxiv.org/pdf/2010.07650)
*Ioannis Mollas, Nick Bassiliades, Grigorios Tsoumakas* 

  Explainable AI is an emerging field providing solutions for acquiring
insights into automated systems' rationale. It has been put on the AI map by
suggesting ways to tackle key ethical and societal issues. Existing explanation
techniques are often not comprehensible to the end user. Lack of evaluation and
selection criteria also makes it difficult for the end user to choose the most
suitable technique. In this study, we combine logic-based argumentation with
Interpretable Machine Learning, introducing a preliminary meta-explanation
methodology that identifies the truthful parts of feature importance oriented
interpretations. This approach, in addition to being used as a meta-explanation
technique, can be used as an evaluation or selection tool for multiple feature
importance techniques. Experimentation strongly indicates that an ensemble of
multiple interpretation techniques yields considerably more truthful
explanations.

---------------

### 30 Oct 2020 | [Biomedical Concept Relatedness -- A large EHR-based benchmark](https://arxiv.org/abs/2010.16218) | [⬇️](https://arxiv.org/pdf/2010.16218)
*Claudia Schulz and Josh Levy-Kramer and Camille Van Assel and Miklos  Kepes and Nils Hammerla* 

  A promising application of AI to healthcare is the retrieval of information
from electronic health records (EHRs), e.g. to aid clinicians in finding
relevant information for a consultation or to recruit suitable patients for a
study. This requires search capabilities far beyond simple string matching,
including the retrieval of concepts (diagnoses, symptoms, medications, etc.)
related to the one in question. The suitability of AI methods for such
applications is tested by predicting the relatedness of concepts with known
relatedness scores. However, all existing biomedical concept relatedness
datasets are notoriously small and consist of hand-picked concept pairs. We
open-source a novel concept relatedness benchmark overcoming these issues: it
is six times larger than existing datasets and concept pairs are chosen based
on co-occurrence in EHRs, ensuring their relevance for the application of
interest. We present an in-depth analysis of our new dataset and compare it to
existing ones, highlighting that it is not only larger but also complements
existing datasets in terms of the types of concepts included. Initial
experiments with state-of-the-art embedding methods show that our dataset is a
challenging new benchmark for testing concept relatedness models.

---------------

### 14 May 2021 | [Domestic waste detection and grasping points for robotic picking up](https://arxiv.org/abs/2105.06825) | [⬇️](https://arxiv.org/pdf/2105.06825)
*Victor De Gea and Santiago T. Puente and Pablo Gil* 

  This paper presents an AI system applied to location and robotic grasping.
Experimental setup is based on a parameter study to train a deep-learning
network based on Mask-RCNN to perform waste location in indoor and outdoor
environment, using five different classes and generating a new waste dataset.
Initially the AI system obtain the RGBD data of the environment, followed by
the detection of objects using the neural network. Later, the 3D object shape
is computed using the network result and the depth channel. Finally, the shape
is used to compute grasping for a robot arm with a two-finger gripper. The
objective is to classify the waste in groups to improve a recycling strategy.

---------------

### 19 Mar 2021 | [Performance Analysis of Deep Learning Workloads on a Composable System](https://arxiv.org/abs/2103.10911) | [⬇️](https://arxiv.org/pdf/2103.10911)
*Kauotar El Maghraoui and Lorraine M. Herger and Chekuri Choudary and  Kim Tran and Todd Deshane and David Hanson* 

  A composable infrastructure is defined as resources, such as compute,
storage, accelerators and networking, that are shared in a pool and that can be
grouped in various configurations to meet application requirements. This
freedom to 'mix and match' resources dynamically allows for experimentation
early in the design cycle, prior to the final architectural design or hardware
implementation of a system. This design provides flexibility to serve a variety
of workloads and provides a dynamic co-design platform that allows experiments
and measurements in a controlled manner. For instance, key performance
bottlenecks can be revealed early on in the experimentation phase thus avoiding
costly and time consuming mistakes. Additionally, various system-level
topologies can be evaluated when experimenting with new System on Chip (SoCs)
and new accelerator types. This paper details the design of an enterprise
composable infrastructure that we have implemented and made available to our
partners in the IBM Research AI Hardware Center (AIHC). Our experimental
evaluations on the composable system give insights into how the system works
and evaluates the impact of various resource aggregations and reconfigurations
on representative deep learning benchmarks.

---------------

### 01 Aug 2023 | [Explaining and visualizing black-box models through counterfactual paths](https://arxiv.org/abs/2307.07764) | [⬇️](https://arxiv.org/pdf/2307.07764)
*Bastian Pfeifer, Mateusz Krzyzinski, Hubert Baniecki, Anna Saranti,  Andreas Holzinger, Przemyslaw Biecek* 

  Explainable AI (XAI) is an increasingly important area of machine learning
research, which aims to make black-box models transparent and interpretable. In
this paper, we propose a novel approach to XAI that uses the so-called
counterfactual paths generated by conditional permutations of features. The
algorithm measures feature importance by identifying sequential permutations of
features that most influence changes in model predictions. It is particularly
suitable for generating explanations based on counterfactual paths in knowledge
graphs incorporating domain knowledge. Counterfactual paths introduce an
additional graph dimension to current XAI methods in both explaining and
visualizing black-box models. Experiments with synthetic and medical data
demonstrate the practical applicability of our approach.

---------------

### 08 Jun 2023 | [ExplainableFold: Understanding AlphaFold Prediction with Explainable AI](https://arxiv.org/abs/2301.11765) | [⬇️](https://arxiv.org/pdf/2301.11765)
*Juntao Tan, Yongfeng Zhang* 

  This paper presents ExplainableFold, an explainable AI framework for protein
structure prediction. Despite the success of AI-based methods such as AlphaFold
in this field, the underlying reasons for their predictions remain unclear due
to the black-box nature of deep learning models. To address this, we propose a
counterfactual learning framework inspired by biological principles to generate
counterfactual explanations for protein structure prediction, enabling a
dry-lab experimentation approach. Our experimental results demonstrate the
ability of ExplainableFold to generate high-quality explanations for
AlphaFold's predictions, providing near-experimental understanding of the
effects of amino acids on 3D protein structure. This framework has the
potential to facilitate a deeper understanding of protein structures.

---------------

### 04 Oct 2023 | [A GPT-4 Reticular Chemist for Guiding MOF Discovery](https://arxiv.org/abs/2306.14915) | [⬇️](https://arxiv.org/pdf/2306.14915)
*Zhiling Zheng, Zichao Rong, Nakul Rampal, Christian Borgs, Jennifer T.  Chayes, Omar M. Yaghi* 

  We present a new framework integrating the AI model GPT-4 into the iterative
process of reticular chemistry experimentation, leveraging a cooperative
workflow of interaction between AI and a human researcher. This GPT-4 Reticular
Chemist is an integrated system composed of three phases. Each of these
utilizes GPT-4 in various capacities, wherein GPT-4 provides detailed
instructions for chemical experimentation and the human provides feedback on
the experimental outcomes, including both success and failures, for the
in-context learning of AI in the next iteration. This iterative human-AI
interaction enabled GPT-4 to learn from the outcomes, much like an experienced
chemist, by a prompt-learning strategy. Importantly, the system is based on
natural language for both development and operation, eliminating the need for
coding skills, and thus, make it accessible to all chemists. Our collaboration
with GPT-4 Reticular Chemist guided the discovery of an isoreticular series of
MOFs, with each synthesis fine-tuned through iterative feedback and expert
suggestions. This workflow presents a potential for broader applications in
scientific research by harnessing the capability of large language models like
GPT-4 to enhance the feasibility and efficiency of research activities.

---------------
**Date:** 11 Aug 2023

**Title:** Assessing Student Errors in Experimentation Using Artificial  Intelligence and Large Language Models: A Comparative Study with Human Raters

**Abstract Link:** [https://arxiv.org/abs/2308.06088](https://arxiv.org/abs/2308.06088)

**PDF Link:** [https://arxiv.org/pdf/2308.06088](https://arxiv.org/pdf/2308.06088)

---

**Date:** 09 Nov 2020

**Title:** An Experimentation Platform for Explainable Coalition Situational  Understanding

**Abstract Link:** [https://arxiv.org/abs/2010.14388](https://arxiv.org/abs/2010.14388)

**PDF Link:** [https://arxiv.org/pdf/2010.14388](https://arxiv.org/pdf/2010.14388)

---

**Date:** 14 Sep 2021

**Title:** Post-Selections in AI and How to Avoid Them

**Abstract Link:** [https://arxiv.org/abs/2106.13233](https://arxiv.org/abs/2106.13233)

**PDF Link:** [https://arxiv.org/pdf/2106.13233](https://arxiv.org/pdf/2106.13233)

---

**Date:** 19 Dec 2021

**Title:** Autonomous synthesis of metastable materials

**Abstract Link:** [https://arxiv.org/abs/2101.07385](https://arxiv.org/abs/2101.07385)

**PDF Link:** [https://arxiv.org/pdf/2101.07385](https://arxiv.org/pdf/2101.07385)

---

**Date:** 07 Dec 2023

**Title:** Evaluating Zero-Shot Scoring for In Vitro Antibody Binding Prediction  with Experimental Validation

**Abstract Link:** [https://arxiv.org/abs/2312.05273](https://arxiv.org/abs/2312.05273)

**PDF Link:** [https://arxiv.org/pdf/2312.05273](https://arxiv.org/pdf/2312.05273)

---

**Date:** 05 Oct 2023

**Title:** Benchmarking Large Language Models As AI Research Agents

**Abstract Link:** [https://arxiv.org/abs/2310.03302](https://arxiv.org/abs/2310.03302)

**PDF Link:** [https://arxiv.org/pdf/2310.03302](https://arxiv.org/pdf/2310.03302)

---

**Date:** 14 Sep 2023

**Title:** Preventing Unauthorized AI Over-Analysis by Medical Image Adversarial  Watermarking

**Abstract Link:** [https://arxiv.org/abs/2303.09858](https://arxiv.org/abs/2303.09858)

**PDF Link:** [https://arxiv.org/pdf/2303.09858](https://arxiv.org/pdf/2303.09858)

---

**Date:** 20 Dec 2023

**Title:** Agglomerative Federated Learning: Empowering Larger Model Training via  End-Edge-Cloud Collaboration

**Abstract Link:** [https://arxiv.org/abs/2312.11489](https://arxiv.org/abs/2312.11489)

**PDF Link:** [https://arxiv.org/pdf/2312.11489](https://arxiv.org/pdf/2312.11489)

---

**Date:** 08 Sep 2022

**Title:** Contextualizing Artificially Intelligent Morality: A Meta-Ethnography of  Top-Down, Bottom-Up, and Hybrid Models for Theoretical and Applied Ethics in  Artificial Intelligence

**Abstract Link:** [https://arxiv.org/abs/2204.07612](https://arxiv.org/abs/2204.07612)

**PDF Link:** [https://arxiv.org/pdf/2204.07612](https://arxiv.org/pdf/2204.07612)

---

**Date:** 01 Feb 2024

**Title:** The whack-a-mole governance challenge for AI-enabled synthetic biology:  literature review and emerging frameworks

**Abstract Link:** [https://arxiv.org/abs/2402.00312](https://arxiv.org/abs/2402.00312)

**PDF Link:** [https://arxiv.org/pdf/2402.00312](https://arxiv.org/pdf/2402.00312)

---

**Date:** 18 Dec 2023

**Title:** Human-Machine Teaming for UAVs: An Experimentation Platform

**Abstract Link:** [https://arxiv.org/abs/2312.11718](https://arxiv.org/abs/2312.11718)

**PDF Link:** [https://arxiv.org/pdf/2312.11718](https://arxiv.org/pdf/2312.11718)

---

**Date:** 04 Nov 2017

**Title:** Emergence of Language with Multi-agent Games: Learning to Communicate  with Sequences of Symbols

**Abstract Link:** [https://arxiv.org/abs/1705.11192](https://arxiv.org/abs/1705.11192)

**PDF Link:** [https://arxiv.org/pdf/1705.11192](https://arxiv.org/pdf/1705.11192)

---

**Date:** 26 Jan 2022

**Title:** SCAI-QReCC Shared Task on Conversational Question Answering

**Abstract Link:** [https://arxiv.org/abs/2201.11094](https://arxiv.org/abs/2201.11094)

**PDF Link:** [https://arxiv.org/pdf/2201.11094](https://arxiv.org/pdf/2201.11094)

---

**Date:** 29 Apr 2022

**Title:** Altruist: Argumentative Explanations through Local Interpretations of  Predictive Models

**Abstract Link:** [https://arxiv.org/abs/2010.07650](https://arxiv.org/abs/2010.07650)

**PDF Link:** [https://arxiv.org/pdf/2010.07650](https://arxiv.org/pdf/2010.07650)

---

**Date:** 30 Oct 2020

**Title:** Biomedical Concept Relatedness -- A large EHR-based benchmark

**Abstract Link:** [https://arxiv.org/abs/2010.16218](https://arxiv.org/abs/2010.16218)

**PDF Link:** [https://arxiv.org/pdf/2010.16218](https://arxiv.org/pdf/2010.16218)

---

**Date:** 14 May 2021

**Title:** Domestic waste detection and grasping points for robotic picking up

**Abstract Link:** [https://arxiv.org/abs/2105.06825](https://arxiv.org/abs/2105.06825)

**PDF Link:** [https://arxiv.org/pdf/2105.06825](https://arxiv.org/pdf/2105.06825)

---

**Date:** 19 Mar 2021

**Title:** Performance Analysis of Deep Learning Workloads on a Composable System

**Abstract Link:** [https://arxiv.org/abs/2103.10911](https://arxiv.org/abs/2103.10911)

**PDF Link:** [https://arxiv.org/pdf/2103.10911](https://arxiv.org/pdf/2103.10911)

---

**Date:** 01 Aug 2023

**Title:** Explaining and visualizing black-box models through counterfactual paths

**Abstract Link:** [https://arxiv.org/abs/2307.07764](https://arxiv.org/abs/2307.07764)

**PDF Link:** [https://arxiv.org/pdf/2307.07764](https://arxiv.org/pdf/2307.07764)

---

**Date:** 08 Jun 2023

**Title:** ExplainableFold: Understanding AlphaFold Prediction with Explainable AI

**Abstract Link:** [https://arxiv.org/abs/2301.11765](https://arxiv.org/abs/2301.11765)

**PDF Link:** [https://arxiv.org/pdf/2301.11765](https://arxiv.org/pdf/2301.11765)

---

**Date:** 04 Oct 2023

**Title:** A GPT-4 Reticular Chemist for Guiding MOF Discovery

**Abstract Link:** [https://arxiv.org/abs/2306.14915](https://arxiv.org/abs/2306.14915)

**PDF Link:** [https://arxiv.org/pdf/2306.14915](https://arxiv.org/pdf/2306.14915)

---

