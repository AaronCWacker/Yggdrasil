AI Research Culture 🌟

### 🔎 AI Research Culture 🌟

💻🤖

# AI Research Culture

## AI Research Culture

AI research culture is a set of shared values, beliefs, and practices that guide the work of AI researchers. It encompasses the way they communicate, collaborate, and make decisions, as well as their attitudes towards ethics, diversity, and inclusion. A strong AI research culture can foster innovation, creativity, and excellence, while a weak one can lead to confusion, conflict, and stagnation.

There are several key elements of a healthy AI research culture:

1. Openness and transparency: AI researchers should be encouraged to share their work openly and transparently, both within their own organizations and with the wider research community. This includes publishing their code, data, and findings in open-access repositories, and engaging in open discussions and debates about their work.
2. Collaboration and interdisciplinary: AI research is a highly interdisciplinary field that draws on insights and methods from many different domains. AI researchers should be open to collaborating with researchers from other fields, and should be willing to learn from and contribute to other disciplines.
3. Ethics and responsibility: AI research has the potential to have a profound impact on society, and AI researchers have a responsibility to ensure that their work is used ethically and responsibly. This means considering the potential consequences of their work, and taking steps to mitigate any negative impacts.
4. Diversity and inclusion: AI research benefits from a diverse range of perspectives and experiences, and AI researchers should be committed to promoting diversity and inclusion in their field. This means actively seeking out and valuing the contributions of people from different backgrounds, and creating an inclusive environment where everyone feels welcome and valued.
5. Continuous learning and improvement: AI research is a rapidly evolving field, and AI researchers should be committed to continuous learning and improvement. This means staying up-to-date with the latest research and developments, and seeking out opportunities to learn new skills and techniques.

Overall, a strong AI research culture is essential for fostering innovation, creativity, and excellence in the field. By promoting openness, collaboration, ethics, diversity, and continuous learning, AI researchers can create a vibrant and dynamic research community that drives progress and makes a positive impact on society.</s>
# 🩺🔍 Search Results
### 14 Nov 2022 | [An Analytics of Culture: Modeling Subjectivity, Scalability,  Contextuality, and Temporality](https://arxiv.org/abs/2211.07460) | [⬇️](https://arxiv.org/pdf/2211.07460)
*Nanne van Noord, Melvin Wevers, Tobias Blanke, Julia Noordegraaf,  Marcel Worring* 

  There is a bidirectional relationship between culture and AI; AI models are
increasingly used to analyse culture, thereby shaping our understanding of
culture. On the other hand, the models are trained on collections of cultural
artifacts thereby implicitly, and not always correctly, encoding expressions of
culture. This creates a tension that both limits the use of AI for analysing
culture and leads to problems in AI with respect to cultural complex issues
such as bias.
  One approach to overcome this tension is to more extensively take into
account the intricacies and complexities of culture. We structure our
discussion using four concepts that guide humanistic inquiry into culture:
subjectivity, scalability, contextuality, and temporality. We focus on these
concepts because they have not yet been sufficiently represented in AI
research. We believe that possible implementations of these aspects into AI
research leads to AI that better captures the complexities of culture. In what
follows, we briefly describe these four concepts and their absence in AI
research. For each concept, we define possible research challenges.

---------------

### 23 Nov 2023 | [The SocialAI School: Insights from Developmental Psychology Towards  Artificial Socio-Cultural Agents](https://arxiv.org/abs/2307.07871) | [⬇️](https://arxiv.org/pdf/2307.07871)
*Grgur Kova\v{c}, R\'emy Portelas, Peter Ford Dominey, Pierre-Yves  Oudeyer* 

  Developmental psychologists have long-established the importance of
socio-cognitive abilities in human intelligence. These abilities enable us to
enter, participate and benefit from human culture. AI research on social
interactive agents mostly concerns the emergence of culture in a multi-agent
setting (often without a strong grounding in developmental psychology). We
argue that AI research should be informed by psychology and study
socio-cognitive abilities enabling to enter a culture too. We discuss the
theories of Michael Tomasello and Jerome Bruner to introduce some of their
concepts to AI and outline key concepts and socio-cognitive abilities. We
present The SocialAI school - a tool including a customizable parameterized
uite of procedurally generated environments, which simplifies conducting
experiments regarding those concepts. We show examples of such experiments with
RL agents and Large Language Models. The main motivation of this work is to
engage the AI community around the problem of social intelligence informed by
developmental psychology, and to provide a tool to simplify first steps in this
direction. Refer to the project website for code and additional information:
https://sites.google.com/view/socialai-school.

---------------

### 05 Sep 2023 | [Exploring the Intersection of Complex Aesthetics and Generative AI for  Promoting Cultural Creativity in Rural China after the Post-Pandemic Era](https://arxiv.org/abs/2309.02136) | [⬇️](https://arxiv.org/pdf/2309.02136)
*Mengyao Guo, Xiaolin Zhang, Yuan Zhuang, Jing Chen, Pengfei Wang, Ze  Gao* 

  This paper explores using generative AI and aesthetics to promote cultural
creativity in rural China amidst COVID-19's impact. Through literature reviews,
case studies, surveys, and text analysis, it examines art and technology
applications in rural contexts and identifies key challenges. The study finds
artworks often fail to resonate locally, while reliance on external artists
limits sustainability. Hence, nurturing grassroots "artist villagers" through
AI is proposed. Our approach involves training machine learning on subjective
aesthetics to generate culturally relevant content. Interactive AI media can
also boost tourism while preserving heritage. This pioneering research puts
forth original perspectives on the intersection of AI and aesthetics to
invigorate rural culture. It advocates holistic integration of technology and
emphasizes AI's potential as a creative enabler versus replacement. Ultimately,
it lays the groundwork for further exploration of leveraging AI innovations to
empower rural communities. This timely study contributes to growing interest in
emerging technologies to address critical issues facing rural China.

---------------

### 29 Apr 2020 | [AI in society and culture: decision making and values](https://arxiv.org/abs/2005.02777) | [⬇️](https://arxiv.org/pdf/2005.02777)
*Katalin Feher and Asta Zelenkauskaite* 

  With the increased expectation of artificial intelligence, academic research
face complex questions of human-centred, responsible and trustworthy technology
embedded into society and culture. Several academic debates, social
consultations and impact studies are available to reveal the key aspects of the
changing human-machine ecosystem. To contribute to these studies, hundreds of
related academic sources are summarized below regarding AI-driven decisions and
valuable AI. In details, sociocultural filters, taxonomy of human-machine
decisions and perspectives of value-based AI are in the focus of this
literature review. For better understanding, it is proposed to invite
stakeholders in the prepared large-scale survey about the next generation AI
that investigates issues that go beyond the technology.

---------------

### 07 Dec 2022 | [Artificial Intelligence Security Competition (AISC)](https://arxiv.org/abs/2212.03412) | [⬇️](https://arxiv.org/pdf/2212.03412)
*Yinpeng Dong, Peng Chen, Senyou Deng, Lianji L, Yi Sun, Hanyu Zhao,  Jiaxing Li, Yunteng Tan, Xinyu Liu, Yangyi Dong, Enhui Xu, Jincai Xu, Shu Xu,  Xuelin Fu, Changfeng Sun, Haoliang Han, Xuchong Zhang, Shen Chen, Zhimin Sun,  Junyi Cao, Taiping Yao, Shouhong Ding, Yu Wu, Jian Lin, Tianpeng Wu, Ye Wang,  Yu Fu, Lin Feng, Kangkang Gao, Zeyu Liu, Yuanzhe Pang, Chengqi Duan, Huipeng  Zhou, Yajie Wang, Yuhang Zhao, Shangbo Wu, Haoran Lyu, Zhiyu Lin, Yifei Gao,  Shuang Li, Haonan Wang, Jitao Sang, Chen Ma, Junhao Zheng, Yijia Li, Chao  Shen, Chenhao Lin, Zhichao Cui, Guoshuai Liu, Huafeng Shi, Kun Hu, Mengxin  Zhang* 

  The security of artificial intelligence (AI) is an important research area
towards safe, reliable, and trustworthy AI systems. To accelerate the research
on AI security, the Artificial Intelligence Security Competition (AISC) was
organized by the Zhongguancun Laboratory, China Industrial Control Systems
Cyber Emergency Response Team, Institute for Artificial Intelligence, Tsinghua
University, and RealAI as part of the Zhongguancun International Frontier
Technology Innovation Competition (https://www.zgc-aisc.com/en). The
competition consists of three tracks, including Deepfake Security Competition,
Autonomous Driving Security Competition, and Face Recognition Security
Competition. This report will introduce the competition rules of these three
tracks and the solutions of top-ranking teams in each track.

---------------

### 13 Dec 2023 | [Culturally Responsive Artificial Intelligence -- Problems, Challenges  and Solutions](https://arxiv.org/abs/2312.08467) | [⬇️](https://arxiv.org/pdf/2312.08467)
*Natalia O\.zegalska-{\L}ukasik, Szymon {\L}ukasik* 

  In the contemporary interconnected world, the concept of cultural
responsibility occupies paramount importance. As the lines between nations
become less distinct, it is incumbent upon individuals, communities, and
institutions to assume the responsibility of safeguarding and valuing the
landscape of diverse cultures that constitute our global society. This paper
explores the socio-cultural and ethical challenges stemming from the
implementation of AI algorithms and highlights the necessity for their
culturally responsive development. It also offers recommendations on essential
elements required to enhance AI systems' adaptability to meet the demands of
contemporary multicultural societies. The paper highlights the need for further
multidisciplinary research to create AI models that effectively address these
challenges. It also advocates the significance of AI enculturation and
underlines the importance of regulatory measures to promote cultural
responsibility in AI systems.

---------------

### 25 Apr 2023 | [Towards a Praxis for Intercultural Ethics in Explainable AI](https://arxiv.org/abs/2304.11861) | [⬇️](https://arxiv.org/pdf/2304.11861)
*Chinasa T. Okolo* 

  Explainable AI (XAI) is often promoted with the idea of helping users
understand how machine learning models function and produce predictions. Still,
most of these benefits are reserved for those with specialized domain
knowledge, such as machine learning developers. Recent research has argued that
making AI explainable can be a viable way of making AI more useful in
real-world contexts, especially within low-resource domains in the Global
South. While AI has transcended borders, a limited amount of work focuses on
democratizing the concept of explainable AI to the "majority world", leaving
much room to explore and develop new approaches within this space that cater to
the distinct needs of users within culturally and socially-diverse regions.
This article introduces the concept of an intercultural ethics approach to AI
explainability. It examines how cultural nuances impact the adoption and use of
technology, the factors that impede how technical concepts such as AI are
explained, and how integrating an intercultural ethics approach in the
development of XAI can improve user understanding and facilitate efficient
usage of these methods.

---------------

### 02 Dec 2021 | [On Two XAI Cultures: A Case Study of Non-technical Explanations in  Deployed AI System](https://arxiv.org/abs/2112.01016) | [⬇️](https://arxiv.org/pdf/2112.01016)
*Helen Jiang, Erwen Senge* 

  Explainable AI (XAI) research has been booming, but the question "$\textbf{To
whom}$ are we making AI explainable?" is yet to gain sufficient attention. Not
much of XAI is comprehensible to non-AI experts, who nonetheless, are the
primary audience and major stakeholders of deployed AI systems in practice. The
gap is glaring: what is considered "explained" to AI-experts versus non-experts
are very different in practical scenarios. Hence, this gap produced two
distinct cultures of expectations, goals, and forms of XAI in real-life AI
deployments.
  We advocate that it is critical to develop XAI methods for non-technical
audiences. We then present a real-life case study, where AI experts provided
non-technical explanations of AI decisions to non-technical stakeholders, and
completed a successful deployment in a highly regulated industry. We then
synthesize lessons learned from the case, and share a list of suggestions for
AI experts to consider when explaining AI decisions to non-technical
stakeholders.

---------------

### 13 Feb 2024 | [Towards Equitable Agile Research and Development of AI and Robotics](https://arxiv.org/abs/2402.08242) | [⬇️](https://arxiv.org/pdf/2402.08242)
*Andrew Hundt, Julia Schuller, Severin Kacianka* 

  Machine Learning (ML) and 'Artificial Intelligence' ('AI') methods tend to
replicate and amplify existing biases and prejudices, as do Robots with AI. For
example, robots with facial recognition have failed to identify Black Women as
human, while others have categorized people, such as Black Men, as criminals
based on appearance alone. A 'culture of modularity' means harms are perceived
as 'out of scope', or someone else's responsibility, throughout employment
positions in the 'AI supply chain'. Incidents are routine enough
(incidentdatabase.ai lists over 2000 examples) to indicate that few
organizations are capable of completely respecting peoples' rights; meeting
claimed equity, diversity, and inclusion (EDI or DEI) goals; or recognizing and
then addressing such failures in their organizations and artifacts. We propose
a framework for adapting widely practiced Research and Development (R&D)
project management methodologies to build organizational equity capabilities
and better integrate known evidence-based best practices. We describe how
project teams can organize and operationalize the most promising practices,
skill sets, organizational cultures, and methods to detect and address
rights-based fairness, equity, accountability, and ethical problems as early as
possible when they are often less harmful and easier to mitigate; then monitor
for unforeseen incidents to adaptively and constructively address them. Our
primary example adapts an Agile development process based on Scrum, one of the
most widely adopted approaches to organizing R&D teams. We also discuss
limitations of our proposed framework and future research directions.

---------------

### 15 Nov 2021 | [aiSTROM -- A roadmap for developing a successful AI strategy](https://arxiv.org/abs/2107.06071) | [⬇️](https://arxiv.org/pdf/2107.06071)
*Dorien Herremans* 

  A total of 34% of AI research and development projects fails or are
abandoned, according to a recent survey by Rackspace Technology of 1,870
companies. We propose a new strategic framework, aiSTROM, that empowers
managers to create a successful AI strategy based on a thorough literature
review. This provides a unique and integrated approach that guides managers and
lead developers through the various challenges in the implementation process.
In the aiSTROM framework, we start by identifying the top n potential projects
(typically 3-5). For each of those, seven areas of focus are thoroughly
analysed. These areas include creating a data strategy that takes into account
unique cross-departmental machine learning data requirements, security, and
legal requirements. aiSTROM then guides managers to think about how to put
together an interdisciplinary artificial intelligence (AI) implementation team
given the scarcity of AI talent. Once an AI team strategy has been established,
it needs to be positioned within the organization, either cross-departmental or
as a separate division. Other considerations include AI as a service (AIaas),
or outsourcing development. Looking at new technologies, we have to consider
challenges such as bias, legality of black-box-models, and keeping humans in
the loop. Next, like any project, we need value-based key performance
indicators (KPIs) to track and validate the progress. Depending on the
company's risk-strategy, a SWOT analysis (strengths, weaknesses, opportunities,
and threats) can help further classify the shortlisted projects. Finally, we
should make sure that our strategy includes continuous education of employees
to enable a culture of adoption. This unique and comprehensive framework offers
a valuable, literature supported, tool for managers and lead developers.

---------------

### 06 Oct 2021 | [A curated, ontology-based, large-scale knowledge graph of artificial  intelligence tasks and benchmarks](https://arxiv.org/abs/2110.01434) | [⬇️](https://arxiv.org/pdf/2110.01434)
*Kathrin Blagec, Adriano Barbosa-Silva, Simon Ott, Matthias Samwald* 

  Research in artificial intelligence (AI) is addressing a growing number of
tasks through a rapidly growing number of models and methodologies. This makes
it difficult to keep track of where novel AI methods are successfully -- or
still unsuccessfully -- applied, how progress is measured, how different
advances might synergize with each other, and how future research should be
prioritized.
  To help address these issues, we created the Intelligence Task Ontology and
Knowledge Graph (ITO), a comprehensive, richly structured and manually curated
resource on artificial intelligence tasks, benchmark results and performance
metrics. The current version of ITO contain 685,560 edges, 1,100 classes
representing AI processes and 1,995 properties representing performance
metrics.
  The goal of ITO is to enable precise and network-based analyses of the global
landscape of AI tasks and capabilities. ITO is based on technologies that allow
for easy integration and enrichment with external data, automated inference and
continuous, collaborative expert curation of underlying ontological models. We
make the ITO dataset and a collection of Jupyter notebooks utilising ITO openly
available.

---------------

### 21 Feb 2024 | [Explain to Question not to Justify](https://arxiv.org/abs/2402.13914) | [⬇️](https://arxiv.org/pdf/2402.13914)
*Przemyslaw Biecek, Wojciech Samek* 

  Explainable Artificial Intelligence (XAI) is a young but very promising field
of research. Unfortunately, the progress in this field is currently slowed down
by divergent and incompatible goals. In this paper, we separate various threads
tangled within the area of XAI into two complementary cultures of
human/value-oriented explanations (BLUE XAI) and model/validation-oriented
explanations (RED XAI). We also argue that the area of RED XAI is currently
under-explored and hides great opportunities and potential for important
research necessary to ensure the safety of AI systems. We conclude this paper
by presenting promising challenges in this area.

---------------

### 30 Oct 2020 | [A New Neural Search and Insights Platform for Navigating and Organizing  AI Research](https://arxiv.org/abs/2011.00061) | [⬇️](https://arxiv.org/pdf/2011.00061)
*Marzieh Fadaee, Olga Gureenkova, Fernando Rejon Barrera, Carsten  Schnober, Wouter Weerkamp, Jakub Zavrel* 

  To provide AI researchers with modern tools for dealing with the explosive
growth of the research literature in their field, we introduce a new platform,
AI Research Navigator, that combines classical keyword search with neural
retrieval to discover and organize relevant literature. The system provides
search at multiple levels of textual granularity, from sentences to
aggregations across documents, both in natural language and through navigation
in a domain-specific Knowledge Graph. We give an overview of the overall
architecture of the system and of the components for document analysis,
question answering, search, analytics, expert search, and recommendations.

---------------

### 07 Jun 2023 | [Art and the science of generative AI: A deeper dive](https://arxiv.org/abs/2306.04141) | [⬇️](https://arxiv.org/pdf/2306.04141)
*Ziv Epstein, Aaron Hertzmann, Laura Herman, Robert Mahari, Morgan R.  Frank, Matthew Groh, Hope Schroeder, Amy Smith, Memo Akten, Jessica Fjeld,  Hany Farid, Neil Leach, Alex Pentland, and Olga Russakovsky* 

  A new class of tools, colloquially called generative AI, can produce
high-quality artistic media for visual arts, concept art, music, fiction,
literature, video, and animation. The generative capabilities of these tools
are likely to fundamentally alter the creative processes by which creators
formulate ideas and put them into production. As creativity is reimagined, so
too may be many sectors of society. Understanding the impact of generative AI -
and making policy decisions around it - requires new interdisciplinary
scientific inquiry into culture, economics, law, algorithms, and the
interaction of technology and creativity. We argue that generative AI is not
the harbinger of art's demise, but rather is a new medium with its own distinct
affordances. In this vein, we consider the impacts of this new medium on
creators across four themes: aesthetics and culture, legal questions of
ownership and credit, the future of creative work, and impacts on the
contemporary media ecosystem. Across these themes, we highlight key research
questions and directions to inform policy and beneficial uses of the
technology.

---------------

### 17 Jan 2020 | [Activism by the AI Community: Analysing Recent Achievements and Future  Prospects](https://arxiv.org/abs/2001.06528) | [⬇️](https://arxiv.org/pdf/2001.06528)
*Haydn Belfield* 

  The artificial intelligence community (AI) has recently engaged in activism
in relation to their employers, other members of the community, and their
governments in order to shape the societal and ethical implications of AI. It
has achieved some notable successes, but prospects for further political
organising and activism are uncertain. We survey activism by the AI community
over the last six years; apply two analytical frameworks drawing upon the
literature on epistemic communities, and worker organising and bargaining; and
explore what they imply for the future prospects of the AI community. Success
thus far has hinged on a coherent shared culture, and high bargaining power due
to the high demand for a limited supply of AI talent. Both are crucial to the
future of AI activism and worthy of sustained attention.

---------------

### 03 Jun 2022 | [Vision-and-Language Navigation: A Survey of Tasks, Methods, and Future  Directions](https://arxiv.org/abs/2203.12667) | [⬇️](https://arxiv.org/pdf/2203.12667)
*Jing Gu, Eliana Stefani, Qi Wu, Jesse Thomason, Xin Eric Wang* 

  A long-term goal of AI research is to build intelligent agents that can
communicate with humans in natural language, perceive the environment, and
perform real-world tasks. Vision-and-Language Navigation (VLN) is a fundamental
and interdisciplinary research topic towards this goal, and receives increasing
attention from natural language processing, computer vision, robotics, and
machine learning communities. In this paper, we review contemporary studies in
the emerging field of VLN, covering tasks, evaluation metrics, methods, etc.
Through structured analysis of current progress and challenges, we highlight
the limitations of current VLN and opportunities for future work. This paper
serves as a thorough reference for the VLN research community.

---------------

### 11 Jul 2023 | [Has China caught up to the US in AI research? An exploration of mimetic  isomorphism as a model for late industrializers](https://arxiv.org/abs/2307.10198) | [⬇️](https://arxiv.org/pdf/2307.10198)
*Chao Min, Yi Zhao, Yi Bu, Ying Ding, Caroline S. Wagner* 

  Artificial Intelligence (AI), a cornerstone of 21st-century technology, has
seen remarkable growth in China. In this paper, we examine China's AI
development process, demonstrating that it is characterized by rapid learning
and differentiation, surpassing the export-oriented growth propelled by Foreign
Direct Investment seen in earlier Asian industrializers.
  Our data indicates that China currently leads the USA in the volume of
AI-related research papers. However, when we delve into the quality of these
papers based on specific metrics, the USA retains a slight edge. Nevertheless,
the pace and scale of China's AI development remain noteworthy.
  We attribute China's accelerated AI progress to several factors, including
global trends favoring open access to algorithms and research papers,
contributions from China's broad diaspora and returnees, and relatively lax
data protection policies.
  In the vein of our research, we have developed a novel measure for gauging
China's imitation of US research. Our analysis shows that by 2018, the time lag
between China and the USA in addressing AI research topics had evaporated. This
finding suggests that China has effectively bridged a significant knowledge gap
and could potentially be setting out on an independent research trajectory.
  While this study compares China and the USA exclusively, it's important to
note that research collaborations between these two nations have resulted in
more highly cited work than those produced by either country independently.
This underscores the power of international cooperation in driving scientific
progress in AI.

---------------

### 10 Nov 2021 | [Internationalizing AI: Evolution and Impact of Distance Factors](https://arxiv.org/abs/2112.01231) | [⬇️](https://arxiv.org/pdf/2112.01231)
*Xuli Tang, Xin Li, Feicheng Ma* 

  International collaboration has become imperative in the field of AI.
However, few studies exist concerning how distance factors have affected the
international collaboration in AI research. In this study, we investigate this
problem by using 1,294,644 AI related collaborative papers harvested from the
Microsoft Academic Graph (MAG) dataset. A framework including 13 indicators to
quantify the distance factors between countries from 5 perspectives (i.e.,
geographic distance, economic distance, cultural distance, academic distance,
and industrial distance) is proposed. The relationships were conducted by the
methods of descriptive analysis and regression analysis. The results show that
international collaboration in the field of AI today is not prevalent (only
15.7%). All the separations in international collaborations have increased over
years, except for the cultural distance in masculinity/felinity dimension and
the industrial distance. The geographic distance, economic distance and
academic distances have shown significantly negative relationships with the
degree of international collaborations in the field of AI. The industrial
distance has a significant positive relationship with the degree of
international collaboration in the field of AI. Also, the results demonstrate
that the participation of the United States and China have promoted the
international collaboration in the field of AI. This study provides a
comprehensive understanding of internationalizing AI research in geographic,
economic, cultural, academic, and industrial aspects.

---------------

### 04 Nov 2022 | [MONAI: An open-source framework for deep learning in healthcare](https://arxiv.org/abs/2211.02701) | [⬇️](https://arxiv.org/pdf/2211.02701)
*M. Jorge Cardoso, Wenqi Li, Richard Brown, Nic Ma, Eric Kerfoot,  Yiheng Wang, Benjamin Murrey, Andriy Myronenko, Can Zhao, Dong Yang, Vishwesh  Nath, Yufan He, Ziyue Xu, Ali Hatamizadeh, Andriy Myronenko, Wentao Zhu, Yun  Liu, Mingxin Zheng, Yucheng Tang, Isaac Yang, Michael Zephyr, Behrooz  Hashemian, Sachidanand Alle, Mohammad Zalbagi Darestani, Charlie Budd, Marc  Modat, Tom Vercauteren, Guotai Wang, Yiwen Li, Yipeng Hu, Yunguan Fu,  Benjamin Gorman, Hans Johnson, Brad Genereaux, Barbaros S. Erdal, Vikash  Gupta, Andres Diaz-Pinto, Andre Dourson, Lena Maier-Hein, Paul F. Jaeger,  Michael Baumgartner, Jayashree Kalpathy-Cramer, Mona Flores, Justin Kirby,  Lee A.D. Cooper, Holger R. Roth, Daguang Xu, David Bericat, Ralf Floca, S.  Kevin Zhou, Haris Shuaib, Keyvan Farahani, Klaus H. Maier-Hein, Stephen  Aylward, Prerna Dogra, Sebastien Ourselin, Andrew Feng* 

  Artificial Intelligence (AI) is having a tremendous impact across most areas
of science. Applications of AI in healthcare have the potential to improve our
ability to detect, diagnose, prognose, and intervene on human disease. For AI
models to be used clinically, they need to be made safe, reproducible and
robust, and the underlying software framework must be aware of the
particularities (e.g. geometry, physiology, physics) of medical data being
processed. This work introduces MONAI, a freely available, community-supported,
and consortium-led PyTorch-based framework for deep learning in healthcare.
MONAI extends PyTorch to support medical data, with a particular focus on
imaging, and provide purpose-specific AI model architectures, transformations
and utilities that streamline the development and deployment of medical AI
models. MONAI follows best practices for software-development, providing an
easy-to-use, robust, well-documented, and well-tested software framework. MONAI
preserves the simple, additive, and compositional approach of its underlying
PyTorch libraries. MONAI is being used by and receiving contributions from
research, clinical and industrial teams from around the world, who are pursuing
applications spanning nearly every aspect of healthcare.

---------------

### 14 Apr 2005 | [Proceedings of the Pacific Knowledge Acquisition Workshop 2004](https://arxiv.org/abs/cs/0504071) | [⬇️](https://arxiv.org/pdf/cs/0504071)
*Byeong Ho Kang, Achim Hoffmann, Takahira Yamaguchi, Wai Kiang Yeap* 

  Artificial intelligence (AI) research has evolved over the last few decades
and knowledge acquisition research is at the core of AI research. PKAW-04 is
one of three international knowledge acquisition workshops held in the
Pacific-Rim, Canada and Europe over the last two decades. PKAW-04 has a strong
emphasis on incremental knowledge acquisition, machine learning, neural nets
and active mining.
  The proceedings contain 19 papers that were selected by the program committee
among 24 submitted papers. All papers were peer reviewed by at least two
reviewers. The papers in these proceedings cover the methods and tools as well
as the applications related to develop expert systems or knowledge based
systems.

---------------
