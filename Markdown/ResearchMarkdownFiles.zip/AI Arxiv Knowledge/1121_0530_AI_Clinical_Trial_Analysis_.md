AI Clinical Trial Analysis 🏥

### 🔎 AI Clinical Trial Analysis 🏥



# AI Clinical Trial Analysis 🏥

## AI Clinical Trial Analysis 🏥

Clinical trials are a critical part of the drug development process, but they can be expensive and time-consuming. Artificial intelligence (AI) is being used to analyze clinical trial data to help speed up the process and make it more efficient.

AI can be used to analyze large amounts of data from clinical trials, including patient demographics, medical history, and lab results. This analysis can help identify patterns and trends that might not be apparent to human researchers. For example, AI can be used to identify which patients are most likely to respond to a particular treatment, or which patients are at the highest risk of side effects.

AI can also be used to predict which clinical trials are likely to be successful, based on the characteristics of the patients and the drug being tested. This can help drug companies prioritize their resources and focus on the most promising trials.

In addition, AI can be used to monitor clinical trials in real-time, allowing researchers to quickly identify and address any issues that arise. This can help ensure that the trial is conducted safely and efficiently, and that the results are accurate and reliable.

Overall, AI is a powerful tool that can help improve the efficiency and effectiveness of clinical trials. By analyzing large amounts of data and identifying patterns and trends, AI can help researchers make more informed decisions and improve the chances of success for new drugs.</s>
# 🩺🔍 Search Results
### 28 Jul 2023 | [Matching Patients to Clinical Trials with Large Language Models](https://arxiv.org/abs/2307.15051) | [⬇️](https://arxiv.org/pdf/2307.15051)
*Qiao Jin, Zifeng Wang, Charalampos S. Floudas, Jimeng Sun, Zhiyong Lu* 

  Clinical trials are vital in advancing drug development and evidence-based
medicine, but their success is often hindered by challenges in patient
recruitment. In this work, we investigate the potential of large language
models (LLMs) to assist individual patients and referral physicians in
identifying suitable clinical trials from an extensive selection. Specifically,
we introduce TrialGPT, a novel architecture employing LLMs to predict
criterion-level eligibility with detailed explanations, which are then
aggregated for ranking and excluding candidate clinical trials based on
free-text patient notes. We evaluate TrialGPT on three publicly available
cohorts of 184 patients and 18,238 annotated clinical trials. The experimental
results demonstrate several key findings: First, TrialGPT achieves high
criterion-level prediction accuracy with faithful explanations. Second, the
aggregated trial-level TrialGPT scores are highly correlated with expert
eligibility annotations. Third, these scores prove effective in ranking
clinical trials and exclude ineligible candidates. Our error analysis suggests
that current LLMs still make some mistakes due to limited medical knowledge and
domain-specific context understanding. Nonetheless, we believe the explanatory
capabilities of LLMs are highly valuable. Future research is warranted on how
such AI assistants can be integrated into the routine trial matching workflow
in real-world settings to improve its efficiency.

---------------

### 16 Sep 2022 | [Artificial Intelligence for In Silico Clinical Trials: A Review](https://arxiv.org/abs/2209.09023) | [⬇️](https://arxiv.org/pdf/2209.09023)
*Zifeng Wang, Chufan Gao, Lucas M. Glass, Jimeng Sun* 

  A clinical trial is an essential step in drug development, which is often
costly and time-consuming. In silico trials are clinical trials conducted
digitally through simulation and modeling as an alternative to traditional
clinical trials. AI-enabled in silico trials can increase the case group size
by creating virtual cohorts as controls. In addition, it also enables
automation and optimization of trial design and predicts the trial success
rate. This article systematically reviews papers under three main topics:
clinical simulation, individualized predictive modeling, and computer-aided
trial design. We focus on how machine learning (ML) may be applied in these
applications. In particular, we present the machine learning problem
formulation and available data sources for each task. We end with discussing
the challenges and opportunities of AI for in silico trials in real-world
applications.

---------------

### 07 Sep 2021 | [A Scalable AI Approach for Clinical Trial Cohort Optimization](https://arxiv.org/abs/2109.02808) | [⬇️](https://arxiv.org/pdf/2109.02808)
*Xiong Liu, Cheng Shi, Uday Deore, Yingbo Wang, Myah Tran, Iya Khalil,  Murthy Devarakonda* 

  FDA has been promoting enrollment practices that could enhance the diversity
of clinical trial populations, through broadening eligibility criteria.
However, how to broaden eligibility remains a significant challenge. We propose
an AI approach to Cohort Optimization (AICO) through transformer-based natural
language processing of the eligibility criteria and evaluation of the criteria
using real-world data. The method can extract common eligibility criteria
variables from a large set of relevant trials and measure the generalizability
of trial designs to real-world patients. It overcomes the scalability limits of
existing manual methods and enables rapid simulation of eligibility criteria
design for a disease of interest. A case study on breast cancer trial design
demonstrates the utility of the method in improving trial generalizability.

---------------

### 22 Jan 2024 | [Revolutionizing Pharma: Unveiling the AI and LLM Trends in the  Pharmaceutical Industry](https://arxiv.org/abs/2401.10273) | [⬇️](https://arxiv.org/pdf/2401.10273)
*Yu Han, Jingwen Tao* 

  This document offers a critical overview of the emerging trends and
significant advancements in artificial intelligence (AI) within the
pharmaceutical industry. Detailing its application across key operational
areas, including research and development, animal testing, clinical trials,
hospital clinical stages, production, regulatory affairs, quality control and
other supporting areas, the paper categorically examines AI's role in each
sector. Special emphasis is placed on cutting-edge AI technologies like machine
learning algorithms and their contributions to various aspects of
pharmaceutical operations. Through this comprehensive analysis, the paper
highlights the transformative potential of AI in reshaping the pharmaceutical
industry's future.

---------------

### 17 Aug 2023 | [Data diversity and virtual imaging in AI-based diagnosis: A case study  based on COVID-19](https://arxiv.org/abs/2308.09730) | [⬇️](https://arxiv.org/pdf/2308.09730)
*Fakrul Islam Tushar, Lavsen Dahal, Saman Sotoudeh-Paima, Ehsan Abadi,  W. Paul Segars, Ehsan Samei, Joseph Y. Lo* 

  Many studies have investigated deep-learning-based artificial intelligence
(AI) models for medical imaging diagnosis of the novel coronavirus (COVID-19),
with many reports of near-perfect performance. However, variability in
performance and underlying data biases raise concerns about clinical
generalizability. This retrospective study involved the development and
evaluation of artificial intelligence (AI) models for COVID-19 diagnosis using
both diverse clinical and virtually generated medical images. In addition, we
conducted a virtual imaging trial to assess how AI performance is affected by
several patient- and physics-based factors, including the extent of disease,
radiation dose, and imaging modality of computed tomography (CT) and chest
radiography (CXR). AI performance was strongly influenced by dataset
characteristics including quantity, diversity, and prevalence, leading to poor
generalization with up to 20% drop in receiver operating characteristic area
under the curve. Model performance on virtual CT and CXR images was comparable
to overall results on clinical data. Imaging dose proved to have negligible
influence on the results, but the extent of the disease had a marked affect. CT
results were consistently superior to those from CXR. Overall, the study
highlighted the significant impact of dataset characteristics and disease
extent on COVID assessment, and the relevance and potential role of virtual
imaging trial techniques on developing effective evaluation of AI algorithms
and facilitating translation into diagnostic practice.

---------------

### 02 Feb 2021 | [Applications of artificial intelligence in drug development using  real-world data](https://arxiv.org/abs/2101.08904) | [⬇️](https://arxiv.org/pdf/2101.08904)
*Zhaoyi Chen, Xiong Liu, William Hogan, Elizabeth Shenkman, Jiang Bian* 

  The US Food and Drug Administration (FDA) has been actively promoting the use
of real-world data (RWD) in drug development. RWD can generate important
real-world evidence reflecting the real-world clinical environment where the
treatments are used. Meanwhile, artificial intelligence (AI), especially
machine- and deep-learning (ML/DL) methods, have been increasingly used across
many stages of the drug development process. Advancements in AI have also
provided new strategies to analyze large, multidimensional RWD. Thus, we
conducted a rapid review of articles from the past 20 years, to provide an
overview of the drug development studies that use both AI and RWD. We found
that the most popular applications were adverse event detection, trial
recruitment, and drug repurposing. Here, we also discuss current research gaps
and future opportunities.

---------------

### 03 Nov 2023 | [Towards objective and systematic evaluation of bias in medical imaging  AI](https://arxiv.org/abs/2311.02115) | [⬇️](https://arxiv.org/pdf/2311.02115)
*Emma A.M. Stanley, Raissa Souza, Anthony Winder, Vedant Gulve,  Kimberly Amador, Matthias Wilms, Nils D. Forkert* 

  Artificial intelligence (AI) models trained using medical images for clinical
tasks often exhibit bias in the form of disparities in performance between
subgroups. Since not all sources of biases in real-world medical imaging data
are easily identifiable, it is challenging to comprehensively assess how those
biases are encoded in models, and how capable bias mitigation methods are at
ameliorating performance disparities. In this article, we introduce a novel
analysis framework for systematically and objectively investigating the impact
of biases in medical images on AI models. We developed and tested this
framework for conducting controlled in silico trials to assess bias in medical
imaging AI using a tool for generating synthetic magnetic resonance images with
known disease effects and sources of bias. The feasibility is showcased by
using three counterfactual bias scenarios to measure the impact of simulated
bias effects on a convolutional neural network (CNN) classifier and the
efficacy of three bias mitigation strategies. The analysis revealed that the
simulated biases resulted in expected subgroup performance disparities when the
CNN was trained on the synthetic datasets. Moreover, reweighing was identified
as the most successful bias mitigation strategy for this setup, and we
demonstrated how explainable AI methods can aid in investigating the
manifestation of bias in the model using this framework. Developing fair AI
models is a considerable challenge given that many and often unknown sources of
biases can be present in medical imaging datasets. In this work, we present a
novel methodology to objectively study the impact of biases and mitigation
strategies on deep learning pipelines, which can support the development of
clinical AI that is robust and responsible.

---------------

### 27 Oct 2023 | [Knowledge-based in silico models and dataset for the comparative  evaluation of mammography AI for a range of breast characteristics, lesion  conspicuities and doses](https://arxiv.org/abs/2310.18494) | [⬇️](https://arxiv.org/pdf/2310.18494)
*Elena Sizikova, Niloufar Saharkhiz, Diksha Sharma, Miguel Lago,  Berkman Sahiner, Jana G. Delfino, Aldo Badano* 

  To generate evidence regarding the safety and efficacy of artificial
intelligence (AI) enabled medical devices, AI models need to be evaluated on a
diverse population of patient cases, some of which may not be readily
available. We propose an evaluation approach for testing medical imaging AI
models that relies on in silico imaging pipelines in which stochastic digital
models of human anatomy (in object space) with and without pathology are imaged
using a digital replica imaging acquisition system to generate realistic
synthetic image datasets. Here, we release M-SYNTH, a dataset of cohorts with
four breast fibroglandular density distributions imaged at different exposure
levels using Monte Carlo x-ray simulations with the publicly available Virtual
Imaging Clinical Trial for Regulatory Evaluation (VICTRE) toolkit. We utilize
the synthetic dataset to analyze AI model performance and find that model
performance decreases with increasing breast density and increases with higher
mass density, as expected. As exposure levels decrease, AI model performance
drops with the highest performance achieved at exposure levels lower than the
nominal recommended dose for the breast type.

---------------

### 13 Jun 2023 | [Multi-Task Training with In-Domain Language Models for Diagnostic  Reasoning](https://arxiv.org/abs/2306.04551) | [⬇️](https://arxiv.org/pdf/2306.04551)
*Brihat Sharma, Yanjun Gao, Timothy Miller, Matthew M. Churpek, Majid  Afshar and Dmitriy Dligach* 

  Generative artificial intelligence (AI) is a promising direction for
augmenting clinical diagnostic decision support and reducing diagnostic errors,
a leading contributor to medical errors. To further the development of clinical
AI systems, the Diagnostic Reasoning Benchmark (DR.BENCH) was introduced as a
comprehensive generative AI framework, comprised of six tasks representing key
components in clinical reasoning. We present a comparative analysis of
in-domain versus out-of-domain language models as well as multi-task versus
single task training with a focus on the problem summarization task in DR.BENCH
(Gao et al., 2023). We demonstrate that a multi-task, clinically trained
language model outperforms its general domain counterpart by a large margin,
establishing a new state-of-the-art performance, with a ROUGE-L score of 28.55.
This research underscores the value of domain-specific training for optimizing
clinical diagnostic reasoning tasks.

---------------

### 22 Jan 2021 | [Chemistry42: An AI-based platform for de novo molecular design](https://arxiv.org/abs/2101.09050) | [⬇️](https://arxiv.org/pdf/2101.09050)
*Yan A. Ivanenkov, Alex Zhebrak, Dmitry Bezrukov, Bogdan Zagribelnyy,  Vladimir Aladinskiy, Daniil Polykovskiy, Evgeny Putin, Petrina Kamya,  Alexander Aliper, Alex Zhavoronkov* 

  Chemistry42 is a software platform for de novo small molecule design that
integrates Artificial Intelligence (AI) techniques with computational and
medicinal chemistry methods. Chemistry42 is unique in its ability to generate
novel molecular structures with predefined properties validated through in
vitro and in vivo studies. Chemistry42 is a core component of Insilico Medicine
Pharma.ai drug discovery suite that also includes target discovery and
multi-omics data analysis (PandaOmics) and clinical trial outcomes predictions
(InClinico).

---------------

### 19 Jun 2023 | [Artificial intelligence in digital pathology: a diagnostic test accuracy  systematic review and meta-analysis](https://arxiv.org/abs/2306.07999) | [⬇️](https://arxiv.org/pdf/2306.07999)
*Clare McGenity, Emily L Clarke, Charlotte Jennings, Gillian Matthews,  Caroline Cartlidge, Henschel Freduah-Agyemang, Deborah D Stocken, Darren  Treanor* 

  Ensuring diagnostic performance of AI models before clinical use is key to
the safe and successful adoption of these technologies. Studies reporting AI
applied to digital pathology images for diagnostic purposes have rapidly
increased in number in recent years. The aim of this work is to provide an
overview of the diagnostic accuracy of AI in digital pathology images from all
areas of pathology. This systematic review and meta-analysis included
diagnostic accuracy studies using any type of artificial intelligence applied
to whole slide images (WSIs) in any disease type. The reference standard was
diagnosis through histopathological assessment and / or immunohistochemistry.
Searches were conducted in PubMed, EMBASE and CENTRAL in June 2022. We
identified 2976 studies, of which 100 were included in the review and 48 in the
full meta-analysis. Risk of bias and concerns of applicability were assessed
using the QUADAS-2 tool. Data extraction was conducted by two investigators and
meta-analysis was performed using a bivariate random effects model. 100 studies
were identified for inclusion, equating to over 152,000 whole slide images
(WSIs) and representing many disease types. Of these, 48 studies were included
in the meta-analysis. These studies reported a mean sensitivity of 96.3% (CI
94.1-97.7) and mean specificity of 93.3% (CI 90.5-95.4) for AI. There was
substantial heterogeneity in study design and all 100 studies identified for
inclusion had at least one area at high or unclear risk of bias. This review
provides a broad overview of AI performance across applications in whole slide
imaging. However, there is huge variability in study design and available
performance data, with details around the conduct of the study and make up of
the datasets frequently missing. Overall, AI offers good accuracy when applied
to WSIs but requires more rigorous evaluation of its performance.

---------------

### 06 Apr 2020 | [Bridging the gap between AI and Healthcare sides: towards developing  clinically relevant AI-powered diagnosis systems](https://arxiv.org/abs/2001.03923) | [⬇️](https://arxiv.org/pdf/2001.03923)
*Changhee Han, Leonardo Rundo, Kohei Murao, Takafumi Nemoto, Hideki  Nakayama* 

  Despite the success of Convolutional Neural Network-based Computer-Aided
Diagnosis research, its clinical applications remain challenging. Accordingly,
developing medical Artificial Intelligence (AI) fitting into a clinical
environment requires identifying/bridging the gap between AI and Healthcare
sides. Since the biggest problem in Medical Imaging lies in data paucity,
confirming the clinical relevance for diagnosis of research-proven image
augmentation techniques is essential. Therefore, we hold a clinically valuable
AI-envisioning workshop among Japanese Medical Imaging experts, physicians, and
generalists in Healthcare/Informatics. Then, a questionnaire survey for
physicians evaluates our pathology-aware Generative Adversarial Network
(GAN)-based image augmentation projects in terms of Data Augmentation and
physician training. The workshop reveals the intrinsic gap between
AI/Healthcare sides and solutions on Why (i.e., clinical
significance/interpretation) and How (i.e., data acquisition, commercial
deployment, and safety/feeling safe). This analysis confirms our
pathology-aware GANs' clinical relevance as a clinical decision support system
and non-expert physician training tool. Our findings would play a key role in
connecting inter-disciplinary research and clinical applications, not limited
to the Japanese medical context and pathology-aware GANs.

---------------

### 30 Nov 2023 | [AI in Pharma for Personalized Sequential Decision-Making: Methods,  Applications and Opportunities](https://arxiv.org/abs/2311.18725) | [⬇️](https://arxiv.org/pdf/2311.18725)
*Yuhan Li, Hongtao Zhang, Keaven Anderson, Songzi Li and Ruoqing Zhu* 

  In the pharmaceutical industry, the use of artificial intelligence (AI) has
seen consistent growth over the past decade. This rise is attributed to major
advancements in statistical machine learning methodologies, computational
capabilities and the increased availability of large datasets. AI techniques
are applied throughout different stages of drug development, ranging from drug
discovery to post-marketing benefit-risk assessment. Kolluri et al. provided a
review of several case studies that span these stages, featuring key
applications such as protein structure prediction, success probability
estimation, subgroup identification, and AI-assisted clinical trial monitoring.
From a regulatory standpoint, there was a notable uptick in submissions
incorporating AI components in 2021. The most prevalent therapeutic areas
leveraging AI were oncology (27%), psychiatry (15%), gastroenterology (12%),
and neurology (11%). The paradigm of personalized or precision medicine has
gained significant traction in recent research, partly due to advancements in
AI techniques \cite{hamburg2010path}. This shift has had a transformative
impact on the pharmaceutical industry. Departing from the traditional
"one-size-fits-all" model, personalized medicine incorporates various
individual factors, such as environmental conditions, lifestyle choices, and
health histories, to formulate customized treatment plans. By utilizing
sophisticated machine learning algorithms, clinicians and researchers are
better equipped to make informed decisions in areas such as disease prevention,
diagnosis, and treatment selection, thereby optimizing health outcomes for each
individual.

---------------

### 27 Feb 2020 | [Clinical acceptance of software based on artificial intelligence  technologies (radiology)](https://arxiv.org/abs/1908.00381) | [⬇️](https://arxiv.org/pdf/1908.00381)
*S.P. Morozov, A.V. Vladzymyrskyy, V.G. Klyashtornyy, A.E.  Andreychenko, N.S. Kulberg, V.A. Gombolevsky, K.A. Sergunova* 

  Aim: provide a methodological framework for the process of clinical tests,
clinical acceptance, and scientific assessment of algorithms and software based
on the artificial intelligence (AI) technologies. Clinical tests are considered
as a preparation stage for the software registration as a medical product. The
authors propose approaches to evaluate accuracy and efficiency of the AI
algorithms for radiology.

---------------

### 11 May 2022 | [Computational behavior recognition in child and adolescent psychiatry: A  statistical and machine learning analysis plan](https://arxiv.org/abs/2205.05737) | [⬇️](https://arxiv.org/pdf/2205.05737)
*Nicole N. L{\o}nfeldt, Flavia D. Frumosu, A.-R. Cecilie Mora-Jensen,  Nicklas Leander Lund, Sneha Das, A. Katrine Pagsberg, Line K. H. Clemmensen* 

  Motivation: Behavioral observations are an important resource in the study
and evaluation of psychological phenomena, but it is costly, time-consuming,
and susceptible to bias. Thus, we aim to automate coding of human behavior for
use in psychotherapy and research with the help of artificial intelligence (AI)
tools. Here, we present an analysis plan. Methods: Videos of a gold-standard
semi-structured diagnostic interview of 25 youth with obsessive-compulsive
disorder (OCD) and 12 youth without a psychiatric diagnosis (no-OCD) will be
analyzed. Youth were between 8 and 17 years old. Features from the videos will
be extracted and used to compute ratings of behavior, which will be compared to
ratings of behavior produced by mental health professionals trained to use a
specific behavioral coding manual. We will test the effect of OCD diagnosis on
the computationally-derived behavior ratings using multivariate analysis of
variance (MANOVA). Using the generated features, a binary classification model
will be built and used to classify OCD/no-OCD classes. Discussion: Here, we
present a pre-defined plan for how data will be pre-processed, analyzed and
presented in the publication of results and their interpretation. A challenge
for the proposed study is that the AI approach will attempt to derive
behavioral ratings based solely on vision, whereas humans use visual,
paralinguistic and linguistic cues to rate behavior. Another challenge will be
using machine learning models for body and facial movement detection trained
primarily on adults and not on children. If the AI tools show promising
results, this pre-registered analysis plan may help reduce interpretation bias.
Trial registration: ClinicalTrials.gov - H-18010607

---------------

### 10 Aug 2020 | [Artificial Intelligence to Assist in Exclusion of Coronary  Atherosclerosis during CCTA Evaluation of Chest-Pain in the Emergency  Department: Preparing an Application for Real-World Use](https://arxiv.org/abs/2008.04802) | [⬇️](https://arxiv.org/pdf/2008.04802)
*Richard D. White, Barbaros S. Erdal, Mutlu Demirer, Vikash Gupta,  Matthew T. Bigelow, Engin Dikici, Sema Candemir, Mauricio S. Galizia, Jessica  L. Carpenter, Thomas P. O Donnell, Abdul H. Halabi, Luciano M. Prevedello* 

  Coronary Computed Tomography Angiography (CCTA) evaluation of chest-pain
patients in an Emergency Department (ED) is considered appropriate. While a
negative CCTA interpretation supports direct patient discharge from an ED,
labor-intensive analyses are required, with accuracy in jeopardy from
distractions. We describe the development of an Artificial Intelligence (AI)
algorithm and workflow for assisting interpreting physicians in CCTA screening
for the absence of coronary atherosclerosis. The two-phase approach consisted
of (1) Phase 1 - focused on the development and preliminary testing of an
algorithm for vessel-centerline extraction classification in a balanced study
population (n = 500 with 50% disease prevalence) derived by retrospective
random case selection; and (2) Phase 2 - concerned with simulated-clinical
Trialing of the developed algorithm on a per-case basis in a more real-world
study population (n = 100 with 28% disease prevalence) from an ED chest-pain
series. This allowed pre-deployment evaluation of the AI-based CCTA screening
application which provides a vessel-by-vessel graphic display of algorithm
inference results integrated into a clinically capable viewer. Algorithm
performance evaluation used Area Under the Receiver-Operating-Characteristic
Curve (AUC-ROC); confusion matrices reflected ground-truth vs AI
determinations. The vessel-based algorithm demonstrated strong performance with
AUC-ROC = 0.96. In both Phase 1 and Phase 2, independent of disease prevalence
differences, negative predictive values at the case level were very high at
95%. The rate of completion of the algorithm workflow process (96% with
inference results in 55-80 seconds) in Phase 2 depended on adequate image
quality. There is potential for this AI application to assist in CCTA
interpretation to help extricate atherosclerosis from chest-pain presentations.

---------------

### 08 Jan 2024 | [Medical records condensation: a roadmap towards healthcare data  democratisation](https://arxiv.org/abs/2305.03711) | [⬇️](https://arxiv.org/pdf/2305.03711)
*Yujiang Wang, Anshul Thakur, Mingzhi Dong, Pingchuan Ma, Stavros  Petridis, Li Shang, Tingting Zhu, David A. Clifton* 

  The prevalence of artificial intelligence (AI) has envisioned an era of
healthcare democratisation that promises every stakeholder a new and better way
of life. However, the advancement of clinical AI research is significantly
hurdled by the dearth of data democratisation in healthcare. To truly
democratise data for AI studies, challenges are two-fold: 1. the sensitive
information in clinical data should be anonymised appropriately, and 2.
AI-oriented clinical knowledge should flow freely across organisations. This
paper considers a recent deep-learning advent, dataset condensation (DC), as a
stone that kills two birds in democratising healthcare data. The condensed data
after DC, which can be viewed as statistical metadata, abstracts original
clinical records and irreversibly conceals sensitive information at individual
levels; nevertheless, it still preserves adequate knowledge for learning deep
neural networks (DNNs). More favourably, the compressed volumes and the
accelerated model learnings of condensed data portray a more efficient clinical
knowledge sharing and flowing system, as necessitated by data democratisation.
We underline DC's prospects for democratising clinical data, specifically
electrical healthcare records (EHRs), for AI research through experimental
results and analysis across three healthcare datasets of varying data types.

---------------

### 05 Jan 2024 | [Application of federated learning techniques for arrhythmia  classification using 12-lead ECG signals](https://arxiv.org/abs/2208.10993) | [⬇️](https://arxiv.org/pdf/2208.10993)
*Daniel Mauricio Jimenez Gutierrez, Hafiz Muuhammad Hassan, Lorella  Landi, Andrea Vitaletti and Ioannis Chatzigiannakis* 

  Artificial Intelligence-based (AI) analysis of large, curated medical
datasets is promising for providing early detection, faster diagnosis, and more
effective treatment using low-power Electrocardiography (ECG) monitoring
devices information. However, accessing sensitive medical data from diverse
sources is highly restricted since improper use, unsafe storage, or data
leakage could violate a person's privacy. This work uses a Federated Learning
(FL) privacy-preserving methodology to train AI models over heterogeneous sets
of high-definition ECG from 12-lead sensor arrays collected from six
heterogeneous sources. We evaluated the capacity of the resulting models to
achieve equivalent performance compared to state-of-the-art models trained in a
Centralized Learning (CL) fashion. Moreover, we assessed the performance of our
solution over Independent and Identical distributed (IID) and non-IID federated
data. Our methodology involves machine learning techniques based on Deep Neural
Networks and Long-Short-Term Memory models. It has a robust data preprocessing
pipeline with feature engineering, selection, and data balancing techniques.
Our AI models demonstrated comparable performance to models trained using CL,
IID, and non-IID approaches. They showcased advantages in reduced complexity
and faster training time, making them well-suited for cloud-edge architectures.

---------------

### 24 Feb 2018 | [Generating retinal flow maps from structural optical coherence  tomography with artificial intelligence](https://arxiv.org/abs/1802.08925) | [⬇️](https://arxiv.org/pdf/1802.08925)
*Cecilia S. Lee, Ariel J. Tyring, Yue Wu, Sa Xiao, Ariel S. Rokem,  Nicolaas P. Deruyter, Qinqin Zhang, Adnan Tufail, Ruikang K. Wang, Aaron Y.  Lee* 

  Despite significant advances in artificial intelligence (AI) for computer
vision, its application in medical imaging has been limited by the burden and
limits of expert-generated labels. We used images from optical coherence
tomography angiography (OCTA), a relatively new imaging modality that measures
perfusion of the retinal vasculature, to train an AI algorithm to generate
vasculature maps from standard structural optical coherence tomography (OCT)
images of the same retinae, both exceeding the ability and bypassing the need
for expert labeling. Deep learning was able to infer perfusion of
microvasculature from structural OCT images with similar fidelity to OCTA and
significantly better than expert clinicians (P < 0.00001). OCTA suffers from
need of specialized hardware, laborious acquisition protocols, and motion
artifacts; whereas our model works directly from standard OCT which are
ubiquitous and quick to obtain, and allows unlocking of large volumes of
previously collected standard OCT data both in existing clinical trials and
clinical practice. This finding demonstrates a novel application of AI to
medical imaging, whereby subtle regularities between different modalities are
used to image the same body part and AI is used to generate detailed and
accurate inferences of tissue function from structure imaging.

---------------

### 13 Jan 2022 | [AI-Based Detection, Classification and Prediction/Prognosis in Medical  Imaging: Towards Radiophenomics](https://arxiv.org/abs/2110.10332) | [⬇️](https://arxiv.org/pdf/2110.10332)
*Fereshteh Yousefirizi, Pierre Decazes, Amine Amyar, Su Ruan, Babak  Saboury, Arman Rahmim* 

  Artificial intelligence (AI) techniques have significant potential to enable
effective, robust and automated image phenotyping including identification of
subtle patterns. AI-based detection searches the image space to find the
regions of interest based on patterns and features. There is a spectrum of
tumor histologies from benign to malignant that can be identified by AI-based
classification approaches using image features. The extraction of minable
information from images gives way to the field of radiomics and can be explored
via explicit (handcrafted/engineered) and deep radiomics frameworks. Radiomics
analysis has the potential to be utilized as a noninvasive technique for the
accurate characterization of tumors to improve diagnosis and treatment
monitoring. This work reviews AI-based techniques, with a special focus on
oncological PET and PET/CT imaging, for different detection, classification,
and prediction/prognosis tasks. We also discuss needed efforts to enable the
translation of AI techniques to routine clinical workflows, and potential
improvements and complementary techniques such as the use of natural language
processing on electronic health records and neuro-symbolic AI techniques.

---------------
**Date:** 28 Jul 2023

**Title:** Matching Patients to Clinical Trials with Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2307.15051](https://arxiv.org/abs/2307.15051)

**PDF Link:** [https://arxiv.org/pdf/2307.15051](https://arxiv.org/pdf/2307.15051)

---

**Date:** 16 Sep 2022

**Title:** Artificial Intelligence for In Silico Clinical Trials: A Review

**Abstract Link:** [https://arxiv.org/abs/2209.09023](https://arxiv.org/abs/2209.09023)

**PDF Link:** [https://arxiv.org/pdf/2209.09023](https://arxiv.org/pdf/2209.09023)

---

**Date:** 07 Sep 2021

**Title:** A Scalable AI Approach for Clinical Trial Cohort Optimization

**Abstract Link:** [https://arxiv.org/abs/2109.02808](https://arxiv.org/abs/2109.02808)

**PDF Link:** [https://arxiv.org/pdf/2109.02808](https://arxiv.org/pdf/2109.02808)

---

**Date:** 22 Jan 2024

**Title:** Revolutionizing Pharma: Unveiling the AI and LLM Trends in the  Pharmaceutical Industry

**Abstract Link:** [https://arxiv.org/abs/2401.10273](https://arxiv.org/abs/2401.10273)

**PDF Link:** [https://arxiv.org/pdf/2401.10273](https://arxiv.org/pdf/2401.10273)

---

**Date:** 17 Aug 2023

**Title:** Data diversity and virtual imaging in AI-based diagnosis: A case study  based on COVID-19

**Abstract Link:** [https://arxiv.org/abs/2308.09730](https://arxiv.org/abs/2308.09730)

**PDF Link:** [https://arxiv.org/pdf/2308.09730](https://arxiv.org/pdf/2308.09730)

---

**Date:** 02 Feb 2021

**Title:** Applications of artificial intelligence in drug development using  real-world data

**Abstract Link:** [https://arxiv.org/abs/2101.08904](https://arxiv.org/abs/2101.08904)

**PDF Link:** [https://arxiv.org/pdf/2101.08904](https://arxiv.org/pdf/2101.08904)

---

**Date:** 03 Nov 2023

**Title:** Towards objective and systematic evaluation of bias in medical imaging  AI

**Abstract Link:** [https://arxiv.org/abs/2311.02115](https://arxiv.org/abs/2311.02115)

**PDF Link:** [https://arxiv.org/pdf/2311.02115](https://arxiv.org/pdf/2311.02115)

---

**Date:** 27 Oct 2023

**Title:** Knowledge-based in silico models and dataset for the comparative  evaluation of mammography AI for a range of breast characteristics, lesion  conspicuities and doses

**Abstract Link:** [https://arxiv.org/abs/2310.18494](https://arxiv.org/abs/2310.18494)

**PDF Link:** [https://arxiv.org/pdf/2310.18494](https://arxiv.org/pdf/2310.18494)

---

**Date:** 13 Jun 2023

**Title:** Multi-Task Training with In-Domain Language Models for Diagnostic  Reasoning

**Abstract Link:** [https://arxiv.org/abs/2306.04551](https://arxiv.org/abs/2306.04551)

**PDF Link:** [https://arxiv.org/pdf/2306.04551](https://arxiv.org/pdf/2306.04551)

---

**Date:** 22 Jan 2021

**Title:** Chemistry42: An AI-based platform for de novo molecular design

**Abstract Link:** [https://arxiv.org/abs/2101.09050](https://arxiv.org/abs/2101.09050)

**PDF Link:** [https://arxiv.org/pdf/2101.09050](https://arxiv.org/pdf/2101.09050)

---

**Date:** 19 Jun 2023

**Title:** Artificial intelligence in digital pathology: a diagnostic test accuracy  systematic review and meta-analysis

**Abstract Link:** [https://arxiv.org/abs/2306.07999](https://arxiv.org/abs/2306.07999)

**PDF Link:** [https://arxiv.org/pdf/2306.07999](https://arxiv.org/pdf/2306.07999)

---

**Date:** 06 Apr 2020

**Title:** Bridging the gap between AI and Healthcare sides: towards developing  clinically relevant AI-powered diagnosis systems

**Abstract Link:** [https://arxiv.org/abs/2001.03923](https://arxiv.org/abs/2001.03923)

**PDF Link:** [https://arxiv.org/pdf/2001.03923](https://arxiv.org/pdf/2001.03923)

---

**Date:** 30 Nov 2023

**Title:** AI in Pharma for Personalized Sequential Decision-Making: Methods,  Applications and Opportunities

**Abstract Link:** [https://arxiv.org/abs/2311.18725](https://arxiv.org/abs/2311.18725)

**PDF Link:** [https://arxiv.org/pdf/2311.18725](https://arxiv.org/pdf/2311.18725)

---

**Date:** 27 Feb 2020

**Title:** Clinical acceptance of software based on artificial intelligence  technologies (radiology)

**Abstract Link:** [https://arxiv.org/abs/1908.00381](https://arxiv.org/abs/1908.00381)

**PDF Link:** [https://arxiv.org/pdf/1908.00381](https://arxiv.org/pdf/1908.00381)

---

**Date:** 11 May 2022

**Title:** Computational behavior recognition in child and adolescent psychiatry: A  statistical and machine learning analysis plan

**Abstract Link:** [https://arxiv.org/abs/2205.05737](https://arxiv.org/abs/2205.05737)

**PDF Link:** [https://arxiv.org/pdf/2205.05737](https://arxiv.org/pdf/2205.05737)

---

**Date:** 10 Aug 2020

**Title:** Artificial Intelligence to Assist in Exclusion of Coronary  Atherosclerosis during CCTA Evaluation of Chest-Pain in the Emergency  Department: Preparing an Application for Real-World Use

**Abstract Link:** [https://arxiv.org/abs/2008.04802](https://arxiv.org/abs/2008.04802)

**PDF Link:** [https://arxiv.org/pdf/2008.04802](https://arxiv.org/pdf/2008.04802)

---

**Date:** 08 Jan 2024

**Title:** Medical records condensation: a roadmap towards healthcare data  democratisation

**Abstract Link:** [https://arxiv.org/abs/2305.03711](https://arxiv.org/abs/2305.03711)

**PDF Link:** [https://arxiv.org/pdf/2305.03711](https://arxiv.org/pdf/2305.03711)

---

**Date:** 05 Jan 2024

**Title:** Application of federated learning techniques for arrhythmia  classification using 12-lead ECG signals

**Abstract Link:** [https://arxiv.org/abs/2208.10993](https://arxiv.org/abs/2208.10993)

**PDF Link:** [https://arxiv.org/pdf/2208.10993](https://arxiv.org/pdf/2208.10993)

---

**Date:** 24 Feb 2018

**Title:** Generating retinal flow maps from structural optical coherence  tomography with artificial intelligence

**Abstract Link:** [https://arxiv.org/abs/1802.08925](https://arxiv.org/abs/1802.08925)

**PDF Link:** [https://arxiv.org/pdf/1802.08925](https://arxiv.org/pdf/1802.08925)

---

**Date:** 13 Jan 2022

**Title:** AI-Based Detection, Classification and Prediction/Prognosis in Medical  Imaging: Towards Radiophenomics

**Abstract Link:** [https://arxiv.org/abs/2110.10332](https://arxiv.org/abs/2110.10332)

**PDF Link:** [https://arxiv.org/pdf/2110.10332](https://arxiv.org/pdf/2110.10332)

---

