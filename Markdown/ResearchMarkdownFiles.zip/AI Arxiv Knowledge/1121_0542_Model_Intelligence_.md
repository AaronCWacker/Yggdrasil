Model Intelligence 🧿

### 🔎 Model Intelligence 🧿



# Model Intelligence

Model Intelligence is a Python library for model explainability and model monitoring. It provides a simple and unified interface for various model explainability and model monitoring techniques.

## Installation

You can install Model Intelligence using pip:

```
pip install model-intelligence
```

## Usage

Model Intelligence can be used to explain and monitor models.

### Explain

Model Intelligence provides a simple and unified interface for various model explainability techniques. Here is an example of how to use Model Intelligence to explain a model:

```python
from model_intelligence import Explainer

# create an explainer
explainer = Explainer(model)

# explain a prediction
explanation = explainer.explain(X, y_true, y_pred)

# print the explanation
print(explanation)
```

Model Intelligence supports the following explainability techniques:

- SHAP
- LIME
- TreeExplainer
- DeepLIFT
- Integrated Gradients
- Layer-wise Relevance Propagation
- Saliency Map
- GradientSHAP
- KernelSHAP
- Shapley Value Sampling
- Shapley Value Regression
- Shapley Value Classification
- Shapley Value Regression Tree
- Shapley Value Classification Tree
- Shapley Value Regression Tree
- Shapley Value Classification Tree
- Shapley Value Regression
- Shapley Value Classification
- Shapley Value Regression Tree
- Shapley Value Classification Tree
- Shapley Value Regression
- Shapley Value Classification
- Shapley Value Regression Tree
- Shapley Value Classification Tree
- Shapley Value Regression Tree
- Shapley Value Classification Tree
- Shapley Value Regression
- Shapley Value Classification
- Shapley Value Regression Tree
- Shapley Value Classification Tree
- Shapley Value Regression Tree
- Shapley Value Classification Tree
- Shapley Value Regression
- Shapley Value Classification
- Shapley Value Regression Tree
- Shapley Value Classification Tree
- Shapley Value Regression Tree
- Shapley Value Class
# 🩺🔍 Search Results
### 26 Feb 2024 | [On Languaging a Simulation Engine](https://arxiv.org/abs/2402.16482) | [⬇️](https://arxiv.org/pdf/2402.16482)
*Han Liu, Liantang Li* 

  Language model intelligence is revolutionizing the way we program materials
simulations. However, the diversity of simulation scenarios renders it
challenging to precisely transform human language into a tailored simulator.
Here, using three functionalized types of language model, we propose a
language-to-simulation (Lang2Sim) framework that enables interactive navigation
on languaging a simulation engine, by taking a scenario instance of water
sorption in porous matrices. Unlike line-by-line coding of a target simulator,
the language models interpret each simulator as an assembly of invariant tool
function and its variant input-output pair. Lang2Sim enables the precise
transform of textual description by functionalizing and sequentializing the
language models of, respectively, rationalizing the tool categorization,
customizing its input-output combinations, and distilling the simulator input
into executable format. Importantly, depending on its functionalized type, each
language model features a distinct processing of chat history to best balance
its memory limit and information completeness, thus leveraging the model
intelligence to unstructured nature of human request. Overall, this work
establishes language model as an intelligent platform to unlock the era of
languaging a simulation engine.

---------------

### 18 Oct 2023 | [Pseudointelligence: A Unifying Framework for Language Model Evaluation](https://arxiv.org/abs/2310.12135) | [⬇️](https://arxiv.org/pdf/2310.12135)
*Shikhar Murty, Orr Paradise, Pratyusha Sharma* 

  With large language models surpassing human performance on an increasing
number of benchmarks, we must take a principled approach for targeted
evaluation of model capabilities. Inspired by pseudorandomness, we propose
pseudointelligence, which captures the maxim that "(perceived) intelligence
lies in the eye of the beholder". That is, that claims of intelligence are
meaningful only when their evaluator is taken into account. Concretely, we
propose a complexity-theoretic framework of model evaluation cast as a dynamic
interaction between a model and a learned evaluator. We demonstrate that this
framework can be used to reason about two case studies in language model
evaluation, as well as analyze existing evaluation methods.

---------------

### 16 Nov 2017 | [Question Asking as Program Generation](https://arxiv.org/abs/1711.06351) | [⬇️](https://arxiv.org/pdf/1711.06351)
*Anselm Rothe, Brenden M. Lake, Todd M. Gureckis* 

  A hallmark of human intelligence is the ability to ask rich, creative, and
revealing questions. Here we introduce a cognitive model capable of
constructing human-like questions. Our approach treats questions as formal
programs that, when executed on the state of the world, output an answer. The
model specifies a probability distribution over a complex, compositional space
of programs, favoring concise programs that help the agent learn in the current
context. We evaluate our approach by modeling the types of open-ended questions
generated by humans who were attempting to learn about an ambiguous situation
in a game. We find that our model predicts what questions people will ask, and
can creatively produce novel questions that were not present in the training
set. In addition, we compare a number of model variants, finding that both
question informativeness and complexity are important for producing human-like
questions.

---------------

### 21 Jul 2021 | [GLIME: A new graphical methodology for interpretable model-agnostic  explanations](https://arxiv.org/abs/2107.09927) | [⬇️](https://arxiv.org/pdf/2107.09927)
*Zoumpolia Dikopoulou, Serafeim Moustakidis, Patrik Karlsson* 

  Explainable artificial intelligence (XAI) is an emerging new domain in which
a set of processes and tools allow humans to better comprehend the decisions
generated by black box models. However, most of the available XAI tools are
often limited to simple explanations mainly quantifying the impact of
individual features to the models' output. Therefore, human users are not able
to understand how the features are related to each other to make predictions,
whereas the inner workings of the trained models remain hidden. This paper
contributes to the development of a novel graphical explainability tool that
not only indicates the significant features of the model but also reveals the
conditional relationships between features and the inference capturing both the
direct and indirect impact of features to the models' decision. The proposed
XAI methodology, termed as gLIME, provides graphical model-agnostic
explanations either at the global (for the entire dataset) or the local scale
(for specific data points). It relies on a combination of local interpretable
model-agnostic explanations (LIME) with graphical least absolute shrinkage and
selection operator (GLASSO) producing undirected Gaussian graphical models.
Regularization is adopted to shrink small partial correlation coefficients to
zero providing sparser and more interpretable graphical explanations. Two
well-known classification datasets (BIOPSY and OAI) were selected to confirm
the superiority of gLIME over LIME in terms of both robustness and consistency
over multiple permutations. Specifically, gLIME accomplished increased
stability over the two datasets with respect to features' importance (76%-96%
compared to 52%-77% using LIME). gLIME demonstrates a unique potential to
extend the functionality of the current state-of-the-art in XAI by providing
informative graphically given explanations that could unlock black boxes.

---------------

### 15 Mar 2022 | [Beyond Explaining: Opportunities and Challenges of XAI-Based Model  Improvement](https://arxiv.org/abs/2203.08008) | [⬇️](https://arxiv.org/pdf/2203.08008)
*Leander Weber, Sebastian Lapuschkin, Alexander Binder, Wojciech Samek* 

  Explainable Artificial Intelligence (XAI) is an emerging research field
bringing transparency to highly complex and opaque machine learning (ML)
models. Despite the development of a multitude of methods to explain the
decisions of black-box classifiers in recent years, these tools are seldomly
used beyond visualization purposes. Only recently, researchers have started to
employ explanations in practice to actually improve models. This paper offers a
comprehensive overview over techniques that apply XAI practically for improving
various properties of ML models, and systematically categorizes these
approaches, comparing their respective strengths and weaknesses. We provide a
theoretical perspective on these methods, and show empirically through
experiments on toy and realistic settings how explanations can help improve
properties such as model generalization ability or reasoning, among others. We
further discuss potential caveats and drawbacks of these methods. We conclude
that while model improvement based on XAI can have significant beneficial
effects even on complex and not easily quantifyable model properties, these
methods need to be applied carefully, since their success can vary depending on
a multitude of factors, such as the model and dataset used, or the employed
explanation method.

---------------

### 13 Mar 2022 | [Towards Personalized Intelligence at Scale](https://arxiv.org/abs/2203.06668) | [⬇️](https://arxiv.org/pdf/2203.06668)
*Yiping Kang, Ashish Mahendra, Christopher Clarke, Lingjia Tang, Jason  Mars* 

  Personalized Intelligence (PI) is the problem of providing customized AI
experiences tailored to each individual user. In many applications, PI is
preferred or even required. Existing personalization approaches involve
fine-tuning pre-trained models to create new customized models. However, these
approaches require a significant amount of computation to train, scaling with
model size and the number of users, inhibiting PI to be realized widely. In
this work, we introduce a novel model architecture and training/inference
framework to enable Personalized Intelligence at scale. We achieve this by
attaching a Personalization Head (PH) to pre-trained language models (LM).
During training, the base LMs are frozen and only the parameters in PH are
updated and are unique per user. This results in significantly smaller overall
model sizes and training cost than traditional fine-tuning approaches when
scaled across many users. We evaluate PHs on academia and industry-focused
datasets and show that the PHs outperform zeroshot baseline in F1 score and are
significantly more scalable than traditional fine-tuning approaches. We
identify key factors required for effective PH design and training.

---------------

### 11 Jan 2020 | [RTOP: A Conceptual and Computational Framework for General Intelligence](https://arxiv.org/abs/1910.10393) | [⬇️](https://arxiv.org/pdf/1910.10393)
*Shilpesh Garg* 

  A novel general intelligence model is proposed with three types of learning.
A unified sequence of the foreground percept trace and the command trace
translates into direct and time-hop observation paths to form the basis of Raw
learning. Raw learning includes the formation of image-image associations,
which lead to the perception of temporal and spatial relationships among
objects and object parts; and the formation of image-audio associations, which
serve as the building blocks of language. Offline identification of similar
segments in the observation paths and their subsequent reduction into a common
segment through merging of memory nodes leads to Generalized learning.
Generalization includes the formation of interpolated sensory nodes for robust
and generic matching, the formation of sensory properties nodes for specific
matching and superimposition, and the formation of group nodes for simpler
logic pathways. Online superimposition of memory nodes across multiple
predictions, primarily the superimposition of images on the internal projection
canvas, gives rise to Innovative learning and thought. The learning of actions
happens the same way as raw learning while the action determination happens
through the utility model built into the raw learnings, the utility function
being the pleasure and pain of the physical senses.

---------------

### 12 Jul 2019 | [MLR (Memory, Learning and Recognition): A General Cognitive Model --  applied to Intelligent Robots and Systems Control](https://arxiv.org/abs/1907.05553) | [⬇️](https://arxiv.org/pdf/1907.05553)
*Aras R. Dargazany* 

  This paper introduces a new perspective of intelligent robots and systems
control. The presented and proposed cognitive model: Memory, Learning and
Recognition (MLR), is an effort to bridge the gap between Robotics, AI,
Cognitive Science, and Neuroscience. The currently existing gap prevents us
from integrating the current advancement and achievements of these four
research fields which are actively trying to define intelligence in either
application-based way or in generic way. This cognitive model defines
intelligence more specifically, parametrically and detailed. The proposed MLR
model helps us create a general control model for robots and systems
independent of their application domains and platforms since it is mainly based
on the dataset provided for robots and systems controls. This paper is mainly
proposing and introducing this concept and trying to prove this concept in a
small scale, firstly through experimentation. The proposed concept is also
applicable to other different platforms in real-time as well as in simulation.

---------------

### 22 Nov 2022 | [Towards Human-Interpretable Prototypes for Visual Assessment of Image  Classification Models](https://arxiv.org/abs/2211.12173) | [⬇️](https://arxiv.org/pdf/2211.12173)
*Poulami Sinhamahapatra, Lena Heidemann, Maureen Monnet, Karsten  Roscher* 

  Explaining black-box Artificial Intelligence (AI) models is a cornerstone for
trustworthy AI and a prerequisite for its use in safety critical applications
such that AI models can reliably assist humans in critical decisions. However,
instead of trying to explain our models post-hoc, we need models which are
interpretable-by-design built on a reasoning process similar to humans that
exploits meaningful high-level concepts such as shapes, texture or object
parts. Learning such concepts is often hindered by its need for explicit
specification and annotation up front. Instead, prototype-based learning
approaches such as ProtoPNet claim to discover visually meaningful prototypes
in an unsupervised way. In this work, we propose a set of properties that those
prototypes have to fulfill to enable human analysis, e.g. as part of a reliable
model assessment case, and analyse such existing methods in the light of these
properties. Given a 'Guess who?' game, we find that these prototypes still have
a long way ahead towards definite explanations. We quantitatively validate our
findings by conducting a user study indicating that many of the learnt
prototypes are not considered useful towards human understanding. We discuss
about the missing links in the existing methods and present a potential
real-world application motivating the need to progress towards truly
human-interpretable prototypes.

---------------

### 13 Jan 2010 | [The Application of Mamdani Fuzzy Model for Auto Zoom Function of a  Digital Camera](https://arxiv.org/abs/1001.2279) | [⬇️](https://arxiv.org/pdf/1001.2279)
*I. Elamvazuthi, P. Vasant, J. F. Webb* 

  Mamdani Fuzzy Model is an important technique in Computational Intelligence
(CI) study. This paper presents an implementation of a supervised learning
method based on membership function training in the context of Mamdani fuzzy
models. Specifically, auto zoom function of a digital camera is modelled using
Mamdani technique. The performance of control method is verified through a
series of simulation and numerical results are provided as illustrations.

---------------

### 30 Mar 2023 | [Fengshenbang 1.0: Being the Foundation of Chinese Cognitive Intelligence](https://arxiv.org/abs/2209.02970) | [⬇️](https://arxiv.org/pdf/2209.02970)
*Jiaxing Zhang, Ruyi Gan, Junjie Wang, Yuxiang Zhang, Lin Zhang, Ping  Yang, Xinyu Gao, Ziwei Wu, Xiaoqun Dong, Junqing He, Jianheng Zhuo, Qi Yang,  Yongfeng Huang, Xiayu Li, Yanghan Wu, Junyu Lu, Xinyu Zhu, Weifeng Chen, Ting  Han, Kunhao Pan, Rui Wang, Hao Wang, Xiaojun Wu, Zhongshen Zeng, Chongpei  Chen* 

  Nowadays, foundation models become one of fundamental infrastructures in
artificial intelligence, paving ways to the general intelligence. However, the
reality presents two urgent challenges: existing foundation models are
dominated by the English-language community; users are often given limited
resources and thus cannot always use foundation models. To support the
development of the Chinese-language community, we introduce an open-source
project, called Fengshenbang, which leads by the research center for Cognitive
Computing and Natural Language (CCNL). Our project has comprehensive
capabilities, including large pre-trained models, user-friendly APIs,
benchmarks, datasets, and others. We wrap all these in three sub-projects: the
Fengshenbang Model, the Fengshen Framework, and the Fengshen Benchmark. An
open-source roadmap, Fengshenbang, aims to re-evaluate the open-source
community of Chinese pre-trained large-scale models, prompting the development
of the entire Chinese large-scale model community. We also want to build a
user-centered open-source ecosystem to allow individuals to access the desired
models to match their computing resources. Furthermore, we invite companies,
colleges, and research institutions to collaborate with us to build the
large-scale open-source model-based ecosystem. We hope that this project will
be the foundation of Chinese cognitive intelligence.

---------------

### 09 Nov 2023 | [A Number Sense as an Emergent Property of the Manipulating Brain](https://arxiv.org/abs/2012.04132) | [⬇️](https://arxiv.org/pdf/2012.04132)
*Neehar Kondapaneni, Pietro Perona* 

  Artificial intelligence (AI) systems struggle to generalize beyond their
training data and abstract general properties from the specifics of the
training examples. We propose a model that reproduces the apparent human
ability to come up with a number sense through unsupervised everyday
experience. The ability to understand and manipulate numbers and quantities
emerges during childhood, but the mechanism through which humans acquire and
develop this ability is still poorly understood. In particular, it is not known
whether acquiring such a number sense is possible without supervision from a
teacher. We explore this question through a model, assuming that the learner is
able to pick and place small objects and will spontaneously engage in
undirected manipulation. We assume that the learner's visual system will
monitor the changing arrangements of objects in the scene and will learn to
predict the effects of each action by comparing perception with the efferent
signal of the motor system. We model perception using standard deep networks
for feature extraction and classification. We find that, from learning the
unrelated task of action prediction, an unexpected image representation emerges
exhibiting regularities that foreshadow the perception and representation of
numbers. These include distinct categories for the first few natural numbers, a
strict ordering of the numbers, and a one-dimensional signal that correlates
with numerical quantity. As a result, our model acquires the ability to
estimate numerosity and subitize. Remarkably, subitization and numerosity
estimation extrapolate to scenes containing many objects, far beyond the three
objects used during training. We conclude that important aspects of a facility
with numbers and quantities may be learned without teacher supervision.

---------------

### 14 Jun 2021 | [Can Explainable AI Explain Unfairness? A Framework for Evaluating  Explainable AI](https://arxiv.org/abs/2106.07483) | [⬇️](https://arxiv.org/pdf/2106.07483)
*Kiana Alikhademi, Brianna Richardson, Emma Drobina, and Juan E.  Gilbert* 

  Many ML models are opaque to humans, producing decisions too complex for
humans to easily understand. In response, explainable artificial intelligence
(XAI) tools that analyze the inner workings of a model have been created.
Despite these tools' strength in translating model behavior, critiques have
raised concerns about the impact of XAI tools as a tool for `fairwashing` by
misleading users into trusting biased or incorrect models. In this paper, we
created a framework for evaluating explainable AI tools with respect to their
capabilities for detecting and addressing issues of bias and fairness as well
as their capacity to communicate these results to their users clearly. We found
that despite their capabilities in simplifying and explaining model behavior,
many prominent XAI tools lack features that could be critical in detecting
bias. Developers can use our framework to suggest modifications needed in their
toolkits to reduce issues likes fairwashing.

---------------

### 03 Mar 2023 | [SoK: Explainable Machine Learning for Computer Security Applications](https://arxiv.org/abs/2208.10605) | [⬇️](https://arxiv.org/pdf/2208.10605)
*Azqa Nadeem, Dani\"el Vos, Clinton Cao, Luca Pajola, Simon Dieck,  Robert Baumgartner, Sicco Verwer* 

  Explainable Artificial Intelligence (XAI) aims to improve the transparency of
machine learning (ML) pipelines. We systematize the increasingly growing (but
fragmented) microcosm of studies that develop and utilize XAI methods for
defensive and offensive cybersecurity tasks. We identify 3 cybersecurity
stakeholders, i.e., model users, designers, and adversaries, who utilize XAI
for 4 distinct objectives within an ML pipeline, namely 1) XAI-enabled user
assistance, 2) XAI-enabled model verification, 3) explanation verification &
robustness, and 4) offensive use of explanations. Our analysis of the
literature indicates that many of the XAI applications are designed with little
understanding of how they might be integrated into analyst workflows -- user
studies for explanation evaluation are conducted in only 14% of the cases. The
security literature sometimes also fails to disentangle the role of the various
stakeholders, e.g., by providing explanations to model users and designers
while also exposing them to adversaries. Additionally, the role of model
designers is particularly minimized in the security literature. To this end, we
present an illustrative tutorial for model designers, demonstrating how XAI can
help with model verification. We also discuss scenarios where interpretability
by design may be a better alternative. The systematization and the tutorial
enable us to challenge several assumptions, and present open problems that can
help shape the future of XAI research within cybersecurity.

---------------

### 19 Jul 2022 | [Mimetic Models: Ethical Implications of AI that Acts Like You](https://arxiv.org/abs/2207.09394) | [⬇️](https://arxiv.org/pdf/2207.09394)
*Reid McIlroy-Young, Jon Kleinberg, Siddhartha Sen, Solon Barocas,  Ashton Anderson* 

  An emerging theme in artificial intelligence research is the creation of
models to simulate the decisions and behavior of specific people, in domains
including game-playing, text generation, and artistic expression. These models
go beyond earlier approaches in the way they are tailored to individuals, and
the way they are designed for interaction rather than simply the reproduction
of fixed, pre-computed behaviors. We refer to these as mimetic models, and in
this paper we develop a framework for characterizing the ethical and social
issues raised by their growing availability. Our framework includes a number of
distinct scenarios for the use of such models, and considers the impacts on a
range of different participants, including the target being modeled, the
operator who deploys the model, and the entities that interact with it.

---------------

### 18 Feb 2024 | [ModelGPT: Unleashing LLM's Capabilities for Tailored Model Generation](https://arxiv.org/abs/2402.12408) | [⬇️](https://arxiv.org/pdf/2402.12408)
*Zihao Tang, Zheqi Lv, Shengyu Zhang, Fei Wu, Kun Kuang* 

  The rapid advancement of Large Language Models (LLMs) has revolutionized
various sectors by automating routine tasks, marking a step toward the
realization of Artificial General Intelligence (AGI). However, they still
struggle to accommodate the diverse and specific needs of users and simplify
the utilization of AI models for the average user. In response, we propose
ModelGPT, a novel framework designed to determine and generate AI models
specifically tailored to the data or task descriptions provided by the user,
leveraging the capabilities of LLMs. Given user requirements, ModelGPT is able
to provide tailored models at most 270x faster than the previous paradigms
(e.g. all-parameter or LoRA finetuning). Comprehensive experiments on NLP, CV,
and Tabular datasets attest to the effectiveness of our framework in making AI
models more accessible and user-friendly. Our code is available at
https://github.com/IshiKura-a/ModelGPT.

---------------

### 24 Mar 2022 | [Multi-modal multi-objective model-based genetic programming to find  multiple diverse high-quality models](https://arxiv.org/abs/2203.13347) | [⬇️](https://arxiv.org/pdf/2203.13347)
*E.M.C. Sijben, T. Alderliesten and P.A.N. Bosman* 

  Explainable artificial intelligence (XAI) is an important and rapidly
expanding research topic. The goal of XAI is to gain trust in a machine
learning (ML) model through clear insights into how the model arrives at its
predictions. Genetic programming (GP) is often cited as being uniquely
well-suited to contribute to XAI because of its capacity to learn (small)
symbolic models that have the potential to be interpreted. Nevertheless, like
many ML algorithms, GP typically results in a single best model. However, in
practice, the best model in terms of training error may well not be the most
suitable one as judged by a domain expert for various reasons, including
overfitting, multiple different models existing that have similar accuracy, and
unwanted errors on particular data points due to typical accuracy measures like
mean squared error. Hence, to increase chances that domain experts deem a
resulting model plausible, it becomes important to be able to explicitly search
for multiple, diverse, high-quality models that trade-off different meanings of
accuracy. In this paper, we achieve exactly this with a novel multi-modal
multi-tree multi-objective GP approach that extends a modern model-based GP
algorithm known as GP-GOMEA that is already effective at searching for small
expressions.

---------------

### 14 Jun 2022 | [Syntax-Guided Program Reduction for Understanding Neural Code  Intelligence Models](https://arxiv.org/abs/2205.14374) | [⬇️](https://arxiv.org/pdf/2205.14374)
*Md Rafiqul Islam Rabin, Aftab Hussain, Mohammad Amin Alipour* 

  Neural code intelligence (CI) models are opaque black-boxes and offer little
insight on the features they use in making predictions. This opacity may lead
to distrust in their prediction and hamper their wider adoption in
safety-critical applications. Recently, input program reduction techniques have
been proposed to identify key features in the input programs to improve the
transparency of CI models. However, this approach is syntax-unaware and does
not consider the grammar of the programming language. In this paper, we apply a
syntax-guided program reduction technique that considers the grammar of the
input programs during reduction. Our experiments on multiple models across
different types of input programs show that the syntax-guided program reduction
technique is faster and provides smaller sets of key tokens in reduced
programs. We also show that the key tokens could be used in generating
adversarial examples for up to 65% of the input programs.

---------------

### 11 Jun 2023 | [A Survey on Explainable Artificial Intelligence for Cybersecurity](https://arxiv.org/abs/2303.12942) | [⬇️](https://arxiv.org/pdf/2303.12942)
*Gaith Rjoub, Jamal Bentahar, Omar Abdel Wahab, Rabeb Mizouni, Alyssa  Song, Robin Cohen, Hadi Otrok, and Azzam Mourad* 

  The black-box nature of artificial intelligence (AI) models has been the
source of many concerns in their use for critical applications. Explainable
Artificial Intelligence (XAI) is a rapidly growing research field that aims to
create machine learning models that can provide clear and interpretable
explanations for their decisions and actions. In the field of network
cybersecurity, XAI has the potential to revolutionize the way we approach
network security by enabling us to better understand the behavior of cyber
threats and to design more effective defenses. In this survey, we review the
state of the art in XAI for cybersecurity in network systems and explore the
various approaches that have been proposed to address this important problem.
The review follows a systematic classification of network-driven cybersecurity
threats and issues. We discuss the challenges and limitations of current XAI
methods in the context of cybersecurity and outline promising directions for
future research.

---------------

### 25 Jul 2016 | [A Model of Pathways to Artificial Superintelligence Catastrophe for Risk  and Decision Analysis](https://arxiv.org/abs/1607.07730) | [⬇️](https://arxiv.org/pdf/1607.07730)
*Anthony M. Barrett and Seth D. Baum* 

  An artificial superintelligence (ASI) is artificial intelligence that is
significantly more intelligent than humans in all respects. While ASI does not
currently exist, some scholars propose that it could be created sometime in the
future, and furthermore that its creation could cause a severe global
catastrophe, possibly even resulting in human extinction. Given the high
stakes, it is important to analyze ASI risk and factor the risk into decisions
related to ASI research and development. This paper presents a graphical model
of major pathways to ASI catastrophe, focusing on ASI created via recursive
self-improvement. The model uses the established risk and decision analysis
modeling paradigms of fault trees and influence diagrams in order to depict
combinations of events and conditions that could lead to AI catastrophe, as
well as intervention options that could decrease risks. The events and
conditions include select aspects of the ASI itself as well as the human
process of ASI research, development, and management. Model structure is
derived from published literature on ASI risk. The model offers a foundation
for rigorous quantitative evaluation and decision making on the long-term risk
of ASI catastrophe.

---------------
**Date:** 26 Feb 2024

**Title:** On Languaging a Simulation Engine

**Abstract Link:** [https://arxiv.org/abs/2402.16482](https://arxiv.org/abs/2402.16482)

**PDF Link:** [https://arxiv.org/pdf/2402.16482](https://arxiv.org/pdf/2402.16482)

---

**Date:** 18 Oct 2023

**Title:** Pseudointelligence: A Unifying Framework for Language Model Evaluation

**Abstract Link:** [https://arxiv.org/abs/2310.12135](https://arxiv.org/abs/2310.12135)

**PDF Link:** [https://arxiv.org/pdf/2310.12135](https://arxiv.org/pdf/2310.12135)

---

**Date:** 16 Nov 2017

**Title:** Question Asking as Program Generation

**Abstract Link:** [https://arxiv.org/abs/1711.06351](https://arxiv.org/abs/1711.06351)

**PDF Link:** [https://arxiv.org/pdf/1711.06351](https://arxiv.org/pdf/1711.06351)

---

**Date:** 21 Jul 2021

**Title:** GLIME: A new graphical methodology for interpretable model-agnostic  explanations

**Abstract Link:** [https://arxiv.org/abs/2107.09927](https://arxiv.org/abs/2107.09927)

**PDF Link:** [https://arxiv.org/pdf/2107.09927](https://arxiv.org/pdf/2107.09927)

---

**Date:** 15 Mar 2022

**Title:** Beyond Explaining: Opportunities and Challenges of XAI-Based Model  Improvement

**Abstract Link:** [https://arxiv.org/abs/2203.08008](https://arxiv.org/abs/2203.08008)

**PDF Link:** [https://arxiv.org/pdf/2203.08008](https://arxiv.org/pdf/2203.08008)

---

**Date:** 13 Mar 2022

**Title:** Towards Personalized Intelligence at Scale

**Abstract Link:** [https://arxiv.org/abs/2203.06668](https://arxiv.org/abs/2203.06668)

**PDF Link:** [https://arxiv.org/pdf/2203.06668](https://arxiv.org/pdf/2203.06668)

---

**Date:** 11 Jan 2020

**Title:** RTOP: A Conceptual and Computational Framework for General Intelligence

**Abstract Link:** [https://arxiv.org/abs/1910.10393](https://arxiv.org/abs/1910.10393)

**PDF Link:** [https://arxiv.org/pdf/1910.10393](https://arxiv.org/pdf/1910.10393)

---

**Date:** 12 Jul 2019

**Title:** MLR (Memory, Learning and Recognition): A General Cognitive Model --  applied to Intelligent Robots and Systems Control

**Abstract Link:** [https://arxiv.org/abs/1907.05553](https://arxiv.org/abs/1907.05553)

**PDF Link:** [https://arxiv.org/pdf/1907.05553](https://arxiv.org/pdf/1907.05553)

---

**Date:** 22 Nov 2022

**Title:** Towards Human-Interpretable Prototypes for Visual Assessment of Image  Classification Models

**Abstract Link:** [https://arxiv.org/abs/2211.12173](https://arxiv.org/abs/2211.12173)

**PDF Link:** [https://arxiv.org/pdf/2211.12173](https://arxiv.org/pdf/2211.12173)

---

**Date:** 13 Jan 2010

**Title:** The Application of Mamdani Fuzzy Model for Auto Zoom Function of a  Digital Camera

**Abstract Link:** [https://arxiv.org/abs/1001.2279](https://arxiv.org/abs/1001.2279)

**PDF Link:** [https://arxiv.org/pdf/1001.2279](https://arxiv.org/pdf/1001.2279)

---

**Date:** 30 Mar 2023

**Title:** Fengshenbang 1.0: Being the Foundation of Chinese Cognitive Intelligence

**Abstract Link:** [https://arxiv.org/abs/2209.02970](https://arxiv.org/abs/2209.02970)

**PDF Link:** [https://arxiv.org/pdf/2209.02970](https://arxiv.org/pdf/2209.02970)

---

**Date:** 09 Nov 2023

**Title:** A Number Sense as an Emergent Property of the Manipulating Brain

**Abstract Link:** [https://arxiv.org/abs/2012.04132](https://arxiv.org/abs/2012.04132)

**PDF Link:** [https://arxiv.org/pdf/2012.04132](https://arxiv.org/pdf/2012.04132)

---

**Date:** 14 Jun 2021

**Title:** Can Explainable AI Explain Unfairness? A Framework for Evaluating  Explainable AI

**Abstract Link:** [https://arxiv.org/abs/2106.07483](https://arxiv.org/abs/2106.07483)

**PDF Link:** [https://arxiv.org/pdf/2106.07483](https://arxiv.org/pdf/2106.07483)

---

**Date:** 03 Mar 2023

**Title:** SoK: Explainable Machine Learning for Computer Security Applications

**Abstract Link:** [https://arxiv.org/abs/2208.10605](https://arxiv.org/abs/2208.10605)

**PDF Link:** [https://arxiv.org/pdf/2208.10605](https://arxiv.org/pdf/2208.10605)

---

**Date:** 19 Jul 2022

**Title:** Mimetic Models: Ethical Implications of AI that Acts Like You

**Abstract Link:** [https://arxiv.org/abs/2207.09394](https://arxiv.org/abs/2207.09394)

**PDF Link:** [https://arxiv.org/pdf/2207.09394](https://arxiv.org/pdf/2207.09394)

---

**Date:** 18 Feb 2024

**Title:** ModelGPT: Unleashing LLM's Capabilities for Tailored Model Generation

**Abstract Link:** [https://arxiv.org/abs/2402.12408](https://arxiv.org/abs/2402.12408)

**PDF Link:** [https://arxiv.org/pdf/2402.12408](https://arxiv.org/pdf/2402.12408)

---

**Date:** 24 Mar 2022

**Title:** Multi-modal multi-objective model-based genetic programming to find  multiple diverse high-quality models

**Abstract Link:** [https://arxiv.org/abs/2203.13347](https://arxiv.org/abs/2203.13347)

**PDF Link:** [https://arxiv.org/pdf/2203.13347](https://arxiv.org/pdf/2203.13347)

---

**Date:** 14 Jun 2022

**Title:** Syntax-Guided Program Reduction for Understanding Neural Code  Intelligence Models

**Abstract Link:** [https://arxiv.org/abs/2205.14374](https://arxiv.org/abs/2205.14374)

**PDF Link:** [https://arxiv.org/pdf/2205.14374](https://arxiv.org/pdf/2205.14374)

---

**Date:** 11 Jun 2023

**Title:** A Survey on Explainable Artificial Intelligence for Cybersecurity

**Abstract Link:** [https://arxiv.org/abs/2303.12942](https://arxiv.org/abs/2303.12942)

**PDF Link:** [https://arxiv.org/pdf/2303.12942](https://arxiv.org/pdf/2303.12942)

---

**Date:** 25 Jul 2016

**Title:** A Model of Pathways to Artificial Superintelligence Catastrophe for Risk  and Decision Analysis

**Abstract Link:** [https://arxiv.org/abs/1607.07730](https://arxiv.org/abs/1607.07730)

**PDF Link:** [https://arxiv.org/pdf/1607.07730](https://arxiv.org/pdf/1607.07730)

---

