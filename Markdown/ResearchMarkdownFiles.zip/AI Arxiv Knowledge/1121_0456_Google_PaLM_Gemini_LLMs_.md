Google: PaLM Gemini LLMs 🟦

### 🔎 Google: PaLM Gemini LLMs 🟦

🟥
===============================

<p align="center">
  <img src="https://github.com/google-research/gemini/blob/main/docs/images/gemini_logo.png" width="300" height="300">
</p>

This repository contains the code for training and evaluating the PaLM Gemini Language Models (LLMs) on a variety of tasks.

PaLM Gemini LLMs are a family of large language models that are trained on a mixture of web text and code. They are designed to be versatile and perform well on a wide range of NLP tasks, including text classification, question answering, and code generation.

The PaLM Gemini LLMs are based on the [PaLM](https://ai.googleblog.com/2022/04/pathways-language-model-palm-scaling-to.html) model architecture and are trained using the [Gemini](https://github.com/google-research/gemini) training framework.

Getting Started
---------------

To get started with the PaLM Gemini LLMs, you will need to install the following dependencies:

* Python 3.8 or higher
* TensorFlow 2.7 or higher
* Gemini

You can install the required dependencies using the following command:

```
pip install -r requirements.txt
```

Once you have installed the dependencies, you can train and evaluate the PaLM Gemini LLMs using the scripts in the `scripts` directory.

Training
--------

To train a PaLM Gemini LLM, you will need to create a configuration file that specifies the training parameters, such as the learning rate, batch size, and number of epochs.

Here is an example configuration file for training a PaLM Gemini LLM on the GLUE benchmark:

```
model:
  name: palm_gemini
  num_layers: 24
  hidden_size: 2048
  num_attention_heads: 16
  intermediate_size: 8192
  max_sequence_length: 512
  vocab_size: 100000

training:
# 🩺🔍 Search Results
### 02 Jan 2024 | [Evaluating Large Language Models on the GMAT: Implications for the  Future of Business Education](https://arxiv.org/abs/2401.02985) | [⬇️](https://arxiv.org/pdf/2401.02985)
*Vahid Ashrafimoghari, Necdet G\"urkan, and Jordan W. Suchow* 

  The rapid evolution of artificial intelligence (AI), especially in the domain
of Large Language Models (LLMs) and generative AI, has opened new avenues for
application across various fields, yet its role in business education remains
underexplored. This study introduces the first benchmark to assess the
performance of seven major LLMs, OpenAI's models (GPT-3.5 Turbo, GPT-4, and
GPT-4 Turbo), Google's models (PaLM 2, Gemini 1.0 Pro), and Anthropic's models
(Claude 2 and Claude 2.1), on the GMAT, which is a key exam in the admission
process for graduate business programs. Our analysis shows that most LLMs
outperform human candidates, with GPT-4 Turbo not only outperforming the other
models but also surpassing the average scores of graduate students at top
business schools. Through a case study, this research examines GPT-4 Turbo's
ability to explain answers, evaluate responses, identify errors, tailor
instructions, and generate alternative scenarios. The latest LLM versions,
GPT-4 Turbo, Claude 2.1, and Gemini 1.0 Pro, show marked improvements in
reasoning tasks compared to their predecessors, underscoring their potential
for complex problem-solving. While AI's promise in education, assessment, and
tutoring is clear, challenges remain. Our study not only sheds light on LLMs'
academic potential but also emphasizes the need for careful development and
application of AI in education. As AI technology advances, it is imperative to
establish frameworks and protocols for AI interaction, verify the accuracy of
AI-generated content, ensure worldwide access for diverse learners, and create
an educational environment where AI supports human expertise. This research
sets the stage for further exploration into the responsible use of AI to enrich
educational experiences and improve exam preparation and assessment methods.

---------------

### 10 Feb 2024 | [Gemini Goes to Med School: Exploring the Capabilities of Multimodal  Large Language Models on Medical Challenge Problems & Hallucinations](https://arxiv.org/abs/2402.07023) | [⬇️](https://arxiv.org/pdf/2402.07023)
*Ankit Pal, Malaikannan Sankarasubbu* 

  Large language models have the potential to be valuable in the healthcare
industry, but it's crucial to verify their safety and effectiveness through
rigorous evaluation. For this purpose, we comprehensively evaluated both
open-source LLMs and Google's new multimodal LLM called Gemini across Medical
reasoning, hallucination detection, and Medical Visual Question Answering
tasks. While Gemini showed competence, it lagged behind state-of-the-art models
like MedPaLM 2 and GPT-4 in diagnostic accuracy. Additionally, Gemini achieved
an accuracy of 61.45\% on the medical VQA dataset, significantly lower than
GPT-4V's score of 88\%. Our analysis revealed that Gemini is highly susceptible
to hallucinations, overconfidence, and knowledge gaps, which indicate risks if
deployed uncritically. We also performed a detailed analysis by medical subject
and test type, providing actionable feedback for developers and clinicians. To
mitigate risks, we applied prompting strategies that improved performance.
Additionally, we facilitated future research and development by releasing a
Python module for medical LLM evaluation and establishing a dedicated
leaderboard on Hugging Face for medical domain LLMs. Python module can be found
at https://github.com/promptslab/RosettaEval

---------------

### 29 Dec 2023 | [Gemini in Reasoning: Unveiling Commonsense in Multimodal Large Language  Models](https://arxiv.org/abs/2312.17661) | [⬇️](https://arxiv.org/pdf/2312.17661)
*Yuqing Wang, Yun Zhao* 

  The burgeoning interest in Multimodal Large Language Models (MLLMs), such as
OpenAI's GPT-4V(ision), has significantly impacted both academic and industrial
realms. These models enhance Large Language Models (LLMs) with advanced visual
understanding capabilities, facilitating their application in a variety of
multimodal tasks. Recently, Google introduced Gemini, a cutting-edge MLLM
designed specifically for multimodal integration. Despite its advancements,
preliminary benchmarks indicate that Gemini lags behind GPT models in
commonsense reasoning tasks. However, this assessment, based on a limited
dataset (i.e., HellaSWAG), does not fully capture Gemini's authentic
commonsense reasoning potential. To address this gap, our study undertakes a
thorough evaluation of Gemini's performance in complex reasoning tasks that
necessitate the integration of commonsense knowledge across modalities. We
carry out a comprehensive analysis of 12 commonsense reasoning datasets,
ranging from general to domain-specific tasks. This includes 11 datasets
focused solely on language, as well as one that incorporates multimodal
elements. Our experiments across four LLMs and two MLLMs demonstrate Gemini's
competitive commonsense reasoning capabilities. Additionally, we identify
common challenges faced by current LLMs and MLLMs in addressing commonsense
problems, underscoring the need for further advancements in enhancing the
commonsense reasoning abilities of these models.

---------------

### 20 Dec 2023 | [A Challenger to GPT-4V? Early Explorations of Gemini in Visual Expertise](https://arxiv.org/abs/2312.12436) | [⬇️](https://arxiv.org/pdf/2312.12436)
*Chaoyou Fu, Renrui Zhang, Zihan Wang, Yubo Huang, Zhengye Zhang,  Longtian Qiu, Gaoxiang Ye, Yunhang Shen, Mengdan Zhang, Peixian Chen, Sirui  Zhao, Shaohui Lin, Deqiang Jiang, Di Yin, Peng Gao, Ke Li, Hongsheng Li, Xing  Sun* 

  The surge of interest towards Multi-modal Large Language Models (MLLMs),
e.g., GPT-4V(ision) from OpenAI, has marked a significant trend in both
academia and industry. They endow Large Language Models (LLMs) with powerful
capabilities in visual understanding, enabling them to tackle diverse
multi-modal tasks. Very recently, Google released Gemini, its newest and most
capable MLLM built from the ground up for multi-modality. In light of the
superior reasoning capabilities, can Gemini challenge GPT-4V's leading position
in multi-modal learning? In this paper, we present a preliminary exploration of
Gemini Pro's visual understanding proficiency, which comprehensively covers
four domains: fundamental perception, advanced cognition, challenging vision
tasks, and various expert capacities. We compare Gemini Pro with the
state-of-the-art GPT-4V to evaluate its upper limits, along with the latest
open-sourced MLLM, Sphinx, which reveals the gap between manual efforts and
black-box systems. The qualitative samples indicate that, while GPT-4V and
Gemini showcase different answering styles and preferences, they can exhibit
comparable visual reasoning capabilities, and Sphinx still trails behind them
concerning domain generalizability. Specifically, GPT-4V tends to elaborate
detailed explanations and intermediate steps, and Gemini prefers to output a
direct and concise answer. The quantitative evaluation on the popular MME
benchmark also demonstrates the potential of Gemini to be a strong challenger
to GPT-4V. Our early investigation of Gemini also observes some common issues
of MLLMs, indicating that there still remains a considerable distance towards
artificial general intelligence. Our project for tracking the progress of MLLM
is released at
https://github.com/BradyFU/Awesome-Multimodal-Large-Language-Models.

---------------

### 28 Feb 2024 | [FOFO: A Benchmark to Evaluate LLMs' Format-Following Capability](https://arxiv.org/abs/2402.18667) | [⬇️](https://arxiv.org/pdf/2402.18667)
*Congying Xia, Chen Xing, Jiangshu Du, Xinyi Yang, Yihao Feng, Ran Xu,  Wenpeng Yin, Caiming Xiong* 

  This paper presents FoFo, a pioneering benchmark for evaluating large
language models' (LLMs) ability to follow complex, domain-specific formats, a
crucial yet underexamined capability for their application as AI agents.
Despite LLMs' advancements, existing benchmarks fail to assess their
format-following proficiency adequately. FoFo fills this gap with a diverse
range of real-world formats and instructions, developed through an AI-Human
collaborative method. Our evaluation across both open-source (e.g., Llama 2,
WizardLM) and closed-source (e.g., GPT-4, PALM2, Gemini) LLMs highlights three
key findings: open-source models significantly lag behind closed-source ones in
format adherence; LLMs' format-following performance is independent of their
content generation quality; and LLMs' format proficiency varies across
different domains. These insights suggest the need for specialized tuning for
format-following skills and highlight FoFo's role in guiding the selection of
domain-specific AI agents. FoFo is released here at
https://github.com/SalesforceAIResearch/FoFo.

---------------

### 13 Feb 2024 | [Combining Insights From Multiple Large Language Models Improves  Diagnostic Accuracy](https://arxiv.org/abs/2402.08806) | [⬇️](https://arxiv.org/pdf/2402.08806)
*Gioele Barabucci, Victor Shia, Eugene Chu, Benjamin Harack, Nathan Fu* 

  Background: Large language models (LLMs) such as OpenAI's GPT-4 or Google's
PaLM 2 are proposed as viable diagnostic support tools or even spoken of as
replacements for "curbside consults". However, even LLMs specifically trained
on medical topics may lack sufficient diagnostic accuracy for real-life
applications.
  Methods: Using collective intelligence methods and a dataset of 200 clinical
vignettes of real-life cases, we assessed and compared the accuracy of
differential diagnoses obtained by asking individual commercial LLMs (OpenAI
GPT-4, Google PaLM 2, Cohere Command, Meta Llama 2) against the accuracy of
differential diagnoses synthesized by aggregating responses from combinations
of the same LLMs.
  Results: We find that aggregating responses from multiple, various LLMs leads
to more accurate differential diagnoses (average accuracy for 3 LLMs:
$75.3\%\pm 1.6pp$) compared to the differential diagnoses produced by single
LLMs (average accuracy for single LLMs: $59.0\%\pm 6.1pp$).
  Discussion: The use of collective intelligence methods to synthesize
differential diagnoses combining the responses of different LLMs achieves two
of the necessary steps towards advancing acceptance of LLMs as a diagnostic
support tool: (1) demonstrate high diagnostic accuracy and (2) eliminate
dependence on a single commercial vendor.

---------------

### 29 Jan 2024 | [From GPT-4 to Gemini and Beyond: Assessing the Landscape of MLLMs on  Generalizability, Trustworthiness and Causality through Four Modalities](https://arxiv.org/abs/2401.15071) | [⬇️](https://arxiv.org/pdf/2401.15071)
*Chaochao Lu, Chen Qian, Guodong Zheng, Hongxing Fan, Hongzhi Gao, Jie  Zhang, Jing Shao, Jingyi Deng, Jinlan Fu, Kexin Huang, Kunchang Li, Lijun Li,  Limin Wang, Lu Sheng, Meiqi Chen, Ming Zhang, Qibing Ren, Sirui Chen, Tao  Gui, Wanli Ouyang, Yali Wang, Yan Teng, Yaru Wang, Yi Wang, Yinan He,  Yingchun Wang, Yixu Wang, Yongting Zhang, Yu Qiao, Yujiong Shen, Yurong Mou,  Yuxi Chen, Zaibin Zhang, Zhelun Shi, Zhenfei Yin, Zhipin Wang* 

  Multi-modal Large Language Models (MLLMs) have shown impressive abilities in
generating reasonable responses with respect to multi-modal contents. However,
there is still a wide gap between the performance of recent MLLM-based
applications and the expectation of the broad public, even though the most
powerful OpenAI's GPT-4 and Google's Gemini have been deployed. This paper
strives to enhance understanding of the gap through the lens of a qualitative
study on the generalizability, trustworthiness, and causal reasoning
capabilities of recent proprietary and open-source MLLMs across four
modalities: ie, text, code, image, and video, ultimately aiming to improve the
transparency of MLLMs. We believe these properties are several representative
factors that define the reliability of MLLMs, in supporting various downstream
applications. To be specific, we evaluate the closed-source GPT-4 and Gemini
and 6 open-source LLMs and MLLMs. Overall we evaluate 230 manually designed
cases, where the qualitative results are then summarized into 12 scores (ie, 4
modalities times 3 properties). In total, we uncover 14 empirical findings that
are useful to understand the capabilities and limitations of both proprietary
and open-source MLLMs, towards more reliable downstream multi-modal
applications.

---------------

### 04 Mar 2024 | [Exploring the psychology of LLMs' Moral and Legal Reasoning](https://arxiv.org/abs/2308.01264) | [⬇️](https://arxiv.org/pdf/2308.01264)
*Guilherme F. C. F. Almeida, Jos\'e Luiz Nunes, Neele Engelmann, Alex  Wiegmann, Marcelo de Ara\'ujo* 

  Large language models (LLMs) exhibit expert-level performance in tasks across
a wide range of different domains. Ethical issues raised by LLMs and the need
to align future versions makes it important to know how state of the art models
reason about moral and legal issues. In this paper, we employ the methods of
experimental psychology to probe into this question. We replicate eight studies
from the experimental literature with instances of Google's Gemini Pro,
Anthropic's Claude 2.1, OpenAI's GPT-4, and Meta's Llama 2 Chat 70b. We find
that alignment with human responses shifts from one experiment to another, and
that models differ amongst themselves as to their overall alignment, with GPT-4
taking a clear lead over all other models we tested. Nonetheless, even when
LLM-generated responses are highly correlated to human responses, there are
still systematic differences, with a tendency for models to exaggerate effects
that are present among humans, in part by reducing variance. This recommends
caution with regards to proposals of replacing human participants with current
state-of-the-art LLMs in psychological research and highlights the need for
further research about the distinctive aspects of machine psychology.

---------------

### 11 Jan 2024 | [Evidence to Generate (E2G): A Single-agent Two-step Prompting for  Context Grounded and Retrieval Augmented Reasoning](https://arxiv.org/abs/2401.05787) | [⬇️](https://arxiv.org/pdf/2401.05787)
*Md Rizwan Parvez* 

  While chain-of-thought (CoT) prompting has revolutionized how LLMs perform
reasoning tasks, its current methods and variations (e.g, Self-consistency,
ReACT, Reflexion, Tree-of-Thoughts (ToT), Cumulative Reasoning (CR)) suffer
from limitations like slowness, limited context grounding, hallucination and
inconsistent outputs. To overcome these challenges, we introduce Evidence to
Generate (E2G), a novel single-agent, two-step prompting framework. Instead of
unverified reasoning claims, this innovative approach leverages the power of
"evidence for decision making" by first focusing exclusively on the thought
sequences (the series of intermediate steps) explicitly mentioned in the
context which then serve as extracted evidence, guiding the LLM's output
generation process with greater precision and efficiency. This simple yet
powerful approach unlocks the true potential of chain-of-thought like
prompting, paving the way for faster, more reliable, and more contextually
aware reasoning in LLMs. \tool achieves remarkable results robustly across a
wide range of knowledge-intensive reasoning and generation tasks, surpassing
baseline approaches with state-of-the-art LLMs. For example, (i) on LogiQA
benchmark using GPT-4 as backbone model, \tool achieves a new state-of-the
Accuracy of 53.8% exceeding CoT by 18%, ToT by 11%, CR by 9% (ii) a variant of
E2G with PaLM2 outperforms the variable-shot performance of Gemini Ultra by 0.9
F1 points, reaching an F1 score of 83.3 on a subset of DROP.

---------------

### 01 Feb 2024 | [Ocassionally Secure: A Comparative Analysis of Code Generation  Assistants](https://arxiv.org/abs/2402.00689) | [⬇️](https://arxiv.org/pdf/2402.00689)
*Ran Elgedawy, John Sadik, Senjuti Dutta, Anuj Gautam, Konstantinos  Georgiou, Farzin Gholamrezae, Fujiao Ji, Kyungchan Lim, Qian Liu, and Scott  Ruoti* 

  $ $Large Language Models (LLMs) are being increasingly utilized in various
applications, with code generations being a notable example. While previous
research has shown that LLMs have the capability to generate both secure and
insecure code, the literature does not take into account what factors help
generate secure and effective code. Therefore in this paper we focus on
identifying and understanding the conditions and contexts in which LLMs can be
effectively and safely deployed in real-world scenarios to generate quality
code. We conducted a comparative analysis of four advanced LLMs--GPT-3.5 and
GPT-4 using ChatGPT and Bard and Gemini from Google--using 9 separate tasks to
assess each model's code generation capabilities. We contextualized our study
to represent the typical use cases of a real-life developer employing LLMs for
everyday tasks as work. Additionally, we place an emphasis on security
awareness which is represented through the use of two distinct versions of our
developer persona. In total, we collected 61 code outputs and analyzed them
across several aspects: functionality, security, performance, complexity, and
reliability. These insights are crucial for understanding the models'
capabilities and limitations, guiding future development and practical
applications in the field of automated code generation.

---------------

### 30 Jan 2024 | [A Preliminary Study on Using Large Language Models in Software  Pentesting](https://arxiv.org/abs/2401.17459) | [⬇️](https://arxiv.org/pdf/2401.17459)
*Kumar Shashwat, Francis Hahn, Xinming Ou, Dmitry Goldgof, Lawrence  Hall, Jay Ligatti, S. Raj Rajgopalan, Armin Ziaie Tabari* 

  Large language models (LLM) are perceived to offer promising potentials for
automating security tasks, such as those found in security operation centers
(SOCs). As a first step towards evaluating this perceived potential, we
investigate the use of LLMs in software pentesting, where the main task is to
automatically identify software security vulnerabilities in source code. We
hypothesize that an LLM-based AI agent can be improved over time for a specific
security task as human operators interact with it. Such improvement can be
made, as a first step, by engineering prompts fed to the LLM based on the
responses produced, to include relevant contexts and structures so that the
model provides more accurate results. Such engineering efforts become
sustainable if the prompts that are engineered to produce better results on
current tasks, also produce better results on future unknown tasks. To examine
this hypothesis, we utilize the OWASP Benchmark Project 1.2 which contains
2,740 hand-crafted source code test cases containing various types of
vulnerabilities. We divide the test cases into training and testing data, where
we engineer the prompts based on the training data (only), and evaluate the
final system on the testing data. We compare the AI agent's performance on the
testing data against the performance of the agent without the prompt
engineering. We also compare the AI agent's results against those from
SonarQube, a widely used static code analyzer for security testing. We built
and tested multiple versions of the AI agent using different off-the-shelf LLMs
-- Google's Gemini-pro, as well as OpenAI's GPT-3.5-Turbo and GPT-4-Turbo (with
both chat completion and assistant APIs). The results show that using LLMs is a
viable approach to build an AI agent for software pentesting that can improve
through repeated use and prompt engineering.

---------------

### 09 Feb 2024 | [ResumeFlow: An LLM-facilitated Pipeline for Personalized Resume  Generation and Refinement](https://arxiv.org/abs/2402.06221) | [⬇️](https://arxiv.org/pdf/2402.06221)
*Saurabh Bhausaheb Zinjad, Amrita Bhattacharjee, Amey Bhilegaonkar,  Huan Liu* 

  Crafting the ideal, job-specific resume is a challenging task for many job
applicants, especially for early-career applicants. While it is highly
recommended that applicants tailor their resume to the specific role they are
applying for, manually tailoring resumes to job descriptions and role-specific
requirements is often (1) extremely time-consuming, and (2) prone to human
errors. Furthermore, performing such a tailoring step at scale while applying
to several roles may result in a lack of quality of the edited resumes. To
tackle this problem, in this demo paper, we propose ResumeFlow: a Large
Language Model (LLM) aided tool that enables an end user to simply provide
their detailed resume and the desired job posting, and obtain a personalized
resume specifically tailored to that specific job posting in the matter of a
few seconds. Our proposed pipeline leverages the language understanding and
information extraction capabilities of state-of-the-art LLMs such as OpenAI's
GPT-4 and Google's Gemini, in order to (1) extract details from a job
description, (2) extract role-specific details from the user-provided resume,
and then (3) use these to refine and generate a role-specific resume for the
user. Our easy-to-use tool leverages the user-chosen LLM in a completely
off-the-shelf manner, thus requiring no fine-tuning. We demonstrate the
effectiveness of our tool via a video demo and propose novel task-specific
evaluation metrics to control for alignment and hallucination. Our tool is
available at https://job-aligned-resume.streamlit.app.

---------------

### 19 Aug 2023 | [An Empirical Study of AI-based Smart Contract Creation](https://arxiv.org/abs/2308.02955) | [⬇️](https://arxiv.org/pdf/2308.02955)
*Rabimba Karanjai, Edward Li, Lei Xu, Weidong Shi* 

  The introduction of large language models (LLMs) like ChatGPT and Google
Palm2 for smart contract generation seems to be the first well-established
instance of an AI pair programmer. LLMs have access to a large number of
open-source smart contracts, enabling them to utilize more extensive code in
Solidity than other code generation tools. Although the initial and informal
assessments of LLMs for smart contract generation are promising, a systematic
evaluation is needed to explore the limits and benefits of these models. The
main objective of this study is to assess the quality of generated code
provided by LLMs for smart contracts. We also aim to evaluate the impact of the
quality and variety of input parameters fed to LLMs. To achieve this aim, we
created an experimental setup for evaluating the generated code in terms of
validity, correctness, and efficiency. Our study finds crucial evidence of
security bugs getting introduced in the generated smart contracts as well as
the overall quality and correctness of the code getting impacted. However, we
also identified the areas where it can be improved. The paper also proposes
several potential research directions to improve the process, quality and
safety of generated smart contract codes.

---------------

### 15 Jan 2024 | [The Chronicles of RAG: The Retriever, the Chunk and the Generator](https://arxiv.org/abs/2401.07883) | [⬇️](https://arxiv.org/pdf/2401.07883)
*Paulo Finardi, Leonardo Avila, Rodrigo Castaldoni, Pedro Gengo, Celio  Larcher, Marcos Piau, Pablo Costa, Vinicius Carid\'a* 

  Retrieval Augmented Generation (RAG) has become one of the most popular
paradigms for enabling LLMs to access external data, and also as a mechanism
for grounding to mitigate against hallucinations. When implementing RAG you can
face several challenges like effective integration of retrieval models,
efficient representation learning, data diversity, computational efficiency
optimization, evaluation, and quality of text generation. Given all these
challenges, every day a new technique to improve RAG appears, making it
unfeasible to experiment with all combinations for your problem. In this
context, this paper presents good practices to implement, optimize, and
evaluate RAG for the Brazilian Portuguese language, focusing on the
establishment of a simple pipeline for inference and experiments. We explored a
diverse set of methods to answer questions about the first Harry Potter book.
To generate the answers we used the OpenAI's gpt-4, gpt-4-1106-preview,
gpt-3.5-turbo-1106, and Google's Gemini Pro. Focusing on the quality of the
retriever, our approach achieved an improvement of MRR@10 by 35.4% compared to
the baseline. When optimizing the input size in the application, we observed
that it is possible to further enhance it by 2.4%. Finally, we present the
complete architecture of the RAG with our recommendations. As result, we moved
from a baseline of 57.88% to a maximum relative score of 98.61%.

---------------

### 11 Jul 2023 | [OntoChatGPT Information System: Ontology-Driven Structured Prompts for  ChatGPT Meta-Learning](https://arxiv.org/abs/2307.05082) | [⬇️](https://arxiv.org/pdf/2307.05082)
*Oleksandr Palagin, Vladislav Kaverinskiy, Anna Litvin and Kyrylo  Malakhov* 

  This research presents a comprehensive methodology for utilizing an
ontology-driven structured prompts system in interplay with ChatGPT, a widely
used large language model (LLM). The study develops formal models, both
information and functional, and establishes the methodological foundations for
integrating ontology-driven prompts with ChatGPT's meta-learning capabilities.
The resulting productive triad comprises the methodological foundations,
advanced information technology, and the OntoChatGPT system, which collectively
enhance the effectiveness and performance of chatbot systems. The
implementation of this technology is demonstrated using the Ukrainian language
within the domain of rehabilitation. By applying the proposed methodology, the
OntoChatGPT system effectively extracts entities from contexts, classifies
them, and generates relevant responses. The study highlights the versatility of
the methodology, emphasizing its applicability not only to ChatGPT but also to
other chatbot systems based on LLMs, such as Google's Bard utilizing the PaLM 2
LLM. The underlying principles of meta-learning, structured prompts, and
ontology-driven information retrieval form the core of the proposed
methodology, enabling their adaptation and utilization in various LLM-based
systems. This versatile approach opens up new possibilities for NLP and
dialogue systems, empowering developers to enhance the performance and
functionality of chatbot systems across different domains and languages.

---------------

### 05 Jul 2023 | [Distilling Step-by-Step! Outperforming Larger Language Models with Less  Training Data and Smaller Model Sizes](https://arxiv.org/abs/2305.02301) | [⬇️](https://arxiv.org/pdf/2305.02301)
*Cheng-Yu Hsieh, Chun-Liang Li, Chih-Kuan Yeh, Hootan Nakhost, Yasuhisa  Fujii, Alexander Ratner, Ranjay Krishna, Chen-Yu Lee, Tomas Pfister* 

  Deploying large language models (LLMs) is challenging because they are memory
inefficient and compute-intensive for practical applications. In reaction,
researchers train smaller task-specific models by either finetuning with human
labels or distilling using LLM-generated labels. However, finetuning and
distillation require large amounts of training data to achieve comparable
performance to LLMs. We introduce Distilling step-by-step, a new mechanism that
(a) trains smaller models that outperform LLMs, and (b) achieves so by
leveraging less training data needed by finetuning or distillation. Our method
extracts LLM rationales as additional supervision for training small models
within a multi-task framework. We present three findings across 4 NLP
benchmarks: First, compared to both finetuning and distillation, our mechanism
achieves better performance with much fewer labeled/unlabeled training
examples. Second, compared to few-shot prompted LLMs, we achieve better
performance using substantially smaller model sizes. Third, we reduce both the
model size and the amount of data required to outperform LLMs; our finetuned
770M T5 model outperforms the few-shot prompted 540B PaLM model using only 80%
of available data on a benchmark, whereas standard finetuning the same T5 model
struggles to match even by using 100% of the dataset. We release the code at:
https://github.com/google-research/distilling-step-by-step .

---------------

### 24 Dec 2023 | [An In-depth Look at Gemini's Language Abilities](https://arxiv.org/abs/2312.11444) | [⬇️](https://arxiv.org/pdf/2312.11444)
*Syeda Nahida Akter, Zichun Yu, Aashiq Muhamed, Tianyue Ou, Alex  B\"auerle, \'Angel Alexander Cabrera, Krish Dholakia, Chenyan Xiong, Graham  Neubig* 

  The recently released Google Gemini class of models are the first to
comprehensively report results that rival the OpenAI GPT series across a wide
variety of tasks. In this paper, we do an in-depth exploration of Gemini's
language abilities, making two contributions. First, we provide a third-party,
objective comparison of the abilities of the OpenAI GPT and Google Gemini
models with reproducible code and fully transparent results. Second, we take a
closer look at the results, identifying areas where one of the two model
classes excels. We perform this analysis over 10 datasets testing a variety of
language abilities, including reasoning, answering knowledge-based questions,
solving math problems, translating between languages, generating code, and
acting as instruction-following agents. From this analysis, we find that Gemini
Pro achieves accuracy that is close but slightly inferior to the corresponding
GPT 3.5 Turbo on all tasks that we benchmarked. We further provide explanations
for some of this under-performance, including failures in mathematical
reasoning with many digits, sensitivity to multiple-choice answer ordering,
aggressive content filtering, and others. We also identify areas where Gemini
demonstrates comparably high performance, including generation into non-English
languages, and handling longer and more complex reasoning chains. Code and data
for reproduction can be found at https://github.com/neulab/gemini-benchmark

---------------

### 19 Sep 2023 | [Generative AI in the Construction Industry: Opportunities & Challenges](https://arxiv.org/abs/2310.04427) | [⬇️](https://arxiv.org/pdf/2310.04427)
*Prashnna Ghimire, Kyungki Kim, Manoj Acharya* 

  In the last decade, despite rapid advancements in artificial intelligence
(AI) transforming many industry practices, construction largely lags in
adoption. Recently, the emergence and rapid adoption of advanced large language
models (LLM) like OpenAI's GPT, Google's PaLM, and Meta's Llama have shown
great potential and sparked considerable global interest. However, the current
surge lacks a study investigating the opportunities and challenges of
implementing Generative AI (GenAI) in the construction sector, creating a
critical knowledge gap for researchers and practitioners. This underlines the
necessity to explore the prospects and complexities of GenAI integration.
Bridging this gap is fundamental to optimizing GenAI's early-stage adoption
within the construction sector. Given GenAI's unprecedented capabilities to
generate human-like content based on learning from existing content, we reflect
on two guiding questions: What will the future bring for GenAI in the
construction industry? What are the potential opportunities and challenges in
implementing GenAI in the construction industry? This study delves into
reflected perception in literature, analyzes the industry perception using
programming-based word cloud and frequency analysis, and integrates authors'
opinions to answer these questions. This paper recommends a conceptual GenAI
implementation framework, provides practical recommendations, summarizes future
research questions, and builds foundational literature to foster subsequent
research expansion in GenAI within the construction and its allied architecture
& engineering domains.

---------------

### 13 Apr 2023 | [Sparks of Artificial General Intelligence: Early experiments with GPT-4](https://arxiv.org/abs/2303.12712) | [⬇️](https://arxiv.org/pdf/2303.12712)
*S\'ebastien Bubeck, Varun Chandrasekaran, Ronen Eldan, Johannes  Gehrke, Eric Horvitz, Ece Kamar, Peter Lee, Yin Tat Lee, Yuanzhi Li, Scott  Lundberg, Harsha Nori, Hamid Palangi, Marco Tulio Ribeiro, Yi Zhang* 

  Artificial intelligence (AI) researchers have been developing and refining
large language models (LLMs) that exhibit remarkable capabilities across a
variety of domains and tasks, challenging our understanding of learning and
cognition. The latest model developed by OpenAI, GPT-4, was trained using an
unprecedented scale of compute and data. In this paper, we report on our
investigation of an early version of GPT-4, when it was still in active
development by OpenAI. We contend that (this early version of) GPT-4 is part of
a new cohort of LLMs (along with ChatGPT and Google's PaLM for example) that
exhibit more general intelligence than previous AI models. We discuss the
rising capabilities and implications of these models. We demonstrate that,
beyond its mastery of language, GPT-4 can solve novel and difficult tasks that
span mathematics, coding, vision, medicine, law, psychology and more, without
needing any special prompting. Moreover, in all of these tasks, GPT-4's
performance is strikingly close to human-level performance, and often vastly
surpasses prior models such as ChatGPT. Given the breadth and depth of GPT-4's
capabilities, we believe that it could reasonably be viewed as an early (yet
still incomplete) version of an artificial general intelligence (AGI) system.
In our exploration of GPT-4, we put special emphasis on discovering its
limitations, and we discuss the challenges ahead for advancing towards deeper
and more comprehensive versions of AGI, including the possible need for
pursuing a new paradigm that moves beyond next-word prediction. We conclude
with reflections on societal influences of the recent technological leap and
future research directions.

---------------

### 05 Feb 2024 | [Illuminate: A novel approach for depression detection with explainable  analysis and proactive therapy using prompt engineering](https://arxiv.org/abs/2402.05127) | [⬇️](https://arxiv.org/pdf/2402.05127)
*Aryan Agrawal* 

  This paper introduces a novel paradigm for depression detection and treatment
using advanced Large Language Models (LLMs): Generative Pre-trained Transformer
4 (GPT-4), Llama 2 chat, and Gemini. These LLMs are fine-tuned with specialized
prompts to diagnose, explain, and suggest therapeutic interventions for
depression. A unique few-shot prompting method enhances the models' ability to
analyze and explain depressive symptoms based on the DSM-5 criteria. In the
interaction phase, the models engage in empathetic dialogue management, drawing
from resources like PsychDB and a Cognitive Behavioral Therapy (CBT) Guide,
fostering supportive interactions with individuals experiencing major
depressive disorders. Additionally, the research introduces the Illuminate
Database, enriched with various CBT modules, aiding in personalized therapy
recommendations. The study evaluates LLM performance using metrics such as F1
scores, Precision, Recall, Cosine similarity, and Recall-Oriented Understudy
for Gisting Evaluation (ROUGE) across different test sets, demonstrating their
effectiveness. This comprehensive approach blends cutting-edge AI with
established psychological methods, offering new possibilities in mental health
care and showcasing the potential of LLMs in revolutionizing depression
diagnosis and treatment strategies.

---------------
**Date:** 02 Jan 2024

**Title:** Evaluating Large Language Models on the GMAT: Implications for the  Future of Business Education

**Abstract Link:** [https://arxiv.org/abs/2401.02985](https://arxiv.org/abs/2401.02985)

**PDF Link:** [https://arxiv.org/pdf/2401.02985](https://arxiv.org/pdf/2401.02985)

---

**Date:** 10 Feb 2024

**Title:** Gemini Goes to Med School: Exploring the Capabilities of Multimodal  Large Language Models on Medical Challenge Problems & Hallucinations

**Abstract Link:** [https://arxiv.org/abs/2402.07023](https://arxiv.org/abs/2402.07023)

**PDF Link:** [https://arxiv.org/pdf/2402.07023](https://arxiv.org/pdf/2402.07023)

---

**Date:** 29 Dec 2023

**Title:** Gemini in Reasoning: Unveiling Commonsense in Multimodal Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2312.17661](https://arxiv.org/abs/2312.17661)

**PDF Link:** [https://arxiv.org/pdf/2312.17661](https://arxiv.org/pdf/2312.17661)

---

**Date:** 20 Dec 2023

**Title:** A Challenger to GPT-4V? Early Explorations of Gemini in Visual Expertise

**Abstract Link:** [https://arxiv.org/abs/2312.12436](https://arxiv.org/abs/2312.12436)

**PDF Link:** [https://arxiv.org/pdf/2312.12436](https://arxiv.org/pdf/2312.12436)

---

**Date:** 28 Feb 2024

**Title:** FOFO: A Benchmark to Evaluate LLMs' Format-Following Capability

**Abstract Link:** [https://arxiv.org/abs/2402.18667](https://arxiv.org/abs/2402.18667)

**PDF Link:** [https://arxiv.org/pdf/2402.18667](https://arxiv.org/pdf/2402.18667)

---

**Date:** 13 Feb 2024

**Title:** Combining Insights From Multiple Large Language Models Improves  Diagnostic Accuracy

**Abstract Link:** [https://arxiv.org/abs/2402.08806](https://arxiv.org/abs/2402.08806)

**PDF Link:** [https://arxiv.org/pdf/2402.08806](https://arxiv.org/pdf/2402.08806)

---

**Date:** 29 Jan 2024

**Title:** From GPT-4 to Gemini and Beyond: Assessing the Landscape of MLLMs on  Generalizability, Trustworthiness and Causality through Four Modalities

**Abstract Link:** [https://arxiv.org/abs/2401.15071](https://arxiv.org/abs/2401.15071)

**PDF Link:** [https://arxiv.org/pdf/2401.15071](https://arxiv.org/pdf/2401.15071)

---

**Date:** 04 Mar 2024

**Title:** Exploring the psychology of LLMs' Moral and Legal Reasoning

**Abstract Link:** [https://arxiv.org/abs/2308.01264](https://arxiv.org/abs/2308.01264)

**PDF Link:** [https://arxiv.org/pdf/2308.01264](https://arxiv.org/pdf/2308.01264)

---

**Date:** 11 Jan 2024

**Title:** Evidence to Generate (E2G): A Single-agent Two-step Prompting for  Context Grounded and Retrieval Augmented Reasoning

**Abstract Link:** [https://arxiv.org/abs/2401.05787](https://arxiv.org/abs/2401.05787)

**PDF Link:** [https://arxiv.org/pdf/2401.05787](https://arxiv.org/pdf/2401.05787)

---

**Date:** 01 Feb 2024

**Title:** Ocassionally Secure: A Comparative Analysis of Code Generation  Assistants

**Abstract Link:** [https://arxiv.org/abs/2402.00689](https://arxiv.org/abs/2402.00689)

**PDF Link:** [https://arxiv.org/pdf/2402.00689](https://arxiv.org/pdf/2402.00689)

---

**Date:** 30 Jan 2024

**Title:** A Preliminary Study on Using Large Language Models in Software  Pentesting

**Abstract Link:** [https://arxiv.org/abs/2401.17459](https://arxiv.org/abs/2401.17459)

**PDF Link:** [https://arxiv.org/pdf/2401.17459](https://arxiv.org/pdf/2401.17459)

---

**Date:** 09 Feb 2024

**Title:** ResumeFlow: An LLM-facilitated Pipeline for Personalized Resume  Generation and Refinement

**Abstract Link:** [https://arxiv.org/abs/2402.06221](https://arxiv.org/abs/2402.06221)

**PDF Link:** [https://arxiv.org/pdf/2402.06221](https://arxiv.org/pdf/2402.06221)

---

**Date:** 19 Aug 2023

**Title:** An Empirical Study of AI-based Smart Contract Creation

**Abstract Link:** [https://arxiv.org/abs/2308.02955](https://arxiv.org/abs/2308.02955)

**PDF Link:** [https://arxiv.org/pdf/2308.02955](https://arxiv.org/pdf/2308.02955)

---

**Date:** 15 Jan 2024

**Title:** The Chronicles of RAG: The Retriever, the Chunk and the Generator

**Abstract Link:** [https://arxiv.org/abs/2401.07883](https://arxiv.org/abs/2401.07883)

**PDF Link:** [https://arxiv.org/pdf/2401.07883](https://arxiv.org/pdf/2401.07883)

---

**Date:** 11 Jul 2023

**Title:** OntoChatGPT Information System: Ontology-Driven Structured Prompts for  ChatGPT Meta-Learning

**Abstract Link:** [https://arxiv.org/abs/2307.05082](https://arxiv.org/abs/2307.05082)

**PDF Link:** [https://arxiv.org/pdf/2307.05082](https://arxiv.org/pdf/2307.05082)

---

**Date:** 05 Jul 2023

**Title:** Distilling Step-by-Step! Outperforming Larger Language Models with Less  Training Data and Smaller Model Sizes

**Abstract Link:** [https://arxiv.org/abs/2305.02301](https://arxiv.org/abs/2305.02301)

**PDF Link:** [https://arxiv.org/pdf/2305.02301](https://arxiv.org/pdf/2305.02301)

---

**Date:** 24 Dec 2023

**Title:** An In-depth Look at Gemini's Language Abilities

**Abstract Link:** [https://arxiv.org/abs/2312.11444](https://arxiv.org/abs/2312.11444)

**PDF Link:** [https://arxiv.org/pdf/2312.11444](https://arxiv.org/pdf/2312.11444)

---

**Date:** 19 Sep 2023

**Title:** Generative AI in the Construction Industry: Opportunities & Challenges

**Abstract Link:** [https://arxiv.org/abs/2310.04427](https://arxiv.org/abs/2310.04427)

**PDF Link:** [https://arxiv.org/pdf/2310.04427](https://arxiv.org/pdf/2310.04427)

---

**Date:** 13 Apr 2023

**Title:** Sparks of Artificial General Intelligence: Early experiments with GPT-4

**Abstract Link:** [https://arxiv.org/abs/2303.12712](https://arxiv.org/abs/2303.12712)

**PDF Link:** [https://arxiv.org/pdf/2303.12712](https://arxiv.org/pdf/2303.12712)

---

**Date:** 05 Feb 2024

**Title:** Illuminate: A novel approach for depression detection with explainable  analysis and proactive therapy using prompt engineering

**Abstract Link:** [https://arxiv.org/abs/2402.05127](https://arxiv.org/abs/2402.05127)

**PDF Link:** [https://arxiv.org/pdf/2402.05127](https://arxiv.org/pdf/2402.05127)

---

