Neural Network Pruning ✂️

### 🔎 Neural Network Pruning ✂️


=========================

Pruning is a technique to reduce the size of a neural network by removing some of its weights.

This is useful for:

-   **Deployment**: Smaller networks are faster and use less memory.
-   **Training**: Pruned networks are easier to train.

Pruning is usually done in two steps:

1.  **Training**: Train the network normally.
2.  **Pruning**: Remove the smallest weights.

The weights are usually removed by setting them to zero.

Pruning can be done at different levels:

-   **Weight pruning**: Remove individual weights.
-   **Filter pruning**: Remove entire filters.
-   **Layer pruning**: Remove entire layers.

Pruning can be done in different ways:

-   **Magnitude pruning**: Remove the smallest weights.
-   **Lottery ticket pruning**: Remove the weights that are not part of the "winning ticket".
-   **Gradient-based pruning**: Remove the weights that have the smallest gradients.

Pruning can be done in different ways:

-   **One-shot pruning**: Remove the weights once.
-   **Iterative pruning**: Remove the weights multiple times.

Pruning can be done in different ways:

-   **Unstructured pruning**: Remove individual weights.
-   **Structured pruning**: Remove entire filters or layers.

Pruning can be done in different ways:

-   **Static pruning**: Remove the weights once and for all.
-   **Dynamic pruning**: Remove the weights during training.

Pruning can be done in different ways:

-   **Global pruning**: Remove the weights based on their global importance.
-   **Local pruning**: Remove the weights based on their local importance.

Pruning can be done in different ways:

-   **Hard pruning**: Remove the weights completely.
-   **Soft pruning**: Keep the weights but reduce their importance.

Pruning can be done in different ways:

...

Pruning can be done in different ways:

-   **Random pruning**: Remove the weights randomly.
-   **Systematic pruning**: Remove the
# 🩺🔍 Search Results
### 04 Dec 2018 | [Channel-wise pruning of neural networks with tapering resource  constraint](https://arxiv.org/abs/1812.07060) | [⬇️](https://arxiv.org/pdf/1812.07060)
*Alexey Kruglov* 

  Neural network pruning is an important step in design process of efficient
neural networks for edge devices with limited computational power. Pruning is a
form of knowledge transfer from the weights of the original network to a
smaller target subnetwork. We propose a new method for compute-constrained
structured channel-wise pruning of convolutional neural networks. The method
iteratively fine-tunes the network, while gradually tapering the computation
resources available to the pruned network via a holonomic constraint in the
method of Lagrangian multipliers framework. An explicit and adaptive automatic
control over the rate of tapering is provided. The trainable parameters of our
pruning method are separate from the weights of the neural network, which
allows us to avoid the interference with the neural network solver (e.g. avoid
the direct dependence of pruning speed on neural network learning rates). Our
method combines the `rigoristic' approach by the direct application of
constrained optimization, avoiding the pitfalls of ADMM-based methods, like
their need to define the target amount of resources for each pruning run, and
direct dependence of pruning speed and priority of pruning on the relative
scale of weights between layers. For VGG-16 @ ILSVRC-2012, we achieve reduction
of 15.47 -> 3.87 GMAC with only 1% top-1 accuracy reduction (68.4% -> 67.4%).
For AlexNet @ ILSVRC-2012, we achieve 0.724 -> 0.411 GMAC with 1% top-1
accuracy reduction (56.8% -> 55.8%).

---------------

### 04 Aug 2023 | [Pruning a neural network using Bayesian inference](https://arxiv.org/abs/2308.02451) | [⬇️](https://arxiv.org/pdf/2308.02451)
*Sunil Mathew, Daniel B. Rowe* 

  Neural network pruning is a highly effective technique aimed at reducing the
computational and memory demands of large neural networks. In this research
paper, we present a novel approach to pruning neural networks utilizing
Bayesian inference, which can seamlessly integrate into the training procedure.
Our proposed method leverages the posterior probabilities of the neural network
prior to and following pruning, enabling the calculation of Bayes factors. The
calculated Bayes factors guide the iterative pruning. Through comprehensive
evaluations conducted on multiple benchmarks, we demonstrate that our method
achieves desired levels of sparsity while maintaining competitive accuracy.

---------------

### 09 May 2022 | [Neural Network Pruning by Cooperative Coevolution](https://arxiv.org/abs/2204.05639) | [⬇️](https://arxiv.org/pdf/2204.05639)
*Haopu Shang, Jia-Liang Wu, Wenjing Hong, Chao Qian* 

  Neural network pruning is a popular model compression method which can
significantly reduce the computing cost with negligible loss of accuracy.
Recently, filters are often pruned directly by designing proper criteria or
using auxiliary modules to measure their importance, which, however, requires
expertise and trial-and-error. Due to the advantage of automation, pruning by
evolutionary algorithms (EAs) has attracted much attention, but the performance
is limited for deep neural networks as the search space can be quite large. In
this paper, we propose a new filter pruning algorithm CCEP by cooperative
coevolution, which prunes the filters in each layer by EAs separately. That is,
CCEP reduces the pruning space by a divide-and-conquer strategy. The
experiments show that CCEP can achieve a competitive performance with the
state-of-the-art pruning methods, e.g., prune ResNet56 for $63.42\%$ FLOPs on
CIFAR10 with $-0.24\%$ accuracy drop, and ResNet50 for $44.56\%$ FLOPs on
ImageNet with $0.07\%$ accuracy drop.

---------------

### 27 Feb 2024 | [SequentialAttention++ for Block Sparsification: Differentiable Pruning  Meets Combinatorial Optimization](https://arxiv.org/abs/2402.17902) | [⬇️](https://arxiv.org/pdf/2402.17902)
*Taisuke Yasuda, Kyriakos Axiotis, Gang Fu, MohammadHossein Bateni,  Vahab Mirrokni* 

  Neural network pruning is a key technique towards engineering large yet
scalable, interpretable, and generalizable models. Prior work on the subject
has developed largely along two orthogonal directions: (1) differentiable
pruning for efficiently and accurately scoring the importance of parameters,
and (2) combinatorial optimization for efficiently searching over the space of
sparse models. We unite the two approaches, both theoretically and empirically,
to produce a coherent framework for structured neural network pruning in which
differentiable pruning guides combinatorial optimization algorithms to select
the most important sparse set of parameters. Theoretically, we show how many
existing differentiable pruning techniques can be understood as nonconvex
regularization for group sparse optimization, and prove that for a wide class
of nonconvex regularizers, the global optimum is unique, group-sparse, and
provably yields an approximate solution to a sparse convex optimization
problem. The resulting algorithm that we propose, SequentialAttention++,
advances the state of the art in large-scale neural network block-wise pruning
tasks on the ImageNet and Criteo datasets.

---------------

### 10 Mar 2021 | [Manifold Regularized Dynamic Network Pruning](https://arxiv.org/abs/2103.05861) | [⬇️](https://arxiv.org/pdf/2103.05861)
*Yehui Tang, Yunhe Wang, Yixing Xu, Yiping Deng, Chao Xu, Dacheng Tao,  Chang Xu* 

  Neural network pruning is an essential approach for reducing the
computational complexity of deep models so that they can be well deployed on
resource-limited devices. Compared with conventional methods, the recently
developed dynamic pruning methods determine redundant filters variant to each
input instance which achieves higher acceleration. Most of the existing methods
discover effective sub-networks for each instance independently and do not
utilize the relationship between different inputs. To maximally excavate
redundancy in the given network architecture, this paper proposes a new
paradigm that dynamically removes redundant filters by embedding the manifold
information of all instances into the space of pruned networks (dubbed as
ManiDP). We first investigate the recognition complexity and feature similarity
between images in the training set. Then, the manifold relationship between
instances and the pruned sub-networks will be aligned in the training
procedure. The effectiveness of the proposed method is verified on several
benchmarks, which shows better performance in terms of both accuracy and
computational cost compared to the state-of-the-art methods. For example, our
method can reduce 55.3% FLOPs of ResNet-34 with only 0.57% top-1 accuracy
degradation on ImageNet.

---------------

### 11 Mar 2022 | [Improve Convolutional Neural Network Pruning by Maximizing Filter  Variety](https://arxiv.org/abs/2203.05807) | [⬇️](https://arxiv.org/pdf/2203.05807)
*Nathan Hubens, Matei Mancas, Bernard Gosselin, Marius Preda, Titus  Zaharia* 

  Neural network pruning is a widely used strategy for reducing model storage
and computing requirements. It allows to lower the complexity of the network by
introducing sparsity in the weights. Because taking advantage of sparse
matrices is still challenging, pruning is often performed in a structured way,
i.e. removing entire convolution filters in the case of ConvNets, according to
a chosen pruning criteria. Common pruning criteria, such as l1-norm or
movement, usually do not consider the individual utility of filters, which may
lead to: (1) the removal of filters exhibiting rare, thus important and
discriminative behaviour, and (2) the retaining of filters with redundant
information. In this paper, we present a technique solving those two issues,
and which can be appended to any pruning criteria. This technique ensures that
the criteria of selection focuses on redundant filters, while retaining the
rare ones, thus maximizing the variety of remaining filters. The experimental
results, carried out on different datasets (CIFAR-10, CIFAR-100 and
CALTECH-101) and using different architectures (VGG-16 and ResNet-18)
demonstrate that it is possible to achieve similar sparsity levels while
maintaining a higher performance when appending our filter selection technique
to pruning criteria. Moreover, we assess the quality of the found sparse
sub-networks by applying the Lottery Ticket Hypothesis and find that the
addition of our method allows to discover better performing tickets in most
cases

---------------

### 04 Mar 2021 | [Lost in Pruning: The Effects of Pruning Neural Networks beyond Test  Accuracy](https://arxiv.org/abs/2103.03014) | [⬇️](https://arxiv.org/pdf/2103.03014)
*Lucas Liebenwein, Cenk Baykal, Brandon Carter, David Gifford, Daniela  Rus* 

  Neural network pruning is a popular technique used to reduce the inference
costs of modern, potentially overparameterized, networks. Starting from a
pre-trained network, the process is as follows: remove redundant parameters,
retrain, and repeat while maintaining the same test accuracy. The result is a
model that is a fraction of the size of the original with comparable predictive
performance (test accuracy). Here, we reassess and evaluate whether the use of
test accuracy alone in the terminating condition is sufficient to ensure that
the resulting model performs well across a wide spectrum of "harder" metrics
such as generalization to out-of-distribution data and resilience to noise.
Across evaluations on varying architectures and data sets, we find that pruned
networks effectively approximate the unpruned model, however, the prune ratio
at which pruned networks achieve commensurate performance varies significantly
across tasks. These results call into question the extent of \emph{genuine}
overparameterization in deep learning and raise concerns about the
practicability of deploying pruned networks, specifically in the context of
safety-critical systems, unless they are widely evaluated beyond test accuracy
to reliably predict their performance. Our code is available at
https://github.com/lucaslie/torchprune.

---------------

### 21 Dec 2019 | [DBP: Discrimination Based Block-Level Pruning for Deep Model  Acceleration](https://arxiv.org/abs/1912.10178) | [⬇️](https://arxiv.org/pdf/1912.10178)
*Wenxiao Wang, Shuai Zhao, Minghao Chen, Jinming Hu, Deng Cai, Haifeng  Liu* 

  Neural network pruning is one of the most popular methods of accelerating the
inference of deep convolutional neural networks (CNNs). The dominant pruning
methods, filter-level pruning methods, evaluate their performance through the
reduction ratio of computations and deem that a higher reduction ratio of
computations is equivalent to a higher acceleration ratio in terms of inference
time. However, we argue that they are not equivalent if parallel computing is
considered. Given that filter-level pruning only prunes filters in layers and
computations in a layer usually run in parallel, most computations reduced by
filter-level pruning usually run in parallel with the un-reduced ones. Thus,
the acceleration ratio of filter-level pruning is limited. To get a higher
acceleration ratio, it is better to prune redundant layers because computations
of different layers cannot run in parallel. In this paper, we propose our
Discrimination based Block-level Pruning method (DBP). Specifically, DBP takes
a sequence of consecutive layers (e.g., Conv-BN-ReLu) as a block and removes
redundant blocks according to the discrimination of their output features. As a
result, DBP achieves a considerable acceleration ratio by reducing the depth of
CNNs. Extensive experiments show that DBP has surpassed state-of-the-art
filter-level pruning methods in both accuracy and acceleration ratio. Our code
will be made available soon.

---------------

### 03 Jun 2020 | [Knapsack Pruning with Inner Distillation](https://arxiv.org/abs/2002.08258) | [⬇️](https://arxiv.org/pdf/2002.08258)
*Yonathan Aflalo and Asaf Noy and Ming Lin and Itamar Friedman and Lihi  Zelnik* 

  Neural network pruning reduces the computational cost of an
over-parameterized network to improve its efficiency. Popular methods vary from
$\ell_1$-norm sparsification to Neural Architecture Search (NAS). In this work,
we propose a novel pruning method that optimizes the final accuracy of the
pruned network and distills knowledge from the over-parameterized parent
network's inner layers. To enable this approach, we formulate the network
pruning as a Knapsack Problem which optimizes the trade-off between the
importance of neurons and their associated computational cost. Then we prune
the network channels while maintaining the high-level structure of the network.
The pruned network is fine-tuned under the supervision of the parent network
using its inner network knowledge, a technique we refer to as the Inner
Knowledge Distillation. Our method leads to state-of-the-art pruning results on
ImageNet, CIFAR-10 and CIFAR-100 using ResNet backbones. To prune complex
network structures such as convolutions with skip-links and depth-wise
convolutions, we propose a block grouping approach to cope with these
structures. Through this we produce compact architectures with the same FLOPs
as EfficientNet-B0 and MobileNetV3 but with higher accuracy, by $1\%$ and
$0.3\%$ respectively on ImageNet, and faster runtime on GPU.

---------------

### 11 Jul 2023 | [Distributed Pruning Towards Tiny Neural Networks in Federated Learning](https://arxiv.org/abs/2212.01977) | [⬇️](https://arxiv.org/pdf/2212.01977)
*Hong Huang, Lan Zhang, Chaoyue Sun, Ruogu Fang, Xiaoyong Yuan, Dapeng  Wu* 

  Neural network pruning is an essential technique for reducing the size and
complexity of deep neural networks, enabling large-scale models on devices with
limited resources. However, existing pruning approaches heavily rely on
training data for guiding the pruning strategies, making them ineffective for
federated learning over distributed and confidential datasets. Additionally,
the memory- and computation-intensive pruning process becomes infeasible for
recourse-constrained devices in federated learning. To address these
challenges, we propose FedTiny, a distributed pruning framework for federated
learning that generates specialized tiny models for memory- and
computing-constrained devices. We introduce two key modules in FedTiny to
adaptively search coarse- and finer-pruned specialized models to fit deployment
scenarios with sparse and cheap local computation. First, an adaptive batch
normalization selection module is designed to mitigate biases in pruning caused
by the heterogeneity of local data. Second, a lightweight progressive pruning
module aims to finer prune the models under strict memory and computational
budgets, allowing the pruning policy for each layer to be gradually determined
rather than evaluating the overall model structure. The experimental results
demonstrate the effectiveness of FedTiny, which outperforms state-of-the-art
approaches, particularly when compressing deep models to extremely sparse tiny
models. FedTiny achieves an accuracy improvement of 2.61% while significantly
reducing the computational cost by 95.91% and the memory footprint by 94.01%
compared to state-of-the-art methods.

---------------

### 11 Jan 2024 | [Dynamic ASR Pathways: An Adaptive Masking Approach Towards Efficient  Pruning of A Multilingual ASR Model](https://arxiv.org/abs/2309.13018) | [⬇️](https://arxiv.org/pdf/2309.13018)
*Jiamin Xie, Ke Li, Jinxi Guo, Andros Tjandra, Yuan Shangguan, Leda  Sari, Chunyang Wu, Junteng Jia, Jay Mahadeokar, Ozlem Kalinli* 

  Neural network pruning offers an effective method for compressing a
multilingual automatic speech recognition (ASR) model with minimal performance
loss. However, it entails several rounds of pruning and re-training needed to
be run for each language. In this work, we propose the use of an adaptive
masking approach in two scenarios for pruning a multilingual ASR model
efficiently, each resulting in sparse monolingual models or a sparse
multilingual model (named as Dynamic ASR Pathways). Our approach dynamically
adapts the sub-network, avoiding premature decisions about a fixed sub-network
structure. We show that our approach outperforms existing pruning methods when
targeting sparse monolingual models. Further, we illustrate that Dynamic ASR
Pathways jointly discovers and trains better sub-networks (pathways) of a
single multilingual model by adapting from different sub-network
initializations, thereby reducing the need for language-specific pruning.

---------------

### 30 Sep 2021 | [RED++ : Data-Free Pruning of Deep Neural Networks via Input Splitting  and Output Merging](https://arxiv.org/abs/2110.01397) | [⬇️](https://arxiv.org/pdf/2110.01397)
*Edouard Yvinec, Arnaud Dapogny, Matthieu Cord and Kevin Bailly* 

  Pruning Deep Neural Networks (DNNs) is a prominent field of study in the goal
of inference runtime acceleration. In this paper, we introduce a novel
data-free pruning protocol RED++. Only requiring a trained neural network, and
not specific to DNN architecture, we exploit an adaptive data-free scalar
hashing which exhibits redundancies among neuron weight values. We study the
theoretical and empirical guarantees on the preservation of the accuracy from
the hashing as well as the expected pruning ratio resulting from the
exploitation of said redundancies. We propose a novel data-free pruning
technique of DNN layers which removes the input-wise redundant operations. This
algorithm is straightforward, parallelizable and offers novel perspective on
DNN pruning by shifting the burden of large computation to efficient memory
access and allocation. We provide theoretical guarantees on RED++ performance
and empirically demonstrate its superiority over other data-free pruning
methods and its competitiveness with data-driven ones on ResNets, MobileNets
and EfficientNets.

---------------

### 12 Jun 2023 | [Resource Efficient Neural Networks Using Hessian Based Pruning](https://arxiv.org/abs/2306.07030) | [⬇️](https://arxiv.org/pdf/2306.07030)
*Jack Chong, Manas Gupta, Lihui Chen* 

  Neural network pruning is a practical way for reducing the size of trained
models and the number of floating-point operations. One way of pruning is to
use the relative Hessian trace to calculate sensitivity of each channel, as
compared to the more common magnitude pruning approach. However, the stochastic
approach used to estimate the Hessian trace needs to iterate over many times
before it can converge. This can be time-consuming when used for larger models
with many millions of parameters. To address this problem, we modify the
existing approach by estimating the Hessian trace using FP16 precision instead
of FP32. We test the modified approach (EHAP) on
ResNet-32/ResNet-56/WideResNet-28-8 trained on CIFAR10/CIFAR100 image
classification tasks and achieve faster computation of the Hessian trace.
Specifically, our modified approach can achieve speed ups ranging from 17% to
as much as 44% during our experiments on different combinations of model
architectures and GPU devices. Our modified approach also takes up around 40%
less GPU memory when pruning ResNet-32 and ResNet-56 models, which allows for a
larger Hessian batch size to be used for estimating the Hessian trace.
Meanwhile, we also present the results of pruning using both FP16 and FP32
Hessian trace calculation and show that there are no noticeable accuracy
differences between the two. Overall, it is a simple and effective way to
compute the relative Hessian trace faster without sacrificing on pruned model
performance. We also present a full pipeline using EHAP and quantization aware
training (QAT), using INT8 QAT to compress the network further after pruning.
In particular, we use symmetric quantization for the weights and asymmetric
quantization for the activations.

---------------

### 08 Apr 2023 | [Connectivity Matters: Neural Network Pruning Through the Lens of  Effective Sparsity](https://arxiv.org/abs/2107.02306) | [⬇️](https://arxiv.org/pdf/2107.02306)
*Artem Vysogorets, Julia Kempe* 

  Neural network pruning is a fruitful area of research with surging interest
in high sparsity regimes. Benchmarking in this domain heavily relies on
faithful representation of the sparsity of subnetworks, which has been
traditionally computed as the fraction of removed connections (direct
sparsity). This definition, however, fails to recognize unpruned parameters
that detached from input or output layers of underlying subnetworks,
potentially underestimating actual effective sparsity: the fraction of
inactivated connections. While this effect might be negligible for moderately
pruned networks (up to 10-100 compression rates), we find that it plays an
increasing role for thinner subnetworks, greatly distorting comparison between
different pruning algorithms. For example, we show that effective compression
of a randomly pruned LeNet-300-100 can be orders of magnitude larger than its
direct counterpart, while no discrepancy is ever observed when using SynFlow
for pruning [Tanaka et al., 2020]. In this work, we adopt the lens of effective
sparsity to reevaluate several recent pruning algorithms on common benchmark
architectures (e.g., LeNet-300-100, VGG-19, ResNet-18) and discover that their
absolute and relative performance changes dramatically in this new and more
appropriate framework. To aim for effective, rather than direct, sparsity, we
develop a low-cost extension to most pruning algorithms. Further, equipped with
effective sparsity as a reference frame, we partially reconfirm that random
pruning with appropriate sparsity allocation across layers performs as well or
better than more sophisticated algorithms for pruning at initialization [Su et
al., 2020]. In response to this observation, using a simple analogy of pressure
distribution in coupled cylinders from physics, we design novel layerwise
sparsity quotas that outperform all existing baselines in the context of random
pruning.

---------------

### 23 May 2022 | [Recent Advances on Neural Network Pruning at Initialization](https://arxiv.org/abs/2103.06460) | [⬇️](https://arxiv.org/pdf/2103.06460)
*Huan Wang, Can Qin, Yue Bai, Yulun Zhang, Yun Fu* 

  Neural network pruning typically removes connections or neurons from a
pretrained converged model; while a new pruning paradigm, pruning at
initialization (PaI), attempts to prune a randomly initialized network. This
paper offers the first survey concentrated on this emerging pruning fashion. We
first introduce a generic formulation of neural network pruning, followed by
the major classic pruning topics. Then, as the main body of this paper, a
thorough and structured literature review of PaI methods is presented,
consisting of two major tracks (sparse training and sparse selection). Finally,
we summarize the surge of PaI compared to PaT and discuss the open problems.
Apart from the dedicated literature review, this paper also offers a code base
for easy sanity-checking and benchmarking of different PaI methods.

---------------

### 28 Dec 2021 | [A Framework for Neural Network Pruning Using Gibbs Distributions](https://arxiv.org/abs/2006.04981) | [⬇️](https://arxiv.org/pdf/2006.04981)
*Alex Labach and Shahrokh Valaee* 

  Modern deep neural networks are often too large to use in many practical
scenarios. Neural network pruning is an important technique for reducing the
size of such models and accelerating inference. Gibbs pruning is a novel
framework for expressing and designing neural network pruning methods.
Combining approaches from statistical physics and stochastic regularization
methods, it can train and prune a network simultaneously in such a way that the
learned weights and pruning mask are well-adapted for each other. It can be
used for structured or unstructured pruning and we propose a number of specific
methods for each. We compare our proposed methods to a number of contemporary
neural network pruning methods and find that Gibbs pruning outperforms them. In
particular, we achieve a new state-of-the-art result for pruning ResNet-56 with
the CIFAR-10 dataset.

---------------

### 03 Aug 2022 | [Membership Inference Attacks and Defenses in Neural Network Pruning](https://arxiv.org/abs/2202.03335) | [⬇️](https://arxiv.org/pdf/2202.03335)
*Xiaoyong Yuan, Lan Zhang* 

  Neural network pruning has been an essential technique to reduce the
computation and memory requirements for using deep neural networks for
resource-constrained devices. Most existing research focuses primarily on
balancing the sparsity and accuracy of a pruned neural network by strategically
removing insignificant parameters and retraining the pruned model. Such efforts
on reusing training samples pose serious privacy risks due to increased
memorization, which, however, has not been investigated yet.
  In this paper, we conduct the first analysis of privacy risks in neural
network pruning. Specifically, we investigate the impacts of neural network
pruning on training data privacy, i.e., membership inference attacks. We first
explore the impact of neural network pruning on prediction divergence, where
the pruning process disproportionately affects the pruned model's behavior for
members and non-members. Meanwhile, the influence of divergence even varies
among different classes in a fine-grained manner. Enlighten by such divergence,
we proposed a self-attention membership inference attack against the pruned
neural networks. Extensive experiments are conducted to rigorously evaluate the
privacy impacts of different pruning approaches, sparsity levels, and adversary
knowledge. The proposed attack shows the higher attack performance on the
pruned models when compared with eight existing membership inference attacks.
In addition, we propose a new defense mechanism to protect the pruning process
by mitigating the prediction divergence based on KL-divergence distance, whose
effectiveness has been experimentally demonstrated to effectively mitigate the
privacy risks while maintaining the sparsity and accuracy of the pruned models.

---------------

### 20 May 2021 | [A Probabilistic Approach to Neural Network Pruning](https://arxiv.org/abs/2105.10065) | [⬇️](https://arxiv.org/pdf/2105.10065)
*Xin Qian, Diego Klabjan* 

  Neural network pruning techniques reduce the number of parameters without
compromising predicting ability of a network. Many algorithms have been
developed for pruning both over-parameterized fully-connected networks (FCNs)
and convolutional neural networks (CNNs), but analytical studies of
capabilities and compression ratios of such pruned sub-networks are lacking. We
theoretically study the performance of two pruning techniques (random and
magnitude-based) on FCNs and CNNs. Given a target network {whose weights are
independently sampled from appropriate distributions}, we provide a universal
approach to bound the gap between a pruned and the target network in a
probabilistic sense. The results establish that there exist pruned networks
with expressive power within any specified bound from the target network.

---------------

### 12 Oct 2023 | [Samples on Thin Ice: Re-Evaluating Adversarial Pruning of Neural  Networks](https://arxiv.org/abs/2310.08073) | [⬇️](https://arxiv.org/pdf/2310.08073)
*Giorgio Piras, Maura Pintor, Ambra Demontis, Battista Biggio* 

  Neural network pruning has shown to be an effective technique for reducing
the network size, trading desirable properties like generalization and
robustness to adversarial attacks for higher sparsity. Recent work has claimed
that adversarial pruning methods can produce sparse networks while also
preserving robustness to adversarial examples. In this work, we first
re-evaluate three state-of-the-art adversarial pruning methods, showing that
their robustness was indeed overestimated. We then compare pruned and dense
versions of the same models, discovering that samples on thin ice, i.e., closer
to the unpruned model's decision boundary, are typically misclassified after
pruning. We conclude by discussing how this intuition may lead to designing
more effective adversarial pruning methods in future work.

---------------

### 16 Feb 2020 | [A Signal Propagation Perspective for Pruning Neural Networks at  Initialization](https://arxiv.org/abs/1906.06307) | [⬇️](https://arxiv.org/pdf/1906.06307)
*Namhoon Lee, Thalaiyasingam Ajanthan, Stephen Gould, Philip H. S. Torr* 

  Network pruning is a promising avenue for compressing deep neural networks. A
typical approach to pruning starts by training a model and then removing
redundant parameters while minimizing the impact on what is learned.
Alternatively, a recent approach shows that pruning can be done at
initialization prior to training, based on a saliency criterion called
connection sensitivity. However, it remains unclear exactly why pruning an
untrained, randomly initialized neural network is effective. In this work, by
noting connection sensitivity as a form of gradient, we formally characterize
initialization conditions to ensure reliable connection sensitivity
measurements, which in turn yields effective pruning results. Moreover, we
analyze the signal propagation properties of the resulting pruned networks and
introduce a simple, data-free method to improve their trainability. Our
modifications to the existing pruning at initialization method lead to improved
results on all tested network models for image classification tasks.
Furthermore, we empirically study the effect of supervision for pruning and
demonstrate that our signal propagation perspective, combined with unsupervised
pruning, can be useful in various scenarios where pruning is applied to
non-standard arbitrarily-designed architectures.

---------------
**Date:** 04 Dec 2018

**Title:** Channel-wise pruning of neural networks with tapering resource  constraint

**Abstract Link:** [https://arxiv.org/abs/1812.07060](https://arxiv.org/abs/1812.07060)

**PDF Link:** [https://arxiv.org/pdf/1812.07060](https://arxiv.org/pdf/1812.07060)

---

**Date:** 04 Aug 2023

**Title:** Pruning a neural network using Bayesian inference

**Abstract Link:** [https://arxiv.org/abs/2308.02451](https://arxiv.org/abs/2308.02451)

**PDF Link:** [https://arxiv.org/pdf/2308.02451](https://arxiv.org/pdf/2308.02451)

---

**Date:** 09 May 2022

**Title:** Neural Network Pruning by Cooperative Coevolution

**Abstract Link:** [https://arxiv.org/abs/2204.05639](https://arxiv.org/abs/2204.05639)

**PDF Link:** [https://arxiv.org/pdf/2204.05639](https://arxiv.org/pdf/2204.05639)

---

**Date:** 27 Feb 2024

**Title:** SequentialAttention++ for Block Sparsification: Differentiable Pruning  Meets Combinatorial Optimization

**Abstract Link:** [https://arxiv.org/abs/2402.17902](https://arxiv.org/abs/2402.17902)

**PDF Link:** [https://arxiv.org/pdf/2402.17902](https://arxiv.org/pdf/2402.17902)

---

**Date:** 10 Mar 2021

**Title:** Manifold Regularized Dynamic Network Pruning

**Abstract Link:** [https://arxiv.org/abs/2103.05861](https://arxiv.org/abs/2103.05861)

**PDF Link:** [https://arxiv.org/pdf/2103.05861](https://arxiv.org/pdf/2103.05861)

---

**Date:** 11 Mar 2022

**Title:** Improve Convolutional Neural Network Pruning by Maximizing Filter  Variety

**Abstract Link:** [https://arxiv.org/abs/2203.05807](https://arxiv.org/abs/2203.05807)

**PDF Link:** [https://arxiv.org/pdf/2203.05807](https://arxiv.org/pdf/2203.05807)

---

**Date:** 04 Mar 2021

**Title:** Lost in Pruning: The Effects of Pruning Neural Networks beyond Test  Accuracy

**Abstract Link:** [https://arxiv.org/abs/2103.03014](https://arxiv.org/abs/2103.03014)

**PDF Link:** [https://arxiv.org/pdf/2103.03014](https://arxiv.org/pdf/2103.03014)

---

**Date:** 21 Dec 2019

**Title:** DBP: Discrimination Based Block-Level Pruning for Deep Model  Acceleration

**Abstract Link:** [https://arxiv.org/abs/1912.10178](https://arxiv.org/abs/1912.10178)

**PDF Link:** [https://arxiv.org/pdf/1912.10178](https://arxiv.org/pdf/1912.10178)

---

**Date:** 03 Jun 2020

**Title:** Knapsack Pruning with Inner Distillation

**Abstract Link:** [https://arxiv.org/abs/2002.08258](https://arxiv.org/abs/2002.08258)

**PDF Link:** [https://arxiv.org/pdf/2002.08258](https://arxiv.org/pdf/2002.08258)

---

**Date:** 11 Jul 2023

**Title:** Distributed Pruning Towards Tiny Neural Networks in Federated Learning

**Abstract Link:** [https://arxiv.org/abs/2212.01977](https://arxiv.org/abs/2212.01977)

**PDF Link:** [https://arxiv.org/pdf/2212.01977](https://arxiv.org/pdf/2212.01977)

---

**Date:** 11 Jan 2024

**Title:** Dynamic ASR Pathways: An Adaptive Masking Approach Towards Efficient  Pruning of A Multilingual ASR Model

**Abstract Link:** [https://arxiv.org/abs/2309.13018](https://arxiv.org/abs/2309.13018)

**PDF Link:** [https://arxiv.org/pdf/2309.13018](https://arxiv.org/pdf/2309.13018)

---

**Date:** 30 Sep 2021

**Title:** RED++ : Data-Free Pruning of Deep Neural Networks via Input Splitting  and Output Merging

**Abstract Link:** [https://arxiv.org/abs/2110.01397](https://arxiv.org/abs/2110.01397)

**PDF Link:** [https://arxiv.org/pdf/2110.01397](https://arxiv.org/pdf/2110.01397)

---

**Date:** 12 Jun 2023

**Title:** Resource Efficient Neural Networks Using Hessian Based Pruning

**Abstract Link:** [https://arxiv.org/abs/2306.07030](https://arxiv.org/abs/2306.07030)

**PDF Link:** [https://arxiv.org/pdf/2306.07030](https://arxiv.org/pdf/2306.07030)

---

**Date:** 08 Apr 2023

**Title:** Connectivity Matters: Neural Network Pruning Through the Lens of  Effective Sparsity

**Abstract Link:** [https://arxiv.org/abs/2107.02306](https://arxiv.org/abs/2107.02306)

**PDF Link:** [https://arxiv.org/pdf/2107.02306](https://arxiv.org/pdf/2107.02306)

---

**Date:** 23 May 2022

**Title:** Recent Advances on Neural Network Pruning at Initialization

**Abstract Link:** [https://arxiv.org/abs/2103.06460](https://arxiv.org/abs/2103.06460)

**PDF Link:** [https://arxiv.org/pdf/2103.06460](https://arxiv.org/pdf/2103.06460)

---

**Date:** 28 Dec 2021

**Title:** A Framework for Neural Network Pruning Using Gibbs Distributions

**Abstract Link:** [https://arxiv.org/abs/2006.04981](https://arxiv.org/abs/2006.04981)

**PDF Link:** [https://arxiv.org/pdf/2006.04981](https://arxiv.org/pdf/2006.04981)

---

**Date:** 03 Aug 2022

**Title:** Membership Inference Attacks and Defenses in Neural Network Pruning

**Abstract Link:** [https://arxiv.org/abs/2202.03335](https://arxiv.org/abs/2202.03335)

**PDF Link:** [https://arxiv.org/pdf/2202.03335](https://arxiv.org/pdf/2202.03335)

---

**Date:** 20 May 2021

**Title:** A Probabilistic Approach to Neural Network Pruning

**Abstract Link:** [https://arxiv.org/abs/2105.10065](https://arxiv.org/abs/2105.10065)

**PDF Link:** [https://arxiv.org/pdf/2105.10065](https://arxiv.org/pdf/2105.10065)

---

**Date:** 12 Oct 2023

**Title:** Samples on Thin Ice: Re-Evaluating Adversarial Pruning of Neural  Networks

**Abstract Link:** [https://arxiv.org/abs/2310.08073](https://arxiv.org/abs/2310.08073)

**PDF Link:** [https://arxiv.org/pdf/2310.08073](https://arxiv.org/pdf/2310.08073)

---

**Date:** 16 Feb 2020

**Title:** A Signal Propagation Perspective for Pruning Neural Networks at  Initialization

**Abstract Link:** [https://arxiv.org/abs/1906.06307](https://arxiv.org/abs/1906.06307)

**PDF Link:** [https://arxiv.org/pdf/1906.06307](https://arxiv.org/pdf/1906.06307)

---

