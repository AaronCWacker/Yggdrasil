Training Methodologies 📚

### 🔎 Training Methodologies 📚



# The 5 Best Ways to Learn a New Skill

Learning a new skill can be a daunting task, but it doesn't have to be. With the right approach, you can make the process enjoyable and rewarding. Here are the 5 best ways to learn a new skill:

1. Practice regularly: Consistency is key when it comes to learning a new skill. Set aside time each day to practice, even if it's just for a few minutes. The more you practice, the more comfortable you'll become with the skill.
2. Break it down: Learning a new skill can be overwhelming, so break it down into smaller, manageable parts. Focus on one aspect of the skill at a time, and gradually build up to more complex tasks.
3. Learn from experts: Seek out experts in the field and learn from them. Watch videos, read books, and attend workshops or classes. You can also find online communities where you can connect with like-minded individuals and learn from their experiences.
4. Get feedback: Feedback is essential when learning a new skill. Ask for constructive criticism from teachers, mentors, or peers. This will help you identify areas where you need improvement and give you the opportunity to make adjustments.
5. Stay motivated: Learning a new skill takes time and effort, so it's important to stay motivated. Set goals, track your progress, and celebrate your successes along the way. Remember, the journey is just as important as the destination.

By following these tips, you can make the process of learning a new skill more enjoyable and rewarding. Happy learning!</s>
# 🩺🔍 Search Results
### 25 Jul 2022 | [Dive into Big Model Training](https://arxiv.org/abs/2207.11912) | [⬇️](https://arxiv.org/pdf/2207.11912)
*Qinghua Liu, Yuxiang Jiang* 

  The increasing scale of model size and continuous improvement of performance
herald the arrival of the Big Model era. In this report, we explore what and
how the big model training works by diving into training objectives and
training methodologies. Specifically,training objectives describe how to
leverage web-scale data to develop extremely capable and incredibly large
models based on self-supervised learning, and training methodologies which are
based on distributed training describe how to make big model training a
reality. We summarize the existing training methodologies into three main
categories: training parallelism, memory-saving technologies, and model
sparsity design. Training parallelism can be categorized into data, pipeline,
and tensor parallelism according to the dimension of parallelism that takes
place. Memory-saving technologies are orthogonal and complementary to training
parallelism. And model sparsity design further scales up the model size with a
constant computational cost. A continuously updated paper list of big model
training is provided at https://github.com/qhliu26/BM-Training.

---------------

### 11 Nov 2017 | [CT-SRCNN: Cascade Trained and Trimmed Deep Convolutional Neural Networks  for Image Super Resolution](https://arxiv.org/abs/1711.04048) | [⬇️](https://arxiv.org/pdf/1711.04048)
*Haoyu Ren, Mostafa El-Khamy, and Jungwon Lee* 

  We propose methodologies to train highly accurate and efficient deep
convolutional neural networks (CNNs) for image super resolution (SR). A cascade
training approach to deep learning is proposed to improve the accuracy of the
neural networks while gradually increasing the number of network layers. Next,
we explore how to improve the SR efficiency by making the network slimmer. Two
methodologies, the one-shot trimming and the cascade trimming, are proposed.
With the cascade trimming, the network's size is gradually reduced layer by
layer, without significant loss on its discriminative ability. Experiments on
benchmark image datasets show that our proposed SR network achieves the
state-of-the-art super resolution accuracy, while being more than 4 times
faster compared to existing deep super resolution networks.

---------------

### 28 May 2021 | [WeaQA: Weak Supervision via Captions for Visual Question Answering](https://arxiv.org/abs/2012.02356) | [⬇️](https://arxiv.org/pdf/2012.02356)
*Pratyay Banerjee, Tejas Gokhale, Yezhou Yang, Chitta Baral* 

  Methodologies for training visual question answering (VQA) models assume the
availability of datasets with human-annotated \textit{Image-Question-Answer}
(I-Q-A) triplets. This has led to heavy reliance on datasets and a lack of
generalization to new types of questions and scenes. Linguistic priors along
with biases and errors due to annotator subjectivity have been shown to
percolate into VQA models trained on such samples. We study whether models can
be trained without any human-annotated Q-A pairs, but only with images and
their associated textual descriptions or captions. We present a method to train
models with synthetic Q-A pairs generated procedurally from captions.
Additionally, we demonstrate the efficacy of spatial-pyramid image patches as a
simple but effective alternative to dense and costly object bounding box
annotations used in existing VQA models. Our experiments on three VQA
benchmarks demonstrate the efficacy of this weakly-supervised approach,
especially on the VQA-CP challenge, which tests performance under changing
linguistic priors.

---------------

### 21 Mar 2023 | [Boosting Verified Training for Robust Image Classifications via  Abstraction](https://arxiv.org/abs/2303.11552) | [⬇️](https://arxiv.org/pdf/2303.11552)
*Zhaodi Zhang, Zhiyi Xue, Yang Chen, Si Liu, Yueling Zhang, Jing Liu,  Min Zhang* 

  This paper proposes a novel, abstraction-based, certified training method for
robust image classifiers. Via abstraction, all perturbed images are mapped into
intervals before feeding into neural networks for training. By training on
intervals, all the perturbed images that are mapped to the same interval are
classified as the same label, rendering the variance of training sets to be
small and the loss landscape of the models to be smooth. Consequently, our
approach significantly improves the robustness of trained models. For the
abstraction, our training method also enables a sound and complete black-box
verification approach, which is orthogonal and scalable to arbitrary types of
neural networks regardless of their sizes and architectures. We evaluate our
method on a wide range of benchmarks in different scales. The experimental
results show that our method outperforms state of the art by (i) reducing the
verified errors of trained models up to 95.64%; (ii) totally achieving up to
602.50x speedup; and (iii) scaling up to larger models with up to 138 million
trainable parameters. The demo is available at
https://github.com/zhangzhaodi233/ABSCERT.git.

---------------

### 03 Feb 2024 | [Rethinking the Starting Point: Enhancing Performance and Fairness of  Federated Learning via Collaborative Pre-Training](https://arxiv.org/abs/2402.02225) | [⬇️](https://arxiv.org/pdf/2402.02225)
*Yun-Wei Chu, Dong-Jun Han, Seyyedali Hosseinalipour, Christopher G.  Brinton* 

  Most existing federated learning (FL) methodologies have assumed training
begins from a randomly initialized model. Recently, several studies have
empirically demonstrated that leveraging a pre-trained model can offer
advantageous initializations for FL. In this paper, we propose a collaborative
pre-training approach, CoPreFL, which strategically designs a pre-trained model
to serve as a good initialization for any downstream FL task. The key idea of
our pre-training algorithm is a meta-learning procedure which mimics downstream
distributed scenarios, enabling it to adapt to any unforeseen FL task.
CoPreFL's pre-training optimization procedure also strikes a balance between
average performance and fairness, with the aim of addressing these competing
challenges in downstream FL tasks through intelligent initializations.
Extensive experimental results validate that our pre-training method provides a
robust initialization for any unseen downstream FL task, resulting in enhanced
average performance and more equitable predictions.

---------------

### 31 Jan 2023 | [Friend-training: Learning from Models of Different but Related Tasks](https://arxiv.org/abs/2301.13683) | [⬇️](https://arxiv.org/pdf/2301.13683)
*Mian Zhang, Lifeng Jin, Linfeng Song, Haitao Mi, Xiabing Zhou and Dong  Yu* 

  Current self-training methods such as standard self-training, co-training,
tri-training, and others often focus on improving model performance on a single
task, utilizing differences in input features, model architectures, and
training processes. However, many tasks in natural language processing are
about different but related aspects of language, and models trained for one
task can be great teachers for other related tasks. In this work, we propose
friend-training, a cross-task self-training framework, where models trained to
do different tasks are used in an iterative training, pseudo-labeling, and
retraining process to help each other for better selection of pseudo-labels.
With two dialogue understanding tasks, conversational semantic role labeling
and dialogue rewriting, chosen for a case study, we show that the models
trained with the friend-training framework achieve the best performance
compared to strong baselines.

---------------

### 02 Sep 2023 | [On the training and generalization of deep operator networks](https://arxiv.org/abs/2309.01020) | [⬇️](https://arxiv.org/pdf/2309.01020)
*Sanghyun Lee, Yeonjong Shin* 

  We present a novel training method for deep operator networks (DeepONets),
one of the most popular neural network models for operators. DeepONets are
constructed by two sub-networks, namely the branch and trunk networks.
Typically, the two sub-networks are trained simultaneously, which amounts to
solving a complex optimization problem in a high dimensional space. In
addition, the nonconvex and nonlinear nature makes training very challenging.
To tackle such a challenge, we propose a two-step training method that trains
the trunk network first and then sequentially trains the branch network. The
core mechanism is motivated by the divide-and-conquer paradigm and is the
decomposition of the entire complex training task into two subtasks with
reduced complexity. Therein the Gram-Schmidt orthonormalization process is
introduced which significantly improves stability and generalization ability.
On the theoretical side, we establish a generalization error estimate in terms
of the number of training data, the width of DeepONets, and the number of input
and output sensors. Numerical examples are presented to demonstrate the
effectiveness of the two-step training method, including Darcy flow in
heterogeneous porous media.

---------------

### 04 Dec 2023 | [Federated Learning is Better with Non-Homomorphic Encryption](https://arxiv.org/abs/2312.02074) | [⬇️](https://arxiv.org/pdf/2312.02074)
*Konstantin Burlachenko, Abdulmajeed Alrowithi, Fahad Ali Albalawi,  Peter Richtarik* 

  Traditional AI methodologies necessitate centralized data collection, which
becomes impractical when facing problems with network communication, data
privacy, or storage capacity. Federated Learning (FL) offers a paradigm that
empowers distributed AI model training without collecting raw data. There are
different choices for providing privacy during FL training. One of the popular
methodologies is employing Homomorphic Encryption (HE) - a breakthrough in
privacy-preserving computation from Cryptography. However, these methods have a
price in the form of extra computation and memory footprint. To resolve these
issues, we propose an innovative framework that synergizes permutation-based
compressors with Classical Cryptography, even though employing Classical
Cryptography was assumed to be impossible in the past in the context of FL. Our
framework offers a way to replace HE with cheaper Classical Cryptography
primitives which provides security for the training process. It fosters
asynchronous communication and provides flexible deployment options in various
communication topologies.

---------------

### 05 Jul 2018 | [Few-shot learning of neural networks from scratch by pseudo example  optimization](https://arxiv.org/abs/1802.03039) | [⬇️](https://arxiv.org/pdf/1802.03039)
*Akisato Kimura, Zoubin Ghahramani, Koh Takeuchi, Tomoharu Iwata,  Naonori Ueda* 

  In this paper, we propose a simple but effective method for training neural
networks with a limited amount of training data. Our approach inherits the idea
of knowledge distillation that transfers knowledge from a deep or wide
reference model to a shallow or narrow target model. The proposed method
employs this idea to mimic predictions of reference estimators that are more
robust against overfitting than the network we want to train. Different from
almost all the previous work for knowledge distillation that requires a large
amount of labeled training data, the proposed method requires only a small
amount of training data. Instead, we introduce pseudo training examples that
are optimized as a part of model parameters. Experimental results for several
benchmark datasets demonstrate that the proposed method outperformed all the
other baselines, such as naive training of the target model and standard
knowledge distillation.

---------------

### 24 Nov 2019 | [DeepMimic: Mentor-Student Unlabeled Data Based Training](https://arxiv.org/abs/1912.00079) | [⬇️](https://arxiv.org/pdf/1912.00079)
*Itay Mosafi, Eli David, Nathan S. Netanyahu* 

  In this paper, we present a deep neural network (DNN) training approach
called the "DeepMimic" training method. Enormous amounts of data are available
nowadays for training usage. Yet, only a tiny portion of these data is manually
labeled, whereas almost all of the data are unlabeled. The training approach
presented utilizes, in a most simplified manner, the unlabeled data to the
fullest, in order to achieve remarkable (classification) results. Our DeepMimic
method uses a small portion of labeled data and a large amount of unlabeled
data for the training process, as expected in a real-world scenario. It
consists of a mentor model and a student model. Employing a mentor model
trained on a small portion of the labeled data and then feeding it only with
unlabeled data, we show how to obtain a (simplified) student model that reaches
the same accuracy and loss as the mentor model, on the same test set, without
using any of the original data labels in the training of the student model. Our
experiments demonstrate that even on challenging classification tasks the
student network architecture can be simplified significantly with a minor
influence on the performance, i.e., we need not even know the original network
architecture of the mentor. In addition, the time required for training the
student model to reach the mentor's performance level is shorter, as a result
of a simplified architecture and more available data. The proposed method
highlights the disadvantages of regular supervised training and demonstrates
the benefits of a less traditional training approach.

---------------

### 02 Nov 2023 | [Doubly Robust Self-Training](https://arxiv.org/abs/2306.00265) | [⬇️](https://arxiv.org/pdf/2306.00265)
*Banghua Zhu, Mingyu Ding, Philip Jacobson, Ming Wu, Wei Zhan, Michael  Jordan, Jiantao Jiao* 

  Self-training is an important technique for solving semi-supervised learning
problems. It leverages unlabeled data by generating pseudo-labels and combining
them with a limited labeled dataset for training. The effectiveness of
self-training heavily relies on the accuracy of these pseudo-labels. In this
paper, we introduce doubly robust self-training, a novel semi-supervised
algorithm that provably balances between two extremes. When the pseudo-labels
are entirely incorrect, our method reduces to a training process solely using
labeled data. Conversely, when the pseudo-labels are completely accurate, our
method transforms into a training process utilizing all pseudo-labeled data and
labeled data, thus increasing the effective sample size. Through empirical
evaluations on both the ImageNet dataset for image classification and the
nuScenes autonomous driving dataset for 3D object detection, we demonstrate the
superiority of the doubly robust loss over the standard self-training baseline.

---------------

### 04 Dec 2012 | [Separate Training for Conditional Random Fields Using Co-occurrence Rate  Factorization](https://arxiv.org/abs/1008.1566) | [⬇️](https://arxiv.org/pdf/1008.1566)
*Zhemin Zhu, Djoerd Hiemstra, Peter Apers, Andreas Wombacher* 

  The standard training method of Conditional Random Fields (CRFs) is very slow
for large-scale applications. As an alternative, piecewise training divides the
full graph into pieces, trains them independently, and combines the learned
weights at test time. In this paper, we present \emph{separate} training for
undirected models based on the novel Co-occurrence Rate Factorization (CR-F).
Separate training is a local training method. In contrast to MEMMs, separate
training is unaffected by the label bias problem. Experiments show that
separate training (i) is unaffected by the label bias problem; (ii) reduces the
training time from weeks to seconds; and (iii) obtains competitive results to
the standard and piecewise training on linear-chain CRFs.

---------------

### 26 Dec 2023 | [Error-free Training for Artificial Neural Network](https://arxiv.org/abs/2312.16060) | [⬇️](https://arxiv.org/pdf/2312.16060)
*Bo Deng* 

  Conventional training methods for artificial neural network (ANN) models
never achieve zero error rate systematically for large data. A new training
method consists of three steps: first create an auxiliary data from
conventionally trained parameters which correspond exactly to a global minimum
for the loss function of the cloned data; second create a one-parameter
homotopy (hybrid) of the auxiliary data and the original data; and third train
the model for the hybrid data iteratively from the auxiliary data end of the
homotopy parameter to the original data end while maintaining the zero-error
training rate at every iteration. This continuationmethod is guaranteed to
converge numerically by a theorem which converts the ANN training problem into
a continuation problem for fixed points of a parameterized transformation in
the training parameter space to which the Uniform Contraction Mapping Theorem
from dynamical systems applies.

---------------

### 17 Apr 2018 | [Reinforced Co-Training](https://arxiv.org/abs/1804.06035) | [⬇️](https://arxiv.org/pdf/1804.06035)
*Jiawei Wu, Lei Li, William Yang Wang* 

  Co-training is a popular semi-supervised learning framework to utilize a
large amount of unlabeled data in addition to a small labeled set. Co-training
methods exploit predicted labels on the unlabeled data and select samples based
on prediction confidence to augment the training. However, the selection of
samples in existing co-training methods is based on a predetermined policy,
which ignores the sampling bias between the unlabeled and the labeled subsets,
and fails to explore the data space. In this paper, we propose a novel method,
Reinforced Co-Training, to select high-quality unlabeled samples to better
co-train on. More specifically, our approach uses Q-learning to learn a data
selection policy with a small labeled dataset, and then exploits this policy to
train the co-training classifiers automatically. Experimental results on
clickbait detection and generic text classification tasks demonstrate that our
proposed method can obtain more accurate text classification results.

---------------

### 08 Feb 2021 | [Rapid Classification of Glaucomatous Fundus Images](https://arxiv.org/abs/2102.04400) | [⬇️](https://arxiv.org/pdf/2102.04400)
*Hardit Singh, Simarjeet Saini, Vasudevan Lakshminarayanan* 

  We propose a new method for training convolutional neural networks which
integrates reinforcement learning along with supervised learning and use ti for
transfer learning for classification of glaucoma from colored fundus images.
The training method uses hill climbing techniques via two different climber
types, viz "random movment" and "random detection" integrated with supervised
learning model though stochastic gradient descent with momentum (SGDM) model.
The model was trained and tested using the Drishti GS and RIM-ONE-r2 datasets
having glaucomatous and normal fundus images. The performance metrics for
prediction was tested by transfer learning on five CNN architectures, namely
GoogLenet, DesnseNet-201, NASNet, VGG-19 and Inception-resnet-v2. A fivefold
classification was used for evaluating the perfroamnace and high sensitivities
while high maintaining high accuracies were achieved. Of the models tested, the
denseNet-201 architecture performed the best in terms of sensitivity and area
under the curve (AUC). This method of training allows transfer learning on
small datasets and can be applied for tele-ophthalmology applications including
training with local datasets.

---------------

### 16 Apr 2018 | [Learning How to Self-Learn: Enhancing Self-Training Using Neural  Reinforcement Learning](https://arxiv.org/abs/1804.05734) | [⬇️](https://arxiv.org/pdf/1804.05734)
*Chenhua Chen, Yue Zhang* 

  Self-training is a useful strategy for semi-supervised learning, leveraging
raw texts for enhancing model performances. Traditional self-training methods
depend on heuristics such as model confidence for instance selection, the
manual adjustment of which can be expensive. To address these challenges, we
propose a deep reinforcement learning method to learn the self-training
strategy automatically. Based on neural network representation of sentences,
our model automatically learns an optimal policy for instance selection.
Experimental results show that our approach outperforms the baseline solutions
in terms of better tagging performances and stability.

---------------

### 19 Jan 2024 | [Early alignment in two-layer networks training is a two-edged sword](https://arxiv.org/abs/2401.10791) | [⬇️](https://arxiv.org/pdf/2401.10791)
*Etienne Boursier, Nicolas Flammarion* 

  Training neural networks with first order optimisation methods is at the core
of the empirical success of deep learning. The scale of initialisation is a
crucial factor, as small initialisations are generally associated to a feature
learning regime, for which gradient descent is implicitly biased towards simple
solutions. This work provides a general and quantitative description of the
early alignment phase, originally introduced by Maennel et al. (2018) . For
small initialisation and one hidden ReLU layer networks, the early stage of the
training dynamics leads to an alignment of the neurons towards key directions.
This alignment induces a sparse representation of the network, which is
directly related to the implicit bias of gradient flow at convergence. This
sparsity inducing alignment however comes at the expense of difficulties in
minimising the training objective: we also provide a simple data example for
which overparameterised networks fail to converge towards global minima and
only converge to a spurious stationary point instead.

---------------

### 08 Dec 2022 | [Self-training via Metric Learning for Source-Free Domain Adaptation of  Semantic Segmentation](https://arxiv.org/abs/2212.04227) | [⬇️](https://arxiv.org/pdf/2212.04227)
*Ibrahim Batuhan Akkaya and Ugur Halici* 

  Unsupervised source-free domain adaptation methods aim to train a model to be
used in the target domain utilizing the pretrained source-domain model and
unlabeled target-domain data, where the source data may not be accessible due
to intellectual property or privacy issues. These methods frequently utilize
self-training with pseudo-labeling thresholded by prediction confidence. In a
source-free scenario, only supervision comes from target data, and thresholding
limits the contribution of the self-training. In this study, we utilize
self-training with a mean-teacher approach. The student network is trained with
all predictions of the teacher network. Instead of thresholding the
predictions, the gradients calculated from the pseudo-labels are weighted based
on the reliability of the teacher's predictions. We propose a novel method that
uses proxy-based metric learning to estimate reliability. We train a metric
network on the encoder features of the teacher network. Since the teacher is
updated with the moving average, the encoder feature space is slowly changing.
Therefore, the metric network can be updated in training time, which enables
end-to-end training. We also propose a metric-based online ClassMix method to
augment the input of the student network where the patches to be mixed are
decided based on the metric reliability. We evaluated our method in
synthetic-to-real and cross-city scenarios. The benchmarks show that our method
significantly outperforms the existing state-of-the-art methods.

---------------

### 21 Apr 2020 | [A Mathematical Programming approach to Binary Supervised Classification  with Label Noise](https://arxiv.org/abs/2004.10170) | [⬇️](https://arxiv.org/pdf/2004.10170)
*V\'ictor Blanco, Alberto Jap\'on and Justo Puerto* 

  In this paper we propose novel methodologies to construct Support Vector
Machine -based classifiers that takes into account that label noises occur in
the training sample. We propose different alternatives based on solving Mixed
Integer Linear and Non Linear models by incorporating decisions on relabeling
some of the observations in the training dataset. The first method incorporates
relabeling directly in the SVM model while a second family of methods combines
clustering with classification at the same time, giving rise to a model that
applies simultaneously similarity measures and SVM. Extensive computational
experiments are reported based on a battery of standard datasets taken from UCI
Machine Learning repository, showing the effectiveness of the proposed
approaches.

---------------

### 02 Jun 2018 | [Maximum Principle Based Algorithms for Deep Learning](https://arxiv.org/abs/1710.09513) | [⬇️](https://arxiv.org/pdf/1710.09513)
*Qianxiao Li, Long Chen, Cheng Tai, Weinan E* 

  The continuous dynamical system approach to deep learning is explored in
order to devise alternative frameworks for training algorithms. Training is
recast as a control problem and this allows us to formulate necessary
optimality conditions in continuous time using the Pontryagin's maximum
principle (PMP). A modification of the method of successive approximations is
then used to solve the PMP, giving rise to an alternative training algorithm
for deep learning. This approach has the advantage that rigorous error
estimates and convergence results can be established. We also show that it may
avoid some pitfalls of gradient-based methods, such as slow convergence on flat
landscapes near saddle points. Furthermore, we demonstrate that it obtains
favorable initial convergence rate per-iteration, provided Hamiltonian
maximization can be efficiently carried out - a step which is still in need of
improvement. Overall, the approach opens up new avenues to attack problems
associated with deep learning, such as trapping in slow manifolds and
inapplicability of gradient-based methods for discrete trainable variables.

---------------
**Date:** 25 Jul 2022

**Title:** Dive into Big Model Training

**Abstract Link:** [https://arxiv.org/abs/2207.11912](https://arxiv.org/abs/2207.11912)

**PDF Link:** [https://arxiv.org/pdf/2207.11912](https://arxiv.org/pdf/2207.11912)

---

**Date:** 11 Nov 2017

**Title:** CT-SRCNN: Cascade Trained and Trimmed Deep Convolutional Neural Networks  for Image Super Resolution

**Abstract Link:** [https://arxiv.org/abs/1711.04048](https://arxiv.org/abs/1711.04048)

**PDF Link:** [https://arxiv.org/pdf/1711.04048](https://arxiv.org/pdf/1711.04048)

---

**Date:** 28 May 2021

**Title:** WeaQA: Weak Supervision via Captions for Visual Question Answering

**Abstract Link:** [https://arxiv.org/abs/2012.02356](https://arxiv.org/abs/2012.02356)

**PDF Link:** [https://arxiv.org/pdf/2012.02356](https://arxiv.org/pdf/2012.02356)

---

**Date:** 21 Mar 2023

**Title:** Boosting Verified Training for Robust Image Classifications via  Abstraction

**Abstract Link:** [https://arxiv.org/abs/2303.11552](https://arxiv.org/abs/2303.11552)

**PDF Link:** [https://arxiv.org/pdf/2303.11552](https://arxiv.org/pdf/2303.11552)

---

**Date:** 03 Feb 2024

**Title:** Rethinking the Starting Point: Enhancing Performance and Fairness of  Federated Learning via Collaborative Pre-Training

**Abstract Link:** [https://arxiv.org/abs/2402.02225](https://arxiv.org/abs/2402.02225)

**PDF Link:** [https://arxiv.org/pdf/2402.02225](https://arxiv.org/pdf/2402.02225)

---

**Date:** 31 Jan 2023

**Title:** Friend-training: Learning from Models of Different but Related Tasks

**Abstract Link:** [https://arxiv.org/abs/2301.13683](https://arxiv.org/abs/2301.13683)

**PDF Link:** [https://arxiv.org/pdf/2301.13683](https://arxiv.org/pdf/2301.13683)

---

**Date:** 02 Sep 2023

**Title:** On the training and generalization of deep operator networks

**Abstract Link:** [https://arxiv.org/abs/2309.01020](https://arxiv.org/abs/2309.01020)

**PDF Link:** [https://arxiv.org/pdf/2309.01020](https://arxiv.org/pdf/2309.01020)

---

**Date:** 04 Dec 2023

**Title:** Federated Learning is Better with Non-Homomorphic Encryption

**Abstract Link:** [https://arxiv.org/abs/2312.02074](https://arxiv.org/abs/2312.02074)

**PDF Link:** [https://arxiv.org/pdf/2312.02074](https://arxiv.org/pdf/2312.02074)

---

**Date:** 05 Jul 2018

**Title:** Few-shot learning of neural networks from scratch by pseudo example  optimization

**Abstract Link:** [https://arxiv.org/abs/1802.03039](https://arxiv.org/abs/1802.03039)

**PDF Link:** [https://arxiv.org/pdf/1802.03039](https://arxiv.org/pdf/1802.03039)

---

**Date:** 24 Nov 2019

**Title:** DeepMimic: Mentor-Student Unlabeled Data Based Training

**Abstract Link:** [https://arxiv.org/abs/1912.00079](https://arxiv.org/abs/1912.00079)

**PDF Link:** [https://arxiv.org/pdf/1912.00079](https://arxiv.org/pdf/1912.00079)

---

**Date:** 02 Nov 2023

**Title:** Doubly Robust Self-Training

**Abstract Link:** [https://arxiv.org/abs/2306.00265](https://arxiv.org/abs/2306.00265)

**PDF Link:** [https://arxiv.org/pdf/2306.00265](https://arxiv.org/pdf/2306.00265)

---

**Date:** 04 Dec 2012

**Title:** Separate Training for Conditional Random Fields Using Co-occurrence Rate  Factorization

**Abstract Link:** [https://arxiv.org/abs/1008.1566](https://arxiv.org/abs/1008.1566)

**PDF Link:** [https://arxiv.org/pdf/1008.1566](https://arxiv.org/pdf/1008.1566)

---

**Date:** 26 Dec 2023

**Title:** Error-free Training for Artificial Neural Network

**Abstract Link:** [https://arxiv.org/abs/2312.16060](https://arxiv.org/abs/2312.16060)

**PDF Link:** [https://arxiv.org/pdf/2312.16060](https://arxiv.org/pdf/2312.16060)

---

**Date:** 17 Apr 2018

**Title:** Reinforced Co-Training

**Abstract Link:** [https://arxiv.org/abs/1804.06035](https://arxiv.org/abs/1804.06035)

**PDF Link:** [https://arxiv.org/pdf/1804.06035](https://arxiv.org/pdf/1804.06035)

---

**Date:** 08 Feb 2021

**Title:** Rapid Classification of Glaucomatous Fundus Images

**Abstract Link:** [https://arxiv.org/abs/2102.04400](https://arxiv.org/abs/2102.04400)

**PDF Link:** [https://arxiv.org/pdf/2102.04400](https://arxiv.org/pdf/2102.04400)

---

**Date:** 16 Apr 2018

**Title:** Learning How to Self-Learn: Enhancing Self-Training Using Neural  Reinforcement Learning

**Abstract Link:** [https://arxiv.org/abs/1804.05734](https://arxiv.org/abs/1804.05734)

**PDF Link:** [https://arxiv.org/pdf/1804.05734](https://arxiv.org/pdf/1804.05734)

---

**Date:** 19 Jan 2024

**Title:** Early alignment in two-layer networks training is a two-edged sword

**Abstract Link:** [https://arxiv.org/abs/2401.10791](https://arxiv.org/abs/2401.10791)

**PDF Link:** [https://arxiv.org/pdf/2401.10791](https://arxiv.org/pdf/2401.10791)

---

**Date:** 08 Dec 2022

**Title:** Self-training via Metric Learning for Source-Free Domain Adaptation of  Semantic Segmentation

**Abstract Link:** [https://arxiv.org/abs/2212.04227](https://arxiv.org/abs/2212.04227)

**PDF Link:** [https://arxiv.org/pdf/2212.04227](https://arxiv.org/pdf/2212.04227)

---

**Date:** 21 Apr 2020

**Title:** A Mathematical Programming approach to Binary Supervised Classification  with Label Noise

**Abstract Link:** [https://arxiv.org/abs/2004.10170](https://arxiv.org/abs/2004.10170)

**PDF Link:** [https://arxiv.org/pdf/2004.10170](https://arxiv.org/pdf/2004.10170)

---

**Date:** 02 Jun 2018

**Title:** Maximum Principle Based Algorithms for Deep Learning

**Abstract Link:** [https://arxiv.org/abs/1710.09513](https://arxiv.org/abs/1710.09513)

**PDF Link:** [https://arxiv.org/pdf/1710.09513](https://arxiv.org/pdf/1710.09513)

---

