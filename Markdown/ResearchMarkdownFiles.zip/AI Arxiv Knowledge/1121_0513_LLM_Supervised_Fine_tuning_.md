LLM Supervised Fine-tuning 👨‍🏫

### 🔎 LLM Supervised Fine-tuning 👨‍🏫


=================================

This is a simple example of fine-tuning a pre-trained LLM model on a custom dataset.

The dataset used in this example is the [SQuAD](https://rajpurkar.github.io/SQuAD-explorer/) dataset, which is a popular dataset for question answering tasks.

The pre-trained LLM model used in this example is the [BART-large](https://huggingface.co/facebook/bart-large) model, which is a pre-trained sequence-to-sequence model.

The fine-tuning process is supervised, which means that the model is trained to predict the correct answer to a question given a context.

The fine-tuning process is done using the [Transformers](https://github.com/huggingface/transformers) library.

Setup
-----

To run this example, you need to install the following dependencies:

- Python 3.6 or higher
- Transformers library
- Torch library

You can install the dependencies using the following command:

```bash
pip install transformers torch
```

Data Preparation
----------------

The SQuAD dataset is already pre-processed and split into training, validation, and test sets.

The training set is used to fine-tune the model, the validation set is used to evaluate the model during training, and the test set is used to evaluate the model after training.

The SQuAD dataset is provided in JSON format, and each example in the dataset consists of a context, a question, and an answer.

The context is a paragraph of text, the question is a question related to the context, and the answer is the correct answer to the question.

The SQuAD dataset is loaded using the `load_dataset` function from the `transformers` library.

The `load_dataset` function returns a `DatasetDict` object, which contains the training, validation, and test sets.

The `DatasetDict` object is converted to a `DataLoader` object using the `DataLoader` function from the `torch` library.

The `DataLoader` object is used to feed the data to the model during training.

Model Preparation
-----------------

The pre-trained LLM model
# 🩺🔍 Search Results
### 05 Mar 2024 | [LoRAMoE: Alleviate World Knowledge Forgetting in Large Language Models  via MoE-Style Plugin](https://arxiv.org/abs/2312.09979) | [⬇️](https://arxiv.org/pdf/2312.09979)
*Shihan Dou, Enyu Zhou, Yan Liu, Songyang Gao, Jun Zhao, Wei Shen,  Yuhao Zhou, Zhiheng Xi, Xiao Wang, Xiaoran Fan, Shiliang Pu, Jiang Zhu, Rui  Zheng, Tao Gui, Qi Zhang, Xuanjing Huang* 

  Supervised fine-tuning (SFT) is a crucial step for large language models
(LLMs), enabling them to align with human instructions and enhance their
capabilities in downstream tasks. Increasing instruction data substantially is
a direct solution to align the model with a broader range of downstream tasks
or notably improve its performance on a specific task. However, we find that
large-scale increases in instruction data can damage the world knowledge
previously stored in LLMs. To address this challenge, we propose LoRAMoE, a
novelty framework that introduces several low-rank adapters (LoRA) and
integrates them by using a router network, like a plugin version of Mixture of
Experts (MoE). It freezes the backbone model and forces a portion of LoRAs to
focus on leveraging world knowledge to solve downstream tasks, to alleviate
world knowledge-edge forgetting. Experimental results show that, as the
instruction data increases, LoRAMoE can significantly improve the ability to
process downstream tasks, while maintaining the world knowledge stored in the
LLM.

---------------

### 16 Oct 2023 | [LoBaSS: Gauging Learnability in Supervised Fine-tuning Data](https://arxiv.org/abs/2310.13008) | [⬇️](https://arxiv.org/pdf/2310.13008)
*Haotian Zhou, Tingkai Liu, Qianli Ma, Jianbo Yuan, Pengfei Liu, Yang  You and Hongxia Yang* 

  Supervised Fine-Tuning (SFT) serves as a crucial phase in aligning Large
Language Models (LLMs) to specific task prerequisites. The selection of
fine-tuning data profoundly influences the model's performance, whose principle
is traditionally grounded in data quality and distribution. In this paper, we
introduce a new dimension in SFT data selection: learnability. This new
dimension is motivated by the intuition that SFT unlocks capabilities acquired
by a LLM during the pretraining phase. Given that different pretrained models
have disparate capabilities, the SFT data appropriate for one may not suit
another. Thus, we introduce the term learnability to define the suitability of
data for effective learning by the model. We present the Loss Based SFT Data
Selection (LoBaSS) method, utilizing data learnability as the principal
criterion for the selection SFT data. This method provides a nuanced approach,
allowing the alignment of data selection with inherent model capabilities,
ensuring optimal compatibility and learning efficiency. In experimental
comparisons involving 7B and 13B models, our LoBaSS method is able to surpass
full-data fine-tuning at merely 6% of the total training data. When employing
16.7% of the data, LoBaSS harmonizes the model's capabilities across
conversational and mathematical domains, proving its efficacy and adaptability.

---------------

### 31 Dec 2023 | [LaFFi: Leveraging Hybrid Natural Language Feedback for Fine-tuning  Language Models](https://arxiv.org/abs/2401.00907) | [⬇️](https://arxiv.org/pdf/2401.00907)
*Qianxi Li, Yingyue Cao, Jikun Kang, Tianpei Yang, Xi Chen, Jun Jin and  Matthew E. Taylor* 

  Fine-tuning Large Language Models (LLMs) adapts a trained model to specific
downstream tasks, significantly improving task-specific performance. Supervised
Fine-Tuning (SFT) is a common approach, where an LLM is trained to produce
desired answers. However, LLMs trained with SFT sometimes make simple mistakes
and result in hallucinations on reasoning tasks such as question-answering.
Without external feedback, it is difficult for SFT to learn a good mapping
between the question and the desired answer, especially with a small dataset.
This paper introduces an alternative to SFT called Natural Language Feedback
for Finetuning LLMs (LaFFi). LaFFi has LLMs directly predict the feedback they
will receive from an annotator. We find that requiring such reflection can
significantly improve the accuracy in in-domain question-answering tasks,
providing a promising direction for the application of natural language
feedback in the realm of SFT LLMs. Additional ablation studies show that the
portion of human-annotated data in the annotated datasets affects the
fine-tuning performance.

---------------

### 09 Oct 2023 | [SALMON: Self-Alignment with Principle-Following Reward Models](https://arxiv.org/abs/2310.05910) | [⬇️](https://arxiv.org/pdf/2310.05910)
*Zhiqing Sun, Yikang Shen, Hongxin Zhang, Qinhong Zhou, Zhenfang Chen,  David Cox, Yiming Yang, Chuang Gan* 

  Supervised Fine-Tuning (SFT) on response demonstrations combined with
Reinforcement Learning from Human Feedback (RLHF) constitutes a powerful
paradigm for aligning LLM-based AI agents. However, a significant limitation of
such an approach is its dependency on high-quality human annotations, making
its application to intricate tasks challenging due to difficulties in obtaining
consistent response demonstrations and in-distribution response preferences.
This paper presents a novel approach, namely SALMON (Self-ALignMent with
principle-fOllowiNg reward models), to align base language models with minimal
human supervision, using only a small set of human-defined principles, yet
achieving superior performance. Central to our approach is a
principle-following reward model. Trained on synthetic preference data, this
model can generate reward scores based on arbitrary human-defined principles.
By merely adjusting these principles during the RL training phase, we gain full
control over the preferences with the reward model, subsequently influencing
the behavior of the RL-trained policies, and eliminating the reliance on the
collection of online human preferences. Applying our method to the LLaMA-2-70b
base language model, we developed an AI assistant named Dromedary-2. With only
6 exemplars for in-context learning and 31 human-defined principles,
Dromedary-2 significantly surpasses the performance of several state-of-the-art
AI systems, including LLaMA-2-Chat-70b, on various benchmark datasets. We have
open-sourced the code and model weights to encourage further research into
aligning LLM-based AI agents with enhanced supervision efficiency, improved
controllability, and scalable oversight.

---------------

### 04 Mar 2024 | [Analyzing and Adapting Large Language Models for Few-Shot Multilingual  NLU: Are We There Yet?](https://arxiv.org/abs/2403.01929) | [⬇️](https://arxiv.org/pdf/2403.01929)
*Evgeniia Razumovskaia, Ivan Vuli\'c, Anna Korhonen* 

  Supervised fine-tuning (SFT), supervised instruction tuning (SIT) and
in-context learning (ICL) are three alternative, de facto standard approaches
to few-shot learning. ICL has gained popularity recently with the advent of
LLMs due to its simplicity and sample efficiency. Prior research has conducted
only limited investigation into how these approaches work for multilingual
few-shot learning, and the focus so far has been mostly on their performance.
In this work, we present an extensive and systematic comparison of the three
approaches, testing them on 6 high- and low-resource languages, three different
NLU tasks, and a myriad of language and domain setups. Importantly, performance
is only one aspect of the comparison, where we also analyse the approaches
through the optics of their computational, inference and financial costs. Our
observations show that supervised instruction tuning has the best trade-off
between performance and resource requirements. As another contribution, we
analyse the impact of target language adaptation of pretrained LLMs and find
that the standard adaptation approaches can (superficially) improve target
language generation capabilities, but language understanding elicited through
ICL does not improve and remains limited, with low scores especially for
low-resource languages.

---------------

### 25 Feb 2024 | [PeriodicLoRA: Breaking the Low-Rank Bottleneck in LoRA Optimization](https://arxiv.org/abs/2402.16141) | [⬇️](https://arxiv.org/pdf/2402.16141)
*Xiangdi Meng, Damai Dai, Weiyao Luo, Zhe Yang, Shaoxiang Wu, Xiaochen  Wang, Peiyi Wang, Qingxiu Dong, Liang Chen, Zhifang Sui* 

  Supervised fine-tuning is the most common method to adapt large language
models (LLMs) to downstream tasks, but full fine-tuning LLMs requires massive
computational resources. Recently, parameter-efficient fine-tuning (PEFT)
methods have been widely studied due to its cost-effectiveness. LoRA is one of
the most widely used methods, which assumes that the optimization process is
essentially low-dimensional. Although LoRA fine-tuning is effective, there is
still a performance gap compared to full fine-tuning, since its weight update
is limited to low-rank matrices. In order to break the low-rank bottleneck in
LoRA Optimization, we propose PeriodicLoRA (PLoRA), which accumulates low-rank
update matrices multiple times to achieve a higher update rank. PLoRA has
multiple training stages. During each stage, we still update only the LoRA
weights. However, at the end of each stage, we unload the LoRA weights into the
backbone parameters and then reinitialize the LoRA states. Experimental results
show that PLoRA has stronger learning ability, approximately 1.8 times that of
LoRA's learning ability at most, but it does not increase memory usage.
Further, we introduce a momentum-based unloading strategy for PLoRA to mitigate
the training instability.

---------------

### 12 Feb 2024 | [Self-Play Fine-Tuning Converts Weak Language Models to Strong Language  Models](https://arxiv.org/abs/2401.01335) | [⬇️](https://arxiv.org/pdf/2401.01335)
*Zixiang Chen and Yihe Deng and Huizhuo Yuan and Kaixuan Ji and  Quanquan Gu* 

  Harnessing the power of human-annotated data through Supervised Fine-Tuning
(SFT) is pivotal for advancing Large Language Models (LLMs). In this paper, we
delve into the prospect of growing a strong LLM out of a weak one without the
need for acquiring additional human-annotated data. We propose a new
fine-tuning method called Self-Play fIne-tuNing (SPIN), which starts from a
supervised fine-tuned model. At the heart of SPIN lies a self-play mechanism,
where the LLM refines its capability by playing against instances of itself.
More specifically, the LLM generates its own training data from its previous
iterations, refining its policy by discerning these self-generated responses
from those obtained from human-annotated data. Our method progressively
elevates the LLM from a nascent model to a formidable one, unlocking the full
potential of human-annotated demonstration data for SFT. Theoretically, we
prove that the global optimum to the training objective function of our method
is achieved only when the LLM policy aligns with the target data distribution.
Empirically, we evaluate our method on several benchmark datasets including the
HuggingFace Open LLM Leaderboard, MT-Bench, and datasets from Big-Bench. Our
results show that SPIN can significantly improve the LLM's performance across a
variety of benchmarks and even outperform models trained through direct
preference optimization (DPO) supplemented with extra GPT-4 preference data.
This sheds light on the promise of self-play, enabling the achievement of
human-level performance in LLMs without the need for expert opponents. Codes
are available at https://github.com/uclaml/SPIN.

---------------

### 07 Nov 2023 | [Reinforcement Learning Fine-tuning of Language Models is Biased Towards  More Extractable Features](https://arxiv.org/abs/2311.04046) | [⬇️](https://arxiv.org/pdf/2311.04046)
*Diogo Cruz, Edoardo Pona, Alex Holness-Tofts, Elias Schmied, V\'ictor  Abia Alonso, Charlie Griffin, Bogdan-Ionut Cirstea* 

  Many capable large language models (LLMs) are developed via self-supervised
pre-training followed by a reinforcement-learning fine-tuning phase, often
based on human or AI feedback. During this stage, models may be guided by their
inductive biases to rely on simpler features which may be easier to extract, at
a cost to robustness and generalisation. We investigate whether principles
governing inductive biases in the supervised fine-tuning of LLMs also apply
when the fine-tuning process uses reinforcement learning. Following Lovering et
al (2021), we test two hypotheses: that features more $\textit{extractable}$
after pre-training are more likely to be utilised by the final policy, and that
the evidence for/against a feature predicts whether it will be utilised.
Through controlled experiments on synthetic and natural language tasks, we find
statistically significant correlations which constitute strong evidence for
these hypotheses.

---------------

### 19 Dec 2023 | [Taiyi: A Bilingual Fine-Tuned Large Language Model for Diverse  Biomedical Tasks](https://arxiv.org/abs/2311.11608) | [⬇️](https://arxiv.org/pdf/2311.11608)
*Ling Luo, Jinzhong Ning, Yingwen Zhao, Zhijun Wang, Zeyuan Ding, Peng  Chen, Weiru Fu, Qinyu Han, Guangtao Xu, Yunzhi Qiu, Dinghao Pan, Jiru Li, Hao  Li, Wenduo Feng, Senbo Tu, Yuqi Liu, Zhihao Yang, Jian Wang, Yuanyuan Sun,  Hongfei Lin* 

  Objective: Most existing fine-tuned biomedical large language models (LLMs)
focus on enhancing performance in monolingual biomedical question answering and
conversation tasks. To investigate the effectiveness of the fine-tuned LLMs on
diverse biomedical NLP tasks in different languages, We present Taiyi, a
bilingual fine-tuned LLM for diverse biomedical tasks. Materials and Methods:
We first curated a comprehensive collection of 140 existing biomedical text
mining datasets (102 English and 38 Chinese datasets) across over 10 task
types. Subsequently, a two-stage strategy is proposed for supervised
fine-tuning to optimize the model performance across varied tasks. Results:
Experimental results on 13 test sets covering named entity recognition,
relation extraction, text classification, question answering tasks demonstrate
that Taiyi achieves superior performance compared to general LLMs. The case
study involving additional biomedical NLP tasks further shows Taiyi's
considerable potential for bilingual biomedical multi-tasking. Conclusion:
Leveraging rich high-quality biomedical corpora and developing effective
fine-tuning strategies can significantly improve the performance of LLMs within
the biomedical domain. Taiyi shows the bilingual multi-tasking capability
through supervised fine-tuning. However, those tasks such as information
extraction that are not generation tasks in nature remain challenging for
LLM-based generative approaches, and they still underperform the conventional
discriminative approaches of smaller language models.

---------------

### 07 Jun 2023 | [Explicit Knowledge Transfer for Weakly-Supervised Code Generation](https://arxiv.org/abs/2211.16740) | [⬇️](https://arxiv.org/pdf/2211.16740)
*Zhangir Azerbayev, Ansong Ni, Hailey Schoelkopf, Dragomir Radev* 

  Large language models (LLMs) can acquire strong code-generation capabilities
through few-shot learning. In contrast, supervised fine-tuning is still needed
for smaller models to achieve good performance. Such fine-tuning demands a
large number of task-specific NL-code pairs, which are expensive to obtain. In
this paper, we attempt to transfer the code generation ability of an LLM to a
smaller model with the aid of weakly-supervised data. More specifically, we
propose explicit knowledge transfer (EKT), which uses the few-shot capabilities
of a teacher LLM to create NL-code pairs that we then filter for correctness
and fine-tune the student on. We evaluate EKT on the task of generating code
solutions to math word problems from the GSM8k dataset. We find that EKT not
only yields better performance than training with expert iteration, but also
outperforms knowledge distillation, another form of knowledge transfer. A
GPT-Neo 1.3B model trained using EKT with a GPT-J teacher achieves a 12.4%
pass@100 on GSM8k, while the same student and teacher trained with knowledge
distillation yield only a 3.7% pass@100. We also show that it is possible for a
student model to outperform the teacher using EKT.

---------------

### 23 Feb 2024 | [An Empirical Study of Data Ability Boundary in LLMs' Math Reasoning](https://arxiv.org/abs/2403.00799) | [⬇️](https://arxiv.org/pdf/2403.00799)
*Zui Chen, Yezeng Chen, Jiaqi Han, Zhijie Huang, Ji Qi, Yi Zhou* 

  Large language models (LLMs) are displaying emergent abilities for math
reasoning tasks,and there is a growing attention on enhancing the ability of
open-source LLMs through supervised fine-tuning (SFT).In this paper, we aim to
explore a general data strategy for supervised data to help optimize and expand
math reasoning ability.Firstly, we determine the ability boundary of reasoning
paths augmentation by identifying these paths' minimal optimal set.Secondly, we
validate that different abilities of the model can be cumulatively enhanced by
Mix of Minimal Optimal Sets of corresponding types of data, while our models
MMOS achieve SOTA performance on series base models under much lower
construction costs.Besides, we point out GSM-HARD is not really hard and
today's LLMs no longer lack numerical robustness.Also, we provide an Auto
Problem Generator for robustness testing and educational applications.Our code
and data are publicly available at https://github.com/cyzhh/MMOS.

---------------

### 02 Oct 2023 | [Label Supervised LLaMA Finetuning](https://arxiv.org/abs/2310.01208) | [⬇️](https://arxiv.org/pdf/2310.01208)
*Zongxi Li, Xianming Li, Yuzhang Liu, Haoran Xie, Jing Li, Fu-lee Wang,  Qing Li, Xiaoqin Zhong* 

  The recent success of Large Language Models (LLMs) has gained significant
attention in both academia and industry. Substantial efforts have been made to
enhance the zero- and few-shot generalization capabilities of open-source LLMs
through finetuning. Currently, the prevailing approach is instruction-tuning,
which trains LLMs to complete real-world tasks by generating responses guided
by natural language instructions. It is worth noticing that such an approach
may underperform in sequence and token classification tasks. Unlike text
generation tasks, classification tasks have a limited label space, where
precise label prediction is more appreciated than generating diverse and
human-like responses. Prior research has unveiled that instruction-tuned LLMs
cannot outperform BERT, prompting us to explore the potential of leveraging
latent representations from LLMs for supervised label prediction. In this
paper, we introduce a label-supervised adaptation for LLMs, which aims to
finetuning the model with discriminant labels. We evaluate this approach with
Label Supervised LLaMA (LS-LLaMA), based on LLaMA-2-7B, a relatively
small-scale LLM, and can be finetuned on a single GeForce RTX4090 GPU. We
extract latent representations from the final LLaMA layer and project them into
the label space to compute the cross-entropy loss. The model is finetuned by
Low-Rank Adaptation (LoRA) to minimize this loss. Remarkably, without intricate
prompt engineering or external knowledge, LS-LLaMA substantially outperforms
LLMs ten times its size in scale and demonstrates consistent improvements
compared to robust baselines like BERT-Large and RoBERTa-Large in text
classification. Moreover, by removing the causal mask from decoders, LS-unLLaMA
achieves the state-of-the-art performance in named entity recognition (NER).
Our work will shed light on a novel approach to adapting LLMs for various
downstream tasks.

---------------

### 22 Dec 2023 | [On Task Performance and Model Calibration with Supervised and  Self-Ensembled In-Context Learning](https://arxiv.org/abs/2312.13772) | [⬇️](https://arxiv.org/pdf/2312.13772)
*Chengzu Li, Han Zhou, Goran Glava\v{s}, Anna Korhonen, Ivan Vuli\'c* 

  Following the standard supervised fine-tuning (SFT) paradigm, in-context
learning (ICL) has become an efficient approach propelled by the recent
advancements in large language models (LLMs), yielding promising performance
across various tasks in few-shot data setups. However, both paradigms are prone
to suffer from the critical problem of overconfidence (i.e., miscalibration),
especially in such limited data setups. In this work, we deliver an in-depth
analysis of the behavior across different choices of learning methods from the
perspective of both performance and calibration, as well as their interplay.
Through extensive controlled experiments, we find that simultaneous gains for
both task performance and calibration are difficult to achieve, and the problem
of miscalibration exists across all learning methods in low-resource scenarios.
To address this challenging trade-off between performance and calibration, we
then investigate the potential of self-ensembling techniques applied at
different modeling stages (e.g., variations of in-context examples or
variations in prompts or different ensembling strategies). We justify the
feasibility of self-ensembling on SFT in addition to ICL, to make the
predictions more calibrated and have comparable or even better performance. Our
work sheds light on which learning paradigm to choose and how to enhance both
task performance and calibration of LLMs.

---------------

### 02 Aug 2023 | [Okapi: Instruction-tuned Large Language Models in Multiple Languages  with Reinforcement Learning from Human Feedback](https://arxiv.org/abs/2307.16039) | [⬇️](https://arxiv.org/pdf/2307.16039)
*Viet Dac Lai, Chien Van Nguyen, Nghia Trung Ngo, Thuat Nguyen, Franck  Dernoncourt, Ryan A. Rossi, Thien Huu Nguyen* 

  A key technology for the development of large language models (LLMs) involves
instruction tuning that helps align the models' responses with human
expectations to realize impressive learning abilities. Two major approaches for
instruction tuning characterize supervised fine-tuning (SFT) and reinforcement
learning from human feedback (RLHF), which are currently applied to produce the
best commercial LLMs (e.g., ChatGPT). To improve the accessibility of LLMs for
research and development efforts, various instruction-tuned open-source LLMs
have also been introduced recently, e.g., Alpaca, Vicuna, to name a few.
However, existing open-source LLMs have only been instruction-tuned for English
and a few popular languages, thus hindering their impacts and accessibility to
many other languages in the world. Among a few very recent work to explore
instruction tuning for LLMs in multiple languages, SFT has been used as the
only approach to instruction-tune LLMs for multiple languages. This has left a
significant gap for fine-tuned LLMs based on RLHF in diverse languages and
raised important questions on how RLHF can boost the performance of
multilingual instruction tuning. To overcome this issue, we present Okapi, the
first system with instruction-tuned LLMs based on RLHF for multiple languages.
Okapi introduces instruction and response-ranked data in 26 diverse languages
to facilitate the experiments and development of future multilingual LLM
research. We also present benchmark datasets to enable the evaluation of
generative LLMs in multiple languages. Our experiments demonstrate the
advantages of RLHF for multilingual instruction over SFT for different base
models and datasets. Our framework and resources are released at
https://github.com/nlp-uoregon/Okapi.

---------------

### 22 Sep 2023 | [CFGPT: Chinese Financial Assistant with Large Language Model](https://arxiv.org/abs/2309.10654) | [⬇️](https://arxiv.org/pdf/2309.10654)
*Jiangtong Li, Yuxuan Bian, Guoxuan Wang, Yang Lei, Dawei Cheng, Zhijun  Ding and Changjun Jiang* 

  Large language models (LLMs) have demonstrated great potential in natural
language processing tasks within the financial domain. In this work, we present
a Chinese Financial Generative Pre-trained Transformer framework, named CFGPT,
which includes a dataset~(CFData) for pre-training and supervised fine-tuning,
a financial LLM~(CFLLM) to adeptly manage financial texts, and a deployment
framework~(CFAPP) designed to navigate real-world financial applications. The
CFData comprising both a pre-training dataset and a supervised fine-tuning
dataset, where the pre-training dataset collates Chinese financial data and
analytics, alongside a smaller subset of general-purpose text with 584M
documents and 141B tokens in total, and the supervised fine-tuning dataset is
tailored for six distinct financial tasks, embodying various facets of
financial analysis and decision-making with 1.5M instruction pairs and 1.5B
tokens in total. The CFLLM, which is based on InternLM-7B to balance the model
capability and size, is trained on CFData in two stage, continued pre-training
and supervised fine-tuning. The CFAPP is centered on large language models
(LLMs) and augmented with additional modules to ensure multifaceted
functionality in real-world application. Our codes are released at
https://github.com/TongjiFinLab/CFGPT.

---------------

### 09 Sep 2023 | [Analysis of Disinformation and Fake News Detection Using Fine-Tuned  Large Language Model](https://arxiv.org/abs/2309.04704) | [⬇️](https://arxiv.org/pdf/2309.04704)
*Bohdan M. Pavlyshenko* 

  The paper considers the possibility of fine-tuning Llama 2 large language
model (LLM) for the disinformation analysis and fake news detection. For
fine-tuning, the PEFT/LoRA based approach was used. In the study, the model was
fine-tuned for the following tasks: analysing a text on revealing
disinformation and propaganda narratives, fact checking, fake news detection,
manipulation analytics, extracting named entities with their sentiments. The
obtained results show that the fine-tuned Llama 2 model can perform a deep
analysis of texts and reveal complex styles and narratives. Extracted
sentiments for named entities can be considered as predictive features in
supervised machine learning models.

---------------

### 28 Nov 2023 | [Training Chain-of-Thought via Latent-Variable Inference](https://arxiv.org/abs/2312.02179) | [⬇️](https://arxiv.org/pdf/2312.02179)
*Du Phan, Matthew D. Hoffman, David Dohan, Sholto Douglas, Tuan Anh Le,  Aaron Parisi, Pavel Sountsov, Charles Sutton, Sharad Vikram, Rif A. Saurous* 

  Large language models (LLMs) solve problems more accurately and interpretably
when instructed to work out the answer step by step using a
``chain-of-thought'' (CoT) prompt. One can also improve LLMs' performance on a
specific task by supervised fine-tuning, i.e., by using gradient ascent on some
tunable parameters to maximize the average log-likelihood of correct answers
from a labeled training set. Naively combining CoT with supervised tuning
requires supervision not just of the correct answers, but also of detailed
rationales that lead to those answers; these rationales are expensive to
produce by hand. Instead, we propose a fine-tuning strategy that tries to
maximize the \emph{marginal} log-likelihood of generating a correct answer
using CoT prompting, approximately averaging over all possible rationales. The
core challenge is sampling from the posterior over rationales conditioned on
the correct answer; we address it using a simple Markov-chain Monte Carlo
(MCMC) expectation-maximization (EM) algorithm inspired by the self-taught
reasoner (STaR), memoized wake-sleep, Markovian score climbing, and persistent
contrastive divergence. This algorithm also admits a novel control-variate
technique that drives the variance of our gradient estimates to zero as the
model improves. Applying our technique to GSM8K and the tasks in BIG-Bench
Hard, we find that this MCMC-EM fine-tuning technique typically improves the
model's accuracy on held-out examples more than STaR or prompt-tuning with or
without CoT.

---------------

### 13 Sep 2023 | [Scaling Relationship on Learning Mathematical Reasoning with Large  Language Models](https://arxiv.org/abs/2308.01825) | [⬇️](https://arxiv.org/pdf/2308.01825)
*Zheng Yuan, Hongyi Yuan, Chengpeng Li, Guanting Dong, Keming Lu,  Chuanqi Tan, Chang Zhou, Jingren Zhou* 

  Mathematical reasoning is a challenging task for large language models
(LLMs), while the scaling relationship of it with respect to LLM capacity is
under-explored. In this paper, we investigate how the pre-training loss,
supervised data amount, and augmented data amount influence the reasoning
performances of a supervised LLM. We find that pre-training loss is a better
indicator of the model's performance than the model's parameter count. We apply
supervised fine-tuning (SFT) with different amounts of supervised data and
empirically find a log-linear relation between data amount and model
performance, and we find better models improve less with enlarged supervised
datasets. To augment more data samples for improving model performances without
any human effort, we propose to apply Rejection sampling Fine-Tuning (RFT). RFT
uses supervised models to generate and collect correct reasoning paths as
augmented fine-tuning datasets. We find with augmented samples containing more
distinct reasoning paths, RFT improves mathematical reasoning performance more
for LLMs. We also find RFT brings more improvement for less performant LLMs.
Furthermore, we combine rejection samples from multiple models which push
LLaMA-7B to an accuracy of 49.3\% on GSM8K which outperforms the supervised
fine-tuning (SFT) accuracy of 35.9\% significantly.

---------------

### 28 Aug 2023 | [DISC-MedLLM: Bridging General Large Language Models and Real-World  Medical Consultation](https://arxiv.org/abs/2308.14346) | [⬇️](https://arxiv.org/pdf/2308.14346)
*Zhijie Bao, Wei Chen, Shengze Xiao, Kuang Ren, Jiaao Wu, Cheng Zhong,  Jiajie Peng, Xuanjing Huang, Zhongyu Wei* 

  We propose DISC-MedLLM, a comprehensive solution that leverages Large
Language Models (LLMs) to provide accurate and truthful medical response in
end-to-end conversational healthcare services. To construct high-quality
Supervised Fine-Tuning (SFT) datasets, we employ three strategies: utilizing
medical knowledge-graphs, reconstructing real-world dialogues, and
incorporating human-guided preference rephrasing. These datasets are
instrumental in training DISC-MedLLM, surpassing existing medical LLMs in both
single-turn and multi-turn consultation scenarios. Extensive experimental
results demonstrate the effectiveness of the proposed model in bridging the gap
between general language models and real-world medical consultation.
Additionally, we release the constructed dataset and model weights to further
contribute to research and development. Further details and resources can be
found at https://github.com/FudanDISC/DISC-MedLLM

---------------

### 02 Mar 2024 | [STAR: Constraint LoRA with Dynamic Active Learning for Data-Efficient  Fine-Tuning of Large Language Models](https://arxiv.org/abs/2403.01165) | [⬇️](https://arxiv.org/pdf/2403.01165)
*Linhai Zhang, Jialong Wu, Deyu Zhou, Guoqiang Xu* 

  Though Large Language Models (LLMs) have demonstrated the powerful
capabilities of few-shot learning through prompting methods, supervised
training is still necessary for complex reasoning tasks. Because of their
extensive parameters and memory consumption, both Parameter-Efficient
Fine-Tuning (PEFT) methods and Memory-Efficient Fine-Tuning methods have been
proposed for LLMs. Nevertheless, the issue of large annotated data consumption,
the aim of Data-Efficient Fine-Tuning, remains unexplored. One obvious way is
to combine the PEFT method with active learning. However, the experimental
results show that such a combination is not trivial and yields inferior
results. Through probe experiments, such observation might be explained by two
main reasons: uncertainty gap and poor model calibration. Therefore, in this
paper, we propose a novel approach to effectively integrate uncertainty-based
active learning and LoRA. Specifically, for the uncertainty gap, we introduce a
dynamic uncertainty measurement that combines the uncertainty of the base model
and the uncertainty of the full model during the iteration of active learning.
For poor model calibration, we incorporate the regularization method during
LoRA training to keep the model from being over-confident, and the Monte-Carlo
dropout mechanism is employed to enhance the uncertainty estimation.
Experimental results show that the proposed approach outperforms existing
baseline models on three complex reasoning tasks.

---------------
**Date:** 05 Mar 2024

**Title:** LoRAMoE: Alleviate World Knowledge Forgetting in Large Language Models  via MoE-Style Plugin

**Abstract Link:** [https://arxiv.org/abs/2312.09979](https://arxiv.org/abs/2312.09979)

**PDF Link:** [https://arxiv.org/pdf/2312.09979](https://arxiv.org/pdf/2312.09979)

---

**Date:** 16 Oct 2023

**Title:** LoBaSS: Gauging Learnability in Supervised Fine-tuning Data

**Abstract Link:** [https://arxiv.org/abs/2310.13008](https://arxiv.org/abs/2310.13008)

**PDF Link:** [https://arxiv.org/pdf/2310.13008](https://arxiv.org/pdf/2310.13008)

---

**Date:** 31 Dec 2023

**Title:** LaFFi: Leveraging Hybrid Natural Language Feedback for Fine-tuning  Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.00907](https://arxiv.org/abs/2401.00907)

**PDF Link:** [https://arxiv.org/pdf/2401.00907](https://arxiv.org/pdf/2401.00907)

---

**Date:** 09 Oct 2023

**Title:** SALMON: Self-Alignment with Principle-Following Reward Models

**Abstract Link:** [https://arxiv.org/abs/2310.05910](https://arxiv.org/abs/2310.05910)

**PDF Link:** [https://arxiv.org/pdf/2310.05910](https://arxiv.org/pdf/2310.05910)

---

**Date:** 04 Mar 2024

**Title:** Analyzing and Adapting Large Language Models for Few-Shot Multilingual  NLU: Are We There Yet?

**Abstract Link:** [https://arxiv.org/abs/2403.01929](https://arxiv.org/abs/2403.01929)

**PDF Link:** [https://arxiv.org/pdf/2403.01929](https://arxiv.org/pdf/2403.01929)

---

**Date:** 25 Feb 2024

**Title:** PeriodicLoRA: Breaking the Low-Rank Bottleneck in LoRA Optimization

**Abstract Link:** [https://arxiv.org/abs/2402.16141](https://arxiv.org/abs/2402.16141)

**PDF Link:** [https://arxiv.org/pdf/2402.16141](https://arxiv.org/pdf/2402.16141)

---

**Date:** 12 Feb 2024

**Title:** Self-Play Fine-Tuning Converts Weak Language Models to Strong Language  Models

**Abstract Link:** [https://arxiv.org/abs/2401.01335](https://arxiv.org/abs/2401.01335)

**PDF Link:** [https://arxiv.org/pdf/2401.01335](https://arxiv.org/pdf/2401.01335)

---

**Date:** 07 Nov 2023

**Title:** Reinforcement Learning Fine-tuning of Language Models is Biased Towards  More Extractable Features

**Abstract Link:** [https://arxiv.org/abs/2311.04046](https://arxiv.org/abs/2311.04046)

**PDF Link:** [https://arxiv.org/pdf/2311.04046](https://arxiv.org/pdf/2311.04046)

---

**Date:** 19 Dec 2023

**Title:** Taiyi: A Bilingual Fine-Tuned Large Language Model for Diverse  Biomedical Tasks

**Abstract Link:** [https://arxiv.org/abs/2311.11608](https://arxiv.org/abs/2311.11608)

**PDF Link:** [https://arxiv.org/pdf/2311.11608](https://arxiv.org/pdf/2311.11608)

---

**Date:** 07 Jun 2023

**Title:** Explicit Knowledge Transfer for Weakly-Supervised Code Generation

**Abstract Link:** [https://arxiv.org/abs/2211.16740](https://arxiv.org/abs/2211.16740)

**PDF Link:** [https://arxiv.org/pdf/2211.16740](https://arxiv.org/pdf/2211.16740)

---

**Date:** 23 Feb 2024

**Title:** An Empirical Study of Data Ability Boundary in LLMs' Math Reasoning

**Abstract Link:** [https://arxiv.org/abs/2403.00799](https://arxiv.org/abs/2403.00799)

**PDF Link:** [https://arxiv.org/pdf/2403.00799](https://arxiv.org/pdf/2403.00799)

---

**Date:** 02 Oct 2023

**Title:** Label Supervised LLaMA Finetuning

**Abstract Link:** [https://arxiv.org/abs/2310.01208](https://arxiv.org/abs/2310.01208)

**PDF Link:** [https://arxiv.org/pdf/2310.01208](https://arxiv.org/pdf/2310.01208)

---

**Date:** 22 Dec 2023

**Title:** On Task Performance and Model Calibration with Supervised and  Self-Ensembled In-Context Learning

**Abstract Link:** [https://arxiv.org/abs/2312.13772](https://arxiv.org/abs/2312.13772)

**PDF Link:** [https://arxiv.org/pdf/2312.13772](https://arxiv.org/pdf/2312.13772)

---

**Date:** 02 Aug 2023

**Title:** Okapi: Instruction-tuned Large Language Models in Multiple Languages  with Reinforcement Learning from Human Feedback

**Abstract Link:** [https://arxiv.org/abs/2307.16039](https://arxiv.org/abs/2307.16039)

**PDF Link:** [https://arxiv.org/pdf/2307.16039](https://arxiv.org/pdf/2307.16039)

---

**Date:** 22 Sep 2023

**Title:** CFGPT: Chinese Financial Assistant with Large Language Model

**Abstract Link:** [https://arxiv.org/abs/2309.10654](https://arxiv.org/abs/2309.10654)

**PDF Link:** [https://arxiv.org/pdf/2309.10654](https://arxiv.org/pdf/2309.10654)

---

**Date:** 09 Sep 2023

**Title:** Analysis of Disinformation and Fake News Detection Using Fine-Tuned  Large Language Model

**Abstract Link:** [https://arxiv.org/abs/2309.04704](https://arxiv.org/abs/2309.04704)

**PDF Link:** [https://arxiv.org/pdf/2309.04704](https://arxiv.org/pdf/2309.04704)

---

**Date:** 28 Nov 2023

**Title:** Training Chain-of-Thought via Latent-Variable Inference

**Abstract Link:** [https://arxiv.org/abs/2312.02179](https://arxiv.org/abs/2312.02179)

**PDF Link:** [https://arxiv.org/pdf/2312.02179](https://arxiv.org/pdf/2312.02179)

---

**Date:** 13 Sep 2023

**Title:** Scaling Relationship on Learning Mathematical Reasoning with Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2308.01825](https://arxiv.org/abs/2308.01825)

**PDF Link:** [https://arxiv.org/pdf/2308.01825](https://arxiv.org/pdf/2308.01825)

---

**Date:** 28 Aug 2023

**Title:** DISC-MedLLM: Bridging General Large Language Models and Real-World  Medical Consultation

**Abstract Link:** [https://arxiv.org/abs/2308.14346](https://arxiv.org/abs/2308.14346)

**PDF Link:** [https://arxiv.org/pdf/2308.14346](https://arxiv.org/pdf/2308.14346)

---

**Date:** 02 Mar 2024

**Title:** STAR: Constraint LoRA with Dynamic Active Learning for Data-Efficient  Fine-Tuning of Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2403.01165](https://arxiv.org/abs/2403.01165)

**PDF Link:** [https://arxiv.org/pdf/2403.01165](https://arxiv.org/pdf/2403.01165)

---

