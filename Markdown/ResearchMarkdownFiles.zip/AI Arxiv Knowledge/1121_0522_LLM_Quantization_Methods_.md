LLM Quantization Methods 📊

### 🔎 LLM Quantization Methods 📊



Quantization is the process of converting a continuous value into a discrete one. In the context of machine learning, quantization is often used to reduce the memory footprint and computational cost of models.

There are several quantization methods, each with its own trade-offs. Here are some of the most common ones:

1. **Uniform Quantization**: This is the simplest form of quantization, where the continuous range is divided into equal-sized bins. The number of bins is a hyperparameter that can be adjusted to balance between memory footprint and quantization error.
2. **Logarithmic Quantization**: This method is useful when the continuous range has a large dynamic range. Instead of dividing the range into equal-sized bins, logarithmic quantization divides the range into bins that are exponentially spaced. This allows for a smaller number of bins to be used while still maintaining a high level of precision for small values.
3. **Non-Uniform Quantization**: This method is similar to uniform quantization, but the bins are not of equal size. Instead, the bin sizes are chosen to minimize the quantization error for a given number of bins. This can result in a significant reduction in quantization error compared to uniform quantization.
4. **K-Means Quantization**: This method uses the K-means clustering algorithm to group the continuous values into K clusters. The centroids of the clusters are then used as the discrete values. This method can be more flexible than uniform or logarithmic quantization, but it can also be more computationally expensive.
5. **Product Quantization**: This method is used for quantizing high-dimensional vectors, such as those used in image and video recognition. The vector is divided into subvectors, and each subvector is quantized independently using a separate codebook. This allows for a more efficient use of the available bits, resulting in a lower quantization error.

When choosing a quantization method, it's important to consider the trade-offs between memory footprint, computational cost, and quantization error. The optimal method will depend on the specific use case and the available resources.</s>
# 🩺🔍 Search Results
### 29 May 2023 | [LLM-QAT: Data-Free Quantization Aware Training for Large Language Models](https://arxiv.org/abs/2305.17888) | [⬇️](https://arxiv.org/pdf/2305.17888)
*Zechun Liu, Barlas Oguz, Changsheng Zhao, Ernie Chang, Pierre Stock,  Yashar Mehdad, Yangyang Shi, Raghuraman Krishnamoorthi, Vikas Chandra* 

  Several post-training quantization methods have been applied to large
language models (LLMs), and have been shown to perform well down to 8-bits. We
find that these methods break down at lower bit precision, and investigate
quantization aware training for LLMs (LLM-QAT) to push quantization levels even
further. We propose a data-free distillation method that leverages generations
produced by the pre-trained model, which better preserves the original output
distribution and allows quantizing any generative model independent of its
training data, similar to post-training quantization methods. In addition to
quantizing weights and activations, we also quantize the KV cache, which is
critical for increasing throughput and support long sequence dependencies at
current model sizes. We experiment with LLaMA models of sizes 7B, 13B, and 30B,
at quantization levels down to 4-bits. We observe large improvements over
training-free methods, especially in the low-bit settings.

---------------

### 01 Dec 2023 | [QuantEase: Optimization-based Quantization for Language Models](https://arxiv.org/abs/2309.01885) | [⬇️](https://arxiv.org/pdf/2309.01885)
*Kayhan Behdin, Ayan Acharya, Aman Gupta, Qingquan Song, Siyu Zhu,  Sathiya Keerthi, Rahul Mazumder* 

  With the rising popularity of Large Language Models (LLMs), there has been an
increasing interest in compression techniques that enable their efficient
deployment. This study focuses on the Post-Training Quantization (PTQ) of LLMs.
Drawing from recent advances, our work introduces QuantEase, a layer-wise
quantization framework where individual layers undergo separate quantization.
The problem is framed as a discrete-structured non-convex optimization,
prompting the development of algorithms rooted in Coordinate Descent (CD)
techniques. These CD-based methods provide high-quality solutions to the
complex non-convex layer-wise quantization problems. Notably, our CD-based
approach features straightforward updates, relying solely on matrix and vector
operations, circumventing the need for matrix inversion or decomposition. We
also explore an outlier-aware variant of our approach, allowing for retaining
significant weights (outliers) with complete precision. Our proposal attains
state-of-the-art performance in terms of perplexity and zero-shot accuracy in
empirical evaluations across various LLMs and datasets, with relative
improvements up to 15% over methods such as GPTQ. Leveraging careful linear
algebra optimizations, QuantEase can quantize models like Falcon-180B on a
single NVIDIA A100 GPU in $\sim$3 hours. Particularly noteworthy is our
outlier-aware algorithm's capability to achieve near or sub-3-bit quantization
of LLMs with an acceptable drop in accuracy, obviating the need for non-uniform
quantization or grouping techniques, improving upon methods such as SpQR by up
to two times in terms of perplexity.

---------------

### 07 Nov 2023 | [PB-LLM: Partially Binarized Large Language Models](https://arxiv.org/abs/2310.00034) | [⬇️](https://arxiv.org/pdf/2310.00034)
*Yuzhang Shang, Zhihang Yuan, Qiang Wu, Zhen Dong* 

  This paper explores network binarization, a radical form of quantization,
compressing model weights to a single bit, specifically for Large Language
Models (LLMs) compression. Due to previous binarization methods collapsing
LLMs, we propose a novel approach, Partially-Binarized LLM (PB-LLM), which can
achieve extreme low-bit quantization while maintaining the linguistic reasoning
capacity of quantized LLMs. Specifically, our exploration first uncovers the
ineffectiveness of naive applications of existing binarization algorithms and
highlights the imperative role of salient weights in achieving low-bit
quantization. Thus, PB-LLM filters a small ratio of salient weights during
binarization, allocating them to higher-bit storage, i.e.,
partially-binarization. PB-LLM is extended to recover the capacities of
quantized LMMs, by analyzing from the perspective of post-training quantization
(PTQ) and quantization-aware training (QAT). Under PTQ, combining the concepts
from GPTQ, we reconstruct the binarized weight matrix guided by the Hessian
matrix and successfully recover the reasoning capacity of PB-LLM in low-bit.
Under QAT, we freeze the salient weights during training, explore the
derivation of optimal scaling factors crucial for minimizing the quantization
error, and propose a scaling mechanism based on this derived scaling strategy
for residual binarized weights. Those explorations and the developed
methodologies significantly contribute to rejuvenating the performance of
low-bit quantized LLMs and present substantial advancements in the field of
network binarization for LLMs.The code is available at
https://github.com/hahnyuan/BinaryLLM.

---------------

### 04 Mar 2024 | [LQER: Low-Rank Quantization Error Reconstruction for LLMs](https://arxiv.org/abs/2402.02446) | [⬇️](https://arxiv.org/pdf/2402.02446)
*Cheng Zhang, Jianyi Cheng, George A. Constantinides, and Yiren Zhao* 

  Post-training quantization of Large Language Models (LLMs) is challenging. In
this work, we introduce Low-rank Quantization Error Reduction (LQER), which
combines quantization and low-rank approximation to recover the model
capability. LQER leverages an activation-induced scale matrix to drive the
singular value distribution of quantization error towards a desirable
distribution, which enables nearly-lossless W4A8 quantization on various LLMs
and downstream tasks without the need for knowledge distillation, grid search,
or gradient-base iterative optimization. Unlike existing methods, the
computation pattern of LQER eliminates the need for specialized Scatter and
Gather processes to collect high-precision weights from irregular memory
locations. Our W4A8 LLMs achieve near-lossless performance on six popular
downstream tasks, while using 1.36$\times$ fewer hardware resources than the
leading state-of-the-art method. We will open-source our framework once the
paper is accepted.

---------------

### 28 Feb 2024 | [Evaluating Quantized Large Language Models](https://arxiv.org/abs/2402.18158) | [⬇️](https://arxiv.org/pdf/2402.18158)
*Shiyao Li, Xuefei Ning, Luning Wang, Tengxuan Liu, Xiangsheng Shi,  Shengen Yan, Guohao Dai, Huazhong Yang, Yu Wang* 

  Post-training quantization (PTQ) has emerged as a promising technique to
reduce the cost of large language models (LLMs). Specifically, PTQ can
effectively mitigate memory consumption and reduce computational overhead in
LLMs. To meet the requirements of both high efficiency and performance across
diverse scenarios, a comprehensive evaluation of quantized LLMs is essential to
guide the selection of quantization methods. This paper presents a thorough
evaluation of these factors by evaluating the effect of PTQ on Weight,
Activation, and KV Cache on 11 model families, including OPT, LLaMA2, Falcon,
Bloomz, Mistral, ChatGLM, Vicuna, LongChat, StableLM, Gemma, and Mamba, with
parameters ranging from 125M to 180B. The evaluation encompasses five types of
tasks: basic NLP, emergent ability, trustworthiness, dialogue, and long-context
tasks. Moreover, we also evaluate the state-of-the-art (SOTA) quantization
methods to demonstrate their applicability. Based on the extensive experiments,
we systematically summarize the effect of quantization, provide recommendations
to apply quantization techniques, and point out future directions.

---------------

### 19 Feb 2024 | [DB-LLM: Accurate Dual-Binarization for Efficient LLMs](https://arxiv.org/abs/2402.11960) | [⬇️](https://arxiv.org/pdf/2402.11960)
*Hong Chen, Chengtao Lv, Liang Ding, Haotong Qin, Xiabin Zhou, Yifu  Ding, Xuebo Liu, Min Zhang, Jinyang Guo, Xianglong Liu, Dacheng Tao* 

  Large language models (LLMs) have significantly advanced the field of natural
language processing, while the expensive memory and computation consumption
impede their practical deployment. Quantization emerges as one of the most
effective methods for improving the computational efficiency of LLMs. However,
existing ultra-low-bit quantization always causes severe accuracy drops. In
this paper, we empirically relieve the micro and macro characteristics of
ultra-low bit quantization and present a novel Dual-Binarization method for
LLMs, namely DB-LLM. For the micro-level, we take both the accuracy advantage
of 2-bit-width and the efficiency advantage of binarization into account,
introducing Flexible Dual Binarization (FDB). By splitting 2-bit quantized
weights into two independent sets of binaries, FDB ensures the accuracy of
representations and introduces flexibility, utilizing the efficient bitwise
operations of binarization while retaining the inherent high sparsity of
ultra-low bit quantization. For the macro-level, we find the distortion that
exists in the prediction of LLM after quantization, which is specified as the
deviations related to the ambiguity of samples. We propose the Deviation-Aware
Distillation (DAD) method, enabling the model to focus differently on various
samples. Comprehensive experiments show that our DB-LLM not only significantly
surpasses the current State-of-The-Art (SoTA) in ultra-low bit quantization
(eg, perplexity decreased from 9.64 to 7.23), but also achieves an additional
20\% reduction in computational consumption compared to the SOTA method under
the same bit-width. Our code will be released soon.

---------------

### 28 Nov 2023 | [LoftQ: LoRA-Fine-Tuning-Aware Quantization for Large Language Models](https://arxiv.org/abs/2310.08659) | [⬇️](https://arxiv.org/pdf/2310.08659)
*Yixiao Li, Yifan Yu, Chen Liang, Pengcheng He, Nikos Karampatziakis,  Weizhu Chen, Tuo Zhao* 

  Quantization is an indispensable technique for serving Large Language Models
(LLMs) and has recently found its way into LoRA fine-tuning. In this work we
focus on the scenario where quantization and LoRA fine-tuning are applied
together on a pre-trained model. In such cases it is common to observe a
consistent gap in the performance on downstream tasks between full fine-tuning
and quantization plus LoRA fine-tuning approach. In response, we propose LoftQ
(LoRA-Fine-Tuning-aware Quantization), a novel quantization framework that
simultaneously quantizes an LLM and finds a proper low-rank initialization for
LoRA fine-tuning. Such an initialization alleviates the discrepancy between the
quantized and full-precision model and significantly improves generalization in
downstream tasks. We evaluate our method on natural language understanding,
question answering, summarization, and natural language generation tasks.
Experiments show that our method is highly effective and outperforms existing
quantization methods, especially in the challenging 2-bit and 2/4-bit mixed
precision regimes. The code is available on https://github.com/yxli2123/LoftQ.

---------------

### 22 Oct 2023 | [OmniQuant: Omnidirectionally Calibrated Quantization for Large Language  Models](https://arxiv.org/abs/2308.13137) | [⬇️](https://arxiv.org/pdf/2308.13137)
*Wenqi Shao, Mengzhao Chen, Zhaoyang Zhang, Peng Xu, Lirui Zhao,  Zhiqian Li, Kaipeng Zhang, Peng Gao, Yu Qiao, Ping Luo* 

  Large language models (LLMs) have revolutionized natural language processing
tasks. However, their practical deployment is hindered by their immense memory
and computation requirements. Although recent post-training quantization (PTQ)
methods are effective in reducing memory footprint and improving the
computational efficiency of LLM, they hand-craft quantization parameters, which
leads to low performance and fails to deal with extremely low-bit quantization.
To tackle this issue, we introduce an Omnidirectionally calibrated Quantization
(OmniQuant) technique for LLMs, which achieves good performance in diverse
quantization settings while maintaining the computational efficiency of PTQ by
efficiently optimizing various quantization parameters. OmniQuant comprises two
innovative components including Learnable Weight Clipping (LWC) and Learnable
Equivalent Transformation (LET). LWC modulates the extreme values of weights by
optimizing the clipping threshold. Meanwhile, LET tackles activation outliers
by shifting the challenge of quantization from activations to weights through a
learnable equivalent transformation. Operating within a differentiable
framework using block-wise error minimization, OmniQuant can optimize the
quantization process efficiently for both weight-only and weight-activation
quantization. For instance, the LLaMA-2 model family with the size of 7-70B can
be processed with OmniQuant on a single A100-40G GPU within 1-16 hours using
128 samples. Extensive experiments validate OmniQuant's superior performance
across diverse quantization configurations such as W4A4, W6A6, W4A16, W3A16,
and W2A16. Additionally, OmniQuant demonstrates effectiveness in
instruction-tuned models and delivers notable improvements in inference speed
and memory reduction on real devices. Codes and models are available at
\url{https://github.com/OpenGVLab/OmniQuant}.

---------------

### 05 Jun 2023 | [SmoothQuant: Accurate and Efficient Post-Training Quantization for Large  Language Models](https://arxiv.org/abs/2211.10438) | [⬇️](https://arxiv.org/pdf/2211.10438)
*Guangxuan Xiao, Ji Lin, Mickael Seznec, Hao Wu, Julien Demouth, Song  Han* 

  Large language models (LLMs) show excellent performance but are compute- and
memory-intensive. Quantization can reduce memory and accelerate inference.
However, existing methods cannot maintain accuracy and hardware efficiency at
the same time. We propose SmoothQuant, a training-free, accuracy-preserving,
and general-purpose post-training quantization (PTQ) solution to enable 8-bit
weight, 8-bit activation (W8A8) quantization for LLMs. Based on the fact that
weights are easy to quantize while activations are not, SmoothQuant smooths the
activation outliers by offline migrating the quantization difficulty from
activations to weights with a mathematically equivalent transformation.
SmoothQuant enables an INT8 quantization of both weights and activations for
all the matrix multiplications in LLMs, including OPT, BLOOM, GLM, MT-NLG, and
LLaMA family. We demonstrate up to 1.56x speedup and 2x memory reduction for
LLMs with negligible loss in accuracy. SmoothQuant enables serving 530B LLM
within a single node. Our work offers a turn-key solution that reduces hardware
costs and democratizes LLMs. Code is available at
https://github.com/mit-han-lab/smoothquant.

---------------

### 24 Jan 2024 | [OWQ: Outlier-Aware Weight Quantization for Efficient Fine-Tuning and  Inference of Large Language Models](https://arxiv.org/abs/2306.02272) | [⬇️](https://arxiv.org/pdf/2306.02272)
*Changhun Lee, Jungyu Jin, Taesu Kim, Hyungjun Kim, Eunhyeok Park* 

  Large language models (LLMs) with hundreds of billions of parameters require
powerful server-grade GPUs for inference, limiting their practical deployment.
To address this challenge, we introduce the outlier-aware weight quantization
(OWQ) method, which aims to minimize LLM's footprint through low-precision
representation. OWQ prioritizes a small subset of structured weights sensitive
to quantization, storing them in high-precision, while applying highly tuned
quantization to the remaining dense weights. This sensitivity-aware
mixed-precision scheme reduces the quantization error notably, and extensive
experiments demonstrate that 3.1-bit models using OWQ perform comparably to
4-bit models optimized by OPTQ. Furthermore, OWQ incorporates a
parameter-efficient fine-tuning for task-specific adaptation, called weak
column tuning (WCT), enabling accurate task-specific LLM adaptation with
minimal memory overhead in the optimized format. OWQ represents a notable
advancement in the flexibility, efficiency, and practicality of LLM
optimization literature. The source code is available at
https://github.com/xvyaward/owq

---------------

### 28 Feb 2023 | [The case for 4-bit precision: k-bit Inference Scaling Laws](https://arxiv.org/abs/2212.09720) | [⬇️](https://arxiv.org/pdf/2212.09720)
*Tim Dettmers, Luke Zettlemoyer* 

  Quantization methods reduce the number of bits required to represent each
parameter in a model, trading accuracy for smaller memory footprints and
inference latencies. However, the final model size depends on both the number
of parameters of the original model and the rate of compression. For example, a
30B 8-bit model and a 60B 4-bit model have the same number of bits but may have
very different zero-shot accuracies. In this work, we study this trade-off by
developing inference scaling laws of zero-shot performance in Large Language
Models (LLMs) to determine the bit-precision and model size that maximizes
zero-shot performance. We run more than 35,000 experiments with 16-bit inputs
and k-bit parameters to examine which zero-shot quantization methods improve
scaling for 3 to 8-bit precision at scales of 19M to 176B parameters across the
LLM families BLOOM, OPT, NeoX/Pythia, and GPT-2. We find that it is challenging
to improve the bit-level scaling trade-off, with the only improvements being
the use of a small block size -- splitting the parameters into small
independently quantized blocks -- and the quantization data type being used
(e.g., Int vs Float). Overall, our findings show that {4-bit} precision is
almost universally optimal for total model bits and zero-shot accuracy.

---------------

### 02 Feb 2024 | [CBQ: Cross-Block Quantization for Large Language Models](https://arxiv.org/abs/2312.07950) | [⬇️](https://arxiv.org/pdf/2312.07950)
*Xin Ding, Xiaoyu Liu, Zhijun Tu, Yun Zhang, Wei Li, Jie Hu, Hanting  Chen, Yehui Tang, Zhiwei Xiong, Baoqun Yin, Yunhe Wang* 

  Post-training quantization (PTQ) has played a key role in compressing large
language models (LLMs) with ultra-low costs. However, existing PTQ methods only
focus on handling the outliers within one layer or one block, which ignores the
dependency of blocks and leads to severe performance degradation in low-bit
settings. In this paper, we propose CBQ, a cross-block reconstruction-based PTQ
method for LLMs. CBQ employs a cross-block dependency using a homologous
reconstruction scheme, establishing long-range dependencies across multiple
blocks to minimize error accumulation. Furthermore, CBQ incorporates a
coarse-to-fine preprocessing (CFP) strategy for suppressing weight and
activation outliers, coupled with an adaptive LoRA-Rounding technique for
precise weight quantization. These innovations enable CBQ to not only handle
extreme outliers effectively but also improve overall quantization accuracy.
Extensive experiments show that CBQ achieves superior low-bit quantization
(W4A4, W4A8, W2A16) and outperforms existing state-of-the-art methods across
various LLMs and datasets. Notably, CBQ quantizes the 4-bit LLAMA1-65B model
within only 4.3 hours on a single GPU, achieving a commendable tradeoff between
performance and quantization efficiency.

---------------

### 17 Feb 2024 | [OneBit: Towards Extremely Low-bit Large Language Models](https://arxiv.org/abs/2402.11295) | [⬇️](https://arxiv.org/pdf/2402.11295)
*Yuzhuang Xu, Xu Han, Zonghan Yang, Shuo Wang, Qingfu Zhu, Zhiyuan Liu,  Weidong Liu, Wanxiang Che* 

  Model quantification uses low bit-width values to represent the weight
matrices of models, which is a promising approach to reduce both storage and
computational overheads of deploying highly anticipated LLMs. However, existing
quantization methods suffer severe performance degradation when the bit-width
is extremely reduced, and thus focus on utilizing 4-bit or 8-bit values to
quantize models. This paper boldly quantizes the weight matrices of LLMs to
1-bit, paving the way for the extremely low bit-width deployment of LLMs. For
this target, we introduce a 1-bit quantization-aware training (QAT) framework
named OneBit, including a novel 1-bit parameter representation method to better
quantize LLMs as well as an effective parameter initialization method based on
matrix decomposition to improve the convergence speed of the QAT framework.
Sufficient experimental results indicate that OneBit achieves good performance
(at least 83% of the non-quantized performance) with robust training processes
when only using 1-bit weight matrices.

---------------

### 09 Nov 2023 | [Enhancing Computation Efficiency in Large Language Models through Weight  and Activation Quantization](https://arxiv.org/abs/2311.05161) | [⬇️](https://arxiv.org/pdf/2311.05161)
*Jangwhan Lee, Minsoo Kim, Seungcheol Baek, Seok Joong Hwang, Wonyong  Sung and Jungwook Choi* 

  Large Language Models (LLMs) are proficient in natural language processing
tasks, but their deployment is often restricted by extensive parameter sizes
and computational demands. This paper focuses on post-training quantization
(PTQ) in LLMs, specifically 4-bit weight and 8-bit activation (W4A8)
quantization, to enhance computational efficiency -- a topic less explored
compared to weight-only quantization. We present two innovative techniques:
activation-quantization-aware scaling (AQAS) and sequence-length-aware
calibration (SLAC) to enhance PTQ by considering the combined effects on
weights and activations and aligning calibration sequence lengths to target
tasks. Moreover, we introduce dINT, a hybrid data format combining integer and
denormal representations, to address the underflow issue in W4A8 quantization,
where small values are rounded to zero. Through rigorous evaluations of LLMs,
including OPT and LLaMA, we demonstrate that our techniques significantly boost
task accuracies to levels comparable with full-precision models. By developing
arithmetic units compatible with dINT, we further confirm that our methods
yield a 2$\times$ hardware efficiency improvement compared to 8-bit integer MAC
unit.

---------------

### 21 Feb 2024 | [QLLM: Accurate and Efficient Low-Bitwidth Quantization for Large  Language Models](https://arxiv.org/abs/2310.08041) | [⬇️](https://arxiv.org/pdf/2310.08041)
*Jing Liu, Ruihao Gong, Xiuying Wei, Zhiwei Dong, Jianfei Cai, Bohan  Zhuang* 

  Large Language Models (LLMs) excel in NLP, but their demands hinder their
widespread deployment. While Quantization-Aware Training (QAT) offers a
solution, its extensive training costs make Post-Training Quantization (PTQ) a
more practical approach for LLMs. In existing studies, activation outliers in
particular channels are identified as the bottleneck to PTQ accuracy. They
propose to transform the magnitudes from activations to weights, which however
offers limited alleviation or suffers from unstable gradients, resulting in a
severe performance drop at low-bitwidth. In this paper, we propose QLLM, an
accurate and efficient low-bitwidth PTQ method designed for LLMs. QLLM
introduces an adaptive channel reassembly technique that reallocates the
magnitude of outliers to other channels, thereby mitigating their impact on the
quantization range. This is achieved by channel disassembly and channel
assembly, which first breaks down the outlier channels into several
sub-channels to ensure a more balanced distribution of activation magnitudes.
Then similar channels are merged to maintain the original channel number for
efficiency. Additionally, an adaptive strategy is designed to autonomously
determine the optimal number of sub-channels for channel disassembly. To
further compensate for the performance loss caused by quantization, we propose
an efficient tuning method that only learns a small number of low-rank weights
while freezing the pre-trained quantized model. After training, these low-rank
parameters can be fused into the frozen weights without affecting inference.
Extensive experiments on LLaMA-1 and LLaMA-2 show that QLLM can obtain accurate
quantized models efficiently. For example, QLLM quantizes the 4-bit LLaMA-2-70B
within 10 hours on a single A100-80G GPU, outperforming the previous
state-of-the-art method by 7.89% on the average accuracy across five zero-shot
tasks.

---------------

### 07 Oct 2023 | [Dual Grained Quantization: Efficient Fine-Grained Quantization for LLM](https://arxiv.org/abs/2310.04836) | [⬇️](https://arxiv.org/pdf/2310.04836)
*Luoming Zhang, Wen Fei, Weijia Wu, Yefei He, Zhenyu Lou, Hong Zhou* 

  Large Language Models (LLMs) pose significant hardware challenges related to
memory requirements and computational ability. There are two mainstream
quantization schemes for LLMs: coarse-grained ($\textit{e.g.,}$ channel-wise)
quantization and fine-grained ($\textit{e.g.,}$ group-wise) quantization.
Fine-grained quantization has smaller quantization loss, consequently achieving
superior performance. However, when applied to weight-activation quantization,
it disrupts continuous integer matrix multiplication, leading to inefficient
inference. In this paper, we introduce Dual Grained Quantization (DGQ), a novel
A8W4 quantization for LLM that maintains superior performance while ensuring
fast inference speed. DSQ dequantizes the fine-grained INT4 weight into
coarse-grained INT8 representation and preform matrix multiplication using INT8
kernels. Besides, we develop a two-phase grid search algorithm to simplify the
determination of fine-grained and coarse-grained quantization scales. We also
devise a percentile clipping schema for smoothing the activation outliers
without the need for complex optimization techniques. Experimental results
demonstrate that DGQ consistently outperforms prior methods across various LLM
architectures and a wide range of tasks. Remarkably, by our implemented
efficient CUTLASS kernel, we achieve $\textbf{1.12}$ $\times$ memory reduction
and $\textbf{3.24}$ $\times$ speed gains comparing A16W4 implementation. These
advancements enable efficient deployment of A8W4 LLMs for real-world
applications.

---------------

### 15 Feb 2024 | [L4Q: Parameter Efficient Quantization-Aware Training on Large Language  Models via LoRA-wise LSQ](https://arxiv.org/abs/2402.04902) | [⬇️](https://arxiv.org/pdf/2402.04902)
*Hyesung Jeon, Yulhwa Kim, Jae-joon Kim* 

  Post-training quantization (PTQ) and quantization-aware training (QAT)
methods are gaining popularity in mitigating the high memory and computational
costs associated with Large Language Models (LLMs). In resource-constrained
scenarios, PTQ, with its reduced training overhead, is often preferred over
QAT, despite the latter's potential for higher accuracy. Meanwhile,
parameter-efficient fine-tuning (PEFT) methods like low-rank adaptation (LoRA)
have been introduced, and recent efforts have explored quantization-aware PEFT
techniques. However, these approaches may lack generality due to their reliance
on the pre-quantized model's configuration. Their effectiveness may be
compromised by non-linearly quantized or mixed-precision weights, and the
retraining of specific quantization parameters might impede optimal
performance. To address these challenges, we propose L4Q, an algorithm for
parameter-efficient quantization-aware training. L4Q leverages LoRA-wise
learned quantization step size for LLMs, aiming to enhance generality. The
simultaneous quantization-and-fine-tuning process of L4Q is applicable to
high-precision models, yielding linearly quantized weights with superior
accuracy. Our experiments, conducted on the LLaMA and LLaMA2 model families
using an instructional dataset, showcase L4Q's capabilities in language
comprehension and few-shot in-context learning, achieving sub-4-bit precision
while maintaining comparable training times to applying PEFT on a quantized
model.

---------------

### 15 Jan 2024 | [QuIP: 2-Bit Quantization of Large Language Models With Guarantees](https://arxiv.org/abs/2307.13304) | [⬇️](https://arxiv.org/pdf/2307.13304)
*Jerry Chee, Yaohui Cai, Volodymyr Kuleshov, Christopher De Sa* 

  This work studies post-training parameter quantization in large language
models (LLMs). We introduce quantization with incoherence processing (QuIP), a
new method based on the insight that quantization benefits from
$\textit{incoherent}$ weight and Hessian matrices, i.e., from the weights being
even in magnitude and the directions in which it is important to round them
accurately being unaligned with the coordinate axes. QuIP consists of two
steps: (1) an adaptive rounding procedure minimizing a quadratic proxy
objective; (2) efficient pre- and post-processing that ensures weight and
Hessian incoherence via multiplication by random orthogonal matrices. We
complement QuIP with the first theoretical analysis for an LLM-scale
quantization algorithm, and show that our theory also applies to an existing
method, OPTQ. Empirically, we find that our incoherence preprocessing improves
several existing quantization algorithms and yields the first LLM quantization
methods that produce viable results using only two bits per weight. Our code
can be found at https://github.com/Cornell-RelaxML/QuIP.

---------------

### 06 Feb 2024 | [Extreme Compression of Large Language Models via Additive Quantization](https://arxiv.org/abs/2401.06118) | [⬇️](https://arxiv.org/pdf/2401.06118)
*Vage Egiazarian, Andrei Panferov, Denis Kuznedelev, Elias Frantar,  Artem Babenko, Dan Alistarh* 

  The emergence of accurate open large language models (LLMs) has led to a race
towards quantization techniques for such models enabling execution on end-user
devices. In this paper, we revisit the problem of "extreme" LLM
compression--defined as targeting extremely low bit counts, such as 2 to 3 bits
per parameter, from the point of view of classic methods in Multi-Codebook
Quantization (MCQ). Our work builds on top of Additive Quantization, a classic
algorithm from the MCQ family, and adapts it to the quantization of language
models. The resulting algorithm advances the state-of-the-art in LLM
compression, outperforming all recently-proposed techniques in terms of
accuracy at a given compression budget. For instance, when compressing Llama 2
models to 2 bits per parameter, our algorithm quantizes the 7B model to 6.93
perplexity (a 1.29 improvement relative to the best prior work, and 1.81 points
from FP16), the 13B model to 5.70 perplexity (a .36 improvement) and the 70B
model to 3.94 perplexity (a .22 improvement) on WikiText2. We release our
implementation of Additive Quantization for Language Models AQLM as a baseline
to facilitate future research in LLM quantization.

---------------

### 07 Nov 2023 | [Atom: Low-bit Quantization for Efficient and Accurate LLM Serving](https://arxiv.org/abs/2310.19102) | [⬇️](https://arxiv.org/pdf/2310.19102)
*Yilong Zhao, Chien-Yu Lin, Kan Zhu, Zihao Ye, Lequn Chen, Size Zheng,  Luis Ceze, Arvind Krishnamurthy, Tianqi Chen and Baris Kasikci* 

  The growing demand for Large Language Models (LLMs) in applications such as
content generation, intelligent chatbots, and sentiment analysis poses
considerable challenges for LLM service providers. To efficiently use GPU
resources and boost throughput, batching multiple requests has emerged as a
popular paradigm; to further speed up batching, LLM quantization techniques
reduce memory consumption and increase computing capacity. However, prevalent
quantization schemes (e.g., 8-bit weight-activation quantization) cannot fully
leverage the capabilities of modern GPUs, such as 4-bit integer operators,
resulting in sub-optimal performance.
  To maximize LLMs' serving throughput, we introduce Atom, a low-bit
quantization method that achieves high throughput improvements with negligible
accuracy loss. Atom significantly boosts serving throughput by using low-bit
operators and considerably reduces memory consumption via low-bit quantization.
It attains high accuracy by applying a novel mixed-precision and fine-grained
quantization process. We evaluate Atom on 4-bit weight-activation quantization
setups in the serving context. Atom improves end-to-end throughput by up to
$7.73\times$ compared to the FP16 and by $2.53\times$ compared to INT8
quantization, while maintaining the same latency target.

---------------
**Date:** 29 May 2023

**Title:** LLM-QAT: Data-Free Quantization Aware Training for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2305.17888](https://arxiv.org/abs/2305.17888)

**PDF Link:** [https://arxiv.org/pdf/2305.17888](https://arxiv.org/pdf/2305.17888)

---

**Date:** 01 Dec 2023

**Title:** QuantEase: Optimization-based Quantization for Language Models

**Abstract Link:** [https://arxiv.org/abs/2309.01885](https://arxiv.org/abs/2309.01885)

**PDF Link:** [https://arxiv.org/pdf/2309.01885](https://arxiv.org/pdf/2309.01885)

---

**Date:** 07 Nov 2023

**Title:** PB-LLM: Partially Binarized Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.00034](https://arxiv.org/abs/2310.00034)

**PDF Link:** [https://arxiv.org/pdf/2310.00034](https://arxiv.org/pdf/2310.00034)

---

**Date:** 04 Mar 2024

**Title:** LQER: Low-Rank Quantization Error Reconstruction for LLMs

**Abstract Link:** [https://arxiv.org/abs/2402.02446](https://arxiv.org/abs/2402.02446)

**PDF Link:** [https://arxiv.org/pdf/2402.02446](https://arxiv.org/pdf/2402.02446)

---

**Date:** 28 Feb 2024

**Title:** Evaluating Quantized Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.18158](https://arxiv.org/abs/2402.18158)

**PDF Link:** [https://arxiv.org/pdf/2402.18158](https://arxiv.org/pdf/2402.18158)

---

**Date:** 19 Feb 2024

**Title:** DB-LLM: Accurate Dual-Binarization for Efficient LLMs

**Abstract Link:** [https://arxiv.org/abs/2402.11960](https://arxiv.org/abs/2402.11960)

**PDF Link:** [https://arxiv.org/pdf/2402.11960](https://arxiv.org/pdf/2402.11960)

---

**Date:** 28 Nov 2023

**Title:** LoftQ: LoRA-Fine-Tuning-Aware Quantization for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.08659](https://arxiv.org/abs/2310.08659)

**PDF Link:** [https://arxiv.org/pdf/2310.08659](https://arxiv.org/pdf/2310.08659)

---

**Date:** 22 Oct 2023

**Title:** OmniQuant: Omnidirectionally Calibrated Quantization for Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2308.13137](https://arxiv.org/abs/2308.13137)

**PDF Link:** [https://arxiv.org/pdf/2308.13137](https://arxiv.org/pdf/2308.13137)

---

**Date:** 05 Jun 2023

**Title:** SmoothQuant: Accurate and Efficient Post-Training Quantization for Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2211.10438](https://arxiv.org/abs/2211.10438)

**PDF Link:** [https://arxiv.org/pdf/2211.10438](https://arxiv.org/pdf/2211.10438)

---

**Date:** 24 Jan 2024

**Title:** OWQ: Outlier-Aware Weight Quantization for Efficient Fine-Tuning and  Inference of Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2306.02272](https://arxiv.org/abs/2306.02272)

**PDF Link:** [https://arxiv.org/pdf/2306.02272](https://arxiv.org/pdf/2306.02272)

---

**Date:** 28 Feb 2023

**Title:** The case for 4-bit precision: k-bit Inference Scaling Laws

**Abstract Link:** [https://arxiv.org/abs/2212.09720](https://arxiv.org/abs/2212.09720)

**PDF Link:** [https://arxiv.org/pdf/2212.09720](https://arxiv.org/pdf/2212.09720)

---

**Date:** 02 Feb 2024

**Title:** CBQ: Cross-Block Quantization for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2312.07950](https://arxiv.org/abs/2312.07950)

**PDF Link:** [https://arxiv.org/pdf/2312.07950](https://arxiv.org/pdf/2312.07950)

---

**Date:** 17 Feb 2024

**Title:** OneBit: Towards Extremely Low-bit Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.11295](https://arxiv.org/abs/2402.11295)

**PDF Link:** [https://arxiv.org/pdf/2402.11295](https://arxiv.org/pdf/2402.11295)

---

**Date:** 09 Nov 2023

**Title:** Enhancing Computation Efficiency in Large Language Models through Weight  and Activation Quantization

**Abstract Link:** [https://arxiv.org/abs/2311.05161](https://arxiv.org/abs/2311.05161)

**PDF Link:** [https://arxiv.org/pdf/2311.05161](https://arxiv.org/pdf/2311.05161)

---

**Date:** 21 Feb 2024

**Title:** QLLM: Accurate and Efficient Low-Bitwidth Quantization for Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.08041](https://arxiv.org/abs/2310.08041)

**PDF Link:** [https://arxiv.org/pdf/2310.08041](https://arxiv.org/pdf/2310.08041)

---

**Date:** 07 Oct 2023

**Title:** Dual Grained Quantization: Efficient Fine-Grained Quantization for LLM

**Abstract Link:** [https://arxiv.org/abs/2310.04836](https://arxiv.org/abs/2310.04836)

**PDF Link:** [https://arxiv.org/pdf/2310.04836](https://arxiv.org/pdf/2310.04836)

---

**Date:** 15 Feb 2024

**Title:** L4Q: Parameter Efficient Quantization-Aware Training on Large Language  Models via LoRA-wise LSQ

**Abstract Link:** [https://arxiv.org/abs/2402.04902](https://arxiv.org/abs/2402.04902)

**PDF Link:** [https://arxiv.org/pdf/2402.04902](https://arxiv.org/pdf/2402.04902)

---

**Date:** 15 Jan 2024

**Title:** QuIP: 2-Bit Quantization of Large Language Models With Guarantees

**Abstract Link:** [https://arxiv.org/abs/2307.13304](https://arxiv.org/abs/2307.13304)

**PDF Link:** [https://arxiv.org/pdf/2307.13304](https://arxiv.org/pdf/2307.13304)

---

**Date:** 06 Feb 2024

**Title:** Extreme Compression of Large Language Models via Additive Quantization

**Abstract Link:** [https://arxiv.org/abs/2401.06118](https://arxiv.org/abs/2401.06118)

**PDF Link:** [https://arxiv.org/pdf/2401.06118](https://arxiv.org/pdf/2401.06118)

---

**Date:** 07 Nov 2023

**Title:** Atom: Low-bit Quantization for Efficient and Accurate LLM Serving

**Abstract Link:** [https://arxiv.org/abs/2310.19102](https://arxiv.org/abs/2310.19102)

**PDF Link:** [https://arxiv.org/pdf/2310.19102](https://arxiv.org/pdf/2310.19102)

---

