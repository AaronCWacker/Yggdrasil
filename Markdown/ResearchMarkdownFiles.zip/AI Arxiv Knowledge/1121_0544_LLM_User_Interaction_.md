LLM User Interaction 🎭

### 🔎 LLM User Interaction 🎭



# User Interaction

User interaction is the way users interact with your app. This can be through tapping buttons, scrolling, swiping, or even typing.

## Buttons

Buttons are the most common way to interact with an app. They can be used to trigger actions, navigate to other screens, or submit forms.

### Standard Button

A standard button is a button that has a solid background color and text on top of it. It's the most common type of button and is used for the majority of cases.

### Outline Button

An outline button is a button that has a thin border and text inside it. It's used when you want to draw attention to the button, but you don't want it to be the primary action.

### Text Button

A text button is a button that is just text. It's used when you want to provide a link-like interaction, but you want it to be more obvious that it's a button.

## Links

Links are used to navigate to other screens or to open external websites. They can be underlined or not, depending on the design.

## Forms

Forms are used to collect information from users. They can be used to create accounts, submit feedback, or make purchases.

### Text Field

A text field is a form input that allows users to type text. It can be used for names, email addresses, passwords, or any other text input.

### Checkbox

A checkbox is a form input that allows users to select one or more options. It's used when you want to allow users to select multiple options.

### Radio Button

A radio button is a form input that allows users to select one option from a list. It's used when you want to allow users to select only one option.

### Switch

A switch is a form input that allows users to toggle between two options. It's used when you want to allow users to turn something on or off.

## Scroll View

A scroll view is a view that allows users to scroll through content that is too large to fit on the screen. It's used when you have a lot of content that you want to display, but you don't want to make the user scroll through it all at once.

## Tab Bar


# 🩺🔍 Search Results
### 21 Feb 2024 | [User-LLM: Efficient LLM Contextualization with User Embeddings](https://arxiv.org/abs/2402.13598) | [⬇️](https://arxiv.org/pdf/2402.13598)
*Lin Ning, Luyang Liu, Jiaxing Wu, Neo Wu, Devora Berlowitz, Sushant  Prakash, Bradley Green, Shawn O'Banion, Jun Xie* 

  Large language models (LLMs) have revolutionized natural language processing.
However, effectively incorporating complex and potentially noisy user
interaction data remains a challenge. To address this, we propose User-LLM, a
novel framework that leverages user embeddings to contextualize LLMs. These
embeddings, distilled from diverse user interactions using self-supervised
pretraining, capture latent user preferences and their evolution over time. We
integrate these user embeddings with LLMs through cross-attention and
soft-prompting, enabling LLMs to dynamically adapt to user context. Our
comprehensive experiments on MovieLens, Amazon Review, and Google Local Review
datasets demonstrate significant performance gains across various tasks.
Notably, our approach outperforms text-prompt-based contextualization on long
sequence tasks and tasks that require deep user understanding while being
computationally efficient. We further incorporate Perceiver layers to
streamline the integration between user encoders and LLMs, reducing
computational demands.

---------------

### 24 Feb 2024 | [Mobile-Env: An Evaluation Platform and Benchmark for LLM-GUI Interaction](https://arxiv.org/abs/2305.08144) | [⬇️](https://arxiv.org/pdf/2305.08144)
*Danyang Zhang, Hongshen Xu, Zihan Zhao, Lu Chen, Ruisheng Cao, Kai Yu* 

  The User Interface (UI) is pivotal for human interaction with the digital
world, facilitating efficient control of machines, information navigation, and
complex task completion. To achieve easy, efficient, and free interactions,
researchers have been exploring the potential of encapsulating the traditional
Programming Language Interfaces (PLIs) and Graphical User Interfaces (GUIs)
into Natural Language Interfaces (NLIs). However, due to the limited
capabilities of small models, traditional work mainly focuses on tasks for
which only a single step is needed. This largely constrains the application of
NLIs. Recently, Large Language Models (LLMs) have exhibited robust reasoning
and planning abilities, yet their potential for multi-turn interactions in
complex environments remains under-explored. To assess LLMs as NLIs in
real-world graphical environments, we introduce the GUI interaction platform,
Mobile-Env, specifically on mobile apps. Mobile-Env enhances interaction
flexibility, task extensibility, and environment adaptability compared with
previous environments. A GUI task set based on WikiHow app is collected on
Mobile-Env to form a benchmark covering a range of GUI interaction
capabilities. We further conduct comprehensive evaluations of LLM agents,
including various versions of GPT, LLaMA 2, and AgentLM, on WikiHow task set to
acquire insights into the potentials and challenges of LLMs in GUI
interactions.

---------------

### 20 Apr 2023 | [Low-code LLM: Visual Programming over LLMs](https://arxiv.org/abs/2304.08103) | [⬇️](https://arxiv.org/pdf/2304.08103)
*Yuzhe Cai, Shaoguang Mao, Wenshan Wu, Zehua Wang, Yaobo Liang, Tao Ge,  Chenfei Wu, Wang You, Ting Song, Yan Xia, Jonathan Tien, Nan Duan* 

  Effectively utilizing LLMs for complex tasks is challenging, often involving
a time-consuming and uncontrollable prompt engineering process. This paper
introduces a novel human-LLM interaction framework, Low-code LLM. It
incorporates six types of simple low-code visual programming interactions, all
supported by clicking, dragging, or text editing, to achieve more controllable
and stable responses. Through visual interaction with a graphical user
interface, users can incorporate their ideas into the workflow without writing
trivial prompts. The proposed Low-code LLM framework consists of a Planning LLM
that designs a structured planning workflow for complex tasks, which can be
correspondingly edited and confirmed by users through low-code visual
programming operations, and an Executing LLM that generates responses following
the user-confirmed workflow. We highlight three advantages of the low-code LLM:
controllable generation results, user-friendly human-LLM interaction, and
broadly applicable scenarios. We demonstrate its benefits using four typical
applications. By introducing this approach, we aim to bridge the gap between
humans and LLMs, enabling more effective and efficient utilization of LLMs for
complex tasks. Our system will be soon publicly available at LowCodeLLM.

---------------

### 14 Nov 2023 | [LatticeGen: A Cooperative Framework which Hides Generated Text in a  Lattice for Privacy-Aware Generation on Cloud](https://arxiv.org/abs/2309.17157) | [⬇️](https://arxiv.org/pdf/2309.17157)
*Mengke Zhang, Tianxing He, Tianle Wang, Lu Mi, Fatemehsadat  Mireshghallah, Binyi Chen, Hao Wang, Yulia Tsvetkov* 

  In the current user-server interaction paradigm of prompted generation with
large language models (LLM) on cloud, the server fully controls the generation
process, which leaves zero options for users who want to keep the generated
text to themselves. We propose LatticeGen, a cooperative framework in which the
server still handles most of the computation while the user controls the
sampling operation. The key idea is that the true generated sequence is mixed
with noise tokens by the user and hidden in a noised lattice. Considering
potential attacks from a hypothetically malicious server and how the user can
defend against it, we propose the repeated beam-search attack and the mixing
noise scheme. In our experiments we apply LatticeGen to protect both prompt and
generation. It is shown that while the noised lattice degrades generation
quality, LatticeGen successfully protects the true generation to a remarkable
degree under strong attacks (more than 50% of the semantic remains hidden as
measured by BERTScore).

---------------

### 06 Jan 2024 | [Understanding Large-Language Model (LLM)-powered Human-Robot Interaction](https://arxiv.org/abs/2401.03217) | [⬇️](https://arxiv.org/pdf/2401.03217)
*Callie Y. Kim, Christine P. Lee, Bilge Mutlu* 

  Large-language models (LLMs) hold significant promise in improving
human-robot interaction, offering advanced conversational skills and
versatility in managing diverse, open-ended user requests in various tasks and
domains. Despite the potential to transform human-robot interaction, very
little is known about the distinctive design requirements for utilizing LLMs in
robots, which may differ from text and voice interaction and vary by task and
context. To better understand these requirements, we conducted a user study (n
= 32) comparing an LLM-powered social robot against text- and voice-based
agents, analyzing task-based requirements in conversational tasks, including
choose, generate, execute, and negotiate. Our findings show that LLM-powered
robots elevate expectations for sophisticated non-verbal cues and excel in
connection-building and deliberation, but fall short in logical communication
and may induce anxiety. We provide design implications both for robots
integrating LLMs and for fine-tuning LLMs for use with robots.

---------------

### 22 Dec 2023 | [MetaAID 2.5: A Secure Framework for Developing Metaverse Applications  via Large Language Models](https://arxiv.org/abs/2312.14480) | [⬇️](https://arxiv.org/pdf/2312.14480)
*Hongyin Zhu* 

  Large language models (LLMs) are increasingly being used in Metaverse
environments to generate dynamic and realistic content and to control the
behavior of non-player characters (NPCs). However, the cybersecurity concerns
associated with LLMs have become increasingly prominent. Previous research has
primarily focused on patching system vulnerabilities to enhance cybersecurity,
but these approaches are not well-suited to the Metaverse, where the virtual
space is more complex, LLMs are vulnerable, and ethical user interaction is
critical. Moreover, the scope of cybersecurity in the Metaverse is expected to
expand significantly. This paper proposes a method for enhancing cybersecurity
through the simulation of user interaction with LLMs. Our goal is to educate
users and strengthen their defense capabilities through exposure to a
comprehensive simulation system. This system includes extensive Metaverse
cybersecurity Q&A and attack simulation scenarios. By engaging with these,
users will improve their ability to recognize and withstand risks.
Additionally, to address the ethical implications of user input, we propose
using LLMs as evaluators to assess user content across five dimensions. We
further adapt the models through vocabulary expansion training to better
understand personalized inputs and emoticons. We conduct experiments on
multiple LLMs and find that our approach is effective.

---------------

### 01 Dec 2023 | [Beyond ChatBots: ExploreLLM for Structured Thoughts and Personalized  Model Responses](https://arxiv.org/abs/2312.00763) | [⬇️](https://arxiv.org/pdf/2312.00763)
*Xiao Ma, Swaroop Mishra, Ariel Liu, Sophie Su, Jilin Chen, Chinmay  Kulkarni, Heng-Tze Cheng, Quoc Le, Ed Chi* 

  Large language model (LLM) powered chatbots are primarily text-based today,
and impose a large interactional cognitive load, especially for exploratory or
sensemaking tasks such as planning a trip or learning about a new city. Because
the interaction is textual, users have little scaffolding in the way of
structure, informational "scent", or ability to specify high-level preferences
or goals. We introduce ExploreLLM that allows users to structure thoughts, help
explore different options, navigate through the choices and recommendations,
and to more easily steer models to generate more personalized responses. We
conduct a user study and show that users find it helpful to use ExploreLLM for
exploratory or planning tasks, because it provides a useful schema-like
structure to the task, and guides users in planning. The study also suggests
that users can more easily personalize responses with high-level preferences
with ExploreLLM. Together, ExploreLLM points to a future where users interact
with LLMs beyond the form of chatbots, and instead designed to support complex
user tasks with a tighter integration between natural language and graphical
user interfaces.

---------------

### 10 May 2023 | [Do LLMs Understand User Preferences? Evaluating LLMs On User Rating  Prediction](https://arxiv.org/abs/2305.06474) | [⬇️](https://arxiv.org/pdf/2305.06474)
*Wang-Cheng Kang, Jianmo Ni, Nikhil Mehta, Maheswaran Sathiamoorthy,  Lichan Hong, Ed Chi, Derek Zhiyuan Cheng* 

  Large Language Models (LLMs) have demonstrated exceptional capabilities in
generalizing to new tasks in a zero-shot or few-shot manner. However, the
extent to which LLMs can comprehend user preferences based on their previous
behavior remains an emerging and still unclear research question.
Traditionally, Collaborative Filtering (CF) has been the most effective method
for these tasks, predominantly relying on the extensive volume of rating data.
In contrast, LLMs typically demand considerably less data while maintaining an
exhaustive world knowledge about each item, such as movies or products. In this
paper, we conduct a thorough examination of both CF and LLMs within the classic
task of user rating prediction, which involves predicting a user's rating for a
candidate item based on their past ratings. We investigate various LLMs in
different sizes, ranging from 250M to 540B parameters and evaluate their
performance in zero-shot, few-shot, and fine-tuning scenarios. We conduct
comprehensive analysis to compare between LLMs and strong CF methods, and find
that zero-shot LLMs lag behind traditional recommender models that have the
access to user interaction data, indicating the importance of user interaction
data. However, through fine-tuning, LLMs achieve comparable or even better
performance with only a small fraction of the training data, demonstrating
their potential through data efficiency.

---------------

### 13 Oct 2023 | [AgentCF: Collaborative Learning with Autonomous Language Agents for  Recommender Systems](https://arxiv.org/abs/2310.09233) | [⬇️](https://arxiv.org/pdf/2310.09233)
*Junjie Zhang, Yupeng Hou, Ruobing Xie, Wenqi Sun, Julian McAuley,  Wayne Xin Zhao, Leyu Lin, Ji-Rong Wen* 

  Recently, there has been an emergence of employing LLM-powered agents as
believable human proxies, based on their remarkable decision-making capability.
However, existing studies mainly focus on simulating human dialogue. Human
non-verbal behaviors, such as item clicking in recommender systems, although
implicitly exhibiting user preferences and could enhance the modeling of users,
have not been deeply explored. The main reasons lie in the gap between language
modeling and behavior modeling, as well as the incomprehension of LLMs about
user-item relations.
  To address this issue, we propose AgentCF for simulating user-item
interactions in recommender systems through agent-based collaborative
filtering. We creatively consider not only users but also items as agents, and
develop a collaborative learning approach that optimizes both kinds of agents
together. Specifically, at each time step, we first prompt the user and item
agents to interact autonomously. Then, based on the disparities between the
agents' decisions and real-world interaction records, user and item agents are
prompted to reflect on and adjust the misleading simulations collaboratively,
thereby modeling their two-sided relations. The optimized agents can also
propagate their preferences to other agents in subsequent interactions,
implicitly capturing the collaborative filtering idea. Overall, the optimized
agents exhibit diverse interaction behaviors within our framework, including
user-item, user-user, item-item, and collective interactions. The results show
that these agents can demonstrate personalized behaviors akin to those of
real-world individuals, sparking the development of next-generation user
behavior simulation.

---------------

### 06 Mar 2024 | [KIWI: A Dataset of Knowledge-Intensive Writing Instructions for  Answering Research Questions](https://arxiv.org/abs/2403.03866) | [⬇️](https://arxiv.org/pdf/2403.03866)
*Fangyuan Xu, Kyle Lo, Luca Soldaini, Bailey Kuehl, Eunsol Choi, David  Wadden* 

  Large language models (LLMs) adapted to follow user instructions are now
widely deployed as conversational agents. In this work, we examine one
increasingly common instruction-following task: providing writing assistance to
compose a long-form answer. To evaluate the capabilities of current LLMs on
this task, we construct KIWI, a dataset of knowledge-intensive writing
instructions in the scientific domain. Given a research question, an initial
model-generated answer and a set of relevant papers, an expert annotator
iteratively issues instructions for the model to revise and improve its answer.
We collect 1,260 interaction turns from 234 interaction sessions with three
state-of-the-art LLMs. Each turn includes a user instruction, a model response,
and a human evaluation of the model response. Through a detailed analysis of
the collected responses, we find that all models struggle to incorporate new
information into an existing answer, and to perform precise and unambiguous
edits. Further, we find that models struggle to judge whether their outputs
successfully followed user instructions, with accuracy at least 10 points short
of human agreement. Our findings indicate that KIWI will be a valuable resource
to measure progress and improve LLMs' instruction-following capabilities for
knowledge intensive writing tasks.

---------------

### 09 Feb 2024 | [Exploring Interaction Patterns for Debugging: Enhancing Conversational  Capabilities of AI-assistants](https://arxiv.org/abs/2402.06229) | [⬇️](https://arxiv.org/pdf/2402.06229)
*Bhavya Chopra, Yasharth Bajpai, Param Biyani, Gustavo Soares, Arjun  Radhakrishna, Chris Parnin, Sumit Gulwani* 

  The widespread availability of Large Language Models (LLMs) within Integrated
Development Environments (IDEs) has led to their speedy adoption.
Conversational interactions with LLMs enable programmers to obtain natural
language explanations for various software development tasks. However, LLMs
often leap to action without sufficient context, giving rise to implicit
assumptions and inaccurate responses. Conversations between developers and LLMs
are primarily structured as question-answer pairs, where the developer is
responsible for asking the the right questions and sustaining conversations
across multiple turns. In this paper, we draw inspiration from interaction
patterns and conversation analysis -- to design Robin, an enhanced
conversational AI-assistant for debugging. Through a within-subjects user study
with 12 industry professionals, we find that equipping the LLM to -- (1)
leverage the insert expansion interaction pattern, (2) facilitate turn-taking,
and (3) utilize debugging workflows -- leads to lowered conversation barriers,
effective fault localization, and 5x improvement in bug resolution rates.

---------------

### 02 Nov 2023 | [Incremental Learning of Humanoid Robot Behavior from Natural Interaction  and Large Language Models](https://arxiv.org/abs/2309.04316) | [⬇️](https://arxiv.org/pdf/2309.04316)
*Leonard B\"armann, Rainer Kartmann, Fabian Peller-Konrad, Alex Waibel,  Tamim Asfour* 

  Natural-language dialog is key for intuitive human-robot interaction. It can
be used not only to express humans' intents, but also to communicate
instructions for improvement if a robot does not understand a command
correctly. Of great importance is to endow robots with the ability to learn
from such interaction experience in an incremental way to allow them to improve
their behaviors or avoid mistakes in the future. In this paper, we propose a
system to achieve incremental learning of complex behavior from natural
interaction, and demonstrate its implementation on a humanoid robot. Building
on recent advances, we present a system that deploys Large Language Models
(LLMs) for high-level orchestration of the robot's behavior, based on the idea
of enabling the LLM to generate Python statements in an interactive console to
invoke both robot perception and action. The interaction loop is closed by
feeding back human instructions, environment observations, and execution
results to the LLM, thus informing the generation of the next statement.
Specifically, we introduce incremental prompt learning, which enables the
system to interactively learn from its mistakes. For that purpose, the LLM can
call another LLM responsible for code-level improvements of the current
interaction based on human feedback. The improved interaction is then saved in
the robot's memory, and thus retrieved on similar requests. We integrate the
system in the robot cognitive architecture of the humanoid robot ARMAR-6 and
evaluate our methods both quantitatively (in simulation) and qualitatively (in
simulation and real-world) by demonstrating generalized incrementally-learned
knowledge.

---------------

### 06 Feb 2024 | [Empowering Language Models with Active Inquiry for Deeper Understanding](https://arxiv.org/abs/2402.03719) | [⬇️](https://arxiv.org/pdf/2402.03719)
*Jing-Cheng Pang, Heng-Bo Fan, Pengyuan Wang, Jia-Hao Xiao, Nan Tang,  Si-Hang Yang, Chengxing Jia, Sheng-Jun Huang, Yang Yu* 

  The rise of large language models (LLMs) has revolutionized the way that we
interact with artificial intelligence systems through natural language.
However, LLMs often misinterpret user queries because of their uncertain
intention, leading to less helpful responses. In natural human interactions,
clarification is sought through targeted questioning to uncover obscure
information. Thus, in this paper, we introduce LaMAI (Language Model with
Active Inquiry), designed to endow LLMs with this same level of interactive
engagement. LaMAI leverages active learning techniques to raise the most
informative questions, fostering a dynamic bidirectional dialogue. This
approach not only narrows the contextual gap but also refines the output of the
LLMs, aligning it more closely with user expectations. Our empirical studies,
across a variety of complex datasets where LLMs have limited conversational
context, demonstrate the effectiveness of LaMAI. The method improves answer
accuracy from 31.9% to 50.9%, outperforming other leading question-answering
frameworks. Moreover, in scenarios involving human participants, LaMAI
consistently generates responses that are superior or comparable to baseline
methods in more than 82% of the cases. The applicability of LaMAI is further
evidenced by its successful integration with various LLMs, highlighting its
potential for the future of interactive language models.

---------------

### 17 Sep 2023 | [Unified Human-Scene Interaction via Prompted Chain-of-Contacts](https://arxiv.org/abs/2309.07918) | [⬇️](https://arxiv.org/pdf/2309.07918)
*Zeqi Xiao, Tai Wang, Jingbo Wang, Jinkun Cao, Wenwei Zhang, Bo Dai,  Dahua Lin, Jiangmiao Pang* 

  Human-Scene Interaction (HSI) is a vital component of fields like embodied AI
and virtual reality. Despite advancements in motion quality and physical
plausibility, two pivotal factors, versatile interaction control and the
development of a user-friendly interface, require further exploration before
the practical application of HSI. This paper presents a unified HSI framework,
UniHSI, which supports unified control of diverse interactions through language
commands. This framework is built upon the definition of interaction as Chain
of Contacts (CoC): steps of human joint-object part pairs, which is inspired by
the strong correlation between interaction types and human-object contact
regions. Based on the definition, UniHSI constitutes a Large Language Model
(LLM) Planner to translate language prompts into task plans in the form of CoC,
and a Unified Controller that turns CoC into uniform task execution. To
facilitate training and evaluation, we collect a new dataset named ScenePlan
that encompasses thousands of task plans generated by LLMs based on diverse
scenarios. Comprehensive experiments demonstrate the effectiveness of our
framework in versatile task execution and generalizability to real scanned
scenes. The project page is at https://github.com/OpenRobotLab/UniHSI .

---------------

### 29 Jan 2024 | ["You tell me": A Dataset of GPT-4-Based Behaviour Change Support  Conversations](https://arxiv.org/abs/2401.16167) | [⬇️](https://arxiv.org/pdf/2401.16167)
*Selina Meyer and David Elsweiler* 

  Conversational agents are increasingly used to address emotional needs on top
of information needs. One use case of increasing interest are counselling-style
mental health and behaviour change interventions, with large language model
(LLM)-based approaches becoming more popular. Research in this context so far
has been largely system-focused, foregoing the aspect of user behaviour and the
impact this can have on LLM-generated texts. To address this issue, we share a
dataset containing text-based user interactions related to behaviour change
with two GPT-4-based conversational agents collected in a preregistered user
study. This dataset includes conversation data, user language analysis,
perception measures, and user feedback for LLM-generated turns, and can offer
valuable insights to inform the design of such systems based on real
interactions.

---------------

### 07 Nov 2023 | [Detecting Any Human-Object Interaction Relationship: Universal HOI  Detector with Spatial Prompt Learning on Foundation Models](https://arxiv.org/abs/2311.03799) | [⬇️](https://arxiv.org/pdf/2311.03799)
*Yichao Cao, Qingfei Tang, Xiu Su, Chen Song, Shan You, Xiaobo Lu,  Chang Xu* 

  Human-object interaction (HOI) detection aims to comprehend the intricate
relationships between humans and objects, predicting $<human, action, object>$
triplets, and serving as the foundation for numerous computer vision tasks. The
complexity and diversity of human-object interactions in the real world,
however, pose significant challenges for both annotation and recognition,
particularly in recognizing interactions within an open world context. This
study explores the universal interaction recognition in an open-world setting
through the use of Vision-Language (VL) foundation models and large language
models (LLMs). The proposed method is dubbed as \emph{\textbf{UniHOI}}. We
conduct a deep analysis of the three hierarchical features inherent in visual
HOI detectors and propose a method for high-level relation extraction aimed at
VL foundation models, which we call HO prompt-based learning. Our design
includes an HO Prompt-guided Decoder (HOPD), facilitates the association of
high-level relation representations in the foundation model with various HO
pairs within the image. Furthermore, we utilize a LLM (\emph{i.e.} GPT) for
interaction interpretation, generating a richer linguistic understanding for
complex HOIs. For open-category interaction recognition, our method supports
either of two input types: interaction phrase or interpretive sentence. Our
efficient architecture design and learning methods effectively unleash the
potential of the VL foundation models and LLMs, allowing UniHOI to surpass all
existing methods with a substantial margin, under both supervised and zero-shot
settings. The code and pre-trained weights are available at:
\url{https://github.com/Caoyichao/UniHOI}.

---------------

### 23 Feb 2024 | [On the Multi-turn Instruction Following for Conversational Web Agents](https://arxiv.org/abs/2402.15057) | [⬇️](https://arxiv.org/pdf/2402.15057)
*Yang Deng, Xuan Zhang, Wenxuan Zhang, Yifei Yuan, See-Kiong Ng,  Tat-Seng Chua* 

  Web agents powered by Large Language Models (LLMs) have demonstrated
remarkable abilities in planning and executing multi-step interactions within
complex web-based environments, fulfilling a wide range of web navigation
tasks. Despite these advancements, the potential for LLM-powered agents to
effectively engage with sequential user instructions in real-world scenarios
has not been fully explored. In this work, we introduce a new task of
Conversational Web Navigation, which necessitates sophisticated interactions
that span multiple turns with both the users and the environment, supported by
a specially developed dataset named Multi-Turn Mind2Web (MT-Mind2Web). To
tackle the limited context length of LLMs and the context-dependency issue of
the conversational tasks, we further propose a novel framework, named
self-reflective memory-augmented planning (Self-MAP), which employs memory
utilization and self-reflection techniques. Extensive experiments are conducted
to benchmark the MT-Mind2Web dataset, and validate the effectiveness of the
proposed method.

---------------

### 23 Dec 2023 | [User Modeling in the Era of Large Language Models: Current Research and  Future Directions](https://arxiv.org/abs/2312.11518) | [⬇️](https://arxiv.org/pdf/2312.11518)
*Zhaoxuan Tan, Meng Jiang* 

  User modeling (UM) aims to discover patterns or learn representations from
user data about the characteristics of a specific user, such as profile,
preference, and personality. The user models enable personalization and
suspiciousness detection in many online applications such as recommendation,
education, and healthcare. Two common types of user data are text and graph, as
the data usually contain a large amount of user-generated content (UGC) and
online interactions. The research of text and graph mining is developing
rapidly, contributing many notable solutions in the past two decades. Recently,
large language models (LLMs) have shown superior performance on generating,
understanding, and even reasoning over text data. The approaches of user
modeling have been equipped with LLMs and soon become outstanding. This article
summarizes existing research about how and why LLMs are great tools of modeling
and understanding UGC. Then it reviews a few categories of large language
models for user modeling (LLM-UM) approaches that integrate the LLMs with text
and graph-based methods in different ways. Then it introduces specific LLM-UM
techniques for a variety of UM applications. Finally, it presents remaining
challenges and future directions in the LLM-UM research. We maintain the
reading list at: https://github.com/TamSiuhin/LLM-UM-Reading

---------------

### 29 Nov 2023 | [ChatIllusion: Efficient-Aligning Interleaved Generation ability with  Visual Instruction Model](https://arxiv.org/abs/2311.17963) | [⬇️](https://arxiv.org/pdf/2311.17963)
*Xiaowei Chi, Yijiang Liu, Zhengkai Jiang, Rongyu Zhang, Ziyi Lin,  Renrui Zhang, Peng Gao, Chaoyou Fu, Shanghang Zhang, Qifeng Liu, Yike Guo* 

  As the capabilities of Large-Language Models (LLMs) become widely recognized,
there is an increasing demand for human-machine chat applications. Human
interaction with text often inherently invokes mental imagery, an aspect that
existing LLM-based chatbots like GPT-4 do not currently emulate, as they are
confined to generating text-only content. To bridge this gap, we introduce
ChatIllusion, an advanced Generative multimodal large language model (MLLM)
that combines the capabilities of LLM with not only visual comprehension but
also creativity. Specifically, ChatIllusion integrates Stable Diffusion XL and
Llama, which have been fine-tuned on modest image-caption data, to facilitate
multiple rounds of illustrated chats. The central component of ChatIllusion is
the "GenAdapter," an efficient approach that equips the multimodal language
model with capabilities for visual representation, without necessitating
modifications to the foundational model. Extensive experiments validate the
efficacy of our approach, showcasing its ability to produce diverse and
superior-quality image outputs Simultaneously, it preserves semantic
consistency and control over the dialogue, significantly enhancing the overall
user's quality of experience (QoE). The code is available at
https://github.com/litwellchi/ChatIllusion.

---------------

### 02 Feb 2024 | [A Multi-Agent Conversational Recommender System](https://arxiv.org/abs/2402.01135) | [⬇️](https://arxiv.org/pdf/2402.01135)
*Jiabao Fang, Shen Gao, Pengjie Ren, Xiuying Chen, Suzan Verberne,  Zhaochun Ren* 

  Due to strong capabilities in conducting fluent, multi-turn conversations
with users, Large Language Models (LLMs) have the potential to further improve
the performance of Conversational Recommender System (CRS). Unlike the aimless
chit-chat that LLM excels at, CRS has a clear target. So it is imperative to
control the dialogue flow in the LLM to successfully recommend appropriate
items to the users. Furthermore, user feedback in CRS can assist the system in
better modeling user preferences, which has been ignored by existing studies.
However, simply prompting LLM to conduct conversational recommendation cannot
address the above two key challenges.
  In this paper, we propose Multi-Agent Conversational Recommender System
(MACRS) which contains two essential modules. First, we design a multi-agent
act planning framework, which can control the dialogue flow based on four
LLM-based agents. This cooperative multi-agent framework will generate various
candidate responses based on different dialogue acts and then choose the most
appropriate response as the system response, which can help MACRS plan suitable
dialogue acts. Second, we propose a user feedback-aware reflection mechanism
which leverages user feedback to reason errors made in previous turns to adjust
the dialogue act planning, and higher-level user information from implicit
semantics. We conduct extensive experiments based on user simulator to
demonstrate the effectiveness of MACRS in recommendation and user preferences
collection. Experimental results illustrate that MACRS demonstrates an
improvement in user interaction experience compared to directly using LLMs.

---------------
**Date:** 21 Feb 2024

**Title:** User-LLM: Efficient LLM Contextualization with User Embeddings

**Abstract Link:** [https://arxiv.org/abs/2402.13598](https://arxiv.org/abs/2402.13598)

**PDF Link:** [https://arxiv.org/pdf/2402.13598](https://arxiv.org/pdf/2402.13598)

---

**Date:** 24 Feb 2024

**Title:** Mobile-Env: An Evaluation Platform and Benchmark for LLM-GUI Interaction

**Abstract Link:** [https://arxiv.org/abs/2305.08144](https://arxiv.org/abs/2305.08144)

**PDF Link:** [https://arxiv.org/pdf/2305.08144](https://arxiv.org/pdf/2305.08144)

---

**Date:** 20 Apr 2023

**Title:** Low-code LLM: Visual Programming over LLMs

**Abstract Link:** [https://arxiv.org/abs/2304.08103](https://arxiv.org/abs/2304.08103)

**PDF Link:** [https://arxiv.org/pdf/2304.08103](https://arxiv.org/pdf/2304.08103)

---

**Date:** 14 Nov 2023

**Title:** LatticeGen: A Cooperative Framework which Hides Generated Text in a  Lattice for Privacy-Aware Generation on Cloud

**Abstract Link:** [https://arxiv.org/abs/2309.17157](https://arxiv.org/abs/2309.17157)

**PDF Link:** [https://arxiv.org/pdf/2309.17157](https://arxiv.org/pdf/2309.17157)

---

**Date:** 06 Jan 2024

**Title:** Understanding Large-Language Model (LLM)-powered Human-Robot Interaction

**Abstract Link:** [https://arxiv.org/abs/2401.03217](https://arxiv.org/abs/2401.03217)

**PDF Link:** [https://arxiv.org/pdf/2401.03217](https://arxiv.org/pdf/2401.03217)

---

**Date:** 22 Dec 2023

**Title:** MetaAID 2.5: A Secure Framework for Developing Metaverse Applications  via Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2312.14480](https://arxiv.org/abs/2312.14480)

**PDF Link:** [https://arxiv.org/pdf/2312.14480](https://arxiv.org/pdf/2312.14480)

---

**Date:** 01 Dec 2023

**Title:** Beyond ChatBots: ExploreLLM for Structured Thoughts and Personalized  Model Responses

**Abstract Link:** [https://arxiv.org/abs/2312.00763](https://arxiv.org/abs/2312.00763)

**PDF Link:** [https://arxiv.org/pdf/2312.00763](https://arxiv.org/pdf/2312.00763)

---

**Date:** 10 May 2023

**Title:** Do LLMs Understand User Preferences? Evaluating LLMs On User Rating  Prediction

**Abstract Link:** [https://arxiv.org/abs/2305.06474](https://arxiv.org/abs/2305.06474)

**PDF Link:** [https://arxiv.org/pdf/2305.06474](https://arxiv.org/pdf/2305.06474)

---

**Date:** 13 Oct 2023

**Title:** AgentCF: Collaborative Learning with Autonomous Language Agents for  Recommender Systems

**Abstract Link:** [https://arxiv.org/abs/2310.09233](https://arxiv.org/abs/2310.09233)

**PDF Link:** [https://arxiv.org/pdf/2310.09233](https://arxiv.org/pdf/2310.09233)

---

**Date:** 06 Mar 2024

**Title:** KIWI: A Dataset of Knowledge-Intensive Writing Instructions for  Answering Research Questions

**Abstract Link:** [https://arxiv.org/abs/2403.03866](https://arxiv.org/abs/2403.03866)

**PDF Link:** [https://arxiv.org/pdf/2403.03866](https://arxiv.org/pdf/2403.03866)

---

**Date:** 09 Feb 2024

**Title:** Exploring Interaction Patterns for Debugging: Enhancing Conversational  Capabilities of AI-assistants

**Abstract Link:** [https://arxiv.org/abs/2402.06229](https://arxiv.org/abs/2402.06229)

**PDF Link:** [https://arxiv.org/pdf/2402.06229](https://arxiv.org/pdf/2402.06229)

---

**Date:** 02 Nov 2023

**Title:** Incremental Learning of Humanoid Robot Behavior from Natural Interaction  and Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2309.04316](https://arxiv.org/abs/2309.04316)

**PDF Link:** [https://arxiv.org/pdf/2309.04316](https://arxiv.org/pdf/2309.04316)

---

**Date:** 06 Feb 2024

**Title:** Empowering Language Models with Active Inquiry for Deeper Understanding

**Abstract Link:** [https://arxiv.org/abs/2402.03719](https://arxiv.org/abs/2402.03719)

**PDF Link:** [https://arxiv.org/pdf/2402.03719](https://arxiv.org/pdf/2402.03719)

---

**Date:** 17 Sep 2023

**Title:** Unified Human-Scene Interaction via Prompted Chain-of-Contacts

**Abstract Link:** [https://arxiv.org/abs/2309.07918](https://arxiv.org/abs/2309.07918)

**PDF Link:** [https://arxiv.org/pdf/2309.07918](https://arxiv.org/pdf/2309.07918)

---

**Date:** 29 Jan 2024

**Title:** "You tell me": A Dataset of GPT-4-Based Behaviour Change Support  Conversations

**Abstract Link:** [https://arxiv.org/abs/2401.16167](https://arxiv.org/abs/2401.16167)

**PDF Link:** [https://arxiv.org/pdf/2401.16167](https://arxiv.org/pdf/2401.16167)

---

**Date:** 07 Nov 2023

**Title:** Detecting Any Human-Object Interaction Relationship: Universal HOI  Detector with Spatial Prompt Learning on Foundation Models

**Abstract Link:** [https://arxiv.org/abs/2311.03799](https://arxiv.org/abs/2311.03799)

**PDF Link:** [https://arxiv.org/pdf/2311.03799](https://arxiv.org/pdf/2311.03799)

---

**Date:** 23 Feb 2024

**Title:** On the Multi-turn Instruction Following for Conversational Web Agents

**Abstract Link:** [https://arxiv.org/abs/2402.15057](https://arxiv.org/abs/2402.15057)

**PDF Link:** [https://arxiv.org/pdf/2402.15057](https://arxiv.org/pdf/2402.15057)

---

**Date:** 23 Dec 2023

**Title:** User Modeling in the Era of Large Language Models: Current Research and  Future Directions

**Abstract Link:** [https://arxiv.org/abs/2312.11518](https://arxiv.org/abs/2312.11518)

**PDF Link:** [https://arxiv.org/pdf/2312.11518](https://arxiv.org/pdf/2312.11518)

---

**Date:** 29 Nov 2023

**Title:** ChatIllusion: Efficient-Aligning Interleaved Generation ability with  Visual Instruction Model

**Abstract Link:** [https://arxiv.org/abs/2311.17963](https://arxiv.org/abs/2311.17963)

**PDF Link:** [https://arxiv.org/pdf/2311.17963](https://arxiv.org/pdf/2311.17963)

---

**Date:** 02 Feb 2024

**Title:** A Multi-Agent Conversational Recommender System

**Abstract Link:** [https://arxiv.org/abs/2402.01135](https://arxiv.org/abs/2402.01135)

**PDF Link:** [https://arxiv.org/pdf/2402.01135](https://arxiv.org/pdf/2402.01135)

---

