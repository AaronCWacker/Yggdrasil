Transformer Attention Analysis 🎪

### 🔎 Transformer Attention Analysis 🎪


=================================

This is a simple tool to analyze the attention weights of a transformer model.

![Attention Analysis](https://github.com/juliusfriedrich/transformer-attention-analysis/blob/main/images/attention_analysis.gif)


Installation
------------

```bash
pip install transformer-attention-analysis
```

Usage
-----

```python
from transformer_attention_analysis import AttentionAnalysis

# Initialize the attention analysis tool
analysis = AttentionAnalysis(model, tokenizer)

# Analyze the attention weights of a sentence
analysis.analyze("The quick brown fox jumps over the lazy dog.")

# Visualize the attention weights
analysis.visualize()
```


License
-------

MIT


Citation
--------

If you use this tool in your research, please cite it as follows:

```bibtex
@misc{transformer_attention_analysis,
  author = {Julius Friedrich},
  title = {Transformer Attention Analysis},
  year = {2022},
  publisher = {GitHub},
  journal = {GitHub repository},
  howpublished = {\url{https://github.com/juliusfriedrich/transformer-attention-analysis}},
}
```</s>
# 🩺🔍 Search Results
### 18 Jun 2019 | [Analyzing the Structure of Attention in a Transformer Language Model](https://arxiv.org/abs/1906.04284) | [⬇️](https://arxiv.org/pdf/1906.04284)
*Jesse Vig and Yonatan Belinkov* 

  The Transformer is a fully attention-based alternative to recurrent networks
that has achieved state-of-the-art results across a range of NLP tasks. In this
paper, we analyze the structure of attention in a Transformer language model,
the GPT-2 small pretrained model. We visualize attention for individual
instances and analyze the interaction between attention and syntax over a large
corpus. We find that attention targets different parts of speech at different
layer depths within the model, and that attention aligns with dependency
relations most strongly in the middle layers. We also find that the deepest
layers of the model capture the most distant relationships. Finally, we extract
exemplar sentences that reveal highly specific patterns targeted by particular
attention heads.

---------------

### 06 Mar 2024 | [Structure-Preserving Transformers for Sequences of SPD Matrices](https://arxiv.org/abs/2309.07579) | [⬇️](https://arxiv.org/pdf/2309.07579)
*Mathieu Seraphim, Alexis Lechervy, Florian Yger, Luc Brun and Olivier  Etard* 

  In recent years, Transformer-based auto-attention mechanisms have been
successfully applied to the analysis of a variety of context-reliant data
types, from texts to images and beyond, including data from non-Euclidean
geometries. In this paper, we present such a mechanism, designed to classify
sequences of Symmetric Positive Definite matrices while preserving their
Riemannian geometry throughout the analysis. We apply our method to automatic
sleep staging on timeseries of EEG-derived covariance matrices from a standard
dataset, obtaining high levels of stage-wise performance.

---------------

### 01 Jul 2021 | [SparseBERT: Rethinking the Importance Analysis in Self-attention](https://arxiv.org/abs/2102.12871) | [⬇️](https://arxiv.org/pdf/2102.12871)
*Han Shi, Jiahui Gao, Xiaozhe Ren, Hang Xu, Xiaodan Liang, Zhenguo Li,  James T. Kwok* 

  Transformer-based models are popularly used in natural language processing
(NLP). Its core component, self-attention, has aroused widespread interest. To
understand the self-attention mechanism, a direct method is to visualize the
attention map of a pre-trained model. Based on the patterns observed, a series
of efficient Transformers with different sparse attention masks have been
proposed. From a theoretical perspective, universal approximability of
Transformer-based models is also recently proved. However, the above
understanding and analysis of self-attention is based on a pre-trained model.
To rethink the importance analysis in self-attention, we study the significance
of different positions in attention matrix during pre-training. A surprising
result is that diagonal elements in the attention map are the least important
compared with other attention positions. We provide a proof showing that these
diagonal elements can indeed be removed without deteriorating model
performance. Furthermore, we propose a Differentiable Attention Mask (DAM)
algorithm, which further guides the design of the SparseBERT. Extensive
experiments verify our interesting findings and illustrate the effect of the
proposed algorithm.

---------------

### 10 Oct 2020 | [Structured Self-Attention Weights Encode Semantics in Sentiment Analysis](https://arxiv.org/abs/2010.04922) | [⬇️](https://arxiv.org/pdf/2010.04922)
*Zhengxuan Wu, Thanh-Son Nguyen, Desmond C. Ong* 

  Neural attention, especially the self-attention made popular by the
Transformer, has become the workhorse of state-of-the-art natural language
processing (NLP) models. Very recent work suggests that the self-attention in
the Transformer encodes syntactic information; Here, we show that
self-attention scores encode semantics by considering sentiment analysis tasks.
In contrast to gradient-based feature attribution methods, we propose a simple
and effective Layer-wise Attention Tracing (LAT) method to analyze structured
attention weights. We apply our method to Transformer models trained on two
tasks that have surface dissimilarities, but share common semantics---sentiment
analysis of movie reviews and time-series valence prediction in life story
narratives. Across both tasks, words with high aggregated attention weights
were rich in emotional semantics, as quantitatively validated by an emotion
lexicon labeled by human annotators. Our results show that structured attention
weights encode rich semantics in sentiment analysis, and match human
interpretations of semantics.

---------------

### 11 Oct 2023 | [Multichannel consecutive data cross-extraction with 1DCNN-attention for  diagnosis of power transformer](https://arxiv.org/abs/2310.07323) | [⬇️](https://arxiv.org/pdf/2310.07323)
*Wei Zheng, Guogang Zhang, Chenchen Zhao, Qianqian Zhu* 

  Power transformer plays a critical role in grid infrastructure, and its
diagnosis is paramount for maintaining stable operation. However, the current
methods for transformer diagnosis focus on discrete dissolved gas analysis,
neglecting deep feature extraction of multichannel consecutive data. The
unutilized sequential data contains the significant temporal information
reflecting the transformer condition. In light of this, the structure of
multichannel consecutive data cross-extraction (MCDC) is proposed in this
article in order to comprehensively exploit the intrinsic characteristic and
evaluate the states of transformer. Moreover, for the better accommodation in
scenario of transformer diagnosis, one dimensional convolution neural network
attention (1DCNN-attention) mechanism is introduced and offers a more efficient
solution given the simplified spatial complexity. Finally, the effectiveness of
MCDC and the superior generalization ability, compared with other algorithms,
are validated in experiments conducted on a dataset collected from real
operation cases of power transformer. Additionally, the better stability of
1DCNN-attention has also been certified.

---------------

### 30 Jan 2024 | [Superiority of Multi-Head Attention in In-Context Linear Regression](https://arxiv.org/abs/2401.17426) | [⬇️](https://arxiv.org/pdf/2401.17426)
*Yingqian Cui, Jie Ren, Pengfei He, Jiliang Tang, Yue Xing* 

  We present a theoretical analysis of the performance of transformer with
softmax attention in in-context learning with linear regression tasks. While
the existing literature predominantly focuses on the convergence of
transformers with single-/multi-head attention, our research centers on
comparing their performance. We conduct an exact theoretical analysis to
demonstrate that multi-head attention with a substantial embedding dimension
performs better than single-head attention. When the number of in-context
examples D increases, the prediction loss using single-/multi-head attention is
in O(1/D), and the one for multi-head attention has a smaller multiplicative
constant. In addition to the simplest data distribution setting, we consider
more scenarios, e.g., noisy labels, local examples, correlated features, and
prior knowledge. We observe that, in general, multi-head attention is preferred
over single-head attention. Our results verify the effectiveness of the design
of multi-head attention in the transformer architecture.

---------------

### 20 Feb 2021 | [Evolving Attention with Residual Convolutions](https://arxiv.org/abs/2102.12895) | [⬇️](https://arxiv.org/pdf/2102.12895)
*Yujing Wang, Yaming Yang, Jiangang Bai, Mingliang Zhang, Jing Bai,  Jing Yu, Ce Zhang, Gao Huang, Yunhai Tong* 

  Transformer is a ubiquitous model for natural language processing and has
attracted wide attentions in computer vision. The attention maps are
indispensable for a transformer model to encode the dependencies among input
tokens. However, they are learned independently in each layer and sometimes
fail to capture precise patterns. In this paper, we propose a novel and generic
mechanism based on evolving attention to improve the performance of
transformers. On one hand, the attention maps in different layers share common
knowledge, thus the ones in preceding layers can instruct the attention in
succeeding layers through residual connections. On the other hand, low-level
and high-level attentions vary in the level of abstraction, so we adopt
convolutional layers to model the evolutionary process of attention maps. The
proposed evolving attention mechanism achieves significant performance
improvement over various state-of-the-art models for multiple tasks, including
image classification, natural language understanding and machine translation.

---------------

### 27 Feb 2023 | [Low latency transformers for speech processing](https://arxiv.org/abs/2302.13451) | [⬇️](https://arxiv.org/pdf/2302.13451)
*Jianbo Ma, Siqi Pan, Deepak Chandran, Andrea Fanelli, Richard  Cartwright* 

  The transformer is a widely-used building block in modern neural networks.
However, when applied to audio data, the transformer's acausal behaviour, which
we term Acausal Attention (AA), has generally limited its application to
offline tasks. In this paper we introduce Streaming Attention (SA), which
operates causally with fixed latency, and requires lower compute and memory
resources than AA to train. Next, we introduce Low Latency Streaming Attention
(LLSA), a method which combines multiple SA layers without latency build-up
proportional to the layer count. Comparative analysis between AA, SA and LLSA
on Automatic Speech Recognition (ASR) and Speech Emotion Recognition (SER)
tasks are presented. The results show that causal SA-based networks with fixed
latencies of a few seconds (e.g. 1.8 seconds) and LLSA networks with latencies
as short as 300 ms can perform comparably with acausal (AA) networks. We
conclude that SA and LLSA methods retain many of the benefits of conventional
acausal transformers, but with latency characteristics that make them practical
to run in real-time streaming applications.

---------------

### 03 Mar 2024 | [From Interpolation to Extrapolation: Complete Length Generalization for  Arithmetic Transformers](https://arxiv.org/abs/2310.11984) | [⬇️](https://arxiv.org/pdf/2310.11984)
*Shaoxiong Duan, Yining Shi, Wei Xu* 

  In this paper, we investigate the inherent capabilities of transformer models
in learning arithmetic algorithms, such as addition and parity. Through
experiments and attention analysis, we identify a number of crucial factors for
achieving optimal length generalization. We show that transformer models are
able to generalize to long lengths with the help of targeted attention biasing.
In particular, our solution solves the Parity task, a well-known and
theoretically proven failure mode for Transformers. We then introduce Attention
Bias Calibration (ABC), a calibration stage that enables the model to
automatically learn the proper attention biases, which we show to be connected
to mechanisms in relative position encoding. We demonstrate that using ABC, the
transformer model can achieve unprecedented near-perfect length generalization
on certain arithmetic tasks. Our code is available at https:
//github.com/shaoxiongduan/AttentionBiasCalibration.

---------------

### 15 Sep 2021 | [Incorporating Residual and Normalization Layers into Analysis of Masked  Language Models](https://arxiv.org/abs/2109.07152) | [⬇️](https://arxiv.org/pdf/2109.07152)
*Goro Kobayashi, Tatsuki Kuribayashi, Sho Yokoi, Kentaro Inui* 

  Transformer architecture has become ubiquitous in the natural language
processing field. To interpret the Transformer-based models, their attention
patterns have been extensively analyzed. However, the Transformer architecture
is not only composed of the multi-head attention; other components can also
contribute to Transformers' progressive performance. In this study, we extended
the scope of the analysis of Transformers from solely the attention patterns to
the whole attention block, i.e., multi-head attention, residual connection, and
layer normalization. Our analysis of Transformer-based masked language models
shows that the token-to-token interaction performed via attention has less
impact on the intermediate representations than previously assumed. These
results provide new intuitive explanations of existing reports; for example,
discarding the learned attention patterns tends not to adversely affect the
performance. The codes of our experiments are publicly available.

---------------

### 27 Jun 2022 | [Kernel Attention Transformer (KAT) for Histopathology Whole Slide Image  Classification](https://arxiv.org/abs/2206.13156) | [⬇️](https://arxiv.org/pdf/2206.13156)
*Yushan Zheng, Jun Li, Jun Shi, Fengying Xie, Zhiguo Jiang* 

  Transformer has been widely used in histopathology whole slide image (WSI)
classification for the purpose of tumor grading, prognosis analysis, etc.
However, the design of token-wise self-attention and positional embedding
strategy in the common Transformer limits the effectiveness and efficiency in
the application to gigapixel histopathology images. In this paper, we propose a
kernel attention Transformer (KAT) for histopathology WSI classification. The
information transmission of the tokens is achieved by cross-attention between
the tokens and a set of kernels related to a set of positional anchors on the
WSI. Compared to the common Transformer structure, the proposed KAT can better
describe the hierarchical context information of the local regions of the WSI
and meanwhile maintains a lower computational complexity. The proposed method
was evaluated on a gastric dataset with 2040 WSIs and an endometrial dataset
with 2560 WSIs, and was compared with 6 state-of-the-art methods. The
experimental results have demonstrated the proposed KAT is effective and
efficient in the task of histopathology WSI classification and is superior to
the state-of-the-art methods. The code is available at
https://github.com/zhengyushan/kat.

---------------

### 12 Jun 2019 | [A Multiscale Visualization of Attention in the Transformer Model](https://arxiv.org/abs/1906.05714) | [⬇️](https://arxiv.org/pdf/1906.05714)
*Jesse Vig* 

  The Transformer is a sequence model that forgoes traditional recurrent
architectures in favor of a fully attention-based approach. Besides improving
performance, an advantage of using attention is that it can also help to
interpret a model by showing how the model assigns weight to different input
elements. However, the multi-layer, multi-head attention mechanism in the
Transformer model can be difficult to decipher. To make the model more
accessible, we introduce an open-source tool that visualizes attention at
multiple scales, each of which provides a unique perspective on the attention
mechanism. We demonstrate the tool on BERT and OpenAI GPT-2 and present three
example use cases: detecting model bias, locating relevant attention heads, and
linking neurons to model behavior.

---------------

### 06 Oct 2020 | [Attention is Not Only a Weight: Analyzing Transformers with Vector Norms](https://arxiv.org/abs/2004.10102) | [⬇️](https://arxiv.org/pdf/2004.10102)
*Goro Kobayashi, Tatsuki Kuribayashi, Sho Yokoi, Kentaro Inui* 

  Attention is a key component of Transformers, which have recently achieved
considerable success in natural language processing. Hence, attention is being
extensively studied to investigate various linguistic capabilities of
Transformers, focusing on analyzing the parallels between attention weights and
specific linguistic phenomena. This paper shows that attention weights alone
are only one of the two factors that determine the output of attention and
proposes a norm-based analysis that incorporates the second factor, the norm of
the transformed input vectors. The findings of our norm-based analyses of BERT
and a Transformer-based neural machine translation system include the
following: (i) contrary to previous studies, BERT pays poor attention to
special tokens, and (ii) reasonable word alignment can be extracted from
attention mechanisms of Transformer. These findings provide insights into the
inner workings of Transformers.

---------------

### 07 Nov 2022 | [How Much Does Attention Actually Attend? Questioning the Importance of  Attention in Pretrained Transformers](https://arxiv.org/abs/2211.03495) | [⬇️](https://arxiv.org/pdf/2211.03495)
*Michael Hassid, Hao Peng, Daniel Rotem, Jungo Kasai, Ivan Montero,  Noah A. Smith and Roy Schwartz* 

  The attention mechanism is considered the backbone of the widely-used
Transformer architecture. It contextualizes the input by computing
input-specific attention matrices. We find that this mechanism, while powerful
and elegant, is not as important as typically thought for pretrained language
models. We introduce PAPA, a new probing method that replaces the
input-dependent attention matrices with constant ones -- the average attention
weights over multiple inputs. We use PAPA to analyze several established
pretrained Transformers on six downstream tasks. We find that without any
input-dependent attention, all models achieve competitive performance -- an
average relative drop of only 8% from the probing baseline. Further, little or
no performance drop is observed when replacing half of the input-dependent
attention matrices with constant (input-independent) ones. Interestingly, we
show that better-performing models lose more from applying our method than
weaker models, suggesting that the utilization of the input-dependent attention
mechanism might be a factor in their success. Our results motivate research on
simpler alternatives to input-dependent attention, as well as on methods for
better utilization of this mechanism in the Transformer architecture.

---------------

### 13 Sep 2021 | [Attention Weights in Transformer NMT Fail Aligning Words Between  Sequences but Largely Explain Model Predictions](https://arxiv.org/abs/2109.05853) | [⬇️](https://arxiv.org/pdf/2109.05853)
*Javier Ferrando and Marta R. Costa-juss\`a* 

  This work proposes an extensive analysis of the Transformer architecture in
the Neural Machine Translation (NMT) setting. Focusing on the encoder-decoder
attention mechanism, we prove that attention weights systematically make
alignment errors by relying mainly on uninformative tokens from the source
sequence. However, we observe that NMT models assign attention to these tokens
to regulate the contribution in the prediction of the two contexts, the source
and the prefix of the target sequence. We provide evidence about the influence
of wrong alignments on the model behavior, demonstrating that the
encoder-decoder attention mechanism is well suited as an interpretability
method for NMT. Finally, based on our analysis, we propose methods that largely
reduce the word alignment error rate compared to standard induced alignments
from attention weights.

---------------

### 11 Nov 2019 | [Transformer Dissection: A Unified Understanding of Transformer's  Attention via the Lens of Kernel](https://arxiv.org/abs/1908.11775) | [⬇️](https://arxiv.org/pdf/1908.11775)
*Yao-Hung Hubert Tsai and Shaojie Bai and Makoto Yamada and  Louis-Philippe Morency and Ruslan Salakhutdinov* 

  Transformer is a powerful architecture that achieves superior performance on
various sequence learning tasks, including neural machine translation, language
understanding, and sequence prediction. At the core of the Transformer is the
attention mechanism, which concurrently processes all inputs in the streams. In
this paper, we present a new formulation of attention via the lens of the
kernel. To be more precise, we realize that the attention can be seen as
applying kernel smoother over the inputs with the kernel scores being the
similarities between inputs. This new formulation gives us a better way to
understand individual components of the Transformer's attention, such as the
better way to integrate the positional embedding. Another important advantage
of our kernel-based formulation is that it paves the way to a larger space of
composing Transformer's attention. As an example, we propose a new variant of
Transformer's attention which models the input as a product of symmetric
kernels. This approach achieves competitive performance to the current state of
the art model with less computation. In our experiments, we empirically study
different kernel construction strategies on two widely used tasks: neural
machine translation and sequence prediction.

---------------

### 01 Oct 2020 | [Masked Language Modeling for Proteins via Linearly Scalable Long-Context  Transformers](https://arxiv.org/abs/2006.03555) | [⬇️](https://arxiv.org/pdf/2006.03555)
*Krzysztof Choromanski, Valerii Likhosherstov, David Dohan, Xingyou  Song, Andreea Gane, Tamas Sarlos, Peter Hawkins, Jared Davis, David Belanger,  Lucy Colwell, Adrian Weller* 

  Transformer models have achieved state-of-the-art results across a diverse
range of domains. However, concern over the cost of training the attention
mechanism to learn complex dependencies between distant inputs continues to
grow. In response, solutions that exploit the structure and sparsity of the
learned attention matrix have blossomed. However, real-world applications that
involve long sequences, such as biological sequence analysis, may fall short of
meeting these assumptions, precluding exploration of these models. To address
this challenge, we present a new Transformer architecture, Performer, based on
Fast Attention Via Orthogonal Random features (FAVOR). Our mechanism scales
linearly rather than quadratically in the number of tokens in the sequence, is
characterized by sub-quadratic space complexity and does not incorporate any
sparsity pattern priors. Furthermore, it provides strong theoretical
guarantees: unbiased estimation of the attention matrix and uniform
convergence. It is also backwards-compatible with pre-trained regular
Transformers. We demonstrate its effectiveness on the challenging task of
protein sequence modeling and provide detailed theoretical analysis.

---------------

### 29 Jan 2023 | [Exploring Attention Map Reuse for Efficient Transformer Neural Networks](https://arxiv.org/abs/2301.12444) | [⬇️](https://arxiv.org/pdf/2301.12444)
*Kyuhong Shim, Jungwook Choi, Wonyong Sung* 

  Transformer-based deep neural networks have achieved great success in various
sequence applications due to their powerful ability to model long-range
dependency. The key module of Transformer is self-attention (SA) which extracts
features from the entire sequence regardless of the distance between positions.
Although SA helps Transformer performs particularly well on long-range tasks,
SA requires quadratic computation and memory complexity with the input sequence
length. Recently, attention map reuse, which groups multiple SA layers to share
one attention map, has been proposed and achieved significant speedup for
speech recognition models. In this paper, we provide a comprehensive study on
attention map reuse focusing on its ability to accelerate inference. We compare
the method with other SA compression techniques and conduct a breakdown
analysis of its advantages for a long sequence. We demonstrate the
effectiveness of attention map reuse by measuring the latency on both CPU and
GPU platforms.

---------------

### 31 May 2020 | [Quantifying Attention Flow in Transformers](https://arxiv.org/abs/2005.00928) | [⬇️](https://arxiv.org/pdf/2005.00928)
*Samira Abnar and Willem Zuidema* 

  In the Transformer model, "self-attention" combines information from attended
embeddings into the representation of the focal embedding in the next layer.
Thus, across layers of the Transformer, information originating from different
tokens gets increasingly mixed. This makes attention weights unreliable as
explanations probes. In this paper, we consider the problem of quantifying this
flow of information through self-attention. We propose two methods for
approximating the attention to input tokens given attention weights, attention
rollout and attention flow, as post hoc methods when we use attention weights
as the relative relevance of the input tokens. We show that these methods give
complementary views on the flow of information, and compared to raw attention,
both yield higher correlations with importance scores of input tokens obtained
using an ablation method and input gradients.

---------------

### 18 Nov 2021 | [You Only Sample (Almost) Once: Linear Cost Self-Attention Via Bernoulli  Sampling](https://arxiv.org/abs/2111.09714) | [⬇️](https://arxiv.org/pdf/2111.09714)
*Zhanpeng Zeng, Yunyang Xiong, Sathya N. Ravi, Shailesh Acharya, Glenn  Fung, Vikas Singh* 

  Transformer-based models are widely used in natural language processing
(NLP). Central to the transformer model is the self-attention mechanism, which
captures the interactions of token pairs in the input sequences and depends
quadratically on the sequence length. Training such models on longer sequences
is expensive. In this paper, we show that a Bernoulli sampling attention
mechanism based on Locality Sensitive Hashing (LSH), decreases the quadratic
complexity of such models to linear. We bypass the quadratic cost by
considering self-attention as a sum of individual tokens associated with
Bernoulli random variables that can, in principle, be sampled at once by a
single hash (although in practice, this number may be a small constant). This
leads to an efficient sampling scheme to estimate self-attention which relies
on specific modifications of LSH (to enable deployment on GPU architectures).
We evaluate our algorithm on the GLUE benchmark with standard 512 sequence
length where we see favorable performance relative to a standard pretrained
Transformer. On the Long Range Arena (LRA) benchmark, for evaluating
performance on long sequences, our method achieves results consistent with
softmax self-attention but with sizable speed-ups and memory savings and often
outperforms other efficient self-attention methods. Our code is available at
https://github.com/mlpen/YOSO

---------------
**Date:** 18 Jun 2019

**Title:** Analyzing the Structure of Attention in a Transformer Language Model

**Abstract Link:** [https://arxiv.org/abs/1906.04284](https://arxiv.org/abs/1906.04284)

**PDF Link:** [https://arxiv.org/pdf/1906.04284](https://arxiv.org/pdf/1906.04284)

---

**Date:** 06 Mar 2024

**Title:** Structure-Preserving Transformers for Sequences of SPD Matrices

**Abstract Link:** [https://arxiv.org/abs/2309.07579](https://arxiv.org/abs/2309.07579)

**PDF Link:** [https://arxiv.org/pdf/2309.07579](https://arxiv.org/pdf/2309.07579)

---

**Date:** 01 Jul 2021

**Title:** SparseBERT: Rethinking the Importance Analysis in Self-attention

**Abstract Link:** [https://arxiv.org/abs/2102.12871](https://arxiv.org/abs/2102.12871)

**PDF Link:** [https://arxiv.org/pdf/2102.12871](https://arxiv.org/pdf/2102.12871)

---

**Date:** 10 Oct 2020

**Title:** Structured Self-Attention Weights Encode Semantics in Sentiment Analysis

**Abstract Link:** [https://arxiv.org/abs/2010.04922](https://arxiv.org/abs/2010.04922)

**PDF Link:** [https://arxiv.org/pdf/2010.04922](https://arxiv.org/pdf/2010.04922)

---

**Date:** 11 Oct 2023

**Title:** Multichannel consecutive data cross-extraction with 1DCNN-attention for  diagnosis of power transformer

**Abstract Link:** [https://arxiv.org/abs/2310.07323](https://arxiv.org/abs/2310.07323)

**PDF Link:** [https://arxiv.org/pdf/2310.07323](https://arxiv.org/pdf/2310.07323)

---

**Date:** 30 Jan 2024

**Title:** Superiority of Multi-Head Attention in In-Context Linear Regression

**Abstract Link:** [https://arxiv.org/abs/2401.17426](https://arxiv.org/abs/2401.17426)

**PDF Link:** [https://arxiv.org/pdf/2401.17426](https://arxiv.org/pdf/2401.17426)

---

**Date:** 20 Feb 2021

**Title:** Evolving Attention with Residual Convolutions

**Abstract Link:** [https://arxiv.org/abs/2102.12895](https://arxiv.org/abs/2102.12895)

**PDF Link:** [https://arxiv.org/pdf/2102.12895](https://arxiv.org/pdf/2102.12895)

---

**Date:** 27 Feb 2023

**Title:** Low latency transformers for speech processing

**Abstract Link:** [https://arxiv.org/abs/2302.13451](https://arxiv.org/abs/2302.13451)

**PDF Link:** [https://arxiv.org/pdf/2302.13451](https://arxiv.org/pdf/2302.13451)

---

**Date:** 03 Mar 2024

**Title:** From Interpolation to Extrapolation: Complete Length Generalization for  Arithmetic Transformers

**Abstract Link:** [https://arxiv.org/abs/2310.11984](https://arxiv.org/abs/2310.11984)

**PDF Link:** [https://arxiv.org/pdf/2310.11984](https://arxiv.org/pdf/2310.11984)

---

**Date:** 15 Sep 2021

**Title:** Incorporating Residual and Normalization Layers into Analysis of Masked  Language Models

**Abstract Link:** [https://arxiv.org/abs/2109.07152](https://arxiv.org/abs/2109.07152)

**PDF Link:** [https://arxiv.org/pdf/2109.07152](https://arxiv.org/pdf/2109.07152)

---

**Date:** 27 Jun 2022

**Title:** Kernel Attention Transformer (KAT) for Histopathology Whole Slide Image  Classification

**Abstract Link:** [https://arxiv.org/abs/2206.13156](https://arxiv.org/abs/2206.13156)

**PDF Link:** [https://arxiv.org/pdf/2206.13156](https://arxiv.org/pdf/2206.13156)

---

**Date:** 12 Jun 2019

**Title:** A Multiscale Visualization of Attention in the Transformer Model

**Abstract Link:** [https://arxiv.org/abs/1906.05714](https://arxiv.org/abs/1906.05714)

**PDF Link:** [https://arxiv.org/pdf/1906.05714](https://arxiv.org/pdf/1906.05714)

---

**Date:** 06 Oct 2020

**Title:** Attention is Not Only a Weight: Analyzing Transformers with Vector Norms

**Abstract Link:** [https://arxiv.org/abs/2004.10102](https://arxiv.org/abs/2004.10102)

**PDF Link:** [https://arxiv.org/pdf/2004.10102](https://arxiv.org/pdf/2004.10102)

---

**Date:** 07 Nov 2022

**Title:** How Much Does Attention Actually Attend? Questioning the Importance of  Attention in Pretrained Transformers

**Abstract Link:** [https://arxiv.org/abs/2211.03495](https://arxiv.org/abs/2211.03495)

**PDF Link:** [https://arxiv.org/pdf/2211.03495](https://arxiv.org/pdf/2211.03495)

---

**Date:** 13 Sep 2021

**Title:** Attention Weights in Transformer NMT Fail Aligning Words Between  Sequences but Largely Explain Model Predictions

**Abstract Link:** [https://arxiv.org/abs/2109.05853](https://arxiv.org/abs/2109.05853)

**PDF Link:** [https://arxiv.org/pdf/2109.05853](https://arxiv.org/pdf/2109.05853)

---

**Date:** 11 Nov 2019

**Title:** Transformer Dissection: A Unified Understanding of Transformer's  Attention via the Lens of Kernel

**Abstract Link:** [https://arxiv.org/abs/1908.11775](https://arxiv.org/abs/1908.11775)

**PDF Link:** [https://arxiv.org/pdf/1908.11775](https://arxiv.org/pdf/1908.11775)

---

**Date:** 01 Oct 2020

**Title:** Masked Language Modeling for Proteins via Linearly Scalable Long-Context  Transformers

**Abstract Link:** [https://arxiv.org/abs/2006.03555](https://arxiv.org/abs/2006.03555)

**PDF Link:** [https://arxiv.org/pdf/2006.03555](https://arxiv.org/pdf/2006.03555)

---

**Date:** 29 Jan 2023

**Title:** Exploring Attention Map Reuse for Efficient Transformer Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2301.12444](https://arxiv.org/abs/2301.12444)

**PDF Link:** [https://arxiv.org/pdf/2301.12444](https://arxiv.org/pdf/2301.12444)

---

**Date:** 31 May 2020

**Title:** Quantifying Attention Flow in Transformers

**Abstract Link:** [https://arxiv.org/abs/2005.00928](https://arxiv.org/abs/2005.00928)

**PDF Link:** [https://arxiv.org/pdf/2005.00928](https://arxiv.org/pdf/2005.00928)

---

**Date:** 18 Nov 2021

**Title:** You Only Sample (Almost) Once: Linear Cost Self-Attention Via Bernoulli  Sampling

**Abstract Link:** [https://arxiv.org/abs/2111.09714](https://arxiv.org/abs/2111.09714)

**PDF Link:** [https://arxiv.org/pdf/2111.09714](https://arxiv.org/pdf/2111.09714)

---

