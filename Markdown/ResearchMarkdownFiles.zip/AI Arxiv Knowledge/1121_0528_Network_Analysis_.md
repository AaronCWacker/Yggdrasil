Network Analysis 🕵️

### 🔎 Network Analysis 🕵️

‍♀️

Network analysis is a method of analyzing the structure of a network, which is a set of nodes (also called vertices) and links (also called edges) between them. Network analysis can be used to understand the patterns of connections and interactions within a network, and to identify key nodes or clusters of nodes.

There are several different approaches to network analysis, including:

1. Descriptive statistics: This involves calculating various measures of the network's structure, such as the number of nodes and links, the density of links, the average degree of nodes, and the clustering coefficient.
2. Centrality measures: These are measures of the importance or influence of individual nodes within the network. Common centrality measures include degree centrality (the number of links a node has), betweenness centrality (the extent to which a node lies on the shortest paths between other nodes), and eigenvector centrality (the extent to which a node is connected to other nodes that are themselves well-connected).
3. Community detection: This involves identifying clusters or groups of nodes that are more closely connected to each other than to the rest of the network. There are several different algorithms for community detection, including modularity maximization, hierarchical clustering, and spectral clustering.
4. Graph partitioning: This involves dividing the network into smaller subgraphs or components, with the goal of minimizing the number of links between the subgraphs and maximizing the number of links within the subgraphs.
5. Network evolution: This involves studying how networks change over time, including the addition or removal of nodes and links, and the dynamics of node and link formation.

Network analysis can be applied to a wide range of domains, including social networks, biological networks, transportation networks, and the World Wide Web. It is a powerful tool for understanding the structure and behavior of complex systems.</s>
# 🩺🔍 Search Results
### 05 Feb 2021 | [Social Network Analysis: From Graph Theory to Applications with Python](https://arxiv.org/abs/2102.10014) | [⬇️](https://arxiv.org/pdf/2102.10014)
*Dmitri Goldenberg* 

  Social network analysis is the process of investigating social structures
through the use of networks and graph theory. It combines a variety of
techniques for analyzing the structure of social networks as well as theories
that aim at explaining the underlying dynamics and patterns observed in these
structures. It is an inherently interdisciplinary field which originally
emerged from the fields of social psychology, statistics and graph theory. This
talk will covers the theory of social network analysis, with a short
introduction to graph theory and information spread. Then we will deep dive
into Python code with NetworkX to get a better understanding of the network
components, followed-up by constructing and implying social networks from real
Pandas and textual datasets. Finally we will go over code examples of practical
use-cases such as visualization with matplotlib, social-centrality analysis and
influence maximization for information spread.

---------------

### 14 Feb 2024 | [A Semantic Social Network Analysis Tool for Sensitivity Analysis and  What-If Scenario Testing in Alcohol Consumption Studies](https://arxiv.org/abs/2402.12390) | [⬇️](https://arxiv.org/pdf/2402.12390)
*Jos\'e Alberto Ben\'itez-Andrades, Alejandro Rodr\'iguez-Gonz\'alez,  Carmen Benavides, Leticia S\'anchez-Valde\'on and Isa\'ias Garc\'ia* 

  Social Network Analysis (SNA) is a set of techniques developed in the field
of social and behavioral sciences research, in order to characterize and study
the social relationships that are established among a set of individuals. When
building a social network for performing an SNA analysis, an initial process of
data gathering is achieved in order to extract the characteristics of the
individuals and their relationships. This is usually done by completing a
questionnaire containing different types of questions that will be later used
to obtain the SNA measures needed to perform the study. There are, then, a
great number of different possible network generating questions and also many
possibilities for mapping the responses to the corresponding characteristics
and relationships. Many variations may be introduced into these questions (the
way they are posed, the weights given to each of the responses, etc.) that may
have an effect on the resulting networks. All these different variations are
difficult to achieve manually, because the process is time-consuming and error
prone. The tool described in this paper uses semantic knowledge representation
techniques in order to facilitate this kind of sensitivity studies. The base of
the tool is a conceptual structure, called "ontology" that is able to represent
the different concepts and their definitions. The tool is compared to other
similar ones, and the advantages of the approach are highlighted, giving some
particular examples from an ongoing SNA study about alcohol consumption habits
in adolescents.

---------------

### 28 Sep 2022 | [Consensus Knowledge Graph Learning via Multi-view Sparse Low Rank Block  Model](https://arxiv.org/abs/2209.13762) | [⬇️](https://arxiv.org/pdf/2209.13762)
*Tianxi Cai, Dong Xia, Luwan Zhang and Doudou Zhou* 

  Network analysis has been a powerful tool to unveil relationships and
interactions among a large number of objects. Yet its effectiveness in
accurately identifying important node-node interactions is challenged by the
rapidly growing network size, with data being collected at an unprecedented
granularity and scale. Common wisdom to overcome such high dimensionality is
collapsing nodes into smaller groups and conducting connectivity analysis on
the group level. Dividing efforts into two phases inevitably opens a gap in
consistency and drives down efficiency. Consensus learning emerges as a new
normal for common knowledge discovery with multiple data sources available. To
this end, this paper features developing a unified framework of simultaneous
grouping and connectivity analysis by combining multiple data sources. The
algorithm also guarantees a statistically optimal estimator.

---------------

### 02 Mar 2022 | [Interactive Visualization of Protein RINs using NetworKit in the Cloud](https://arxiv.org/abs/2203.01263) | [⬇️](https://arxiv.org/pdf/2203.01263)
*Eugenio Angriman, Fabian Brandt-Tumescheit, Leon Franke, Alexander van  der Grinten, Henning Meyerhenke* 

  Network analysis has been applied in diverse application domains. In this
paper, we consider an example from protein dynamics, specifically residue
interaction networks (RINs). In this context, we use NetworKit -- an
established package for network analysis -- to build a cloud-based environment
that enables domain scientists to run their visualization and analysis
workflows on large compute servers, without requiring extensive programming
and/or system administration knowledge. To demonstrate the versatility of this
approach, we use it to build a custom Jupyter-based widget for RIN
visualization. In contrast to existing RIN visualization approaches, our widget
can easily be customized through simple modifications of Python code, while
both supporting a good feature set and providing near real-time speed. It is
also easily integrated into analysis pipelines (e.g., that use Python to feed
RIN data into downstream machine learning tasks).

---------------

### 05 Jun 2021 | [Network Estimation by Mixing: Adaptivity and More](https://arxiv.org/abs/2106.02803) | [⬇️](https://arxiv.org/pdf/2106.02803)
*Tianxi Li, Can M. Le* 

  Networks analysis has been commonly used to study the interactions between
units of complex systems. One problem of particular interest is learning the
network's underlying connection pattern given a single and noisy instantiation.
While many methods have been proposed to address this problem in recent years,
they usually assume that the true model belongs to a known class, which is not
verifiable in most real-world applications. Consequently, network modeling
based on these methods either suffers from model misspecification or relies on
additional model selection procedures that are not well understood in theory
and can potentially be unstable in practice. To address this difficulty, we
propose a mixing strategy that leverages available arbitrary models to improve
their individual performances. The proposed method is computationally efficient
and almost tuning-free; thus, it can be used as an off-the-shelf method for
network modeling. We show that the proposed method performs equally well as the
oracle estimate when the true model is included as individual candidates. More
importantly, the method remains robust and outperforms all current estimates
even when the models are misspecified. Extensive simulation examples are used
to verify the advantage of the proposed mixing method. Evaluation of link
prediction performance on 385 real-world networks from six domains also
demonstrates the universal competitiveness of the mixing method across multiple
domains.

---------------

### 17 Jul 2020 | [On the Robustness of Deep Learning-predicted Contention Models for  Network Calculus](https://arxiv.org/abs/1911.10522) | [⬇️](https://arxiv.org/pdf/1911.10522)
*Fabien Geyer and Steffen Bondorf* 

  The network calculus (NC) analysis takes a simple model consisting of a
network of schedulers and data flows crossing them. A number of analysis
"building blocks" can then be applied to capture the model without imposing
pessimistic assumptions like self-contention on tandems of servers. Yet, adding
pessimism cannot always be avoided. To compute the best bound on a single
flow's end-to-end delay thus boils down to finding the least pessimistic
contention models for all tandems of schedulers in the network - and an
exhaustive search can easily become a very resource intensive task. The
literature proposes a promising solution to this dilemma: a heuristic making
use of machine learning (ML) predictions inside the NC analysis.
  While results of this work were promising in terms of delay bound quality and
computational effort, there is little to no insight on when a prediction is
made or if the trained algorithm can achieve similarly striking results in
networks vastly differing from its training data. In this paper, we address
these pending questions. We evaluate the influence of the training data and its
features on accuracy, impact and scalability. Additionally, we contribute an
extension of the method by predicting the best $n$ contention model
alternatives in order to achieve increased robustness for its application
outside the training data. Our numerical evaluation shows that good accuracy
can still be achieved on large networks although we restrict the training to
networks that are two orders of magnitude smaller.

---------------

### 02 Aug 2016 | [Size-Consistent Statistics for Anomaly Detection in Dynamic Networks](https://arxiv.org/abs/1608.00712) | [⬇️](https://arxiv.org/pdf/1608.00712)
*Timothy La Fond, Jennifer Neville, Brian Gallagher* 

  An important task in network analysis is the detection of anomalous events in
a network time series. These events could merely be times of interest in the
network timeline or they could be examples of malicious activity or network
malfunction. Hypothesis testing using network statistics to summarize the
behavior of the network provides a robust framework for the anomaly detection
decision process. Unfortunately, choosing network statistics that are dependent
on confounding factors like the total number of nodes or edges can lead to
incorrect conclusions (e.g., false positives and false negatives). In this
dissertation we describe the challenges that face anomaly detection in dynamic
network streams regarding confounding factors. We also provide two solutions to
avoiding error due to confounding factors: the first is a randomization testing
method that controls for confounding factors, and the second is a set of
size-consistent network statistics which avoid confounding due to the most
common factors, edge count and node count.

---------------

### 17 Aug 2020 | [A Visual Analytics Framework for Contrastive Network Analysis](https://arxiv.org/abs/2008.00151) | [⬇️](https://arxiv.org/pdf/2008.00151)
*Takanori Fujiwara, Jian Zhao, Francine Chen, Kwan-Liu Ma* 

  A common network analysis task is comparison of two networks to identify
unique characteristics in one network with respect to the other. For example,
when comparing protein interaction networks derived from normal and cancer
tissues, one essential task is to discover protein-protein interactions unique
to cancer tissues. However, this task is challenging when the networks contain
complex structural (and semantic) relations. To address this problem, we design
ContraNA, a visual analytics framework leveraging both the power of machine
learning for uncovering unique characteristics in networks and also the
effectiveness of visualization for understanding such uniqueness. The basis of
ContraNA is cNRL, which integrates two machine learning schemes, network
representation learning (NRL) and contrastive learning (CL), to generate a
low-dimensional embedding that reveals the uniqueness of one network when
compared to another. ContraNA provides an interactive visualization interface
to help analyze the uniqueness by relating embedding results and network
structures as well as explaining the learned features by cNRL. We demonstrate
the usefulness of ContraNA with two case studies using real-world datasets. We
also evaluate through a controlled user study with 12 participants on network
comparison tasks. The results show that participants were able to both
effectively identify unique characteristics from complex networks and interpret
the results obtained from cNRL.

---------------

### 18 Apr 2019 | [Deep Representation Learning for Social Network Analysis](https://arxiv.org/abs/1904.08547) | [⬇️](https://arxiv.org/pdf/1904.08547)
*Qiaoyu Tan, Ninghao Liu, Xia Hu* 

  Social network analysis is an important problem in data mining. A fundamental
step for analyzing social networks is to encode network data into
low-dimensional representations, i.e., network embeddings, so that the network
topology structure and other attribute information can be effectively
preserved. Network representation leaning facilitates further applications such
as classification, link prediction, anomaly detection and clustering. In
addition, techniques based on deep neural networks have attracted great
interests over the past a few years. In this survey, we conduct a comprehensive
review of current literature in network representation learning utilizing
neural network models. First, we introduce the basic models for learning node
representations in homogeneous networks. Meanwhile, we will also introduce some
extensions of the base models in tackling more complex scenarios, such as
analyzing attributed networks, heterogeneous networks and dynamic networks.
Then, we introduce the techniques for embedding subgraphs. After that, we
present the applications of network representation learning. At the end, we
discuss some promising research directions for future work.

---------------

### 19 Feb 2018 | [Community Aware Random Walk for Network Embedding](https://arxiv.org/abs/1710.05199) | [⬇️](https://arxiv.org/pdf/1710.05199)
*Mohammad Mehdi Keikha, Maseud Rahgozar, Masoud Asadpour* 

  Social network analysis provides meaningful information about behavior of
network members that can be used for diverse applications such as
classification, link prediction. However, network analysis is computationally
expensive because of feature learning for different applications. In recent
years, many researches have focused on feature learning methods in social
networks. Network embedding represents the network in a lower dimensional
representation space with the same properties which presents a compressed
representation of the network. In this paper, we introduce a novel algorithm
named "CARE" for network embedding that can be used for different types of
networks including weighted, directed and complex. Current methods try to
preserve local neighborhood information of nodes, whereas the proposed method
utilizes local neighborhood and community information of network nodes to cover
both local and global structure of social networks. CARE builds customized
paths, which are consisted of local and global structure of network nodes, as a
basis for network embedding and uses the Skip-gram model to learn
representation vector of nodes. Subsequently, stochastic gradient descent is
applied to optimize our objective function and learn the final representation
of nodes. Our method can be scalable when new nodes are appended to network
without information loss. Parallelize generation of customized random walks is
also used for speeding up CARE. We evaluate the performance of CARE on multi
label classification and link prediction tasks. Experimental results on various
networks indicate that the proposed method outperforms others in both Micro and
Macro-f1 measures for different size of training data.

---------------

### 27 Jul 2015 | [A Review of Network Traffic Analysis and Prediction Techniques](https://arxiv.org/abs/1507.05722) | [⬇️](https://arxiv.org/pdf/1507.05722)
*Manish Joshi, Theyazn Hassn Hadi* 

  Analysis and prediction of network traffic has applications in wide
comprehensive set of areas and has newly attracted significant number of
studies. Different kinds of experiments are conducted and summarized to
identify various problems in existing computer network applications. Network
traffic analysis and prediction is a proactive approach to ensure secure,
reliable and qualitative network communication. Various techniques are proposed
and experimented for analyzing network traffic including neural network based
techniques to data mining techniques. Similarly, various Linear and non-linear
models are proposed for network traffic prediction. Several interesting
combinations of network analysis and prediction techniques are implemented to
attain efficient and effective results.
  This paper presents a survey on various such network analysis and traffic
prediction techniques. The uniqueness and rules of previous studies are
investigated. Moreover, various accomplished areas of analysis and prediction
of network traffic have been summed.

---------------

### 23 Apr 2009 | [Semantic Social Network Analysis](https://arxiv.org/abs/0904.3701) | [⬇️](https://arxiv.org/pdf/0904.3701)
*Guillaume Er\'et\'eo (INRIA Sophia Antipolis), Fabien Gandon (INRIA  Sophia Antipolis), Olivier Corby (INRIA Sophia Antipolis), Michel Buffa* 

  Social Network Analysis (SNA) tries to understand and exploit the key
features of social networks in order to manage their life cycle and predict
their evolution. Increasingly popular web 2.0 sites are forming huge social
network. Classical methods from social network analysis (SNA) have been applied
to such online networks. In this paper, we propose leveraging semantic web
technologies to merge and exploit the best features of each domain. We present
how to facilitate and enhance the analysis of online social networks,
exploiting the power of semantic social network analysis.

---------------

### 15 May 2014 | [Topic words analysis based on LDA model](https://arxiv.org/abs/1405.3726) | [⬇️](https://arxiv.org/pdf/1405.3726)
*Xi Qiu and Christopher Stewart* 

  Social network analysis (SNA), which is a research field describing and
modeling the social connection of a certain group of people, is popular among
network services. Our topic words analysis project is a SNA method to visualize
the topic words among emails from Obama.com to accounts registered in Columbus,
Ohio. Based on Latent Dirichlet Allocation (LDA) model, a popular topic model
of SNA, our project characterizes the preference of senders for target group of
receptors. Gibbs sampling is used to estimate topic and word distribution. Our
training and testing data are emails from the carbon-free server
Datagreening.com. We use parallel computing tool BashReduce for word processing
and generate related words under each latent topic to discovers typical
information of political news sending specially to local Columbus receptors.
Running on two instances using paralleling tool BashReduce, our project
contributes almost 30% speedup processing the raw contents, comparing with
processing contents on one instance locally. Also, the experimental result
shows that the LDA model applied in our project provides precision rate 53.96%
higher than TF-IDF model finding target words, on the condition that
appropriate size of topic words list is selected.

---------------

### 09 Aug 2020 | [Big Networks: A Survey](https://arxiv.org/abs/2008.03638) | [⬇️](https://arxiv.org/pdf/2008.03638)
*Hayat Dino Bedru, Shuo Yu, Xinru Xiao, Da Zhang, Liangtian Wan, He  Guo, Feng Xia* 

  A network is a typical expressive form of representing complex systems in
terms of vertices and links, in which the pattern of interactions amongst
components of the network is intricate. The network can be static that does not
change over time or dynamic that evolves through time. The complication of
network analysis is different under the new circumstance of network size
explosive increasing. In this paper, we introduce a new network science concept
called big network. Big networks are generally in large-scale with a
complicated and higher-order inner structure. This paper proposes a guideline
framework that gives an insight into the major topics in the area of network
science from the viewpoint of a big network. We first introduce the structural
characteristics of big networks from three levels, which are micro-level,
meso-level, and macro-level. We then discuss some state-of-the-art advanced
topics of big network analysis. Big network models and related approaches,
including ranking methods, partition approaches, as well as network embedding
algorithms are systematically introduced. Some typical applications in big
networks are then reviewed, such as community detection, link prediction,
recommendation, etc. Moreover, we also pinpoint some critical open issues that
need to be investigated further.

---------------

### 16 Nov 2020 | [Resilient Identification of Distribution Network Topology](https://arxiv.org/abs/2011.07981) | [⬇️](https://arxiv.org/pdf/2011.07981)
*Mohammad Jafarian, Alireza Soroudi, Andrew Keane* 

  Network topology identification (TI) is an essential function for distributed
energy resources management systems (DERMS) to organize and operate widespread
distributed energy resources (DERs). In this paper, discriminant analysis (DA)
is deployed to develop a network TI function that relies only on the
measurements available to DERMS. The propounded method is able to identify the
network switching configuration, as well as the status of protective devices.
Following, to improve the TI resiliency against the interruption of
communication channels, a quadratic programming optimization approach is
proposed to recover the missing signals. By deploying the propounded data
recovery approach and Bayes' theorem together, a benchmark is developed
afterward to identify anomalous measurements. This benchmark can make the TI
function resilient against cyber-attacks. Having a low computational burden,
this approach is fast-track and can be applied in real-time applications.
Sensitivity analysis is performed to assess the contribution of different
measurements and the impact of the system load type and loading level on the
performance of the proposed approach.

---------------

### 16 Jun 2015 | [SNA-based reasoning for multiagent team composition](https://arxiv.org/abs/1506.05154) | [⬇️](https://arxiv.org/pdf/1506.05154)
*Andre Filipe de Moraes Batista and Maria das Gra\c{c}as Bruno Marietto* 

  The social network analysis (SNA), branch of complex systems can be used in
the construction of multiagent systems. This paper proposes a study of how
social network analysis can assist in modeling multiagent systems, while
addressing similarities and differences between the two theories. We built a
prototype of multi-agent systems for resolution of tasks through the formation
of teams of agents that are formed on the basis of the social network
established between agents. Agents make use of performance indicators to assess
when should change their social network to maximize the participation in teams

---------------

### 31 Oct 2022 | [A Case Study of Chinese Sentiment Analysis on Social Media Reviews Based  on LSTM](https://arxiv.org/abs/2210.17452) | [⬇️](https://arxiv.org/pdf/2210.17452)
*Lukai Wang, Lei Wang* 

  Network public opinion analysis is obtained by a combination of natural
language processing (NLP) and public opinion supervision, and is crucial for
monitoring public mood and trends. Therefore, network public opinion analysis
can identify and solve potential and budding social problems. This study aims
to realize an analysis of Chinese sentiment in social media reviews using a
long short-term memory network (LSTM) model. The dataset was obtained from Sina
Weibo using a web crawler and was cleaned with Pandas. First, Chinese comments
regarding the legal sentencing in of Tangshan attack and Jiang Ge Case were
segmented and vectorized. Then, a binary LSTM model was trained and tested.
Finally, sentiment analysis results were obtained by analyzing the comments
with the LSTM model. The accuracy of the proposed model has reached
approximately 92%.

---------------

### 02 Aug 2022 | [20 years of network community detection](https://arxiv.org/abs/2208.00111) | [⬇️](https://arxiv.org/pdf/2208.00111)
*Santo Fortunato, M. E. J. Newman* 

  A fundamental technical challenge in the analysis of network data is the
automated discovery of communities - groups of nodes that are strongly
connected or that share similar features or roles. In this commentary we review
progress in the field over the last 20 years.

---------------

### 15 Feb 2022 | [Network Comparison with Interpretable Contrastive Network Representation  Learning](https://arxiv.org/abs/2005.12419) | [⬇️](https://arxiv.org/pdf/2005.12419)
*Takanori Fujiwara, Jian Zhao, Francine Chen, Yaoliang Yu, Kwan-Liu Ma* 

  Identifying unique characteristics in a network through comparison with
another network is an essential network analysis task. For example, with
networks of protein interactions obtained from normal and cancer tissues, we
can discover unique types of interactions in cancer tissues. This analysis task
could be greatly assisted by contrastive learning, which is an emerging
analysis approach to discover salient patterns in one dataset relative to
another. However, existing contrastive learning methods cannot be directly
applied to networks as they are designed only for high-dimensional data
analysis. To address this problem, we introduce a new analysis approach called
contrastive network representation learning (cNRL). By integrating two machine
learning schemes, network representation learning and contrastive learning,
cNRL enables embedding of network nodes into a low-dimensional representation
that reveals the uniqueness of one network compared to another. Within this
approach, we also design a method, named i-cNRL, which offers interpretability
in the learned results, allowing for understanding which specific patterns are
only found in one network. We demonstrate the effectiveness of i-cNRL for
network comparison with multiple network models and real-world datasets.
Furthermore, we compare i-cNRL and other potential cNRL algorithm designs
through quantitative and qualitative evaluations.

---------------

### 04 Feb 2014 | [Discovering Latent Network Structure in Point Process Data](https://arxiv.org/abs/1402.0914) | [⬇️](https://arxiv.org/pdf/1402.0914)
*Scott W. Linderman and Ryan P. Adams* 

  Networks play a central role in modern data analysis, enabling us to reason
about systems by studying the relationships between their parts. Most often in
network analysis, the edges are given. However, in many systems it is difficult
or impossible to measure the network directly. Examples of latent networks
include economic interactions linking financial instruments and patterns of
reciprocity in gang violence. In these cases, we are limited to noisy
observations of events associated with each node. To enable analysis of these
implicit networks, we develop a probabilistic model that combines
mutually-exciting point processes with random graph models. We show how the
Poisson superposition principle enables an elegant auxiliary variable
formulation and a fully-Bayesian, parallel inference algorithm. We evaluate
this new model empirically on several datasets.

---------------
**Date:** 05 Feb 2021

**Title:** Social Network Analysis: From Graph Theory to Applications with Python

**Abstract Link:** [https://arxiv.org/abs/2102.10014](https://arxiv.org/abs/2102.10014)

**PDF Link:** [https://arxiv.org/pdf/2102.10014](https://arxiv.org/pdf/2102.10014)

---

**Date:** 14 Feb 2024

**Title:** A Semantic Social Network Analysis Tool for Sensitivity Analysis and  What-If Scenario Testing in Alcohol Consumption Studies

**Abstract Link:** [https://arxiv.org/abs/2402.12390](https://arxiv.org/abs/2402.12390)

**PDF Link:** [https://arxiv.org/pdf/2402.12390](https://arxiv.org/pdf/2402.12390)

---

**Date:** 28 Sep 2022

**Title:** Consensus Knowledge Graph Learning via Multi-view Sparse Low Rank Block  Model

**Abstract Link:** [https://arxiv.org/abs/2209.13762](https://arxiv.org/abs/2209.13762)

**PDF Link:** [https://arxiv.org/pdf/2209.13762](https://arxiv.org/pdf/2209.13762)

---

**Date:** 02 Mar 2022

**Title:** Interactive Visualization of Protein RINs using NetworKit in the Cloud

**Abstract Link:** [https://arxiv.org/abs/2203.01263](https://arxiv.org/abs/2203.01263)

**PDF Link:** [https://arxiv.org/pdf/2203.01263](https://arxiv.org/pdf/2203.01263)

---

**Date:** 05 Jun 2021

**Title:** Network Estimation by Mixing: Adaptivity and More

**Abstract Link:** [https://arxiv.org/abs/2106.02803](https://arxiv.org/abs/2106.02803)

**PDF Link:** [https://arxiv.org/pdf/2106.02803](https://arxiv.org/pdf/2106.02803)

---

**Date:** 17 Jul 2020

**Title:** On the Robustness of Deep Learning-predicted Contention Models for  Network Calculus

**Abstract Link:** [https://arxiv.org/abs/1911.10522](https://arxiv.org/abs/1911.10522)

**PDF Link:** [https://arxiv.org/pdf/1911.10522](https://arxiv.org/pdf/1911.10522)

---

**Date:** 02 Aug 2016

**Title:** Size-Consistent Statistics for Anomaly Detection in Dynamic Networks

**Abstract Link:** [https://arxiv.org/abs/1608.00712](https://arxiv.org/abs/1608.00712)

**PDF Link:** [https://arxiv.org/pdf/1608.00712](https://arxiv.org/pdf/1608.00712)

---

**Date:** 17 Aug 2020

**Title:** A Visual Analytics Framework for Contrastive Network Analysis

**Abstract Link:** [https://arxiv.org/abs/2008.00151](https://arxiv.org/abs/2008.00151)

**PDF Link:** [https://arxiv.org/pdf/2008.00151](https://arxiv.org/pdf/2008.00151)

---

**Date:** 18 Apr 2019

**Title:** Deep Representation Learning for Social Network Analysis

**Abstract Link:** [https://arxiv.org/abs/1904.08547](https://arxiv.org/abs/1904.08547)

**PDF Link:** [https://arxiv.org/pdf/1904.08547](https://arxiv.org/pdf/1904.08547)

---

**Date:** 19 Feb 2018

**Title:** Community Aware Random Walk for Network Embedding

**Abstract Link:** [https://arxiv.org/abs/1710.05199](https://arxiv.org/abs/1710.05199)

**PDF Link:** [https://arxiv.org/pdf/1710.05199](https://arxiv.org/pdf/1710.05199)

---

**Date:** 27 Jul 2015

**Title:** A Review of Network Traffic Analysis and Prediction Techniques

**Abstract Link:** [https://arxiv.org/abs/1507.05722](https://arxiv.org/abs/1507.05722)

**PDF Link:** [https://arxiv.org/pdf/1507.05722](https://arxiv.org/pdf/1507.05722)

---

**Date:** 23 Apr 2009

**Title:** Semantic Social Network Analysis

**Abstract Link:** [https://arxiv.org/abs/0904.3701](https://arxiv.org/abs/0904.3701)

**PDF Link:** [https://arxiv.org/pdf/0904.3701](https://arxiv.org/pdf/0904.3701)

---

**Date:** 15 May 2014

**Title:** Topic words analysis based on LDA model

**Abstract Link:** [https://arxiv.org/abs/1405.3726](https://arxiv.org/abs/1405.3726)

**PDF Link:** [https://arxiv.org/pdf/1405.3726](https://arxiv.org/pdf/1405.3726)

---

**Date:** 09 Aug 2020

**Title:** Big Networks: A Survey

**Abstract Link:** [https://arxiv.org/abs/2008.03638](https://arxiv.org/abs/2008.03638)

**PDF Link:** [https://arxiv.org/pdf/2008.03638](https://arxiv.org/pdf/2008.03638)

---

**Date:** 16 Nov 2020

**Title:** Resilient Identification of Distribution Network Topology

**Abstract Link:** [https://arxiv.org/abs/2011.07981](https://arxiv.org/abs/2011.07981)

**PDF Link:** [https://arxiv.org/pdf/2011.07981](https://arxiv.org/pdf/2011.07981)

---

**Date:** 16 Jun 2015

**Title:** SNA-based reasoning for multiagent team composition

**Abstract Link:** [https://arxiv.org/abs/1506.05154](https://arxiv.org/abs/1506.05154)

**PDF Link:** [https://arxiv.org/pdf/1506.05154](https://arxiv.org/pdf/1506.05154)

---

**Date:** 31 Oct 2022

**Title:** A Case Study of Chinese Sentiment Analysis on Social Media Reviews Based  on LSTM

**Abstract Link:** [https://arxiv.org/abs/2210.17452](https://arxiv.org/abs/2210.17452)

**PDF Link:** [https://arxiv.org/pdf/2210.17452](https://arxiv.org/pdf/2210.17452)

---

**Date:** 02 Aug 2022

**Title:** 20 years of network community detection

**Abstract Link:** [https://arxiv.org/abs/2208.00111](https://arxiv.org/abs/2208.00111)

**PDF Link:** [https://arxiv.org/pdf/2208.00111](https://arxiv.org/pdf/2208.00111)

---

**Date:** 15 Feb 2022

**Title:** Network Comparison with Interpretable Contrastive Network Representation  Learning

**Abstract Link:** [https://arxiv.org/abs/2005.12419](https://arxiv.org/abs/2005.12419)

**PDF Link:** [https://arxiv.org/pdf/2005.12419](https://arxiv.org/pdf/2005.12419)

---

**Date:** 04 Feb 2014

**Title:** Discovering Latent Network Structure in Point Process Data

**Abstract Link:** [https://arxiv.org/abs/1402.0914](https://arxiv.org/abs/1402.0914)

**PDF Link:** [https://arxiv.org/pdf/1402.0914](https://arxiv.org/pdf/1402.0914)

---

