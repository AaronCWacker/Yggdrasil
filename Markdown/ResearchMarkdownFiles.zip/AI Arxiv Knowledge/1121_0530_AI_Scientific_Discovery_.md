AI Scientific Discovery 🧮

### 🔎 AI Scientific Discovery 🧮

🔬

# AI Scientific Discovery

AI Scientific Discovery is a field of artificial intelligence that focuses on the use of AI techniques to make scientific discoveries. This can involve using AI to analyze large datasets, make predictions, or identify patterns that might not be apparent to human researchers. AI Scientific Discovery has the potential to revolutionize the way that scientific research is conducted, making it faster, more efficient, and more accurate.

There are a number of different AI techniques that can be used in Scientific Discovery, including machine learning, deep learning, and natural language processing. Machine learning algorithms can be used to analyze large datasets and identify patterns or trends that might be of interest to researchers. Deep learning algorithms, which are a type of machine learning algorithm that uses artificial neural networks, can be used to make predictions or identify complex patterns in data. Natural language processing algorithms can be used to analyze text data, such as scientific papers or patient records, to extract relevant information or identify trends.

AI Scientific Discovery has already been used in a number of different fields, including biology, chemistry, physics, and medicine. In biology, for example, AI has been used to analyze genetic data to identify patterns that might be associated with certain diseases. In chemistry, AI has been used to predict the properties of new materials or to design new drugs. In physics, AI has been used to analyze data from particle accelerators to identify new particles or to understand the fundamental laws of the universe. In medicine, AI has been used to analyze medical records to identify patients who are at risk of developing certain diseases, or to develop personalized treatment plans for individual patients.

AI Scientific Discovery is still a relatively new field, and there are many challenges that need to be addressed in order to fully realize its potential. One of the biggest challenges is the need for large, high-quality datasets that can be used to train AI algorithms. Another challenge is the need for robust and explainable AI algorithms that can be trusted by researchers and regulators. Despite these challenges, AI Scientific Discovery has the potential to transform the way that scientific research is conducted, and to lead to new discoveries that would otherwise be impossible.</s>
# 🩺🔍 Search Results
### 28 Oct 2022 | [Automatic Discovery and Description of Human Planning Strategies](https://arxiv.org/abs/2109.14493) | [⬇️](https://arxiv.org/pdf/2109.14493)
*Julian Skirzynski, Yash Raj Jain, Falk Lieder* 

  Scientific discovery concerns finding patterns in data and creating
insightful hypotheses that explain these patterns. Traditionally, this process
required human ingenuity, but with the galloping advances in artificial
intelligence (AI) it becomes feasible to automate some parts of scientific
discovery. In this work we leverage AI for strategy discovery for understanding
human planning. In the state-of-the-art methods data about the process of human
planning is often used to group similar behaviors together and formulate verbal
descriptions of the strategies which might underlie those groups. Here, we
automate these two steps. Our method utilizes a new algorithm, called
Human-Interpret, that performs imitation learning to describe sequences of
planning operations in terms of a procedural formula and then translates that
formula to natural language. We test our method on a benchmark data set that
researchers have previously scrutinized manually. We find that the descriptions
of human planning strategies obtained automatically are about as understandable
as human-generated descriptions. They also cover a substantial proportion of of
relevant types of human planning strategies that had been discovered manually.
Our method saves scientists' time and effort as all the reasoning about human
planning is done automatically. This might make it feasible to more rapidly
scale up the search for yet undiscovered cognitive strategies to many new
decision environments, populations, tasks, and domains. Given these results, we
believe that the presented work may accelerate scientific discovery in
psychology, and due to its generality, extend to problems from other fields.

---------------

### 13 Jul 2023 | [Artificial Intelligence for Drug Discovery: Are We There Yet?](https://arxiv.org/abs/2307.06521) | [⬇️](https://arxiv.org/pdf/2307.06521)
*Catrin Hasselgren and Tudor I. Oprea* 

  Drug discovery is adapting to novel technologies such as data science,
informatics, and artificial intelligence (AI) to accelerate effective treatment
development while reducing costs and animal experiments. AI is transforming
drug discovery, as indicated by increasing interest from investors, industrial
and academic scientists, and legislators. Successful drug discovery requires
optimizing properties related to pharmacodynamics, pharmacokinetics, and
clinical outcomes. This review discusses the use of AI in the three pillars of
drug discovery: diseases, targets, and therapeutic modalities, with a focus on
small molecule drugs. AI technologies, such as generative chemistry, machine
learning, and multi-property optimization, have enabled several compounds to
enter clinical trials. The scientific community must carefully vet known
information to address the reproducibility crisis. The full potential of AI in
drug discovery can only be realized with sufficient ground truth and
appropriate human intervention at later pipeline stages.

---------------

### 23 Jan 2023 | [From Kepler to Newton: Explainable AI for Science](https://arxiv.org/abs/2111.12210) | [⬇️](https://arxiv.org/pdf/2111.12210)
*Zelong Li and Jianchao Ji and Yongfeng Zhang* 

  The Observation--Hypothesis--Prediction--Experimentation loop paradigm for
scientific research has been practiced by researchers for years towards
scientific discoveries. However, with data explosion in both mega-scale and
milli-scale scientific research, it has been sometimes very difficult to
manually analyze the data and propose new hypotheses to drive the cycle for
scientific discovery. In this paper, we discuss the role of Explainable AI in
scientific discovery process by demonstrating an Explainable AI-based paradigm
for science discovery. The key is to use Explainable AI to help derive data or
model interpretations, hypotheses, as well as scientific discoveries or
insights. We show how computational and data-intensive methodology -- together
with experimental and theoretical methodology -- can be seamlessly integrated
for scientific research. To demonstrate the AI-based science discovery process,
and to pay our respect to some of the greatest minds in human history, we show
how Kepler's laws of planetary motion and Newton's law of universal gravitation
can be rediscovered by (Explainable) AI based on Tycho Brahe's astronomical
observation data, whose works were leading the scientific revolution in the
16-17th century. This work also highlights the important role of Explainable AI
(as compared to Blackbox AI) in science discovery to help humans prevent or
better prepare for the possible technological singularity that may happen in
the future, since science is not only about the know how, but also the know
why. Presentation of the work is available at
https://slideslive.com/38986142/from-kepler-to-newton-explainable-ai-for-science-discovery.

---------------

### 27 Nov 2021 | [Learning from learning machines: a new generation of AI technology to  meet the needs of science](https://arxiv.org/abs/2111.13786) | [⬇️](https://arxiv.org/pdf/2111.13786)
*Luca Pion-Tonachini, Kristofer Bouchard, Hector Garcia Martin, Sean  Peisert, W. Bradley Holtz, Anil Aswani, Dipankar Dwivedi, Haruko Wainwright,  Ghanshyam Pilania, Benjamin Nachman, Babetta L. Marrone, Nicola Falco,  Prabhat, Daniel Arnold, Alejandro Wolf-Yadlin, Sarah Powers, Sharlee Climer,  Quinn Jackson, Ty Carlson, Michael Sohn, Petrus Zwart, Neeraj Kumar, Amy  Justice, Claire Tomlin, Daniel Jacobson, Gos Micklem, Georgios V. Gkoutos,  Peter J. Bickel, Jean-Baptiste Cazier, Juliane M\"uller, Bobbie-Jo  Webb-Robertson, Rick Stevens, Mark Anderson, Ken Kreutz-Delgado, Michael W.  Mahoney, James B. Brown* 

  We outline emerging opportunities and challenges to enhance the utility of AI
for scientific discovery. The distinct goals of AI for industry versus the
goals of AI for science create tension between identifying patterns in data
versus discovering patterns in the world from data. If we address the
fundamental challenges associated with "bridging the gap" between domain-driven
scientific models and data-driven AI learning machines, then we expect that
these AI models can transform hypothesis generation, scientific discovery, and
the scientific process itself.

---------------

### 22 Dec 2023 | [Constructing Custom Thermodynamics Using Deep Learning](https://arxiv.org/abs/2308.04119) | [⬇️](https://arxiv.org/pdf/2308.04119)
*Xiaoli Chen, Beatrice W. Soh, Zi-En Ooi, Eleonore Vissol-Gaudin,  Haijun Yu, Kostya S. Novoselov, Kedar Hippalgaonkar, Qianxiao Li* 

  One of the most exciting applications of artificial intelligence (AI) is
automated scientific discovery based on previously amassed data, coupled with
restrictions provided by known physical principles, including symmetries and
conservation laws. Such automated hypothesis creation and verification can
assist scientists in studying complex phenomena, where traditional physical
intuition may fail. Here we develop a platform based on a generalized Onsager
principle to learn macroscopic dynamical descriptions of arbitrary stochastic
dissipative systems directly from observations of their microscopic
trajectories. Our method simultaneously constructs reduced thermodynamic
coordinates and interprets the dynamics on these coordinates. We demonstrate
its effectiveness by studying theoretically and validating experimentally the
stretching of long polymer chains in an externally applied field. Specifically,
we learn three interpretable thermodynamic coordinates and build a dynamical
landscape of polymer stretching, including the identification of stable and
transition states and the control of the stretching rate. Our general
methodology can be used to address a wide range of scientific and technological
applications.

---------------

### 19 Dec 2023 | [Vertical Symbolic Regression](https://arxiv.org/abs/2312.11955) | [⬇️](https://arxiv.org/pdf/2312.11955)
*Nan Jiang, Md Nasim, Yexiang Xue* 

  Automating scientific discovery has been a grand goal of Artificial
Intelligence (AI) and will bring tremendous societal impact. Learning symbolic
expressions from experimental data is a vital step in AI-driven scientific
discovery. Despite exciting progress, most endeavors have focused on the
horizontal discovery paths, i.e., they directly search for the best expression
in the full hypothesis space involving all the independent variables.
Horizontal paths are challenging due to the exponentially large hypothesis
space involving all the independent variables. We propose Vertical Symbolic
Regression (VSR) to expedite symbolic regression. The VSR starts by fitting
simple expressions involving a few independent variables under controlled
experiments where the remaining variables are held constant. It then extends
the expressions learned in previous rounds by adding new independent variables
and using new control variable experiments allowing these variables to vary.
The first few steps in vertical discovery are significantly cheaper than the
horizontal path, as their search is in reduced hypothesis spaces involving a
small set of variables. As a consequence, vertical discovery has the potential
to supercharge state-of-the-art symbolic regression approaches in handling
complex equations with many contributing factors. Theoretically, we show that
the search space of VSR can be exponentially smaller than that of horizontal
approaches when learning a class of expressions. Experimentally, VSR
outperforms several baselines in learning symbolic expressions involving many
independent variables.

---------------

### 02 Feb 2022 | [AI Research Associate for Early-Stage Scientific Discovery](https://arxiv.org/abs/2202.03199) | [⬇️](https://arxiv.org/pdf/2202.03199)
*Morad Behandish, John Maxwell III, Johan de Kleer* 

  Artificial intelligence (AI) has been increasingly applied in scientific
activities for decades; however, it is still far from an insightful and
trustworthy collaborator in the scientific process. Most existing AI methods
are either too simplistic to be useful in real problems faced by scientists or
too domain-specialized (even dogmatized), stifling transformative discoveries
or paradigm shifts. We present an AI research associate for early-stage
scientific discovery based on (a) a novel minimally-biased ontology for
physics-based modeling that is context-aware, interpretable, and generalizable
across classical and relativistic physics; (b) automatic search for viable and
parsimonious hypotheses, represented at a high-level (via domain-agnostic
constructs) with built-in invariants, e.g., postulated forms of conservation
principles implied by a presupposed spacetime topology; and (c) automatic
compilation of the enumerated hypotheses to domain-specific, interpretable, and
trainable/testable tensor-based computation graphs to learn phenomenological
relations, e.g., constitutive or material laws, from sparse (and possibly
noisy) data sets.

---------------

### 17 Aug 2023 | [Towards Lightweight Data Integration using Multi-workflow Provenance and  Data Observability](https://arxiv.org/abs/2308.09004) | [⬇️](https://arxiv.org/pdf/2308.09004)
*Renan Souza, Tyler J. Skluzacek, Sean R. Wilkinson, Maxim Ziatdinov,  Rafael Ferreira da Silva* 

  Modern large-scale scientific discovery requires multidisciplinary
collaboration across diverse computing facilities, including High Performance
Computing (HPC) machines and the Edge-to-Cloud continuum. Integrated data
analysis plays a crucial role in scientific discovery, especially in the
current AI era, by enabling Responsible AI development, FAIR, Reproducibility,
and User Steering. However, the heterogeneous nature of science poses
challenges such as dealing with multiple supporting tools, cross-facility
environments, and efficient HPC execution. Building on data observability,
adapter system design, and provenance, we propose MIDA: an approach for
lightweight runtime Multi-workflow Integrated Data Analysis. MIDA defines data
observability strategies and adaptability methods for various parallel systems
and machine learning tools. With observability, it intercepts the dataflows in
the background without requiring instrumentation while integrating domain,
provenance, and telemetry data at runtime into a unified database ready for
user steering queries. We conduct experiments showing end-to-end multi-workflow
analysis integrating data from Dask and MLFlow in a real distributed deep
learning use case for materials science that runs on multiple environments with
up to 276 GPUs in parallel. We show near-zero overhead running up to 100,000
tasks on 1,680 CPU cores on the Summit supercomputer.

---------------

### 05 Nov 2022 | [Toward Human-AI Co-creation to Accelerate Material Discovery](https://arxiv.org/abs/2211.04257) | [⬇️](https://arxiv.org/pdf/2211.04257)
*Dmitry Zubarev, Carlos Raoni Mendes, Emilio Vital Brazil, Renato  Cerqueira, Kristin Schmidt, Vinicius Segura, Juliana Jansen Ferreira, Dan  Sanders* 

  There is an increasing need in our society to achieve faster advances in
Science to tackle urgent problems, such as climate changes, environmental
hazards, sustainable energy systems, pandemics, among others. In certain
domains like chemistry, scientific discovery carries the extra burden of
assessing risks of the proposed novel solutions before moving to the
experimental stage. Despite several recent advances in Machine Learning and AI
to address some of these challenges, there is still a gap in technologies to
support end-to-end discovery applications, integrating the myriad of available
technologies into a coherent, orchestrated, yet flexible discovery process.
Such applications need to handle complex knowledge management at scale,
enabling knowledge consumption and production in a timely and efficient way for
subject matter experts (SMEs). Furthermore, the discovery of novel functional
materials strongly relies on the development of exploration strategies in the
chemical space. For instance, generative models have gained attention within
the scientific community due to their ability to generate enormous volumes of
novel molecules across material domains. These models exhibit extreme
creativity that often translates in low viability of the generated candidates.
In this work, we propose a workbench framework that aims at enabling the
human-AI co-creation to reduce the time until the first discovery and the
opportunity costs involved. This framework relies on a knowledge base with
domain and process knowledge, and user-interaction components to acquire
knowledge and advise the SMEs. Currently,the framework supports four main
activities: generative modeling, dataset triage, molecule adjudication, and
risk assessment.

---------------

### 13 Sep 2023 | [End-to-end Phase Field Model Discovery Combining Experimentation,  Crowdsourcing, Simulation and Learning](https://arxiv.org/abs/2311.12801) | [⬇️](https://arxiv.org/pdf/2311.12801)
*Md Nasim, Anter El-Azab, Xinghang Zhang, Yexiang Xue* 

  The availability of tera-byte scale experiment data calls for AI driven
approaches which automatically discover scientific models from data.
Nonetheless, significant challenges present in AI-driven scientific discovery:
(i) The annotation of large scale datasets requires fundamental re-thinking in
developing scalable crowdsourcing tools. (ii) The learning of scientific models
from data calls for innovations beyond black-box neural nets. (iii) Novel
visualization and diagnosis tools are needed for the collaboration of
experimental and theoretical physicists, and computer scientists. We present
Phase-Field-Lab platform for end-to-end phase field model discovery, which
automatically discovers phase field physics models from experiment data,
integrating experimentation, crowdsourcing, simulation and learning.
Phase-Field-Lab combines (i) a streamlined annotation tool which reduces the
annotation time (by ~50-75%), while increasing annotation accuracy compared to
baseline; (ii) an end-to-end neural model which automatically learns phase
field models from data by embedding phase field simulation and existing domain
knowledge into learning; and (iii) novel interfaces and visualizations to
integrate our platform into the scientific discovery cycle of domain
scientists. Our platform is deployed in the analysis of nano-structure
evolution in materials under extreme conditions (high temperature and
irradiation). Our approach reveals new properties of nano-void defects, which
otherwise cannot be detected via manual analysis.

---------------

### 23 Dec 2022 | [On How AI Needs to Change to Advance the Science of Drug Discovery](https://arxiv.org/abs/2212.12560) | [⬇️](https://arxiv.org/pdf/2212.12560)
*Kieran Didi and Matej Ze\v{c}evi\'c* 

  Research around AI for Science has seen significant success since the rise of
deep learning models over the past decade, even with longstanding challenges
such as protein structure prediction. However, this fast development inevitably
made their flaws apparent -- especially in domains of reasoning where
understanding the cause-effect relationship is important. One such domain is
drug discovery, in which such understanding is required to make sense of data
otherwise plagued by spurious correlations. Said spuriousness only becomes
worse with the ongoing trend of ever-increasing amounts of data in the life
sciences and thereby restricts researchers in their ability to understand
disease biology and create better therapeutics. Therefore, to advance the
science of drug discovery with AI it is becoming necessary to formulate the key
problems in the language of causality, which allows the explication of
modelling assumptions needed for identifying true cause-effect relationships.
  In this attention paper, we present causal drug discovery as the craft of
creating models that ground the process of drug discovery in causal reasoning.

---------------

### 24 Aug 2022 | [AI-coupled HPC Workflows](https://arxiv.org/abs/2208.11745) | [⬇️](https://arxiv.org/pdf/2208.11745)
*Shantenu Jha, Vincent R. Pascuzzi, Matteo Turilli* 

  Increasingly, scientific discovery requires sophisticated and scalable
workflows. Workflows have become the ``new applications,'' wherein multi-scale
computing campaigns comprise multiple and heterogeneous executable tasks. In
particular, the introduction of AI/ML models into the traditional HPC workflows
has been an enabler of highly accurate modeling, typically reducing
computational needs compared to traditional methods. This chapter discusses
various modes of integrating AI/ML models to HPC computations, resulting in
diverse types of AI-coupled HPC workflows. The increasing need of coupling
AI/ML and HPC across scientific domains is motivated, and then exemplified by a
number of production-grade use cases for each mode. We additionally discuss the
primary challenges of extreme-scale AI-coupled HPC campaigns -- task
heterogeneity, adaptivity, performance -- and several framework and middleware
solutions which aim to address them. While both HPC workflow and AI/ML
computing paradigms are independently effective, we highlight how their
integration, and ultimate convergence, is leading to significant improvements
in scientific performance across a range of domains, ultimately resulting in
scientific explorations otherwise unattainable.

---------------

### 29 Aug 2023 | [The Future of Fundamental Science Led by Generative Closed-Loop  Artificial Intelligence](https://arxiv.org/abs/2307.07522) | [⬇️](https://arxiv.org/pdf/2307.07522)
*Hector Zenil, Jesper Tegn\'er, Felipe S. Abrah\~ao, Alexander Lavin,  Vipin Kumar, Jeremy G. Frey, Adrian Weller, Larisa Soldatova, Alan R. Bundy,  Nicholas R. Jennings, Koichi Takahashi, Lawrence Hunter, Saso Dzeroski,  Andrew Briggs, Frederick D. Gregory, Carla P. Gomes, Jon Rowe, James Evans,  Hiroaki Kitano, Ross King* 

  Recent advances in machine learning and AI, including Generative AI and LLMs,
are disrupting technological innovation, product development, and society as a
whole. AI's contribution to technology can come from multiple approaches that
require access to large training data sets and clear performance evaluation
criteria, ranging from pattern recognition and classification to generative
models. Yet, AI has contributed less to fundamental science in part because
large data sets of high-quality data for scientific practice and model
discovery are more difficult to access. Generative AI, in general, and Large
Language Models in particular, may represent an opportunity to augment and
accelerate the scientific discovery of fundamental deep science with
quantitative models. Here we explore and investigate aspects of an AI-driven,
automated, closed-loop approach to scientific discovery, including self-driven
hypothesis generation and open-ended autonomous exploration of the hypothesis
space. Integrating AI-driven automation into the practice of science would
mitigate current problems, including the replication of findings, systematic
production of data, and ultimately democratisation of the scientific process.
Realising these possibilities requires a vision for augmented AI coupled with a
diversity of AI approaches able to deal with fundamental aspects of causality
analysis and model discovery while enabling unbiased search across the space of
putative explanations. These advances hold the promise to unleash AI's
potential for searching and discovering the fundamental structure of our world
beyond what human scientists have been able to achieve. Such a vision would
push the boundaries of new fundamental science rather than automatize current
workflows and instead open doors for technological innovation to tackle some of
the greatest challenges facing humanity today.

---------------

### 15 Nov 2023 | [Artificial Intelligence for Science in Quantum, Atomistic, and Continuum  Systems](https://arxiv.org/abs/2307.08423) | [⬇️](https://arxiv.org/pdf/2307.08423)
*Xuan Zhang, Limei Wang, Jacob Helwig, Youzhi Luo, Cong Fu, Yaochen  Xie, Meng Liu, Yuchao Lin, Zhao Xu, Keqiang Yan, Keir Adams, Maurice Weiler,  Xiner Li, Tianfan Fu, Yucheng Wang, Haiyang Yu, YuQing Xie, Xiang Fu, Alex  Strasser, Shenglong Xu, Yi Liu, Yuanqi Du, Alexandra Saxton, Hongyi Ling,  Hannah Lawrence, Hannes St\"ark, Shurui Gui, Carl Edwards, Nicholas Gao,  Adriana Ladera, Tailin Wu, Elyssa F. Hofgard, Aria Mansouri Tehrani, Rui  Wang, Ameya Daigavane, Montgomery Bohde, Jerry Kurtin, Qian Huang, Tuong  Phung, Minkai Xu, Chaitanya K. Joshi, Simon V. Mathis, Kamyar  Azizzadenesheli, Ada Fang, Al\'an Aspuru-Guzik, Erik Bekkers, Michael  Bronstein, Marinka Zitnik, Anima Anandkumar, Stefano Ermon, Pietro Li\`o,  Rose Yu, Stephan G\"unnemann, Jure Leskovec, Heng Ji, Jimeng Sun, Regina  Barzilay, Tommi Jaakkola, Connor W. Coley, Xiaoning Qian, Xiaofeng Qian, Tess  Smidt, Shuiwang Ji* 

  Advances in artificial intelligence (AI) are fueling a new paradigm of
discoveries in natural sciences. Today, AI has started to advance natural
sciences by improving, accelerating, and enabling our understanding of natural
phenomena at a wide range of spatial and temporal scales, giving rise to a new
area of research known as AI for science (AI4Science). Being an emerging
research paradigm, AI4Science is unique in that it is an enormous and highly
interdisciplinary area. Thus, a unified and technical treatment of this field
is needed yet challenging. This work aims to provide a technically thorough
account of a subarea of AI4Science; namely, AI for quantum, atomistic, and
continuum systems. These areas aim at understanding the physical world from the
subatomic (wavefunctions and electron density), atomic (molecules, proteins,
materials, and interactions), to macro (fluids, climate, and subsurface) scales
and form an important subarea of AI4Science. A unique advantage of focusing on
these areas is that they largely share a common set of challenges, thereby
allowing a unified and foundational treatment. A key common challenge is how to
capture physics first principles, especially symmetries, in natural systems by
deep learning methods. We provide an in-depth yet intuitive account of
techniques to achieve equivariance to symmetry transformations. We also discuss
other common technical challenges, including explainability,
out-of-distribution generalization, knowledge transfer with foundation and
large language models, and uncertainty quantification. To facilitate learning
and education, we provide categorized lists of resources that we found to be
useful. We strive to be thorough and unified and hope this initial effort may
trigger more community interests and efforts to further advance AI4Science.

---------------

### 03 May 2023 | [Automated Scientific Discovery: From Equation Discovery to Autonomous  Discovery Systems](https://arxiv.org/abs/2305.02251) | [⬇️](https://arxiv.org/pdf/2305.02251)
*Stefan Kramer, Mattia Cerrato, Sa\v{s}o D\v{z}eroski, Ross King* 

  The paper surveys automated scientific discovery, from equation discovery and
symbolic regression to autonomous discovery systems and agents. It discusses
the individual approaches from a "big picture" perspective and in context, but
also discusses open issues and recent topics like the various roles of deep
neural networks in this area, aiding in the discovery of human-interpretable
knowledge. Further, we will present closed-loop scientific discovery systems,
starting with the pioneering work on the Adam system up to current efforts in
fields from material science to astronomy. Finally, we will elaborate on
autonomy from a machine learning perspective, but also in analogy to the
autonomy levels in autonomous driving. The maximal level, level five, is
defined to require no human intervention at all in the production of scientific
knowledge. Achieving this is one step towards solving the Nobel Turing Grand
Challenge to develop AI Scientists: AI systems capable of making Nobel-quality
scientific discoveries highly autonomously at a level comparable, and possibly
superior, to the best human scientists by 2050.

---------------

### 02 Jun 2023 | [Accelerating science with human-aware artificial intelligence](https://arxiv.org/abs/2306.01495) | [⬇️](https://arxiv.org/pdf/2306.01495)
*Jamshid Sourati, James Evans* 

  Artificial intelligence (AI) models trained on published scientific findings
have been used to invent valuable materials and targeted therapies, but they
typically ignore the human scientists who continually alter the landscape of
discovery. Here we show that incorporating the distribution of human expertise
by training unsupervised models on simulated inferences cognitively accessible
to experts dramatically improves (up to 400%) AI prediction of future
discoveries beyond those focused on research content alone, especially when
relevant literature is sparse. These models succeed by predicting human
predictions and the scientists who will make them. By tuning human-aware AI to
avoid the crowd, we can generate scientifically promising "alien" hypotheses
unlikely to be imagined or pursued without intervention until the distant
future, which hold promise to punctuate scientific advance beyond questions
currently pursued. Accelerating human discovery or probing its blind spots,
human-aware AI enables us to move toward and beyond the contemporary scientific
frontier.

---------------

### 07 Mar 2023 | [Knowledge-augmented Graph Machine Learning for Drug Discovery: A Survey  from Precision to Interpretability](https://arxiv.org/abs/2302.08261) | [⬇️](https://arxiv.org/pdf/2302.08261)
*Zhiqiang Zhong and Anastasia Barkova and Davide Mottin* 

  The integration of Artificial Intelligence (AI) into the field of drug
discovery has been a growing area of interdisciplinary scientific research.
However, conventional AI models are heavily limited in handling complex
biomedical structures (such as 2D or 3D protein and molecule structures) and
providing interpretations for outputs, which hinders their practical
application. As of late, Graph Machine Learning (GML) has gained considerable
attention for its exceptional ability to model graph-structured biomedical data
and investigate their properties and functional relationships. Despite
extensive efforts, GML methods still suffer from several deficiencies, such as
the limited ability to handle supervision sparsity and provide interpretability
in learning and inference processes, and their ineffectiveness in utilising
relevant domain knowledge. In response, recent studies have proposed
integrating external biomedical knowledge into the GML pipeline to realise more
precise and interpretable drug discovery with limited training instances.
However, a systematic definition for this burgeoning research direction is yet
to be established. This survey presents a comprehensive overview of
long-standing drug discovery principles, provides the foundational concepts and
cutting-edge techniques for graph-structured data and knowledge databases, and
formally summarises Knowledge-augmented Graph Machine Learning (KaGML) for drug
discovery. we propose a thorough review of related KaGML works, collected
following a carefully designed search methodology, and organise them into four
categories following a novel-defined taxonomy. To facilitate research in this
promptly emerging field, we also share collected practical resources that are
valuable for intelligent drug discovery and provide an in-depth discussion of
the potential avenues for future advancements.

---------------

### 31 Oct 2023 | [AI for Open Science: A Multi-Agent Perspective for Ethically Translating  Data to Knowledge](https://arxiv.org/abs/2310.18852) | [⬇️](https://arxiv.org/pdf/2310.18852)
*Chase Yakaboski, Gregory Hyde, Clement Nyanhongo and Eugene Santos Jr* 

  AI for Science (AI4Science), particularly in the form of self-driving labs,
has the potential to sideline human involvement and hinder scientific discovery
within the broader community. While prior research has focused on ensuring the
responsible deployment of AI applications, enhancing security, and ensuring
interpretability, we also propose that promoting openness in AI4Science
discoveries should be carefully considered. In this paper, we introduce the
concept of AI for Open Science (AI4OS) as a multi-agent extension of AI4Science
with the core principle of maximizing open knowledge translation throughout the
scientific enterprise rather than a single organizational unit. We use the
established principles of Knowledge Discovery and Data Mining (KDD) to
formalize a language around AI4OS. We then discuss three principle stages of
knowledge translation embedded in AI4Science systems and detail specific points
where openness can be applied to yield an AI4OS alternative. Lastly, we
formulate a theoretical metric to assess AI4OS with a supporting ethical
argument highlighting its importance. Our goal is that by drawing attention to
AI4OS we can ensure the natural consequence of AI4Science (e.g., self-driving
labs) is a benefit not only for its developers but for society as a whole.

---------------

### 21 Feb 2024 | [Toward a Team of AI-made Scientists for Scientific Discovery from Gene  Expression Data](https://arxiv.org/abs/2402.12391) | [⬇️](https://arxiv.org/pdf/2402.12391)
*Haoyang Liu, Yijiang Li, Jinglin Jian, Yuxuan Cheng, Jianrong Lu,  Shuyi Guo, Jinglei Zhu, Mianchen Zhang, Miantong Zhang, Haohan Wang* 

  Machine learning has emerged as a powerful tool for scientific discovery,
enabling researchers to extract meaningful insights from complex datasets. For
instance, it has facilitated the identification of disease-predictive genes
from gene expression data, significantly advancing healthcare. However, the
traditional process for analyzing such datasets demands substantial human
effort and expertise for the data selection, processing, and analysis. To
address this challenge, we introduce a novel framework, a Team of AI-made
Scientists (TAIS), designed to streamline the scientific discovery pipeline.
TAIS comprises simulated roles, including a project manager, data engineer, and
domain expert, each represented by a Large Language Model (LLM). These roles
collaborate to replicate the tasks typically performed by data scientists, with
a specific focus on identifying disease-predictive genes. Furthermore, we have
curated a benchmark dataset to assess TAIS's effectiveness in gene
identification, demonstrating our system's potential to significantly enhance
the efficiency and scope of scientific exploration. Our findings represent a
solid step towards automating scientific discovery through large language
models.

---------------

### 06 Oct 2023 | [A Comprehensive Performance Study of Large Language Models on Novel AI  Accelerators](https://arxiv.org/abs/2310.04607) | [⬇️](https://arxiv.org/pdf/2310.04607)
*Murali Emani, Sam Foreman, Varuni Sastry, Zhen Xie, Siddhisanket  Raskar, William Arnold, Rajeev Thakur, Venkatram Vishwanath, Michael E. Papka* 

  Artificial intelligence (AI) methods have become critical in scientific
applications to help accelerate scientific discovery. Large language models
(LLMs) are being considered as a promising approach to address some of the
challenging problems because of their superior generalization capabilities
across domains. The effectiveness of the models and the accuracy of the
applications is contingent upon their efficient execution on the underlying
hardware infrastructure. Specialized AI accelerator hardware systems have
recently become available for accelerating AI applications. However, the
comparative performance of these AI accelerators on large language models has
not been previously studied. In this paper, we systematically study LLMs on
multiple AI accelerators and GPUs and evaluate their performance
characteristics for these models. We evaluate these systems with (i) a
micro-benchmark using a core transformer block, (ii) a GPT- 2 model, and (iii)
an LLM-driven science use case, GenSLM. We present our findings and analyses of
the models' performance to better understand the intrinsic capabilities of AI
accelerators. Furthermore, our analysis takes into account key factors such as
sequence lengths, scaling behavior, sparsity, and sensitivity to gradient
accumulation steps.

---------------
**Date:** 28 Oct 2022

**Title:** Automatic Discovery and Description of Human Planning Strategies

**Abstract Link:** [https://arxiv.org/abs/2109.14493](https://arxiv.org/abs/2109.14493)

**PDF Link:** [https://arxiv.org/pdf/2109.14493](https://arxiv.org/pdf/2109.14493)

---

**Date:** 13 Jul 2023

**Title:** Artificial Intelligence for Drug Discovery: Are We There Yet?

**Abstract Link:** [https://arxiv.org/abs/2307.06521](https://arxiv.org/abs/2307.06521)

**PDF Link:** [https://arxiv.org/pdf/2307.06521](https://arxiv.org/pdf/2307.06521)

---

**Date:** 23 Jan 2023

**Title:** From Kepler to Newton: Explainable AI for Science

**Abstract Link:** [https://arxiv.org/abs/2111.12210](https://arxiv.org/abs/2111.12210)

**PDF Link:** [https://arxiv.org/pdf/2111.12210](https://arxiv.org/pdf/2111.12210)

---

**Date:** 27 Nov 2021

**Title:** Learning from learning machines: a new generation of AI technology to  meet the needs of science

**Abstract Link:** [https://arxiv.org/abs/2111.13786](https://arxiv.org/abs/2111.13786)

**PDF Link:** [https://arxiv.org/pdf/2111.13786](https://arxiv.org/pdf/2111.13786)

---

**Date:** 22 Dec 2023

**Title:** Constructing Custom Thermodynamics Using Deep Learning

**Abstract Link:** [https://arxiv.org/abs/2308.04119](https://arxiv.org/abs/2308.04119)

**PDF Link:** [https://arxiv.org/pdf/2308.04119](https://arxiv.org/pdf/2308.04119)

---

**Date:** 19 Dec 2023

**Title:** Vertical Symbolic Regression

**Abstract Link:** [https://arxiv.org/abs/2312.11955](https://arxiv.org/abs/2312.11955)

**PDF Link:** [https://arxiv.org/pdf/2312.11955](https://arxiv.org/pdf/2312.11955)

---

**Date:** 02 Feb 2022

**Title:** AI Research Associate for Early-Stage Scientific Discovery

**Abstract Link:** [https://arxiv.org/abs/2202.03199](https://arxiv.org/abs/2202.03199)

**PDF Link:** [https://arxiv.org/pdf/2202.03199](https://arxiv.org/pdf/2202.03199)

---

**Date:** 17 Aug 2023

**Title:** Towards Lightweight Data Integration using Multi-workflow Provenance and  Data Observability

**Abstract Link:** [https://arxiv.org/abs/2308.09004](https://arxiv.org/abs/2308.09004)

**PDF Link:** [https://arxiv.org/pdf/2308.09004](https://arxiv.org/pdf/2308.09004)

---

**Date:** 05 Nov 2022

**Title:** Toward Human-AI Co-creation to Accelerate Material Discovery

**Abstract Link:** [https://arxiv.org/abs/2211.04257](https://arxiv.org/abs/2211.04257)

**PDF Link:** [https://arxiv.org/pdf/2211.04257](https://arxiv.org/pdf/2211.04257)

---

**Date:** 13 Sep 2023

**Title:** End-to-end Phase Field Model Discovery Combining Experimentation,  Crowdsourcing, Simulation and Learning

**Abstract Link:** [https://arxiv.org/abs/2311.12801](https://arxiv.org/abs/2311.12801)

**PDF Link:** [https://arxiv.org/pdf/2311.12801](https://arxiv.org/pdf/2311.12801)

---

**Date:** 23 Dec 2022

**Title:** On How AI Needs to Change to Advance the Science of Drug Discovery

**Abstract Link:** [https://arxiv.org/abs/2212.12560](https://arxiv.org/abs/2212.12560)

**PDF Link:** [https://arxiv.org/pdf/2212.12560](https://arxiv.org/pdf/2212.12560)

---

**Date:** 24 Aug 2022

**Title:** AI-coupled HPC Workflows

**Abstract Link:** [https://arxiv.org/abs/2208.11745](https://arxiv.org/abs/2208.11745)

**PDF Link:** [https://arxiv.org/pdf/2208.11745](https://arxiv.org/pdf/2208.11745)

---

**Date:** 29 Aug 2023

**Title:** The Future of Fundamental Science Led by Generative Closed-Loop  Artificial Intelligence

**Abstract Link:** [https://arxiv.org/abs/2307.07522](https://arxiv.org/abs/2307.07522)

**PDF Link:** [https://arxiv.org/pdf/2307.07522](https://arxiv.org/pdf/2307.07522)

---

**Date:** 15 Nov 2023

**Title:** Artificial Intelligence for Science in Quantum, Atomistic, and Continuum  Systems

**Abstract Link:** [https://arxiv.org/abs/2307.08423](https://arxiv.org/abs/2307.08423)

**PDF Link:** [https://arxiv.org/pdf/2307.08423](https://arxiv.org/pdf/2307.08423)

---

**Date:** 03 May 2023

**Title:** Automated Scientific Discovery: From Equation Discovery to Autonomous  Discovery Systems

**Abstract Link:** [https://arxiv.org/abs/2305.02251](https://arxiv.org/abs/2305.02251)

**PDF Link:** [https://arxiv.org/pdf/2305.02251](https://arxiv.org/pdf/2305.02251)

---

**Date:** 02 Jun 2023

**Title:** Accelerating science with human-aware artificial intelligence

**Abstract Link:** [https://arxiv.org/abs/2306.01495](https://arxiv.org/abs/2306.01495)

**PDF Link:** [https://arxiv.org/pdf/2306.01495](https://arxiv.org/pdf/2306.01495)

---

**Date:** 07 Mar 2023

**Title:** Knowledge-augmented Graph Machine Learning for Drug Discovery: A Survey  from Precision to Interpretability

**Abstract Link:** [https://arxiv.org/abs/2302.08261](https://arxiv.org/abs/2302.08261)

**PDF Link:** [https://arxiv.org/pdf/2302.08261](https://arxiv.org/pdf/2302.08261)

---

**Date:** 31 Oct 2023

**Title:** AI for Open Science: A Multi-Agent Perspective for Ethically Translating  Data to Knowledge

**Abstract Link:** [https://arxiv.org/abs/2310.18852](https://arxiv.org/abs/2310.18852)

**PDF Link:** [https://arxiv.org/pdf/2310.18852](https://arxiv.org/pdf/2310.18852)

---

**Date:** 21 Feb 2024

**Title:** Toward a Team of AI-made Scientists for Scientific Discovery from Gene  Expression Data

**Abstract Link:** [https://arxiv.org/abs/2402.12391](https://arxiv.org/abs/2402.12391)

**PDF Link:** [https://arxiv.org/pdf/2402.12391](https://arxiv.org/pdf/2402.12391)

---

**Date:** 06 Oct 2023

**Title:** A Comprehensive Performance Study of Large Language Models on Novel AI  Accelerators

**Abstract Link:** [https://arxiv.org/abs/2310.04607](https://arxiv.org/abs/2310.04607)

**PDF Link:** [https://arxiv.org/pdf/2310.04607](https://arxiv.org/pdf/2310.04607)

---

