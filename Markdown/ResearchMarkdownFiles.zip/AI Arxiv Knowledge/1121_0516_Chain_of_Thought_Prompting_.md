Chain of Thought Prompting 🧩

### 🔎 Chain of Thought Prompting 🧩



Chain of Thought Prompting is a technique that involves breaking down a complex problem into smaller, more manageable parts and then using a series of prompts to guide a language model through the process of solving it. This technique can be used to generate creative ideas, solve complex math problems, or even write code.

Here's an example of how Chain of Thought Prompting might be used to solve a complex math problem:

1. Problem: Solve the equation 3x^2 + 5x - 2 = 0.
2. Prompt: "First, let's find the roots of the equation. To do this, we need to factor the equation."
3. Prompt: "The equation can be factored as (3x - 1)(x + 2) = 0."
4. Prompt: "Now, we can set each factor equal to zero and solve for x."
5. Prompt: "Setting the first factor equal to zero gives us 3x - 1 = 0, which can be solved to give x = 1/3. Setting the second factor equal to zero gives us x + 2 = 0, which can be solved to give x = -2."
6. Prompt: "Therefore, the solutions to the equation are x = 1/3 and x = -2."

Chain of Thought Prompting can be a powerful tool for solving complex problems, but it does require some practice and skill to use effectively. It's important to break the problem down into small, manageable parts and to use clear, concise prompts to guide the language model through the process of solving it. With practice, however, Chain of Thought Prompting can be a valuable tool for generating creative ideas, solving complex math problems, and even writing code.</s>
# 🩺🔍 Search Results
### 16 Feb 2024 | [Can Separators Improve Chain-of-Thought Prompting?](https://arxiv.org/abs/2402.10645) | [⬇️](https://arxiv.org/pdf/2402.10645)
*Yoonjeong Park, Hyunjin Kim, Chanyeol Choi, Junseong Kim, Jy-yong Sohn* 

  Chain-of-thought (CoT) prompting is a simple and effective method for
improving the reasoning capabilities of Large language models (LLMs). The basic
idea of CoT is to let LLMs break down their thought processes step-by-step by
putting exemplars in the input prompt. However, the densely structured prompt
exemplars of CoT may cause the cognitive overload of LLMs. Inspired by human
cognition, we introduce CoT-Sep, a novel method that strategically employs
separators at the end of each exemplar in CoT prompting. These separators are
designed to help the LLMs understand their thought processes better while
reasoning. It turns out that CoT-Sep significantly improves the LLMs'
performances on complex reasoning tasks (e.g., GSM-8K, AQuA, CSQA), compared
with the vanilla CoT, which does not use separators. We also study the effects
of the type and the location of separators tested on multiple LLMs, including
GPT-3.5-Turbo, GPT-4, and LLaMA-2 7B. Interestingly, the type/location of
separators should be chosen appropriately to boost the reasoning capability of
CoT.

---------------

### 24 Jun 2023 | [Symbolic Chain-of-Thought Distillation: Small Models Can Also "Think"  Step-by-Step](https://arxiv.org/abs/2306.14050) | [⬇️](https://arxiv.org/pdf/2306.14050)
*Liunian Harold Li, Jack Hessel, Youngjae Yu, Xiang Ren, Kai-Wei Chang,  Yejin Choi* 

  Chain-of-thought prompting (e.g., "Let's think step-by-step") primes large
language models to verbalize rationalization for their predictions. While
chain-of-thought can lead to dramatic performance gains, benefits appear to
emerge only for sufficiently large models (beyond 50B parameters). We show that
orders-of-magnitude smaller models (125M -- 1.3B parameters) can still benefit
from chain-of-thought prompting. To achieve this, we introduce Symbolic
Chain-of-Thought Distillation (SCoTD), a method to train a smaller student
model on rationalizations sampled from a significantly larger teacher model.
Experiments across several commonsense benchmarks show that: 1) SCoTD enhances
the performance of the student model in both supervised and few-shot settings,
and especially for challenge sets; 2) sampling many reasoning chains per
instance from the teacher is paramount; and 3) after distillation, student
chain-of-thoughts are judged by humans as comparable to the teacher, despite
orders of magnitude fewer parameters. We test several hypotheses regarding what
properties of chain-of-thought samples are important, e.g., diversity vs.
teacher likelihood vs. open-endedness. We release our corpus of
chain-of-thought samples and code.

---------------

### 02 Nov 2023 | [The Art of SOCRATIC QUESTIONING: Recursive Thinking with Large Language  Models](https://arxiv.org/abs/2305.14999) | [⬇️](https://arxiv.org/pdf/2305.14999)
*Jingyuan Qi, Zhiyang Xu, Ying Shen, Minqian Liu, Di Jin, Qifan Wang,  Lifu Huang* 

  Chain-of-Thought (CoT) prompting enables large language models to solve
complex reasoning problems by generating intermediate steps. However, confined
by its inherent single-pass and sequential generation process, CoT heavily
relies on the initial decisions, causing errors in early steps to accumulate
and impact the final answers. In contrast, humans adopt recursive thinking when
tackling complex reasoning problems, i.e., iteratively breaking the original
problem into approachable sub-problems and aggregating their answers to resolve
the original one. Inspired by the human cognitive process, we propose SOCRATIC
QUESTIONING, a divide-and-conquer style algorithm that mimics the recursive
thinking process. Specifically, SOCRATIC QUESTIONING leverages large language
models to raise and answer sub-questions until collecting enough information to
tackle the original question. Unlike CoT, SOCRATIC QUESTIONING explicitly
navigates the thinking space, stimulates effective recursive thinking, and is
more robust towards errors in the thinking process. Extensive experiments on
several complex reasoning tasks, including MMLU, MATH, LogiQA, and visual
question-answering demonstrate significant performance improvements over the
state-of-the-art prompting methods, such as CoT, and Tree-of-Thought. The
qualitative analysis clearly shows that the intermediate reasoning steps
elicited by SOCRATIC QUESTIONING are similar to humans' recursively thinking
process of complex reasoning problems.

---------------

### 07 Mar 2023 | [CoTEVer: Chain of Thought Prompting Annotation Toolkit for Explanation  Verification](https://arxiv.org/abs/2303.03628) | [⬇️](https://arxiv.org/pdf/2303.03628)
*Seungone Kim, Se June Joo, Yul Jang, Hyungjoo Chae, Jinyoung Yeo* 

  Chain-of-thought (CoT) prompting enables large language models (LLMs) to
solve complex reasoning tasks by generating an explanation before the final
prediction. Despite it's promising ability, a critical downside of CoT
prompting is that the performance is greatly affected by the factuality of the
generated explanation. To improve the correctness of the explanations,
fine-tuning language models with explanation data is needed. However, there
exists only a few datasets that can be used for such approaches, and no data
collection tool for building them. Thus, we introduce CoTEVer, a tool-kit for
annotating the factual correctness of generated explanations and collecting
revision data of wrong explanations. Furthermore, we suggest several use cases
where the data collected with CoTEVer can be utilized for enhancing the
faithfulness of explanations. Our toolkit is publicly available at
https://github.com/SeungoneKim/CoTEVer.

---------------

### 11 Dec 2023 | [Get an A in Math: Progressive Rectification Prompting](https://arxiv.org/abs/2312.06867) | [⬇️](https://arxiv.org/pdf/2312.06867)
*Zhenyu Wu, Meng Jiang, Chao Shen* 

  Chain-of-Thought (CoT) prompting methods have enabled large language models
(LLMs) to generate reasoning paths and solve math word problems (MWPs).
However, they are sensitive to mistakes in the paths, as any mistake can result
in an incorrect answer. We propose a novel method named Progressive
Rectification Prompting (PRP) to improve average accuracy on eight MWP datasets
from 77.3 to 90.5. Given an initial answer from CoT, PRP iterates a
verify-then-rectify process to progressively identify incorrect answers and
rectify the reasoning paths. With the most likely correct answer, the LLM
predicts a masked numerical value in the question; if the prediction does not
match the masked value, the answer is likely incorrect. Then the LLM is
prompted to re-generate the reasoning path hinted with a set of incorrect
answers to prevent itself from repeating previous mistakes. PRP achieves the
best performance compared against the CoT methods. Our implementation is made
publicly available at https://wzy6642.github.io/prp.github.io/.

---------------

### 10 Jan 2023 | [Chain-of-Thought Prompting Elicits Reasoning in Large Language Models](https://arxiv.org/abs/2201.11903) | [⬇️](https://arxiv.org/pdf/2201.11903)
*Jason Wei, Xuezhi Wang, Dale Schuurmans, Maarten Bosma, Brian Ichter,  Fei Xia, Ed Chi, Quoc Le, Denny Zhou* 

  We explore how generating a chain of thought -- a series of intermediate
reasoning steps -- significantly improves the ability of large language models
to perform complex reasoning. In particular, we show how such reasoning
abilities emerge naturally in sufficiently large language models via a simple
method called chain of thought prompting, where a few chain of thought
demonstrations are provided as exemplars in prompting. Experiments on three
large language models show that chain of thought prompting improves performance
on a range of arithmetic, commonsense, and symbolic reasoning tasks. The
empirical gains can be striking. For instance, prompting a 540B-parameter
language model with just eight chain of thought exemplars achieves state of the
art accuracy on the GSM8K benchmark of math word problems, surpassing even
finetuned GPT-3 with a verifier.

---------------

### 16 Apr 2023 | [Least-to-Most Prompting Enables Complex Reasoning in Large Language  Models](https://arxiv.org/abs/2205.10625) | [⬇️](https://arxiv.org/pdf/2205.10625)
*Denny Zhou, Nathanael Sch\"arli, Le Hou, Jason Wei, Nathan Scales,  Xuezhi Wang, Dale Schuurmans, Claire Cui, Olivier Bousquet, Quoc Le, Ed Chi* 

  Chain-of-thought prompting has demonstrated remarkable performance on various
natural language reasoning tasks. However, it tends to perform poorly on tasks
which requires solving problems harder than the exemplars shown in the prompts.
To overcome this challenge of easy-to-hard generalization, we propose a novel
prompting strategy, least-to-most prompting. The key idea in this strategy is
to break down a complex problem into a series of simpler subproblems and then
solve them in sequence. Solving each subproblem is facilitated by the answers
to previously solved subproblems. Our experimental results on tasks related to
symbolic manipulation, compositional generalization, and math reasoning reveal
that least-to-most prompting is capable of generalizing to more difficult
problems than those seen in the prompts. A notable finding is that when the
GPT-3 code-davinci-002 model is used with least-to-most prompting, it can solve
the compositional generalization benchmark SCAN in any split (including length
split) with an accuracy of at least 99% using just 14 exemplars, compared to
only 16% accuracy with chain-of-thought prompting. This is particularly
noteworthy because neural-symbolic models in the literature that specialize in
solving SCAN are trained on the entire training set containing over 15,000
examples. We have included prompts for all the tasks in the Appendix.

---------------

### 01 Jun 2023 | [Teaching Small Language Models to Reason](https://arxiv.org/abs/2212.08410) | [⬇️](https://arxiv.org/pdf/2212.08410)
*Lucie Charlotte Magister, Jonathan Mallinson, Jakub Adamek, Eric  Malmi, Aliaksei Severyn* 

  Chain of thought prompting successfully improves the reasoning capabilities
of large language models, achieving state of the art results on a range of
datasets. However, these reasoning capabilities only appear to emerge in models
with a size of over 100 billion parameters. In this paper, we explore the
transfer of such reasoning capabilities to models with less than 100 billion
parameters via knowledge distillation. Specifically, we finetune a student
model on the chain of thought outputs generated by a larger teacher model. Our
experiments show that the proposed method improves task performance across
arithmetic, commonsense and symbolic reasoning datasets. For example, the
accuracy of T5 XXL on GSM8K improves from 8.11% to 21.99% when finetuned on
PaLM-540B generated chains of thought.

---------------

### 07 Mar 2023 | [Self-Consistency Improves Chain of Thought Reasoning in Language Models](https://arxiv.org/abs/2203.11171) | [⬇️](https://arxiv.org/pdf/2203.11171)
*Xuezhi Wang, Jason Wei, Dale Schuurmans, Quoc Le, Ed Chi, Sharan  Narang, Aakanksha Chowdhery, Denny Zhou* 

  Chain-of-thought prompting combined with pre-trained large language models
has achieved encouraging results on complex reasoning tasks. In this paper, we
propose a new decoding strategy, self-consistency, to replace the naive greedy
decoding used in chain-of-thought prompting. It first samples a diverse set of
reasoning paths instead of only taking the greedy one, and then selects the
most consistent answer by marginalizing out the sampled reasoning paths.
Self-consistency leverages the intuition that a complex reasoning problem
typically admits multiple different ways of thinking leading to its unique
correct answer. Our extensive empirical evaluation shows that self-consistency
boosts the performance of chain-of-thought prompting with a striking margin on
a range of popular arithmetic and commonsense reasoning benchmarks, including
GSM8K (+17.9%), SVAMP (+11.0%), AQuA (+12.2%), StrategyQA (+6.4%) and
ARC-challenge (+3.9%).

---------------

### 07 Oct 2023 | [Large Language Models as Analogical Reasoners](https://arxiv.org/abs/2310.01714) | [⬇️](https://arxiv.org/pdf/2310.01714)
*Michihiro Yasunaga, Xinyun Chen, Yujia Li, Panupong Pasupat, Jure  Leskovec, Percy Liang, Ed H. Chi, Denny Zhou* 

  Chain-of-thought (CoT) prompting for language models demonstrates impressive
performance across reasoning tasks, but typically needs labeled exemplars of
the reasoning process. In this work, we introduce a new prompting approach,
Analogical Prompting, designed to automatically guide the reasoning process of
large language models. Inspired by analogical reasoning, a cognitive process in
which humans draw from relevant past experiences to tackle new problems, our
approach prompts language models to self-generate relevant exemplars or
knowledge in the context, before proceeding to solve the given problem. This
method presents several advantages: it obviates the need for labeling or
retrieving exemplars, offering generality and convenience; it can also tailor
the generated exemplars and knowledge to each problem, offering adaptability.
Experimental results show that our approach outperforms 0-shot CoT and manual
few-shot CoT in a variety of reasoning tasks, including math problem solving in
GSM8K and MATH, code generation in Codeforces, and other reasoning tasks in
BIG-Bench.

---------------

### 16 Nov 2023 | [Graph-Guided Reasoning for Multi-Hop Question Answering in Large  Language Models](https://arxiv.org/abs/2311.09762) | [⬇️](https://arxiv.org/pdf/2311.09762)
*Jinyoung Park, Ameen Patel, Omar Zia Khan, Hyunwoo J. Kim, Joo-Kyung  Kim* 

  Chain-of-Thought (CoT) prompting has boosted the multi-step reasoning
capabilities of Large Language Models (LLMs) by generating a series of
rationales before the final answer. We analyze the reasoning paths generated by
CoT and find two issues in multi-step reasoning: (i) Generating rationales
irrelevant to the question, (ii) Unable to compose subquestions or queries for
generating/retrieving all the relevant information. To address them, we propose
a graph-guided CoT prompting method, which guides the LLMs to reach the correct
answer with graph representation/verification steps. Specifically, we first
leverage LLMs to construct a "question/rationale graph" by using knowledge
extraction prompting given the initial question and the rationales generated in
the previous steps. Then, the graph verification step diagnoses the current
rationale triplet by comparing it with the existing question/rationale graph to
filter out irrelevant rationales and generate follow-up questions to obtain
relevant information. Additionally, we generate CoT paths that exclude the
extracted graph information to represent the context information missed from
the graph extraction. Our graph-guided reasoning method shows superior
performance compared to previous CoT prompting and the variants on multi-hop
question answering benchmark datasets.

---------------

### 23 Oct 2023 | [DialCoT Meets PPO: Decomposing and Exploring Reasoning Paths in Smaller  Language Models](https://arxiv.org/abs/2310.05074) | [⬇️](https://arxiv.org/pdf/2310.05074)
*Chengcheng Han, Xiaowei Du, Che Zhang, Yixin Lian, Xiang Li, Ming Gao,  Baoyuan Wang* 

  Chain-of-Thought (CoT) prompting has proven to be effective in enhancing the
reasoning capabilities of Large Language Models (LLMs) with at least 100
billion parameters. However, it is ineffective or even detrimental when applied
to reasoning tasks in Smaller Language Models (SLMs) with less than 10 billion
parameters. To address this limitation, we introduce Dialogue-guided
Chain-of-Thought (DialCoT) which employs a dialogue format to generate
intermediate reasoning steps, guiding the model toward the final answer.
Additionally, we optimize the model's reasoning path selection using the
Proximal Policy Optimization (PPO) algorithm, further enhancing its reasoning
capabilities. Our method offers several advantages compared to previous
approaches. Firstly, we transform the process of solving complex reasoning
questions by breaking them down into a series of simpler sub-questions,
significantly reducing the task difficulty and making it more suitable for
SLMs. Secondly, we optimize the model's reasoning path selection through the
PPO algorithm. We conduct comprehensive experiments on four arithmetic
reasoning datasets, demonstrating that our method achieves significant
performance improvements compared to state-of-the-art competitors.

---------------

### 20 Jul 2023 | [Boosting Language Models Reasoning with Chain-of-Knowledge Prompting](https://arxiv.org/abs/2306.06427) | [⬇️](https://arxiv.org/pdf/2306.06427)
*Jianing Wang, Qiushi Sun, Nuo Chen, Xiang Li, Ming Gao* 

  Recently, Chain-of-Thought (CoT) prompting has delivered success on complex
reasoning tasks, which aims at designing a simple prompt like ``Let's think
step by step'' or multiple in-context exemplars with well-designed rationales
to elicit Large Language Models (LLMs) to generate intermediate reasoning
steps. However, the generated rationales often come with mistakes, making
unfactual and unfaithful reasoning chains. To mitigate this brittleness, we
propose a novel Chain-of-Knowledge (CoK) prompting, where we aim at eliciting
LLMs to generate explicit pieces of knowledge evidence in the form of structure
triple. This is inspired by our human behaviors, i.e., we can draw a mind map
or knowledge map as the reasoning evidence in the brain before answering a
complex question. Benefiting from CoK, we additionally introduce a
F^2-Verification method to estimate the reliability of the reasoning chains in
terms of factuality and faithfulness. For the unreliable response, the wrong
evidence can be indicated to prompt the LLM to rethink. Extensive experiments
demonstrate that our method can further improve the performance of commonsense,
factual, symbolic, and arithmetic reasoning tasks.

---------------

### 19 Feb 2024 | [It's Not Easy Being Wrong: Large Language Models Struggle with Process  of Elimination Reasoning](https://arxiv.org/abs/2311.07532) | [⬇️](https://arxiv.org/pdf/2311.07532)
*Nishant Balepur, Shramay Palta, Rachel Rudinger* 

  Chain-of-thought (COT) prompting can help large language models (LLMs) reason
toward correct answers, but its efficacy in reasoning toward incorrect answers
is unexplored. This process of elimination (PoE), when used with COT, can
enhance self-consistency, interpretability, and tasks such as medical diagnoses
of exclusion. Thus, we propose PoE with COT, where LLMs must reason toward
incorrect options on multiple-choice questions. We evaluate the ability of
GPT-3.5, LLaMA-2, and Falcon to perform PoE with COT on a total of four
commonsense and scientific reasoning datasets. We find that the strategy of PoE
always underperforms the strategy of choosing the correct answer. The agreement
of these strategies is also lower than the self-consistency of each strategy.
To study these issues further, we conduct error analyses and give suggestions
for future work.

---------------

### 23 Apr 2023 | [Divide and Prompt: Chain of Thought Prompting for Text-to-SQL](https://arxiv.org/abs/2304.11556) | [⬇️](https://arxiv.org/pdf/2304.11556)
*Xiping Liu and Zhao Tan* 

  Chain-of-thought (CoT) prompting combined with large language models (LLMs)
have achieved encouraging results on complex reasoning tasks. Text-to-SQL is a
critical semantic parsing task that converts natural language questions into
SQL statements, involving a complex reasoning process. However, there is little
work about using CoT prompting to activate LLM's reasoning capabilities on
Text-to-SQL tasks. In this work, we propose a new paradigm for prompting
Text-to-SQL tasks, called Divide-and-Prompt, which first divides the task into
subtasks, and then approach each subtask through CoT. We present 3
prompting-based methods to enhance the Text-to-SQL ability of LLMs. Experiments
show that these prompts guide LLMs to generate Text-to-SQL with higher
execution accuracy.

---------------

### 08 Oct 2023 | [Towards Better Chain-of-Thought Prompting Strategies: A Survey](https://arxiv.org/abs/2310.04959) | [⬇️](https://arxiv.org/pdf/2310.04959)
*Zihan Yu, Liang He, Zhen Wu, Xinyu Dai, Jiajun Chen* 

  Chain-of-Thought (CoT), a step-wise and coherent reasoning chain, shows its
impressive strength when used as a prompting strategy for large language models
(LLM). Recent years, the prominent effect of CoT prompting has attracted
emerging research. However, there still lacks of a systematic summary about key
factors of CoT prompting and comprehensive guide for prompts utilizing. For a
deeper understanding about CoT prompting, we survey on a wide range of current
research, presenting a systematic and comprehensive analysis on several factors
that may influence the effect of CoT prompting, and introduce how to better
apply it in different applications under these discussions. We further analyze
the challenges and propose some future directions about CoT prompting. This
survey could provide an overall reference on related research.

---------------

### 09 Jun 2023 | [Leveraging Training Data in Few-Shot Prompting for Numerical Reasoning](https://arxiv.org/abs/2305.18170) | [⬇️](https://arxiv.org/pdf/2305.18170)
*Zhanming Jie, Wei Lu* 

  Chain-of-thought (CoT) prompting with large language models has proven
effective in numerous natural language processing tasks, but designing prompts
that generalize well to diverse problem types can be challenging, especially in
the context of math word problem (MWP) solving. Additionally, it is common to
have a large amount of training data that have a better diversity coverage but
CoT annotations are not available, which limits the use of supervised learning
techniques. To address these issues, we investigate two approaches to leverage
the training data in a few-shot prompting scenario: dynamic program prompting
and program distillation. Our approach is largely inspired by Gao et al.,
(2022), where they proposed to replace the CoT with the programs as the
intermediate reasoning step. Such a prompting strategy allows us to accurately
verify the answer correctness through program execution in MWP solving. Our
dynamic program prompting involves annotating the training data by sampling
correct programs from a large language model, while program distillation
involves adapting a smaller model to the program-annotated training data. Our
experiments on three standard MWP datasets demonstrate the effectiveness of
these approaches, yielding significant improvements over previous baselines for
prompting and fine-tuning. Our results suggest that leveraging a large amount
of training data can improve the generalization ability of prompts and boost
the performance of fine-tuned small models in MWP solving.

---------------

### 14 Nov 2023 | [Empowering Multi-step Reasoning across Languages via Tree-of-Thoughts](https://arxiv.org/abs/2311.08097) | [⬇️](https://arxiv.org/pdf/2311.08097)
*Leonardo Ranaldi, Fabio Massimo Zanzotto* 

  Chain-of-Thought (CoT) prompting empowers the reasoning abilities of Large
Language Models (LLMs), eliciting them to solve complex reasoning tasks
step-by-step. However, with the success of CoT methods, the ability to deliver
multi-step reasoning remains limited to English due to the imbalance in the
distribution of the pre-training data, making the other languages a barrier.
  In this work, we propose a Cross-lingual multi-step reasoning approach,
aiming to align reasoning processes across different languages. In particular,
our method, through a Self-consistent Cross-lingual prompting mechanism
inspired by the Tree-of-Thoughts approach, delivers multi-step reasoning paths
in different languages that, during the steps, lead to the final solution. Our
experimental evaluations show that our method significantly outperforms
existing prompting methods, reducing the number of interactions and achieving
state-of-the-art performance.

---------------

### 25 Jul 2023 | [Analyzing Chain-of-Thought Prompting in Large Language Models via  Gradient-based Feature Attributions](https://arxiv.org/abs/2307.13339) | [⬇️](https://arxiv.org/pdf/2307.13339)
*Skyler Wu, Eric Meng Shen, Charumathi Badrinath, Jiaqi Ma, Himabindu  Lakkaraju* 

  Chain-of-thought (CoT) prompting has been shown to empirically improve the
accuracy of large language models (LLMs) on various question answering tasks.
While understanding why CoT prompting is effective is crucial to ensuring that
this phenomenon is a consequence of desired model behavior, little work has
addressed this; nonetheless, such an understanding is a critical prerequisite
for responsible model deployment. We address this question by leveraging
gradient-based feature attribution methods which produce saliency scores that
capture the influence of input tokens on model output. Specifically, we probe
several open-source LLMs to investigate whether CoT prompting affects the
relative importances they assign to particular input tokens. Our results
indicate that while CoT prompting does not increase the magnitude of saliency
scores attributed to semantically relevant tokens in the prompt compared to
standard few-shot prompting, it increases the robustness of saliency scores to
question perturbations and variations in model output.

---------------

### 01 Jun 2023 | [Towards Understanding Chain-of-Thought Prompting: An Empirical Study of  What Matters](https://arxiv.org/abs/2212.10001) | [⬇️](https://arxiv.org/pdf/2212.10001)
*Boshi Wang, Sewon Min, Xiang Deng, Jiaming Shen, You Wu, Luke  Zettlemoyer, Huan Sun* 

  Chain-of-Thought (CoT) prompting can dramatically improve the multi-step
reasoning abilities of large language models (LLMs). CoT explicitly encourages
the LLM to generate intermediate rationales for solving a problem, by providing
a series of reasoning steps in the demonstrations. Despite its success, there
is still little understanding of what makes CoT prompting effective and which
aspects of the demonstrated reasoning steps contribute to its performance. In
this paper, we show that CoT reasoning is possible even with invalid
demonstrations - prompting with invalid reasoning steps can achieve over 80-90%
of the performance obtained using CoT under various metrics, while still
generating coherent lines of reasoning during inference. Further experiments
show that other aspects of the rationales, such as being relevant to the query
and correctly ordering the reasoning steps, are much more important for
effective CoT reasoning. Overall, these findings both deepen our understanding
of CoT prompting, and open up new questions regarding LLMs' capability to learn
to reason in context.

---------------
**Date:** 16 Feb 2024

**Title:** Can Separators Improve Chain-of-Thought Prompting?

**Abstract Link:** [https://arxiv.org/abs/2402.10645](https://arxiv.org/abs/2402.10645)

**PDF Link:** [https://arxiv.org/pdf/2402.10645](https://arxiv.org/pdf/2402.10645)

---

**Date:** 24 Jun 2023

**Title:** Symbolic Chain-of-Thought Distillation: Small Models Can Also "Think"  Step-by-Step

**Abstract Link:** [https://arxiv.org/abs/2306.14050](https://arxiv.org/abs/2306.14050)

**PDF Link:** [https://arxiv.org/pdf/2306.14050](https://arxiv.org/pdf/2306.14050)

---

**Date:** 02 Nov 2023

**Title:** The Art of SOCRATIC QUESTIONING: Recursive Thinking with Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2305.14999](https://arxiv.org/abs/2305.14999)

**PDF Link:** [https://arxiv.org/pdf/2305.14999](https://arxiv.org/pdf/2305.14999)

---

**Date:** 07 Mar 2023

**Title:** CoTEVer: Chain of Thought Prompting Annotation Toolkit for Explanation  Verification

**Abstract Link:** [https://arxiv.org/abs/2303.03628](https://arxiv.org/abs/2303.03628)

**PDF Link:** [https://arxiv.org/pdf/2303.03628](https://arxiv.org/pdf/2303.03628)

---

**Date:** 11 Dec 2023

**Title:** Get an A in Math: Progressive Rectification Prompting

**Abstract Link:** [https://arxiv.org/abs/2312.06867](https://arxiv.org/abs/2312.06867)

**PDF Link:** [https://arxiv.org/pdf/2312.06867](https://arxiv.org/pdf/2312.06867)

---

**Date:** 10 Jan 2023

**Title:** Chain-of-Thought Prompting Elicits Reasoning in Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2201.11903](https://arxiv.org/abs/2201.11903)

**PDF Link:** [https://arxiv.org/pdf/2201.11903](https://arxiv.org/pdf/2201.11903)

---

**Date:** 16 Apr 2023

**Title:** Least-to-Most Prompting Enables Complex Reasoning in Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2205.10625](https://arxiv.org/abs/2205.10625)

**PDF Link:** [https://arxiv.org/pdf/2205.10625](https://arxiv.org/pdf/2205.10625)

---

**Date:** 01 Jun 2023

**Title:** Teaching Small Language Models to Reason

**Abstract Link:** [https://arxiv.org/abs/2212.08410](https://arxiv.org/abs/2212.08410)

**PDF Link:** [https://arxiv.org/pdf/2212.08410](https://arxiv.org/pdf/2212.08410)

---

**Date:** 07 Mar 2023

**Title:** Self-Consistency Improves Chain of Thought Reasoning in Language Models

**Abstract Link:** [https://arxiv.org/abs/2203.11171](https://arxiv.org/abs/2203.11171)

**PDF Link:** [https://arxiv.org/pdf/2203.11171](https://arxiv.org/pdf/2203.11171)

---

**Date:** 07 Oct 2023

**Title:** Large Language Models as Analogical Reasoners

**Abstract Link:** [https://arxiv.org/abs/2310.01714](https://arxiv.org/abs/2310.01714)

**PDF Link:** [https://arxiv.org/pdf/2310.01714](https://arxiv.org/pdf/2310.01714)

---

**Date:** 16 Nov 2023

**Title:** Graph-Guided Reasoning for Multi-Hop Question Answering in Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2311.09762](https://arxiv.org/abs/2311.09762)

**PDF Link:** [https://arxiv.org/pdf/2311.09762](https://arxiv.org/pdf/2311.09762)

---

**Date:** 23 Oct 2023

**Title:** DialCoT Meets PPO: Decomposing and Exploring Reasoning Paths in Smaller  Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.05074](https://arxiv.org/abs/2310.05074)

**PDF Link:** [https://arxiv.org/pdf/2310.05074](https://arxiv.org/pdf/2310.05074)

---

**Date:** 20 Jul 2023

**Title:** Boosting Language Models Reasoning with Chain-of-Knowledge Prompting

**Abstract Link:** [https://arxiv.org/abs/2306.06427](https://arxiv.org/abs/2306.06427)

**PDF Link:** [https://arxiv.org/pdf/2306.06427](https://arxiv.org/pdf/2306.06427)

---

**Date:** 19 Feb 2024

**Title:** It's Not Easy Being Wrong: Large Language Models Struggle with Process  of Elimination Reasoning

**Abstract Link:** [https://arxiv.org/abs/2311.07532](https://arxiv.org/abs/2311.07532)

**PDF Link:** [https://arxiv.org/pdf/2311.07532](https://arxiv.org/pdf/2311.07532)

---

**Date:** 23 Apr 2023

**Title:** Divide and Prompt: Chain of Thought Prompting for Text-to-SQL

**Abstract Link:** [https://arxiv.org/abs/2304.11556](https://arxiv.org/abs/2304.11556)

**PDF Link:** [https://arxiv.org/pdf/2304.11556](https://arxiv.org/pdf/2304.11556)

---

**Date:** 08 Oct 2023

**Title:** Towards Better Chain-of-Thought Prompting Strategies: A Survey

**Abstract Link:** [https://arxiv.org/abs/2310.04959](https://arxiv.org/abs/2310.04959)

**PDF Link:** [https://arxiv.org/pdf/2310.04959](https://arxiv.org/pdf/2310.04959)

---

**Date:** 09 Jun 2023

**Title:** Leveraging Training Data in Few-Shot Prompting for Numerical Reasoning

**Abstract Link:** [https://arxiv.org/abs/2305.18170](https://arxiv.org/abs/2305.18170)

**PDF Link:** [https://arxiv.org/pdf/2305.18170](https://arxiv.org/pdf/2305.18170)

---

**Date:** 14 Nov 2023

**Title:** Empowering Multi-step Reasoning across Languages via Tree-of-Thoughts

**Abstract Link:** [https://arxiv.org/abs/2311.08097](https://arxiv.org/abs/2311.08097)

**PDF Link:** [https://arxiv.org/pdf/2311.08097](https://arxiv.org/pdf/2311.08097)

---

**Date:** 25 Jul 2023

**Title:** Analyzing Chain-of-Thought Prompting in Large Language Models via  Gradient-based Feature Attributions

**Abstract Link:** [https://arxiv.org/abs/2307.13339](https://arxiv.org/abs/2307.13339)

**PDF Link:** [https://arxiv.org/pdf/2307.13339](https://arxiv.org/pdf/2307.13339)

---

**Date:** 01 Jun 2023

**Title:** Towards Understanding Chain-of-Thought Prompting: An Empirical Study of  What Matters

**Abstract Link:** [https://arxiv.org/abs/2212.10001](https://arxiv.org/abs/2212.10001)

**PDF Link:** [https://arxiv.org/pdf/2212.10001](https://arxiv.org/pdf/2212.10001)

---

