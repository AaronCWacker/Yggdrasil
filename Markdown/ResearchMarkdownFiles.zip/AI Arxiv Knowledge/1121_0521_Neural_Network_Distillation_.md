Neural Network Distillation 🧪

### 🔎 Neural Network Distillation 🧪


===============================

This is a simple implementation of Neural Network Distillation.

The code is based on the [official TensorFlow tutorial](https://www.tensorflow.org/tutorials/distillation/teacher_student).

The code is written in Python 3.6 and TensorFlow 1.14.


Requirements
------------

- Python 3.6
- TensorFlow 1.14


Usage
-----

1. Download the [MNIST dataset](http://yann.lecun.com/exdb/mnist/).

2. Run the `distillation.py` script.

```
python distillation.py --teacher_model_path=<path_to_teacher_model> --student_model_path=<path_to_student_model>
```


License
-------

This project is licensed under the MIT License - see the [LICENSE.md](LICENSE.md) file for details.</s>
# 🩺🔍 Search Results
### 01 May 2020 | [Distilling Spikes: Knowledge Distillation in Spiking Neural Networks](https://arxiv.org/abs/2005.00288) | [⬇️](https://arxiv.org/pdf/2005.00288)
*Ravi Kumar Kushawaha, Saurabh Kumar, Biplab Banerjee, Rajbabu  Velmurugan* 

  Spiking Neural Networks (SNN) are energy-efficient computing architectures
that exchange spikes for processing information, unlike classical Artificial
Neural Networks (ANN). Due to this, SNNs are better suited for real-life
deployments. However, similar to ANNs, SNNs also benefit from deeper
architectures to obtain improved performance. Furthermore, like the deep ANNs,
the memory, compute and power requirements of SNNs also increase with model
size, and model compression becomes a necessity. Knowledge distillation is a
model compression technique that enables transferring the learning of a large
machine learning model to a smaller model with minimal loss in performance. In
this paper, we propose techniques for knowledge distillation in spiking neural
networks for the task of image classification. We present ways to distill
spikes from a larger SNN, also called the teacher network, to a smaller one,
also called the student network, while minimally impacting the classification
accuracy. We demonstrate the effectiveness of the proposed method with detailed
experiments on three standard datasets while proposing novel distillation
methodologies and loss functions. We also present a multi-stage knowledge
distillation technique for SNNs using an intermediate network to obtain higher
performance from the student network. Our approach is expected to open up new
avenues for deploying high performing large SNN models on resource-constrained
hardware platforms.

---------------

### 03 Jan 2021 | [Neural network algorithm and its application in temperature control of  distillation tower](https://arxiv.org/abs/2101.00582) | [⬇️](https://arxiv.org/pdf/2101.00582)
*Ningrui Zhao, Jinwei Lu* 

  Distillation process is a complex process of conduction, mass transfer and
heat conduction, which is mainly manifested as follows: The mechanism is
complex and changeable with uncertainty; the process is multivariate and strong
coupling; the system is nonlinear, hysteresis and time-varying. Neural networks
can perform effective learning based on corresponding samples, do not rely on
fixed mechanisms, have the ability to approximate arbitrary nonlinear mappings,
and can be used to establish system input and output models. The temperature
system of the rectification tower has a complicated structure and high accuracy
requirements. The neural network is used to control the temperature of the
system, which satisfies the requirements of the production process. This
article briefly describes the basic concepts and research progress of neural
network and distillation tower temperature control, and systematically
summarizes the application of neural network in distillation tower control,
aiming to provide reference for the development of related industries.

---------------

### 31 Oct 2019 | [Distilling Pixel-Wise Feature Similarities for Semantic Segmentation](https://arxiv.org/abs/1910.14226) | [⬇️](https://arxiv.org/pdf/1910.14226)
*Yuhu Shan* 

  Among the neural network compression techniques, knowledge distillation is an
effective one which forces a simpler student network to mimic the output of a
larger teacher network. However, most of such model distillation methods focus
on the image-level classification task. Directly adapting these methods to the
task of semantic segmentation only brings marginal improvements. In this paper,
we propose a simple, yet effective knowledge representation referred to as
pixel-wise feature similarities (PFS) to tackle the challenging distillation
problem of semantic segmentation. The developed PFS encodes spatial structural
information for each pixel location of the high-level convolutional features,
which helps guide the distillation process in an easier way. Furthermore, a
novel weighted pixel-level soft prediction imitation approach is proposed to
enable the student network to selectively mimic the teacher network's output,
according to their pixel-wise knowledge-gaps. Extensive experiments are
conducted on the challenging datasets of Pascal VOC 2012, ADE20K and Pascal
Context. Our approach brings significant performance improvements compared to
several strong baselines and achieves new state-of-the-art results.

---------------

### 08 Feb 2024 | [Classifying Nodes in Graphs without GNNs](https://arxiv.org/abs/2402.05934) | [⬇️](https://arxiv.org/pdf/2402.05934)
*Daniel Winter, Niv Cohen, Yedid Hoshen* 

  Graph neural networks (GNNs) are the dominant paradigm for classifying nodes
in a graph, but they have several undesirable attributes stemming from their
message passing architecture. Recently, distillation methods succeeded in
eliminating the use of GNNs at test time but they still require them during
training. We perform a careful analysis of the role that GNNs play in
distillation methods. This analysis leads us to propose a fully GNN-free
approach for node classification, not requiring them at train or test time. Our
method consists of three key components: smoothness constraints,
pseudo-labeling iterations and neighborhood-label histograms. Our final
approach can match the state-of-the-art accuracy on standard popular benchmarks
such as citation and co-purchase networks, without training a GNN.

---------------

### 07 Jun 2021 | [Zero-Shot Knowledge Distillation from a Decision-Based Black-Box Model](https://arxiv.org/abs/2106.03310) | [⬇️](https://arxiv.org/pdf/2106.03310)
*Zi Wang* 

  Knowledge distillation (KD) is a successful approach for deep neural network
acceleration, with which a compact network (student) is trained by mimicking
the softmax output of a pre-trained high-capacity network (teacher). In
tradition, KD usually relies on access to the training samples and the
parameters of the white-box teacher to acquire the transferred knowledge.
However, these prerequisites are not always realistic due to storage costs or
privacy issues in real-world applications. Here we propose the concept of
decision-based black-box (DB3) knowledge distillation, with which the student
is trained by distilling the knowledge from a black-box teacher (parameters are
not accessible) that only returns classes rather than softmax outputs. We start
with the scenario when the training set is accessible. We represent a sample's
robustness against other classes by computing its distances to the teacher's
decision boundaries and use it to construct the soft label for each training
sample. After that, the student can be trained via standard KD. We then extend
this approach to a more challenging scenario in which even accessing the
training data is not feasible. We propose to generate pseudo samples
distinguished by the teacher's decision boundaries to the largest extent and
construct soft labels for them, which are used as the transfer set. We evaluate
our approaches on various benchmark networks and datasets and experiment
results demonstrate their effectiveness. Codes are available at:
https://github.com/zwang84/zsdb3kd.

---------------

### 28 Apr 2021 | [Interpretable Embedding Procedure Knowledge Transfer via Stacked  Principal Component Analysis and Graph Neural Network](https://arxiv.org/abs/2104.13561) | [⬇️](https://arxiv.org/pdf/2104.13561)
*Seunghyun Lee, Byung Cheol Song* 

  Knowledge distillation (KD) is one of the most useful techniques for
light-weight neural networks. Although neural networks have a clear purpose of
embedding datasets into the low-dimensional space, the existing knowledge was
quite far from this purpose and provided only limited information. We argue
that good knowledge should be able to interpret the embedding procedure. This
paper proposes a method of generating interpretable embedding procedure (IEP)
knowledge based on principal component analysis, and distilling it based on a
message passing neural network. Experimental results show that the student
network trained by the proposed KD method improves 2.28% in the CIFAR100
dataset, which is higher performance than the state-of-the-art (SOTA) method.
We also demonstrate that the embedding procedure knowledge is interpretable via
visualization of the proposed KD process. The implemented code is available at
https://github.com/sseung0703/IEPKT.

---------------

### 20 Oct 2020 | [Knowledge Distillation in Wide Neural Networks: Risk Bound, Data  Efficiency and Imperfect Teacher](https://arxiv.org/abs/2010.10090) | [⬇️](https://arxiv.org/pdf/2010.10090)
*Guangda Ji, Zhanxing Zhu* 

  Knowledge distillation is a strategy of training a student network with guide
of the soft output from a teacher network. It has been a successful method of
model compression and knowledge transfer. However, currently knowledge
distillation lacks a convincing theoretical understanding. On the other hand,
recent finding on neural tangent kernel enables us to approximate a wide neural
network with a linear model of the network's random features. In this paper, we
theoretically analyze the knowledge distillation of a wide neural network.
First we provide a transfer risk bound for the linearized model of the network.
Then we propose a metric of the task's training difficulty, called data
inefficiency. Based on this metric, we show that for a perfect teacher, a high
ratio of teacher's soft labels can be beneficial. Finally, for the case of
imperfect teacher, we find that hard labels can correct teacher's wrong
prediction, which explains the practice of mixing hard and soft labels.

---------------

### 02 Oct 2019 | [Distillation $\approx$ Early Stopping? Harvesting Dark Knowledge  Utilizing Anisotropic Information Retrieval For Overparameterized Neural  Network](https://arxiv.org/abs/1910.01255) | [⬇️](https://arxiv.org/pdf/1910.01255)
*Bin Dong, Jikai Hou, Yiping Lu, Zhihua Zhang* 

  Distillation is a method to transfer knowledge from one model to another and
often achieves higher accuracy with the same capacity. In this paper, we aim to
provide a theoretical understanding on what mainly helps with the distillation.
Our answer is "early stopping". Assuming that the teacher network is
overparameterized, we argue that the teacher network is essentially harvesting
dark knowledge from the data via early stopping. This can be justified by a new
concept, {Anisotropic Information Retrieval (AIR)}, which means that the neural
network tends to fit the informative information first and the non-informative
information (including noise) later. Motivated by the recent development on
theoretically analyzing overparameterized neural networks, we can characterize
AIR by the eigenspace of the Neural Tangent Kernel(NTK). AIR facilities a new
understanding of distillation. With that, we further utilize distillation to
refine noisy labels. We propose a self-distillation algorithm to sequentially
distill knowledge from the network in the previous training epoch to avoid
memorizing the wrong labels. We also demonstrate, both theoretically and
empirically, that self-distillation can benefit from more than just early
stopping. Theoretically, we prove convergence of the proposed algorithm to the
ground truth labels for randomly initialized overparameterized neural networks
in terms of $\ell_2$ distance, while the previous result was on convergence in
$0$-$1$ loss. The theoretical result ensures the learned neural network enjoy a
margin on the training data which leads to better generalization. Empirically,
we achieve better testing accuracy and entirely avoid early stopping which
makes the algorithm more user-friendly.

---------------

### 19 Nov 2018 | [Self-Referenced Deep Learning](https://arxiv.org/abs/1811.07598) | [⬇️](https://arxiv.org/pdf/1811.07598)
*Xu Lan, Xiatian Zhu, Shaogang Gong* 

  Knowledge distillation is an effective approach to transferring knowledge
from a teacher neural network to a student target network for satisfying the
low-memory and fast running requirements in practice use. Whilst being able to
create stronger target networks compared to the vanilla non-teacher based
learning strategy, this scheme needs to train additionally a large teacher
model with expensive computational cost. In this work, we present a
Self-Referenced Deep Learning (SRDL) strategy. Unlike both vanilla optimisation
and existing knowledge distillation, SRDL distils the knowledge discovered by
the in-training target model back to itself to regularise the subsequent
learning procedure therefore eliminating the need for training a large teacher
model. SRDL improves the model generalisation performance compared to vanilla
learning and conventional knowledge distillation approaches with negligible
extra computational cost. Extensive evaluations show that a variety of deep
networks benefit from SRDL resulting in enhanced deployment performance on both
coarse-grained object categorisation tasks (CIFAR10, CIFAR100, Tiny ImageNet,
and ImageNet) and fine-grained person instance identification tasks
(Market-1501).

---------------

### 06 Feb 2021 | [Study on the simulation control of neural network algorithm in thermally  coupled distillation](https://arxiv.org/abs/2102.03506) | [⬇️](https://arxiv.org/pdf/2102.03506)
*ZhaoLan Zheng, Yu Qi* 

  Thermally coupled distillation is a new energy-saving method, but the
traditional thermally coupled distillation simulation calculation process is
complicated, and the optimization method based on the traditional simulation
process is difficult to obtain a good feasible solution. The neural network
algorithm has the advantages of fast learning and can approach nonlinear
functions arbitrarily. For the problems in complex process control systems,
neural network control does not require cumbersome control structures or
precise mathematical models. When training the network, only the input and
output samples it needs are given, so that the dynamics of the system can be
controlled. Performance is approaching. This method can effectively solve the
mathematical model of the thermally coupled distillation process, and quickly
obtain the solution of the optimized variables and the objective function. This
article summarizes the research progress of artificial neural network and the
optimization control of thermally coupled distillation and the application of
neural network in thermally coupled distillation.

---------------

### 02 Jun 2023 | [Privacy Distillation: Reducing Re-identification Risk of Multimodal  Diffusion Models](https://arxiv.org/abs/2306.01322) | [⬇️](https://arxiv.org/pdf/2306.01322)
*Virginia Fernandez, Pedro Sanchez, Walter Hugo Lopez Pinaya, Grzegorz  Jacenk\'ow, Sotirios A. Tsaftaris, Jorge Cardoso* 

  Knowledge distillation in neural networks refers to compressing a large model
or dataset into a smaller version of itself. We introduce Privacy Distillation,
a framework that allows a text-to-image generative model to teach another model
without exposing it to identifiable data. Here, we are interested in the
privacy issue faced by a data provider who wishes to share their data via a
multimodal generative model. A question that immediately arises is ``How can a
data provider ensure that the generative model is not leaking identifiable
information about a patient?''. Our solution consists of (1) training a first
diffusion model on real data (2) generating a synthetic dataset using this
model and filtering it to exclude images with a re-identifiability risk (3)
training a second diffusion model on the filtered synthetic data only. We
showcase that datasets sampled from models trained with privacy distillation
can effectively reduce re-identification risk whilst maintaining downstream
performance.

---------------

### 21 Feb 2023 | [What Makes a "Good" Data Augmentation in Knowledge Distillation -- A  Statistical Perspective](https://arxiv.org/abs/2012.02909) | [⬇️](https://arxiv.org/pdf/2012.02909)
*Huan Wang, Suhas Lohit, Mike Jones, Yun Fu* 

  Knowledge distillation (KD) is a general neural network training approach
that uses a teacher model to guide the student model. Existing works mainly
study KD from the network output side (e.g., trying to design a better KD loss
function), while few have attempted to understand it from the input side.
Especially, its interplay with data augmentation (DA) has not been well
understood. In this paper, we ask: Why do some DA schemes (e.g., CutMix)
inherently perform much better than others in KD? What makes a "good" DA in KD?
Our investigation from a statistical perspective suggests that a good DA scheme
should reduce the covariance of the teacher-student cross-entropy. A practical
metric, the stddev of teacher's mean probability (T. stddev), is further
presented and well justified empirically. Besides the theoretical
understanding, we also introduce a new entropy-based data-mixing DA scheme,
CutMixPick, to further enhance CutMix. Extensive empirical studies support our
claims and demonstrate how we can harvest considerable performance gains simply
by using a better DA scheme in knowledge distillation.

---------------

### 01 Aug 2019 | [Similarity-Preserving Knowledge Distillation](https://arxiv.org/abs/1907.09682) | [⬇️](https://arxiv.org/pdf/1907.09682)
*Frederick Tung, Greg Mori* 

  Knowledge distillation is a widely applicable technique for training a
student neural network under the guidance of a trained teacher network. For
example, in neural network compression, a high-capacity teacher is distilled to
train a compact student; in privileged learning, a teacher trained with
privileged data is distilled to train a student without access to that data.
The distillation loss determines how a teacher's knowledge is captured and
transferred to the student. In this paper, we propose a new form of knowledge
distillation loss that is inspired by the observation that semantically similar
inputs tend to elicit similar activation patterns in a trained network.
Similarity-preserving knowledge distillation guides the training of a student
network such that input pairs that produce similar (dissimilar) activations in
the teacher network produce similar (dissimilar) activations in the student
network. In contrast to previous distillation methods, the student is not
required to mimic the representation space of the teacher, but rather to
preserve the pairwise similarities in its own representation space. Experiments
on three public datasets demonstrate the potential of our approach.

---------------

### 17 Nov 2022 | [CoupleFace: Relation Matters for Face Recognition Distillation](https://arxiv.org/abs/2204.05502) | [⬇️](https://arxiv.org/pdf/2204.05502)
*Jiaheng Liu, Haoyu Qin, Yichao Wu, Jinyang Guo, Ding Liang, Ke Xu* 

  Knowledge distillation is an effective method to improve the performance of a
lightweight neural network (i.e., student model) by transferring the knowledge
of a well-performed neural network (i.e., teacher model), which has been widely
applied in many computer vision tasks, including face recognition.
Nevertheless, the current face recognition distillation methods usually utilize
the Feature Consistency Distillation (FCD) (e.g., L2 distance) on the learned
embeddings extracted by the teacher and student models for each sample, which
is not able to fully transfer the knowledge from the teacher to the student for
face recognition. In this work, we observe that mutual relation knowledge
between samples is also important to improve the discriminative ability of the
learned representation of the student model, and propose an effective face
recognition distillation method called CoupleFace by additionally introducing
the Mutual Relation Distillation (MRD) into existing distillation framework.
Specifically, in MRD, we first propose to mine the informative mutual
relations, and then introduce the Relation-Aware Distillation (RAD) loss to
transfer the mutual relation knowledge of the teacher model to the student
model. Extensive experimental results on multiple benchmark datasets
demonstrate the effectiveness of our proposed CoupleFace for face recognition.
Moreover, based on our proposed CoupleFace, we have won the first place in the
ICCV21 Masked Face Recognition Challenge (MS1M track).

---------------

### 24 Oct 2021 | [Adaptive Distillation: Aggregating Knowledge from Multiple Paths for  Efficient Distillation](https://arxiv.org/abs/2110.09674) | [⬇️](https://arxiv.org/pdf/2110.09674)
*Sumanth Chennupati, Mohammad Mahdi Kamani, Zhongwei Cheng, Lin Chen* 

  Knowledge Distillation is becoming one of the primary trends among neural
network compression algorithms to improve the generalization performance of a
smaller student model with guidance from a larger teacher model. This momentous
rise in applications of knowledge distillation is accompanied by the
introduction of numerous algorithms for distilling the knowledge such as soft
targets and hint layers. Despite this advancement in different techniques for
distilling the knowledge, the aggregation of different paths for distillation
has not been studied comprehensively. This is of particular significance, not
only because different paths have different importance, but also due to the
fact that some paths might have negative effects on the generalization
performance of the student model. Hence, we need to adaptively adjust the
importance of each path to maximize the impact of distillation on the student
model. In this paper, we explore different approaches for aggregating these
different paths and introduce our proposed adaptive approach based on multitask
learning methods. We empirically demonstrate the effectiveness of the proposed
approach over other baselines on the applications of knowledge distillation in
classification, semantic segmentation, and object detection tasks.

---------------

### 16 May 2023 | [Lightweight Self-Knowledge Distillation with Multi-source Information  Fusion](https://arxiv.org/abs/2305.09183) | [⬇️](https://arxiv.org/pdf/2305.09183)
*Xucong Wang, Pengchao Han, Lei Guo* 

  Knowledge Distillation (KD) is a powerful technique for transferring
knowledge between neural network models, where a pre-trained teacher model is
used to facilitate the training of the target student model. However, the
availability of a suitable teacher model is not always guaranteed. To address
this challenge, Self-Knowledge Distillation (SKD) attempts to construct a
teacher model from itself. Existing SKD methods add Auxiliary Classifiers (AC)
to intermediate layers of the model or use the history models and models with
different input data within the same class. However, these methods are
computationally expensive and only capture time-wise and class-wise features of
data. In this paper, we propose a lightweight SKD framework that utilizes
multi-source information to construct a more informative teacher. Specifically,
we introduce a Distillation with Reverse Guidance (DRG) method that considers
different levels of information extracted by the model, including edge, shape,
and detail of the input data, to construct a more informative teacher.
Additionally, we design a Distillation with Shape-wise Regularization (DSR)
method that ensures a consistent shape of ranked model output for all data. We
validate the performance of the proposed DRG, DSR, and their combination
through comprehensive experiments on various datasets and models. Our results
demonstrate the superiority of the proposed methods over baselines (up to
2.87%) and state-of-the-art SKD methods (up to 1.15%), while being
computationally efficient and robust. The code is available at
https://github.com/xucong-parsifal/LightSKD.

---------------

### 27 Jan 2022 | [Dynamic Rectification Knowledge Distillation](https://arxiv.org/abs/2201.11319) | [⬇️](https://arxiv.org/pdf/2201.11319)
*Fahad Rahman Amik, Ahnaf Ismat Tasin, Silvia Ahmed, M. M. Lutfe Elahi,  Nabeel Mohammed* 

  Knowledge Distillation is a technique which aims to utilize dark knowledge to
compress and transfer information from a vast, well-trained neural network
(teacher model) to a smaller, less capable neural network (student model) with
improved inference efficiency. This approach of distilling knowledge has gained
popularity as a result of the prohibitively complicated nature of such
cumbersome models for deployment on edge computing devices. Generally, the
teacher models used to teach smaller student models are cumbersome in nature
and expensive to train. To eliminate the necessity for a cumbersome teacher
model completely, we propose a simple yet effective knowledge distillation
framework that we termed Dynamic Rectification Knowledge Distillation (DR-KD).
Our method transforms the student into its own teacher, and if the self-teacher
makes wrong predictions while distilling information, the error is rectified
prior to the knowledge being distilled. Specifically, the teacher targets are
dynamically tweaked by the agency of ground-truth while distilling the
knowledge gained from traditional training. Our proposed DR-KD performs
remarkably well in the absence of a sophisticated cumbersome teacher model and
achieves comparable performance to existing state-of-the-art teacher-free
knowledge distillation frameworks when implemented by a low-cost dynamic
mannered teacher. Our approach is all-encompassing and can be utilized for any
deep neural network training that requires categorization or object
recognition. DR-KD enhances the test accuracy on Tiny ImageNet by 2.65% over
prominent baseline models, which is significantly better than any other
knowledge distillation approach while requiring no additional training costs.

---------------

### 27 Jun 2022 | [Energy-efficient Knowledge Distillation for Spiking Neural Networks](https://arxiv.org/abs/2106.07172) | [⬇️](https://arxiv.org/pdf/2106.07172)
*Dongjin Lee, Seongsik Park, Jongwan Kim, Wuhyeong Doh, Sungroh Yoon* 

  Spiking neural networks (SNNs) have been gaining interest as energy-efficient
alternatives of conventional artificial neural networks (ANNs) due to their
event-driven computation. Considering the future deployment of SNN models to
constrained neuromorphic devices, many studies have applied techniques
originally used for ANN model compression, such as network quantization,
pruning, and knowledge distillation, to SNNs. Among them, existing works on
knowledge distillation reported accuracy improvements of student SNN model.
However, analysis on energy efficiency, which is also an important feature of
SNN, was absent. In this paper, we thoroughly analyze the performance of the
distilled SNN model in terms of accuracy and energy efficiency. In the process,
we observe a substantial increase in the number of spikes, leading to energy
inefficiency, when using the conventional knowledge distillation methods. Based
on this analysis, to achieve energy efficiency, we propose a novel knowledge
distillation method with heterogeneous temperature parameters. We evaluate our
method on two different datasets and show that the resulting SNN student
satisfies both accuracy improvement and reduction of the number of spikes. On
MNIST dataset, our proposed student SNN achieves up to 0.09% higher accuracy
and produces 65% less spikes compared to the student SNN trained with
conventional knowledge distillation method. We also compare the results with
other SNN compression techniques and training methods.

---------------

### 18 Mar 2022 | [A Closer Look at Knowledge Distillation with Features, Logits, and  Gradients](https://arxiv.org/abs/2203.10163) | [⬇️](https://arxiv.org/pdf/2203.10163)
*Yen-Chang Hsu, James Smith, Yilin Shen, Zsolt Kira, Hongxia Jin* 

  Knowledge distillation (KD) is a substantial strategy for transferring
learned knowledge from one neural network model to another. A vast number of
methods have been developed for this strategy. While most method designs a more
efficient way to facilitate knowledge transfer, less attention has been put on
comparing the effect of knowledge sources such as features, logits, and
gradients. This work provides a new perspective to motivate a set of knowledge
distillation strategies by approximating the classical KL-divergence criteria
with different knowledge sources, making a systematic comparison possible in
model compression and incremental learning. Our analysis indicates that logits
are generally a more efficient knowledge source and suggests that having
sufficient feature dimensions is crucial for the model design, providing a
practical guideline for effective KD-based transfer learning.

---------------

### 10 Apr 2021 | [Data-Free Knowledge Distillation with Soft Targeted Transfer Set  Synthesis](https://arxiv.org/abs/2104.04868) | [⬇️](https://arxiv.org/pdf/2104.04868)
*Zi Wang* 

  Knowledge distillation (KD) has proved to be an effective approach for deep
neural network compression, which learns a compact network (student) by
transferring the knowledge from a pre-trained, over-parameterized network
(teacher). In traditional KD, the transferred knowledge is usually obtained by
feeding training samples to the teacher network to obtain the class
probabilities. However, the original training dataset is not always available
due to storage costs or privacy issues. In this study, we propose a novel
data-free KD approach by modeling the intermediate feature space of the teacher
with a multivariate normal distribution and leveraging the soft targeted labels
generated by the distribution to synthesize pseudo samples as the transfer set.
Several student networks trained with these synthesized transfer sets present
competitive performance compared to the networks trained with the original
training set and other data-free KD approaches.

---------------
**Date:** 01 May 2020

**Title:** Distilling Spikes: Knowledge Distillation in Spiking Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2005.00288](https://arxiv.org/abs/2005.00288)

**PDF Link:** [https://arxiv.org/pdf/2005.00288](https://arxiv.org/pdf/2005.00288)

---

**Date:** 03 Jan 2021

**Title:** Neural network algorithm and its application in temperature control of  distillation tower

**Abstract Link:** [https://arxiv.org/abs/2101.00582](https://arxiv.org/abs/2101.00582)

**PDF Link:** [https://arxiv.org/pdf/2101.00582](https://arxiv.org/pdf/2101.00582)

---

**Date:** 31 Oct 2019

**Title:** Distilling Pixel-Wise Feature Similarities for Semantic Segmentation

**Abstract Link:** [https://arxiv.org/abs/1910.14226](https://arxiv.org/abs/1910.14226)

**PDF Link:** [https://arxiv.org/pdf/1910.14226](https://arxiv.org/pdf/1910.14226)

---

**Date:** 08 Feb 2024

**Title:** Classifying Nodes in Graphs without GNNs

**Abstract Link:** [https://arxiv.org/abs/2402.05934](https://arxiv.org/abs/2402.05934)

**PDF Link:** [https://arxiv.org/pdf/2402.05934](https://arxiv.org/pdf/2402.05934)

---

**Date:** 07 Jun 2021

**Title:** Zero-Shot Knowledge Distillation from a Decision-Based Black-Box Model

**Abstract Link:** [https://arxiv.org/abs/2106.03310](https://arxiv.org/abs/2106.03310)

**PDF Link:** [https://arxiv.org/pdf/2106.03310](https://arxiv.org/pdf/2106.03310)

---

**Date:** 28 Apr 2021

**Title:** Interpretable Embedding Procedure Knowledge Transfer via Stacked  Principal Component Analysis and Graph Neural Network

**Abstract Link:** [https://arxiv.org/abs/2104.13561](https://arxiv.org/abs/2104.13561)

**PDF Link:** [https://arxiv.org/pdf/2104.13561](https://arxiv.org/pdf/2104.13561)

---

**Date:** 20 Oct 2020

**Title:** Knowledge Distillation in Wide Neural Networks: Risk Bound, Data  Efficiency and Imperfect Teacher

**Abstract Link:** [https://arxiv.org/abs/2010.10090](https://arxiv.org/abs/2010.10090)

**PDF Link:** [https://arxiv.org/pdf/2010.10090](https://arxiv.org/pdf/2010.10090)

---

**Date:** 02 Oct 2019

**Title:** Distillation $\approx$ Early Stopping? Harvesting Dark Knowledge  Utilizing Anisotropic Information Retrieval For Overparameterized Neural  Network

**Abstract Link:** [https://arxiv.org/abs/1910.01255](https://arxiv.org/abs/1910.01255)

**PDF Link:** [https://arxiv.org/pdf/1910.01255](https://arxiv.org/pdf/1910.01255)

---

**Date:** 19 Nov 2018

**Title:** Self-Referenced Deep Learning

**Abstract Link:** [https://arxiv.org/abs/1811.07598](https://arxiv.org/abs/1811.07598)

**PDF Link:** [https://arxiv.org/pdf/1811.07598](https://arxiv.org/pdf/1811.07598)

---

**Date:** 06 Feb 2021

**Title:** Study on the simulation control of neural network algorithm in thermally  coupled distillation

**Abstract Link:** [https://arxiv.org/abs/2102.03506](https://arxiv.org/abs/2102.03506)

**PDF Link:** [https://arxiv.org/pdf/2102.03506](https://arxiv.org/pdf/2102.03506)

---

**Date:** 02 Jun 2023

**Title:** Privacy Distillation: Reducing Re-identification Risk of Multimodal  Diffusion Models

**Abstract Link:** [https://arxiv.org/abs/2306.01322](https://arxiv.org/abs/2306.01322)

**PDF Link:** [https://arxiv.org/pdf/2306.01322](https://arxiv.org/pdf/2306.01322)

---

**Date:** 21 Feb 2023

**Title:** What Makes a "Good" Data Augmentation in Knowledge Distillation -- A  Statistical Perspective

**Abstract Link:** [https://arxiv.org/abs/2012.02909](https://arxiv.org/abs/2012.02909)

**PDF Link:** [https://arxiv.org/pdf/2012.02909](https://arxiv.org/pdf/2012.02909)

---

**Date:** 01 Aug 2019

**Title:** Similarity-Preserving Knowledge Distillation

**Abstract Link:** [https://arxiv.org/abs/1907.09682](https://arxiv.org/abs/1907.09682)

**PDF Link:** [https://arxiv.org/pdf/1907.09682](https://arxiv.org/pdf/1907.09682)

---

**Date:** 17 Nov 2022

**Title:** CoupleFace: Relation Matters for Face Recognition Distillation

**Abstract Link:** [https://arxiv.org/abs/2204.05502](https://arxiv.org/abs/2204.05502)

**PDF Link:** [https://arxiv.org/pdf/2204.05502](https://arxiv.org/pdf/2204.05502)

---

**Date:** 24 Oct 2021

**Title:** Adaptive Distillation: Aggregating Knowledge from Multiple Paths for  Efficient Distillation

**Abstract Link:** [https://arxiv.org/abs/2110.09674](https://arxiv.org/abs/2110.09674)

**PDF Link:** [https://arxiv.org/pdf/2110.09674](https://arxiv.org/pdf/2110.09674)

---

**Date:** 16 May 2023

**Title:** Lightweight Self-Knowledge Distillation with Multi-source Information  Fusion

**Abstract Link:** [https://arxiv.org/abs/2305.09183](https://arxiv.org/abs/2305.09183)

**PDF Link:** [https://arxiv.org/pdf/2305.09183](https://arxiv.org/pdf/2305.09183)

---

**Date:** 27 Jan 2022

**Title:** Dynamic Rectification Knowledge Distillation

**Abstract Link:** [https://arxiv.org/abs/2201.11319](https://arxiv.org/abs/2201.11319)

**PDF Link:** [https://arxiv.org/pdf/2201.11319](https://arxiv.org/pdf/2201.11319)

---

**Date:** 27 Jun 2022

**Title:** Energy-efficient Knowledge Distillation for Spiking Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2106.07172](https://arxiv.org/abs/2106.07172)

**PDF Link:** [https://arxiv.org/pdf/2106.07172](https://arxiv.org/pdf/2106.07172)

---

**Date:** 18 Mar 2022

**Title:** A Closer Look at Knowledge Distillation with Features, Logits, and  Gradients

**Abstract Link:** [https://arxiv.org/abs/2203.10163](https://arxiv.org/abs/2203.10163)

**PDF Link:** [https://arxiv.org/pdf/2203.10163](https://arxiv.org/pdf/2203.10163)

---

**Date:** 10 Apr 2021

**Title:** Data-Free Knowledge Distillation with Soft Targeted Transfer Set  Synthesis

**Abstract Link:** [https://arxiv.org/abs/2104.04868](https://arxiv.org/abs/2104.04868)

**PDF Link:** [https://arxiv.org/pdf/2104.04868](https://arxiv.org/pdf/2104.04868)

---

