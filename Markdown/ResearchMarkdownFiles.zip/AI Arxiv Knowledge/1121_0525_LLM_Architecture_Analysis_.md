LLM Architecture Analysis 🏗️

### 🔎 LLM Architecture Analysis 🏗️



In this article, we will discuss the architecture analysis of a system. We will learn about the different types of architecture analysis, their importance, and how to perform them.

Architecture analysis is the process of evaluating a software system's architecture to ensure that it meets its functional and non-functional requirements. It is an essential step in the software development lifecycle, as it helps to identify potential issues early on, reducing the risk of costly rework later in the development process.

Types of Architecture Analysis

There are several types of architecture analysis, each with its own focus and objectives. Here are some of the most common types:

1. Static Analysis: This type of analysis involves examining the code and design artifacts without executing the system. It can help identify issues such as code smells, design flaws, and security vulnerabilities.
2. Dynamic Analysis: This type of analysis involves executing the system and observing its behavior. It can help identify issues such as performance bottlenecks, memory leaks, and concurrency issues.
3. Model-Based Analysis: This type of analysis involves creating a model of the system and analyzing it using formal methods. It can help identify issues such as deadlocks, race conditions, and inconsistencies in the design.
4. Scenario-Based Analysis: This type of analysis involves creating scenarios that represent different usage patterns of the system and analyzing the system's behavior under those scenarios. It can help identify issues such as scalability, reliability, and availability.
5. Security Analysis: This type of analysis involves evaluating the system's security posture and identifying potential vulnerabilities. It can help ensure that the system is protected against cyber threats and data breaches.

Importance of Architecture Analysis

Architecture analysis is critical for ensuring the success of a software system. Here are some of the reasons why:

1. Early Detection of Issues: Architecture analysis helps to identify potential issues early on, reducing the risk of costly rework later in the development process.
2. Improved Quality: Architecture analysis helps to ensure that the system meets its functional and non-functional requirements, improving its overall quality.
3. Reduced Risk: Architecture analysis helps to reduce the risk of project failure by identifying potential issues and risks early on.
4. Better Design: Architecture analysis helps to ensure
# 🩺🔍 Search Results
### 31 Dec 2023 | [Viz: A QLoRA-based Copyright Marketplace for Legally Compliant  Generative AI](https://arxiv.org/abs/2401.00503) | [⬇️](https://arxiv.org/pdf/2401.00503)
*Dipankar Sarkar* 

  This paper aims to introduce and analyze the Viz system in a comprehensive
way, a novel system architecture that integrates Quantized Low-Rank Adapters
(QLoRA) to fine-tune large language models (LLM) within a legally compliant and
resource efficient marketplace. Viz represents a significant contribution to
the field of artificial intelligence, particularly in addressing the challenges
of computational efficiency, legal compliance, and economic sustainability in
the utilization and monetization of LLMs. The paper delineates the scholarly
discourse and developments that have informed the creation of Viz, focusing
primarily on the advancements in LLM models, copyright issues in AI training
(NYT case, 2023), and the evolution of model fine-tuning techniques,
particularly low-rank adapters and quantized low-rank adapters, to create a
sustainable and economically compliant framework for LLM utilization. The
economic model it proposes benefits content creators, AI developers, and
end-users, delineating a harmonious integration of technology, economy, and
law, offering a comprehensive solution to the complex challenges of today's AI
landscape.

---------------

### 04 Mar 2024 | [Can LLMs Generate Architectural Design Decisions? -An Exploratory  Empirical study](https://arxiv.org/abs/2403.01709) | [⬇️](https://arxiv.org/pdf/2403.01709)
*Rudra Dhar, Karthik Vaidhyanathan, Vasudeva Varma* 

  Architectural Knowledge Management (AKM) involves the organized handling of
information related to architectural decisions and design within a project or
organization. An essential artifact of AKM is the Architecture Decision Records
(ADR), which documents key design decisions. ADRs are documents that capture
decision context, decision made and various aspects related to a design
decision, thereby promoting transparency, collaboration, and understanding.
Despite their benefits, ADR adoption in software development has been slow due
to challenges like time constraints and inconsistent uptake. Recent
advancements in Large Language Models (LLMs) may help bridge this adoption gap
by facilitating ADR generation. However, the effectiveness of LLM for ADR
generation or understanding is something that has not been explored. To this
end, in this work, we perform an exploratory study that aims to investigate the
feasibility of using LLM for the generation of ADRs given the decision context.
In our exploratory study, we utilize GPT and T5-based models with 0-shot,
few-shot, and fine-tuning approaches to generate the Decision of an ADR given
its Context. Our results indicate that in a 0-shot setting, state-of-the-art
models such as GPT-4 generate relevant and accurate Design Decisions, although
they fall short of human-level performance. Additionally, we observe that more
cost-effective models like GPT-3.5 can achieve similar outcomes in a few-shot
setting, and smaller models such as Flan-T5 can yield comparable results after
fine-tuning. To conclude, this exploratory study suggests that LLM can generate
Design Decisions, but further research is required to attain human-level
generation and establish standardized widespread adoption.

---------------

### 27 Dec 2023 | [PanGu-$\pi$: Enhancing Language Model Architectures via Nonlinearity  Compensation](https://arxiv.org/abs/2312.17276) | [⬇️](https://arxiv.org/pdf/2312.17276)
*Yunhe Wang, Hanting Chen, Yehui Tang, Tianyu Guo, Kai Han, Ying Nie,  Xutao Wang, Hailin Hu, Zheyuan Bai, Yun Wang, Fangcheng Liu, Zhicheng Liu,  Jianyuan Guo, Sinan Zeng, Yinchen Zhang, Qinghua Xu, Qun Liu, Jun Yao, Chao  Xu, Dacheng Tao* 

  The recent trend of large language models (LLMs) is to increase the scale of
both model size (\aka the number of parameters) and dataset to achieve better
generative ability, which is definitely proved by a lot of work such as the
famous GPT and Llama. However, large models often involve massive computational
costs, and practical applications cannot afford such high prices. However, the
method of constructing a strong model architecture for LLMs is rarely
discussed. We first analyze the state-of-the-art language model architectures
and observe the feature collapse problem. Based on the theoretical analysis, we
propose that the nonlinearity is also very important for language models, which
is usually studied in convolutional neural networks for vision tasks. The
series informed activation function is then introduced with tiny calculations
that can be ignored, and an augmented shortcut is further used to enhance the
model nonlinearity. We then demonstrate that the proposed approach is
significantly effective for enhancing the model nonlinearity through carefully
designed ablations; thus, we present a new efficient model architecture for
establishing modern, namely, PanGu-$\pi$. Experiments are then conducted using
the same dataset and training strategy to compare PanGu-$\pi$ with
state-of-the-art LLMs. The results show that PanGu-$\pi$-7B can achieve a
comparable performance to that of benchmarks with about 10\% inference
speed-up, and PanGu-$\pi$-1B can achieve state-of-the-art performance in terms
of accuracy and efficiency. In addition, we have deployed PanGu-$\pi$-7B in the
high-value domains of finance and law, developing an LLM named YunShan for
practical application. The results show that YunShan can surpass other models
with similar scales on benchmarks.

---------------

### 05 Oct 2023 | [Balancing Autonomy and Alignment: A Multi-Dimensional Taxonomy for  Autonomous LLM-powered Multi-Agent Architectures](https://arxiv.org/abs/2310.03659) | [⬇️](https://arxiv.org/pdf/2310.03659)
*Thorsten H\"andler* 

  Large language models (LLMs) have revolutionized the field of artificial
intelligence, endowing it with sophisticated language understanding and
generation capabilities. However, when faced with more complex and
interconnected tasks that demand a profound and iterative thought process, LLMs
reveal their inherent limitations. Autonomous LLM-powered multi-agent systems
represent a strategic response to these challenges. Such systems strive for
autonomously tackling user-prompted goals by decomposing them into manageable
tasks and orchestrating their execution and result synthesis through a
collective of specialized intelligent agents. Equipped with LLM-powered
reasoning capabilities, these agents harness the cognitive synergy of
collaborating with their peers, enhanced by leveraging contextual resources
such as tools and datasets. While these architectures hold promising potential
in amplifying AI capabilities, striking the right balance between different
levels of autonomy and alignment remains the crucial challenge for their
effective operation. This paper proposes a comprehensive multi-dimensional
taxonomy, engineered to analyze how autonomous LLM-powered multi-agent systems
balance the dynamic interplay between autonomy and alignment across various
aspects inherent to architectural viewpoints such as goal-driven task
management, agent composition, multi-agent collaboration, and context
interaction. It also includes a domain-ontology model specifying fundamental
architectural concepts. Our taxonomy aims to empower researchers, engineers,
and AI practitioners to systematically analyze the architectural dynamics and
balancing strategies employed by these increasingly prevalent AI systems. The
exploratory taxonomic classification of selected representative LLM-powered
multi-agent systems illustrates its practical utility and reveals potential for
future research and development.

---------------

### 26 Jan 2024 | [Scientific Large Language Models: A Survey on Biological & Chemical  Domains](https://arxiv.org/abs/2401.14656) | [⬇️](https://arxiv.org/pdf/2401.14656)
*Qiang Zhang, Keyang Ding, Tianwen Lyv, Xinda Wang, Qingyu Yin, Yiwen  Zhang, Jing Yu, Yuhao Wang, Xiaotong Li, Zhuoyi Xiang, Xiang Zhuang, Zeyuan  Wang, Ming Qin, Mengyao Zhang, Jinlu Zhang, Jiyu Cui, Renjun Xu, Hongyang  Chen, Xiaohui Fan, Huabin Xing, Huajun Chen* 

  Large Language Models (LLMs) have emerged as a transformative power in
enhancing natural language comprehension, representing a significant stride
toward artificial general intelligence. The application of LLMs extends beyond
conventional linguistic boundaries, encompassing specialized linguistic systems
developed within various scientific disciplines. This growing interest has led
to the advent of scientific LLMs, a novel subclass specifically engineered for
facilitating scientific discovery. As a burgeoning area in the community of AI
for Science, scientific LLMs warrant comprehensive exploration. However, a
systematic and up-to-date survey introducing them is currently lacking. In this
paper, we endeavor to methodically delineate the concept of "scientific
language", whilst providing a thorough review of the latest advancements in
scientific LLMs. Given the expansive realm of scientific disciplines, our
analysis adopts a focused lens, concentrating on the biological and chemical
domains. This includes an in-depth examination of LLMs for textual knowledge,
small molecules, macromolecular proteins, genomic sequences, and their
combinations, analyzing them in terms of model architectures, capabilities,
datasets, and evaluation. Finally, we critically examine the prevailing
challenges and point out promising research directions along with the advances
of LLMs. By offering a comprehensive overview of technical developments in this
field, this survey aspires to be an invaluable resource for researchers
navigating the intricate landscape of scientific LLMs.

---------------

### 25 Oct 2023 | [Is ChatGPT a Good Multi-Party Conversation Solver?](https://arxiv.org/abs/2310.16301) | [⬇️](https://arxiv.org/pdf/2310.16301)
*Chao-Hong Tan, Jia-Chen Gu, Zhen-Hua Ling* 

  Large Language Models (LLMs) have emerged as influential instruments within
the realm of natural language processing; nevertheless, their capacity to
handle multi-party conversations (MPCs) -- a scenario marked by the presence of
multiple interlocutors involved in intricate information exchanges -- remains
uncharted. In this paper, we delve into the potential of generative LLMs such
as ChatGPT and GPT-4 within the context of MPCs. An empirical analysis is
conducted to assess the zero-shot learning capabilities of ChatGPT and GPT-4 by
subjecting them to evaluation across three MPC datasets that encompass five
representative tasks. The findings reveal that ChatGPT's performance on a
number of evaluated MPC tasks leaves much to be desired, whilst GPT-4's results
portend a promising future. Additionally, we endeavor to bolster performance
through the incorporation of MPC structures, encompassing both speaker and
addressee architecture. This study provides an exhaustive evaluation and
analysis of applying generative LLMs to MPCs, casting a light upon the
conception and creation of increasingly effective and robust MPC agents.
Concurrently, this work underscores the challenges implicit in the utilization
of LLMs for MPCs, such as deciphering graphical information flows and
generating stylistically consistent responses.

---------------

### 18 Sep 2023 | [A Study on the Implementation of Generative AI Services Using an  Enterprise Data-Based LLM Application Architecture](https://arxiv.org/abs/2309.01105) | [⬇️](https://arxiv.org/pdf/2309.01105)
*Cheonsu Jeong* 

  This study presents a method for implementing generative AI services by
utilizing the Large Language Models (LLM) application architecture. With recent
advancements in generative AI technology, LLMs have gained prominence across
various domains. In this context, the research addresses the challenge of
information scarcity and proposes specific remedies by harnessing LLM
capabilities. The investigation delves into strategies for mitigating the issue
of inadequate data, offering tailored solutions. The study delves into the
efficacy of employing fine-tuning techniques and direct document integration to
alleviate data insufficiency. A significant contribution of this work is the
development of a Retrieval-Augmented Generation (RAG) model, which tackles the
aforementioned challenges. The RAG model is carefully designed to enhance
information storage and retrieval processes, ensuring improved content
generation. The research elucidates the key phases of the information storage
and retrieval methodology underpinned by the RAG model. A comprehensive
analysis of these steps is undertaken, emphasizing their significance in
addressing the scarcity of data. The study highlights the efficacy of the
proposed method, showcasing its applicability through illustrative instances.
By implementing the RAG model for information storage and retrieval, the
research not only contributes to a deeper comprehension of generative AI
technology but also facilitates its practical usability within enterprises
utilizing LLMs. This work holds substantial value in advancing the field of
generative AI, offering insights into enhancing data-driven content generation
and fostering active utilization of LLM-based services within corporate
settings.

---------------

### 07 Apr 2023 | [Complex QA and language models hybrid architectures, Survey](https://arxiv.org/abs/2302.09051) | [⬇️](https://arxiv.org/pdf/2302.09051)
*Xavier Daull, Patrice Bellot, Emmanuel Bruno, Vincent Martin,  Elisabeth Murisasco* 

  This paper reviews the state-of-the-art of language models architectures and
strategies for "complex" question-answering (QA, CQA, CPS) with a focus on
hybridization. Large Language Models (LLM) are good at leveraging public data
on standard problems but once you want to tackle more specific complex
questions or problems (e.g. How does the concept of personal freedom vary
between different cultures ? What is the best mix of power generation methods
to reduce climate change ?) you may need specific architecture, knowledge,
skills, methods, sensitive data protection, explainability, human approval and
versatile feedback... Recent projects like ChatGPT and GALACTICA have allowed
non-specialists to grasp the great potential as well as the equally strong
limitations of LLM in complex QA. In this paper, we start by reviewing required
skills and evaluation techniques. We integrate findings from the robust
community edited research papers BIG, BLOOM and HELM which open source,
benchmark and analyze limits and challenges of LLM in terms of tasks complexity
and strict evaluation on accuracy (e.g. fairness, robustness, toxicity, ...) as
a baseline. We discuss some challenges associated with complex QA, including
domain adaptation, decomposition and efficient multi-step QA, long form and
non-factoid QA, safety and multi-sensitivity data protection, multimodal
search, hallucinations, explainability and truthfulness, temporal reasoning. We
analyze current solutions and promising research trends, using elements such
as: hybrid LLM architectural patterns, training and prompting strategies,
active human reinforcement learning supervised with AI, neuro-symbolic and
structured knowledge grounding, program synthesis, iterated decomposition and
others.

---------------

### 20 Dec 2023 | [Mini-GPTs: Efficient Large Language Models through Contextual Pruning](https://arxiv.org/abs/2312.12682) | [⬇️](https://arxiv.org/pdf/2312.12682)
*Tim Valicenti, Justice Vidal, Ritik Patnaik* 

  In AI research, the optimization of Large Language Models (LLMs) remains a
significant challenge, crucial for advancing the field's practical applications
and sustainability. Building upon the foundational work of Professor Song Han's
lab at MIT, this paper introduces a novel approach in developing Mini-GPTs via
contextual pruning. Our methodology strategically prunes the computational
architecture of traditional LLMs, like Phi-1.5, focusing on retaining core
functionalities while drastically reducing model sizes. We employ the technique
across diverse and complex datasets, including US law, Medical Q&A, Skyrim
dialogue, English-Taiwanese translation, and Economics articles. The results
underscore the efficiency and effectiveness of contextual pruning, not merely
as a theoretical concept but as a practical tool in developing domain-specific,
resource-efficient LLMs. Contextual pruning is a promising method for building
domain-specific LLMs, and this research is a building block towards future
development with more hardware compute, refined fine-tuning, and quantization.

---------------

### 06 Mar 2024 | [A Prefrontal Cortex-inspired Architecture for Planning in Large Language  Models](https://arxiv.org/abs/2310.00194) | [⬇️](https://arxiv.org/pdf/2310.00194)
*Taylor Webb, Shanka Subhra Mondal, Chi Wang, Brian Krabach, Ida  Momennejad* 

  Large language models (LLMs) demonstrate impressive performance on a wide
variety of tasks, but they often struggle with tasks that require multi-step
reasoning or goal-directed planning. To address this, we take inspiration from
the human brain, in which planning is accomplished via the recurrent
interaction of specialized modules in the prefrontal cortex (PFC). These
modules perform functions such as conflict monitoring, state prediction, state
evaluation, task decomposition, and task coordination. We find that LLMs are
sometimes capable of carrying out these functions in isolation, but struggle to
autonomously coordinate them in the service of a goal. Therefore, we propose a
black box architecture with multiple LLM-based (GPT-4) modules. The
architecture improves planning through the interaction of specialized
PFC-inspired modules that break down a larger problem into multiple brief
automated calls to the LLM. We evaluate the combined architecture on three
challenging planning tasks -- graph traversal, Tower of Hanoi, and logistics --
finding that it yields significant improvements over standard LLM methods
(e.g., zero-shot prompting, in-context learning, and chain-of-thought). These
results demonstrate the benefit of utilizing knowledge from cognitive
neuroscience to improve planning in LLMs.

---------------

### 18 Jan 2024 | [A Survey on Hardware Accelerators for Large Language Models](https://arxiv.org/abs/2401.09890) | [⬇️](https://arxiv.org/pdf/2401.09890)
*Christoforos Kachris* 

  Large Language Models (LLMs) have emerged as powerful tools for natural
language processing tasks, revolutionizing the field with their ability to
understand and generate human-like text. As the demand for more sophisticated
LLMs continues to grow, there is a pressing need to address the computational
challenges associated with their scale and complexity. This paper presents a
comprehensive survey on hardware accelerators designed to enhance the
performance and energy efficiency of Large Language Models. By examining a
diverse range of accelerators, including GPUs, FPGAs, and custom-designed
architectures, we explore the landscape of hardware solutions tailored to meet
the unique computational demands of LLMs. The survey encompasses an in-depth
analysis of architecture, performance metrics, and energy efficiency
considerations, providing valuable insights for researchers, engineers, and
decision-makers aiming to optimize the deployment of LLMs in real-world
applications.

---------------

### 25 Oct 2023 | [LLM Performance Predictors are good initializers for Architecture Search](https://arxiv.org/abs/2310.16712) | [⬇️](https://arxiv.org/pdf/2310.16712)
*Ganesh Jawahar, Muhammad Abdul-Mageed, Laks V. S. Lakshmanan, Dujian  Ding* 

  Large language models (LLMs) have become an integral component in solving a
wide range of NLP tasks. In this work, we explore a novel use case of using
LLMs to build performance predictors (PP): models that, given a specific deep
neural network architecture, predict its performance on a downstream task. We
design PP prompts for LLMs consisting of: (i) role: description of the role
assigned to the LLM, (ii) instructions: set of instructions to be followed by
the LLM to carry out performance prediction, (iii) hyperparameters: a
definition of each architecture-specific hyperparameter and (iv)
demonstrations: sample architectures along with their efficiency metrics and
'training from scratch' performance. For machine translation (MT) tasks, we
discover that GPT-4 with our PP prompts (LLM-PP) can predict the performance of
architecture with a mean absolute error matching the SOTA and a marginal
degradation in rank correlation coefficient compared to SOTA performance
predictors. Further, we show that the predictions from LLM-PP can be distilled
to a small regression model (LLM-Distill-PP). LLM-Distill-PP models
surprisingly retain the performance of LLM-PP largely and can be a
cost-effective alternative for heavy use cases of performance estimation.
Specifically, for neural architecture search (NAS), we propose a Hybrid-Search
algorithm for NAS (HS-NAS), which uses LLM-Distill-PP for the initial part of
search, resorting to the baseline predictor for rest of the search. We show
that HS-NAS performs very similar to SOTA NAS across benchmarks, reduces search
hours by 50% roughly, and in some cases, improves latency, GFLOPs, and model
size.

---------------

### 29 Feb 2024 | [Exploiting Code Symmetries for Learning Program Semantics](https://arxiv.org/abs/2308.03312) | [⬇️](https://arxiv.org/pdf/2308.03312)
*Kexin Pei, Weichen Li, Qirui Jin, Shuyang Liu, Scott Geng, Lorenzo  Cavallaro, Junfeng Yang, Suman Jana* 

  This paper tackles the challenge of teaching code semantics to Large Language
Models (LLMs) for program analysis by incorporating code symmetries into the
model architecture. We introduce a group-theoretic framework that defines code
symmetries as semantics-preserving transformations, where forming a code
symmetry group enables precise and efficient reasoning of code semantics. Our
solution, SymC, develops a novel variant of self-attention that is provably
equivariant to code symmetries from the permutation group defined over the
program dependence graph. SymC obtains superior performance on five program
analysis tasks, outperforming state-of-the-art code models, including GPT-4,
without any pre-training. Our results suggest that code LLMs that encode the
code structural prior via the code symmetry group generalize better and faster.

---------------

### 28 Jul 2023 | [Emotional Intelligence of Large Language Models](https://arxiv.org/abs/2307.09042) | [⬇️](https://arxiv.org/pdf/2307.09042)
*Xuena Wang, Xueting Li, Zi Yin, Yue Wu and Liu Jia* 

  Large Language Models (LLMs) have demonstrated remarkable abilities across
numerous disciplines, primarily assessed through tasks in language generation,
knowledge utilization, and complex reasoning. However, their alignment with
human emotions and values, which is critical for real-world applications, has
not been systematically evaluated. Here, we assessed LLMs' Emotional
Intelligence (EI), encompassing emotion recognition, interpretation, and
understanding, which is necessary for effective communication and social
interactions. Specifically, we first developed a novel psychometric assessment
focusing on Emotion Understanding (EU), a core component of EI, suitable for
both humans and LLMs. This test requires evaluating complex emotions (e.g.,
surprised, joyful, puzzled, proud) in realistic scenarios (e.g., despite
feeling underperformed, John surprisingly achieved a top score). With a
reference frame constructed from over 500 adults, we tested a variety of
mainstream LLMs. Most achieved above-average EQ scores, with GPT-4 exceeding
89% of human participants with an EQ of 117. Interestingly, a multivariate
pattern analysis revealed that some LLMs apparently did not reply on the
human-like mechanism to achieve human-level performance, as their
representational patterns were qualitatively distinct from humans. In addition,
we discussed the impact of factors such as model size, training method, and
architecture on LLMs' EQ. In summary, our study presents one of the first
psychometric evaluations of the human-like characteristics of LLMs, which may
shed light on the future development of LLMs aiming for both high intellectual
and emotional intelligence. Project website:
https://emotional-intelligence.github.io/

---------------

### 15 Jan 2024 | [Stability Analysis of ChatGPT-based Sentiment Analysis in AI Quality  Assurance](https://arxiv.org/abs/2401.07441) | [⬇️](https://arxiv.org/pdf/2401.07441)
*Tinghui Ouyang, AprilPyone MaungMaung, Koichi Konishi, Yoshiki Seo,  and Isao Echizen* 

  In the era of large AI models, the complex architecture and vast parameters
present substantial challenges for effective AI quality management (AIQM), e.g.
large language model (LLM). This paper focuses on investigating the quality
assurance of a specific LLM-based AI product--a ChatGPT-based sentiment
analysis system. The study delves into stability issues related to both the
operation and robustness of the expansive AI model on which ChatGPT is based.
Experimental analysis is conducted using benchmark datasets for sentiment
analysis. The results reveal that the constructed ChatGPT-based sentiment
analysis system exhibits uncertainty, which is attributed to various
operational factors. It demonstrated that the system also exhibits stability
issues in handling conventional small text attacks involving robustness.

---------------

### 28 Nov 2023 | [On the Performance of Multimodal Language Models](https://arxiv.org/abs/2310.03211) | [⬇️](https://arxiv.org/pdf/2310.03211)
*Utsav Garg, Erhan Bas* 

  Instruction-tuned large language models (LLMs) have demonstrated promising
zero-shot generalization capabilities across various downstream tasks. Recent
research has introduced multimodal capabilities to LLMs by integrating
independently pretrained vision encoders through model grafting. These
multimodal variants undergo instruction tuning, similar to LLMs, enabling
effective zero-shot generalization for multimodal tasks. This study conducts a
comparative analysis of different multimodal instruction tuning approaches and
evaluates their performance across a range of tasks, including complex
reasoning, conversation, image captioning, multiple-choice questions (MCQs),
and binary classification. Through rigorous benchmarking and ablation
experiments, we reveal key insights for guiding architectural choices when
incorporating multimodal capabilities into LLMs. However, current approaches
have limitations; they do not sufficiently address the need for a diverse
multimodal instruction dataset, which is crucial for enhancing task
generalization. Additionally, they overlook issues related to truthfulness and
factuality when generating responses. These findings illuminate current
methodological constraints in adapting language models for image comprehension
and provide valuable guidance for researchers and practitioners seeking to
harness multimodal versions of LLMs.

---------------

### 06 Feb 2024 | [Iterative Prompt Refinement for Radiation Oncology Symptom Extraction  Using Teacher-Student Large Language Models](https://arxiv.org/abs/2402.04075) | [⬇️](https://arxiv.org/pdf/2402.04075)
*Reza Khanmohammadi, Ahmed I Ghanem, Kyle Verdecchia, Ryan Hall,  Mohamed Elshaikh, Benjamin Movsas, Hassan Bagher-Ebadian, Indrin Chetty,  Mohammad M. Ghassemi, Kundan Thind* 

  This study introduces a novel teacher-student architecture utilizing Large
Language Models (LLMs) to improve prostate cancer radiotherapy symptom
extraction from clinical notes. Mixtral, the student model, initially extracts
symptoms, followed by GPT-4, the teacher model, which refines prompts based on
Mixtral's performance. This iterative process involved 294 single symptom
clinical notes across 12 symptoms, with up to 16 rounds of refinement per
epoch. Results showed significant improvements in extracting symptoms from both
single and multi-symptom notes. For 59 single symptom notes, accuracy increased
from 0.51 to 0.71, precision from 0.52 to 0.82, recall from 0.52 to 0.72, and
F1 score from 0.49 to 0.73. In 375 multi-symptom notes, accuracy rose from 0.24
to 0.43, precision from 0.6 to 0.76, recall from 0.24 to 0.43, and F1 score
from 0.20 to 0.44. These results demonstrate the effectiveness of advanced
prompt engineering in LLMs for radiation oncology use.

---------------

### 22 Dec 2023 | [Empowering Working Memory for Large Language Model Agents](https://arxiv.org/abs/2312.17259) | [⬇️](https://arxiv.org/pdf/2312.17259)
*Jing Guo, Nan Li, Jianchuan Qi, Hang Yang, Ruiqiao Li, Yuzhen Feng, Si  Zhang, Ming Xu* 

  Large language models (LLMs) have achieved impressive linguistic
capabilities. However, a key limitation persists in their lack of human-like
memory faculties. LLMs exhibit constrained memory retention across sequential
interactions, hindering complex reasoning. This paper explores the potential of
applying cognitive psychology's working memory frameworks, to enhance LLM
architecture. The limitations of traditional LLM memory designs are analyzed,
including their isolation of distinct dialog episodes and lack of persistent
memory links. To address this, an innovative model is proposed incorporating a
centralized Working Memory Hub and Episodic Buffer access to retain memories
across episodes. This architecture aims to provide greater continuity for
nuanced contextual reasoning during intricate tasks and collaborative
scenarios. While promising, further research is required into optimizing
episodic memory encoding, storage, prioritization, retrieval, and security.
Overall, this paper provides a strategic blueprint for developing LLM agents
with more sophisticated, human-like memory capabilities, highlighting memory
mechanisms as a vital frontier in artificial general intelligence.

---------------

### 14 Dec 2023 | [Zebra: Extending Context Window with Layerwise Grouped Local-Global  Attention](https://arxiv.org/abs/2312.08618) | [⬇️](https://arxiv.org/pdf/2312.08618)
*Kaiqiang Song, Xiaoyang Wang, Sangwoo Cho, Xiaoman Pan, Dong Yu* 

  This paper introduces a novel approach to enhance the capabilities of Large
Language Models (LLMs) in processing and understanding extensive text
sequences, a critical aspect in applications requiring deep comprehension and
synthesis of large volumes of information. Recognizing the inherent challenges
in extending the context window for LLMs, primarily built on Transformer
architecture, we propose a new model architecture, referred to as Zebra. This
architecture efficiently manages the quadratic time and memory complexity
issues associated with full attention in the Transformer by employing grouped
local-global attention layers. Our model, akin to a zebra's alternating
stripes, balances local and global attention layers, significantly reducing
computational requirements and memory consumption. Comprehensive experiments,
including pretraining from scratch, continuation of long context adaptation
training, and long instruction tuning, are conducted to evaluate the Zebra's
performance. The results show that Zebra achieves comparable or superior
performance on both short and long sequence benchmarks, while also enhancing
training and inference efficiency.

---------------

### 11 Jan 2024 | [Automatic Semantic Augmentation of Language Model Prompts (for Code  Summarization)](https://arxiv.org/abs/2304.06815) | [⬇️](https://arxiv.org/pdf/2304.06815)
*Toufique Ahmed, Kunal Suresh Pai, Premkumar Devanbu, Earl T. Barr* 

  Large Language Models (LLM) are a new class of computation engines,
"programmed" via prompt engineering. We are still learning how to best
"program" these LLMs to help developers. We start with the intuition that
developers tend to consciously and unconsciously have a collection of semantics
facts in mind when working on coding tasks. Mostly these are shallow, simple
facts arising from a quick read. For a function, examples of facts might
include parameter and local variable names, return expressions, simple pre- and
post-conditions, and basic control and data flow, etc.
  One might assume that the powerful multi-layer architecture of
transformer-style LLMs makes them inherently capable of doing this simple level
of "code analysis" and extracting such information, implicitly, while
processing code: but are they, really? If they aren't, could explicitly adding
this information help? Our goal here is to investigate this question, using the
code summarization task and evaluate whether automatically augmenting an LLM's
prompt with semantic facts explicitly, actually helps.
  Prior work shows that LLM performance on code summarization benefits from
few-shot samples drawn either from the same-project or from examples found via
information retrieval methods (such as BM25). While summarization performance
has steadily increased since the early days, there is still room for
improvement: LLM performance on code summarization still lags its performance
on natural-language tasks like translation and text summarization.
  We find that adding semantic facts actually does help! This approach improves
performance in several different settings suggested by prior work, including
for two different Large Language Models. In most cases, improvement nears or
exceeds 2 BLEU; for the PHP language in the challenging CodeSearchNet dataset,
this augmentation actually yields performance surpassing 30 BLEU.

---------------
**Date:** 31 Dec 2023

**Title:** Viz: A QLoRA-based Copyright Marketplace for Legally Compliant  Generative AI

**Abstract Link:** [https://arxiv.org/abs/2401.00503](https://arxiv.org/abs/2401.00503)

**PDF Link:** [https://arxiv.org/pdf/2401.00503](https://arxiv.org/pdf/2401.00503)

---

**Date:** 04 Mar 2024

**Title:** Can LLMs Generate Architectural Design Decisions? -An Exploratory  Empirical study

**Abstract Link:** [https://arxiv.org/abs/2403.01709](https://arxiv.org/abs/2403.01709)

**PDF Link:** [https://arxiv.org/pdf/2403.01709](https://arxiv.org/pdf/2403.01709)

---

**Date:** 27 Dec 2023

**Title:** PanGu-$\pi$: Enhancing Language Model Architectures via Nonlinearity  Compensation

**Abstract Link:** [https://arxiv.org/abs/2312.17276](https://arxiv.org/abs/2312.17276)

**PDF Link:** [https://arxiv.org/pdf/2312.17276](https://arxiv.org/pdf/2312.17276)

---

**Date:** 05 Oct 2023

**Title:** Balancing Autonomy and Alignment: A Multi-Dimensional Taxonomy for  Autonomous LLM-powered Multi-Agent Architectures

**Abstract Link:** [https://arxiv.org/abs/2310.03659](https://arxiv.org/abs/2310.03659)

**PDF Link:** [https://arxiv.org/pdf/2310.03659](https://arxiv.org/pdf/2310.03659)

---

**Date:** 26 Jan 2024

**Title:** Scientific Large Language Models: A Survey on Biological & Chemical  Domains

**Abstract Link:** [https://arxiv.org/abs/2401.14656](https://arxiv.org/abs/2401.14656)

**PDF Link:** [https://arxiv.org/pdf/2401.14656](https://arxiv.org/pdf/2401.14656)

---

**Date:** 25 Oct 2023

**Title:** Is ChatGPT a Good Multi-Party Conversation Solver?

**Abstract Link:** [https://arxiv.org/abs/2310.16301](https://arxiv.org/abs/2310.16301)

**PDF Link:** [https://arxiv.org/pdf/2310.16301](https://arxiv.org/pdf/2310.16301)

---

**Date:** 18 Sep 2023

**Title:** A Study on the Implementation of Generative AI Services Using an  Enterprise Data-Based LLM Application Architecture

**Abstract Link:** [https://arxiv.org/abs/2309.01105](https://arxiv.org/abs/2309.01105)

**PDF Link:** [https://arxiv.org/pdf/2309.01105](https://arxiv.org/pdf/2309.01105)

---

**Date:** 07 Apr 2023

**Title:** Complex QA and language models hybrid architectures, Survey

**Abstract Link:** [https://arxiv.org/abs/2302.09051](https://arxiv.org/abs/2302.09051)

**PDF Link:** [https://arxiv.org/pdf/2302.09051](https://arxiv.org/pdf/2302.09051)

---

**Date:** 20 Dec 2023

**Title:** Mini-GPTs: Efficient Large Language Models through Contextual Pruning

**Abstract Link:** [https://arxiv.org/abs/2312.12682](https://arxiv.org/abs/2312.12682)

**PDF Link:** [https://arxiv.org/pdf/2312.12682](https://arxiv.org/pdf/2312.12682)

---

**Date:** 06 Mar 2024

**Title:** A Prefrontal Cortex-inspired Architecture for Planning in Large Language  Models

**Abstract Link:** [https://arxiv.org/abs/2310.00194](https://arxiv.org/abs/2310.00194)

**PDF Link:** [https://arxiv.org/pdf/2310.00194](https://arxiv.org/pdf/2310.00194)

---

**Date:** 18 Jan 2024

**Title:** A Survey on Hardware Accelerators for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2401.09890](https://arxiv.org/abs/2401.09890)

**PDF Link:** [https://arxiv.org/pdf/2401.09890](https://arxiv.org/pdf/2401.09890)

---

**Date:** 25 Oct 2023

**Title:** LLM Performance Predictors are good initializers for Architecture Search

**Abstract Link:** [https://arxiv.org/abs/2310.16712](https://arxiv.org/abs/2310.16712)

**PDF Link:** [https://arxiv.org/pdf/2310.16712](https://arxiv.org/pdf/2310.16712)

---

**Date:** 29 Feb 2024

**Title:** Exploiting Code Symmetries for Learning Program Semantics

**Abstract Link:** [https://arxiv.org/abs/2308.03312](https://arxiv.org/abs/2308.03312)

**PDF Link:** [https://arxiv.org/pdf/2308.03312](https://arxiv.org/pdf/2308.03312)

---

**Date:** 28 Jul 2023

**Title:** Emotional Intelligence of Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2307.09042](https://arxiv.org/abs/2307.09042)

**PDF Link:** [https://arxiv.org/pdf/2307.09042](https://arxiv.org/pdf/2307.09042)

---

**Date:** 15 Jan 2024

**Title:** Stability Analysis of ChatGPT-based Sentiment Analysis in AI Quality  Assurance

**Abstract Link:** [https://arxiv.org/abs/2401.07441](https://arxiv.org/abs/2401.07441)

**PDF Link:** [https://arxiv.org/pdf/2401.07441](https://arxiv.org/pdf/2401.07441)

---

**Date:** 28 Nov 2023

**Title:** On the Performance of Multimodal Language Models

**Abstract Link:** [https://arxiv.org/abs/2310.03211](https://arxiv.org/abs/2310.03211)

**PDF Link:** [https://arxiv.org/pdf/2310.03211](https://arxiv.org/pdf/2310.03211)

---

**Date:** 06 Feb 2024

**Title:** Iterative Prompt Refinement for Radiation Oncology Symptom Extraction  Using Teacher-Student Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.04075](https://arxiv.org/abs/2402.04075)

**PDF Link:** [https://arxiv.org/pdf/2402.04075](https://arxiv.org/pdf/2402.04075)

---

**Date:** 22 Dec 2023

**Title:** Empowering Working Memory for Large Language Model Agents

**Abstract Link:** [https://arxiv.org/abs/2312.17259](https://arxiv.org/abs/2312.17259)

**PDF Link:** [https://arxiv.org/pdf/2312.17259](https://arxiv.org/pdf/2312.17259)

---

**Date:** 14 Dec 2023

**Title:** Zebra: Extending Context Window with Layerwise Grouped Local-Global  Attention

**Abstract Link:** [https://arxiv.org/abs/2312.08618](https://arxiv.org/abs/2312.08618)

**PDF Link:** [https://arxiv.org/pdf/2312.08618](https://arxiv.org/pdf/2312.08618)

---

**Date:** 11 Jan 2024

**Title:** Automatic Semantic Augmentation of Language Model Prompts (for Code  Summarization)

**Abstract Link:** [https://arxiv.org/abs/2304.06815](https://arxiv.org/abs/2304.06815)

**PDF Link:** [https://arxiv.org/pdf/2304.06815](https://arxiv.org/pdf/2304.06815)

---

