Emerging Research Areas 🔮

### 🔎 Emerging Research Areas 🔮



# Emerging Research Areas

## Introduction

The field of machine learning is constantly evolving, with new research areas and techniques emerging all the time. In this section, we will explore some of the most exciting and promising areas of research in machine learning today.

## Deep Learning

Deep learning is a subset of machine learning that uses artificial neural networks with many layers (hence "deep") to learn and represent data. Deep learning has been responsible for many of the recent breakthroughs in areas such as computer vision, natural language processing, and speech recognition.

Deep learning models can learn complex patterns and representations from large amounts of data, making them particularly well-suited for tasks such as image and speech recognition. They have also been used to achieve state-of-the-art performance in areas such as machine translation and game playing.

Despite their success, deep learning models can be computationally expensive to train and require large amounts of data. Research is ongoing to improve the efficiency and scalability of deep learning models, as well as to develop new architectures and techniques for learning and representation.

## Reinforcement Learning

Reinforcement learning is a type of machine learning in which an agent learns to make decisions by interacting with an environment and receiving rewards or penalties. The goal of the agent is to learn a policy that maximizes the expected cumulative reward over time.

Reinforcement learning has been used to solve a wide range of problems, including game playing, robotics, and control systems. It has also been used to develop intelligent agents that can learn to perform tasks autonomously, such as driving a car or flying a drone.

One of the challenges of reinforcement learning is the trade-off between exploration and exploitation. The agent must balance the need to explore the environment and try new actions with the need to exploit what it has already learned in order to maximize reward. Research is ongoing to develop new algorithms and techniques for addressing this challenge and improving the efficiency and effectiveness of reinforcement learning.

## Transfer Learning

Transfer learning is a type of machine learning in which a model trained on one task is reused as the starting point for a model on a second task. The idea is to leverage the knowledge and representations learned by the first model in order to improve the performance of the second model.

Transfer learning has been shown to be particularly effective in deep learning, where models can learn
# 🩺🔍 Search Results
### 02 Jun 2023 | [Visual Question Answering: A Survey on Techniques and Common Trends in  Recent Literature](https://arxiv.org/abs/2305.11033) | [⬇️](https://arxiv.org/pdf/2305.11033)
*Ana Cl\'audia Akemi Matsuki de Faria, Felype de Castro Bastos, Jos\'e  Victor Nogueira Alves da Silva, Vitor Lopes Fabris, Valeska de Sousa Uchoa,  D\'ecio Gon\c{c}alves de Aguiar Neto, Claudio Filipi Goncalves dos Santos* 

  Visual Question Answering (VQA) is an emerging area of interest for
researches, being a recent problem in natural language processing and image
prediction. In this area, an algorithm needs to answer questions about certain
images. As of the writing of this survey, 25 recent studies were analyzed.
Besides, 6 datasets were analyzed and provided their link to download. In this
work, several recent pieces of research in this area were investigated and a
deeper analysis and comparison among them were provided, including results, the
state-of-the-art, common errors, and possible points of improvement for future
researchers.

---------------

### 03 Sep 2023 | [A Survey on Service Route and Time Prediction in Instant Delivery:  Taxonomy, Progress, and Prospects](https://arxiv.org/abs/2309.01194) | [⬇️](https://arxiv.org/pdf/2309.01194)
*Haomin Wen, Youfang Lin, Lixia Wu, Xiaowei Mao, Tianyue Cai, Yunfeng  Hou, Shengnan Guo, Yuxuan Liang, Guangyin Jin, Yiji Zhao, Roger Zimmermann,  Jieping Ye, Huaiyu Wan* 

  Instant delivery services, such as food delivery and package delivery, have
achieved explosive growth in recent years by providing customers with
daily-life convenience. An emerging research area within these services is
service Route\&Time Prediction (RTP), which aims to estimate the future service
route as well as the arrival time of a given worker. As one of the most crucial
tasks in those service platforms, RTP stands central to enhancing user
satisfaction and trimming operational expenditures on these platforms. Despite
a plethora of algorithms developed to date, there is no systematic,
comprehensive survey to guide researchers in this domain. To fill this gap, our
work presents the first comprehensive survey that methodically categorizes
recent advances in service route and time prediction. We start by defining the
RTP challenge and then delve into the metrics that are often employed.
Following that, we scrutinize the existing RTP methodologies, presenting a
novel taxonomy of them. We categorize these methods based on three criteria:
(i) type of task, subdivided into only-route prediction, only-time prediction,
and joint route\&time prediction; (ii) model architecture, which encompasses
sequence-based and graph-based models; and (iii) learning paradigm, including
Supervised Learning (SL) and Deep Reinforcement Learning (DRL). Conclusively,
we highlight the limitations of current research and suggest prospective
avenues. We believe that the taxonomy, progress, and prospects introduced in
this paper can significantly promote the development of this field.

---------------

### 22 Apr 2020 | [PanNuke Dataset Extension, Insights and Baselines](https://arxiv.org/abs/2003.10778) | [⬇️](https://arxiv.org/pdf/2003.10778)
*Jevgenij Gamper, Navid Alemi Koohbanani, Ksenija Benes, Simon Graham,  Mostafa Jahanifar, Syed Ali Khurram, Ayesha Azam, Katherine Hewitt, Nasir  Rajpoot* 

  The emerging area of computational pathology (CPath) is ripe ground for the
application of deep learning (DL) methods to healthcare due to the sheer volume
of raw pixel data in whole-slide images (WSIs) of cancerous tissue slides.
However, it is imperative for the DL algorithms relying on nuclei-level details
to be able to cope with data from `the clinical wild', which tends to be quite
challenging.
  We study, and extend recently released PanNuke dataset consisting of ~200,000
nuclei categorized into 5 clinically important classes for the challenging
tasks of segmenting and classifying nuclei in WSIs. Previous pan-cancer
datasets consisted of only up to 9 different tissues and up to 21,000 unlabeled
nuclei and just over 24,000 labeled nuclei with segmentation masks. PanNuke
consists of 19 different tissue types that have been semi-automatically
annotated and quality controlled by clinical pathologists, leading to a dataset
with statistics similar to the clinical wild and with minimal selection bias.
We study the performance of segmentation and classification models when applied
to the proposed dataset and demonstrate the application of models trained on
PanNuke to whole-slide images. We provide comprehensive statistics about the
dataset and outline recommendations and research directions to address the
limitations of existing DL tools when applied to real-world CPath applications.

---------------

### 10 Oct 2023 | [Representation Engineering: A Top-Down Approach to AI Transparency](https://arxiv.org/abs/2310.01405) | [⬇️](https://arxiv.org/pdf/2310.01405)
*Andy Zou, Long Phan, Sarah Chen, James Campbell, Phillip Guo, Richard  Ren, Alexander Pan, Xuwang Yin, Mantas Mazeika, Ann-Kathrin Dombrowski,  Shashwat Goel, Nathaniel Li, Michael J. Byun, Zifan Wang, Alex Mallen, Steven  Basart, Sanmi Koyejo, Dawn Song, Matt Fredrikson, J. Zico Kolter, Dan  Hendrycks* 

  In this paper, we identify and characterize the emerging area of
representation engineering (RepE), an approach to enhancing the transparency of
AI systems that draws on insights from cognitive neuroscience. RepE places
population-level representations, rather than neurons or circuits, at the
center of analysis, equipping us with novel methods for monitoring and
manipulating high-level cognitive phenomena in deep neural networks (DNNs). We
provide baselines and an initial analysis of RepE techniques, showing that they
offer simple yet effective solutions for improving our understanding and
control of large language models. We showcase how these methods can provide
traction on a wide range of safety-relevant problems, including honesty,
harmlessness, power-seeking, and more, demonstrating the promise of top-down
transparency research. We hope that this work catalyzes further exploration of
RepE and fosters advancements in the transparency and safety of AI systems.

---------------

### 11 Dec 2003 | [Mapping Subsets of Scholarly Information](https://arxiv.org/abs/cs/0312018) | [⬇️](https://arxiv.org/pdf/cs/0312018)
*Paul Ginsparg, Paul Houle, Thorsten Joachims, and Jae-Hoon Sul  (Cornell University)* 

  We illustrate the use of machine learning techniques to analyze, structure,
maintain, and evolve a large online corpus of academic literature. An emerging
field of research can be identified as part of an existing corpus, permitting
the implementation of a more coherent community structure for its
practitioners.

---------------

### 30 Nov 2022 | [MinUn: Accurate ML Inference on Microcontrollers](https://arxiv.org/abs/2210.16556) | [⬇️](https://arxiv.org/pdf/2210.16556)
*Shikhar Jaiswal, Rahul Kiran Kranti Goli, Aayan Kumar, Vivek Seshadri  and Rahul Sharma* 

  Running machine learning inference on tiny devices, known as TinyML, is an
emerging research area. This task requires generating inference code that uses
memory frugally, a task that standard ML frameworks are ill-suited for. A
deployment framework for TinyML must be a) parametric in the number
representation to take advantage of the emerging representations like posits,
b) carefully assign high-precision to a few tensors so that most tensors can be
kept in low-precision while still maintaining model accuracy, and c) avoid
memory fragmentation. We describe MinUn, the first TinyML framework that
holistically addresses these issues to generate efficient code for ARM
microcontrollers (e.g., Arduino Uno, Due and STM32H747) that outperforms the
prior TinyML frameworks.

---------------

### 18 Dec 2019 | [Macaw: An Extensible Conversational Information Seeking Platform](https://arxiv.org/abs/1912.08904) | [⬇️](https://arxiv.org/pdf/1912.08904)
*Hamed Zamani, Nick Craswell* 

  Conversational information seeking (CIS) has been recognized as a major
emerging research area in information retrieval. Such research will require
data and tools, to allow the implementation and study of conversational
systems. This paper introduces Macaw, an open-source framework with a modular
architecture for CIS research. Macaw supports multi-turn, multi-modal, and
mixed-initiative interactions, and enables research for tasks such as document
retrieval, question answering, recommendation, and structured data exploration.
It has a modular design to encourage the study of new CIS algorithms, which can
be evaluated in batch mode. It can also integrate with a user interface, which
allows user studies and data collection in an interactive mode, where the back
end can be fully algorithmic or a wizard of oz setup. Macaw is distributed
under the MIT License.

---------------

### 10 Sep 2021 | [Opinion Prediction with User Fingerprinting](https://arxiv.org/abs/2108.00270) | [⬇️](https://arxiv.org/pdf/2108.00270)
*Kishore Tumarada, Yifan Zhang, Fan Yang, Eduard Dragut, Omprakash  Gnawali, and Arjun Mukherjee* 

  Opinion prediction is an emerging research area with diverse real-world
applications, such as market research and situational awareness. We identify
two lines of approaches to the problem of opinion prediction. One uses
topic-based sentiment analysis with time-series modeling, while the other uses
static embedding of text. The latter approaches seek user-specific solutions by
generating user fingerprints. Such approaches are useful in predicting user's
reactions to unseen content. In this work, we propose a novel dynamic
fingerprinting method that leverages contextual embedding of user's comments
conditioned on relevant user's reading history. We integrate BERT variants with
a recurrent neural network to generate predictions. The results show up to 13\%
improvement in micro F1-score compared to previous approaches. Experimental
results show novel insights that were previously unknown such as better
predictions for an increase in dynamic history length, the impact of the nature
of the article on performance, thereby laying the foundation for further
research.

---------------

### 30 Sep 2022 | [B2RL: An open-source Dataset for Building Batch Reinforcement Learning](https://arxiv.org/abs/2209.15626) | [⬇️](https://arxiv.org/pdf/2209.15626)
*Hsin-Yu Liu (1), Xiaohan Fu (1), Bharathan Balaji (2), Rajesh Gupta  (1), and Dezhi Hong (2) ((1) University of California, San Diego, (2) Amazon)* 

  Batch reinforcement learning (BRL) is an emerging research area in the RL
community. It learns exclusively from static datasets (i.e. replay buffers)
without interaction with the environment. In the offline settings, existing
replay experiences are used as prior knowledge for BRL models to find the
optimal policy. Thus, generating replay buffers is crucial for BRL model
benchmark. In our B2RL (Building Batch RL) dataset, we collected real-world
data from our building management systems, as well as buffers generated by
several behavioral policies in simulation environments. We believe it could
help building experts on BRL research. To the best of our knowledge, we are the
first to open-source building datasets for the purpose of BRL learning.

---------------

### 13 Jun 2022 | [Topic-Aware Evaluation and Transformer Methods for Topic-Controllable  Summarization](https://arxiv.org/abs/2206.04317) | [⬇️](https://arxiv.org/pdf/2206.04317)
*Tatiana Passali, Grigorios Tsoumakas* 

  Topic-controllable summarization is an emerging research area with a wide
range of potential applications. However, existing approaches suffer from
significant limitations. First, there is currently no established evaluation
metric for this task. Furthermore, existing methods built upon recurrent
architectures, which can significantly limit their performance compared to more
recent Transformer-based architectures, while they also require modifications
to the model's architecture for controlling the topic. In this work, we propose
a new topic-oriented evaluation measure to automatically evaluate the generated
summaries based on the topic affinity between the generated summary and the
desired topic. We also conducted a user study that validates the reliability of
this measure. Finally, we propose simple, yet powerful methods for
topic-controllable summarization either incorporating topic embeddings into the
model's architecture or employing control tokens to guide the summary
generation. Experimental results show that control tokens can achieve better
performance compared to more complicated embedding-based approaches while being
at the same time significantly faster.

---------------

### 04 Jun 2019 | [Recent Advances in Neural Question Generation](https://arxiv.org/abs/1905.08949) | [⬇️](https://arxiv.org/pdf/1905.08949)
*Liangming Pan, Wenqiang Lei, Tat-Seng Chua and Min-Yen Kan* 

  Emerging research in Neural Question Generation (NQG) has started to
integrate a larger variety of inputs, and generating questions requiring higher
levels of cognition. These trends point to NQG as a bellwether for NLP, about
how human intelligence embodies the skills of curiosity and integration.
  We present a comprehensive survey of neural question generation, examining
the corpora, methodologies, and evaluation methods. From this, we elaborate on
what we see as emerging on NQG's trend: in terms of the learning paradigms,
input modalities, and cognitive levels considered by NQG. We end by pointing
out the potential directions ahead.

---------------

### 28 Jun 2023 | [Lifelong Change Detection: Continuous Domain Adaptation for Small Object  Change Detection in Every Robot Navigation](https://arxiv.org/abs/2306.16086) | [⬇️](https://arxiv.org/pdf/2306.16086)
*Koji Takeda, Kanji Tanaka, Yoshimasa Nakamura* 

  The recently emerging research area in robotics, ground view change
detection, suffers from its ill-posed-ness because of visual uncertainty
combined with complex nonlinear perspective projection. To regularize the
ill-posed-ness, the commonly applied supervised learning methods (e.g.,
CSCD-Net) rely on manually annotated high-quality object-class-specific priors.
In this work, we consider general application domains where no manual
annotation is available and present a fully self-supervised approach. The
present approach adopts the powerful and versatile idea that object changes
detected during everyday robot navigation can be reused as additional priors to
improve future change detection tasks. Furthermore, a robustified framework is
implemented and verified experimentally in a new challenging practical
application scenario: ground-view small object change detection.

---------------

### 27 Jan 2024 | [A Survey on 3D Skeleton Based Person Re-Identification: Approaches,  Designs, Challenges, and Future Directions](https://arxiv.org/abs/2401.15296) | [⬇️](https://arxiv.org/pdf/2401.15296)
*Haocong Rao, Chunyan Miao* 

  Person re-identification via 3D skeletons is an important emerging research
area that triggers great interest in the pattern recognition community. With
distinctive advantages for many application scenarios, a great diversity of 3D
skeleton based person re-identification (SRID) methods have been proposed in
recent years, effectively addressing prominent problems in skeleton modeling
and feature learning. Despite recent advances, to the best of our knowledge,
little effort has been made to comprehensively summarize these studies and
their challenges. In this paper, we attempt to fill this gap by providing a
systematic survey on current SRID approaches, model designs, challenges, and
future directions. Specifically, we first formulate the SRID problem, and
propose a taxonomy of SRID research with a summary of benchmark datasets,
commonly-used model architectures, and an analytical review of different
methods' characteristics. Then, we elaborate on the design principles of SRID
models from multiple aspects to offer key insights for model improvement.
Finally, we identify critical challenges confronting current studies and
discuss several promising directions for future research of SRID.

---------------

### 19 Jul 2022 | [Mimetic Models: Ethical Implications of AI that Acts Like You](https://arxiv.org/abs/2207.09394) | [⬇️](https://arxiv.org/pdf/2207.09394)
*Reid McIlroy-Young, Jon Kleinberg, Siddhartha Sen, Solon Barocas,  Ashton Anderson* 

  An emerging theme in artificial intelligence research is the creation of
models to simulate the decisions and behavior of specific people, in domains
including game-playing, text generation, and artistic expression. These models
go beyond earlier approaches in the way they are tailored to individuals, and
the way they are designed for interaction rather than simply the reproduction
of fixed, pre-computed behaviors. We refer to these as mimetic models, and in
this paper we develop a framework for characterizing the ethical and social
issues raised by their growing availability. Our framework includes a number of
distinct scenarios for the use of such models, and considers the impacts on a
range of different participants, including the target being modeled, the
operator who deploys the model, and the entities that interact with it.

---------------

### 31 Oct 2020 | [Learning Open Set Network with Discriminative Reciprocal Points](https://arxiv.org/abs/2011.00178) | [⬇️](https://arxiv.org/pdf/2011.00178)
*Guangyao Chen, Limeng Qiao, Yemin Shi, Peixi Peng, Jia Li, Tiejun  Huang, Shiliang Pu, Yonghong Tian* 

  Open set recognition is an emerging research area that aims to simultaneously
classify samples from predefined classes and identify the rest as 'unknown'. In
this process, one of the key challenges is to reduce the risk of generalizing
the inherent characteristics of numerous unknown samples learned from a small
amount of known data. In this paper, we propose a new concept, Reciprocal
Point, which is the potential representation of the extra-class space
corresponding to each known category. The sample can be classified to known or
unknown by the otherness with reciprocal points. To tackle the open set
problem, we offer a novel open space risk regularization term. Based on the
bounded space constructed by reciprocal points, the risk of unknown is reduced
through multi-category interaction. The novel learning framework called
Reciprocal Point Learning (RPL), which can indirectly introduce the unknown
information into the learner with only known classes, so as to learn more
compact and discriminative representations. Moreover, we further construct a
new large-scale challenging aircraft dataset for open set recognition: Aircraft
300 (Air-300). Extensive experiments on multiple benchmark datasets indicate
that our framework is significantly superior to other existing approaches and
achieves state-of-the-art performance on standard open set benchmarks.

---------------

### 17 Jan 2022 | [A Brief Survey of Machine Learning Methods for Emotion Prediction using  Physiological Data](https://arxiv.org/abs/2201.06610) | [⬇️](https://arxiv.org/pdf/2201.06610)
*Maryam Khalid, Emily Willis* 

  Emotion prediction is a key emerging research area that focuses on
identifying and forecasting the emotional state of a human from multiple
modalities. Among other data sources, physiological data can serve as an
indicator for emotions with an added advantage that it cannot be
masked/tampered by the individual and can be easily collected. This paper
surveys multiple machine learning methods that deploy smartphone and
physiological data to predict emotions in real-time, using self-reported
ecological momentary assessments (EMA) scores as ground-truth. Comparing
regression, long short-term memory (LSTM) networks, convolutional neural
networks (CNN), reinforcement online learning (ROL), and deep belief networks
(DBN), we showcase the variability of machine learning methods employed to
achieve accurate emotion prediction. We compare the state-of-the-art methods
and highlight that experimental performance is still not very good. The
performance can be improved in future works by considering the following
issues: improving scalability and generalizability, synchronizing multimodal
data, optimizing EMA sampling, integrating adaptability with sequence
prediction, collecting unbiased data, and leveraging sophisticated feature
engineering techniques.

---------------

### 26 Aug 2022 | [Remote Work Optimization with Robust Multi-channel Graph Neural Networks](https://arxiv.org/abs/2209.03150) | [⬇️](https://arxiv.org/pdf/2209.03150)
*Qinyi Zhu, Liang Wu, Qi Guo, Liangjie Hong* 

  The spread of COVID-19 leads to the global shutdown of many corporate
offices, and encourages companies to open more opportunities that allow
employees to work from a remote location. As the workplace type expands from
onsite offices to remote areas, an emerging challenge for an online hiring
marketplace is how these remote opportunities and user intentions to work
remotely can be modeled and matched without prior information. Despite the
unprecedented amount of remote jobs posted amid COVID-19, there is no existing
approach that can be directly applied.
  Introducing a brand new workplace type naturally leads to the cold-start
problem, which is particularly more common for less active job seekers. It is
challenging, if not impossible, to onboard a new workplace type for any
predictive model if existing information sources can provide little information
related to a new category of jobs, including data from resumes and job
descriptions. Hence, in this work, we aim to propose a principled approach that
jointly models the remoteness of job seekers and job opportunities with limited
information, which also suffices the needs of web-scale applications. Existing
research on the emerging type of remote workplace mainly focuses on qualitative
studies, and classic predictive modeling approaches are inapplicable
considering the problem of cold-start and information scarcity. We precisely
try to close this gap with a novel graph neural architecture. Extensive
experiments on large-scale data from real-world applications have been
conducted to validate the superiority of the proposed approach over competitive
baselines. The improvement may translate to more rapid onboarding of the new
workplace type that can benefit job seekers who are interested in working
remotely.

---------------

### 08 Feb 2023 | [ChatGPT versus Traditional Question Answering for Knowledge Graphs:  Current Status and Future Directions Towards Knowledge Graph Chatbots](https://arxiv.org/abs/2302.06466) | [⬇️](https://arxiv.org/pdf/2302.06466)
*Reham Omar, Omij Mangukiya, Panos Kalnis and Essam Mansour* 

  Conversational AI and Question-Answering systems (QASs) for knowledge graphs
(KGs) are both emerging research areas: they empower users with natural
language interfaces for extracting information easily and effectively.
Conversational AI simulates conversations with humans; however, it is limited
by the data captured in the training datasets. In contrast, QASs retrieve the
most recent information from a KG by understanding and translating the natural
language question into a formal query supported by the database engine.
  In this paper, we present a comprehensive study of the characteristics of the
existing alternatives towards combining both worlds into novel KG chatbots. Our
framework compares two representative conversational models, ChatGPT and
Galactica, against KGQAN, the current state-of-the-art QAS. We conduct a
thorough evaluation using four real KGs across various application domains to
identify the current limitations of each category of systems. Based on our
findings, we propose open research opportunities to empower QASs with chatbot
capabilities for KGs. All benchmarks and all raw results are available1 for
further analysis.

---------------

### 15 Jan 2021 | [Artificial Intelligence for IT Operations (AIOPS) Workshop White Paper](https://arxiv.org/abs/2101.06054) | [⬇️](https://arxiv.org/pdf/2101.06054)
*Jasmin Bogatinovski, Sasho Nedelkoski, Alexander Acker, Florian  Schmidt, Thorsten Wittkopp, Soeren Becker, Jorge Cardoso, and Odej Kao* 

  Artificial Intelligence for IT Operations (AIOps) is an emerging
interdisciplinary field arising in the intersection between the research areas
of machine learning, big data, streaming analytics, and the management of IT
operations. AIOps, as a field, is a candidate to produce the future standard
for IT operation management. To that end, AIOps has several challenges. First,
it needs to combine separate research branches from other research fields like
software reliability engineering. Second, novel modelling techniques are needed
to understand the dynamics of different systems. Furthermore, it requires to
lay out the basis for assessing: time horizons and uncertainty for imminent SLA
violations, the early detection of emerging problems, autonomous remediation,
decision making, support of various optimization objectives. Moreover, a good
understanding and interpretability of these aiding models are important for
building trust between the employed tools and the domain experts. Finally, all
this will result in faster adoption of AIOps, further increase the interest in
this research field and contribute to bridging the gap towards fully-autonomous
operating IT systems.
  The main aim of the AIOPS workshop is to bring together researchers from both
academia and industry to present their experiences, results, and work in
progress in this field. The workshop aims to strengthen the community and unite
it towards the goal of joining the efforts for solving the main challenges the
field is currently facing. A consensus and adoption of the principles of
openness and reproducibility will boost the research in this emerging area
significantly.

---------------

### 17 Jul 2019 | [Electroencephalography based Classification of Long-term Stress using  Psychological Labeling](https://arxiv.org/abs/1907.07671) | [⬇️](https://arxiv.org/pdf/1907.07671)
*Sanay Muhammad Umar Saeed, Syed Muhammad Anwar, Humaira Khalid,  Muhammad Majid, Ulas Bagci* 

  Stress research is a rapidly emerging area in thefield of
electroencephalography (EEG) based signal processing.The use of EEG as an
objective measure for cost effective andpersonalized stress management becomes
important in particularsituations such as the non-availability of mental health
facilities.In this study, long-term stress is classified using baseline
EEGsignal recordings. The labelling for the stress and control groupsis
performed using two methods (i) the perceived stress scalescore and (ii) expert
evaluation. The frequency domain featuresare extracted from five-channel EEG
recordings in addition tothe frontal and temporal alpha and beta asymmetries.
The alphaasymmetry is computed from four channels and used as a feature.Feature
selection is also performed using a t-test to identifystatistically significant
features for both stress and control groups.We found that support vector
machine is best suited to classifylong-term human stress when used with alpha
asymmetry asa feature. It is observed that expert evaluation based
labellingmethod has improved the classification accuracy up to 85.20%.Based on
these results, it is concluded that alpha asymmetry maybe used as a potential
bio-marker for stress classification, when labels are assigned using expert
evaluation.

---------------
