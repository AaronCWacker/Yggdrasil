Architecture Advances 💫

### 🔎 Architecture Advances 💫



# Architecture Advances 💫

## Outlines

* [Architecture Advances 💫](#architecture-advances-)
	+ [Outlines](#outlines)
	+ [Architecture Advances](#architecture-advances)
		- [Architecture Advances 1](#architecture-advances-1)
		- [Architecture Advances 2](#architecture-advances-2)
		- [Architecture Advances 3](#architecture-advances-3)
		- [Architecture Advances 4](#architecture-advances-4)
		- [Architecture Advances 5](#architecture-advances-5)
		- [Architecture Advances 6](#architecture-advances-6)
		- [Architecture Advances 7](#architecture-advances-7)
		- [Architecture Advances 8](#architecture-advances-8)
		- [Architecture Advances 9](#architecture-advances-9)
		- [Architecture Advances 10](#architecture-advances-10)
		- [Architecture Advances 11](#architecture-advances-11)
		- [Architecture Advances 12](#architecture-advances-12)
		- [Architecture Advances 13](#architecture-advances-13)
		- [Architecture Advances 14](#architecture-advances-14)
		- [Architecture Advances 15](#architecture-advances-15)
		- [Architecture Advances 16](#architecture-advances-16)
		- [Architecture Advances 17](#architecture-advances-17)
		- [Architecture Advances 18](#architecture-advances-18)
		- [Architecture Advances 
# 🩺🔍 Search Results
### 19 Jun 2019 | [Transfer NAS: Knowledge Transfer between Search Spaces with Transformer  Agents](https://arxiv.org/abs/1906.08102) | [⬇️](https://arxiv.org/pdf/1906.08102)
*Zal\'an Borsos, Andrey Khorlin, Andrea Gesmundo* 

  Recent advances in Neural Architecture Search (NAS) have produced
state-of-the-art architectures on several tasks. NAS shifts the efforts of
human experts from developing novel architectures directly to designing
architecture search spaces and methods to explore them efficiently. The search
space definition captures prior knowledge about the properties of the
architectures and it is crucial for the complexity and the performance of the
search algorithm. However, different search space definitions require
restarting the learning process from scratch. We propose a novel agent based on
the Transformer that supports joint training and efficient transfer of prior
knowledge between multiple search spaces and tasks.

---------------

### 05 Jan 2024 | [DocGraphLM: Documental Graph Language Model for Information Extraction](https://arxiv.org/abs/2401.02823) | [⬇️](https://arxiv.org/pdf/2401.02823)
*Dongsheng Wang, Zhiqiang Ma, Armineh Nourbakhsh, Kang Gu, Sameena Shah* 

  Advances in Visually Rich Document Understanding (VrDU) have enabled
information extraction and question answering over documents with complex
layouts. Two tropes of architectures have emerged -- transformer-based models
inspired by LLMs, and Graph Neural Networks. In this paper, we introduce
DocGraphLM, a novel framework that combines pre-trained language models with
graph semantics. To achieve this, we propose 1) a joint encoder architecture to
represent documents, and 2) a novel link prediction approach to reconstruct
document graphs. DocGraphLM predicts both directions and distances between
nodes using a convergent joint loss function that prioritizes neighborhood
restoration and downweighs distant node detection. Our experiments on three
SotA datasets show consistent improvement on IE and QA tasks with the adoption
of graph features. Moreover, we report that adopting the graph features
accelerates convergence in the learning process during training, despite being
solely constructed through link prediction.

---------------

### 14 May 2019 | [NAS-Bench-101: Towards Reproducible Neural Architecture Search](https://arxiv.org/abs/1902.09635) | [⬇️](https://arxiv.org/pdf/1902.09635)
*Chris Ying, Aaron Klein, Esteban Real, Eric Christiansen, Kevin  Murphy, Frank Hutter* 

  Recent advances in neural architecture search (NAS) demand tremendous
computational resources, which makes it difficult to reproduce experiments and
imposes a barrier-to-entry to researchers without access to large-scale
computation. We aim to ameliorate these problems by introducing NAS-Bench-101,
the first public architecture dataset for NAS research. To build NAS-Bench-101,
we carefully constructed a compact, yet expressive, search space, exploiting
graph isomorphisms to identify 423k unique convolutional architectures. We
trained and evaluated all of these architectures multiple times on CIFAR-10 and
compiled the results into a large dataset of over 5 million trained models.
This allows researchers to evaluate the quality of a diverse range of models in
milliseconds by querying the pre-computed dataset. We demonstrate its utility
by analyzing the dataset as a whole and by benchmarking a range of architecture
optimization algorithms.

---------------

### 20 Aug 2022 | [Visual Analysis of Neural Architecture Spaces for Summarizing Design  Principles](https://arxiv.org/abs/2208.09665) | [⬇️](https://arxiv.org/pdf/2208.09665)
*Jun Yuan, Mengchen Liu, Fengyuan Tian, and Shixia Liu* 

  Recent advances in artificial intelligence largely benefit from better neural
network architectures. These architectures are a product of a costly process of
trial-and-error. To ease this process, we develop ArchExplorer, a visual
analysis method for understanding a neural architecture space and summarizing
design principles. The key idea behind our method is to make the architecture
space explainable by exploiting structural distances between architectures. We
formulate the pairwise distance calculation as solving an all-pairs shortest
path problem. To improve efficiency, we decompose this problem into a set of
single-source shortest path problems. The time complexity is reduced from
O(kn^2N) to O(knN). Architectures are hierarchically clustered according to the
distances between them. A circle-packing-based architecture visualization has
been developed to convey both the global relationships between clusters and
local neighborhoods of the architectures in each cluster. Two case studies and
a post-analysis are presented to demonstrate the effectiveness of ArchExplorer
in summarizing design principles and selecting better-performing architectures.

---------------

### 29 Nov 2022 | [Neural Font Rendering](https://arxiv.org/abs/2211.14802) | [⬇️](https://arxiv.org/pdf/2211.14802)
*Daniel Anderson, Ariel Shamir and Ohad Fried* 

  Recent advances in deep learning techniques and applications have
revolutionized artistic creation and manipulation in many domains (text,
images, music); however, fonts have not yet been integrated with deep learning
architectures in a manner that supports their multi-scale nature. In this work
we aim to bridge this gap, proposing a network architecture capable of
rasterizing glyphs in multiple sizes, potentially paving the way for easy and
accessible creation and manipulation of fonts.

---------------

### 07 Apr 2007 | [Architecture for Pseudo Acausal Evolvable Embedded Systems](https://arxiv.org/abs/0704.0985) | [⬇️](https://arxiv.org/pdf/0704.0985)
*Mohd Abubakr, R.M.Vinay* 

  Advances in semiconductor technology are contributing to the increasing
complexity in the design of embedded systems. Architectures with novel
techniques such as evolvable nature and autonomous behavior have engrossed lot
of attention. This paper demonstrates conceptually evolvable embedded systems
can be characterized basing on acausal nature. It is noted that in acausal
systems, future input needs to be known, here we make a mechanism such that the
system predicts the future inputs and exhibits pseudo acausal nature. An
embedded system that uses theoretical framework of acausality is proposed. Our
method aims at a novel architecture that features the hardware evolability and
autonomous behavior alongside pseudo acausality. Various aspects of this
architecture are discussed in detail along with the limitations.

---------------

### 07 Sep 2023 | [Dawn of the transformer era in speech emotion recognition: closing the  valence gap](https://arxiv.org/abs/2203.07378) | [⬇️](https://arxiv.org/pdf/2203.07378)
*Johannes Wagner, Andreas Triantafyllopoulos, Hagen Wierstorf,  Maximilian Schmitt, Felix Burkhardt, Florian Eyben, Bj\"orn W. Schuller* 

  Recent advances in transformer-based architectures which are pre-trained in
self-supervised manner have shown great promise in several machine learning
tasks. In the audio domain, such architectures have also been successfully
utilised in the field of speech emotion recognition (SER). However, existing
works have not evaluated the influence of model size and pre-training data on
downstream performance, and have shown limited attention to generalisation,
robustness, fairness, and efficiency. The present contribution conducts a
thorough analysis of these aspects on several pre-trained variants of wav2vec
2.0 and HuBERT that we fine-tuned on the dimensions arousal, dominance, and
valence of MSP-Podcast, while additionally using IEMOCAP and MOSI to test
cross-corpus generalisation. To the best of our knowledge, we obtain the top
performance for valence prediction without use of explicit linguistic
information, with a concordance correlation coefficient (CCC) of .638 on
MSP-Podcast. Furthermore, our investigations reveal that transformer-based
architectures are more robust to small perturbations compared to a CNN-based
baseline and fair with respect to biological sex groups, but not towards
individual speakers. Finally, we are the first to show that their extraordinary
success on valence is based on implicit linguistic information learnt during
fine-tuning of the transformer layers, which explains why they perform on-par
with recent multimodal approaches that explicitly utilise textual information.
Our findings collectively paint the following picture: transformer-based
architectures constitute the new state-of-the-art in SER, but further advances
are needed to mitigate remaining robustness and individual speaker issues. To
make our findings reproducible, we release the best performing model to the
community.

---------------

### 20 Apr 2021 | [Efficient Retrieval Optimized Multi-task Learning](https://arxiv.org/abs/2104.10129) | [⬇️](https://arxiv.org/pdf/2104.10129)
*Hengxin Fun, Sunil Gandhi, Sujith Ravi* 

  Recently, there have been significant advances in neural methods for tackling
knowledge-intensive tasks such as open domain question answering (QA). These
advances are fueled by combining large pre-trained language models with
learnable retrieval of documents. Majority of these models use separate
encoders for learning query representation, passage representation for the
retriever and an additional encoder for the downstream task. Using separate
encoders for each stage/task occupies a lot of memory and makes it difficult to
scale to a large number of tasks. In this paper, we propose a novel Retrieval
Optimized Multi-task (ROM) framework for jointly training self-supervised
tasks, knowledge retrieval, and extractive question answering. Our ROM approach
presents a unified and generalizable framework that enables scaling efficiently
to multiple tasks, varying levels of supervision, and optimization choices such
as different learning schedules without changing the model architecture. It
also provides the flexibility of changing the encoders without changing the
architecture of the system. Using our framework, we achieve comparable or
better performance than recent methods on QA, while drastically reducing the
number of parameters.

---------------

### 08 Nov 2023 | [Designing Robust Transformers using Robust Kernel Density Estimation](https://arxiv.org/abs/2210.05794) | [⬇️](https://arxiv.org/pdf/2210.05794)
*Xing Han and Tongzheng Ren and Tan Minh Nguyen and Khai Nguyen and  Joydeep Ghosh and Nhat Ho* 

  Recent advances in Transformer architectures have empowered their empirical
success in a variety of tasks across different domains. However, existing works
mainly focus on predictive accuracy and computational cost, without considering
other practical issues, such as robustness to contaminated samples. Recent work
by Nguyen et al., (2022) has shown that the self-attention mechanism, which is
the center of the Transformer architecture, can be viewed as a non-parametric
estimator based on kernel density estimation (KDE). This motivates us to
leverage a set of robust kernel density estimation methods for alleviating the
issue of data contamination. Specifically, we introduce a series of
self-attention mechanisms that can be incorporated into different Transformer
architectures and discuss the special properties of each method. We then
perform extensive empirical studies on language modeling and image
classification tasks. Our methods demonstrate robust performance in multiple
scenarios while maintaining competitive results on clean datasets.

---------------

### 24 Oct 2023 | [Yin Yang Convolutional Nets: Image Manifold Extraction by the Analysis  of Opposites](https://arxiv.org/abs/2310.16148) | [⬇️](https://arxiv.org/pdf/2310.16148)
*Augusto Seben da Rosa, Frederico Santos de Oliveira, Anderson da Silva  Soares, Arnaldo Candido Junior* 

  Computer vision in general presented several advances such as training
optimizations, new architectures (pure attention, efficient block, vision
language models, generative models, among others). This have improved
performance in several tasks such as classification, and others. However, the
majority of these models focus on modifications that are taking distance from
realistic neuroscientific approaches related to the brain. In this work, we
adopt a more bio-inspired approach and present the Yin Yang Convolutional
Network, an architecture that extracts visual manifold, its blocks are intended
to separate analysis of colors and forms at its initial layers, simulating
occipital lobe's operations. Our results shows that our architecture provides
State-of-the-Art efficiency among low parameter architectures in the dataset
CIFAR-10. Our first model reached 93.32\% test accuracy, 0.8\% more than the
older SOTA in this category, while having 150k less parameters (726k in total).
Our second model uses 52k parameters, losing only 3.86\% test accuracy. We also
performed an analysis on ImageNet, where we reached 66.49\% validation accuracy
with 1.6M parameters. We make the code publicly available at:
https://github.com/NoSavedDATA/YinYang_CNN.

---------------

### 06 Dec 2023 | [Transformer-Powered Surrogates Close the ICF Simulation-Experiment Gap  with Extremely Limited Data](https://arxiv.org/abs/2312.03642) | [⬇️](https://arxiv.org/pdf/2312.03642)
*Matthew L. Olson, Shusen Liu, Jayaraman J. Thiagarajan, Bogdan  Kustowski, Weng-Keen Wong, Rushil Anirudh* 

  Recent advances in machine learning, specifically transformer architecture,
have led to significant advancements in commercial domains. These powerful
models have demonstrated superior capability to learn complex relationships and
often generalize better to new data and problems. This paper presents a novel
transformer-powered approach for enhancing prediction accuracy in multi-modal
output scenarios, where sparse experimental data is supplemented with
simulation data. The proposed approach integrates transformer-based
architecture with a novel graph-based hyper-parameter optimization technique.
The resulting system not only effectively reduces simulation bias, but also
achieves superior prediction accuracy compared to the prior method. We
demonstrate the efficacy of our approach on inertial confinement fusion
experiments, where only 10 shots of real-world data are available, as well as
synthetic versions of these experiments.

---------------

### 25 Jan 2023 | [Neural Architecture Search: Insights from 1000 Papers](https://arxiv.org/abs/2301.08727) | [⬇️](https://arxiv.org/pdf/2301.08727)
*Colin White, Mahmoud Safari, Rhea Sukthanker, Binxin Ru, Thomas  Elsken, Arber Zela, Debadeepta Dey, Frank Hutter* 

  In the past decade, advances in deep learning have resulted in breakthroughs
in a variety of areas, including computer vision, natural language
understanding, speech recognition, and reinforcement learning. Specialized,
high-performing neural architectures are crucial to the success of deep
learning in these areas. Neural architecture search (NAS), the process of
automating the design of neural architectures for a given task, is an
inevitable next step in automating machine learning and has already outpaced
the best human-designed architectures on many tasks. In the past few years,
research in NAS has been progressing rapidly, with over 1000 papers released
since 2020 (Deng and Lindauer, 2021). In this survey, we provide an organized
and comprehensive guide to neural architecture search. We give a taxonomy of
search spaces, algorithms, and speedup techniques, and we discuss resources
such as benchmarks, best practices, other surveys, and open-source libraries.

---------------

### 14 Jul 2020 | [HuggingFace's Transformers: State-of-the-art Natural Language Processing](https://arxiv.org/abs/1910.03771) | [⬇️](https://arxiv.org/pdf/1910.03771)
*Thomas Wolf and Lysandre Debut and Victor Sanh and Julien Chaumond and  Clement Delangue and Anthony Moi and Pierric Cistac and Tim Rault and R\'emi  Louf and Morgan Funtowicz and Joe Davison and Sam Shleifer and Patrick von  Platen and Clara Ma and Yacine Jernite and Julien Plu and Canwen Xu and Teven  Le Scao and Sylvain Gugger and Mariama Drame and Quentin Lhoest and Alexander  M. Rush* 

  Recent progress in natural language processing has been driven by advances in
both model architecture and model pretraining. Transformer architectures have
facilitated building higher-capacity models and pretraining has made it
possible to effectively utilize this capacity for a wide variety of tasks.
\textit{Transformers} is an open-source library with the goal of opening up
these advances to the wider machine learning community. The library consists of
carefully engineered state-of-the art Transformer architectures under a unified
API. Backing this library is a curated collection of pretrained models made by
and available for the community. \textit{Transformers} is designed to be
extensible by researchers, simple for practitioners, and fast and robust in
industrial deployments. The library is available at
\url{https://github.com/huggingface/transformers}.

---------------

### 20 Jul 2017 | [Field-Programmable Crossbar Array (FPCA) for Reconfigurable Computing](https://arxiv.org/abs/1612.02913) | [⬇️](https://arxiv.org/pdf/1612.02913)
*Mohammed A. Zidan, YeonJoo Jeong, Jong Hong Shin, Chao Du, Zhengya  Zhang, Wei D. Lu* 

  For decades, advances in electronics were directly driven by the scaling of
CMOS transistors according to Moore's law. However, both the CMOS scaling and
the classical computer architecture are approaching fundamental and practical
limits, and new computing architectures based on emerging devices, such as
resistive random-access memory (RRAM) devices, are expected to sustain the
exponential growth of computing capability. Here we propose a novel
memory-centric, reconfigurable, general purpose computing platform that is
capable of handling the explosive amount of data in a fast and energy-efficient
manner. The proposed computing architecture is based on a uniform, physical,
resistive, memory-centric fabric that can be optimally reconfigured and
utilized to perform different computing and data storage tasks in a massively
parallel approach. The system can be tailored to achieve maximal energy
efficiency based on the data flow by dynamically allocating the basic computing
fabric for storage, arithmetic, and analog computing including neuromorphic
computing tasks.

---------------

### 02 Jul 2020 | [A Closer Look at Local Aggregation Operators in Point Cloud Analysis](https://arxiv.org/abs/2007.01294) | [⬇️](https://arxiv.org/pdf/2007.01294)
*Ze Liu and Han Hu and Yue Cao and Zheng Zhang and Xin Tong* 

  Recent advances of network architecture for point cloud processing are mainly
driven by new designs of local aggregation operators. However, the impact of
these operators to network performance is not carefully investigated due to
different overall network architecture and implementation details in each
solution. Meanwhile, most of operators are only applied in shallow
architectures. In this paper, we revisit the representative local aggregation
operators and study their performance using the same deep residual
architecture. Our investigation reveals that despite the different designs of
these operators, all of these operators make surprisingly similar contributions
to the network performance under the same network input and feature numbers and
result in the state-of-the-art accuracy on standard benchmarks. This finding
stimulate us to rethink the necessity of sophisticated design of local
aggregation operator for point cloud processing. To this end, we propose a
simple local aggregation operator without learnable weights, named Position
Pooling (PosPool), which performs similarly or slightly better than existing
sophisticated operators. In particular, a simple deep residual network with
PosPool layers achieves outstanding performance on all benchmarks, which
outperforms the previous state-of-the methods on the challenging PartNet
datasets by a large margin (7.4 mIoU). The code is publicly available at
https://github.com/zeliu98/CloserLook3D

---------------

### 29 Jan 2018 | [Playing FPS Games with Deep Reinforcement Learning](https://arxiv.org/abs/1609.05521) | [⬇️](https://arxiv.org/pdf/1609.05521)
*Guillaume Lample, Devendra Singh Chaplot* 

  Advances in deep reinforcement learning have allowed autonomous agents to
perform well on Atari games, often outperforming humans, using only raw pixels
to make their decisions. However, most of these games take place in 2D
environments that are fully observable to the agent. In this paper, we present
the first architecture to tackle 3D environments in first-person shooter games,
that involve partially observable states. Typically, deep reinforcement
learning methods only utilize visual input for training. We present a method to
augment these models to exploit game feature information such as the presence
of enemies or items, during the training phase. Our model is trained to
simultaneously learn these features along with minimizing a Q-learning
objective, which is shown to dramatically improve the training speed and
performance of our agent. Our architecture is also modularized to allow
different models to be independently trained for different phases of the game.
We show that the proposed architecture substantially outperforms built-in AI
agents of the game as well as humans in deathmatch scenarios.

---------------

### 27 Feb 2023 | [Full Stack Optimization of Transformer Inference: a Survey](https://arxiv.org/abs/2302.14017) | [⬇️](https://arxiv.org/pdf/2302.14017)
*Sehoon Kim, Coleman Hooper, Thanakul Wattanawong, Minwoo Kang, Ruohan  Yan, Hasan Genc, Grace Dinh, Qijing Huang, Kurt Keutzer, Michael W. Mahoney,  Yakun Sophia Shao, Amir Gholami* 

  Recent advances in state-of-the-art DNN architecture design have been moving
toward Transformer models. These models achieve superior accuracy across a wide
range of applications. This trend has been consistent over the past several
years since Transformer models were originally introduced. However, the amount
of compute and bandwidth required for inference of recent Transformer models is
growing at a significant rate, and this has made their deployment in
latency-sensitive applications challenging. As such, there has been an
increased focus on making Transformer models more efficient, with methods that
range from changing the architecture design, all the way to developing
dedicated domain-specific accelerators. In this work, we survey different
approaches for efficient Transformer inference, including: (i) analysis and
profiling of the bottlenecks in existing Transformer architectures and their
similarities and differences with previous convolutional models; (ii)
implications of Transformer architecture on hardware, including the impact of
non-linear operations such as Layer Normalization, Softmax, and GELU, as well
as linear operations, on hardware design; (iii) approaches for optimizing a
fixed Transformer architecture; (iv) challenges in finding the right mapping
and scheduling of operations for Transformer models; and (v) approaches for
optimizing Transformer models by adapting the architecture using neural
architecture search. Finally, we perform a case study by applying the surveyed
optimizations on Gemmini, the open-source, full-stack DNN accelerator
generator, and we show how each of these approaches can yield improvements,
compared to previous benchmark results on Gemmini. Among other things, we find
that a full-stack co-design approach with the aforementioned methods can result
in up to 88.7x speedup with a minimal performance degradation for Transformer
inference.

---------------

### 14 Dec 2021 | [Efficient differentiable quadratic programming layers: an ADMM approach](https://arxiv.org/abs/2112.07464) | [⬇️](https://arxiv.org/pdf/2112.07464)
*Andrew Butler and Roy Kwon* 

  Recent advances in neural-network architecture allow for seamless integration
of convex optimization problems as differentiable layers in an end-to-end
trainable neural network. Integrating medium and large scale quadratic programs
into a deep neural network architecture, however, is challenging as solving
quadratic programs exactly by interior-point methods has worst-case cubic
complexity in the number of variables. In this paper, we present an alternative
network layer architecture based on the alternating direction method of
multipliers (ADMM) that is capable of scaling to problems with a moderately
large number of variables. Backward differentiation is performed by implicit
differentiation of the residual map of a modified fixed-point iteration.
Simulated results demonstrate the computational advantage of the ADMM layer,
which for medium scaled problems is approximately an order of magnitude faster
than the OptNet quadratic programming layer. Furthermore, our novel
backward-pass routine is efficient, from both a memory and computation
standpoint, in comparison to the standard approach based on unrolled
differentiation or implicit differentiation of the KKT optimality conditions.
We conclude with examples from portfolio optimization in the integrated
prediction and optimization paradigm.

---------------

### 02 Jan 2018 | [Generalization Tower Network: A Novel Deep Neural Network Architecture  for Multi-Task Learning](https://arxiv.org/abs/1710.10036) | [⬇️](https://arxiv.org/pdf/1710.10036)
*Yuhang Song, Main Xu, Songyang Zhang, Liangyu Huo* 

  Deep learning (DL) advances state-of-the-art reinforcement learning (RL), by
incorporating deep neural networks in learning representations from the input
to RL. However, the conventional deep neural network architecture is limited in
learning representations for multi-task RL (MT-RL), as multiple tasks can refer
to different kinds of representations. In this paper, we thus propose a novel
deep neural network architecture, namely generalization tower network (GTN),
which can achieve MT-RL within a single learned model. Specifically, the
architecture of GTN is composed of both horizontal and vertical streams. In our
GTN architecture, horizontal streams are used to learn representation shared in
similar tasks. In contrast, the vertical streams are introduced to be more
suitable for handling diverse tasks, which encodes hierarchical shared
knowledge of these tasks. The effectiveness of the introduced vertical stream
is validated by experimental results. Experimental results further verify that
our GTN architecture is able to advance the state-of-the-art MT-RL, via being
tested on 51 Atari games.

---------------

### 05 Sep 2021 | [NAS-OoD: Neural Architecture Search for Out-of-Distribution  Generalization](https://arxiv.org/abs/2109.02038) | [⬇️](https://arxiv.org/pdf/2109.02038)
*Haoyue Bai, Fengwei Zhou, Lanqing Hong, Nanyang Ye, S.-H. Gary Chan,  Zhenguo Li* 

  Recent advances on Out-of-Distribution (OoD) generalization reveal the
robustness of deep learning models against distribution shifts. However,
existing works focus on OoD algorithms, such as invariant risk minimization,
domain generalization, or stable learning, without considering the influence of
deep model architectures on OoD generalization, which may lead to sub-optimal
performance. Neural Architecture Search (NAS) methods search for architecture
based on its performance on the training data, which may result in poor
generalization for OoD tasks. In this work, we propose robust Neural
Architecture Search for OoD generalization (NAS-OoD), which optimizes the
architecture with respect to its performance on generated OoD data by gradient
descent. Specifically, a data generator is learned to synthesize OoD data by
maximizing losses computed by different neural architectures, while the goal
for architecture search is to find the optimal architecture parameters that
minimize the synthetic OoD data losses. The data generator and the neural
architecture are jointly optimized in an end-to-end manner, and the minimax
training process effectively discovers robust architectures that generalize
well for different distribution shifts. Extensive experimental results show
that NAS-OoD achieves superior performance on various OoD generalization
benchmarks with deep models having a much fewer number of parameters. In
addition, on a real industry dataset, the proposed NAS-OoD method reduces the
error rate by more than 70% compared with the state-of-the-art method,
demonstrating the proposed method's practicality for real applications.

---------------
**Date:** 19 Jun 2019

**Title:** Transfer NAS: Knowledge Transfer between Search Spaces with Transformer  Agents

**Abstract Link:** [https://arxiv.org/abs/1906.08102](https://arxiv.org/abs/1906.08102)

**PDF Link:** [https://arxiv.org/pdf/1906.08102](https://arxiv.org/pdf/1906.08102)

---

**Date:** 05 Jan 2024

**Title:** DocGraphLM: Documental Graph Language Model for Information Extraction

**Abstract Link:** [https://arxiv.org/abs/2401.02823](https://arxiv.org/abs/2401.02823)

**PDF Link:** [https://arxiv.org/pdf/2401.02823](https://arxiv.org/pdf/2401.02823)

---

**Date:** 14 May 2019

**Title:** NAS-Bench-101: Towards Reproducible Neural Architecture Search

**Abstract Link:** [https://arxiv.org/abs/1902.09635](https://arxiv.org/abs/1902.09635)

**PDF Link:** [https://arxiv.org/pdf/1902.09635](https://arxiv.org/pdf/1902.09635)

---

**Date:** 20 Aug 2022

**Title:** Visual Analysis of Neural Architecture Spaces for Summarizing Design  Principles

**Abstract Link:** [https://arxiv.org/abs/2208.09665](https://arxiv.org/abs/2208.09665)

**PDF Link:** [https://arxiv.org/pdf/2208.09665](https://arxiv.org/pdf/2208.09665)

---

**Date:** 29 Nov 2022

**Title:** Neural Font Rendering

**Abstract Link:** [https://arxiv.org/abs/2211.14802](https://arxiv.org/abs/2211.14802)

**PDF Link:** [https://arxiv.org/pdf/2211.14802](https://arxiv.org/pdf/2211.14802)

---

**Date:** 07 Apr 2007

**Title:** Architecture for Pseudo Acausal Evolvable Embedded Systems

**Abstract Link:** [https://arxiv.org/abs/0704.0985](https://arxiv.org/abs/0704.0985)

**PDF Link:** [https://arxiv.org/pdf/0704.0985](https://arxiv.org/pdf/0704.0985)

---

**Date:** 07 Sep 2023

**Title:** Dawn of the transformer era in speech emotion recognition: closing the  valence gap

**Abstract Link:** [https://arxiv.org/abs/2203.07378](https://arxiv.org/abs/2203.07378)

**PDF Link:** [https://arxiv.org/pdf/2203.07378](https://arxiv.org/pdf/2203.07378)

---

**Date:** 20 Apr 2021

**Title:** Efficient Retrieval Optimized Multi-task Learning

**Abstract Link:** [https://arxiv.org/abs/2104.10129](https://arxiv.org/abs/2104.10129)

**PDF Link:** [https://arxiv.org/pdf/2104.10129](https://arxiv.org/pdf/2104.10129)

---

**Date:** 08 Nov 2023

**Title:** Designing Robust Transformers using Robust Kernel Density Estimation

**Abstract Link:** [https://arxiv.org/abs/2210.05794](https://arxiv.org/abs/2210.05794)

**PDF Link:** [https://arxiv.org/pdf/2210.05794](https://arxiv.org/pdf/2210.05794)

---

**Date:** 24 Oct 2023

**Title:** Yin Yang Convolutional Nets: Image Manifold Extraction by the Analysis  of Opposites

**Abstract Link:** [https://arxiv.org/abs/2310.16148](https://arxiv.org/abs/2310.16148)

**PDF Link:** [https://arxiv.org/pdf/2310.16148](https://arxiv.org/pdf/2310.16148)

---

**Date:** 06 Dec 2023

**Title:** Transformer-Powered Surrogates Close the ICF Simulation-Experiment Gap  with Extremely Limited Data

**Abstract Link:** [https://arxiv.org/abs/2312.03642](https://arxiv.org/abs/2312.03642)

**PDF Link:** [https://arxiv.org/pdf/2312.03642](https://arxiv.org/pdf/2312.03642)

---

**Date:** 25 Jan 2023

**Title:** Neural Architecture Search: Insights from 1000 Papers

**Abstract Link:** [https://arxiv.org/abs/2301.08727](https://arxiv.org/abs/2301.08727)

**PDF Link:** [https://arxiv.org/pdf/2301.08727](https://arxiv.org/pdf/2301.08727)

---

**Date:** 14 Jul 2020

**Title:** HuggingFace's Transformers: State-of-the-art Natural Language Processing

**Abstract Link:** [https://arxiv.org/abs/1910.03771](https://arxiv.org/abs/1910.03771)

**PDF Link:** [https://arxiv.org/pdf/1910.03771](https://arxiv.org/pdf/1910.03771)

---

**Date:** 20 Jul 2017

**Title:** Field-Programmable Crossbar Array (FPCA) for Reconfigurable Computing

**Abstract Link:** [https://arxiv.org/abs/1612.02913](https://arxiv.org/abs/1612.02913)

**PDF Link:** [https://arxiv.org/pdf/1612.02913](https://arxiv.org/pdf/1612.02913)

---

**Date:** 02 Jul 2020

**Title:** A Closer Look at Local Aggregation Operators in Point Cloud Analysis

**Abstract Link:** [https://arxiv.org/abs/2007.01294](https://arxiv.org/abs/2007.01294)

**PDF Link:** [https://arxiv.org/pdf/2007.01294](https://arxiv.org/pdf/2007.01294)

---

**Date:** 29 Jan 2018

**Title:** Playing FPS Games with Deep Reinforcement Learning

**Abstract Link:** [https://arxiv.org/abs/1609.05521](https://arxiv.org/abs/1609.05521)

**PDF Link:** [https://arxiv.org/pdf/1609.05521](https://arxiv.org/pdf/1609.05521)

---

**Date:** 27 Feb 2023

**Title:** Full Stack Optimization of Transformer Inference: a Survey

**Abstract Link:** [https://arxiv.org/abs/2302.14017](https://arxiv.org/abs/2302.14017)

**PDF Link:** [https://arxiv.org/pdf/2302.14017](https://arxiv.org/pdf/2302.14017)

---

**Date:** 14 Dec 2021

**Title:** Efficient differentiable quadratic programming layers: an ADMM approach

**Abstract Link:** [https://arxiv.org/abs/2112.07464](https://arxiv.org/abs/2112.07464)

**PDF Link:** [https://arxiv.org/pdf/2112.07464](https://arxiv.org/pdf/2112.07464)

---

**Date:** 02 Jan 2018

**Title:** Generalization Tower Network: A Novel Deep Neural Network Architecture  for Multi-Task Learning

**Abstract Link:** [https://arxiv.org/abs/1710.10036](https://arxiv.org/abs/1710.10036)

**PDF Link:** [https://arxiv.org/pdf/1710.10036](https://arxiv.org/pdf/1710.10036)

---

**Date:** 05 Sep 2021

**Title:** NAS-OoD: Neural Architecture Search for Out-of-Distribution  Generalization

**Abstract Link:** [https://arxiv.org/abs/2109.02038](https://arxiv.org/abs/2109.02038)

**PDF Link:** [https://arxiv.org/pdf/2109.02038](https://arxiv.org/pdf/2109.02038)

---

