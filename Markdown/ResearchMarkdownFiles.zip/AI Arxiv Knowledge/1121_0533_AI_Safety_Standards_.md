AI Safety Standards 🛡️

### 🔎 AI Safety Standards 🛡️



# AI Safety Standards

AI safety standards are a set of guidelines and protocols designed to ensure that artificial intelligence (AI) systems are developed and deployed in a safe, ethical, and responsible manner. These standards aim to minimize the risks associated with AI, such as bias, discrimination, and unintended consequences, and to maximize the benefits of AI for society. AI safety standards may be established by governments, industry organizations, or other stakeholders, and they may cover various aspects of AI development and deployment, such as data privacy, transparency, accountability, and human oversight. Compliance with AI safety standards is typically voluntary, but it may be required by law or regulation in some jurisdictions.

## AI Safety Standards

There are various AI safety standards that have been proposed or adopted by different organizations and stakeholders. Some examples of AI safety standards include:

1. The EU's Ethics Guidelines for Trustworthy AI: This document provides a framework for the development and use of AI systems that are ethical, transparent, and respect human rights and values.
2. The IEEE's Global Initiative on Ethics of Autonomous and Intelligent Systems: This initiative aims to develop and promote ethical standards and best practices for the design, development, and deployment of AI and autonomous systems.
3. The OECD's Principles on Artificial Intelligence: This document outlines five principles for the responsible stewardship of AI, including human-centered values, transparency, accountability, and robustness and security.
4. The Montreal Declaration for a Responsible Development of Artificial Intelligence: This declaration is a set of ethical principles and recommendations for the development and use of AI, including respect for human rights, fairness, transparency, and accountability.
5. The AI Ethics Guidelines of the Association for Computing Machinery (ACM): This document provides a set of ethical principles and recommendations for the design, development, and deployment of AI systems, including respect for human rights, fairness, transparency, and accountability.

These are just a few examples of AI safety standards that have been proposed or adopted by various organizations and stakeholders. There are many other initiatives and efforts underway to establish and promote AI safety standards, and this field is likely to continue to evolve and expand in the coming years.

## Importance of AI Safety Standards


# 🩺🔍 Search Results
### 05 Jun 2023 | [The Chai Platform's AI Safety Framework](https://arxiv.org/abs/2306.02979) | [⬇️](https://arxiv.org/pdf/2306.02979)
*Xiaoding Lu, Aleksey Korshuk, Zongyi Liu, William Beauchamp* 

  Chai empowers users to create and interact with customized chatbots, offering
unique and engaging experiences. Despite the exciting prospects, the work
recognizes the inherent challenges of a commitment to modern safety standards.
Therefore, this paper presents the integrated AI safety principles into Chai to
prioritize user safety, data protection, and ethical technology use. The paper
specifically explores the multidimensional domain of AI safety research,
demonstrating its application in Chai's conversational chatbot platform. It
presents Chai's AI safety principles, informed by well-established AI research
centres and adapted for chat AI. This work proposes the following safety
framework: Content Safeguarding; Stability and Robustness; and Operational
Transparency and Traceability. The subsequent implementation of these
principles is outlined, followed by an experimental analysis of Chai's AI
safety framework's real-world impact. We emphasise the significance of
conscientious application of AI safety principles and robust safety measures.
The successful implementation of the safe AI framework in Chai indicates the
practicality of mitigating potential risks for responsible and ethical use of
AI technologies. The ultimate vision is a transformative AI tool fostering
progress and innovation while prioritizing user safety and ethical standards.

---------------

### 11 Sep 2023 | [International Governance of Civilian AI: A Jurisdictional Certification  Approach](https://arxiv.org/abs/2308.15514) | [⬇️](https://arxiv.org/pdf/2308.15514)
*Robert Trager, Ben Harack, Anka Reuel, Allison Carnegie, Lennart Heim,  Lewis Ho, Sarah Kreps, Ranjit Lall, Owen Larter, Se\'an \'O h\'Eigeartaigh,  Simon Staffell, Jos\'e Jaime Villalobos* 

  This report describes trade-offs in the design of international governance
arrangements for civilian artificial intelligence (AI) and presents one
approach in detail. This approach represents the extension of a standards,
licensing, and liability regime to the global level. We propose that states
establish an International AI Organization (IAIO) to certify state
jurisdictions (not firms or AI projects) for compliance with international
oversight standards. States can give force to these international standards by
adopting regulations prohibiting the import of goods whose supply chains embody
AI from non-IAIO-certified jurisdictions. This borrows attributes from models
of existing international organizations, such as the International Civilian
Aviation Organization (ICAO), the International Maritime Organization (IMO),
and the Financial Action Task Force (FATF). States can also adopt multilateral
controls on the export of AI product inputs, such as specialized hardware, to
non-certified jurisdictions. Indeed, both the import and export standards could
be required for certification. As international actors reach consensus on risks
of and minimum standards for advanced AI, a jurisdictional certification regime
could mitigate a broad range of potential harms, including threats to public
safety.

---------------

### 27 Sep 2023 | [No Trust without regulation!](https://arxiv.org/abs/2311.06263) | [⬇️](https://arxiv.org/pdf/2311.06263)
*Fran\c{c}ois Terrier (CEA List)* 

  The explosion in the performance of Machine Learning (ML) and the potential
of its applications are strongly encouraging us to consider its use in
industrial systems, including for critical functions such as decision-making in
autonomous systems. While the AI community is well aware of the need to ensure
the trustworthiness of AI-based applications, it is still leaving too much to
one side the issue of safety and its corollary, regulation and standards,
without which it is not possible to certify any level of safety, whether the
systems are slightly or very critical.The process of developing and qualifying
safety-critical software and systems in regulated industries such as aerospace,
nuclear power stations, railways or automotive industry has long been well
rationalized and mastered. They use well-defined standards, regulatory
frameworks and processes, as well as formal techniques to assess and
demonstrate the quality and safety of the systems and software they develop.
However, the low level of formalization of specifications and the uncertainties
and opacity of machine learning-based components make it difficult to validate
and verify them using most traditional critical systems engineering methods.
This raises the question of qualification standards, and therefore of
regulations adapted to AI. With the AI Act, the European Commission has laid
the foundations for moving forward and building solid approaches to the
integration of AI-based applications that are safe, trustworthy and respect
European ethical values. The question then becomes "How can we rise to the
challenge of certification and propose methods and tools for trusted artificial
intelligence?"

---------------

### 01 Feb 2023 | [Model Monitoring and Robustness of In-Use Machine Learning Models:  Quantifying Data Distribution Shifts Using Population Stability Index](https://arxiv.org/abs/2302.00775) | [⬇️](https://arxiv.org/pdf/2302.00775)
*Aria Khademi, Michael Hopka, Devesh Upadhyay* 

  Safety goes first. Meeting and maintaining industry safety standards for
robustness of artificial intelligence (AI) and machine learning (ML) models
require continuous monitoring for faults and performance drops. Deep learning
models are widely used in industrial applications, e.g., computer vision, but
the susceptibility of their performance to environment changes (e.g., noise)
\emph{after deployment} on the product, are now well-known. A major challenge
is detecting data distribution shifts that happen, comparing the following:
{\bf (i)} development stage of AI and ML models, i.e., train/validation/test,
to {\bf (ii)} deployment stage on the product (i.e., even after `testing') in
the environment. We focus on a computer vision example related to autonomous
driving and aim at detecting shifts that occur as a result of adding noise to
images. We use the population stability index (PSI) as a measure of presence
and intensity of shift and present results of our empirical experiments showing
a promising potential for the PSI. We further discuss multiple aspects of model
monitoring and robustness that need to be analyzed \emph{simultaneously} to
achieve robustness for industry safety standards. We propose the need for and
the research direction toward \emph{categorizations} of problem classes and
examples where monitoring for robustness is required and present challenges and
pointers for future work from a \emph{practical} perspective.

---------------

### 26 Aug 2021 | [AI at work -- Mitigating safety and discriminatory risk with technical  standards](https://arxiv.org/abs/2108.11844) | [⬇️](https://arxiv.org/pdf/2108.11844)
*Nikolas Becker, Pauline Junginger, Lukas Martinez, Daniel Krupka,  Leonie Beining* 

  The use of artificial intelligence (AI) and AI methods in the workplace holds
both great opportunities as well as risks to occupational safety and
discrimination. In addition to legal regulation, technical standards will play
a key role in mitigating such risk by defining technical requirements for
development and testing of AI systems. This paper provides an overview and
assessment of existing international, European and German standards as well as
those currently under development. The paper is part of the research project
"ExamAI - Testing and Auditing of AI systems" and focusses on the use of AI in
an industrial production environment as well as in the realm of human resource
management (HR).

---------------

### 02 Aug 2023 | [Dual Governance: The intersection of centralized regulation and  crowdsourced safety mechanisms for Generative AI](https://arxiv.org/abs/2308.04448) | [⬇️](https://arxiv.org/pdf/2308.04448)
*Avijit Ghosh, Dhanya Lakshmi* 

  Generative Artificial Intelligence (AI) has seen mainstream adoption lately,
especially in the form of consumer-facing, open-ended, text and image
generating models. However, the use of such systems raises significant ethical
and safety concerns, including privacy violations, misinformation and
intellectual property theft. The potential for generative AI to displace human
creativity and livelihoods has also been under intense scrutiny. To mitigate
these risks, there is an urgent need of policies and regulations responsible
and ethical development in the field of generative AI. Existing and proposed
centralized regulations by governments to rein in AI face criticisms such as
not having sufficient clarity or uniformity, lack of interoperability across
lines of jurisdictions, restricting innovation, and hindering free market
competition. Decentralized protections via crowdsourced safety tools and
mechanisms are a potential alternative. However, they have clear deficiencies
in terms of lack of adequacy of oversight and difficulty of enforcement of
ethical and safety standards, and are thus not enough by themselves as a
regulation mechanism. We propose a marriage of these two strategies via a
framework we call Dual Governance. This framework proposes a cooperative
synergy between centralized government regulations in a U.S. specific context
and safety mechanisms developed by the community to protect stakeholders from
the harms of generative AI. By implementing the Dual Governance framework, we
posit that innovation and creativity can be promoted while ensuring safe and
ethical deployment of generative AI.

---------------

### 07 Sep 2023 | [Deep Learning Safety Concerns in Automated Driving Perception](https://arxiv.org/abs/2309.03774) | [⬇️](https://arxiv.org/pdf/2309.03774)
*Stephanie Abrecht, Alexander Hirsch, Shervin Raafatnia, Matthias  Woehrle* 

  Recent advances in the field of deep learning and impressive performance of
deep neural networks (DNNs) for perception have resulted in an increased demand
for their use in automated driving (AD) systems. The safety of such systems is
of utmost importance and thus requires to consider the unique properties of
DNNs.
  In order to achieve safety of AD systems with DNN-based perception components
in a systematic and comprehensive approach, so-called safety concerns have been
introduced as a suitable structuring element. On the one hand, the concept of
safety concerns is -- by design -- well aligned to existing standards relevant
for safety of AD systems such as ISO 21448 (SOTIF). On the other hand, it has
already inspired several academic publications and upcoming standards on AI
safety such as ISO PAS 8800.
  While the concept of safety concerns has been previously introduced, this
paper extends and refines it, leveraging feedback from various domain and
safety experts in the field. In particular, this paper introduces an additional
categorization for a better understanding as well as enabling cross-functional
teams to jointly address the concerns.

---------------

### 07 Nov 2023 | [Frontier AI Regulation: Managing Emerging Risks to Public Safety](https://arxiv.org/abs/2307.03718) | [⬇️](https://arxiv.org/pdf/2307.03718)
*Markus Anderljung, Joslyn Barnhart, Anton Korinek, Jade Leung, Cullen  O'Keefe, Jess Whittlestone, Shahar Avin, Miles Brundage, Justin Bullock,  Duncan Cass-Beggs, Ben Chang, Tantum Collins, Tim Fist, Gillian Hadfield,  Alan Hayes, Lewis Ho, Sara Hooker, Eric Horvitz, Noam Kolt, Jonas Schuett,  Yonadav Shavit, Divya Siddarth, Robert Trager, Kevin Wolf* 

  Advanced AI models hold the promise of tremendous benefits for humanity, but
society needs to proactively manage the accompanying risks. In this paper, we
focus on what we term "frontier AI" models: highly capable foundation models
that could possess dangerous capabilities sufficient to pose severe risks to
public safety. Frontier AI models pose a distinct regulatory challenge:
dangerous capabilities can arise unexpectedly; it is difficult to robustly
prevent a deployed model from being misused; and, it is difficult to stop a
model's capabilities from proliferating broadly. To address these challenges,
at least three building blocks for the regulation of frontier models are
needed: (1) standard-setting processes to identify appropriate requirements for
frontier AI developers, (2) registration and reporting requirements to provide
regulators with visibility into frontier AI development processes, and (3)
mechanisms to ensure compliance with safety standards for the development and
deployment of frontier AI models. Industry self-regulation is an important
first step. However, wider societal discussions and government intervention
will be needed to create standards and to ensure compliance with them. We
consider several options to this end, including granting enforcement powers to
supervisory authorities and licensure regimes for frontier AI models. Finally,
we propose an initial set of safety standards. These include conducting
pre-deployment risk assessments; external scrutiny of model behavior; using
risk assessments to inform deployment decisions; and monitoring and responding
to new information about model capabilities and uses post-deployment. We hope
this discussion contributes to the broader conversation on how to balance
public safety risks and innovation benefits from advances at the frontier of AI
development.

---------------

### 17 Aug 2022 | [Assurance Cases as Foundation Stone for Auditing AI-enabled and  Autonomous Systems: Workshop Results and Political Recommendations for Action  from the ExamAI Project](https://arxiv.org/abs/2208.08198) | [⬇️](https://arxiv.org/pdf/2208.08198)
*Rasmus Adler and Michael Klaes* 

  The European Machinery Directive and related harmonized standards do consider
that software is used to generate safety-relevant behavior of the machinery but
do not consider all kinds of software. In particular, software based on machine
learning (ML) are not considered for the realization of safety-relevant
behavior. This limits the introduction of suitable safety concepts for
autonomous mobile robots and other autonomous machinery, which commonly depend
on ML-based functions. We investigated this issue and the way safety standards
define safety measures to be implemented against software faults. Functional
safety standards use Safety Integrity Levels (SILs) to define which safety
measures shall be implemented. They provide rules for determining the SIL and
rules for selecting safety measures depending on the SIL. In this paper, we
argue that this approach can hardly be adopted with respect to ML and other
kinds of Artificial Intelligence (AI). Instead of simple rules for determining
an SIL and applying related measures against faults, we propose the use of
assurance cases to argue that the individually selected and applied measures
are sufficient in the given case. To get a first rating regarding the
feasibility and usefulness of our proposal, we presented and discussed it in a
workshop with experts from industry, German statutory accident insurance
companies, work safety and standardization commissions, and representatives
from various national, European, and international working groups dealing with
safety and AI. In this paper, we summarize the proposal and the workshop
discussion. Moreover, we check to which extent our proposal is in line with the
European AI Act proposal and current safety standardization initiatives
addressing AI and Autonomous Systems

---------------

### 21 Apr 2023 | [ChatGPT, Large Language Technologies, and the Bumpy Road of Benefiting  Humanity](https://arxiv.org/abs/2304.11163) | [⬇️](https://arxiv.org/pdf/2304.11163)
*Atoosa Kasirzadeh* 

  The allure of emerging AI technologies is undoubtedly thrilling. However, the
promise that AI technologies will benefit all of humanity is empty so long as
we lack a nuanced understanding of what humanity is supposed to be in the face
of widening global inequality and pressing existential threats. Going forward,
it is crucial to invest in rigorous and collaborative AI safety and ethics
research. We also need to develop standards in a sustainable and equitable way
that differentiate between merely speculative and well-researched questions.
Only the latter enable us to co-construct and deploy the values that are
necessary for creating beneficial AI. Failure to do so could result in a future
in which our AI technological advancements outstrip our ability to navigate
their ethical and social implications. This path we do not want to go down.

---------------

### 24 Nov 2023 | [RAISE -- Radiology AI Safety, an End-to-end lifecycle approach](https://arxiv.org/abs/2311.14570) | [⬇️](https://arxiv.org/pdf/2311.14570)
*M. Jorge Cardoso, Julia Moosbauer, Tessa S. Cook, B. Selnur Erdal,  Brad Genereaux, Vikash Gupta, Bennett A. Landman, Tiarna Lee, Parashkev  Nachev, Elanchezhian Somasundaram, Ronald M. Summers, Khaled Younis,  Sebastien Ourselin, Franz MJ Pfister* 

  The integration of AI into radiology introduces opportunities for improved
clinical care provision and efficiency but it demands a meticulous approach to
mitigate potential risks as with any other new technology. Beginning with
rigorous pre-deployment evaluation and validation, the focus should be on
ensuring models meet the highest standards of safety, effectiveness and
efficacy for their intended applications. Input and output guardrails
implemented during production usage act as an additional layer of protection,
identifying and addressing individual failures as they occur. Continuous
post-deployment monitoring allows for tracking population-level performance
(data drift), fairness, and value delivery over time. Scheduling reviews of
post-deployment model performance and educating radiologists about new
algorithmic-driven findings is critical for AI to be effective in clinical
practice. Recognizing that no single AI solution can provide absolute assurance
even when limited to its intended use, the synergistic application of quality
assurance at multiple levels - regulatory, clinical, technical, and ethical -
is emphasized. Collaborative efforts between stakeholders spanning healthcare
systems, industry, academia, and government are imperative to address the
multifaceted challenges involved. Trust in AI is an earned privilege,
contingent on a broad set of goals, among them transparently demonstrating that
the AI adheres to the same rigorous safety, effectiveness and efficacy
standards as other established medical technologies. By doing so, developers
can instil confidence among providers and patients alike, enabling the
responsible scaling of AI and the realization of its potential benefits. The
roadmap presented herein aims to expedite the achievement of deployable,
reliable, and safe AI in radiology.

---------------

### 14 Apr 2021 | [Towards a framework for evaluating the safety, acceptability and  efficacy of AI systems for health: an initial synthesis](https://arxiv.org/abs/2104.06910) | [⬇️](https://arxiv.org/pdf/2104.06910)
*Jessica Morley, Caroline Morton, Kassandra Karpathakis, Mariarosaria  Taddeo, Luciano Floridi* 

  The potential presented by Artificial Intelligence (AI) for healthcare has
long been recognised by the technical community. More recently, this potential
has been recognised by policymakers, resulting in considerable public and
private investment in the development of AI for healthcare across the globe.
Despite this, excepting limited success stories, real-world implementation of
AI systems into front-line healthcare has been limited. There are numerous
reasons for this, but a main contributory factor is the lack of internationally
accepted, or formalised, regulatory standards to assess AI safety and impact
and effectiveness. This is a well-recognised problem with numerous ongoing
research and policy projects to overcome it. Our intention here is to
contribute to this problem-solving effort by seeking to set out a minimally
viable framework for evaluating the safety, acceptability and efficacy of AI
systems for healthcare. We do this by conducting a systematic search across
Scopus, PubMed and Google Scholar to identify all the relevant literature
published between January 1970 and November 2020 related to the evaluation of:
output performance; efficacy; and real-world use of AI systems, and
synthesising the key themes according to the stages of evaluation: pre-clinical
(theoretical phase); exploratory phase; definitive phase; and post-market
surveillance phase (monitoring). The result is a framework to guide AI system
developers, policymakers, and regulators through a sufficient evaluation of an
AI system designed for use in healthcare.

---------------

### 21 Jul 2023 | [Model Reporting for Certifiable AI: A Proposal from Merging EU  Regulation into AI Development](https://arxiv.org/abs/2307.11525) | [⬇️](https://arxiv.org/pdf/2307.11525)
*Danilo Brajovic, Niclas Renner, Vincent Philipp Goebels, Philipp  Wagner, Benjamin Fresz, Martin Biller, Mara Klaeb, Janika Kutz, Jens  Neuhuettler, Marco F. Huber* 

  Despite large progress in Explainable and Safe AI, practitioners suffer from
a lack of regulation and standards for AI safety. In this work we merge recent
regulation efforts by the European Union and first proposals for AI guidelines
with recent trends in research: data and model cards. We propose the use of
standardized cards to document AI applications throughout the development
process. Our main contribution is the introduction of use-case and operation
cards, along with updates for data and model cards to cope with regulatory
requirements. We reference both recent research as well as the source of the
regulation in our cards and provide references to additional support material
and toolboxes whenever possible. The goal is to design cards that help
practitioners develop safe AI systems throughout the development process, while
enabling efficient third-party auditing of AI applications, being easy to
understand, and building trust in the system. Our work incorporates insights
from interviews with certification experts as well as developers and
individuals working with the developed AI applications.

---------------

### 29 Feb 2024 | [NewsBench: Systematic Evaluation of LLMs for Writing Proficiency and  Safety Adherence in Chinese Journalistic Editorial Applications](https://arxiv.org/abs/2403.00862) | [⬇️](https://arxiv.org/pdf/2403.00862)
*Miao Li and Ming-Bin Chen and Bo Tang and Shengbin Hou and Pengyu Wang  and Haiying Deng and Zhiyu Li and Feiyu Xiong and Keming Mao and Peng Cheng  and Yi Luo* 

  This study presents NewsBench, a novel benchmark framework developed to
evaluate the capability of Large Language Models (LLMs) in Chinese Journalistic
Writing Proficiency (JWP) and their Safety Adherence (SA), addressing the gap
between journalistic ethics and the risks associated with AI utilization.
Comprising 1,267 tasks across 5 editorial applications, 7 aspects (including
safety and journalistic writing with 4 detailed facets), and spanning 24 news
topics domains, NewsBench employs two GPT-4 based automatic evaluation
protocols validated by human assessment. Our comprehensive analysis of 11 LLMs
highlighted GPT-4 and ERNIE Bot as top performers, yet revealed a relative
deficiency in journalistic ethic adherence during creative writing tasks. These
findings underscore the need for enhanced ethical guidance in AI-generated
journalistic content, marking a step forward in aligning AI capabilities with
journalistic standards and safety considerations.

---------------

### 09 Jul 2020 | [AI safety: state of the field through quantitative lens](https://arxiv.org/abs/2002.05671) | [⬇️](https://arxiv.org/pdf/2002.05671)
*Mislav Juric, Agneza Sandic, Mario Brcic* 

  Last decade has seen major improvements in the performance of artificial
intelligence which has driven wide-spread applications. Unforeseen effects of
such mass-adoption has put the notion of AI safety into the public eye. AI
safety is a relatively new field of research focused on techniques for building
AI beneficial for humans. While there exist survey papers for the field of AI
safety, there is a lack of a quantitative look at the research being conducted.
The quantitative aspect gives a data-driven insight about the emerging trends,
knowledge gaps and potential areas for future research. In this paper,
bibliometric analysis of the literature finds significant increase in research
activity since 2015. Also, the field is so new that most of the technical
issues are open, including: explainability with its long-term utility, and
value alignment which we have identified as the most important long-term
research topic. Equally, there is a severe lack of research into concrete
policies regarding AI. As we expect AI to be the one of the main driving forces
of changes in society, AI safety is the field under which we need to decide the
direction of humanity's future.

---------------

### 27 Jan 2024 | [Low-Resource Languages Jailbreak GPT-4](https://arxiv.org/abs/2310.02446) | [⬇️](https://arxiv.org/pdf/2310.02446)
*Zheng-Xin Yong, Cristina Menghini and Stephen H. Bach* 

  AI safety training and red-teaming of large language models (LLMs) are
measures to mitigate the generation of unsafe content. Our work exposes the
inherent cross-lingual vulnerability of these safety mechanisms, resulting from
the linguistic inequality of safety training data, by successfully
circumventing GPT-4's safeguard through translating unsafe English inputs into
low-resource languages. On the AdvBenchmark, GPT-4 engages with the unsafe
translated inputs and provides actionable items that can get the users towards
their harmful goals 79% of the time, which is on par with or even surpassing
state-of-the-art jailbreaking attacks. Other high-/mid-resource languages have
significantly lower attack success rate, which suggests that the cross-lingual
vulnerability mainly applies to low-resource languages. Previously, limited
training on low-resource languages primarily affects speakers of those
languages, causing technological disparities. However, our work highlights a
crucial shift: this deficiency now poses a risk to all LLMs users. Publicly
available translation APIs enable anyone to exploit LLMs' safety
vulnerabilities. Therefore, our work calls for a more holistic red-teaming
efforts to develop robust multilingual safeguards with wide language coverage.

---------------

### 23 Feb 2023 | [Actionable Guidance for High-Consequence AI Risk Management: Towards  Standards Addressing AI Catastrophic Risks](https://arxiv.org/abs/2206.08966) | [⬇️](https://arxiv.org/pdf/2206.08966)
*Anthony M. Barrett, Dan Hendrycks, Jessica Newman, Brandie Nonnecke* 

  Artificial intelligence (AI) systems can provide many beneficial capabilities
but also risks of adverse events. Some AI systems could present risks of events
with very high or catastrophic consequences at societal scale. The US National
Institute of Standards and Technology (NIST) has been developing the NIST
Artificial Intelligence Risk Management Framework (AI RMF) as voluntary
guidance on AI risk assessment and management for AI developers and others. For
addressing risks of events with catastrophic consequences, NIST indicated a
need to translate from high level principles to actionable risk management
guidance.
  In this document, we provide detailed actionable-guidance recommendations
focused on identifying and managing risks of events with very high or
catastrophic consequences, intended as a risk management practices resource for
NIST for AI RMF version 1.0 (released in January 2023), or for AI RMF users, or
for other AI risk management guidance and standards as appropriate. We also
provide our methodology for our recommendations.
  We provide actionable-guidance recommendations for AI RMF 1.0 on: identifying
risks from potential unintended uses and misuses of AI systems; including
catastrophic-risk factors within the scope of risk assessments and impact
assessments; identifying and mitigating human rights harms; and reporting
information on AI risk factors including catastrophic-risk factors.
  In addition, we provide recommendations on additional issues for a roadmap
for later versions of the AI RMF or supplementary publications. These include:
providing an AI RMF Profile with supplementary guidance for cutting-edge
increasingly multi-purpose or general-purpose AI.
  We aim for this work to be a concrete risk-management practices contribution,
and to stimulate constructive dialogue on how to address catastrophic risks and
associated issues in AI standards.

---------------

### 27 Feb 2023 | [Towards Audit Requirements for AI-based Systems in Mobility Applications](https://arxiv.org/abs/2302.13567) | [⬇️](https://arxiv.org/pdf/2302.13567)
*Devi Padmavathi Alagarswamy, Christian Berghoff, Vasilios Danos,  Fabian Langer, Thora Markert, Georg Schneider, Arndt von Twickel, Fabian  Woitschek* 

  Various mobility applications like advanced driver assistance systems
increasingly utilize artificial intelligence (AI) based functionalities.
Typically, deep neural networks (DNNs) are used as these provide the best
performance on the challenging perception, prediction or planning tasks that
occur in real driving environments. However, current regulations like UNECE R
155 or ISO 26262 do not consider AI-related aspects and are only applied to
traditional algorithm-based systems. The non-existence of AI-specific standards
or norms prevents the practical application and can harm the trust level of
users. Hence, it is important to extend existing standardization for security
and safety to consider AI-specific challenges and requirements. To take a step
towards a suitable regulation we propose 50 technical requirements or best
practices that extend existing regulations and address the concrete needs for
DNN-based systems. We show the applicability, usefulness and meaningfulness of
the proposed requirements by performing an exemplary audit of a DNN-based
traffic sign recognition system using three of the proposed requirements.

---------------

### 09 Nov 2023 | [A Framework to Assess (Dis)agreement Among Diverse Rater Groups](https://arxiv.org/abs/2311.05074) | [⬇️](https://arxiv.org/pdf/2311.05074)
*Vinodkumar Prabhakaran, Christopher Homan, Lora Aroyo, Alicia Parrish,  Alex Taylor, Mark D\'iaz, Ding Wang* 

  Recent advancements in conversational AI have created an urgent need for
safety guardrails that prevent users from being exposed to offensive and
dangerous content. Much of this work relies on human ratings and feedback, but
does not account for the fact that perceptions of offense and safety are
inherently subjective and that there may be systematic disagreements between
raters that align with their socio-demographic identities. Instead, current
machine learning approaches largely ignore rater subjectivity and use gold
standards that obscure disagreements (e.g., through majority voting). In order
to better understand the socio-cultural leanings of such tasks, we propose a
comprehensive disagreement analysis framework to measure systematic diversity
in perspectives among different rater subgroups. We then demonstrate its
utility by applying this framework to a dataset of human-chatbot conversations
rated by a demographically diverse pool of raters. Our analysis reveals
specific rater groups that have more diverse perspectives than the rest, and
informs demographic axes that are crucial to consider for safety annotations.

---------------

### 23 Jan 2024 | [Considering Fundamental Rights in the European Standardisation of  Artificial Intelligence: Nonsense or Strategic Alliance?](https://arxiv.org/abs/2402.16869) | [⬇️](https://arxiv.org/pdf/2402.16869)
*Marion Ho-Dac (UA)* 

  In the European context, both the EU AI Act proposal and the draft
Standardisation Request on safe and trustworthy AI link standardisation to
fundamental rights. However, these texts do not provide any guidelines that
specify and detail the relationship between AI standards and fundamental
rights, its meaning or implication. This chapter aims to clarify this critical
regulatory blind spot. The main issue tackled is whether the adoption of AI
harmonised standards, based on the future AI Act, should take into account
fundamental rights. In our view, the response is yes. The high risks posed by
certain AI systems relate in particular to infringements of fundamental rights.
Therefore, mitigating such risks involves fundamental rights considerations and
this is what future harmonised standards should reflect. At the same time,
valid criticisms of the European standardisation process have to be addressed.
Finally, the practical incorporation of fundamental rights considerations in
the ongoing European standardisation of AI systems is discussed.

---------------
**Date:** 05 Jun 2023

**Title:** The Chai Platform's AI Safety Framework

**Abstract Link:** [https://arxiv.org/abs/2306.02979](https://arxiv.org/abs/2306.02979)

**PDF Link:** [https://arxiv.org/pdf/2306.02979](https://arxiv.org/pdf/2306.02979)

---

**Date:** 11 Sep 2023

**Title:** International Governance of Civilian AI: A Jurisdictional Certification  Approach

**Abstract Link:** [https://arxiv.org/abs/2308.15514](https://arxiv.org/abs/2308.15514)

**PDF Link:** [https://arxiv.org/pdf/2308.15514](https://arxiv.org/pdf/2308.15514)

---

**Date:** 27 Sep 2023

**Title:** No Trust without regulation!

**Abstract Link:** [https://arxiv.org/abs/2311.06263](https://arxiv.org/abs/2311.06263)

**PDF Link:** [https://arxiv.org/pdf/2311.06263](https://arxiv.org/pdf/2311.06263)

---

**Date:** 01 Feb 2023

**Title:** Model Monitoring and Robustness of In-Use Machine Learning Models:  Quantifying Data Distribution Shifts Using Population Stability Index

**Abstract Link:** [https://arxiv.org/abs/2302.00775](https://arxiv.org/abs/2302.00775)

**PDF Link:** [https://arxiv.org/pdf/2302.00775](https://arxiv.org/pdf/2302.00775)

---

**Date:** 26 Aug 2021

**Title:** AI at work -- Mitigating safety and discriminatory risk with technical  standards

**Abstract Link:** [https://arxiv.org/abs/2108.11844](https://arxiv.org/abs/2108.11844)

**PDF Link:** [https://arxiv.org/pdf/2108.11844](https://arxiv.org/pdf/2108.11844)

---

**Date:** 02 Aug 2023

**Title:** Dual Governance: The intersection of centralized regulation and  crowdsourced safety mechanisms for Generative AI

**Abstract Link:** [https://arxiv.org/abs/2308.04448](https://arxiv.org/abs/2308.04448)

**PDF Link:** [https://arxiv.org/pdf/2308.04448](https://arxiv.org/pdf/2308.04448)

---

**Date:** 07 Sep 2023

**Title:** Deep Learning Safety Concerns in Automated Driving Perception

**Abstract Link:** [https://arxiv.org/abs/2309.03774](https://arxiv.org/abs/2309.03774)

**PDF Link:** [https://arxiv.org/pdf/2309.03774](https://arxiv.org/pdf/2309.03774)

---

**Date:** 07 Nov 2023

**Title:** Frontier AI Regulation: Managing Emerging Risks to Public Safety

**Abstract Link:** [https://arxiv.org/abs/2307.03718](https://arxiv.org/abs/2307.03718)

**PDF Link:** [https://arxiv.org/pdf/2307.03718](https://arxiv.org/pdf/2307.03718)

---

**Date:** 17 Aug 2022

**Title:** Assurance Cases as Foundation Stone for Auditing AI-enabled and  Autonomous Systems: Workshop Results and Political Recommendations for Action  from the ExamAI Project

**Abstract Link:** [https://arxiv.org/abs/2208.08198](https://arxiv.org/abs/2208.08198)

**PDF Link:** [https://arxiv.org/pdf/2208.08198](https://arxiv.org/pdf/2208.08198)

---

**Date:** 21 Apr 2023

**Title:** ChatGPT, Large Language Technologies, and the Bumpy Road of Benefiting  Humanity

**Abstract Link:** [https://arxiv.org/abs/2304.11163](https://arxiv.org/abs/2304.11163)

**PDF Link:** [https://arxiv.org/pdf/2304.11163](https://arxiv.org/pdf/2304.11163)

---

**Date:** 24 Nov 2023

**Title:** RAISE -- Radiology AI Safety, an End-to-end lifecycle approach

**Abstract Link:** [https://arxiv.org/abs/2311.14570](https://arxiv.org/abs/2311.14570)

**PDF Link:** [https://arxiv.org/pdf/2311.14570](https://arxiv.org/pdf/2311.14570)

---

**Date:** 14 Apr 2021

**Title:** Towards a framework for evaluating the safety, acceptability and  efficacy of AI systems for health: an initial synthesis

**Abstract Link:** [https://arxiv.org/abs/2104.06910](https://arxiv.org/abs/2104.06910)

**PDF Link:** [https://arxiv.org/pdf/2104.06910](https://arxiv.org/pdf/2104.06910)

---

**Date:** 21 Jul 2023

**Title:** Model Reporting for Certifiable AI: A Proposal from Merging EU  Regulation into AI Development

**Abstract Link:** [https://arxiv.org/abs/2307.11525](https://arxiv.org/abs/2307.11525)

**PDF Link:** [https://arxiv.org/pdf/2307.11525](https://arxiv.org/pdf/2307.11525)

---

**Date:** 29 Feb 2024

**Title:** NewsBench: Systematic Evaluation of LLMs for Writing Proficiency and  Safety Adherence in Chinese Journalistic Editorial Applications

**Abstract Link:** [https://arxiv.org/abs/2403.00862](https://arxiv.org/abs/2403.00862)

**PDF Link:** [https://arxiv.org/pdf/2403.00862](https://arxiv.org/pdf/2403.00862)

---

**Date:** 09 Jul 2020

**Title:** AI safety: state of the field through quantitative lens

**Abstract Link:** [https://arxiv.org/abs/2002.05671](https://arxiv.org/abs/2002.05671)

**PDF Link:** [https://arxiv.org/pdf/2002.05671](https://arxiv.org/pdf/2002.05671)

---

**Date:** 27 Jan 2024

**Title:** Low-Resource Languages Jailbreak GPT-4

**Abstract Link:** [https://arxiv.org/abs/2310.02446](https://arxiv.org/abs/2310.02446)

**PDF Link:** [https://arxiv.org/pdf/2310.02446](https://arxiv.org/pdf/2310.02446)

---

**Date:** 23 Feb 2023

**Title:** Actionable Guidance for High-Consequence AI Risk Management: Towards  Standards Addressing AI Catastrophic Risks

**Abstract Link:** [https://arxiv.org/abs/2206.08966](https://arxiv.org/abs/2206.08966)

**PDF Link:** [https://arxiv.org/pdf/2206.08966](https://arxiv.org/pdf/2206.08966)

---

**Date:** 27 Feb 2023

**Title:** Towards Audit Requirements for AI-based Systems in Mobility Applications

**Abstract Link:** [https://arxiv.org/abs/2302.13567](https://arxiv.org/abs/2302.13567)

**PDF Link:** [https://arxiv.org/pdf/2302.13567](https://arxiv.org/pdf/2302.13567)

---

**Date:** 09 Nov 2023

**Title:** A Framework to Assess (Dis)agreement Among Diverse Rater Groups

**Abstract Link:** [https://arxiv.org/abs/2311.05074](https://arxiv.org/abs/2311.05074)

**PDF Link:** [https://arxiv.org/pdf/2311.05074](https://arxiv.org/pdf/2311.05074)

---

**Date:** 23 Jan 2024

**Title:** Considering Fundamental Rights in the European Standardisation of  Artificial Intelligence: Nonsense or Strategic Alliance?

**Abstract Link:** [https://arxiv.org/abs/2402.16869](https://arxiv.org/abs/2402.16869)

**PDF Link:** [https://arxiv.org/pdf/2402.16869](https://arxiv.org/pdf/2402.16869)

---

