LLM Behavioral Training 🎹

### 🔎 LLM Behavioral Training 🎹

🎶

I'm a beginner at the piano and I'm looking for a way to improve my skills. I've heard that behavioral training can be helpful, but I'm not sure what it entails. Can you explain how behavioral training can help me improve my piano skills and provide some examples of exercises I can do?

Behavioral training is a type of training that focuses on changing behaviors and habits to improve skills and performance. In the context of piano playing, behavioral training can help you develop good practice habits, improve your technique, and increase your musicality.

Here are some examples of behavioral training exercises you can do to improve your piano skills:

1. Set specific goals: Before you start practicing, set specific goals for what you want to achieve. This could be learning a new song, improving your technique, or working on a particular skill. Having clear goals will help you stay focused and motivated during your practice sessions.
2. Break down tasks: When learning a new song or skill, break it down into smaller tasks. This will make it easier to focus on one thing at a time and prevent you from feeling overwhelmed. For example, if you're learning a new song, start by practicing the left-hand part alone, then the right-hand part, and finally put both hands together.
3. Practice slowly: When practicing a new skill or song, start by practicing it slowly. This will help you develop muscle memory and ensure that you're playing the notes correctly. Once you feel comfortable playing it slowly, gradually increase the tempo.
4. Use a metronome: A metronome can help you develop a sense of rhythm and timing. Set the metronome to a slow tempo and practice playing along with it. Gradually increase the tempo as you become more comfortable.
5. Record yourself: Recording yourself while you practice can help you identify areas that need improvement. Listen to the recording and take note of any mistakes or areas where you could improve.
6. Practice regularly: Consistency is key when it comes to improving your piano skills. Set aside time each day to practice, even if it's just for a few minutes.
7. Get feedback: Consider working with a piano teacher or mentor who can provide feedback and guidance. They can help you identify areas where you need improvement and provide exercises to help you improve.

By incorporating these behavioral training exercises into your
# 🩺🔍 Search Results
### 26 Oct 2023 | [Large Content And Behavior Models To Understand, Simulate, And Optimize  Content And Behavior](https://arxiv.org/abs/2309.00359) | [⬇️](https://arxiv.org/pdf/2309.00359)
*Ashmit Khandelwal, Aditya Agrawal, Aanisha Bhattacharyya, Yaman K  Singla, Somesh Singh, Uttaran Bhattacharya, Ishita Dasgupta, Stefano  Petrangeli, Rajiv Ratn Shah, Changyou Chen, Balaji Krishnamurthy* 

  Shannon, in his seminal paper introducing information theory, divided the
communication into three levels: technical, semantic, and effectivenss. While
the technical level is concerned with accurate reconstruction of transmitted
symbols, the semantic and effectiveness levels deal with the inferred meaning
and its effect on the receiver. Thanks to telecommunications, the first level
problem has produced great advances like the internet. Large Language Models
(LLMs) make some progress towards the second goal, but the third level still
remains largely untouched. The third problem deals with predicting and
optimizing communication for desired receiver behavior. LLMs, while showing
wide generalization capabilities across a wide range of tasks, are unable to
solve for this. One reason for the underperformance could be a lack of
``behavior tokens'' in LLMs' training corpora. Behavior tokens define receiver
behavior over a communication, such as shares, likes, clicks, purchases,
retweets, etc. While preprocessing data for LLM training, behavior tokens are
often removed from the corpora as noise. Therefore, in this paper, we make some
initial progress towards reintroducing behavior tokens in LLM training. The
trained models, other than showing similar performance to LLMs on content
understanding tasks, show generalization capabilities on behavior simulation,
content simulation, behavior understanding, and behavior domain adaptation.
Using a wide range of tasks on two corpora, we show results on all these
capabilities. We call these models Large Content and Behavior Models (LCBMs).
Further, to spur more research on LCBMs, we release our new Content Behavior
Corpus (CBC), a repository containing communicator, message, and corresponding
receiver behavior.

---------------

### 27 Nov 2023 | [In-Context Learning Dynamics with Random Binary Sequences](https://arxiv.org/abs/2310.17639) | [⬇️](https://arxiv.org/pdf/2310.17639)
*Eric J. Bigelow, Ekdeep Singh Lubana, Robert P. Dick, Hidenori Tanaka,  Tomer D. Ullman* 

  Large language models (LLMs) trained on huge corpora of text datasets
demonstrate intriguing capabilities, achieving state-of-the-art performance on
tasks they were not explicitly trained for. The precise nature of LLM
capabilities is often mysterious, and different prompts can elicit different
capabilities through in-context learning. We propose a framework that enables
us to analyze in-context learning dynamics to understand latent concepts
underlying LLMs' behavioral patterns. This provides a more nuanced
understanding than success-or-failure evaluation benchmarks, but does not
require observing internal activations as a mechanistic interpretation of
circuits would. Inspired by the cognitive science of human randomness
perception, we use random binary sequences as context and study dynamics of
in-context learning by manipulating properties of context data, such as
sequence length. In the latest GPT-3.5+ models, we find emergent abilities to
generate seemingly random numbers and learn basic formal languages, with
striking in-context learning dynamics where model outputs transition sharply
from seemingly random behaviors to deterministic repetition.

---------------

### 01 Feb 2024 | [Plan-Grounded Large Language Models for Dual Goal Conversational  Settings](https://arxiv.org/abs/2402.01053) | [⬇️](https://arxiv.org/pdf/2402.01053)
*Diogo Gl\'oria-Silva, Rafael Ferreira, Diogo Tavares, David Semedo,  Jo\~ao Magalh\~aes* 

  Training Large Language Models (LLMs) to follow user instructions has been
shown to supply the LLM with ample capacity to converse fluently while being
aligned with humans. Yet, it is not completely clear how an LLM can lead a
plan-grounded conversation in mixed-initiative settings where instructions flow
in both directions of the conversation, i.e. both the LLM and the user provide
instructions to one another. In this paper, we tackle a dual goal
mixed-initiative conversational setting where the LLM not only grounds the
conversation on an arbitrary plan but also seeks to satisfy both a procedural
plan and user instructions. The LLM is then responsible for guiding the user
through the plan and, at the same time, adapting to new circumstances,
answering questions, and activating safety guardrails when needed. We propose a
novel LLM that grounds the dialogue on a procedural plan, can take the dialogue
initiative, and enforces guardrails on the system's behavior, while also
improving the LLM's responses to unexpected user behavior. Experiments in
controlled settings and with real users show that the best-performing model,
which we call PlanLLM, achieves a 2.1x improvement over a strong baseline.
Moreover, experiments also show good generalization to unseen domains.

---------------

### 02 Sep 2023 | [BLSP: Bootstrapping Language-Speech Pre-training via Behavior Alignment  of Continuation Writing](https://arxiv.org/abs/2309.00916) | [⬇️](https://arxiv.org/pdf/2309.00916)
*Chen Wang, Minpeng Liao, Zhongqiang Huang, Jinliang Lu, Junhong Wu,  Yuchen Liu, Chengqing Zong, Jiajun Zhang* 

  The emergence of large language models (LLMs) has sparked significant
interest in extending their remarkable language capabilities to speech.
However, modality alignment between speech and text still remains an open
problem. Current solutions can be categorized into two strategies. One is a
cascaded approach where outputs (tokens or states) of a separately trained
speech recognition system are used as inputs for LLMs, which limits their
potential in modeling alignment between speech and text. The other is an
end-to-end approach that relies on speech instruction data, which is very
difficult to collect in large quantities. In this paper, we address these
issues and propose the BLSP approach that Bootstraps Language-Speech
Pre-training via behavior alignment of continuation writing. We achieve this by
learning a lightweight modality adapter between a frozen speech encoder and an
LLM, ensuring that the LLM exhibits the same generation behavior regardless of
the modality of input: a speech segment or its transcript. The training process
can be divided into two steps. The first step prompts an LLM to generate texts
with speech transcripts as prefixes, obtaining text continuations. In the
second step, these continuations are used as supervised signals to train the
modality adapter in an end-to-end manner. We demonstrate that this
straightforward process can extend the capabilities of LLMs to speech, enabling
speech recognition, speech translation, spoken language understanding, and
speech conversation, even in zero-shot cross-lingual scenarios.

---------------

### 29 Feb 2024 | [ReLLa: Retrieval-enhanced Large Language Models for Lifelong Sequential  Behavior Comprehension in Recommendation](https://arxiv.org/abs/2308.11131) | [⬇️](https://arxiv.org/pdf/2308.11131)
*Jianghao Lin, Rong Shan, Chenxu Zhu, Kounianhua Du, Bo Chen, Shigang  Quan, Ruiming Tang, Yong Yu, Weinan Zhang* 

  With large language models (LLMs) achieving remarkable breakthroughs in
natural language processing (NLP) domains, LLM-enhanced recommender systems
have received much attention and have been actively explored currently. In this
paper, we focus on adapting and empowering a pure large language model for
zero-shot and few-shot recommendation tasks. First and foremost, we identify
and formulate the lifelong sequential behavior incomprehension problem for LLMs
in recommendation domains, i.e., LLMs fail to extract useful information from a
textual context of long user behavior sequence, even if the length of context
is far from reaching the context limitation of LLMs. To address such an issue
and improve the recommendation performance of LLMs, we propose a novel
framework, namely Retrieval-enhanced Large Language models (ReLLa) for
recommendation tasks in both zero-shot and few-shot settings. For zero-shot
recommendation, we perform semantic user behavior retrieval (SUBR) to improve
the data quality of testing samples, which greatly reduces the difficulty for
LLMs to extract the essential knowledge from user behavior sequences. As for
few-shot recommendation, we further design retrieval-enhanced instruction
tuning (ReiT) by adopting SUBR as a data augmentation technique for training
samples. Specifically, we develop a mixed training dataset consisting of both
the original data samples and their retrieval-enhanced counterparts. We conduct
extensive experiments on three real-world public datasets to demonstrate the
superiority of ReLLa compared with existing baseline models, as well as its
capability for lifelong sequential behavior comprehension. To be highlighted,
with only less than 10% training samples, few-shot ReLLa can outperform
traditional CTR models that are trained on the entire training set (e.g.,
DCNv2, DIN, SIM). The code is available
\url{https://github.com/LaVieEnRose365/ReLLa}.

---------------

### 03 Jun 2023 | [Guided scenarios with simulated expert personae: a remarkable strategy  to perform cognitive work](https://arxiv.org/abs/2306.03104) | [⬇️](https://arxiv.org/pdf/2306.03104)
*David Van Buren* 

  Large language models (LLMs) trained on a substantial corpus of human
knowledge and literature productively work with a large array of facts from
that corpus. Surprisingly, they are also able to re-create the behaviors of
personae that are captured within the corpus. By forming teams of simulated
personae, supplying contexts that set the stage, and providing gentle prompts,
one can move through scenarios that elicit expert behavior to perform
meaningful cognitive work. The power of this strategy is demonstrated with two
examples, one attacking factuality of LLM responses and the other reproducing a
very recently published result in quantum optics.

---------------

### 25 May 2023 | [Code as Policies: Language Model Programs for Embodied Control](https://arxiv.org/abs/2209.07753) | [⬇️](https://arxiv.org/pdf/2209.07753)
*Jacky Liang, Wenlong Huang, Fei Xia, Peng Xu, Karol Hausman, Brian  Ichter, Pete Florence, Andy Zeng* 

  Large language models (LLMs) trained on code completion have been shown to be
capable of synthesizing simple Python programs from docstrings [1]. We find
that these code-writing LLMs can be re-purposed to write robot policy code,
given natural language commands. Specifically, policy code can express
functions or feedback loops that process perception outputs (e.g.,from object
detectors [2], [3]) and parameterize control primitive APIs. When provided as
input several example language commands (formatted as comments) followed by
corresponding policy code (via few-shot prompting), LLMs can take in new
commands and autonomously re-compose API calls to generate new policy code
respectively. By chaining classic logic structures and referencing third-party
libraries (e.g., NumPy, Shapely) to perform arithmetic, LLMs used in this way
can write robot policies that (i) exhibit spatial-geometric reasoning, (ii)
generalize to new instructions, and (iii) prescribe precise values (e.g.,
velocities) to ambiguous descriptions ("faster") depending on context (i.e.,
behavioral commonsense). This paper presents code as policies: a robot-centric
formulation of language model generated programs (LMPs) that can represent
reactive policies (e.g., impedance controllers), as well as waypoint-based
policies (vision-based pick and place, trajectory-based control), demonstrated
across multiple real robot platforms. Central to our approach is prompting
hierarchical code-gen (recursively defining undefined functions), which can
write more complex code and also improves state-of-the-art to solve 39.8% of
problems on the HumanEval [1] benchmark. Code and videos are available at
https://code-as-policies.github.io

---------------

### 30 May 2023 | [LLM-BRAIn: AI-driven Fast Generation of Robot Behaviour Tree based on  Large Language Model](https://arxiv.org/abs/2305.19352) | [⬇️](https://arxiv.org/pdf/2305.19352)
*Artem Lykov and Dzmitry Tsetserukou* 

  This paper presents a novel approach in autonomous robot control, named
LLM-BRAIn, that makes possible robot behavior generation, based on operator's
commands. LLM-BRAIn is a transformer-based Large Language Model (LLM)
fine-tuned from Stanford Alpaca 7B model to generate robot behavior tree (BT)
from the text description. We train the LLM-BRAIn on 8,5k instruction-following
demonstrations, generated in the style of self-instruct using
text-davinchi-003. The developed model accurately builds complex robot behavior
while remaining small enough to be run on the robot's onboard microcomputer.
The model gives structural and logical correct BTs and can successfully manage
instructions that were not presented in training set. The experiment did not
reveal any significant subjective differences between BTs generated by
LLM-BRAIn and those created by humans (on average, participants were able to
correctly distinguish between LLM-BRAIn generated BTs and human-created BTs in
only 4.53 out of 10 cases, indicating that their performance was close to
random chance). The proposed approach potentially can be applied to mobile
robotics, drone operation, robot manipulator systems and Industry 4.0.

---------------

### 17 Feb 2024 | [Training Language Model Agents without Modifying Language Models](https://arxiv.org/abs/2402.11359) | [⬇️](https://arxiv.org/pdf/2402.11359)
*Shaokun Zhang, Jieyu Zhang, Jiale Liu, Linxin Song, Chi Wang, Ranjay  Krishna, Qingyun Wu* 

  Researchers and practitioners have recently reframed powerful Large Language
Models (LLMs) as agents, enabling them to automate complex tasks largely via
the use of specialized functions. To facilitate the development of LLM agents,
we present a novel paradigm of training LLM agents without modifying the LLM
weights, which is particularly useful when the LLMs are difficult or
inaccessible for modifications. Inspired by how humans continuously forge tools
to adapt to real-world tasks, rather than change our biological structure to
fit a static set of tools, we propose to progressively forge agent's functions
to better solve the downstream tasks instead of modifying the LLM weights. By
treating the functions as learnable `agent parameters' and leveraging the
fundamental idea of model training in artificial intelligence, we develop
AgentOptimizer that employs the LLM to update agents' functions and devise an
agent training algorithm with two strategies, roll-back, and early-stop, to
streamline the training process. With extensive experiments, we showcase that
the agent training paradigm could significantly improve the performance of
representative LLM agents in various downstream tasks. We also study the
behavior of the agent training regarding aspects like the learning curve and
domain transferability.

---------------

### 27 Feb 2024 | [Can an LLM-Powered Socially Assistive Robot Effectively and Safely  Deliver Cognitive Behavioral Therapy? A Study With University Students](https://arxiv.org/abs/2402.17937) | [⬇️](https://arxiv.org/pdf/2402.17937)
*Mina J. Kian, Mingyu Zong, Katrin Fischer, Abhyuday Singh, Anna-Maria  Velentza, Pau Sang, Shriya Upadhyay, Anika Gupta, Misha A. Faruki, Wallace  Browning, Sebastien M. R. Arnold, Bhaskar Krishnamachari, and Maja J. Mataric* 

  Cognitive behavioral therapy (CBT) is a widely used therapeutic method for
guiding individuals toward restructuring their thinking patterns as a means of
addressing anxiety, depression, and other challenges. We developed a large
language model (LLM)-powered prompt-engineered socially assistive robot (SAR)
that guides participants through interactive CBT at-home exercises. We
evaluated the performance of the SAR through a 15-day study with 38 university
students randomly assigned to interact daily with the robot or a chatbot (using
the same LLM), or complete traditional CBT worksheets throughout the duration
of the study. We measured weekly therapeutic outcomes, changes in
pre-/post-session anxiety measures, and adherence to completing CBT exercises.
We found that self-reported measures of general psychological distress
significantly decreased over the study period in the robot and worksheet
conditions but not the chatbot condition. Furthermore, the SAR enabled
significant single-session improvements for more sessions than the other two
conditions combined. Our findings suggest that SAR-guided LLM-powered CBT may
be as effective as traditional worksheet methods in supporting therapeutic
progress from the beginning to the end of the study and superior in decreasing
user anxiety immediately after completing the CBT exercise.

---------------

### 01 Feb 2024 | [LLMs learn governing principles of dynamical systems, revealing an  in-context neural scaling law](https://arxiv.org/abs/2402.00795) | [⬇️](https://arxiv.org/pdf/2402.00795)
*Toni J.B. Liu, Nicolas Boull\'e, Rapha\"el Sarfati, Christopher J.  Earls* 

  Pretrained large language models (LLMs) are surprisingly effective at
performing zero-shot tasks, including time-series forecasting. However,
understanding the mechanisms behind such capabilities remains highly
challenging due to the complexity of the models. In this paper, we study LLMs'
ability to extrapolate the behavior of dynamical systems whose evolution is
governed by principles of physical interest. Our results show that LLaMA 2, a
language model trained primarily on texts, achieves accurate predictions of
dynamical system time series without fine-tuning or prompt engineering.
Moreover, the accuracy of the learned physical rules increases with the length
of the input context window, revealing an in-context version of neural scaling
law. Along the way, we present a flexible and efficient algorithm for
extracting probability density functions of multi-digit numbers directly from
LLMs.

---------------

### 12 Dec 2023 | [FairSISA: Ensemble Post-Processing to Improve Fairness of Unlearning in  LLMs](https://arxiv.org/abs/2312.07420) | [⬇️](https://arxiv.org/pdf/2312.07420)
*Swanand Ravindra Kadhe, Anisa Halimi, Ambrish Rawat, Nathalie  Baracaldo* 

  Training large language models (LLMs) is a costly endeavour in terms of time
and computational resources. The large amount of training data used during the
unsupervised pre-training phase makes it difficult to verify all data and,
unfortunately, undesirable data may be ingested during training. Re-training
from scratch is impractical and has led to the creation of the 'unlearning'
discipline where models are modified to "unlearn" undesirable information
without retraining. However, any modification can alter the behaviour of LLMs,
especially on key dimensions such as fairness. This is the first work that
examines this interplay between unlearning and fairness for LLMs. In
particular, we focus on a popular unlearning framework known as SISA [Bourtoule
et al., 2021], which creates an ensemble of models trained on disjoint shards.
We evaluate the performance-fairness trade-off for SISA, and empirically
demsontrate that SISA can indeed reduce fairness in LLMs. To remedy this, we
propose post-processing bias mitigation techniques for ensemble models produced
by SISA. We adapt the post-processing fairness improvement technique from
[Hardt et al., 2016] to design three methods that can handle model ensembles,
and prove that one of the methods is an optimal fair predictor for ensemble of
models. Through experimental results, we demonstrate the efficacy of our
post-processing framework called 'FairSISA'.

---------------

### 02 Nov 2023 | [Making Harmful Behaviors Unlearnable for Large Language Models](https://arxiv.org/abs/2311.02105) | [⬇️](https://arxiv.org/pdf/2311.02105)
*Xin Zhou, Yi Lu, Ruotian Ma, Tao Gui, Qi Zhang, Xuanjing Huang* 

  Large language models (LLMs) have shown great potential as general-purpose AI
assistants in various domains. To meet the requirements of different
applications, LLMs are often customized by further fine-tuning. However, the
powerful learning ability of LLMs not only enables them to acquire new tasks
but also makes them susceptible to learning undesired behaviors. For example,
even safety-aligned LLMs can be easily fine-tuned into harmful assistants as
the fine-tuning data often contains implicit or explicit harmful content. Can
we train LLMs on harmful data without learning harmful behaviors? This paper
proposes a controllable training framework that makes harmful behaviors
unlearnable during the fine-tuning process. Specifically, we introduce
``security vectors'', a few new parameters that can be separated from the LLM,
to ensure LLM's responses are consistent with the harmful behavior. Security
vectors are activated during fine-tuning, the consistent behavior makes LLM
believe that such behavior has already been learned, there is no need to
further optimize for harmful data. During inference, we can deactivate security
vectors to restore the LLM's normal behavior. The experimental results show
that the security vectors generated by 100 harmful samples are enough to
prevent LLM from learning 1000 harmful samples, while preserving the ability to
learn other useful information.

---------------

### 07 Aug 2023 | [AI Text-to-Behavior: A Study In Steerability](https://arxiv.org/abs/2308.07326) | [⬇️](https://arxiv.org/pdf/2308.07326)
*David Noever and Sam Hyams* 

  The research explores the steerability of Large Language Models (LLMs),
particularly OpenAI's ChatGPT iterations. By employing a behavioral psychology
framework called OCEAN (Openness, Conscientiousness, Extroversion,
Agreeableness, Neuroticism), we quantitatively gauged the model's
responsiveness to tailored prompts. When asked to generate text mimicking an
extroverted personality, OCEAN scored the language alignment to that behavioral
trait. In our analysis, while "openness" presented linguistic ambiguity,
"conscientiousness" and "neuroticism" were distinctly evoked in the OCEAN
framework, with "extroversion" and "agreeableness" showcasing a notable overlap
yet distinct separation from other traits. Our findings underscore GPT's
versatility and ability to discern and adapt to nuanced instructions.
Furthermore, historical figure simulations highlighted the LLM's capacity to
internalize and project instructible personas, precisely replicating their
philosophies and dialogic styles. However, the rapid advancements in LLM
capabilities and the opaque nature of some training techniques make metric
proposals degrade rapidly. Our research emphasizes a quantitative role to
describe steerability in LLMs, presenting both its promise and areas for
further refinement in aligning its progress to human intentions.

---------------

### 17 Oct 2023 | [Artificial Neuropsychology: Are Large Language Models Developing  Executive Functions?](https://arxiv.org/abs/2305.04134) | [⬇️](https://arxiv.org/pdf/2305.04134)
*Hernan Ceferino Vazquez* 

  Artificial Intelligence (AI) has been rapidly advancing and has demonstrated
its ability to perform a wide range of cognitive tasks, including language
processing, visual recognition, and decision-making. Part of this progress is
due to LLMs (Large Language Models) like those of the GPT (Generative
Pre-Trained Transformers) family. These models are capable of exhibiting
behavior that can be perceived as intelligent. Most authors in Neuropsychology
consider intelligent behavior to depend on a number of overarching skills, or
Executive Functions (EFs), which rely on the correct functioning of neural
networks in the frontal lobes, and have developed a series of tests to evaluate
them. In this work, we raise the question of whether LLMs are developing
executive functions similar to those of humans as part of their learning, and
we evaluate the planning function and working memory of GPT using the popular
Towers of Hanoi method. Additionally, we introduce a new variant of the
classical method in order to avoid that the solutions are found in the LLM
training data (dataleakeage). Preliminary results show that LLMs generates
near-optimal solutions in Towers of Hanoi related tasks, adheres to task
constraints, and exhibits rapid planning capabilities and efficient working
memory usage, indicating a potential development of executive functions.
However, these abilities are quite limited and worse than well-trained humans
when the tasks are not known and are not part of the training data.

---------------

### 19 Feb 2024 | [Beyond Reference-Based Metrics: Analyzing Behaviors of Open LLMs on  Data-to-Text Generation](https://arxiv.org/abs/2401.10186) | [⬇️](https://arxiv.org/pdf/2401.10186)
*Zden\v{e}k Kasner, Ond\v{r}ej Du\v{s}ek* 

  We analyze the behaviors of open large language models (LLMs) on the task of
data-to-text (D2T) generation, i.e., generating coherent and relevant text from
structured data. To avoid the issue of LLM training data contamination with
standard benchmarks, we design Quintd - a tool for collecting novel structured
data records from public APIs. Using a dataset collected with Quintd and
leveraging reference-free evaluation, we analyze model behaviors on five D2T
generation tasks. We find that recent open LLMs (Llama2, Mistral, and Zephyr)
can generate fluent and coherent text from standard data formats in zero-shot
settings. However, we also show that the semantic accuracy of the outputs is a
major issue: both according to our GPT-4-based metric and human annotators,
more than 80% of the outputs of open LLMs contain a semantic error. We publicly
release the code, data, and model outputs.

---------------

### 25 Dec 2023 | [DriveMLM: Aligning Multi-Modal Large Language Models with Behavioral  Planning States for Autonomous Driving](https://arxiv.org/abs/2312.09245) | [⬇️](https://arxiv.org/pdf/2312.09245)
*Wenhai Wang, Jiangwei Xie, ChuanYang Hu, Haoming Zou, Jianan Fan,  Wenwen Tong, Yang Wen, Silei Wu, Hanming Deng, Zhiqi Li, Hao Tian, Lewei Lu,  Xizhou Zhu, Xiaogang Wang, Yu Qiao, Jifeng Dai* 

  Large language models (LLMs) have opened up new possibilities for intelligent
agents, endowing them with human-like thinking and cognitive abilities. In this
work, we delve into the potential of large language models (LLMs) in autonomous
driving (AD). We introduce DriveMLM, an LLM-based AD framework that can perform
close-loop autonomous driving in realistic simulators. To this end, (1) we
bridge the gap between the language decisions and the vehicle control commands
by standardizing the decision states according to the off-the-shelf motion
planning module. (2) We employ a multi-modal LLM (MLLM) to model the behavior
planning module of a module AD system, which uses driving rules, user commands,
and inputs from various sensors (e.g., camera, lidar) as input and makes
driving decisions and provide explanations; This model can plug-and-play in
existing AD systems such as Apollo for close-loop driving. (3) We design an
effective data engine to collect a dataset that includes decision state and
corresponding explanation annotation for model training and evaluation. We
conduct extensive experiments and show that our model achieves 76.1 driving
score on the CARLA Town05 Long, and surpasses the Apollo baseline by 4.7 points
under the same settings, demonstrating the effectiveness of our model. We hope
this work can serve as a baseline for autonomous driving with LLMs. Code and
models shall be released at https://github.com/OpenGVLab/DriveMLM.

---------------

### 28 Oct 2023 | [On the Exploitability of Instruction Tuning](https://arxiv.org/abs/2306.17194) | [⬇️](https://arxiv.org/pdf/2306.17194)
*Manli Shu, Jiongxiao Wang, Chen Zhu, Jonas Geiping, Chaowei Xiao, Tom  Goldstein* 

  Instruction tuning is an effective technique to align large language models
(LLMs) with human intents. In this work, we investigate how an adversary can
exploit instruction tuning by injecting specific instruction-following examples
into the training data that intentionally changes the model's behavior. For
example, an adversary can achieve content injection by injecting training
examples that mention target content and eliciting such behavior from
downstream models. To achieve this goal, we propose \textit{AutoPoison}, an
automated data poisoning pipeline. It naturally and coherently incorporates
versatile attack goals into poisoned data with the help of an oracle LLM. We
showcase two example attacks: content injection and over-refusal attacks, each
aiming to induce a specific exploitable behavior. We quantify and benchmark the
strength and the stealthiness of our data poisoning scheme. Our results show
that AutoPoison allows an adversary to change a model's behavior by poisoning
only a small fraction of data while maintaining a high level of stealthiness in
the poisoned examples. We hope our work sheds light on how data quality affects
the behavior of instruction-tuned models and raises awareness of the importance
of data quality for responsible deployments of LLMs. Code is available at
\url{https://github.com/azshue/AutoPoison}.

---------------

### 22 Oct 2023 | [Sources of Hallucination by Large Language Models on Inference Tasks](https://arxiv.org/abs/2305.14552) | [⬇️](https://arxiv.org/pdf/2305.14552)
*Nick McKenna, Tianyi Li, Liang Cheng, Mohammad Javad Hosseini, Mark  Johnson, Mark Steedman* 

  Large Language Models (LLMs) are claimed to be capable of Natural Language
Inference (NLI), necessary for applied tasks like question answering and
summarization. We present a series of behavioral studies on several LLM
families (LLaMA, GPT-3.5, and PaLM) which probe their behavior using controlled
experiments. We establish two biases originating from pretraining which predict
much of their behavior, and show that these are major sources of hallucination
in generative LLMs. First, memorization at the level of sentences: we show
that, regardless of the premise, models falsely label NLI test samples as
entailing when the hypothesis is attested in training data, and that entities
are used as ``indices'' to access the memorized data. Second, statistical
patterns of usage learned at the level of corpora: we further show a similar
effect when the premise predicate is less frequent than that of the hypothesis
in the training data, a bias following from previous studies. We demonstrate
that LLMs perform significantly worse on NLI test samples which do not conform
to these biases than those which do, and we offer these as valuable controls
for future LLM evaluation.

---------------

### 13 Oct 2023 | [Driving with LLMs: Fusing Object-Level Vector Modality for Explainable  Autonomous Driving](https://arxiv.org/abs/2310.01957) | [⬇️](https://arxiv.org/pdf/2310.01957)
*Long Chen, Oleg Sinavski, Jan H\"unermann, Alice Karnsund, Andrew  James Willmott, Danny Birch, Daniel Maund, Jamie Shotton* 

  Large Language Models (LLMs) have shown promise in the autonomous driving
sector, particularly in generalization and interpretability. We introduce a
unique object-level multimodal LLM architecture that merges vectorized numeric
modalities with a pre-trained LLM to improve context understanding in driving
situations. We also present a new dataset of 160k QA pairs derived from 10k
driving scenarios, paired with high quality control commands collected with RL
agent and question answer pairs generated by teacher LLM (GPT-3.5). A distinct
pretraining strategy is devised to align numeric vector modalities with static
LLM representations using vector captioning language data. We also introduce an
evaluation metric for Driving QA and demonstrate our LLM-driver's proficiency
in interpreting driving scenarios, answering questions, and decision-making.
Our findings highlight the potential of LLM-based driving action generation in
comparison to traditional behavioral cloning. We make our benchmark, datasets,
and model available for further exploration.

---------------
**Date:** 26 Oct 2023

**Title:** Large Content And Behavior Models To Understand, Simulate, And Optimize  Content And Behavior

**Abstract Link:** [https://arxiv.org/abs/2309.00359](https://arxiv.org/abs/2309.00359)

**PDF Link:** [https://arxiv.org/pdf/2309.00359](https://arxiv.org/pdf/2309.00359)

---

**Date:** 27 Nov 2023

**Title:** In-Context Learning Dynamics with Random Binary Sequences

**Abstract Link:** [https://arxiv.org/abs/2310.17639](https://arxiv.org/abs/2310.17639)

**PDF Link:** [https://arxiv.org/pdf/2310.17639](https://arxiv.org/pdf/2310.17639)

---

**Date:** 01 Feb 2024

**Title:** Plan-Grounded Large Language Models for Dual Goal Conversational  Settings

**Abstract Link:** [https://arxiv.org/abs/2402.01053](https://arxiv.org/abs/2402.01053)

**PDF Link:** [https://arxiv.org/pdf/2402.01053](https://arxiv.org/pdf/2402.01053)

---

**Date:** 02 Sep 2023

**Title:** BLSP: Bootstrapping Language-Speech Pre-training via Behavior Alignment  of Continuation Writing

**Abstract Link:** [https://arxiv.org/abs/2309.00916](https://arxiv.org/abs/2309.00916)

**PDF Link:** [https://arxiv.org/pdf/2309.00916](https://arxiv.org/pdf/2309.00916)

---

**Date:** 29 Feb 2024

**Title:** ReLLa: Retrieval-enhanced Large Language Models for Lifelong Sequential  Behavior Comprehension in Recommendation

**Abstract Link:** [https://arxiv.org/abs/2308.11131](https://arxiv.org/abs/2308.11131)

**PDF Link:** [https://arxiv.org/pdf/2308.11131](https://arxiv.org/pdf/2308.11131)

---

**Date:** 03 Jun 2023

**Title:** Guided scenarios with simulated expert personae: a remarkable strategy  to perform cognitive work

**Abstract Link:** [https://arxiv.org/abs/2306.03104](https://arxiv.org/abs/2306.03104)

**PDF Link:** [https://arxiv.org/pdf/2306.03104](https://arxiv.org/pdf/2306.03104)

---

**Date:** 25 May 2023

**Title:** Code as Policies: Language Model Programs for Embodied Control

**Abstract Link:** [https://arxiv.org/abs/2209.07753](https://arxiv.org/abs/2209.07753)

**PDF Link:** [https://arxiv.org/pdf/2209.07753](https://arxiv.org/pdf/2209.07753)

---

**Date:** 30 May 2023

**Title:** LLM-BRAIn: AI-driven Fast Generation of Robot Behaviour Tree based on  Large Language Model

**Abstract Link:** [https://arxiv.org/abs/2305.19352](https://arxiv.org/abs/2305.19352)

**PDF Link:** [https://arxiv.org/pdf/2305.19352](https://arxiv.org/pdf/2305.19352)

---

**Date:** 17 Feb 2024

**Title:** Training Language Model Agents without Modifying Language Models

**Abstract Link:** [https://arxiv.org/abs/2402.11359](https://arxiv.org/abs/2402.11359)

**PDF Link:** [https://arxiv.org/pdf/2402.11359](https://arxiv.org/pdf/2402.11359)

---

**Date:** 27 Feb 2024

**Title:** Can an LLM-Powered Socially Assistive Robot Effectively and Safely  Deliver Cognitive Behavioral Therapy? A Study With University Students

**Abstract Link:** [https://arxiv.org/abs/2402.17937](https://arxiv.org/abs/2402.17937)

**PDF Link:** [https://arxiv.org/pdf/2402.17937](https://arxiv.org/pdf/2402.17937)

---

**Date:** 01 Feb 2024

**Title:** LLMs learn governing principles of dynamical systems, revealing an  in-context neural scaling law

**Abstract Link:** [https://arxiv.org/abs/2402.00795](https://arxiv.org/abs/2402.00795)

**PDF Link:** [https://arxiv.org/pdf/2402.00795](https://arxiv.org/pdf/2402.00795)

---

**Date:** 12 Dec 2023

**Title:** FairSISA: Ensemble Post-Processing to Improve Fairness of Unlearning in  LLMs

**Abstract Link:** [https://arxiv.org/abs/2312.07420](https://arxiv.org/abs/2312.07420)

**PDF Link:** [https://arxiv.org/pdf/2312.07420](https://arxiv.org/pdf/2312.07420)

---

**Date:** 02 Nov 2023

**Title:** Making Harmful Behaviors Unlearnable for Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2311.02105](https://arxiv.org/abs/2311.02105)

**PDF Link:** [https://arxiv.org/pdf/2311.02105](https://arxiv.org/pdf/2311.02105)

---

**Date:** 07 Aug 2023

**Title:** AI Text-to-Behavior: A Study In Steerability

**Abstract Link:** [https://arxiv.org/abs/2308.07326](https://arxiv.org/abs/2308.07326)

**PDF Link:** [https://arxiv.org/pdf/2308.07326](https://arxiv.org/pdf/2308.07326)

---

**Date:** 17 Oct 2023

**Title:** Artificial Neuropsychology: Are Large Language Models Developing  Executive Functions?

**Abstract Link:** [https://arxiv.org/abs/2305.04134](https://arxiv.org/abs/2305.04134)

**PDF Link:** [https://arxiv.org/pdf/2305.04134](https://arxiv.org/pdf/2305.04134)

---

**Date:** 19 Feb 2024

**Title:** Beyond Reference-Based Metrics: Analyzing Behaviors of Open LLMs on  Data-to-Text Generation

**Abstract Link:** [https://arxiv.org/abs/2401.10186](https://arxiv.org/abs/2401.10186)

**PDF Link:** [https://arxiv.org/pdf/2401.10186](https://arxiv.org/pdf/2401.10186)

---

**Date:** 25 Dec 2023

**Title:** DriveMLM: Aligning Multi-Modal Large Language Models with Behavioral  Planning States for Autonomous Driving

**Abstract Link:** [https://arxiv.org/abs/2312.09245](https://arxiv.org/abs/2312.09245)

**PDF Link:** [https://arxiv.org/pdf/2312.09245](https://arxiv.org/pdf/2312.09245)

---

**Date:** 28 Oct 2023

**Title:** On the Exploitability of Instruction Tuning

**Abstract Link:** [https://arxiv.org/abs/2306.17194](https://arxiv.org/abs/2306.17194)

**PDF Link:** [https://arxiv.org/pdf/2306.17194](https://arxiv.org/pdf/2306.17194)

---

**Date:** 22 Oct 2023

**Title:** Sources of Hallucination by Large Language Models on Inference Tasks

**Abstract Link:** [https://arxiv.org/abs/2305.14552](https://arxiv.org/abs/2305.14552)

**PDF Link:** [https://arxiv.org/pdf/2305.14552](https://arxiv.org/pdf/2305.14552)

---

**Date:** 13 Oct 2023

**Title:** Driving with LLMs: Fusing Object-Level Vector Modality for Explainable  Autonomous Driving

**Abstract Link:** [https://arxiv.org/abs/2310.01957](https://arxiv.org/abs/2310.01957)

**PDF Link:** [https://arxiv.org/pdf/2310.01957](https://arxiv.org/pdf/2310.01957)

---

