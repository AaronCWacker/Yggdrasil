Neural Network Growth Analysis 🌱

### 🔎 Neural Network Growth Analysis 🌱


=================================

This repository contains the code for the paper:

> **Neural Network Growth Analysis: A Study of the Evolution of Neural Networks during Training**
>
> *Juan Manuel Carrasco-Gallego, Carlos M. Fernández-Granda, and Carlos Guestrin*
>
> *Proceedings of the 37th International Conference on Machine Learning (ICML), 2020.*

The code is written in Python and uses TensorFlow 2.0.


Installation
------------

To install the required packages, run:

```
pip install -r requirements.txt
```


Usage
-----

To run the code, you need to specify the path to the dataset and the path to the output directory.

For example, to run the code for the MNIST dataset, you can use:

```
python main.py --dataset mnist --output_dir output
```


Citation
--------

If you use this code in your research, please cite the following paper:

```
@inproceedings{carrasco2020neural,
  title={Neural Network Growth Analysis: A Study of the Evolution of Neural Networks during Training},
  author={Carrasco-Gallego, Juan Manuel and Fern{\'a}ndez-Granda, Carlos M and Guestrin, Carlos},
  booktitle={Proceedings of the 37th International Conference on Machine Learning},
  pages={10111--10121},
  year={2020}
}
```


License
-------

This code is released under the [MIT License](LICENSE).</s>
# 🩺🔍 Search Results
### 06 Jan 2024 | [When To Grow? A Fitting Risk-Aware Policy for Layer Growing in Deep  Neural Networks](https://arxiv.org/abs/2401.03104) | [⬇️](https://arxiv.org/pdf/2401.03104)
*Haihang Wu, Wei Wang, Tamasha Malepathirana, Damith Senanayake, Denny  Oetomo, Saman Halgamuge* 

  Neural growth is the process of growing a small neural network to a large
network and has been utilized to accelerate the training of deep neural
networks. One crucial aspect of neural growth is determining the optimal growth
timing. However, few studies investigate this systematically. Our study reveals
that neural growth inherently exhibits a regularization effect, whose intensity
is influenced by the chosen policy for growth timing. While this regularization
effect may mitigate the overfitting risk of the model, it may lead to a notable
accuracy drop when the model underfits. Yet, current approaches have not
addressed this issue due to their lack of consideration of the regularization
effect from neural growth. Motivated by these findings, we propose an
under/over fitting risk-aware growth timing policy, which automatically adjusts
the growth timing informed by the level of potential under/overfitting risks to
address both risks. Comprehensive experiments conducted using CIFAR-10/100 and
ImageNet datasets show that the proposed policy achieves accuracy improvements
of up to 1.3% in models prone to underfitting while achieving similar
accuracies in models suffering from overfitting compared to the existing
methods.

---------------

### 13 Jan 2023 | [Adaptive Neural Networks Using Residual Fitting](https://arxiv.org/abs/2301.05744) | [⬇️](https://arxiv.org/pdf/2301.05744)
*Noah Ford, John Winder, Josh McClellan* 

  Current methods for estimating the required neural-network size for a given
problem class have focused on methods that can be computationally intensive,
such as neural-architecture search and pruning. In contrast, methods that add
capacity to neural networks as needed may provide similar results to
architecture search and pruning, but do not require as much computation to find
an appropriate network size. Here, we present a network-growth method that
searches for explainable error in the network's residuals and grows the network
if sufficient error is detected. We demonstrate this method using examples from
classification, imitation learning, and reinforcement learning. Within these
tasks, the growing network can often achieve better performance than small
networks that do not grow, and similar performance to networks that begin much
larger.

---------------

### 12 May 2022 | [Performing Video Frame Prediction of Microbial Growth with a Recurrent  Neural Network](https://arxiv.org/abs/2205.05810) | [⬇️](https://arxiv.org/pdf/2205.05810)
*Connor Robertson, Jared L. Wilmoth, Scott Retterer, Miguel  Fuentes-Cabrera* 

  A Recurrent Neural Network (RNN) was used to perform video frame prediction
of microbial growth for a population of two mutants of Pseudomonas aeruginosa.
The RNN was trained on videos of 20 frames that were acquired using
fluorescence microscopy and microfluidics. The network predicted the last 10
frames of each video, and the accuracy's of the predictions was assessed by
comparing raw images, population curves, and the number and size of individual
colonies. Overall, we found the predictions to be accurate using this approach.
The implications this result has on designing autonomous experiments in
microbiology, and the steps that can be taken to make the predictions even more
accurate, are discussed.

---------------

### 22 Jun 2023 | [Accelerated Training via Incrementally Growing Neural Networks using  Variance Transfer and Learning Rate Adaptation](https://arxiv.org/abs/2306.12700) | [⬇️](https://arxiv.org/pdf/2306.12700)
*Xin Yuan, Pedro Savarese, Michael Maire* 

  We develop an approach to efficiently grow neural networks, within which
parameterization and optimization strategies are designed by considering their
effects on the training dynamics. Unlike existing growing methods, which follow
simple replication heuristics or utilize auxiliary gradient-based local
optimization, we craft a parameterization scheme which dynamically stabilizes
weight, activation, and gradient scaling as the architecture evolves, and
maintains the inference functionality of the network. To address the
optimization difficulty resulting from imbalanced training effort distributed
to subnetworks fading in at different growth phases, we propose a learning rate
adaption mechanism that rebalances the gradient contribution of these separate
subcomponents. Experimental results show that our method achieves comparable or
better accuracy than training large fixed-size models, while saving a
substantial portion of the original computation budget for training. We
demonstrate that these gains translate into real wall-clock training speedups.

---------------

### 17 Jul 1998 | [Development and Evolution of Neural Networks in an Artificial Chemistry](https://arxiv.org/abs/adap-org/9807003) | [⬇️](https://arxiv.org/pdf/adap-org/9807003)
*Jens C. Astor and Christoph Adami (Caltech)* 

  We present a model of decentralized growth for Artificial Neural Networks
(ANNs) inspired by the development and the physiology of real nervous systems.
In this model, each individual artificial neuron is an autonomous unit whose
behavior is determined only by the genetic information it harbors and local
concentrations of substrates modeled by a simple artificial chemistry. Gene
expression is manifested as axon and dendrite growth, cell division and
differentiation, substrate production and cell stimulation. We demonstrate the
model's power with a hand-written genome that leads to the growth of a simple
network which performs classical conditioning. To evolve more complex
structures, we implemented a platform-independent, asynchronous, distributed
Genetic Algorithm (GA) that allows users to participate in evolutionary
experiments via the World Wide Web.

---------------

### 21 Dec 2023 | [Probing Biological and Artificial Neural Networks with Task-dependent  Neural Manifolds](https://arxiv.org/abs/2312.14285) | [⬇️](https://arxiv.org/pdf/2312.14285)
*Michael Kuoch, Chi-Ning Chou, Nikhil Parthasarathy, Joel Dapello,  James J. DiCarlo, Haim Sompolinsky, SueYeon Chung* 

  Recently, growth in our understanding of the computations performed in both
biological and artificial neural networks has largely been driven by either
low-level mechanistic studies or global normative approaches. However, concrete
methodologies for bridging the gap between these levels of abstraction remain
elusive. In this work, we investigate the internal mechanisms of neural
networks through the lens of neural population geometry, aiming to provide
understanding at an intermediate level of abstraction, as a way to bridge that
gap. Utilizing manifold capacity theory (MCT) from statistical physics and
manifold alignment analysis (MAA) from high-dimensional statistics, we probe
the underlying organization of task-dependent manifolds in deep neural networks
and macaque neural recordings. Specifically, we quantitatively characterize how
different learning objectives lead to differences in the organizational
strategies of these models and demonstrate how these geometric analyses are
connected to the decodability of task-relevant information. These analyses
present a strong direction for bridging mechanistic and normative theories in
neural networks through neural population geometry, potentially opening up many
future research avenues in both machine learning and neuroscience.

---------------

### 03 Jun 2019 | [Neural networks grown and self-organized by noise](https://arxiv.org/abs/1906.01039) | [⬇️](https://arxiv.org/pdf/1906.01039)
*Guruprasad Raghavan, Matt Thomson* 

  Living neural networks emerge through a process of growth and
self-organization that begins with a single cell and results in a brain, an
organized and functional computational device. Artificial neural networks,
however, rely on human-designed, hand-programmed architectures for their
remarkable performance. Can we develop artificial computational devices that
can grow and self-organize without human intervention? In this paper, we
propose a biologically inspired developmental algorithm that can 'grow' a
functional, layered neural network from a single initial cell. The algorithm
organizes inter-layer connections to construct a convolutional pooling layer, a
key constituent of convolutional neural networks (CNN's). Our approach is
inspired by the mechanisms employed by the early visual system to wire the
retina to the lateral geniculate nucleus (LGN), days before animals open their
eyes. The key ingredients for robust self-organization are an emergent
spontaneous spatiotemporal activity wave in the first layer and a local
learning rule in the second layer that 'learns' the underlying activity pattern
in the first layer. The algorithm is adaptable to a wide-range of input-layer
geometries, robust to malfunctioning units in the first layer, and so can be
used to successfully grow and self-organize pooling architectures of different
pool-sizes and shapes. The algorithm provides a primitive procedure for
constructing layered neural networks through growth and self-organization.
Broadly, our work shows that biologically inspired developmental algorithms can
be applied to autonomously grow functional 'brains' in-silico.

---------------

### 01 Jun 2018 | [NeST: A Neural Network Synthesis Tool Based on a Grow-and-Prune Paradigm](https://arxiv.org/abs/1711.02017) | [⬇️](https://arxiv.org/pdf/1711.02017)
*Xiaoliang Dai, Hongxu Yin, Niraj K. Jha* 

  Deep neural networks (DNNs) have begun to have a pervasive impact on various
applications of machine learning. However, the problem of finding an optimal
DNN architecture for large applications is challenging. Common approaches go
for deeper and larger DNN architectures but may incur substantial redundancy.
To address these problems, we introduce a network growth algorithm that
complements network pruning to learn both weights and compact DNN architectures
during training. We propose a DNN synthesis tool (NeST) that combines both
methods to automate the generation of compact and accurate DNNs. NeST starts
with a randomly initialized sparse network called the seed architecture. It
iteratively tunes the architecture with gradient-based growth and
magnitude-based pruning of neurons and connections. Our experimental results
show that NeST yields accurate, yet very compact DNNs, with a wide range of
seed architecture selection. For the LeNet-300-100 (LeNet-5) architecture, we
reduce network parameters by 70.2x (74.3x) and floating-point operations
(FLOPs) by 79.4x (43.7x). For the AlexNet and VGG-16 architectures, we reduce
network parameters (FLOPs) by 15.7x (4.6x) and 30.2x (8.6x), respectively.
NeST's grow-and-prune paradigm delivers significant additional parameter and
FLOPs reduction relative to pruning-only methods.

---------------

### 25 Nov 2019 | [Trajectory growth lower bounds for random sparse deep ReLU networks](https://arxiv.org/abs/1911.10651) | [⬇️](https://arxiv.org/pdf/1911.10651)
*Ilan Price, Jared Tanner* 

  This paper considers the growth in the length of one-dimensional trajectories
as they are passed through deep ReLU neural networks, which, among other
things, is one measure of the expressivity of deep networks. We generalise
existing results, providing an alternative, simpler method for lower bounding
expected trajectory growth through random networks, for a more general class of
weights distributions, including sparsely connected networks. We illustrate
this approach by deriving bounds for sparse-Gaussian, sparse-uniform, and
sparse-discrete-valued random nets. We prove that trajectory growth can remain
exponential in depth with these new distributions, including their sparse
variants, with the sparsity parameter appearing in the base of the exponent.

---------------

### 27 May 2019 | [Incremental Learning Using a Grow-and-Prune Paradigm with Efficient  Neural Networks](https://arxiv.org/abs/1905.10952) | [⬇️](https://arxiv.org/pdf/1905.10952)
*Xiaoliang Dai, Hongxu Yin, Niraj K. Jha* 

  Deep neural networks (DNNs) have become a widely deployed model for numerous
machine learning applications. However, their fixed architecture, substantial
training cost, and significant model redundancy make it difficult to
efficiently update them to accommodate previously unseen data. To solve these
problems, we propose an incremental learning framework based on a
grow-and-prune neural network synthesis paradigm. When new data arrive, the
neural network first grows new connections based on the gradients to increase
the network capacity to accommodate new data. Then, the framework iteratively
prunes away connections based on the magnitude of weights to enhance network
compactness, and hence recover efficiency. Finally, the model rests at a
lightweight DNN that is both ready for inference and suitable for future
grow-and-prune updates. The proposed framework improves accuracy, shrinks
network size, and significantly reduces the additional training cost for
incoming data compared to conventional approaches, such as training from
scratch and network fine-tuning. For the LeNet-300-100 and LeNet-5 neural
network architectures derived for the MNIST dataset, the framework reduces
training cost by up to 64% (63%) and 67% (63%) compared to training from
scratch (network fine-tuning), respectively. For the ResNet-18 architecture
derived for the ImageNet dataset and DeepSpeech2 for the AN4 dataset, the
corresponding training cost reductions against training from scratch (network
fine-tunning) are 64% (60%) and 67% (62%), respectively. Our derived models
contain fewer network parameters but achieve higher accuracy relative to
conventional baselines.

---------------

### 27 Jan 2021 | [Nonclosedness of Sets of Neural Networks in Sobolev Spaces](https://arxiv.org/abs/2007.11730) | [⬇️](https://arxiv.org/pdf/2007.11730)
*Scott Mahan, Emily King, Alex Cloninger* 

  We examine the closedness of sets of realized neural networks of a fixed
architecture in Sobolev spaces. For an exactly $m$-times differentiable
activation function $\rho$, we construct a sequence of neural networks
$(\Phi_n)_{n \in \mathbb{N}}$ whose realizations converge in order-$(m-1)$
Sobolev norm to a function that cannot be realized exactly by a neural network.
Thus, sets of realized neural networks are not closed in order-$(m-1)$ Sobolev
spaces $W^{m-1,p}$ for $p \in [1,\infty]$. We further show that these sets are
not closed in $W^{m,p}$ under slightly stronger conditions on the $m$-th
derivative of $\rho$. For a real analytic activation function, we show that
sets of realized neural networks are not closed in $W^{k,p}$ for any $k \in
\mathbb{N}$. The nonclosedness allows for approximation of non-network target
functions with unbounded parameter growth. We partially characterize the rate
of parameter growth for most activation functions by showing that a specific
sequence of realized neural networks can approximate the activation function's
derivative with weights increasing inversely proportional to the $L^p$
approximation error. Finally, we present experimental results showing that
networks are capable of closely approximating non-network target functions with
increasing parameters via training.

---------------

### 01 Feb 2024 | [Towards an Algebraic Framework For Approximating Functions Using Neural  Network Polynomials](https://arxiv.org/abs/2402.01058) | [⬇️](https://arxiv.org/pdf/2402.01058)
*Shakil Rafi, Joshua Lee Padgett, and Ukash Nakarmi* 

  We make the case for neural network objects and extend an already existing
neural network calculus explained in detail in Chapter 2 on \cite{bigbook}. Our
aim will be to show that, yes, indeed, it makes sense to talk about neural
network polynomials, neural network exponentials, sine, and cosines in the
sense that they do indeed approximate their real number counterparts subject to
limitations on certain of their parameters, $q$, and $\varepsilon$. While doing
this, we show that the parameter and depth growth are only polynomial on their
desired accuracy (defined as a 1-norm difference over $\mathbb{R}$), thereby
showing that this approach to approximating, where a neural network in some
sense has the structural properties of the function it is approximating is not
entire intractable.

---------------

### 03 Mar 2017 | [Exponential Moving Average Model in Parallel Speech Recognition Training](https://arxiv.org/abs/1703.01024) | [⬇️](https://arxiv.org/pdf/1703.01024)
*Xu Tian, Jun Zhang, Zejun Ma, Yi He, Juan Wei* 

  As training data rapid growth, large-scale parallel training with multi-GPUs
cluster is widely applied in the neural network model learning currently.We
present a new approach that applies exponential moving average method in
large-scale parallel training of neural network model. It is a non-interference
strategy that the exponential moving average model is not broadcasted to
distributed workers to update their local models after model synchronization in
the training process, and it is implemented as the final model of the training
system. Fully-connected feed-forward neural networks (DNNs) and deep
unidirectional Long short-term memory (LSTM) recurrent neural networks (RNNs)
are successfully trained with proposed method for large vocabulary continuous
speech recognition on Shenma voice search data in Mandarin. The character error
rate (CER) of Mandarin speech recognition further degrades than
state-of-the-art approaches of parallel training.

---------------

### 16 Oct 2021 | [BAPGAN: GAN-based Bone Age Progression of Femur and Phalange X-ray  Images](https://arxiv.org/abs/2110.08509) | [⬇️](https://arxiv.org/pdf/2110.08509)
*Shinji Nakazawa, Changhee Han, Joe Hasei, Ryuichi Nakahara, Toshifumi  Ozaki* 

  Convolutional Neural Networks play a key role in bone age assessment for
investigating endocrinology, genetic, and growth disorders under various
modalities and body regions. However, no researcher has tackled bone age
progression/regression despite its valuable potential applications:
bone-related disease diagnosis, clinical knowledge acquisition, and museum
education. Therefore, we propose Bone Age Progression Generative Adversarial
Network (BAPGAN) to progress/regress both femur/phalange X-ray images while
preserving identity and realism. We exhaustively confirm the BAPGAN's clinical
potential via Frechet Inception Distance, Visual Turing Test by two expert
orthopedists, and t-Distributed Stochastic Neighbor Embedding.

---------------

### 05 Mar 2024 | [G-EvoNAS: Evolutionary Neural Architecture Search Based on Network  Growth](https://arxiv.org/abs/2403.02667) | [⬇️](https://arxiv.org/pdf/2403.02667)
*Juan Zou, Weiwei Jiang, Yizhang Xia, Yuan Liu, Zhanglu Hou* 

  The evolutionary paradigm has been successfully applied to neural network
search(NAS) in recent years. Due to the vast search complexity of the global
space, current research mainly seeks to repeatedly stack partial architectures
to build the entire model or to seek the entire model based on manually
designed benchmark modules. The above two methods are attempts to reduce the
search difficulty by narrowing the search space. To efficiently search network
architecture in the global space, this paper proposes another solution, namely
a computationally efficient neural architecture evolutionary search framework
based on network growth (G-EvoNAS). The complete network is obtained by
gradually deepening different Blocks. The process begins from a shallow
network, grows and evolves, and gradually deepens into a complete network,
reducing the search complexity in the global space. Then, to improve the
ranking accuracy of the network, we reduce the weight coupling of each network
in the SuperNet by pruning the SuperNet according to elite groups at different
growth stages. The G-EvoNAS is tested on three commonly used image
classification datasets, CIFAR10, CIFAR100, and ImageNet, and compared with
various state-of-the-art algorithms, including hand-designed networks and NAS
networks. Experimental results demonstrate that G-EvoNAS can find a neural
network architecture comparable to state-of-the-art designs in 0.2 GPU days.

---------------

### 17 Jul 2023 | [Towards Self-Assembling Artificial Neural Networks through Neural  Developmental Programs](https://arxiv.org/abs/2307.08197) | [⬇️](https://arxiv.org/pdf/2307.08197)
*Elias Najarro, Shyam Sudhakaran, Sebastian Risi* 

  Biological nervous systems are created in a fundamentally different way than
current artificial neural networks. Despite its impressive results in a variety
of different domains, deep learning often requires considerable engineering
effort to design high-performing neural architectures. By contrast, biological
nervous systems are grown through a dynamic self-organizing process. In this
paper, we take initial steps toward neural networks that grow through a
developmental process that mirrors key properties of embryonic development in
biological organisms. The growth process is guided by another neural network,
which we call a Neural Developmental Program (NDP) and which operates through
local communication alone. We investigate the role of neural growth on
different machine learning benchmarks and different optimization methods
(evolutionary training, online RL, offline RL, and supervised learning).
Additionally, we highlight future research directions and opportunities enabled
by having self-organization driving the growth of neural networks.

---------------

### 07 Mar 2023 | [Effects of Parameter Norm Growth During Transformer Training: Inductive  Bias from Gradient Descent](https://arxiv.org/abs/2010.09697) | [⬇️](https://arxiv.org/pdf/2010.09697)
*William Merrill and Vivek Ramanujan and Yoav Goldberg and Roy Schwartz  and Noah Smith* 

  The capacity of neural networks like the widely adopted transformer is known
to be very high. Evidence is emerging that they learn successfully due to
inductive bias in the training routine, typically a variant of gradient descent
(GD). To better understand this bias, we study the tendency for transformer
parameters to grow in magnitude ($\ell_2$ norm) during training, and its
implications for the emergent representations within self attention layers.
Empirically, we document norm growth in the training of transformer language
models, including T5 during its pretraining. As the parameters grow in
magnitude, we prove that the network approximates a discretized network with
saturated activation functions. Such "saturated" networks are known to have a
reduced capacity compared to the full network family that can be described in
terms of formal languages and automata. Our results suggest saturation is a new
characterization of an inductive bias implicit in GD of particular interest for
NLP. We leverage the emergent discrete structure in a saturated transformer to
analyze the role of different attention heads, finding that some focus locally
on a small number of positions, while other heads compute global averages,
allowing counting. We believe understanding the interplay between these two
capabilities may shed further light on the structure of computation within
large transformers.

---------------

### 07 Jun 2022 | [GradMax: Growing Neural Networks using Gradient Information](https://arxiv.org/abs/2201.05125) | [⬇️](https://arxiv.org/pdf/2201.05125)
*Utku Evci, Bart van Merri\"enboer, Thomas Unterthiner, Max Vladymyrov,  Fabian Pedregosa* 

  The architecture and the parameters of neural networks are often optimized
independently, which requires costly retraining of the parameters whenever the
architecture is modified. In this work we instead focus on growing the
architecture without requiring costly retraining. We present a method that adds
new neurons during training without impacting what is already learned, while
improving the training dynamics. We achieve the latter by maximizing the
gradients of the new weights and find the optimal initialization efficiently by
means of the singular value decomposition (SVD). We call this technique
Gradient Maximizing Growth (GradMax) and demonstrate its effectiveness in
variety of vision tasks and architectures.

---------------

### 28 Aug 2023 | [Kernel Limit of Recurrent Neural Networks Trained on Ergodic Data  Sequences](https://arxiv.org/abs/2308.14555) | [⬇️](https://arxiv.org/pdf/2308.14555)
*Samuel Chun-Hei Lam, Justin Sirignano, and Konstantinos Spiliopoulos* 

  Mathematical methods are developed to characterize the asymptotics of
recurrent neural networks (RNN) as the number of hidden units, data samples in
the sequence, hidden state updates, and training steps simultaneously grow to
infinity. In the case of an RNN with a simplified weight matrix, we prove the
convergence of the RNN to the solution of an infinite-dimensional ODE coupled
with the fixed point of a random algebraic equation. The analysis requires
addressing several challenges which are unique to RNNs. In typical mean-field
applications (e.g., feedforward neural networks), discrete updates are of
magnitude $\mathcal{O}(\frac{1}{N})$ and the number of updates is
$\mathcal{O}(N)$. Therefore, the system can be represented as an Euler
approximation of an appropriate ODE/PDE, which it will converge to as $N
\rightarrow \infty$. However, the RNN hidden layer updates are
$\mathcal{O}(1)$. Therefore, RNNs cannot be represented as a discretization of
an ODE/PDE and standard mean-field techniques cannot be applied. Instead, we
develop a fixed point analysis for the evolution of the RNN memory states, with
convergence estimates in terms of the number of update steps and the number of
hidden units. The RNN hidden layer is studied as a function in a Sobolev space,
whose evolution is governed by the data sequence (a Markov chain), the
parameter updates, and its dependence on the RNN hidden layer at the previous
time step. Due to the strong correlation between updates, a Poisson equation
must be used to bound the fluctuations of the RNN around its limit equation.
These mathematical methods give rise to the neural tangent kernel (NTK) limits
for RNNs trained on data sequences as the number of data samples and size of
the neural network grow to infinity.

---------------

### 12 Sep 2020 | [Deep Modeling of Growth Trajectories for Longitudinal Prediction of  Missing Infant Cortical Surfaces](https://arxiv.org/abs/2009.02797) | [⬇️](https://arxiv.org/pdf/2009.02797)
*Peirong Liu, Zhengwang Wu, Gang Li, Pew-Thian Yap and Dinggang Shen* 

  Charting cortical growth trajectories is of paramount importance for
understanding brain development. However, such analysis necessitates the
collection of longitudinal data, which can be challenging due to subject
dropouts and failed scans. In this paper, we will introduce a method for
longitudinal prediction of cortical surfaces using a spatial graph
convolutional neural network (GCNN), which extends conventional CNNs from
Euclidean to curved manifolds. The proposed method is designed to model the
cortical growth trajectories and jointly predict inner and outer cortical
surfaces at multiple time points. Adopting a binary flag in loss calculation to
deal with missing data, we fully utilize all available cortical surfaces for
training our deep learning model, without requiring a complete collection of
longitudinal data. Predicting the surfaces directly allows cortical attributes
such as cortical thickness, curvature, and convexity to be computed for
subsequent analysis. We will demonstrate with experimental results that our
method is capable of capturing the nonlinearity of spatiotemporal cortical
growth patterns and can predict cortical surfaces with improved accuracy.

---------------
