Multi-modal LLM Systems 🌈

### 🔎 Multi-modal LLM Systems 🌈


===========================

This repository contains the code for the paper:

> **Multi-modal LLM Systems: A Survey**
>
> *Julien Bringer, Julien Velcin, and Julien Romero*
>
> *ACM Computing Surveys, 2023*

The paper is available [here](https://dl.acm.org/doi/10.1145/3580341).

The code is available [here](https://github.com/julienbringer/multimodal-llm-systems).

The data is available [here](https://github.com/julienbringer/multimodal-llm-systems-data).

















































































































































































































































































































































# 🩺🔍 Search Results
### 13 Nov 2023 | [Finding and Editing Multi-Modal Neurons in Pre-Trained Transformer](https://arxiv.org/abs/2311.07470) | [⬇️](https://arxiv.org/pdf/2311.07470)
*Haowen Pan, Yixin Cao, Xiaozhi Wang, Xun Yang* 

  Multi-modal large language models (LLM) have achieved powerful capabilities
for visual semantic understanding in recent years. However, little is known
about how LLMs comprehend visual information and interpret different modalities
of features. In this paper, we propose a new method for identifying multi-modal
neurons in transformer-based multi-modal LLMs. Through a series of experiments,
We highlight three critical properties of multi-modal neurons by four
well-designed quantitative evaluation metrics. Furthermore, we introduce a
knowledge editing method based on the identified multi-modal neurons, for
modifying a specific token to another designative token. We hope our findings
can inspire further explanatory researches on understanding mechanisms of
multi-modal LLMs.

---------------

### 15 Oct 2023 | [Beyond Segmentation: Road Network Generation with Multi-Modal LLMs](https://arxiv.org/abs/2310.09755) | [⬇️](https://arxiv.org/pdf/2310.09755)
*Sumedh Rasal and Sanjay Kumar Boddhu* 

  This paper introduces an innovative approach to road network generation
through the utilization of a multi-modal Large Language Model (LLM). Our model
is specifically designed to process aerial images of road layouts and produce
detailed, navigable road networks within the input images. The core innovation
of our system lies in the unique training methodology employed for the large
language model to generate road networks as its output. This approach draws
inspiration from the BLIP-2 architecture arXiv:2301.12597, leveraging
pre-trained frozen image encoders and large language models to create a
versatile multi-modal LLM.
  Our work also offers an alternative to the reasoning segmentation method
proposed in the LISA paper arXiv:2308.00692. By training the large language
model with our approach, the necessity for generating binary segmentation
masks, as suggested in the LISA paper arXiv:2308.00692, is effectively
eliminated. Experimental results underscore the efficacy of our multi-modal LLM
in providing precise and valuable navigational guidance. This research
represents a significant stride in bolstering autonomous navigation systems,
especially in road network scenarios, where accurate guidance is of paramount
importance.

---------------

### 31 Aug 2023 | [Enhancing Subtask Performance of Multi-modal Large Language Model](https://arxiv.org/abs/2308.16474) | [⬇️](https://arxiv.org/pdf/2308.16474)
*Yongqiang Zhao, Zhenyu Li, Feng Zhang, Xinhai Xu, Donghong Liu* 

  Multi-modal Large Language Model (MLLM) refers to a model expanded from a
Large Language Model (LLM) that possesses the capability to handle and infer
multi-modal data. Current MLLMs typically begin by using LLMs to decompose
tasks into multiple subtasks, then employing individual pre-trained models to
complete specific subtasks, and ultimately utilizing LLMs to integrate the
results of each subtasks to obtain the results of the task. In real-world
scenarios, when dealing with large projects, it is common practice to break
down the project into smaller sub-projects, with different teams providing
corresponding solutions or results. The project owner then decides which
solution or result to use, ensuring the best possible outcome for each subtask
and, consequently, for the entire project. Inspired by this, this study
considers selecting multiple pre-trained models to complete the same subtask.
By combining the results from multiple pre-trained models, the optimal subtask
result is obtained, enhancing the performance of the MLLM. Specifically, this
study first selects multiple pre-trained models focused on the same subtask
based on distinct evaluation approaches, and then invokes these models in
parallel to process input data and generate corresponding subtask results.
Finally, the results from multiple pre-trained models for the same subtask are
compared using the LLM, and the best result is chosen as the outcome for that
subtask. Extensive experiments are conducted in this study using GPT-4
annotated datasets and human-annotated datasets. The results of various
evaluation metrics adequately demonstrate the effectiveness of the proposed
approach in this paper.

---------------

### 14 Nov 2023 | [Unlock the Power: Competitive Distillation for Multi-Modal Large  Language Models](https://arxiv.org/abs/2311.08213) | [⬇️](https://arxiv.org/pdf/2311.08213)
*Xinwei Li, Li Lin, Shuai Wang, Chen Qian* 

  Recently, multi-modal content generation has attracted lots of attention from
researchers by investigating the utilization of visual instruction tuning based
on large language models (LLMs). To enhance the performance and generalization
ability of such LLMs, the practice of distilling knowledge from pretrained
multi-modal models (a.k.a. teachers) to more compact multi-modal LLMs
(students) has gained considerable interest. However, the prevailing paradigm
of instructiontuning in multi-modal LLMs knowledge distillation is
resource-intensive and unidirectional, neglecting the potential for mutual
feedback between the student and teacher models. Thus, we propose an innovative
Competitive Multi-modal Distillation framework (CoMD), which captures
bidirectional feedback between teacher and student models and continually
updates the multi-modal capabilities that the student model has learned. It
comprises two stages: multi-modal pre-training and multi-modal competitive
distillation. The first stage pre-trains the student model on a large number of
filtered multi-modal datasets. The second stage facilitates a bidirectional
knowledge transfer between the student and teacher models. Our experimental
analysis of diverse datasets shows that our knowledge transfer method
consistently improves the capabilities of the student model. Finally, the
7B-sized student model after four distillations surpassed the current
state-of-the-art model LLaVA-13B on the ScienceQA and LLaVA Test dataset, also
outperforms other strong baselines in the zero-shot setting.

---------------

### 15 Jan 2024 | [InternVL: Scaling up Vision Foundation Models and Aligning for Generic  Visual-Linguistic Tasks](https://arxiv.org/abs/2312.14238) | [⬇️](https://arxiv.org/pdf/2312.14238)
*Zhe Chen, Jiannan Wu, Wenhai Wang, Weijie Su, Guo Chen, Sen Xing,  Muyan Zhong, Qinglong Zhang, Xizhou Zhu, Lewei Lu, Bin Li, Ping Luo, Tong Lu,  Yu Qiao, Jifeng Dai* 

  The exponential growth of large language models (LLMs) has opened up numerous
possibilities for multimodal AGI systems. However, the progress in vision and
vision-language foundation models, which are also critical elements of
multi-modal AGI, has not kept pace with LLMs. In this work, we design a
large-scale vision-language foundation model (InternVL), which scales up the
vision foundation model to 6 billion parameters and progressively aligns it
with the LLM, using web-scale image-text data from various sources. This model
can be broadly applied to and achieve state-of-the-art performance on 32
generic visual-linguistic benchmarks including visual perception tasks such as
image-level or pixel-level recognition, vision-language tasks such as zero-shot
image/video classification, zero-shot image/video-text retrieval, and link with
LLMs to create multi-modal dialogue systems. It has powerful visual
capabilities and can be a good alternative to the ViT-22B. We hope that our
research could contribute to the development of multi-modal large models. Code
and models are available at https://github.com/OpenGVLab/InternVL.

---------------

### 25 Apr 2023 | [AudioGPT: Understanding and Generating Speech, Music, Sound, and Talking  Head](https://arxiv.org/abs/2304.12995) | [⬇️](https://arxiv.org/pdf/2304.12995)
*Rongjie Huang, Mingze Li, Dongchao Yang, Jiatong Shi, Xuankai Chang,  Zhenhui Ye, Yuning Wu, Zhiqing Hong, Jiawei Huang, Jinglin Liu, Yi Ren, Zhou  Zhao, Shinji Watanabe* 

  Large language models (LLMs) have exhibited remarkable capabilities across a
variety of domains and tasks, challenging our understanding of learning and
cognition. Despite the recent success, current LLMs are not capable of
processing complex audio information or conducting spoken conversations (like
Siri or Alexa). In this work, we propose a multi-modal AI system named
AudioGPT, which complements LLMs (i.e., ChatGPT) with 1) foundation models to
process complex audio information and solve numerous understanding and
generation tasks; and 2) the input/output interface (ASR, TTS) to support
spoken dialogue. With an increasing demand to evaluate multi-modal LLMs of
human intention understanding and cooperation with foundation models, we
outline the principles and processes and test AudioGPT in terms of consistency,
capability, and robustness. Experimental results demonstrate the capabilities
of AudioGPT in solving AI tasks with speech, music, sound, and talking head
understanding and generation in multi-round dialogues, which empower humans to
create rich and diverse audio content with unprecedented ease. Our system is
publicly available at \url{https://github.com/AIGC-Audio/AudioGPT}.

---------------

### 01 Nov 2023 | [Enhancing the Spatial Awareness Capability of Multi-Modal Large Language  Model](https://arxiv.org/abs/2310.20357) | [⬇️](https://arxiv.org/pdf/2310.20357)
*Yongqiang Zhao, Zhenyu Li, Zhi Jin, Feng Zhang, Haiyan Zhao, Chengfeng  Dou, Zhengwei Tao, Xinhai Xu, Donghong Liu* 

  The Multi-Modal Large Language Model (MLLM) refers to an extension of the
Large Language Model (LLM) equipped with the capability to receive and infer
multi-modal data. Spatial awareness stands as one of the crucial abilities of
MLLM, encompassing diverse skills related to understanding spatial
relationships among objects and between objects and the scene area. Industries
such as autonomous driving, smart healthcare, robotics, virtual, and augmented
reality heavily demand MLLM's spatial awareness capabilities. However, there
exists a noticeable gap between the current spatial awareness capabilities of
MLLM and the requirements set by human needs. To address this issue, this paper
proposes using more precise spatial position information between objects to
guide MLLM in providing more accurate responses to user-related inquiries.
Specifically, for a particular multi-modal task, we utilize algorithms for
acquiring geometric spatial information and scene graphs to obtain relevant
geometric spatial information and scene details of objects involved in the
query. Subsequently, based on this information, we direct MLLM to address
spatial awareness-related queries posed by the user. Extensive experiments were
conducted in benchmarks such as MME, MM-Vet, and other multi-modal large
language models. The experimental results thoroughly confirm the efficacy of
the proposed method in enhancing the spatial awareness tasks and associated
tasks of MLLM.

---------------

### 07 Dec 2023 | [AVA: Towards Autonomous Visualization Agents through Visual  Perception-Driven Decision-Making](https://arxiv.org/abs/2312.04494) | [⬇️](https://arxiv.org/pdf/2312.04494)
*Shusen Liu, Haichao Miao, Zhimin Li, Matthew Olson, Valerio Pascucci,  Peer-Timo Bremer* 

  With recent advances in multi-modal foundation models, the previously
text-only large language models (LLM) have evolved to incorporate visual input,
opening up unprecedented opportunities for various applications in
visualization. Our work explores the utilization of the visual perception
ability of multi-modal LLMs to develop Autonomous Visualization Agents (AVAs)
that can interpret and accomplish user-defined visualization objectives through
natural language. We propose the first framework for the design of AVAs and
present several usage scenarios intended to demonstrate the general
applicability of the proposed paradigm. The addition of visual perception
allows AVAs to act as the virtual visualization assistant for domain experts
who may lack the knowledge or expertise in fine-tuning visualization outputs.
Our preliminary exploration and proof-of-concept agents suggest that this
approach can be widely applicable whenever the choices of appropriate
visualization parameters require the interpretation of previous visual output.
Feedback from unstructured interviews with experts in AI research, medical
visualization, and radiology has been incorporated, highlighting the
practicality and potential of AVAs. Our study indicates that AVAs represent a
general paradigm for designing intelligent visualization systems that can
achieve high-level visualization goals, which pave the way for developing
expert-level visualization agents in the future.

---------------

### 04 Jan 2024 | [TEAL: Tokenize and Embed ALL for Multi-modal Large Language Models](https://arxiv.org/abs/2311.04589) | [⬇️](https://arxiv.org/pdf/2311.04589)
*Zhen Yang, Yingxue Zhang, Fandong Meng and Jie Zhou* 

  Despite Multi-modal Large Language Models (MM-LLMs) have made exciting
strides recently, they are still struggling to efficiently model the
interactions among multi-modal inputs and the generation in non-textual
modalities. In this work, we propose TEAL (Tokenize and Embed ALl)}, an
approach to treat the input from any modality as a token sequence and learn a
joint embedding space for all modalities. Specifically, for the input from any
modality, TEAL first discretizes it into a token sequence with the
off-the-shelf tokenizer and embeds the token sequence into a joint embedding
space with a learnable embedding matrix. MM-LLMs just need to predict the
multi-modal tokens autoregressively as the textual LLMs do. Finally, the
corresponding de-tokenizer is applied to generate the output in each modality
based on the predicted token sequence. With the joint embedding space, TEAL
enables the frozen LLMs to perform both understanding and generation tasks
involving non-textual modalities, such as image and audio. Thus, the textual
LLM can just work as an interface and maintain its high performance in textual
understanding and generation. Experiments show that TEAL achieves substantial
improvements in multi-modal understanding, and implements a simple scheme for
multi-modal generations.

---------------

### 12 Dec 2023 | [MMICT: Boosting Multi-Modal Fine-Tuning with In-Context Examples](https://arxiv.org/abs/2312.06363) | [⬇️](https://arxiv.org/pdf/2312.06363)
*Tao Chen, Enwei Zhang, Yuting Gao, Ke Li, Xing Sun, Yan Zhang and Hui  Li* 

  Although In-Context Learning (ICL) brings remarkable performance gains to
Large Language Models (LLMs), the improvements remain lower than fine-tuning on
downstream tasks. This paper introduces Multi-Modal In-Context Tuning (MMICT),
a novel multi-modal fine-tuning paradigm that boosts multi-modal fine-tuning by
fully leveraging the promising ICL capability of multi-modal LLMs (MM-LLMs). We
propose the Multi-Modal Hub (M-Hub), a unified module that captures various
multi-modal features according to different inputs and objectives. Based on
M-Hub, MMICT enables MM-LLMs to learn from in-context visual-guided textual
features and subsequently generate outputs conditioned on the textual-guided
visual features. Moreover, leveraging the flexibility of M-Hub, we design a
variety of in-context demonstrations. Extensive experiments on a diverse range
of downstream multi-modal tasks demonstrate that MMICT significantly
outperforms traditional fine-tuning strategy and the vanilla ICT method that
directly takes the concatenation of all information from different modalities
as input.

---------------

### 14 Sep 2023 | [SwitchGPT: Adapting Large Language Models for Non-Text Outputs](https://arxiv.org/abs/2309.07623) | [⬇️](https://arxiv.org/pdf/2309.07623)
*Xinyu Wang, Bohan Zhuang, Qi Wu* 

  Large Language Models (LLMs), primarily trained on text-based datasets,
exhibit exceptional proficiencies in understanding and executing complex
linguistic instructions via text outputs. However, they falter when requests to
generate non-text ones. Concurrently, modality conversion models, such as
text-to-image, despite generating high-quality images, suffer from a lack of
extensive textual pretraining. As a result, these models are only capable of
accommodating specific image descriptions rather than comprehending more
complex instructions. To bridge this gap, we propose a novel approach,
\methodname, from a modality conversion perspective that evolves a text-based
LLM into a multi-modal one. We specifically employ a minimal dataset to
instruct LLMs to recognize the intended output modality as directed by the
instructions. Consequently, the adapted LLM can effectively summon various
off-the-shelf modality conversion models from the model zoos to generate
non-text responses. This circumvents the necessity for complicated pretraining
that typically requires immense quantities of paired multi-modal data, while
simultaneously inheriting the extensive knowledge of LLMs and the ability of
high-quality generative models. To evaluate and compare the adapted multi-modal
LLM with its traditional counterparts, we have constructed a multi-modal
instruction benchmark that solicits diverse modality outputs. The experiment
results reveal that, with minimal training, LLMs can be conveniently adapted to
comprehend requests for non-text responses, thus achieving higher flexibility
in multi-modal scenarios. Code and data will be made available at
https://github.com/xinke-wang/SwitchGPT.

---------------

### 30 Dec 2023 | [InstructAny2Pix: Flexible Visual Editing via Multimodal Instruction  Following](https://arxiv.org/abs/2312.06738) | [⬇️](https://arxiv.org/pdf/2312.06738)
*Shufan Li, Harkanwar Singh, Aditya Grover* 

  The ability to provide fine-grained control for generating and editing visual
imagery has profound implications for computer vision and its applications.
Previous works have explored extending controllability in two directions:
instruction tuning with text-based prompts and multi-modal conditioning.
However, these works make one or more unnatural assumptions on the number
and/or type of modality inputs used to express controllability. We propose
InstructAny2Pix, a flexible multi-modal instruction-following system that
enables users to edit an input image using instructions involving audio,
images, and text. InstructAny2Pix consists of three building blocks that
facilitate this capability: a multi-modal encoder that encodes different
modalities such as images and audio into a unified latent space, a diffusion
model that learns to decode representations in this latent space into images,
and a multi-modal LLM that can understand instructions involving multiple
images and audio pieces and generate a conditional embedding of the desired
output, which can be used by the diffusion decoder. Additionally, to facilitate
training efficiency and improve generation quality, we include an additional
refinement prior module that enhances the visual quality of LLM outputs. These
designs are critical to the performance of our system. We demonstrate that our
system can perform a series of novel instruction-guided editing tasks. The code
is available at https://github.com/jacklishufan/InstructAny2Pix.git

---------------

### 15 Jun 2023 | [Macaw-LLM: Multi-Modal Language Modeling with Image, Audio, Video, and  Text Integration](https://arxiv.org/abs/2306.09093) | [⬇️](https://arxiv.org/pdf/2306.09093)
*Chenyang Lyu, Minghao Wu, Longyue Wang, Xinting Huang, Bingshuai Liu,  Zefeng Du, Shuming Shi, Zhaopeng Tu* 

  Although instruction-tuned large language models (LLMs) have exhibited
remarkable capabilities across various NLP tasks, their effectiveness on other
data modalities beyond text has not been fully studied. In this work, we
propose Macaw-LLM, a novel multi-modal LLM that seamlessly integrates visual,
audio, and textual information. Macaw-LLM consists of three main components: a
modality module for encoding multi-modal data, a cognitive module for
harnessing pretrained LLMs, and an alignment module for harmonizing diverse
representations. Our novel alignment module seamlessly bridges multi-modal
features to textual features, simplifying the adaptation process from the
modality modules to the cognitive module. In addition, we construct a
large-scale multi-modal instruction dataset in terms of multi-turn dialogue,
including 69K image instances and 50K video instances. We have made our data,
code and model publicly available, which we hope can pave the way for future
research in multi-modal LLMs and expand the capabilities of LLMs to handle
diverse data modalities and address complex real-world scenarios.

---------------

### 13 Sep 2023 | [Sight Beyond Text: Multi-Modal Training Enhances LLMs in Truthfulness  and Ethics](https://arxiv.org/abs/2309.07120) | [⬇️](https://arxiv.org/pdf/2309.07120)
*Haoqin Tu, Bingchen Zhao, Chen Wei, Cihang Xie* 

  Multi-modal large language models (MLLMs) are trained based on large language
models (LLM), with an enhanced capability to comprehend multi-modal inputs and
generate textual responses. While they excel in multi-modal tasks, the pure NLP
abilities of MLLMs are often underestimated and left untested. In this study,
we get out of the box and unveil an intriguing characteristic of MLLMs -- our
preliminary results suggest that visual instruction tuning, a prevailing
strategy for transitioning LLMs into MLLMs, unexpectedly and interestingly
helps models attain both improved truthfulness and ethical alignment in the
pure NLP context. For example, a visual-instruction-tuned LLaMA2 7B model
surpasses the performance of the LLaMA2-chat 7B model, fine-tuned with over one
million human annotations, on TruthfulQA-mc and Ethics benchmarks. Further
analysis reveals that the improved alignment can be attributed to the superior
instruction quality inherent to visual-text data. In releasing our code at
github.com/UCSC-VLAA/Sight-Beyond-Text, we aspire to foster further exploration
into the intrinsic value of visual-text synergies and, in a broader scope,
multi-modal interactions in alignment research.

---------------

### 07 Dec 2023 | [Prompt Highlighter: Interactive Control for Multi-Modal LLMs](https://arxiv.org/abs/2312.04302) | [⬇️](https://arxiv.org/pdf/2312.04302)
*Yuechen Zhang, Shengju Qian, Bohao Peng, Shu Liu, Jiaya Jia* 

  This study targets a critical aspect of multi-modal LLMs' (LLMs&VLMs)
inference: explicit controllable text generation. Multi-modal LLMs empower
multi-modality understanding with the capability of semantic generation yet
bring less explainability and heavier reliance on prompt contents due to their
autoregressive generative nature. While manipulating prompt formats could
improve outputs, designing specific and precise prompts per task can be
challenging and ineffective. To tackle this issue, we introduce a novel
inference method, Prompt Highlighter, which enables users to highlight specific
prompt spans to interactively control the focus during generation. Motivated by
the classifier-free diffusion guidance, we form regular and unconditional
context pairs based on highlighted tokens, demonstrating that the
autoregressive generation in models can be guided in a classifier-free way.
Notably, we find that, during inference, guiding the models with highlighted
tokens through the attention weights leads to more desired outputs. Our
approach is compatible with current LLMs and VLMs, achieving impressive
customized generation results without training. Experiments confirm its
effectiveness in focusing on input contexts and generating reliable content.
Without tuning on LLaVA-v1.5, our method secured 69.5 in the MMBench test and
1552.5 in MME-perception. The code is available at:
https://github.com/dvlab-research/Prompt-Highlighter/

---------------

### 23 Dec 2023 | [u-LLaVA: Unifying Multi-Modal Tasks via Large Language Model](https://arxiv.org/abs/2311.05348) | [⬇️](https://arxiv.org/pdf/2311.05348)
*Jinjin Xu, Liwu Xu, Yuzhe Yang, Xiang Li, Yanchun Xie, Yi-Jie Huang,  Yaqian Li* 

  Recent advances such as LLaVA and Mini-GPT4 have successfully integrated
visual information into LLMs, yielding inspiring outcomes and giving rise to a
new generation of multi-modal LLMs, or MLLMs. Nevertheless, these methods
struggle with hallucinations and the mutual interference between tasks. To
tackle these problems, we propose an efficient and accurate approach to adapt
to downstream tasks by utilizing LLM as a bridge to connect multiple expert
models, namely u-LLaVA. Firstly, we incorporate the modality alignment module
and multi-task modules into LLM. Then, we reorganize or rebuild multi-type
public datasets to enable efficient modality alignment and instruction
following. Finally, task-specific information is extracted from the trained LLM
and provided to different modules for solving downstream tasks. The overall
framework is simple, effective, and achieves state-of-the-art performance
across multiple benchmarks. We also release our model, the generated data, and
the code base publicly available at https://github.com/OPPOMKLab/u-LLaVA.

---------------

### 08 Jan 2024 | [SpeechAgents: Human-Communication Simulation with Multi-Modal  Multi-Agent Systems](https://arxiv.org/abs/2401.03945) | [⬇️](https://arxiv.org/pdf/2401.03945)
*Dong Zhang, Zhaowei Li, Pengyu Wang, Xin Zhang, Yaqian Zhou, Xipeng  Qiu* 

  Human communication is a complex and diverse process that not only involves
multiple factors such as language, commonsense, and cultural backgrounds but
also requires the participation of multimodal information, such as speech.
Large Language Model (LLM)-based multi-agent systems have demonstrated
promising performance in simulating human society. Can we leverage LLM-based
multi-agent systems to simulate human communication? However, current LLM-based
multi-agent systems mainly rely on text as the primary medium. In this paper,
we propose SpeechAgents, a multi-modal LLM based multi-agent system designed
for simulating human communication. SpeechAgents utilizes multi-modal LLM as
the control center for individual agent and employes multi-modal signals as the
medium for exchanged messages among agents. Additionally, we propose
Multi-Agent Tuning to enhance the multi-agent capabilities of LLM without
compromising general abilities. To strengthen and evaluate the effectiveness of
human communication simulation, we build the Human-Communication Simulation
Benchmark. Experimental results demonstrate that SpeechAgents can simulate
human communication dialogues with consistent content, authentic rhythm, and
rich emotions and demonstrate excellent scalability even with up to 25 agents,
which can apply to tasks such as drama creation and audio novels generation.
Code and models will be open-sourced at https://github.
com/0nutation/SpeechAgents

---------------

### 24 Jan 2024 | [MLLM-Tool: A Multimodal Large Language Model For Tool Agent Learning](https://arxiv.org/abs/2401.10727) | [⬇️](https://arxiv.org/pdf/2401.10727)
*Chenyu Wang, Weixin Luo, Qianyu Chen, Haonan Mai, Jindi Guo, Sixun  Dong, Xiaohua (Michael) Xuan, Zhengxin Li, Lin Ma, Shenghua Gao* 

  Recently, the astonishing performance of large language models (LLMs) in
natural language comprehension and generation tasks triggered lots of
exploration of using them as central controllers to build agent systems.
Multiple studies focus on bridging the LLMs to external tools to extend the
application scenarios. However, the current LLMs' perceiving tool-use ability
is limited to a single text query, which may result in ambiguity in
understanding the users' real intentions. LLMs are expected to eliminate that
by perceiving the visual- or auditory-grounded instructions' information.
Therefore, in this paper, we propose MLLM-Tool, a system incorporating
open-source LLMs and multi-modal encoders so that the learnt LLMs can be
conscious of multi-modal input instruction and then select the function-matched
tool correctly. To facilitate the evaluation of the model's capability, we
collect a dataset featured by consisting of multi-modal input tools from
HuggingFace. Another important feature of our dataset is that our dataset also
contains multiple potential choices for the same instruction due to the
existence of identical functions and synonymous functions, which provides more
potential solutions for the same query. The experiments reveal that our
MLLM-Tool is capable of recommending appropriate tools for multi-modal
instructions. Codes and data are available at
https://github.com/MLLM-Tool/MLLM-Tool.

---------------

### 31 Oct 2023 | [Ziya-Visual: Bilingual Large Vision-Language Model via Multi-Task  Instruction Tuning](https://arxiv.org/abs/2310.08166) | [⬇️](https://arxiv.org/pdf/2310.08166)
*Junyu Lu, Dixiang Zhang, Xiaojun Wu, Xinyu Gao, Ruyi Gan, Jiaxing  Zhang, Yan Song, Pingjian Zhang* 

  Recent advancements enlarge the capabilities of large language models (LLMs)
in zero-shot image-to-text generation and understanding by integrating
multi-modal inputs. However, such success is typically limited to English
scenarios due to the lack of large-scale and high-quality non-English
multi-modal resources, making it extremely difficult to establish competitive
counterparts in other languages. In this paper, we introduce the Ziya-Visual
series, a set of bilingual large-scale vision-language models (LVLMs) designed
to incorporate visual semantics into LLM for multi-modal dialogue. Composed of
Ziya-Visual-Base and Ziya-Visual-Chat, our models adopt the Querying
Transformer from BLIP-2, further exploring the assistance of optimization
schemes such as instruction tuning, multi-stage training and low-rank
adaptation module for visual-language alignment. In addition, we stimulate the
understanding ability of GPT-4 in multi-modal scenarios, translating our
gathered English image-text datasets into Chinese and generating
instruction-response through the in-context learning method. The experiment
results demonstrate that compared to the existing LVLMs, Ziya-Visual achieves
competitive performance across a wide range of English-only tasks including
zero-shot image-text retrieval, image captioning, and visual question
answering. The evaluation leaderboard accessed by GPT-4 also indicates that our
models possess satisfactory image-text understanding and generation
capabilities in Chinese multi-modal scenario dialogues. Code, demo and models
are available at
~\url{https://huggingface.co/IDEA-CCNL/Ziya-BLIP2-14B-Visual-v1}.

---------------

### 12 Oct 2023 | [Towards Robust Multi-Modal Reasoning via Model Selection](https://arxiv.org/abs/2310.08446) | [⬇️](https://arxiv.org/pdf/2310.08446)
*Xiangyan Liu, Rongxue Li, Wei Ji, Tao Lin* 

  The reasoning capabilities of LLM (Large Language Model) are widely
acknowledged in recent research, inspiring studies on tool learning and
autonomous agents. LLM serves as the "brain" of agent, orchestrating multiple
tools for collaborative multi-step task solving. Unlike methods invoking tools
like calculators or weather APIs for straightforward tasks, multi-modal agents
excel by integrating diverse AI models for complex challenges. However, current
multi-modal agents neglect the significance of model selection: they primarily
focus on the planning and execution phases, and will only invoke predefined
task-specific models for each subtask, making the execution fragile. Meanwhile,
other traditional model selection methods are either incompatible with or
suboptimal for the multi-modal agent scenarios, due to ignorance of
dependencies among subtasks arising by multi-step reasoning.
  To this end, we identify the key challenges therein and propose the
$\textit{M}^3$ framework as a plug-in with negligible runtime overhead at
test-time. This framework improves model selection and bolsters the robustness
of multi-modal agents in multi-step reasoning. In the absence of suitable
benchmarks, we create MS-GQA, a new dataset specifically designed to
investigate the model selection challenge in multi-modal agents. Our
experiments reveal that our framework enables dynamic model selection,
considering both user inputs and subtask dependencies, thereby robustifying the
overall reasoning process. Our code and benchmark:
https://github.com/LINs-lab/M3.

---------------
**Date:** 13 Nov 2023

**Title:** Finding and Editing Multi-Modal Neurons in Pre-Trained Transformer

**Abstract Link:** [https://arxiv.org/abs/2311.07470](https://arxiv.org/abs/2311.07470)

**PDF Link:** [https://arxiv.org/pdf/2311.07470](https://arxiv.org/pdf/2311.07470)

---

**Date:** 15 Oct 2023

**Title:** Beyond Segmentation: Road Network Generation with Multi-Modal LLMs

**Abstract Link:** [https://arxiv.org/abs/2310.09755](https://arxiv.org/abs/2310.09755)

**PDF Link:** [https://arxiv.org/pdf/2310.09755](https://arxiv.org/pdf/2310.09755)

---

**Date:** 31 Aug 2023

**Title:** Enhancing Subtask Performance of Multi-modal Large Language Model

**Abstract Link:** [https://arxiv.org/abs/2308.16474](https://arxiv.org/abs/2308.16474)

**PDF Link:** [https://arxiv.org/pdf/2308.16474](https://arxiv.org/pdf/2308.16474)

---

**Date:** 14 Nov 2023

**Title:** Unlock the Power: Competitive Distillation for Multi-Modal Large  Language Models

**Abstract Link:** [https://arxiv.org/abs/2311.08213](https://arxiv.org/abs/2311.08213)

**PDF Link:** [https://arxiv.org/pdf/2311.08213](https://arxiv.org/pdf/2311.08213)

---

**Date:** 15 Jan 2024

**Title:** InternVL: Scaling up Vision Foundation Models and Aligning for Generic  Visual-Linguistic Tasks

**Abstract Link:** [https://arxiv.org/abs/2312.14238](https://arxiv.org/abs/2312.14238)

**PDF Link:** [https://arxiv.org/pdf/2312.14238](https://arxiv.org/pdf/2312.14238)

---

**Date:** 25 Apr 2023

**Title:** AudioGPT: Understanding and Generating Speech, Music, Sound, and Talking  Head

**Abstract Link:** [https://arxiv.org/abs/2304.12995](https://arxiv.org/abs/2304.12995)

**PDF Link:** [https://arxiv.org/pdf/2304.12995](https://arxiv.org/pdf/2304.12995)

---

**Date:** 01 Nov 2023

**Title:** Enhancing the Spatial Awareness Capability of Multi-Modal Large Language  Model

**Abstract Link:** [https://arxiv.org/abs/2310.20357](https://arxiv.org/abs/2310.20357)

**PDF Link:** [https://arxiv.org/pdf/2310.20357](https://arxiv.org/pdf/2310.20357)

---

**Date:** 07 Dec 2023

**Title:** AVA: Towards Autonomous Visualization Agents through Visual  Perception-Driven Decision-Making

**Abstract Link:** [https://arxiv.org/abs/2312.04494](https://arxiv.org/abs/2312.04494)

**PDF Link:** [https://arxiv.org/pdf/2312.04494](https://arxiv.org/pdf/2312.04494)

---

**Date:** 04 Jan 2024

**Title:** TEAL: Tokenize and Embed ALL for Multi-modal Large Language Models

**Abstract Link:** [https://arxiv.org/abs/2311.04589](https://arxiv.org/abs/2311.04589)

**PDF Link:** [https://arxiv.org/pdf/2311.04589](https://arxiv.org/pdf/2311.04589)

---

**Date:** 12 Dec 2023

**Title:** MMICT: Boosting Multi-Modal Fine-Tuning with In-Context Examples

**Abstract Link:** [https://arxiv.org/abs/2312.06363](https://arxiv.org/abs/2312.06363)

**PDF Link:** [https://arxiv.org/pdf/2312.06363](https://arxiv.org/pdf/2312.06363)

---

**Date:** 14 Sep 2023

**Title:** SwitchGPT: Adapting Large Language Models for Non-Text Outputs

**Abstract Link:** [https://arxiv.org/abs/2309.07623](https://arxiv.org/abs/2309.07623)

**PDF Link:** [https://arxiv.org/pdf/2309.07623](https://arxiv.org/pdf/2309.07623)

---

**Date:** 30 Dec 2023

**Title:** InstructAny2Pix: Flexible Visual Editing via Multimodal Instruction  Following

**Abstract Link:** [https://arxiv.org/abs/2312.06738](https://arxiv.org/abs/2312.06738)

**PDF Link:** [https://arxiv.org/pdf/2312.06738](https://arxiv.org/pdf/2312.06738)

---

**Date:** 15 Jun 2023

**Title:** Macaw-LLM: Multi-Modal Language Modeling with Image, Audio, Video, and  Text Integration

**Abstract Link:** [https://arxiv.org/abs/2306.09093](https://arxiv.org/abs/2306.09093)

**PDF Link:** [https://arxiv.org/pdf/2306.09093](https://arxiv.org/pdf/2306.09093)

---

**Date:** 13 Sep 2023

**Title:** Sight Beyond Text: Multi-Modal Training Enhances LLMs in Truthfulness  and Ethics

**Abstract Link:** [https://arxiv.org/abs/2309.07120](https://arxiv.org/abs/2309.07120)

**PDF Link:** [https://arxiv.org/pdf/2309.07120](https://arxiv.org/pdf/2309.07120)

---

**Date:** 07 Dec 2023

**Title:** Prompt Highlighter: Interactive Control for Multi-Modal LLMs

**Abstract Link:** [https://arxiv.org/abs/2312.04302](https://arxiv.org/abs/2312.04302)

**PDF Link:** [https://arxiv.org/pdf/2312.04302](https://arxiv.org/pdf/2312.04302)

---

**Date:** 23 Dec 2023

**Title:** u-LLaVA: Unifying Multi-Modal Tasks via Large Language Model

**Abstract Link:** [https://arxiv.org/abs/2311.05348](https://arxiv.org/abs/2311.05348)

**PDF Link:** [https://arxiv.org/pdf/2311.05348](https://arxiv.org/pdf/2311.05348)

---

**Date:** 08 Jan 2024

**Title:** SpeechAgents: Human-Communication Simulation with Multi-Modal  Multi-Agent Systems

**Abstract Link:** [https://arxiv.org/abs/2401.03945](https://arxiv.org/abs/2401.03945)

**PDF Link:** [https://arxiv.org/pdf/2401.03945](https://arxiv.org/pdf/2401.03945)

---

**Date:** 24 Jan 2024

**Title:** MLLM-Tool: A Multimodal Large Language Model For Tool Agent Learning

**Abstract Link:** [https://arxiv.org/abs/2401.10727](https://arxiv.org/abs/2401.10727)

**PDF Link:** [https://arxiv.org/pdf/2401.10727](https://arxiv.org/pdf/2401.10727)

---

**Date:** 31 Oct 2023

**Title:** Ziya-Visual: Bilingual Large Vision-Language Model via Multi-Task  Instruction Tuning

**Abstract Link:** [https://arxiv.org/abs/2310.08166](https://arxiv.org/abs/2310.08166)

**PDF Link:** [https://arxiv.org/pdf/2310.08166](https://arxiv.org/pdf/2310.08166)

---

**Date:** 12 Oct 2023

**Title:** Towards Robust Multi-Modal Reasoning via Model Selection

**Abstract Link:** [https://arxiv.org/abs/2310.08446](https://arxiv.org/abs/2310.08446)

**PDF Link:** [https://arxiv.org/pdf/2310.08446](https://arxiv.org/pdf/2310.08446)

---

