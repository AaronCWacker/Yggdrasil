AI Talent Development 👥

### 🔎 AI Talent Development 👥



# AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent Development 👥

AI Talent Development 👥

## AI Talent
# 🩺🔍 Search Results
### 25 Jul 2022 | [Designing an AI-Driven Talent Intelligence Solution: Exploring Big Data  to extend the TOE Framework](https://arxiv.org/abs/2207.12052) | [⬇️](https://arxiv.org/pdf/2207.12052)
*Ali Faqihi and Shah J Miah* 

  AI has the potential to improve approaches to talent management enabling
dynamic provisions through implementing advanced automation. This study aims to
identify the new requirements for developing AI-oriented artifacts to address
talent management issues. Focusing on enhancing interactions between
professional assessment and planning attributes, the design artifact is an
intelligent employment automation solution for career guidance that is largely
dependent on a talent intelligent module and an individuals growth needs. A
design science method is adopted for conducting the experimental study with
structured machine learning techniques which is the primary element of a
comprehensive AI solution framework informed through a proposed moderation of
the technology-organization-environment theory.

---------------

### 03 Jul 2023 | [A Comprehensive Survey of Artificial Intelligence Techniques for Talent  Analytics](https://arxiv.org/abs/2307.03195) | [⬇️](https://arxiv.org/pdf/2307.03195)
*Chuan Qin, Le Zhang, Rui Zha, Dazhong Shen, Qi Zhang, Ying Sun, Chen  Zhu, Hengshu Zhu, Hui Xiong* 

  In today's competitive and fast-evolving business environment, it is a
critical time for organizations to rethink how to make talent-related decisions
in a quantitative manner. Indeed, the recent development of Big Data and
Artificial Intelligence (AI) techniques have revolutionized human resource
management. The availability of large-scale talent and management-related data
provides unparalleled opportunities for business leaders to comprehend
organizational behaviors and gain tangible knowledge from a data science
perspective, which in turn delivers intelligence for real-time decision-making
and effective talent management at work for their organizations. In the last
decade, talent analytics has emerged as a promising field in applied data
science for human resource management, garnering significant attention from AI
communities and inspiring numerous research efforts. To this end, we present an
up-to-date and comprehensive survey on AI technologies used for talent
analytics in the field of human resource management. Specifically, we first
provide the background knowledge of talent analytics and categorize various
pertinent data. Subsequently, we offer a comprehensive taxonomy of relevant
research efforts, categorized based on three distinct application-driven
scenarios: talent management, organization management, and labor market
analysis. In conclusion, we summarize the open challenges and potential
prospects for future research directions in the domain of AI-driven talent
analytics.

---------------

### 12 Sep 2019 | [Human-Machine Collaborative Design for Accelerated Design of Compact  Deep Neural Networks for Autonomous Driving](https://arxiv.org/abs/1909.05587) | [⬇️](https://arxiv.org/pdf/1909.05587)
*Mohammad Javad Shafiee, Mirko Nentwig, Yohannes Kassahun, Francis Li,  Stanislav Bochkarev, Akif Kamal, David Dolson, Secil Altintas, Arif Virani,  and Alexander Wong* 

  An effective deep learning development process is critical for widespread
industrial adoption, particularly in the automotive sector. A typical
industrial deep learning development cycle involves customizing and
re-designing an off-the-shelf network architecture to meet the operational
requirements of the target application, leading to considerable trial and error
work by a machine learning practitioner. This approach greatly impedes
development with a long turnaround time and the unsatisfactory quality of the
created models. As a result, a development platform that can aid engineers in
greatly accelerating the design and production of compact, optimized deep
neural networks is highly desirable. In this joint industrial case study, we
study the efficacy of the GenSynth AI-assisted AI design platform for
accelerating the design of custom, optimized deep neural networks for
autonomous driving through human-machine collaborative design. We perform a
quantitative examination by evaluating 10 different compact deep neural
networks produced by GenSynth for the purpose of object detection via a
NASNet-based user network prototype design, targeted at a low-cost GPU-based
accelerated embedded system. Furthermore, we quantitatively assess the talent
hours and GPU processing hours used by the GenSynth process and three other
approaches based on the typical industrial development process. In addition, we
quantify the annual cloud cost savings for comprehensive testing using networks
produced by GenSynth. Finally, we assess the usability and merits of the
GenSynth process through user feedback. The findings of this case study showed
that GenSynth is easy to use and can be effective at accelerating the design
and production of compact, customized deep neural network.

---------------

### 27 Sep 2018 | [Growing and Retaining AI Talent for the United States Government](https://arxiv.org/abs/1809.10276) | [⬇️](https://arxiv.org/pdf/1809.10276)
*Edward Raff* 

  Artificial Intelligence and Machine Learning have become transformative to a
number of industries, and as such many industries need for AI talent is
increasing the demand for individuals with these skills. This continues to
exacerbate the difficulty of acquiring and retaining talent for the United
States Federal Government, both for its direct employees as well as the
companies that support it. We take the position that by focusing on growing and
retaining current talent through a number of cultural changes, the government
can work to remediate this problem today.

---------------

### 17 Apr 2023 | [Quantifying the Benefit of Artificial Intelligence for Scientific  Research](https://arxiv.org/abs/2304.10578) | [⬇️](https://arxiv.org/pdf/2304.10578)
*Jian Gao, Dashun Wang* 

  The ongoing artificial intelligence (AI) revolution has the potential to
change almost every line of work. As AI capabilities continue to improve in
accuracy, robustness, and reach, AI may outperform and even replace human
experts across many valuable tasks. Despite enormous efforts devoted to
understanding AI's impact on labor and the economy and its recent success in
accelerating scientific discovery and progress, we lack a systematic
understanding of how advances in AI may benefit scientific research across
disciplines and fields. Here we develop a measurement framework to estimate
both the direct use of AI and the potential benefit of AI in scientific
research by applying natural language processing techniques to 87.6 million
publications and 7.1 million patents. We find that the use of AI in research
appears widespread throughout the sciences, growing especially rapidly since
2015, and papers that use AI exhibit an impact premium, more likely to be
highly cited both within and outside their disciplines. While almost every
discipline contains some subfields that benefit substantially from AI,
analyzing 4.6 million course syllabi across various educational disciplines, we
find a systematic misalignment between the education of AI and its impact on
research, suggesting the supply of AI talents in scientific disciplines is not
commensurate with AI research demands. Lastly, examining who benefits from AI
within the scientific workforce, we find that disciplines with a higher
proportion of women or black scientists tend to be associated with less
benefit, suggesting that AI's growing impact on research may further exacerbate
existing inequalities in science. As the connection between AI and scientific
research deepens, our findings may have an increasing value, with important
implications for the equity and sustainability of the research enterprise.

---------------

### 13 Jan 2021 | [How AI Developers Overcome Communication Challenges in a  Multidisciplinary Team: A Case Study](https://arxiv.org/abs/2101.06098) | [⬇️](https://arxiv.org/pdf/2101.06098)
*David Piorkowski, Soya Park, April Yi Wang, Dakuo Wang, Michael  Muller, Felix Portnoy* 

  The development of AI applications is a multidisciplinary effort, involving
multiple roles collaborating with the AI developers, an umbrella term we use to
include data scientists and other AI-adjacent roles on the same team. During
these collaborations, there is a knowledge mismatch between AI developers, who
are skilled in data science, and external stakeholders who are typically not.
This difference leads to communication gaps, and the onus falls on AI
developers to explain data science concepts to their collaborators. In this
paper, we report on a study including analyses of both interviews with AI
developers and artifacts they produced for communication. Using the analytic
lens of shared mental models, we report on the types of communication gaps that
AI developers face, how AI developers communicate across disciplinary and
organizational boundaries, and how they simultaneously manage issues regarding
trust and expectations.

---------------

### 17 Jan 2020 | [Activism by the AI Community: Analysing Recent Achievements and Future  Prospects](https://arxiv.org/abs/2001.06528) | [⬇️](https://arxiv.org/pdf/2001.06528)
*Haydn Belfield* 

  The artificial intelligence community (AI) has recently engaged in activism
in relation to their employers, other members of the community, and their
governments in order to shape the societal and ethical implications of AI. It
has achieved some notable successes, but prospects for further political
organising and activism are uncertain. We survey activism by the AI community
over the last six years; apply two analytical frameworks drawing upon the
literature on epistemic communities, and worker organising and bargaining; and
explore what they imply for the future prospects of the AI community. Success
thus far has hinged on a coherent shared culture, and high bargaining power due
to the high demand for a limited supply of AI talent. Both are crucial to the
future of AI activism and worthy of sustained attention.

---------------

### 23 Feb 2022 | [Enabling Reproducibility and Meta-learning Through a Lifelong Database  of Experiments (LDE)](https://arxiv.org/abs/2202.10979) | [⬇️](https://arxiv.org/pdf/2202.10979)
*Jason Tsay, Andrea Bartezzaghi, Aleke Nolte, Cristiano Malossi* 

  Artificial Intelligence (AI) development is inherently iterative and
experimental. Over the course of normal development, especially with the advent
of automated AI, hundreds or thousands of experiments are generated and are
often lost or never examined again. There is a lost opportunity to document
these experiments and learn from them at scale, but the complexity of tracking
and reproducing these experiments is often prohibitive to data scientists. We
present the Lifelong Database of Experiments (LDE) that automatically extracts
and stores linked metadata from experiment artifacts and provides features to
reproduce these artifacts and perform meta-learning across them. We store
context from multiple stages of the AI development lifecycle including
datasets, pipelines, how each is configured, and training runs with information
about their runtime environment. The standardized nature of the stored metadata
allows for querying and aggregation, especially in terms of ranking artifacts
by performance metrics. We exhibit the capabilities of the LDE by reproducing
an existing meta-learning study and storing the reproduced metadata in our
system. Then, we perform two experiments on this metadata: 1) examining the
reproducibility and variability of the performance metrics and 2) implementing
a number of meta-learning algorithms on top of the data and examining how
variability in experimental results impacts recommendation performance. The
experimental results suggest significant variation in performance, especially
depending on dataset configurations; this variation carries over when
meta-learning is built on top of the results, with performance improving when
using aggregated results. This suggests that a system that automatically
collects and aggregates results such as the LDE not only assists in
implementing meta-learning but may also improve its performance.

---------------

### 15 Nov 2021 | [aiSTROM -- A roadmap for developing a successful AI strategy](https://arxiv.org/abs/2107.06071) | [⬇️](https://arxiv.org/pdf/2107.06071)
*Dorien Herremans* 

  A total of 34% of AI research and development projects fails or are
abandoned, according to a recent survey by Rackspace Technology of 1,870
companies. We propose a new strategic framework, aiSTROM, that empowers
managers to create a successful AI strategy based on a thorough literature
review. This provides a unique and integrated approach that guides managers and
lead developers through the various challenges in the implementation process.
In the aiSTROM framework, we start by identifying the top n potential projects
(typically 3-5). For each of those, seven areas of focus are thoroughly
analysed. These areas include creating a data strategy that takes into account
unique cross-departmental machine learning data requirements, security, and
legal requirements. aiSTROM then guides managers to think about how to put
together an interdisciplinary artificial intelligence (AI) implementation team
given the scarcity of AI talent. Once an AI team strategy has been established,
it needs to be positioned within the organization, either cross-departmental or
as a separate division. Other considerations include AI as a service (AIaas),
or outsourcing development. Looking at new technologies, we have to consider
challenges such as bias, legality of black-box-models, and keeping humans in
the loop. Next, like any project, we need value-based key performance
indicators (KPIs) to track and validate the progress. Depending on the
company's risk-strategy, a SWOT analysis (strengths, weaknesses, opportunities,
and threats) can help further classify the shortlisted projects. Finally, we
should make sure that our strategy includes continuous education of employees
to enable a culture of adoption. This unique and comprehensive framework offers
a valuable, literature supported, tool for managers and lead developers.

---------------

### 09 Jul 2021 | [Accelerated, Scalable and Reproducible AI-driven Gravitational Wave  Detection](https://arxiv.org/abs/2012.08545) | [⬇️](https://arxiv.org/pdf/2012.08545)
*E. A. Huerta, Asad Khan, Xiaobo Huang, Minyang Tian, Maksim Levental,  Ryan Chard, Wei Wei, Maeve Heflin, Daniel S. Katz, Volodymyr Kindratenko,  Dawei Mu, Ben Blaiszik and Ian Foster* 

  The development of reusable artificial intelligence (AI) models for wider use
and rigorous validation by the community promises to unlock new opportunities
in multi-messenger astrophysics. Here we develop a workflow that connects the
Data and Learning Hub for Science, a repository for publishing AI models, with
the Hardware Accelerated Learning (HAL) cluster, using funcX as a universal
distributed computing service. Using this workflow, an ensemble of four openly
available AI models can be run on HAL to process an entire month's worth
(August 2017) of advanced Laser Interferometer Gravitational-Wave Observatory
data in just seven minutes, identifying all four all four binary black hole
mergers previously identified in this dataset and reporting no
misclassifications. This approach combines advances in AI, distributed
computing, and scientific data infrastructure to open new pathways to conduct
reproducible, accelerated, data-driven discovery.

---------------

### 23 Jan 2023 | [Proactive and Reactive Engagement of Artificial Intelligence Methods for  Education: A Review](https://arxiv.org/abs/2301.10231) | [⬇️](https://arxiv.org/pdf/2301.10231)
*Sruti Mallik, Ahana Gangopadhyay* 

  Quality education, one of the seventeen sustainable development goals (SDGs)
identified by the United Nations General Assembly, stands to benefit enormously
from the adoption of artificial intelligence (AI) driven tools and
technologies. The concurrent boom of necessary infrastructure, digitized data
and general social awareness has propelled massive research and development
efforts in the artificial intelligence for education (AIEd) sector. In this
review article, we investigate how artificial intelligence, machine learning
and deep learning methods are being utilized to support students, educators and
administrative staff. We do this through the lens of a novel categorization
approach. We consider the involvement of AI-driven methods in the education
process in its entirety - from students admissions, course scheduling etc. in
the proactive planning phase to knowledge delivery, performance assessment etc.
in the reactive execution phase. We outline and analyze the major research
directions under proactive and reactive engagement of AI in education using a
representative group of 194 original research articles published in the past
two decades i.e., 2003 - 2022. We discuss the paradigm shifts in the solution
approaches proposed, i.e., in the choice of data and algorithms used over this
time. We further dive into how the COVID-19 pandemic challenged and reshaped
the education landscape at the fag end of this time period. Finally, we
pinpoint existing limitations in adopting artificial intelligence for education
and reflect on the path forward.

---------------

### 06 Feb 2024 | [GenLens: A Systematic Evaluation of Visual GenAI Model Outputs](https://arxiv.org/abs/2402.03700) | [⬇️](https://arxiv.org/pdf/2402.03700)
*Tica Lin, Hanspeter Pfister, Jui-Hsien Wang* 

  The rapid development of generative AI (GenAI) models in computer vision
necessitates effective evaluation methods to ensure their quality and fairness.
Existing tools primarily focus on dataset quality assurance and model
explainability, leaving a significant gap in GenAI output evaluation during
model development. Current practices often depend on developers' subjective
visual assessments, which may lack scalability and generalizability. This paper
bridges this gap by conducting a formative study with GenAI model developers in
an industrial setting. Our findings led to the development of GenLens, a visual
analytic interface designed for the systematic evaluation of GenAI model
outputs during the early stages of model development. GenLens offers a
quantifiable approach for overviewing and annotating failure cases, customizing
issue tags and classifications, and aggregating annotations from multiple users
to enhance collaboration. A user study with model developers reveals that
GenLens effectively enhances their workflow, evidenced by high satisfaction
rates and a strong intent to integrate it into their practices. This research
underscores the importance of robust early-stage evaluation tools in GenAI
development, contributing to the advancement of fair and high-quality GenAI
models.

---------------

### 13 Aug 2019 | [Evaluation of a Recommender System for Assisting Novice Game Designers](https://arxiv.org/abs/1908.04629) | [⬇️](https://arxiv.org/pdf/1908.04629)
*Tiago Machado, Daniel Gopstein, Oded Nov, Angela Wang, Andy Nealen,  Julian Togelius* 

  Game development is a complex task involving multiple disciplines and
technologies. Developers and researchers alike have suggested that AI-driven
game design assistants may improve developer workflow. We present a recommender
system for assisting humans in game design as well as a rigorous human subjects
study to validate it. The AI-driven game design assistance system suggests game
mechanics to designers based on characteristics of the game being developed. We
believe this method can bring creative insights and increase users'
productivity. We conducted quantitative studies that showed the recommender
system increases users' levels of accuracy and computational affect, and
decreases their levels of workload.

---------------

### 12 Aug 2021 | [Competency Model Approach to AI Literacy: Research-based Path from  Initial Framework to Model](https://arxiv.org/abs/2108.05809) | [⬇️](https://arxiv.org/pdf/2108.05809)
*Farhana Faruqe, Ryan Watkins, Larry Medsker* 

  The recent developments in Artificial Intelligence (AI) technologies
challenge educators and educational institutions to respond with curriculum and
resources that prepare students of all ages with the foundational knowledge and
skills for success in the AI workplace. Research on AI Literacy could lead to
an effective and practical platform for developing these skills. We propose and
advocate for a pathway for developing AI Literacy as a pragmatic and useful
tool for AI education. Such a discipline requires moving beyond a conceptual
framework to a multi-level competency model with associated competency
assessments. This approach to an AI Literacy could guide future development of
instructional content as we prepare a range of groups (i.e., consumers,
co-workers, collaborators, and creators). We propose here a research matrix as
an initial step in the development of a roadmap for AI Literacy research, which
requires a systematic and coordinated effort with the support of publication
outlets and research funding, to expand the areas of competency and
assessments.

---------------

### 23 Jan 2024 | [Towards Trustworthy AI Software Development Assistance](https://arxiv.org/abs/2312.09126) | [⬇️](https://arxiv.org/pdf/2312.09126)
*Daniel Maninger, Krishna Narasimhan, Mira Mezini* 

  It is expected that in the near future, AI software development assistants
will play an important role in the software industry. However, current software
development assistants tend to be unreliable, often producing incorrect,
unsafe, or low-quality code. We seek to resolve these issues by introducing a
holistic architecture for constructing, training, and using trustworthy AI
software development assistants. In the center of the architecture, there is a
foundational LLM trained on datasets representative of real-world coding
scenarios and complex software architectures, and fine-tuned on code quality
criteria beyond correctness. The LLM will make use of graph-based code
representations for advanced semantic comprehension. We envision a knowledge
graph integrated into the system to provide up-to-date background knowledge and
to enable the assistant to provide appropriate explanations. Finally, a modular
framework for constrained decoding will ensure that certain guarantees (e.g.,
for correctness and security) hold for the generated code.

---------------

### 12 Aug 2023 | [Ground Truth Or Dare: Factors Affecting The Creation Of Medical Datasets  For Training AI](https://arxiv.org/abs/2309.12327) | [⬇️](https://arxiv.org/pdf/2309.12327)
*Hubert D. Zaj\k{a}c, Natalia R. Avlona, Tariq O. Andersen, Finn  Kensing, Irina Shklovski* 

  One of the core goals of responsible AI development is ensuring high-quality
training datasets. Many researchers have pointed to the importance of the
annotation step in the creation of high-quality data, but less attention has
been paid to the work that enables data annotation. We define this work as the
design of ground truth schema and explore the challenges involved in the
creation of datasets in the medical domain even before any annotations are
made. Based on extensive work in three health-tech organisations, we describe
five external and internal factors that condition medical dataset creation
processes. Three external factors include regulatory constraints, the context
of creation and use, and commercial and operational pressures. These factors
condition medical data collection and shape the ground truth schema design. Two
internal factors include epistemic differences and limits of labelling. These
directly shape the design of the ground truth schema. Discussions of what
constitutes high-quality data need to pay attention to the factors that shape
and constrain what is possible to be created, to ensure responsible AI design.

---------------

### 23 Mar 2020 | [From Bit To Bedside: A Practical Framework For Artificial Intelligence  Product Development In Healthcare](https://arxiv.org/abs/2003.10303) | [⬇️](https://arxiv.org/pdf/2003.10303)
*David Higgins and Vince I. Madai* 

  Artificial Intelligence (AI) in healthcare holds great potential to expand
access to high-quality medical care, whilst reducing overall systemic costs.
Despite hitting the headlines regularly and many publications of
proofs-of-concept, certified products are failing to breakthrough to the
clinic. AI in healthcare is a multi-party process with deep knowledge required
in multiple individual domains. The lack of understanding of the specific
challenges in the domain is, therefore, the major contributor to the failure to
deliver on the big promises. Thus, we present a decision perspective framework,
for the development of AI-driven biomedical products, from conception to market
launch. Our framework highlights the risks, objectives and key results which
are typically required to proceed through a three-phase process to the market
launch of a validated medical AI product. We focus on issues related to
Clinical validation, Regulatory affairs, Data strategy and Algorithmic
development. The development process we propose for AI in healthcare software
strongly diverges from modern consumer software development processes. We
highlight the key time points to guide founders, investors and key stakeholders
throughout their relevant part of the process. Our framework should be seen as
a template for innovation frameworks, which can be used to coordinate team
communications and responsibilities towards a reasonable product development
roadmap, thus unlocking the potential of AI in medicine.

---------------

### 02 Dec 2017 | [Improvised Comedy as a Turing Test](https://arxiv.org/abs/1711.08819) | [⬇️](https://arxiv.org/pdf/1711.08819)
*Kory Wallace Mathewson and Piotr Mirowski* 

  The best improvisational theatre actors can make any scene partner, of any
skill level or ability, appear talented and proficient in the art form, and
thus "make them shine". To challenge this improvisational paradigm, we built an
artificial intelligence (AI) trained to perform live shows alongside human
actors for human audiences. Over the course of 30 performances to a combined
audience of almost 3000 people, we have refined theatrical games which involve
combinations of human and (at times, adversarial) AI actors. We have developed
specific scene structures to include audience participants in interesting ways.
Finally, we developed a complete show structure that submitted the audience to
a Turing test and observed their suspension of disbelief, which we believe is
key for human/non-human theatre co-creation.

---------------

### 24 Oct 2023 | [Accelerating Split Federated Learning over Wireless Communication  Networks](https://arxiv.org/abs/2310.15584) | [⬇️](https://arxiv.org/pdf/2310.15584)
*Ce Xu, Jinxuan Li, Yuan Liu, Yushi Ling, and Miaowen Wen* 

  The development of artificial intelligence (AI) provides opportunities for
the promotion of deep neural network (DNN)-based applications. However, the
large amount of parameters and computational complexity of DNN makes it
difficult to deploy it on edge devices which are resource-constrained. An
efficient method to address this challenge is model partition/splitting, in
which DNN is divided into two parts which are deployed on device and server
respectively for co-training or co-inference. In this paper, we consider a
split federated learning (SFL) framework that combines the parallel model
training mechanism of federated learning (FL) and the model splitting structure
of split learning (SL). We consider a practical scenario of heterogeneous
devices with individual split points of DNN. We formulate a joint problem of
split point selection and bandwidth allocation to minimize the system latency.
By using alternating optimization, we decompose the problem into two
sub-problems and solve them optimally. Experiment results demonstrate the
superiority of our work in latency reduction and accuracy improvement.

---------------

### 18 Aug 2023 | [Generative AI Assistants in Software Development Education: A vision for  integrating Generative AI into educational practice, not instinctively  defending against it](https://arxiv.org/abs/2303.13936) | [⬇️](https://arxiv.org/pdf/2303.13936)
*Christopher Bull, Ahmed Kharrufa* 

  The software development industry is amid another disruptive paradigm change
- adopting the use of generative AI (GAI) assistants for programming. Whilst AI
is already used in various areas of software engineering, GAI technologies,
such as GitHub Copilot and ChatGPT, have ignited peoples' imaginations (and
fears). It is unclear how the industry will adapt, but the move to integrate
these technologies by large software companies, such as Microsoft (GitHub,
Bing) and Google (Bard), is a clear indication of intent and direction. We
performed exploratory interviews with industry professionals to understand
current practice and challenges, which we incorporate into our vision of a
future of software development education and make some pedagogical
recommendations.

---------------
**Date:** 25 Jul 2022

**Title:** Designing an AI-Driven Talent Intelligence Solution: Exploring Big Data  to extend the TOE Framework

**Abstract Link:** [https://arxiv.org/abs/2207.12052](https://arxiv.org/abs/2207.12052)

**PDF Link:** [https://arxiv.org/pdf/2207.12052](https://arxiv.org/pdf/2207.12052)

---

**Date:** 03 Jul 2023

**Title:** A Comprehensive Survey of Artificial Intelligence Techniques for Talent  Analytics

**Abstract Link:** [https://arxiv.org/abs/2307.03195](https://arxiv.org/abs/2307.03195)

**PDF Link:** [https://arxiv.org/pdf/2307.03195](https://arxiv.org/pdf/2307.03195)

---

**Date:** 12 Sep 2019

**Title:** Human-Machine Collaborative Design for Accelerated Design of Compact  Deep Neural Networks for Autonomous Driving

**Abstract Link:** [https://arxiv.org/abs/1909.05587](https://arxiv.org/abs/1909.05587)

**PDF Link:** [https://arxiv.org/pdf/1909.05587](https://arxiv.org/pdf/1909.05587)

---

**Date:** 27 Sep 2018

**Title:** Growing and Retaining AI Talent for the United States Government

**Abstract Link:** [https://arxiv.org/abs/1809.10276](https://arxiv.org/abs/1809.10276)

**PDF Link:** [https://arxiv.org/pdf/1809.10276](https://arxiv.org/pdf/1809.10276)

---

**Date:** 17 Apr 2023

**Title:** Quantifying the Benefit of Artificial Intelligence for Scientific  Research

**Abstract Link:** [https://arxiv.org/abs/2304.10578](https://arxiv.org/abs/2304.10578)

**PDF Link:** [https://arxiv.org/pdf/2304.10578](https://arxiv.org/pdf/2304.10578)

---

**Date:** 13 Jan 2021

**Title:** How AI Developers Overcome Communication Challenges in a  Multidisciplinary Team: A Case Study

**Abstract Link:** [https://arxiv.org/abs/2101.06098](https://arxiv.org/abs/2101.06098)

**PDF Link:** [https://arxiv.org/pdf/2101.06098](https://arxiv.org/pdf/2101.06098)

---

**Date:** 17 Jan 2020

**Title:** Activism by the AI Community: Analysing Recent Achievements and Future  Prospects

**Abstract Link:** [https://arxiv.org/abs/2001.06528](https://arxiv.org/abs/2001.06528)

**PDF Link:** [https://arxiv.org/pdf/2001.06528](https://arxiv.org/pdf/2001.06528)

---

**Date:** 23 Feb 2022

**Title:** Enabling Reproducibility and Meta-learning Through a Lifelong Database  of Experiments (LDE)

**Abstract Link:** [https://arxiv.org/abs/2202.10979](https://arxiv.org/abs/2202.10979)

**PDF Link:** [https://arxiv.org/pdf/2202.10979](https://arxiv.org/pdf/2202.10979)

---

**Date:** 15 Nov 2021

**Title:** aiSTROM -- A roadmap for developing a successful AI strategy

**Abstract Link:** [https://arxiv.org/abs/2107.06071](https://arxiv.org/abs/2107.06071)

**PDF Link:** [https://arxiv.org/pdf/2107.06071](https://arxiv.org/pdf/2107.06071)

---

**Date:** 09 Jul 2021

**Title:** Accelerated, Scalable and Reproducible AI-driven Gravitational Wave  Detection

**Abstract Link:** [https://arxiv.org/abs/2012.08545](https://arxiv.org/abs/2012.08545)

**PDF Link:** [https://arxiv.org/pdf/2012.08545](https://arxiv.org/pdf/2012.08545)

---

**Date:** 23 Jan 2023

**Title:** Proactive and Reactive Engagement of Artificial Intelligence Methods for  Education: A Review

**Abstract Link:** [https://arxiv.org/abs/2301.10231](https://arxiv.org/abs/2301.10231)

**PDF Link:** [https://arxiv.org/pdf/2301.10231](https://arxiv.org/pdf/2301.10231)

---

**Date:** 06 Feb 2024

**Title:** GenLens: A Systematic Evaluation of Visual GenAI Model Outputs

**Abstract Link:** [https://arxiv.org/abs/2402.03700](https://arxiv.org/abs/2402.03700)

**PDF Link:** [https://arxiv.org/pdf/2402.03700](https://arxiv.org/pdf/2402.03700)

---

**Date:** 13 Aug 2019

**Title:** Evaluation of a Recommender System for Assisting Novice Game Designers

**Abstract Link:** [https://arxiv.org/abs/1908.04629](https://arxiv.org/abs/1908.04629)

**PDF Link:** [https://arxiv.org/pdf/1908.04629](https://arxiv.org/pdf/1908.04629)

---

**Date:** 12 Aug 2021

**Title:** Competency Model Approach to AI Literacy: Research-based Path from  Initial Framework to Model

**Abstract Link:** [https://arxiv.org/abs/2108.05809](https://arxiv.org/abs/2108.05809)

**PDF Link:** [https://arxiv.org/pdf/2108.05809](https://arxiv.org/pdf/2108.05809)

---

**Date:** 23 Jan 2024

**Title:** Towards Trustworthy AI Software Development Assistance

**Abstract Link:** [https://arxiv.org/abs/2312.09126](https://arxiv.org/abs/2312.09126)

**PDF Link:** [https://arxiv.org/pdf/2312.09126](https://arxiv.org/pdf/2312.09126)

---

**Date:** 12 Aug 2023

**Title:** Ground Truth Or Dare: Factors Affecting The Creation Of Medical Datasets  For Training AI

**Abstract Link:** [https://arxiv.org/abs/2309.12327](https://arxiv.org/abs/2309.12327)

**PDF Link:** [https://arxiv.org/pdf/2309.12327](https://arxiv.org/pdf/2309.12327)

---

**Date:** 23 Mar 2020

**Title:** From Bit To Bedside: A Practical Framework For Artificial Intelligence  Product Development In Healthcare

**Abstract Link:** [https://arxiv.org/abs/2003.10303](https://arxiv.org/abs/2003.10303)

**PDF Link:** [https://arxiv.org/pdf/2003.10303](https://arxiv.org/pdf/2003.10303)

---

**Date:** 02 Dec 2017

**Title:** Improvised Comedy as a Turing Test

**Abstract Link:** [https://arxiv.org/abs/1711.08819](https://arxiv.org/abs/1711.08819)

**PDF Link:** [https://arxiv.org/pdf/1711.08819](https://arxiv.org/pdf/1711.08819)

---

**Date:** 24 Oct 2023

**Title:** Accelerating Split Federated Learning over Wireless Communication  Networks

**Abstract Link:** [https://arxiv.org/abs/2310.15584](https://arxiv.org/abs/2310.15584)

**PDF Link:** [https://arxiv.org/pdf/2310.15584](https://arxiv.org/pdf/2310.15584)

---

**Date:** 18 Aug 2023

**Title:** Generative AI Assistants in Software Development Education: A vision for  integrating Generative AI into educational practice, not instinctively  defending against it

**Abstract Link:** [https://arxiv.org/abs/2303.13936](https://arxiv.org/abs/2303.13936)

**PDF Link:** [https://arxiv.org/pdf/2303.13936](https://arxiv.org/pdf/2303.13936)

---

