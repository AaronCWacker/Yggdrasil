Major AI Industry Players 🌐

### 🔎 Major AI Industry Players 🌐



🔹 Google
🔹 Microsoft
🔹 IBM
🔹 Amazon
🔹 Apple
🔹 Baidu
🔹 Alibaba
🔹 Tencent
🔹 Huawei
🔹 NVIDIA
🔹 Intel
🔹 Oracle
🔹 Salesforce
🔹 SAP
🔹 SAS
🔹 Teradata
🔹 Uber
🔹 Tesla
🔹 Didi Chuxing
🔹 JD.com
🔹 Ping An Insurance
🔹 China Mobile
🔹 China Telecom
🔹 China Unicom
🔹 SoftBank
🔹 Samsung
🔹 LG
🔹 Sony
🔹 Fujitsu
🔹 Hitachi
🔹 NEC
🔹 Ericsson
🔹 Cisco
🔹 HPE
🔹 Dell
🔹 Lenovo
🔹 VMware
🔹 Palantir
🔹 Darktrace
🔹 CrowdStrike
🔹 Zscaler
🔹 Okta
🔹 Twilio
🔹 Databricks
🔹 Snowflake
🔹 Datadog
🔹 Elastic
🔹 MongoDB
🔹 Redis Labs
🔹 Confluent
🔹 HashiCorp
🔹 GitLab
🔹 HashiCorp
🔹 GitLab
🔹 GitHub
🔹 Docker
🔹 Mesosphere
🔹 CoreOS
🔹 Kubernetes
🔹 Prometheus
🔹 Grafana
🔹 InfluxData
🔹 Cockroach Labs
🔹 Timescale
🔹 Mattermost
🔹 HashiCorp
🔹 Grafana

# 🩺🔍 Search Results
### 02 Jun 2023 | [AI Imagery and the Overton Window](https://arxiv.org/abs/2306.00080) | [⬇️](https://arxiv.org/pdf/2306.00080)
*Sarah K. Amer* 

  AI-based text-to-image generation has undergone a significant leap in the
production of visually comprehensive and aesthetic imagery over the past year,
to the point where differentiating between a man-made piece of art and an
AI-generated image is becoming more difficult. Generative Models such as Stable
Diffusion, Midjourney and others are expected to affect several major
industries in technological and ethical aspects. Striking the balance between
raising human standard of life and work vs exploiting one group of people to
enrich another is a complex and crucial part of the discussion. Due to the
rapid growth of this technology, the way in which its models operate, and gray
area legalities, visual and artistic domains - including the video game
industry, are at risk of being taken over from creators by AI infrastructure
owners. This paper is a literature review examining the concerns facing both AI
developers and users today, including identity theft, data laundering and more.
It discusses legalization challenges and ethical concerns, and concludes with
how AI generative models can be tremendously useful in streamlining the process
of visual creativity in both static and interactive media given proper
regulation.
  Keywords: AI text-to-image generation, Midjourney, Stable Diffusion, AI
Ethics, Game Design, Digital Art, Data Laundering

---------------

### 01 Apr 2020 | [Suphx: Mastering Mahjong with Deep Reinforcement Learning](https://arxiv.org/abs/2003.13590) | [⬇️](https://arxiv.org/pdf/2003.13590)
*Junjie Li, Sotetsu Koyamada, Qiwei Ye, Guoqing Liu, Chao Wang, Ruihan  Yang, Li Zhao, Tao Qin, Tie-Yan Liu, Hsiao-Wuen Hon* 

  Artificial Intelligence (AI) has achieved great success in many domains, and
game AI is widely regarded as its beachhead since the dawn of AI. In recent
years, studies on game AI have gradually evolved from relatively simple
environments (e.g., perfect-information games such as Go, chess, shogi or
two-player imperfect-information games such as heads-up Texas hold'em) to more
complex ones (e.g., multi-player imperfect-information games such as
multi-player Texas hold'em and StartCraft II). Mahjong is a popular
multi-player imperfect-information game worldwide but very challenging for AI
research due to its complex playing/scoring rules and rich hidden information.
We design an AI for Mahjong, named Suphx, based on deep reinforcement learning
with some newly introduced techniques including global reward prediction,
oracle guiding, and run-time policy adaptation. Suphx has demonstrated stronger
performance than most top human players in terms of stable rank and is rated
above 99.99% of all the officially ranked human players in the Tenhou platform.
This is the first time that a computer program outperforms most top human
players in Mahjong.

---------------

### 24 Nov 2023 | [Who is leading in AI? An analysis of industry AI research](https://arxiv.org/abs/2312.00043) | [⬇️](https://arxiv.org/pdf/2312.00043)
*Ben Cottier, Tamay Besiroglu, David Owen* 

  AI research is increasingly industry-driven, making it crucial to understand
company contributions to this field. We compare leading AI companies by
research publications, citations, size of training runs, and contributions to
algorithmic innovations. Our analysis reveals the substantial role played by
Google, OpenAI and Meta. We find that these three companies have been
responsible for some of the largest training runs, developed a large fraction
of the algorithmic innovations that underpin large language models, and led in
various metrics of citation impact. In contrast, leading Chinese companies such
as Tencent and Baidu had a lower impact on many of these metrics compared to US
counterparts. We observe many industry labs are pursuing large training runs,
and that training runs from relative newcomers -- such as OpenAI and Anthropic
-- have matched or surpassed those of long-standing incumbents such as Google.
The data reveals a diverse ecosystem of companies steering AI progress, though
US labs such as Google, OpenAI and Meta lead across critical metrics.

---------------

### 29 Jul 2022 | [The NPC AI of The Last of Us: A case study](https://arxiv.org/abs/2207.00682) | [⬇️](https://arxiv.org/pdf/2207.00682)
*Harsh Panwar* 

  The Last of Us is a game focused on stealth, companionship and strategy. The
game is based in a lonely world after the pandemic and thus it needs AI
companions to gain the interest of players. There are three main NPCs the game
has - Infected, Human enemy and Buddy AIs. This case study talks about the
challenges in front of the developers to create AI for these NPCs and the AI
techniques they used to solve them. It also compares the challenges and
approach with similar industry-leading games.

---------------

### 04 Jul 2023 | [A Bibliographic Study on Artificial Intelligence Research: Global  Panorama and Indian Appearance](https://arxiv.org/abs/2308.00705) | [⬇️](https://arxiv.org/pdf/2308.00705)
*Amit Tiwari, Susmita Bardhan, Vikas Kumar* 

  The present study identifies and assesses the bibliographic trend in
Artificial Intelligence (AI) research for the years 2015-2020 using the science
mapping method of bibliometric study. The required data has been collected from
the Scopus database. To make the collected data analysis-ready, essential data
transformation was performed manually and with the help of a tool viz.
OpenRefine. For determining the trend and performing the mapping techniques,
top five open access and commercial journals of AI have been chosen based on
their citescore driven ranking. The work includes 6880 articles published in
the specified period for analysis. The trend is based on Country-wise
publications, year-wise publications, topical terms in AI, top-cited articles,
prominent authors, major institutions, involvement of industries in AI and
Indian appearance. The results show that compared to open access journals;
commercial journals have a higher citescore and number of articles published
over the years. Additionally, IEEE is the prominent publisher which publishes
84% of the top-cited publications. Further, China and the United States are the
major contributors to literature in the AI domain. The study reveals that
neural networks and deep learning are the major topics included in top AI
research publications. Recently, not only public institutions but also private
bodies are investing their resources in AI research. The study also
investigates the relative position of Indian researchers in terms of AI
research. Present work helps in understanding the initial development, current
stand and future direction of AI.

---------------

### 13 Apr 2018 | [Successful Nash Equilibrium Agent for a 3-Player Imperfect-Information  Game](https://arxiv.org/abs/1804.04789) | [⬇️](https://arxiv.org/pdf/1804.04789)
*Sam Ganzfried, Austin Nowak, Joannier Pinales* 

  Creating strong agents for games with more than two players is a major open
problem in AI. Common approaches are based on approximating game-theoretic
solution concepts such as Nash equilibrium, which have strong theoretical
guarantees in two-player zero-sum games, but no guarantees in non-zero-sum
games or in games with more than two players. We describe an agent that is able
to defeat a variety of realistic opponents using an exact Nash equilibrium
strategy in a 3-player imperfect-information game. This shows that, despite a
lack of theoretical guarantees, agents based on Nash equilibrium strategies can
be successful in multiplayer games after all.

---------------

### 01 Nov 2022 | [AI-powered mechanisms as judges: Breaking ties in chess and beyond](https://arxiv.org/abs/2210.08289) | [⬇️](https://arxiv.org/pdf/2210.08289)
*Nejat Anbarci and Mehmet S. Ismail* 

  Recently, Artificial Intelligence (AI) technology use has been rising in
sports. For example, to reduce staff during the COVID-19 pandemic, major tennis
tournaments replaced human line judges with Hawk-Eye Live technology. AI is now
ready to move beyond such mundane tasks, however. A case in point and a perfect
application ground is chess. To reduce the growing incidence of draws, many
elite tournaments have resorted to fast chess tiebreakers. However, these
tiebreakers are vulnerable to strategic manipulation, e.g., in the last game of
the 2018 World Chess Championship, Magnus Carlsen -- in a significantly
advantageous position -- offered a draw to Fabiano Caruana (whom accepted the
offer) to proceed to fast chess tiebreaks in which Carlsen had even better odds
of winning the championship. By contrast, we prove that our AI-based method can
serve as a judge to break ties without being vulnerable to such manipulation.
It relies on measuring the difference between the evaluations of a player's
actual move and the best move as deemed by a powerful chess engine. If there is
a tie, the player with the higher quality measure wins the tiebreak. We
generalize our method to all competitive sports and games in which AI's
superiority is -- or can be -- established.

---------------

### 19 Jan 2021 | [Creation and Evaluation of a Pre-tertiary Artificial Intelligence (AI)  Curriculum](https://arxiv.org/abs/2101.07570) | [⬇️](https://arxiv.org/pdf/2101.07570)
*Thomas K.F. Chiu, Helen Meng, Ching-Sing Chai, Irwin King, Savio Wong  and Yeung Yam* 

  Contributions: The Chinese University of Hong Kong (CUHK)-Jockey Club AI for
the Future Project (AI4Future) co-created an AI curriculum for pre-tertiary
education and evaluated its efficacy. While AI is conventionally taught in
tertiary level education, our co-creation process successfully developed the
curriculum that has been used in secondary school teaching in Hong Kong and
received positive feedback. Background: AI4Future is a cross-sector project
that engages five major partners - CUHK Faculty of Engineering and Faculty of
Education, Hong Kong secondary schools, the government and the AI industry. A
team of 14 professors with expertise in engineering and education collaborated
with 17 principals and teachers from 6 secondary schools to co-create the
curriculum. This team formation bridges the gap between researchers in
engineering and education, together with practitioners in education context.
Research Questions: What are the main features of the curriculum content
developed through the co-creation process? Would the curriculum significantly
improve the students perceived competence in, as well as attitude and
motivation towards AI? What are the teachers perceptions of the co-creation
process that aims to accommodate and foster teacher autonomy? Methodology: This
study adopted a mix of quantitative and qualitative methods and involved 335
student participants. Findings: 1) two main features of learning resources, 2)
the students perceived greater competence, and developed more positive attitude
to learn AI, and 3) the co-creation process generated a variety of resources
which enhanced the teachers knowledge in AI, as well as fostered teachers
autonomy in bringing the subject matter into their classrooms.

---------------

### 01 Sep 2020 | ["It's Unwieldy and It Takes a Lot of Time." Challenges and Opportunities  for Creating Agents in Commercial Games](https://arxiv.org/abs/2009.00541) | [⬇️](https://arxiv.org/pdf/2009.00541)
*Mikhail Jacob, Sam Devlin, Katja Hofmann* 

  Game agents such as opponents, non-player characters, and teammates are
central to player experiences in many modern games. As the landscape of AI
techniques used in the games industry evolves to adopt machine learning (ML)
more widely, it is vital that the research community learn from the best
practices cultivated within the industry over decades creating agents. However,
although commercial game agent creation pipelines are more mature than those
based on ML, opportunities for improvement still abound. As a foundation for
shared progress identifying research opportunities between researchers and
practitioners, we interviewed seventeen game agent creators from AAA studios,
indie studios, and industrial research labs about the challenges they
experienced with their professional workflows. Our study revealed several open
challenges ranging from design to implementation and evaluation. We compare
with literature from the research community that address the challenges
identified and conclude by highlighting promising directions for future
research supporting agent creation in the games industry.

---------------

### 31 Mar 2020 | [Enhanced Rolling Horizon Evolution Algorithm with Opponent Model  Learning: Results for the Fighting Game AI Competition](https://arxiv.org/abs/2003.13949) | [⬇️](https://arxiv.org/pdf/2003.13949)
*Zhentao Tang, Yuanheng Zhu, Dongbin Zhao, Simon M. Lucas* 

  The Fighting Game AI Competition (FTGAIC) provides a challenging benchmark
for 2-player video game AI. The challenge arises from the large action space,
diverse styles of characters and abilities, and the real-time nature of the
game. In this paper, we propose a novel algorithm that combines Rolling Horizon
Evolution Algorithm (RHEA) with opponent model learning. The approach is
readily applicable to any 2-player video game. In contrast to conventional
RHEA, an opponent model is proposed and is optimized by supervised learning
with cross-entropy and reinforcement learning with policy gradient and
Q-learning respectively, based on history observations from opponent. The model
is learned during the live gameplay. With the learned opponent model, the
extended RHEA is able to make more realistic plans based on what the opponent
is likely to do. This tends to lead to better results. We compared our approach
directly with the bots from the FTGAIC 2018 competition, and found our method
to significantly outperform all of them, for all three character. Furthermore,
our proposed bot with the policy-gradient-based opponent model is the only one
without using Monte-Carlo Tree Search (MCTS) among top five bots in the 2019
competition in which it achieved second place, while using much less domain
knowledge than the winner.

---------------

### 02 Dec 2021 | [On Two XAI Cultures: A Case Study of Non-technical Explanations in  Deployed AI System](https://arxiv.org/abs/2112.01016) | [⬇️](https://arxiv.org/pdf/2112.01016)
*Helen Jiang, Erwen Senge* 

  Explainable AI (XAI) research has been booming, but the question "$\textbf{To
whom}$ are we making AI explainable?" is yet to gain sufficient attention. Not
much of XAI is comprehensible to non-AI experts, who nonetheless, are the
primary audience and major stakeholders of deployed AI systems in practice. The
gap is glaring: what is considered "explained" to AI-experts versus non-experts
are very different in practical scenarios. Hence, this gap produced two
distinct cultures of expectations, goals, and forms of XAI in real-life AI
deployments.
  We advocate that it is critical to develop XAI methods for non-technical
audiences. We then present a real-life case study, where AI experts provided
non-technical explanations of AI decisions to non-technical stakeholders, and
completed a successful deployment in a highly regulated industry. We then
synthesize lessons learned from the case, and share a list of suggestions for
AI experts to consider when explaining AI decisions to non-technical
stakeholders.

---------------

### 30 Nov 2023 | [AI in Pharma for Personalized Sequential Decision-Making: Methods,  Applications and Opportunities](https://arxiv.org/abs/2311.18725) | [⬇️](https://arxiv.org/pdf/2311.18725)
*Yuhan Li, Hongtao Zhang, Keaven Anderson, Songzi Li and Ruoqing Zhu* 

  In the pharmaceutical industry, the use of artificial intelligence (AI) has
seen consistent growth over the past decade. This rise is attributed to major
advancements in statistical machine learning methodologies, computational
capabilities and the increased availability of large datasets. AI techniques
are applied throughout different stages of drug development, ranging from drug
discovery to post-marketing benefit-risk assessment. Kolluri et al. provided a
review of several case studies that span these stages, featuring key
applications such as protein structure prediction, success probability
estimation, subgroup identification, and AI-assisted clinical trial monitoring.
From a regulatory standpoint, there was a notable uptick in submissions
incorporating AI components in 2021. The most prevalent therapeutic areas
leveraging AI were oncology (27%), psychiatry (15%), gastroenterology (12%),
and neurology (11%). The paradigm of personalized or precision medicine has
gained significant traction in recent research, partly due to advancements in
AI techniques \cite{hamburg2010path}. This shift has had a transformative
impact on the pharmaceutical industry. Departing from the traditional
"one-size-fits-all" model, personalized medicine incorporates various
individual factors, such as environmental conditions, lifestyle choices, and
health histories, to formulate customized treatment plans. By utilizing
sophisticated machine learning algorithms, clinicians and researchers are
better equipped to make informed decisions in areas such as disease prevention,
diagnosis, and treatment selection, thereby optimizing health outcomes for each
individual.

---------------

### 21 Feb 2020 | [Most Important Fundamental Rule of Poker Strategy](https://arxiv.org/abs/1906.09895) | [⬇️](https://arxiv.org/pdf/1906.09895)
*Sam Ganzfried and Max Chiswick* 

  Poker is a large complex game of imperfect information, which has been
singled out as a major AI challenge problem. Recently there has been a series
of breakthroughs culminating in agents that have successfully defeated the
strongest human players in two-player no-limit Texas hold 'em. The strongest
agents are based on algorithms for approximating Nash equilibrium strategies,
which are stored in massive binary files and unintelligible to humans. A recent
line of research has explored approaches for extrapolating knowledge from
strong game-theoretic strategies that can be understood by humans. This would
be useful when humans are the ultimate decision maker and allow humans to make
better decisions from massive algorithmically-generated strategies. Using
techniques from machine learning we have uncovered a new simple, fundamental
rule of poker strategy that leads to a significant improvement in performance
over the best prior rule and can also easily be applied by human players.

---------------

### 09 Nov 2015 | [Using Behavior Objects to Manage Complexity in Virtual Worlds](https://arxiv.org/abs/1508.00377) | [⬇️](https://arxiv.org/pdf/1508.00377)
*Martin \v{C}ern\'y, Tom\'a\v{s} Plch, Mat\v{e}j Marko, Jakub Gemrot,  Petr Ondr\'a\v{c}ek, Cyril Brom* 

  The quality of high-level AI of non-player characters (NPCs) in commercial
open-world games (OWGs) has been increasing during the past years. However, due
to constraints specific to the game industry, this increase has been slow and
it has been driven by larger budgets rather than adoption of new complex AI
techniques. Most of the contemporary AI is still expressed as hard-coded
scripts. The complexity and manageability of the script codebase is one of the
key limiting factors for further AI improvements. In this paper we address this
issue. We present behavior objects - a general approach to development of NPC
behaviors for large OWGs. Behavior objects are inspired by object-oriented
programming and extend the concept of smart objects. Our approach promotes
encapsulation of data and code for multiple related behaviors in one place,
hiding internal details and embedding intelligence in the environment. Behavior
objects are a natural abstraction of five different techniques that we have
implemented to manage AI complexity in an upcoming AAA OWG. We report the
details of the implementations in the context of behavior trees and the lessons
learned during development. Our work should serve as inspiration for AI
architecture designers from both the academia and the industry.

---------------

### 07 Apr 2021 | [The Duo of Artificial Intelligence and Big Data for Industry 4.0: Review  of Applications, Techniques, Challenges, and Future Research Directions](https://arxiv.org/abs/2104.02425) | [⬇️](https://arxiv.org/pdf/2104.02425)
*Senthil Kumar Jagatheesaperumal, Mohamed Rahouti, Kashif Ahmad, Ala  Al-Fuqaha, Mohsen Guizani* 

  The increasing need for economic, safe, and sustainable smart manufacturing
combined with novel technological enablers, has paved the way for Artificial
Intelligence (AI) and Big Data in support of smart manufacturing. This implies
a substantial integration of AI, Industrial Internet of Things (IIoT),
Robotics, Big data, Blockchain, 5G communications, in support of smart
manufacturing and the dynamical processes in modern industries. In this paper,
we provide a comprehensive overview of different aspects of AI and Big Data in
Industry 4.0 with a particular focus on key applications, techniques, the
concepts involved, key enabling technologies, challenges, and research
perspective towards deployment of Industry 5.0. In detail, we highlight and
analyze how the duo of AI and Big Data is helping in different applications of
Industry 4.0. We also highlight key challenges in a successful deployment of AI
and Big Data methods in smart industries with a particular emphasis on
data-related issues, such as availability, bias, auditing, management,
interpretability, communication, and different adversarial attacks and security
issues. In a nutshell, we have explored the significance of AI and Big data
towards Industry 4.0 applications through panoramic reviews and discussions. We
believe, this work will provide a baseline for future research in the domain.

---------------

### 18 Aug 2023 | [Generative AI Assistants in Software Development Education: A vision for  integrating Generative AI into educational practice, not instinctively  defending against it](https://arxiv.org/abs/2303.13936) | [⬇️](https://arxiv.org/pdf/2303.13936)
*Christopher Bull, Ahmed Kharrufa* 

  The software development industry is amid another disruptive paradigm change
- adopting the use of generative AI (GAI) assistants for programming. Whilst AI
is already used in various areas of software engineering, GAI technologies,
such as GitHub Copilot and ChatGPT, have ignited peoples' imaginations (and
fears). It is unclear how the industry will adapt, but the move to integrate
these technologies by large software companies, such as Microsoft (GitHub,
Bing) and Google (Bard), is a clear indication of intent and direction. We
performed exploratory interviews with industry professionals to understand
current practice and challenges, which we incorporate into our vision of a
future of software development education and make some pedagogical
recommendations.

---------------

### 22 Dec 2022 | [Towards Sustainable Artificial Intelligence: An Overview of  Environmental Protection Uses and Issues](https://arxiv.org/abs/2212.11738) | [⬇️](https://arxiv.org/pdf/2212.11738)
*Arnault Pachot, C\'eline Patissier* 

  Artificial Intelligence (AI) is used to create more sustainable production
methods and model climate change, making it a valuable tool in the fight
against environmental degradation. This paper describes the paradox of an
energy-consuming technology serving the ecological challenges of tomorrow. The
study provides an overview of the sectors that use AI-based solutions for
environmental protection. It draws on numerous examples from AI for Green
players to present use cases and concrete examples. In the second part of the
study, the negative impacts of AI on the environment and the emerging
technological solutions to support Green AI are examined. It is also shown that
the research on less energy-consuming AI is motivated more by cost and energy
autonomy constraints than by environmental considerations. This leads to a
rebound effect that favors an increase in the complexity of models. Finally,
the need to integrate environmental indicators into algorithms is discussed.
The environmental dimension is part of the broader ethical problem of AI, and
addressing it is crucial for ensuring the sustainability of AI in the long
term.

---------------

### 18 Aug 2023 | [Balancing Transparency and Risk: The Security and Privacy Risks of  Open-Source Machine Learning Models](https://arxiv.org/abs/2308.09490) | [⬇️](https://arxiv.org/pdf/2308.09490)
*Dominik Hintersdorf, Lukas Struppek, Kristian Kersting* 

  The field of artificial intelligence (AI) has experienced remarkable progress
in recent years, driven by the widespread adoption of open-source machine
learning models in both research and industry. Considering the
resource-intensive nature of training on vast datasets, many applications opt
for models that have already been trained. Hence, a small number of key players
undertake the responsibility of training and publicly releasing large
pre-trained models, providing a crucial foundation for a wide range of
applications. However, the adoption of these open-source models carries
inherent privacy and security risks that are often overlooked. To provide a
concrete example, an inconspicuous model may conceal hidden functionalities
that, when triggered by specific input patterns, can manipulate the behavior of
the system, such as instructing self-driving cars to ignore the presence of
other vehicles. The implications of successful privacy and security attacks
encompass a broad spectrum, ranging from relatively minor damage like service
interruptions to highly alarming scenarios, including physical harm or the
exposure of sensitive user data. In this work, we present a comprehensive
overview of common privacy and security threats associated with the use of
open-source models. By raising awareness of these dangers, we strive to promote
the responsible and secure use of AI systems.

---------------

### 10 Jul 2023 | [Exploring Antitrust and Platform Power in Generative AI](https://arxiv.org/abs/2306.11342) | [⬇️](https://arxiv.org/pdf/2306.11342)
*Konrad Kollnig and Qian Li* 

  The concentration of power in a few digital technology companies has become a
subject of increasing interest in both academic and non-academic discussions.
One of the most noteworthy contributions to the debate is Lina Khan's Amazon's
Antitrust Paradox. In this work, Khan contends that Amazon has systematically
exerted its dominance in online retail to eliminate competitors and
subsequently charge above-market prices. This work contributed to Khan's
appointment as the chair of the US Federal Trade Commission (FTC), one of the
most influential antitrust organisations. Today, several ongoing antitrust
lawsuits in the US and Europe involve major technology companies like Apple,
Google/Alphabet, and Facebook/Meta. In the realm of generative AI, we are once
again witnessing the same companies taking the lead in technological
advancements, leaving little room for others to compete. This article examines
the market dominance of these corporations in the technology stack behind
generative AI from an antitrust law perspective.

---------------

### 06 Mar 2024 | [Human vs. Machine: Language Models and Wargames](https://arxiv.org/abs/2403.03407) | [⬇️](https://arxiv.org/pdf/2403.03407)
*Max Lamparth, Anthony Corso, Jacob Ganz, Oriana Skylar Mastro,  Jacquelyn Schneider, Harold Trinkunas* 

  Wargames have a long history in the development of military strategy and the
response of nations to threats or attacks. The advent of artificial
intelligence (AI) promises better decision-making and increased military
effectiveness. However, there is still debate about how AI systems, especially
large language models (LLMs), behave as compared to humans. To this end, we use
a wargame experiment with 107 national security expert human players designed
to look at crisis escalation in a fictional US-China scenario and compare human
players to LLM-simulated responses. We find considerable agreement in the LLM
and human responses but also significant quantitative and qualitative
differences between simulated and human players in the wargame, motivating
caution to policymakers before handing over autonomy or following AI-based
strategy recommendations.

---------------
**Date:** 02 Jun 2023

**Title:** AI Imagery and the Overton Window

**Abstract Link:** [https://arxiv.org/abs/2306.00080](https://arxiv.org/abs/2306.00080)

**PDF Link:** [https://arxiv.org/pdf/2306.00080](https://arxiv.org/pdf/2306.00080)

---

**Date:** 01 Apr 2020

**Title:** Suphx: Mastering Mahjong with Deep Reinforcement Learning

**Abstract Link:** [https://arxiv.org/abs/2003.13590](https://arxiv.org/abs/2003.13590)

**PDF Link:** [https://arxiv.org/pdf/2003.13590](https://arxiv.org/pdf/2003.13590)

---

**Date:** 24 Nov 2023

**Title:** Who is leading in AI? An analysis of industry AI research

**Abstract Link:** [https://arxiv.org/abs/2312.00043](https://arxiv.org/abs/2312.00043)

**PDF Link:** [https://arxiv.org/pdf/2312.00043](https://arxiv.org/pdf/2312.00043)

---

**Date:** 29 Jul 2022

**Title:** The NPC AI of The Last of Us: A case study

**Abstract Link:** [https://arxiv.org/abs/2207.00682](https://arxiv.org/abs/2207.00682)

**PDF Link:** [https://arxiv.org/pdf/2207.00682](https://arxiv.org/pdf/2207.00682)

---

**Date:** 04 Jul 2023

**Title:** A Bibliographic Study on Artificial Intelligence Research: Global  Panorama and Indian Appearance

**Abstract Link:** [https://arxiv.org/abs/2308.00705](https://arxiv.org/abs/2308.00705)

**PDF Link:** [https://arxiv.org/pdf/2308.00705](https://arxiv.org/pdf/2308.00705)

---

**Date:** 13 Apr 2018

**Title:** Successful Nash Equilibrium Agent for a 3-Player Imperfect-Information  Game

**Abstract Link:** [https://arxiv.org/abs/1804.04789](https://arxiv.org/abs/1804.04789)

**PDF Link:** [https://arxiv.org/pdf/1804.04789](https://arxiv.org/pdf/1804.04789)

---

**Date:** 01 Nov 2022

**Title:** AI-powered mechanisms as judges: Breaking ties in chess and beyond

**Abstract Link:** [https://arxiv.org/abs/2210.08289](https://arxiv.org/abs/2210.08289)

**PDF Link:** [https://arxiv.org/pdf/2210.08289](https://arxiv.org/pdf/2210.08289)

---

**Date:** 19 Jan 2021

**Title:** Creation and Evaluation of a Pre-tertiary Artificial Intelligence (AI)  Curriculum

**Abstract Link:** [https://arxiv.org/abs/2101.07570](https://arxiv.org/abs/2101.07570)

**PDF Link:** [https://arxiv.org/pdf/2101.07570](https://arxiv.org/pdf/2101.07570)

---

**Date:** 01 Sep 2020

**Title:** "It's Unwieldy and It Takes a Lot of Time." Challenges and Opportunities  for Creating Agents in Commercial Games

**Abstract Link:** [https://arxiv.org/abs/2009.00541](https://arxiv.org/abs/2009.00541)

**PDF Link:** [https://arxiv.org/pdf/2009.00541](https://arxiv.org/pdf/2009.00541)

---

**Date:** 31 Mar 2020

**Title:** Enhanced Rolling Horizon Evolution Algorithm with Opponent Model  Learning: Results for the Fighting Game AI Competition

**Abstract Link:** [https://arxiv.org/abs/2003.13949](https://arxiv.org/abs/2003.13949)

**PDF Link:** [https://arxiv.org/pdf/2003.13949](https://arxiv.org/pdf/2003.13949)

---

**Date:** 02 Dec 2021

**Title:** On Two XAI Cultures: A Case Study of Non-technical Explanations in  Deployed AI System

**Abstract Link:** [https://arxiv.org/abs/2112.01016](https://arxiv.org/abs/2112.01016)

**PDF Link:** [https://arxiv.org/pdf/2112.01016](https://arxiv.org/pdf/2112.01016)

---

**Date:** 30 Nov 2023

**Title:** AI in Pharma for Personalized Sequential Decision-Making: Methods,  Applications and Opportunities

**Abstract Link:** [https://arxiv.org/abs/2311.18725](https://arxiv.org/abs/2311.18725)

**PDF Link:** [https://arxiv.org/pdf/2311.18725](https://arxiv.org/pdf/2311.18725)

---

**Date:** 21 Feb 2020

**Title:** Most Important Fundamental Rule of Poker Strategy

**Abstract Link:** [https://arxiv.org/abs/1906.09895](https://arxiv.org/abs/1906.09895)

**PDF Link:** [https://arxiv.org/pdf/1906.09895](https://arxiv.org/pdf/1906.09895)

---

**Date:** 09 Nov 2015

**Title:** Using Behavior Objects to Manage Complexity in Virtual Worlds

**Abstract Link:** [https://arxiv.org/abs/1508.00377](https://arxiv.org/abs/1508.00377)

**PDF Link:** [https://arxiv.org/pdf/1508.00377](https://arxiv.org/pdf/1508.00377)

---

**Date:** 07 Apr 2021

**Title:** The Duo of Artificial Intelligence and Big Data for Industry 4.0: Review  of Applications, Techniques, Challenges, and Future Research Directions

**Abstract Link:** [https://arxiv.org/abs/2104.02425](https://arxiv.org/abs/2104.02425)

**PDF Link:** [https://arxiv.org/pdf/2104.02425](https://arxiv.org/pdf/2104.02425)

---

**Date:** 18 Aug 2023

**Title:** Generative AI Assistants in Software Development Education: A vision for  integrating Generative AI into educational practice, not instinctively  defending against it

**Abstract Link:** [https://arxiv.org/abs/2303.13936](https://arxiv.org/abs/2303.13936)

**PDF Link:** [https://arxiv.org/pdf/2303.13936](https://arxiv.org/pdf/2303.13936)

---

**Date:** 22 Dec 2022

**Title:** Towards Sustainable Artificial Intelligence: An Overview of  Environmental Protection Uses and Issues

**Abstract Link:** [https://arxiv.org/abs/2212.11738](https://arxiv.org/abs/2212.11738)

**PDF Link:** [https://arxiv.org/pdf/2212.11738](https://arxiv.org/pdf/2212.11738)

---

**Date:** 18 Aug 2023

**Title:** Balancing Transparency and Risk: The Security and Privacy Risks of  Open-Source Machine Learning Models

**Abstract Link:** [https://arxiv.org/abs/2308.09490](https://arxiv.org/abs/2308.09490)

**PDF Link:** [https://arxiv.org/pdf/2308.09490](https://arxiv.org/pdf/2308.09490)

---

**Date:** 10 Jul 2023

**Title:** Exploring Antitrust and Platform Power in Generative AI

**Abstract Link:** [https://arxiv.org/abs/2306.11342](https://arxiv.org/abs/2306.11342)

**PDF Link:** [https://arxiv.org/pdf/2306.11342](https://arxiv.org/pdf/2306.11342)

---

**Date:** 06 Mar 2024

**Title:** Human vs. Machine: Language Models and Wargames

**Abstract Link:** [https://arxiv.org/abs/2403.03407](https://arxiv.org/abs/2403.03407)

**PDF Link:** [https://arxiv.org/pdf/2403.03407](https://arxiv.org/pdf/2403.03407)

---

