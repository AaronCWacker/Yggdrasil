Neural Interpretability Methods 🔭

### 🔎 Neural Interpretability Methods 🔭


====================================

This repository contains a collection of neural interpretability methods,
including visualization tools, attribution methods, and model-agnostic
methods.


Visualization Tools
-------------------

* **[Activation Maximization](activation_maximization.py)**:
  Generate images that maximally activate a given neuron.
* **[Saliency Maps](saliency_maps.py)**:
  Visualize the importance of each pixel in an image for a given class.
* **[GradCAM](gradcam.py)**:
  Visualize the importance of each pixel in an image for a given class.
* **[Guided Backpropagation](guided_backpropagation.py)**:
  Visualize the positive and negative contributions of each pixel in an image
  for a given class.
* **[Deconvolution](deconvolution.py)**:
  Visualize the positive and negative contributions of each pixel in an image
  for a given class.
* **[Integrated Gradients](integrated_gradients.py)**:
  Visualize the positive and negative contributions of each pixel in an image
  for a given class.
* **[DeepLIFT](deeplift.py)**:
  Visualize the positive and negative contributions of each pixel in an image
  for a given class.
* **[Layer-wise Relevance Propagation (LRP)](lrp.py)**:
  Visualize the positive and negative contributions of each pixel in an image
  for a given class.
* **[SHAP](shap.py)**:
  Visualize the positive and negative contributions of each pixel in an image
  for a given class.


Attribution Methods
-------------------

* **[Input × Gradient](input_x_gradient.py)**:
  Compute the attribution of each input feature for a given class.
* **[Integrated Gradients](integrated_gradients.py)**:
  Compute the attribution of each input feature for a given class.
* **[DeepLIFT](deeplift.py)**:
  Compute the attribution of each input feature for a given class.
* **[Layer-wise Relevance Propagation (LRP)](lrp
# 🩺🔍 Search Results
### 16 Jun 2022 | [Geometrically Guided Integrated Gradients](https://arxiv.org/abs/2206.05903) | [⬇️](https://arxiv.org/pdf/2206.05903)
*Md Mahfuzur Rahman, Noah Lewis, Sergey Plis* 

  Interpretability methods for deep neural networks mainly focus on the
sensitivity of the class score with respect to the original or perturbed input,
usually measured using actual or modified gradients. Some methods also use a
model-agnostic approach to understanding the rationale behind every prediction.
In this paper, we argue and demonstrate that local geometry of the model
parameter space relative to the input can also be beneficial for improved
post-hoc explanations. To achieve this goal, we introduce an interpretability
method called "geometrically-guided integrated gradients" that builds on top of
the gradient calculation along a linear path as traditionally used in
integrated gradient methods. However, instead of integrating gradient
information, our method explores the model's dynamic behavior from multiple
scaled versions of the input and captures the best possible attribution for
each input. We demonstrate through extensive experiments that the proposed
approach outperforms vanilla and integrated gradients in subjective and
quantitative assessment. We also propose a "model perturbation" sanity check to
complement the traditionally used "model randomization" test.

---------------

### 16 Oct 2020 | [Evaluating Attribution Methods using White-Box LSTMs](https://arxiv.org/abs/2010.08606) | [⬇️](https://arxiv.org/pdf/2010.08606)
*Yiding Hao* 

  Interpretability methods for neural networks are difficult to evaluate
because we do not understand the black-box models typically used to test them.
This paper proposes a framework in which interpretability methods are evaluated
using manually constructed networks, which we call white-box networks, whose
behavior is understood a priori. We evaluate five methods for producing
attribution heatmaps by applying them to white-box LSTM classifiers for tasks
based on formal languages. Although our white-box classifiers solve their tasks
perfectly and transparently, we find that all five attribution methods fail to
produce the expected model explanations.

---------------

### 26 Feb 2021 | [Layer-Wise Interpretation of Deep Neural Networks Using Identity  Initialization](https://arxiv.org/abs/2102.13333) | [⬇️](https://arxiv.org/pdf/2102.13333)
*Shohei Kubota, Hideaki Hayashi, Tomohiro Hayase, Seiichi Uchida* 

  The interpretability of neural networks (NNs) is a challenging but essential
topic for transparency in the decision-making process using machine learning.
One of the reasons for the lack of interpretability is random weight
initialization, where the input is randomly embedded into a different feature
space in each layer. In this paper, we propose an interpretation method for a
deep multilayer perceptron, which is the most general architecture of NNs,
based on identity initialization (namely, initialization using identity
matrices). The proposed method allows us to analyze the contribution of each
neuron to classification and class likelihood in each hidden layer. As a
property of the identity-initialized perceptron, the weight matrices remain
near the identity matrices even after learning. This property enables us to
treat the change of features from the input to each hidden layer as the
contribution to classification. Furthermore, we can separate the output of each
hidden layer into a contribution map that depicts the contribution to
classification and class likelihood, by adding extra dimensions to each layer
according to the number of classes, thereby allowing the calculation of the
recognition accuracy in each layer and thus revealing the roles of independent
layers, such as feature extraction and classification.

---------------

### 15 Nov 2019 | [Explanatory Masks for Neural Network Interpretability](https://arxiv.org/abs/1911.06876) | [⬇️](https://arxiv.org/pdf/1911.06876)
*Lawrence Phillips, Garrett Goh, Nathan Hodas* 

  Neural network interpretability is a vital component for applications across
a wide variety of domains. In such cases it is often useful to analyze a
network which has already been trained for its specific purpose. In this work,
we develop a method to produce explanation masks for pre-trained networks. The
mask localizes the most important aspects of each input for prediction of the
original network. Masks are created by a secondary network whose goal is to
create as small an explanation as possible while still preserving the
predictive accuracy of the original network. We demonstrate the applicability
of our method for image classification with CNNs, sentiment analysis with RNNs,
and chemical property prediction with mixed CNN/RNN architectures.

---------------

### 22 Aug 2023 | [Explicability and Inexplicability in the Interpretation of Quantum  Neural Networks](https://arxiv.org/abs/2308.11098) | [⬇️](https://arxiv.org/pdf/2308.11098)
*Lirand\"e Pira, Chris Ferrie* 

  Interpretability of artificial intelligence (AI) methods, particularly deep
neural networks, is of great interest due to the widespread use of AI-backed
systems, which often have unexplainable behavior. The interpretability of such
models is a crucial component of building trusted systems. Many methods exist
to approach this problem, but they do not obviously generalize to the quantum
setting. Here we explore the interpretability of quantum neural networks using
local model-agnostic interpretability measures of quantum and classical neural
networks. We introduce the concept of the band of inexplicability, representing
the interpretable region in which data samples have no explanation, likely
victims of inherently random quantum measurements. We see this as a step toward
understanding how to build responsible and accountable quantum AI models.

---------------

### 04 Dec 2023 | [Class-Discriminative Attention Maps for Vision Transformers](https://arxiv.org/abs/2312.02364) | [⬇️](https://arxiv.org/pdf/2312.02364)
*Lennart Brocki and Neo Christopher Chung* 

  Interpretability methods are critical components for examining and exploring
deep neural networks (DNN), as well as increasing our understanding of and
trust in them. Vision transformers (ViT), which can be trained to
state-of-the-art performance with a self-supervised learning (SSL) training
method, provide built-in attention maps (AM). While AMs can provide
high-quality semantic segmentation of input images, they do not account for any
signal coming from a downstream classifier. We introduce class-discriminative
attention maps (CDAM), a novel post-hoc explanation method that is highly
sensitive to the target class. Our method essentially scales attention scores
by how relevant the corresponding tokens are for the predictions of a
classifier head. Alternative to classifier outputs, CDAM can also explain a
user-defined concept by targeting similarity measures in the latent space of
the ViT. This allows for explanations of arbitrary concepts, defined by the
user through a few sample images. We investigate the operating characteristics
of CDAM in comparison with relevance propagation (RP) and token ablation maps
(TAM), an alternative to pixel occlusion methods. CDAM is highly
class-discriminative and semantically relevant, while providing implicit
regularization of relevance scores.
  PyTorch implementation: \url{https://github.com/lenbrocki/CDAM}
  Web live demo: \url{https://cdam.informatism.com/}

---------------

### 05 Oct 2023 | [Evaluating the Robustness of Interpretability Methods through  Explanation Invariance and Equivariance](https://arxiv.org/abs/2304.06715) | [⬇️](https://arxiv.org/pdf/2304.06715)
*Jonathan Crabb\'e, Mihaela van der Schaar* 

  Interpretability methods are valuable only if their explanations faithfully
describe the explained model. In this work, we consider neural networks whose
predictions are invariant under a specific symmetry group. This includes
popular architectures, ranging from convolutional to graph neural networks. Any
explanation that faithfully explains this type of model needs to be in
agreement with this invariance property. We formalize this intuition through
the notion of explanation invariance and equivariance by leveraging the
formalism from geometric deep learning. Through this rigorous formalism, we
derive (1) two metrics to measure the robustness of any interpretability method
with respect to the model symmetry group; (2) theoretical robustness guarantees
for some popular interpretability methods and (3) a systematic approach to
increase the invariance of any interpretability method with respect to a
symmetry group. By empirically measuring our metrics for explanations of models
associated with various modalities and symmetry groups, we derive a set of 5
guidelines to allow users and developers of interpretability methods to produce
robust explanations.

---------------

### 20 Jun 2023 | [Causal Analysis for Robust Interpretability of Neural Networks](https://arxiv.org/abs/2305.08950) | [⬇️](https://arxiv.org/pdf/2305.08950)
*Ola Ahmad, Nicolas Bereux, Lo\"ic Baret, Vahid Hashemi, Freddy Lecue* 

  Interpreting the inner function of neural networks is crucial for the
trustworthy development and deployment of these black-box models. Prior
interpretability methods focus on correlation-based measures to attribute model
decisions to individual examples. However, these measures are susceptible to
noise and spurious correlations encoded in the model during the training phase
(e.g., biased inputs, model overfitting, or misspecification). Moreover, this
process has proven to result in noisy and unstable attributions that prevent
any transparent understanding of the model's behavior. In this paper, we
develop a robust interventional-based method grounded by causal analysis to
capture cause-effect mechanisms in pre-trained neural networks and their
relation to the prediction. Our novel approach relies on path interventions to
infer the causal mechanisms within hidden layers and isolate relevant and
necessary information (to model prediction), avoiding noisy ones. The result is
task-specific causal explanatory graphs that can audit model behavior and
express the actual causes underlying its performance. We apply our method to
vision models trained on classification tasks. On image classification tasks,
we provide extensive quantitative experiments to show that our approach can
capture more stable and faithful explanations than standard attribution-based
methods. Furthermore, the underlying causal graphs reveal the neural
interactions in the model, making it a valuable tool in other applications
(e.g., model repair).

---------------

### 27 Aug 2023 | [Towards Vision-Language Mechanistic Interpretability: A Causal Tracing  Tool for BLIP](https://arxiv.org/abs/2308.14179) | [⬇️](https://arxiv.org/pdf/2308.14179)
*Vedant Palit and Rohan Pandey and Aryaman Arora and Paul Pu Liang* 

  Mechanistic interpretability seeks to understand the neural mechanisms that
enable specific behaviors in Large Language Models (LLMs) by leveraging
causality-based methods. While these approaches have identified neural circuits
that copy spans of text, capture factual knowledge, and more, they remain
unusable for multimodal models since adapting these tools to the
vision-language domain requires considerable architectural changes. In this
work, we adapt a unimodal causal tracing tool to BLIP to enable the study of
the neural mechanisms underlying image-conditioned text generation. We
demonstrate our approach on a visual question answering dataset, highlighting
the causal relevance of later layer representations for all tokens.
Furthermore, we release our BLIP causal tracing tool as open source to enable
further experimentation in vision-language mechanistic interpretability by the
community. Our code is available at
https://github.com/vedantpalit/Towards-Vision-Language-Mechanistic-Interpretability.

---------------

### 28 Sep 2021 | [Discriminative Attribution from Counterfactuals](https://arxiv.org/abs/2109.13412) | [⬇️](https://arxiv.org/pdf/2109.13412)
*Nils Eckstein, Alexander S. Bates, Gregory S.X.E. Jefferis, Jan Funke* 

  We present a method for neural network interpretability by combining feature
attribution with counterfactual explanations to generate attribution maps that
highlight the most discriminative features between pairs of classes. We show
that this method can be used to quantitatively evaluate the performance of
feature attribution methods in an objective manner, thus preventing potential
observer bias. We evaluate the proposed method on three diverse datasets,
including a challenging artificial dataset and real-world biological data. We
show quantitatively and qualitatively that the highlighted features are
substantially more discriminative than those extracted using conventional
attribution methods and argue that this type of explanation is better suited
for understanding fine grained class differences as learned by a deep neural
network.

---------------

### 27 May 2022 | [TimeREISE: Time-series Randomized Evolving Input Sample Explanation](https://arxiv.org/abs/2202.07952) | [⬇️](https://arxiv.org/pdf/2202.07952)
*Dominique Mercier, Andreas Dengel, Sheraz Ahmed* 

  Deep neural networks are one of the most successful classifiers across
different domains. However, due to their limitations concerning
interpretability their use is limited in safety critical context. The research
field of explainable artificial intelligence addresses this problem. However,
most of the interpretability methods are aligned to the image modality by
design. The paper introduces TimeREISE a model agnostic attribution method
specifically aligned to success in the context of time series classification.
The method shows superior performance compared to existing approaches
concerning different well-established measurements. TimeREISE is applicable to
any time series classification network, its runtime does not scale in a linear
manner concerning the input shape and it does not rely on prior data knowledge.

---------------

### 02 Jan 2024 | [A Test Statistic Estimation-based Approach for Establishing  Self-interpretable CNN-based Binary Classifiers](https://arxiv.org/abs/2303.06876) | [⬇️](https://arxiv.org/pdf/2303.06876)
*Sourya Sengupta and Mark A. Anastasio* 

  Interpretability is highly desired for deep neural network-based classifiers,
especially when addressing high-stake decisions in medical imaging. Commonly
used post-hoc interpretability methods have the limitation that they can
produce plausible but different interpretations of a given model, leading to
ambiguity about which one to choose. To address this problem, a novel
decision-theory-inspired approach is investigated to establish a
self-interpretable model, given a pre-trained deep binary black-box medical
image classifier. This approach involves utilizing a self-interpretable
encoder-decoder model in conjunction with a single-layer fully connected
network with unity weights. The model is trained to estimate the test statistic
of the given trained black-box deep binary classifier to maintain a similar
accuracy. The decoder output image, referred to as an equivalency map, is an
image that represents a transformed version of the to-be-classified image that,
when processed by the fixed fully connected layer, produces the same test
statistic value as the original classifier. The equivalency map provides a
visualization of the transformed image features that directly contribute to the
test statistic value and, moreover, permits quantification of their relative
contributions. Unlike the traditional post-hoc interpretability methods, the
proposed method is self-interpretable, quantitative. Detailed quantitative and
qualitative analyses have been performed with three different medical image
binary classification tasks.

---------------

### 15 Nov 2022 | [A Fine-grained Interpretability Evaluation Benchmark for Neural NLP](https://arxiv.org/abs/2205.11097) | [⬇️](https://arxiv.org/pdf/2205.11097)
*Lijie Wang, Yaozong Shen, Shuyuan Peng, Shuai Zhang, Xinyan Xiao, Hao  Liu, Hongxuan Tang, Ying Chen, Hua Wu, Haifeng Wang* 

  While there is increasing concern about the interpretability of neural
models, the evaluation of interpretability remains an open problem, due to the
lack of proper evaluation datasets and metrics. In this paper, we present a
novel benchmark to evaluate the interpretability of both neural models and
saliency methods. This benchmark covers three representative NLP tasks:
sentiment analysis, textual similarity and reading comprehension, each provided
with both English and Chinese annotated data. In order to precisely evaluate
the interpretability, we provide token-level rationales that are carefully
annotated to be sufficient, compact and comprehensive. We also design a new
metric, i.e., the consistency between the rationales before and after
perturbations, to uniformly evaluate the interpretability on different types of
tasks. Based on this benchmark, we conduct experiments on three typical models
with three saliency methods, and unveil their strengths and weakness in terms
of interpretability. We will release this benchmark
https://www.luge.ai/#/luge/task/taskDetail?taskId=15 and hope it can facilitate
the research in building trustworthy systems.

---------------

### 19 Nov 2020 | [Learning Variational Word Masks to Improve the Interpretability of  Neural Text Classifiers](https://arxiv.org/abs/2010.00667) | [⬇️](https://arxiv.org/pdf/2010.00667)
*Hanjie Chen, Yangfeng Ji* 

  To build an interpretable neural text classifier, most of the prior work has
focused on designing inherently interpretable models or finding faithful
explanations. A new line of work on improving model interpretability has just
started, and many existing methods require either prior information or human
annotations as additional inputs in training. To address this limitation, we
propose the variational word mask (VMASK) method to automatically learn
task-specific important words and reduce irrelevant information on
classification, which ultimately improves the interpretability of model
predictions. The proposed method is evaluated with three neural text
classifiers (CNN, LSTM, and BERT) on seven benchmark text classification
datasets. Experiments show the effectiveness of VMASK in improving both model
prediction accuracy and interpretability.

---------------

### 19 Nov 2022 | [Decoupling Deep Learning for Interpretable Image Recognition](https://arxiv.org/abs/2210.08336) | [⬇️](https://arxiv.org/pdf/2210.08336)
*Yitao Peng, Yihang Liu, Longzhen Yang, Lianghua He* 

  The interpretability of neural networks has recently received extensive
attention. Previous prototype-based explainable networks involved prototype
activation in both reasoning and interpretation processes, requiring specific
explainable structures for the prototype, thus making the network less accurate
as it gains interpretability. Therefore, the decoupling prototypical network
(DProtoNet) was proposed to avoid this problem. This new model contains
encoder, inference, and interpretation modules. As regards the encoder module,
unrestricted feature masks were presented to generate expressive features and
prototypes. Regarding the inference module, a multi-image prototype learning
method was introduced to update prototypes so that the network can learn
generalized prototypes. Finally, concerning the interpretation module, a
multiple dynamic masks (MDM) decoder was suggested to explain the neural
network, which generates heatmaps using the consistent activation of the
original image and mask image at the detection nodes of the network. It
decouples the inference and interpretation modules of a prototype-based network
by avoiding the use of prototype activation to explain the network's decisions
in order to simultaneously improve the accuracy and interpretability of the
neural network. The multiple public general and medical datasets were tested,
and the results confirmed that our method could achieve a 5% improvement in
accuracy and state-of-the-art interpretability compared with previous methods.

---------------

### 08 Jun 2021 | [On the Lack of Robust Interpretability of Neural Text Classifiers](https://arxiv.org/abs/2106.04631) | [⬇️](https://arxiv.org/pdf/2106.04631)
*Muhammad Bilal Zafar, Michele Donini, Dylan Slack, C\'edric  Archambeau, Sanjiv Das, Krishnaram Kenthapadi* 

  With the ever-increasing complexity of neural language models, practitioners
have turned to methods for understanding the predictions of these models. One
of the most well-adopted approaches for model interpretability is feature-based
interpretability, i.e., ranking the features in terms of their impact on model
predictions. Several prior studies have focused on assessing the fidelity of
feature-based interpretability methods, i.e., measuring the impact of dropping
the top-ranked features on the model output. However, relatively little work
has been conducted on quantifying the robustness of interpretations. In this
work, we assess the robustness of interpretations of neural text classifiers,
specifically, those based on pretrained Transformer encoders, using two
randomization tests. The first compares the interpretations of two models that
are identical except for their initializations. The second measures whether the
interpretations differ between a model with trained parameters and a model with
random parameters. Both tests show surprising deviations from expected
behavior, raising questions about the extent of insights that practitioners may
draw from interpretations.

---------------

### 17 Nov 2023 | [SHAMSUL: Systematic Holistic Analysis to investigate Medical  Significance Utilizing Local interpretability methods in deep learning for  chest radiography pathology prediction](https://arxiv.org/abs/2307.08003) | [⬇️](https://arxiv.org/pdf/2307.08003)
*Mahbub Ul Alam, Jaakko Hollm\'en, J\'on R\'unar Baldvinsson, Rahim  Rahmani* 

  The interpretability of deep neural networks has become a subject of great
interest within the medical and healthcare domain. This attention stems from
concerns regarding transparency, legal and ethical considerations, and the
medical significance of predictions generated by these deep neural networks in
clinical decision support systems. To address this matter, our study delves
into the application of four well-established interpretability methods: Local
Interpretable Model-agnostic Explanations (LIME), Shapley Additive exPlanations
(SHAP), Gradient-weighted Class Activation Mapping (Grad-CAM), and Layer-wise
Relevance Propagation (LRP). Leveraging the approach of transfer learning with
a multi-label-multi-class chest radiography dataset, we aim to interpret
predictions pertaining to specific pathology classes. Our analysis encompasses
both single-label and multi-label predictions, providing a comprehensive and
unbiased assessment through quantitative and qualitative investigations, which
are compared against human expert annotation. Notably, Grad-CAM demonstrates
the most favorable performance in quantitative evaluation, while the LIME
heatmap score segmentation visualization exhibits the highest level of medical
significance. Our research underscores both the outcomes and the challenges
faced in the holistic approach adopted for assessing these interpretability
methods and suggests that a multimodal-based approach, incorporating diverse
sources of information beyond chest radiography images, could offer additional
insights for enhancing interpretability in the medical domain.

---------------

### 22 Oct 2020 | [Towards falsifiable interpretability research](https://arxiv.org/abs/2010.12016) | [⬇️](https://arxiv.org/pdf/2010.12016)
*Matthew L. Leavitt, Ari Morcos* 

  Methods for understanding the decisions of and mechanisms underlying deep
neural networks (DNNs) typically rely on building intuition by emphasizing
sensory or semantic features of individual examples. For instance, methods aim
to visualize the components of an input which are "important" to a network's
decision, or to measure the semantic properties of single neurons. Here, we
argue that interpretability research suffers from an over-reliance on
intuition-based approaches that risk-and in some cases have caused-illusory
progress and misleading conclusions. We identify a set of limitations that we
argue impede meaningful progress in interpretability research, and examine two
popular classes of interpretability methods-saliency and single-neuron-based
approaches-that serve as case studies for how overreliance on intuition and
lack of falsifiability can undermine interpretability research. To address
these concerns, we propose a strategy to address these impediments in the form
of a framework for strongly falsifiable interpretability research. We encourage
researchers to use their intuitions as a starting point to develop and test
clear, falsifiable hypotheses, and hope that our framework yields robust,
evidence-based interpretability methods that generate meaningful advances in
our understanding of DNNs.

---------------

### 12 Sep 2023 | [Fidelity of Interpretability Methods and Perturbation Artifacts in  Neural Networks](https://arxiv.org/abs/2203.02928) | [⬇️](https://arxiv.org/pdf/2203.02928)
*Lennart Brocki, Neo Christopher Chung* 

  Despite excellent performance of deep neural networks (DNNs) in image
classification, detection, and prediction, characterizing how DNNs make a given
decision remains an open problem, resulting in a number of interpretability
methods. Post-hoc interpretability methods primarily aim to quantify the
importance of input features with respect to the class probabilities. However,
due to the lack of ground truth and the existence of interpretability methods
with diverse operating characteristics, evaluating these methods is a crucial
challenge. A popular approach to evaluate interpretability methods is to
perturb input features deemed important for a given prediction and observe the
decrease in accuracy. However, perturbation itself may introduce artifacts. We
propose a method for estimating the impact of such artifacts on the fidelity
estimation by utilizing model accuracy curves from perturbing input features
according to the Most Import First (MIF) and Least Import First (LIF) orders.
Using the ResNet-50 trained on the ImageNet, we demonstrate the proposed
fidelity estimation of four popular post-hoc interpretability methods.

---------------

### 12 May 2023 | [Overlooked factors in concept-based explanations: Dataset choice,  concept learnability, and human capability](https://arxiv.org/abs/2207.09615) | [⬇️](https://arxiv.org/pdf/2207.09615)
*Vikram V. Ramaswamy, Sunnie S. Y. Kim, Ruth Fong and Olga Russakovsky* 

  Concept-based interpretability methods aim to explain deep neural network
model predictions using a predefined set of semantic concepts. These methods
evaluate a trained model on a new, "probe" dataset and correlate model
predictions with the visual concepts labeled in that dataset. Despite their
popularity, they suffer from limitations that are not well-understood and
articulated by the literature. In this work, we analyze three commonly
overlooked factors in concept-based explanations. First, the choice of the
probe dataset has a profound impact on the generated explanations. Our analysis
reveals that different probe datasets may lead to very different explanations,
and suggests that the explanations are not generalizable outside the probe
dataset. Second, we find that concepts in the probe dataset are often less
salient and harder to learn than the classes they claim to explain, calling
into question the correctness of the explanations. We argue that only visually
salient concepts should be used in concept-based explanations. Finally, while
existing methods use hundreds or even thousands of concepts, our human studies
reveal a much stricter upper bound of 32 concepts or less, beyond which the
explanations are much less practically useful. We make suggestions for future
development and analysis of concept-based interpretability methods. Code for
our analysis and user interface can be found at
\url{https://github.com/princetonvisualai/OverlookedFactors}

---------------
**Date:** 16 Jun 2022

**Title:** Geometrically Guided Integrated Gradients

**Abstract Link:** [https://arxiv.org/abs/2206.05903](https://arxiv.org/abs/2206.05903)

**PDF Link:** [https://arxiv.org/pdf/2206.05903](https://arxiv.org/pdf/2206.05903)

---

**Date:** 16 Oct 2020

**Title:** Evaluating Attribution Methods using White-Box LSTMs

**Abstract Link:** [https://arxiv.org/abs/2010.08606](https://arxiv.org/abs/2010.08606)

**PDF Link:** [https://arxiv.org/pdf/2010.08606](https://arxiv.org/pdf/2010.08606)

---

**Date:** 26 Feb 2021

**Title:** Layer-Wise Interpretation of Deep Neural Networks Using Identity  Initialization

**Abstract Link:** [https://arxiv.org/abs/2102.13333](https://arxiv.org/abs/2102.13333)

**PDF Link:** [https://arxiv.org/pdf/2102.13333](https://arxiv.org/pdf/2102.13333)

---

**Date:** 15 Nov 2019

**Title:** Explanatory Masks for Neural Network Interpretability

**Abstract Link:** [https://arxiv.org/abs/1911.06876](https://arxiv.org/abs/1911.06876)

**PDF Link:** [https://arxiv.org/pdf/1911.06876](https://arxiv.org/pdf/1911.06876)

---

**Date:** 22 Aug 2023

**Title:** Explicability and Inexplicability in the Interpretation of Quantum  Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2308.11098](https://arxiv.org/abs/2308.11098)

**PDF Link:** [https://arxiv.org/pdf/2308.11098](https://arxiv.org/pdf/2308.11098)

---

**Date:** 04 Dec 2023

**Title:** Class-Discriminative Attention Maps for Vision Transformers

**Abstract Link:** [https://arxiv.org/abs/2312.02364](https://arxiv.org/abs/2312.02364)

**PDF Link:** [https://arxiv.org/pdf/2312.02364](https://arxiv.org/pdf/2312.02364)

---

**Date:** 05 Oct 2023

**Title:** Evaluating the Robustness of Interpretability Methods through  Explanation Invariance and Equivariance

**Abstract Link:** [https://arxiv.org/abs/2304.06715](https://arxiv.org/abs/2304.06715)

**PDF Link:** [https://arxiv.org/pdf/2304.06715](https://arxiv.org/pdf/2304.06715)

---

**Date:** 20 Jun 2023

**Title:** Causal Analysis for Robust Interpretability of Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2305.08950](https://arxiv.org/abs/2305.08950)

**PDF Link:** [https://arxiv.org/pdf/2305.08950](https://arxiv.org/pdf/2305.08950)

---

**Date:** 27 Aug 2023

**Title:** Towards Vision-Language Mechanistic Interpretability: A Causal Tracing  Tool for BLIP

**Abstract Link:** [https://arxiv.org/abs/2308.14179](https://arxiv.org/abs/2308.14179)

**PDF Link:** [https://arxiv.org/pdf/2308.14179](https://arxiv.org/pdf/2308.14179)

---

**Date:** 28 Sep 2021

**Title:** Discriminative Attribution from Counterfactuals

**Abstract Link:** [https://arxiv.org/abs/2109.13412](https://arxiv.org/abs/2109.13412)

**PDF Link:** [https://arxiv.org/pdf/2109.13412](https://arxiv.org/pdf/2109.13412)

---

**Date:** 27 May 2022

**Title:** TimeREISE: Time-series Randomized Evolving Input Sample Explanation

**Abstract Link:** [https://arxiv.org/abs/2202.07952](https://arxiv.org/abs/2202.07952)

**PDF Link:** [https://arxiv.org/pdf/2202.07952](https://arxiv.org/pdf/2202.07952)

---

**Date:** 02 Jan 2024

**Title:** A Test Statistic Estimation-based Approach for Establishing  Self-interpretable CNN-based Binary Classifiers

**Abstract Link:** [https://arxiv.org/abs/2303.06876](https://arxiv.org/abs/2303.06876)

**PDF Link:** [https://arxiv.org/pdf/2303.06876](https://arxiv.org/pdf/2303.06876)

---

**Date:** 15 Nov 2022

**Title:** A Fine-grained Interpretability Evaluation Benchmark for Neural NLP

**Abstract Link:** [https://arxiv.org/abs/2205.11097](https://arxiv.org/abs/2205.11097)

**PDF Link:** [https://arxiv.org/pdf/2205.11097](https://arxiv.org/pdf/2205.11097)

---

**Date:** 19 Nov 2020

**Title:** Learning Variational Word Masks to Improve the Interpretability of  Neural Text Classifiers

**Abstract Link:** [https://arxiv.org/abs/2010.00667](https://arxiv.org/abs/2010.00667)

**PDF Link:** [https://arxiv.org/pdf/2010.00667](https://arxiv.org/pdf/2010.00667)

---

**Date:** 19 Nov 2022

**Title:** Decoupling Deep Learning for Interpretable Image Recognition

**Abstract Link:** [https://arxiv.org/abs/2210.08336](https://arxiv.org/abs/2210.08336)

**PDF Link:** [https://arxiv.org/pdf/2210.08336](https://arxiv.org/pdf/2210.08336)

---

**Date:** 08 Jun 2021

**Title:** On the Lack of Robust Interpretability of Neural Text Classifiers

**Abstract Link:** [https://arxiv.org/abs/2106.04631](https://arxiv.org/abs/2106.04631)

**PDF Link:** [https://arxiv.org/pdf/2106.04631](https://arxiv.org/pdf/2106.04631)

---

**Date:** 17 Nov 2023

**Title:** SHAMSUL: Systematic Holistic Analysis to investigate Medical  Significance Utilizing Local interpretability methods in deep learning for  chest radiography pathology prediction

**Abstract Link:** [https://arxiv.org/abs/2307.08003](https://arxiv.org/abs/2307.08003)

**PDF Link:** [https://arxiv.org/pdf/2307.08003](https://arxiv.org/pdf/2307.08003)

---

**Date:** 22 Oct 2020

**Title:** Towards falsifiable interpretability research

**Abstract Link:** [https://arxiv.org/abs/2010.12016](https://arxiv.org/abs/2010.12016)

**PDF Link:** [https://arxiv.org/pdf/2010.12016](https://arxiv.org/pdf/2010.12016)

---

**Date:** 12 Sep 2023

**Title:** Fidelity of Interpretability Methods and Perturbation Artifacts in  Neural Networks

**Abstract Link:** [https://arxiv.org/abs/2203.02928](https://arxiv.org/abs/2203.02928)

**PDF Link:** [https://arxiv.org/pdf/2203.02928](https://arxiv.org/pdf/2203.02928)

---

**Date:** 12 May 2023

**Title:** Overlooked factors in concept-based explanations: Dataset choice,  concept learnability, and human capability

**Abstract Link:** [https://arxiv.org/abs/2207.09615](https://arxiv.org/abs/2207.09615)

**PDF Link:** [https://arxiv.org/pdf/2207.09615](https://arxiv.org/pdf/2207.09615)

---

