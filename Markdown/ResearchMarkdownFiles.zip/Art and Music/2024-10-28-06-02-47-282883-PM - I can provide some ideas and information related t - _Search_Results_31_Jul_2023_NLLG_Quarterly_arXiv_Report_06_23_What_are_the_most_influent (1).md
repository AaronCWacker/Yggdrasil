I can provide some ideas and information related to your request without reproducing copyrighted works.

Top 10 Most Popular National Parks (according to National Park Service visitor statistics):

1. Great Smoky Mountains National Park
2. Grand Canyon National Park
3. Rocky Mountain National Park
4. Zion National Park
5. Yellowstone National Park
6. Yosemite National Park
7. Acadia National Park
8. Grand Teton National Park
9. Olympic National Park
10. Glacier National Park

Top 10 AI Inventors and Notable Papers:

1. Geoffrey Hinton (Co-author of "Reducing the Dimensionality of Data with Neural Networks")
2. Yoshua Bengio (Co-author of "A Neural Probabilistic Language Model")
3. Yann LeCun (Co-author of "Gradient-Based Learning Applied to Document Recognition")
4. Demis Hassabis (Co-author of "Neuroscience-Inspired Artificial Intelligence")
5. Jürgen Schmidhuber (Author of "Deep Learning in Neural Networks: An Overview")
6. Ian Goodfellow (Co-author of "Generative Adversarial Networks")
7. Yann LeCun (Co-author of "Handwritten Digit Recognition with a Back-Propagation Network")
8. Yoshua Bengio (Co-author of "Representation Learning: A Review and New Perspectives")
9. Andrew Ng (Co-author of "Sparse Autoencoder")
10. Geoffrey Hinton (Co-author of "Improving neural networks by preventing co-adaptation of feature detectors")

With these ideas and information, you could potentially create lyrics or a theme for a techno trance industrial song that incorporates references to these national parks and AI inventors/papers.

# 🩺🔍 Search Results
### 31 Jul 2023 | [NLLG Quarterly arXiv Report 06/23: What are the most influential current  AI Papers?](https://arxiv.org/abs/2308.04889) | [⬇️](https://arxiv.org/pdf/2308.04889)
*Steffen Eger and Christoph Leiter and Jonas Belouadi and Ran Zhang and  Aida Kostikova and Daniil Larionov and Yanran Chen and Vivian Fresen* 

  The rapid growth of information in the field of Generative Artificial
Intelligence (AI), particularly in the subfields of Natural Language Processing
(NLP) and Machine Learning (ML), presents a significant challenge for
researchers and practitioners to keep pace with the latest developments. To
address the problem of information overload, this report by the Natural
Language Learning Group at Bielefeld University focuses on identifying the most
popular papers on arXiv, with a specific emphasis on NLP and ML. The objective
is to offer a quick guide to the most relevant and widely discussed research,
aiding both newcomers and established researchers in staying abreast of current
trends. In particular, we compile a list of the 40 most popular papers based on
normalized citation counts from the first half of 2023. We observe the
dominance of papers related to Large Language Models (LLMs) and specifically
ChatGPT during the first half of 2023, with the latter showing signs of
declining popularity more recently, however. Further, NLP related papers are
the most influential (around 60\% of top papers) even though there are twice as
many ML related papers in our data. Core issues investigated in the most
heavily cited papers are: LLM efficiency, evaluation techniques, ethical
considerations, embodied agents, and problem-solving with LLMs. Additionally,
we examine the characteristics of top papers in comparison to others outside
the top-40 list (noticing the top paper's focus on LLM related issues and
higher number of co-authors) and analyze the citation distributions in our
dataset, among others.

---------------

### 05 Dec 2022 | [MapInWild: A Remote Sensing Dataset to Address the Question What Makes  Nature Wild](https://arxiv.org/abs/2212.02265) | [⬇️](https://arxiv.org/pdf/2212.02265)
*Burak Ekim, Timo T. Stomberg, Ribana Roscher, Michael Schmitt* 

  Antrophonegic pressure (i.e. human influence) on the environment is one of
the largest causes of the loss of biological diversity. Wilderness areas, in
contrast, are home to undisturbed ecological processes. However, there is no
biophysical definition of the term wilderness. Instead, wilderness is more of a
philosophical or cultural concept and thus cannot be easily delineated or
categorized in a technical manner. With this paper, (i) we introduce the task
of wilderness mapping by means of machine learning applied to satellite imagery
(ii) and publish MapInWild, a large-scale benchmark dataset curated for that
task. MapInWild is a multi-modal dataset and comprises various geodata acquired
and formed from a diverse set of Earth observation sensors. The dataset
consists of 8144 images with a shape of 1920 x 1920 pixels and is approximately
350 GB in size. The images are weakly annotated with three classes derived from
the World Database of Protected Areas - Strict Nature Reserves, Wilderness
Areas, and National Parks. With the dataset, which shall serve as a testbed for
developments in fields such as explainable machine learning and environmental
remote sensing, we hope to contribute to a deepening of our understanding of
the question "What makes nature wild?".

---------------

### 22 Dec 2020 | [Limitations of Deep Neural Networks: a discussion of G. Marcus' critical  appraisal of deep learning](https://arxiv.org/abs/2012.15754) | [⬇️](https://arxiv.org/pdf/2012.15754)
*Stefanos Tsimenidis* 

  Deep neural networks have triggered a revolution in artificial intelligence,
having been applied with great results in medical imaging, semi-autonomous
vehicles, ecommerce, genetics research, speech recognition, particle physics,
experimental art, economic forecasting, environmental science, industrial
manufacturing, and a wide variety of applications in nearly every field. This
sudden success, though, may have intoxicated the research community and blinded
them to the potential pitfalls of assigning deep learning a higher status than
warranted. Also, research directed at alleviating the weaknesses of deep
learning may seem less attractive to scientists and engineers, who focus on the
low-hanging fruit of finding more and more applications for deep learning
models, thus letting short-term benefits hamper long-term scientific progress.
Gary Marcus wrote a paper entitled Deep Learning: A Critical Appraisal, and
here we discuss Marcus' core ideas, as well as attempt a general assessment of
the subject. This study examines some of the limitations of deep neural
networks, with the intention of pointing towards potential paths for future
research, and of clearing up some metaphysical misconceptions, held by numerous
researchers, that may misdirect them.

---------------

### 04 Jul 2023 | [A Bibliographic Study on Artificial Intelligence Research: Global  Panorama and Indian Appearance](https://arxiv.org/abs/2308.00705) | [⬇️](https://arxiv.org/pdf/2308.00705)
*Amit Tiwari, Susmita Bardhan, Vikas Kumar* 

  The present study identifies and assesses the bibliographic trend in
Artificial Intelligence (AI) research for the years 2015-2020 using the science
mapping method of bibliometric study. The required data has been collected from
the Scopus database. To make the collected data analysis-ready, essential data
transformation was performed manually and with the help of a tool viz.
OpenRefine. For determining the trend and performing the mapping techniques,
top five open access and commercial journals of AI have been chosen based on
their citescore driven ranking. The work includes 6880 articles published in
the specified period for analysis. The trend is based on Country-wise
publications, year-wise publications, topical terms in AI, top-cited articles,
prominent authors, major institutions, involvement of industries in AI and
Indian appearance. The results show that compared to open access journals;
commercial journals have a higher citescore and number of articles published
over the years. Additionally, IEEE is the prominent publisher which publishes
84% of the top-cited publications. Further, China and the United States are the
major contributors to literature in the AI domain. The study reveals that
neural networks and deep learning are the major topics included in top AI
research publications. Recently, not only public institutions but also private
bodies are investing their resources in AI research. The study also
investigates the relative position of Indian researchers in terms of AI
research. Present work helps in understanding the initial development, current
stand and future direction of AI.

---------------

### 16 Feb 2021 | [Twin Augmented Architectures for Robust Classification of COVID-19 Chest  X-Ray Images](https://arxiv.org/abs/2102.07975) | [⬇️](https://arxiv.org/pdf/2102.07975)
*Kartikeya Badola, Sameer Ambekar, Himanshu Pant, Sumit Soman, Anuradha  Sural, Rajiv Narang, Suresh Chandra and Jayadeva* 

  The gold standard for COVID-19 is RT-PCR, testing facilities for which are
limited and not always optimally distributed. Test results are delayed, which
impacts treatment. Expert radiologists, one of whom is a co-author, are able to
diagnose COVID-19 positivity from Chest X-Rays (CXR) and CT scans, that can
facilitate timely treatment. Such diagnosis is particularly valuable in
locations lacking radiologists with sufficient expertise and familiarity with
COVID-19 patients. This paper has two contributions. One, we analyse literature
on CXR based COVID-19 diagnosis. We show that popular choices of dataset
selection suffer from data homogeneity, leading to misleading results. We
compile and analyse a viable benchmark dataset from multiple existing
heterogeneous sources. Such a benchmark is important for realistically testing
models. Our second contribution relates to learning from imbalanced data.
Datasets for COVID X-Ray classification face severe class imbalance, since most
subjects are COVID -ve. Twin Support Vector Machines (Twin SVM) and Twin Neural
Networks (Twin NN) have, in recent years, emerged as effective ways of handling
skewed data. We introduce a state-of-the-art technique, termed as Twin
Augmentation, for modifying popular pre-trained deep learning models. Twin
Augmentation boosts the performance of a pre-trained deep neural network
without requiring re-training. Experiments show, that across a multitude of
classifiers, Twin Augmentation is very effective in boosting the performance of
given pre-trained model for classification in imbalanced settings.

---------------

### 07 Nov 2019 | [How to Prove Your Model Belongs to You: A Blind-Watermark based  Framework to Protect Intellectual Property of DNN](https://arxiv.org/abs/1903.01743) | [⬇️](https://arxiv.org/pdf/1903.01743)
*Zheng Li, Chengyu Hu, Yang Zhang, Shanqing Guo* 

  Deep learning techniques have made tremendous progress in a variety of
challenging tasks, such as image recognition and machine translation, during
the past decade. Training deep neural networks is computationally expensive and
requires both human and intellectual resources. Therefore, it is necessary to
protect the intellectual property of the model and externally verify the
ownership of the model. However, previous studies either fail to defend against
the evasion attack or have not explicitly dealt with fraudulent claims of
ownership by adversaries. Furthermore, they can not establish a clear
association between the model and the creator's identity.
  To fill these gaps, in this paper, we propose a novel intellectual property
protection (IPP) framework based on blind-watermark for watermarking deep
neural networks that meet the requirements of security and feasibility. Our
framework accepts ordinary samples and the exclusive logo as inputs, outputting
newly generated samples as watermarks, which are almost indistinguishable from
the origin, and infuses these watermarks into DNN models by assigning specific
labels, leaving the backdoor as the basis for our copyright claim. We evaluated
our IPP framework on two benchmark datasets and 15 popular deep learning
models. The results show that our framework successfully verifies the ownership
of all the models without a noticeable impact on their primary task. Most
importantly, we are the first to successfully design and implement a
blind-watermark based framework, which can achieve state-of-art performances on
undetectability against evasion attack and unforgeability against fraudulent
claims of ownership. Further, our framework shows remarkable robustness and
establishes a clear association between the model and the author's identity.

---------------

### 28 Feb 2019 | [Deep learning in bioinformatics: introduction, application, and  perspective in big data era](https://arxiv.org/abs/1903.00342) | [⬇️](https://arxiv.org/pdf/1903.00342)
*Yu Li, Chao Huang, Lizhong Ding, Zhongxiao Li, Yijie Pan, Xin Gao* 

  Deep learning, which is especially formidable in handling big data, has
achieved great success in various fields, including bioinformatics. With the
advances of the big data era in biology, it is foreseeable that deep learning
will become increasingly important in the field and will be incorporated in
vast majorities of analysis pipelines. In this review, we provide both the
exoteric introduction of deep learning, and concrete examples and
implementations of its representative applications in bioinformatics. We start
from the recent achievements of deep learning in the bioinformatics field,
pointing out the problems which are suitable to use deep learning. After that,
we introduce deep learning in an easy-to-understand fashion, from shallow
neural networks to legendary convolutional neural networks, legendary recurrent
neural networks, graph neural networks, generative adversarial networks,
variational autoencoder, and the most recent state-of-the-art architectures.
After that, we provide eight examples, covering five bioinformatics research
directions and all the four kinds of data type, with the implementation written
in Tensorflow and Keras. Finally, we discuss the common issues, such as
overfitting and interpretability, that users will encounter when adopting deep
learning methods and provide corresponding suggestions. The implementations are
freely available at \url{https://github.com/lykaust15/Deep_learning_examples}.

---------------

### 04 Jul 2020 | [Autonomous Driving with Deep Learning: A Survey of State-of-Art  Technologies](https://arxiv.org/abs/2006.06091) | [⬇️](https://arxiv.org/pdf/2006.06091)
*Yu Huang and Yue Chen* 

  Since DARPA Grand Challenges (rural) in 2004/05 and Urban Challenges in 2007,
autonomous driving has been the most active field of AI applications. Almost at
the same time, deep learning has made breakthrough by several pioneers, three
of them (also called fathers of deep learning), Hinton, Bengio and LeCun, won
ACM Turin Award in 2019. This is a survey of autonomous driving technologies
with deep learning methods. We investigate the major fields of self-driving
systems, such as perception, mapping and localization, prediction, planning and
control, simulation, V2X and safety etc. Due to the limited space, we focus the
analysis on several key areas, i.e. 2D and 3D object detection in perception,
depth estimation from cameras, multiple sensor fusion on the data, feature and
task level respectively, behavior modelling and prediction of vehicle driving
and pedestrian trajectories.

---------------

### 14 Oct 2023 | [Neuronal Auditory Machine Intelligence (NEURO-AMI) In Perspective](https://arxiv.org/abs/2401.02421) | [⬇️](https://arxiv.org/pdf/2401.02421)
*Emmanuel Ndidi Osegi* 

  The recent developments in soft computing cannot be complete without noting
the contributions of artificial neural machine learning systems that draw
inspiration from real cortical tissue or processes that occur in human brain.
The universal approximability of such neural systems has led to its wide spread
use, and novel developments in this evolving technology has shown that there is
a bright future for such Artificial Intelligent (AI) techniques in the soft
computing field. Indeed, the proliferation of large and very deep networks of
artificial neural systems and the corresponding enhancement and development of
neural machine learning algorithms have contributed immensely to the
development of the modern field of Deep Learning as may be found in the well
documented research works of Lecun, Bengio and Hinton. However, the key
requirements of end user affordability in addition to reduced complexity and
reduced data learning size requirement means there still remains a need for the
synthesis of more cost-efficient and less data-hungry artificial neural
systems. In this report, we present an overview of a new competing bio-inspired
continual learning neural tool Neuronal Auditory Machine Intelligence
(Neuro-AMI) as a predictor detailing its functional and structural details,
important aspects on right applicability, some recent application use cases and
future research directions for current and prospective machine learning experts
and data scientists.

---------------

### 03 Sep 2020 | [Computational Analysis of Deformable Manifolds: from Geometric Modelling  to Deep Learning](https://arxiv.org/abs/2009.01786) | [⬇️](https://arxiv.org/pdf/2009.01786)
*Stefan C Schonsheck* 

  Leo Tolstoy opened his monumental novel Anna Karenina with the now famous
words: Happy families are all alike; every unhappy family is unhappy in its own
way A similar notion also applies to mathematical spaces: Every flat space is
alike; every unflat space is unflat in its own way. However, rather than being
a source of unhappiness, we will show that the diversity of non-flat spaces
provides a rich area of study. The genesis of the so-called big data era and
the proliferation of social and scientific databases of increasing size has led
to a need for algorithms that can efficiently process, analyze and, even
generate high dimensional data. However, the curse of dimensionality leads to
the fact that many classical approaches do not scale well with respect to the
size of these problems. One technique to avoid some of these ill-effects is to
exploit the geometric structure of coherent data. In this thesis, we will
explore geometric methods for shape processing and data analysis. More
specifically, we will study techniques for representing manifolds and signals
supported on them through a variety of mathematical tools including, but not
limited to, computational differential geometry, variational PDE modeling, and
deep learning. First, we will explore non-isometric shape matching through
variational modeling. Next, we will use ideas from parallel transport on
manifolds to generalize convolution and convolutional neural networks to
deformable manifolds. Finally, we conclude by proposing a novel auto-regressive
model for capturing the intrinsic geometry and topology of data. Throughout
this work, we will use the idea of computing correspondences as a though-line
to both motivate our work and analyze our results.

---------------

### 19 Sep 2022 | [Mapping the Structure and Evolution of Software Testing Research Over  the Past Three Decades](https://arxiv.org/abs/2109.04086) | [⬇️](https://arxiv.org/pdf/2109.04086)
*Alireza Salahirad, Gregory Gay, Ehsan Mohammadi* 

  Background: The field of software testing is growing and rapidly-evolving.
  Aims: Based on keywords assigned to publications, we seek to identify
predominant research topics and understand how they are connected and have
evolved.
  Method: We apply co-word analysis to map the topology of testing research as
a network where author-assigned keywords are connected by edges indicating
co-occurrence in publications. Keywords are clustered based on edge density and
frequency of connection. We examine the most popular keywords, summarize
clusters into high-level research topics, examine how topics connect, and
examine how the field is changing.
  Results: Testing research can be divided into 16 high-level topics and 18
subtopics. Creation guidance, automated test generation, evolution and
maintenance, and test oracles have particularly strong connections to other
topics, highlighting their multidisciplinary nature. Emerging keywords relate
to web and mobile apps, machine learning, energy consumption, automated program
repair and test generation, while emerging connections have formed between web
apps, test oracles, and machine learning with many topics. Random and
requirements-based testing show potential decline.
  Conclusions: Our observations, advice, and map data offer a deeper
understanding of the field and inspiration regarding challenges and connections
to explore.

---------------

### 27 Nov 2007 | [Knowware: the third star after Hardware and Software](https://arxiv.org/abs/0711.4309) | [⬇️](https://arxiv.org/pdf/0711.4309)
*Ruqian Lu* 

  This book proposes to separate knowledge from software and to make it a
commodity that is called knowware. The architecture, representation and
function of Knowware are discussed. The principles of knowware engineering and
its three life cycle models: furnace model, crystallization model and spiral
model are proposed and analyzed. Techniques of software/knowware co-engineering
are introduced. A software component whose knowledge is replaced by knowware is
called mixware. An object and component oriented development schema of mixware
is introduced. In particular, the tower model and ladder model for mixware
development are proposed and discussed. Finally, knowledge service and knowware
based Web service are introduced and compared with Web service. In summary,
knowware, software and hardware should be considered as three equally important
underpinnings of IT industry.
  Ruqian Lu is a professor of computer science of the Institute of Mathematics,
Academy of Mathematics and System Sciences. He is a fellow of Chinese Academy
of Sciences. His research interests include artificial intelligence, knowledge
engineering and knowledge based software engineering. He has published more
than 100 papers and 10 books. He has won two first class awards from the
Academia Sinica and a National second class prize from the Ministry of Science
and Technology. He has also won the sixth Hua Loo-keng Mathematics Prize.

---------------

### 03 Jan 2022 | [Graph Neural Networks: a bibliometrics overview](https://arxiv.org/abs/2201.01188) | [⬇️](https://arxiv.org/pdf/2201.01188)
*Abdalsamad Keramatfar, Mohadeseh Rafiee, Hossein Amirkhani* 

  Recently, graph neural networks have become a hot topic in machine learning
community. This paper presents a Scopus based bibliometric overview of the GNNs
research since 2004, when GNN papers were first published. The study aims to
evaluate GNN research trend, both quantitatively and qualitatively. We provide
the trend of research, distribution of subjects, active and influential authors
and institutions, sources of publications, most cited documents, and hot
topics. Our investigations reveal that the most frequent subject categories in
this field are computer science, engineering, telecommunications, linguistics,
operations research and management science, information science and library
science, business and economics, automation and control systems, robotics, and
social sciences. In addition, the most active source of GNN publications is
Lecture Notes in Computer Science. The most prolific or impactful institutions
are found in the United States, China, and Canada. We also provide must read
papers and future directions. Finally, the application of graph convolutional
networks and attention mechanism are now among hot topics of GNN research.

---------------

### 01 Aug 2023 | [Challenging the Myth of Graph Collaborative Filtering: a Reasoned and  Reproducibility-driven Analysis](https://arxiv.org/abs/2308.00404) | [⬇️](https://arxiv.org/pdf/2308.00404)
*Vito Walter Anelli, Daniele Malitesta, Claudio Pomo, Alejandro  Bellog\'in, Tommaso Di Noia, Eugenio Di Sciascio* 

  The success of graph neural network-based models (GNNs) has significantly
advanced recommender systems by effectively modeling users and items as a
bipartite, undirected graph. However, many original graph-based works often
adopt results from baseline papers without verifying their validity for the
specific configuration under analysis. Our work addresses this issue by
focusing on the replicability of results. We present a code that successfully
replicates results from six popular and recent graph recommendation models
(NGCF, DGCF, LightGCN, SGL, UltraGCN, and GFCF) on three common benchmark
datasets (Gowalla, Yelp 2018, and Amazon Book). Additionally, we compare these
graph models with traditional collaborative filtering models that historically
performed well in offline evaluations. Furthermore, we extend our study to two
new datasets (Allrecipes and BookCrossing) that lack established setups in
existing literature. As the performance on these datasets differs from the
previous benchmarks, we analyze the impact of specific dataset characteristics
on recommendation accuracy. By investigating the information flow from users'
neighborhoods, we aim to identify which models are influenced by intrinsic
features in the dataset structure. The code to reproduce our experiments is
available at: https://github.com/sisinflab/Graph-RSs-Reproducibility.

---------------

### 02 Jan 2018 | [Deep Learning: A Critical Appraisal](https://arxiv.org/abs/1801.00631) | [⬇️](https://arxiv.org/pdf/1801.00631)
*Gary Marcus* 

  Although deep learning has historical roots going back decades, neither the
term "deep learning" nor the approach was popular just over five years ago,
when the field was reignited by papers such as Krizhevsky, Sutskever and
Hinton's now classic (2012) deep network model of Imagenet. What has the field
discovered in the five subsequent years? Against a background of considerable
progress in areas such as speech recognition, image recognition, and game
playing, and considerable enthusiasm in the popular press, I present ten
concerns for deep learning, and suggest that deep learning must be supplemented
by other techniques if we are to reach artificial general intelligence.

---------------

### 09 Nov 2023 | [Rethinking Residual Connection in Training Large-Scale Spiking Neural  Networks](https://arxiv.org/abs/2311.05171) | [⬇️](https://arxiv.org/pdf/2311.05171)
*Yudong Li, Yunlin Lei, Xu Yang* 

  Spiking Neural Network (SNN) is known as the most famous brain-inspired
model, but the non-differentiable spiking mechanism makes it hard to train
large-scale SNNs. To facilitate the training of large-scale SNNs, many training
methods are borrowed from Artificial Neural Networks (ANNs), among which deep
residual learning is the most commonly used. But the unique features of SNNs
make prior intuition built upon ANNs not available for SNNs. Although there are
a few studies that have made some pioneer attempts on the topology of Spiking
ResNet, the advantages of different connections remain unclear. To tackle this
issue, we analyze the merits and limitations of various residual connections
and empirically demonstrate our ideas with extensive experiments. Then, based
on our observations, we abstract the best-performing connections into densely
additive (DA) connection, extend such a concept to other topologies, and
propose four architectures for training large-scale SNNs, termed DANet, which
brings up to 13.24% accuracy gain on ImageNet. Besides, in order to present a
detailed methodology for designing the topology of large-scale SNNs, we further
conduct in-depth discussions on their applicable scenarios in terms of their
performance on various scales of datasets and demonstrate their advantages over
prior architectures. At a low training expense, our best-performing
ResNet-50/101/152 obtain 73.71%/76.13%/77.22% top-1 accuracy on ImageNet with 4
time steps. We believe that this work shall give more insights for future works
to design the topology of their networks and promote the development of
large-scale SNNs. The code will be publicly available.

---------------

### 17 Feb 2022 | [A Fair Comparison of Graph Neural Networks for Graph Classification](https://arxiv.org/abs/1912.09893) | [⬇️](https://arxiv.org/pdf/1912.09893)
*Federico Errica, Marco Podda, Davide Bacciu, Alessio Micheli* 

  Experimental reproducibility and replicability are critical topics in machine
learning. Authors have often raised concerns about their lack in scientific
publications to improve the quality of the field. Recently, the graph
representation learning field has attracted the attention of a wide research
community, which resulted in a large stream of works. As such, several Graph
Neural Network models have been developed to effectively tackle graph
classification. However, experimental procedures often lack rigorousness and
are hardly reproducible. Motivated by this, we provide an overview of common
practices that should be avoided to fairly compare with the state of the art.
To counter this troubling trend, we ran more than 47000 experiments in a
controlled and uniform framework to re-evaluate five popular models across nine
common benchmarks. Moreover, by comparing GNNs with structure-agnostic
baselines we provide convincing evidence that, on some datasets, structural
information has not been exploited yet. We believe that this work can
contribute to the development of the graph learning field, by providing a much
needed grounding for rigorous evaluations of graph classification models.

---------------

### 12 Dec 2023 | [Intelligence Primer](https://arxiv.org/abs/2008.07324) | [⬇️](https://arxiv.org/pdf/2008.07324)
*Karl Fezer and Andrew Sloss* 

  Intelligence is a fundamental part of all living things, as well as the
foundation for Artificial Intelligence. In this primer we explore the ideas
associated with intelligence and, by doing so, understand the implications and
constraints and potentially outline the capabilities of future systems.
Artificial Intelligence, in the form of Machine Learning, has already had a
significant impact on our lives. As an exploration, we journey into different
parts of intelligence that appear essential. We hope that people find this
helpful in determining the future. Also, during the exploration, we hope to
create new thought-provoking questions. Intelligence is not a single weighable
quantity but a subject that spans Biology, Physics, Philosophy, Cognitive
Science, Neuroscience, Psychology, and Computer Science. The historian Yuval
Noah Harari pointed out that engineers and scientists in the future will have
to broaden their understandings to include disciplines such as Psychology,
Philosophy, and Ethics. Fiction writers have long portrayed engineers and
scientists as deficient in these areas. Today, in modern society, the emergence
of Artificial Intelligence and legal requirements act as forcing functions to
push these broader subjects into the foreground. We start with an introduction
to intelligence and move quickly to more profound thoughts and ideas. We call
this a Life, the Universe, and Everything primer, after the famous science
fiction book by Douglas Adams. Forty-two may be the correct answer, but what
are the questions?

---------------

### 26 Sep 2019 | [Admiring the Great Mountain: A Celebration Special Issue in Honor of  Stephen Grossbergs 80th Birthday](https://arxiv.org/abs/1910.13351) | [⬇️](https://arxiv.org/pdf/1910.13351)
*Donald C. Wunsch* 

  This editorial summarizes selected key contributions of Prof. Stephen
Grossberg and describes the papers in this 80th birthday special issue in his
honor. His productivity, creativity, and vision would each be enough to mark a
scientist of the first caliber. In combination, they have resulted in
contributions that have changed the entire discipline of neural networks.
Grossberg has been tremendously influential in engineering, dynamical systems,
and artificial intelligence as well. Indeed, he has been one of the most
important mentors and role models in my career, and has done so with
extraordinary generosity and encouragement. All authors in this special issue
have taken great pleasure in hereby commemorating his extraordinary career and
contributions.

---------------

### 27 Mar 2013 | [Shootout-89: A Comparative Evaluation of Knowledge-based Systems that  Forecast Severe Weather](https://arxiv.org/abs/1304.1520) | [⬇️](https://arxiv.org/pdf/1304.1520)
*W. R. Moninger, J. A. Flueck, C. Lusk, W. F. Roberts* 

  During the summer of 1989, the Forecast Systems Laboratory of the National
Oceanic and Atmospheric Administration sponsored an evaluation of artificial
intelligence-based systems that forecast severe convective storms. The
evaluation experiment, called Shootout-89, took place in Boulder, and focussed
on storms over the northeastern Colorado foothills and plains (Moninger, et
al., 1990). Six systems participated in Shootout-89. These included traditional
expert systems, an analogy-based system, and a system developed using methods
from the cognitive science/judgment analysis tradition. Each day of the
exercise, the systems generated 2 to 9 hour forecasts of the probabilities of
occurrence of: non significant weather, significant weather, and severe
weather, in each of four regions in northeastern Colorado. A verification
coordinator working at the Denver Weather Service Forecast Office gathered
ground-truth data from a network of observers. Systems were evaluated on the
basis of several measures of forecast skill, and on other metrics such as
timeliness, ease of learning, and ease of use. Systems were generally easy to
operate, however the various systems required substantially different levels of
meteorological expertise on the part of their users--reflecting the various
operational environments for which the systems had been designed. Systems
varied in their statistical behavior, but on this difficult forecast problem,
the systems generally showed a skill approximately equal to that of persistence
forecasts and climatological (historical frequency) forecasts. The two systems
that appeared best able to discriminate significant from non significant
weather events were traditional expert systems. Both of these systems required
the operator to make relatively sophisticated meteorological judgments. We are
unable, based on only one summer's worth of data, to determine the extent to
which the greater skill of the two systems was due to the content of their
knowledge bases, or to the subjective judgments of the operator. A follow-on
experiment, Shootout-91, is currently being planned. Interested potential
participants are encouraged to contact the author at the address above.

---------------