Who was Bucephalus?

Bucephalus was the famous horse of Alexander the Great.

Some key facts about Bucephalus:

- He was a black stallion described as having a massive head and fiery temper. His name means "ox-head" in Greek.

- He was born in 355 BC and acquired by Alexander around 344 BC when Alexander was just 12 years old.

- Alexander was the only one able to tame the wild horse. This impressed his father, Philip II of Macedon.

- Bucephalus carried Alexander into many battles during his conquests across Asia, including the Battle of Gaugamela against Darius III of Persia in 331 BC.

- He died after being wounded in the Battle of Hydaspes in 326 BC in modern-day Pakistan. Alexander was so distraught he founded a city called Bucephala in his horse's honor.

- Their bond was legendary, with Alexander said to be the only person Bucephalus would allow on his back. He formed an inseparable partnership with his master.

So in summary, Bucephalus was Alexander the Great's revered war horse who accompanied him on his military campaigns across three continents.