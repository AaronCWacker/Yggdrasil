Write A Techno Trance Industrial Song about the top ten most popular national parks, and ten most popular inventors in AI and papers they wrote.

# 🩺🔍 Search Results
### 31 Jul 2023 | [NLLG Quarterly arXiv Report 06/23: What are the most influential current  AI Papers?](https://arxiv.org/abs/2308.04889) | [⬇️](https://arxiv.org/pdf/2308.04889)
*Steffen Eger and Christoph Leiter and Jonas Belouadi and Ran Zhang and  Aida Kostikova and Daniil Larionov and Yanran Chen and Vivian Fresen* 

  The rapid growth of information in the field of Generative Artificial
Intelligence (AI), particularly in the subfields of Natural Language Processing
(NLP) and Machine Learning (ML), presents a significant challenge for
researchers and practitioners to keep pace with the latest developments. To
address the problem of information overload, this report by the Natural
Language Learning Group at Bielefeld University focuses on identifying the most
popular papers on arXiv, with a specific emphasis on NLP and ML. The objective
is to offer a quick guide to the most relevant and widely discussed research,
aiding both newcomers and established researchers in staying abreast of current
trends. In particular, we compile a list of the 40 most popular papers based on
normalized citation counts from the first half of 2023. We observe the
dominance of papers related to Large Language Models (LLMs) and specifically
ChatGPT during the first half of 2023, with the latter showing signs of
declining popularity more recently, however. Further, NLP related papers are
the most influential (around 60\% of top papers) even though there are twice as
many ML related papers in our data. Core issues investigated in the most
heavily cited papers are: LLM efficiency, evaluation techniques, ethical
considerations, embodied agents, and problem-solving with LLMs. Additionally,
we examine the characteristics of top papers in comparison to others outside
the top-40 list (noticing the top paper's focus on LLM related issues and
higher number of co-authors) and analyze the citation distributions in our
dataset, among others.

---------------

### 31 Mar 2022 | [SELFIES and the future of molecular string representations](https://arxiv.org/abs/2204.00056) | [⬇️](https://arxiv.org/pdf/2204.00056)
*Mario Krenn, Qianxiang Ai, Senja Barthel, Nessa Carson, Angelo Frei,  Nathan C. Frey, Pascal Friederich, Th\'eophile Gaudin, Alberto Alexander  Gayle, Kevin Maik Jablonka, Rafael F. Lameiro, Dominik Lemm, Alston Lo, Seyed  Mohamad Moosavi, Jos\'e Manuel N\'apoles-Duarte, AkshatKumar Nigam, Robert  Pollice, Kohulan Rajan, Ulrich Schatzschneider, Philippe Schwaller, Marta  Skreta, Berend Smit, Felix Strieth-Kalthoff, Chong Sun, Gary Tom, Guido Falk  von Rudorff, Andrew Wang, Andrew White, Adamo Young, Rose Yu, Al\'an  Aspuru-Guzik* 

  Artificial intelligence (AI) and machine learning (ML) are expanding in
popularity for broad applications to challenging tasks in chemistry and
materials science. Examples include the prediction of properties, the discovery
of new reaction pathways, or the design of new molecules. The machine needs to
read and write fluently in a chemical language for each of these tasks. Strings
are a common tool to represent molecular graphs, and the most popular molecular
string representation, SMILES, has powered cheminformatics since the late
1980s. However, in the context of AI and ML in chemistry, SMILES has several
shortcomings -- most pertinently, most combinations of symbols lead to invalid
results with no valid chemical interpretation. To overcome this issue, a new
language for molecules was introduced in 2020 that guarantees 100\% robustness:
SELFIES (SELF-referencIng Embedded Strings). SELFIES has since simplified and
enabled numerous new applications in chemistry. In this manuscript, we look to
the future and discuss molecular string representations, along with their
respective opportunities and challenges. We propose 16 concrete Future Projects
for robust molecular representations. These involve the extension toward new
chemical domains, exciting questions at the interface of AI and robust
languages and interpretability for both humans and machines. We hope that these
proposals will inspire several follow-up works exploiting the full potential of
molecular string representations for the future of AI in chemistry and
materials science.

---------------

### 16 Dec 2021 | [Context-Based Music Recommendation Algorithm Evaluation](https://arxiv.org/abs/2112.10612) | [⬇️](https://arxiv.org/pdf/2112.10612)
*Marissa Baxter, Lisa Ha, Kirill Perfiliev, and Natalie Sayre* 

  Artificial Intelligence (AI ) has been very successful in creating and
predicting music playlists for online users based on their data; data received
from users experience using the app such as searching the songs they like.
There are lots of current technological advancements in AI due to the
competition between music platform owners such as Spotify, Pandora, and more.
In this paper, 6 machine learning algorithms and their individual accuracy for
predicting whether a user will like a song are explored across 3 different
platforms including Weka, SKLearn, and Orange. The algorithms explored include
Logistic Regression, Naive Bayes, Sequential Minimal Optimization (SMO),
Multilayer Perceptron (Neural Network), Nearest Neighbor, and Random Forest.
With the analysis of the specific characteristics of each song provided by the
Spotify API [1], Random Forest is the most successful algorithm for predicting
whether a user will like a song with an accuracy of 84%. This is higher than
the accuracy of 82.72% found by Mungekar using the Random Forest technique and
slightly different characteristics of a song [2]. The characteristics in
Mungekars Random Forest algorithm focus more on the artist and popularity
rather than the sonic features of the songs. Removing the popularity aspect and
focusing purely on the sonic qualities improve the accuracy of recommendations.
Finally, this paper shows how song prediction can be accomplished without any
monetary investments, and thus, inspires an idea of what amazing results can be
accomplished with full financial research.

---------------

### 09 Mar 2023 | [Seeing ChatGPT Through Students' Eyes: An Analysis of TikTok Data](https://arxiv.org/abs/2303.05349) | [⬇️](https://arxiv.org/pdf/2303.05349)
*Anna-Carolina Haensch, Sarah Ball, Markus Herklotz, Frauke Kreuter* 

  Advanced large language models like ChatGPT have gained considerable
attention recently, including among students. However, while the debate on
ChatGPT in academia is making waves, more understanding is needed among
lecturers and teachers on how students use and perceive ChatGPT. To address
this gap, we analyzed the content on ChatGPT available on TikTok in February
2023. TikTok is a rapidly growing social media platform popular among
individuals under 30. Specifically, we analyzed the content of the 100 most
popular videos in English tagged with #chatgpt, which collectively garnered
over 250 million views. Most of the videos we studied promoted the use of
ChatGPT for tasks like writing essays or code. In addition, many videos
discussed AI detectors, with a focus on how other tools can help to transform
ChatGPT output to fool these detectors. This also mirrors the discussion among
educators on how to treat ChatGPT as lecturers and teachers in teaching and
grading. What is, however, missing from the analyzed clips on TikTok are videos
that discuss ChatGPT producing content that is nonsensical or unfaithful to the
training data.

---------------

### 10 May 2019 | [AI in the media and creative industries](https://arxiv.org/abs/1905.04175) | [⬇️](https://arxiv.org/pdf/1905.04175)
*Giuseppe Amato (CNR PISA), Malte Behrmann, Fr\'ed\'eric Bimbot  (PANAMA), Baptiste Caramiaux (LRI, EX-SITU), Fabrizio Falchi (CNR PISA),  Ander Garcia, Joost Geurts (Inria), Jaume Gibert, Guillaume Gravier  (LinkMedia), Hadmut Holken, Hartmut Koenitz (HKU), Sylvain Lefebvre (MFX),  Antoine Liutkus (LORIA, ZENITH), Fabien Lotte (Potioc, LaBRI), Andrew Perkis  (NTNU), Rafael Redondo, Enrico Turrin (FEP), Thierry Vieville (Mnemosyne),  Emmanuel Vincent (MULTISPEECH)* 

  Thanks to the Big Data revolution and increasing computing capacities,
Artificial Intelligence (AI) has made an impressive revival over the past few
years and is now omnipresent in both research and industry. The creative
sectors have always been early adopters of AI technologies and this continues
to be the case. As a matter of fact, recent technological developments keep
pushing the boundaries of intelligent systems in creative applications: the
critically acclaimed movie "Sunspring", released in 2016, was entirely written
by AI technology, and the first-ever Music Album, called "Hello World",
produced using AI has been released this year. Simultaneously, the exploratory
nature of the creative process is raising important technical challenges for AI
such as the ability for AI-powered techniques to be accurate under limited data
resources, as opposed to the conventional "Big Data" approach, or the ability
to process, analyse and match data from multiple modalities (text, sound,
images, etc.) at the same time. The purpose of this white paper is to
understand future technological advances in AI and their growing impact on
creative industries. This paper addresses the following questions: Where does
AI operate in creative Industries? What is its operative role? How will AI
transform creative industries in the next ten years? This white paper aims to
provide a realistic perspective of the scope of AI actions in creative
industries, proposes a vision of how this technology could contribute to
research and development works in such context, and identifies research and
development challenges.

---------------

### 18 Oct 2022 | [Honor of Kings Arena: an Environment for Generalization in Competitive  Reinforcement Learning](https://arxiv.org/abs/2209.08483) | [⬇️](https://arxiv.org/pdf/2209.08483)
*Hua Wei, Jingxiao Chen, Xiyang Ji, Hongyang Qin, Minwen Deng, Siqin  Li, Liang Wang, Weinan Zhang, Yong Yu, Lin Liu, Lanxiao Huang, Deheng Ye,  Qiang Fu, Wei Yang* 

  This paper introduces Honor of Kings Arena, a reinforcement learning (RL)
environment based on Honor of Kings, one of the world's most popular games at
present. Compared to other environments studied in most previous work, ours
presents new generalization challenges for competitive reinforcement learning.
It is a multi-agent problem with one agent competing against its opponent; and
it requires the generalization ability as it has diverse targets to control and
diverse opponents to compete with. We describe the observation, action, and
reward specifications for the Honor of Kings domain and provide an open-source
Python-based interface for communicating with the game engine. We provide
twenty target heroes with a variety of tasks in Honor of Kings Arena and
present initial baseline results for RL-based methods with feasible computing
resources. Finally, we showcase the generalization challenges imposed by Honor
of Kings Arena and possible remedies to the challenges. All of the software,
including the environment-class, are publicly available at
https://github.com/tencent-ailab/hok_env . The documentation is available at
https://aiarena.tencent.com/hok/doc/ .

---------------

### 31 Jan 2023 | [An Analysis of Classification Approaches for Hit Song Prediction using  Engineered Metadata Features with Lyrics and Audio Features](https://arxiv.org/abs/2301.13507) | [⬇️](https://arxiv.org/pdf/2301.13507)
*Mengyisong Zhao, Morgan Harvey, David Cameron, Frank Hopfgartner and  Valerie J. Gillet* 

  Hit song prediction, one of the emerging fields in music information
retrieval (MIR), remains a considerable challenge. Being able to understand
what makes a given song a hit is clearly beneficial to the whole music
industry. Previous approaches to hit song prediction have focused on using
audio features of a record. This study aims to improve the prediction result of
the top 10 hits among Billboard Hot 100 songs using more alternative metadata,
including song audio features provided by Spotify, song lyrics, and novel
metadata-based features (title topic, popularity continuity and genre class).
Five machine learning approaches are applied, including: k-nearest neighbours,
Naive Bayes, Random Forest, Logistic Regression and Multilayer Perceptron. Our
results show that Random Forest (RF) and Logistic Regression (LR) with all
features (including novel features, song audio features and lyrics features)
outperforms other models, achieving 89.1% and 87.2% accuracy, and 0.91 and 0.93
AUC, respectively. Our findings also demonstrate the utility of our novel music
metadata features, which contributed most to the models' discriminative
performance.

---------------

### 17 Nov 2022 | [Text to Image Generation: Leaving no Language Behind](https://arxiv.org/abs/2208.09333) | [⬇️](https://arxiv.org/pdf/2208.09333)
*Pedro Reviriego and Elena Merino-G\'omez* 

  One of the latest applications of Artificial Intelligence (AI) is to generate
images from natural language descriptions. These generators are now becoming
available and achieve impressive results that have been used for example in the
front cover of magazines. As the input to the generators is in the form of a
natural language text, a question that arises immediately is how these models
behave when the input is written in different languages. In this paper we
perform an initial exploration of how the performance of three popular
text-to-image generators depends on the language. The results show that there
is a significant performance degradation when using languages other than
English, especially for languages that are not widely used. This observation
leads us to discuss different alternatives on how text-to-image generators can
be improved so that performance is consistent across different languages. This
is fundamental to ensure that this new technology can be used by non-native
English speakers and to preserve linguistic diversity.

---------------

### 13 Jan 2023 | [In BLOOM: Creativity and Affinity in Artificial Lyrics and Art](https://arxiv.org/abs/2301.05402) | [⬇️](https://arxiv.org/pdf/2301.05402)
*Evan Crothers, Herna Viktor, Nathalie Japkowicz* 

  We apply a large multilingual language model (BLOOM-176B) in open-ended
generation of Chinese song lyrics, and evaluate the resulting lyrics for
coherence and creativity using human reviewers. We find that current
computational metrics for evaluating large language model outputs (MAUVE) have
limitations in evaluation of creative writing. We note that the human concept
of creativity requires lyrics to be both comprehensible and distinctive -- and
that humans assess certain types of machine-generated lyrics to score more
highly than real lyrics by popular artists. Inspired by the inherently
multimodal nature of album releases, we leverage a Chinese-language stable
diffusion model to produce high-quality lyric-guided album art, demonstrating a
creative approach for an artist seeking inspiration for an album or single.
Finally, we introduce the MojimLyrics dataset, a Chinese-language dataset of
popular song lyrics for future research.

---------------

### 20 May 2023 | [A Survey of Explainable AI and Proposal for a Discipline of Explanation  Engineering](https://arxiv.org/abs/2306.01750) | [⬇️](https://arxiv.org/pdf/2306.01750)
*Clive Gomes, Lalitha Natraj, Shijun Liu, Anushka Datta* 

  In this survey paper, we deep dive into the field of Explainable Artificial
Intelligence (XAI). After introducing the scope of this paper, we start by
discussing what an "explanation" really is. We then move on to discuss some of
the existing approaches to XAI and build a taxonomy of the most popular
methods. Next, we also look at a few applications of these and other XAI
techniques in four primary domains: finance, autonomous driving, healthcare and
manufacturing. We end by introducing a promising discipline, "Explanation
Engineering," which includes a systematic approach for designing explainability
into AI systems.

---------------

### 25 May 2023 | [SemEval-2023 Task 2: Fine-grained Multilingual Named Entity Recognition  (MultiCoNER 2)](https://arxiv.org/abs/2305.06586) | [⬇️](https://arxiv.org/pdf/2305.06586)
*Besnik Fetahu, Sudipta Kar, Zhiyu Chen, Oleg Rokhlenko, Shervin  Malmasi* 

  We present the findings of SemEval-2023 Task 2 on Fine-grained Multilingual
Named Entity Recognition (MultiCoNER 2). Divided into 13 tracks, the task
focused on methods to identify complex fine-grained named entities (like
WRITTENWORK, VEHICLE, MUSICALGRP) across 12 languages, in both monolingual and
multilingual scenarios, as well as noisy settings. The task used the MultiCoNER
V2 dataset, composed of 2.2 million instances in Bangla, Chinese, English,
Farsi, French, German, Hindi, Italian., Portuguese, Spanish, Swedish, and
Ukrainian. MultiCoNER 2 was one of the most popular tasks of SemEval-2023. It
attracted 842 submissions from 47 teams, and 34 teams submitted system papers.
Results showed that complex entity types such as media titles and product names
were the most challenging. Methods fusing external knowledge into transformer
models achieved the best performance, and the largest gains were on the
Creative Work and Group classes, which are still challenging even with external
knowledge. Some fine-grained classes proved to be more challenging than others,
such as SCIENTIST, ARTWORK, and PRIVATECORP. We also observed that noisy data
has a significant impact on model performance, with an average drop of 10% on
the noisy subset. The task highlights the need for future research on improving
NER robustness on noisy data containing complex entities.

---------------

### 21 Feb 2020 | [Introducing Fuzzy Layers for Deep Learning](https://arxiv.org/abs/2003.00880) | [⬇️](https://arxiv.org/pdf/2003.00880)
*Stanton R. Price, Steven R. Price, Derek T. Anderson* 

  Many state-of-the-art technologies developed in recent years have been
influenced by machine learning to some extent. Most popular at the time of this
writing are artificial intelligence methodologies that fall under the umbrella
of deep learning. Deep learning has been shown across many applications to be
extremely powerful and capable of handling problems that possess great
complexity and difficulty. In this work, we introduce a new layer to deep
learning: the fuzzy layer. Traditionally, the network architecture of neural
networks is composed of an input layer, some combination of hidden layers, and
an output layer. We propose the introduction of fuzzy layers into the deep
learning architecture to exploit the powerful aggregation properties expressed
through fuzzy methodologies, such as the Choquet and Sugueno fuzzy integrals.
To date, fuzzy approaches taken to deep learning have been through the
application of various fusion strategies at the decision level to aggregate
outputs from state-of-the-art pre-trained models, e.g., AlexNet, VGG16,
GoogLeNet, Inception-v3, ResNet-18, etc. While these strategies have been shown
to improve accuracy performance for image classification tasks, none have
explored the use of fuzzified intermediate, or hidden, layers. Herein, we
present a new deep learning strategy that incorporates fuzzy strategies into
the deep learning architecture focused on the application of semantic
segmentation using per-pixel classification. Experiments are conducted on a
benchmark data set as well as a data set collected via an unmanned aerial
system at a U.S. Army test site for the task of automatic road segmentation,
and preliminary results are promising.

---------------

### 19 Apr 2023 | [How to Do Things with Deep Learning Code](https://arxiv.org/abs/2304.09406) | [⬇️](https://arxiv.org/pdf/2304.09406)
*Minh Hua, Rita Raley* 

  The premise of this article is that a basic understanding of the composition
and functioning of large language models is critically urgent. To that end, we
extract a representational map of OpenAI's GPT-2 with what we articulate as two
classes of deep learning code, that which pertains to the model and that which
underwrites applications built around the model. We then verify this map
through case studies of two popular GPT-2 applications: the text adventure
game, AI Dungeon, and the language art project, This Word Does Not Exist. Such
an exercise allows us to test the potential of Critical Code Studies when the
object of study is deep learning code and to demonstrate the validity of code
as an analytical focus for researchers in the subfields of Critical Artificial
Intelligence and Critical Machine Learning Studies. More broadly, however, our
work draws attention to the means by which ordinary users might interact with,
and even direct, the behavior of deep learning systems, and by extension works
toward demystifying some of the auratic mystery of "AI." What is at stake is
the possibility of achieving an informed sociotechnical consensus about the
responsible applications of large language models, as well as a more expansive
sense of their creative capabilities-indeed, understanding how and where
engagement occurs allows all of us to become more active participants in the
development of machine learning systems.

---------------

### 29 Mar 2017 | [The Top 10 Topics in Machine Learning Revisited: A Quantitative  Meta-Study](https://arxiv.org/abs/1703.10121) | [⬇️](https://arxiv.org/pdf/1703.10121)
*Patrick Glauner, Manxing Du, Victor Paraschiv, Andrey Boytsov, Isabel  Lopez Andrade, Jorge Meira, Petko Valtchev, Radu State* 

  Which topics of machine learning are most commonly addressed in research?
This question was initially answered in 2007 by doing a qualitative survey
among distinguished researchers. In our study, we revisit this question from a
quantitative perspective. Concretely, we collect 54K abstracts of papers
published between 2007 and 2016 in leading machine learning journals and
conferences. We then use machine learning in order to determine the top 10
topics in machine learning. We not only include models, but provide a holistic
view across optimization, data, features, etc. This quantitative approach
allows reducing the bias of surveys. It reveals new and up-to-date insights
into what the 10 most prolific topics in machine learning research are. This
allows researchers to identify popular topics as well as new and rising topics
for their research.

---------------

### 21 Jul 2023 | [Methodologies for Improving Modern Industrial Recommender Systems](https://arxiv.org/abs/2308.01204) | [⬇️](https://arxiv.org/pdf/2308.01204)
*Shusen Wang* 

  Recommender system (RS) is an established technology with successful
applications in social media, e-commerce, entertainment, and more. RSs are
indeed key to the success of many popular APPs, such as YouTube, Tik Tok,
Xiaohongshu, Bilibili, and others. This paper explores the methodology for
improving modern industrial RSs. It is written for experienced RS engineers who
are diligently working to improve their key performance indicators, such as
retention and duration. The experiences shared in this paper have been tested
in some real industrial RSs and are likely to be generalized to other RSs as
well. Most contents in this paper are industry experience without publicly
available references.

---------------

### 07 Feb 2021 | ["Short is the Road that Leads from Fear to Hate": Fear Speech in Indian  WhatsApp Groups](https://arxiv.org/abs/2102.03870) | [⬇️](https://arxiv.org/pdf/2102.03870)
*Punyajoy Saha, Binny Mathew, Kiran Garimella, Animesh Mukherjee* 

  WhatsApp is the most popular messaging app in the world. Due to its
popularity, WhatsApp has become a powerful and cheap tool for political
campaigning being widely used during the 2019 Indian general election, where it
was used to connect to the voters on a large scale. Along with the campaigning,
there have been reports that WhatsApp has also become a breeding ground for
harmful speech against various protected groups and religious minorities. Many
such messages attempt to instil fear among the population about a specific
(minority) community. According to research on inter-group conflict, such `fear
speech' messages could have a lasting impact and might lead to real offline
violence. In this paper, we perform the first large scale study on fear speech
across thousands of public WhatsApp groups discussing politics in India. We
curate a new dataset and try to characterize fear speech from this dataset. We
observe that users writing fear speech messages use various events and symbols
to create the illusion of fear among the reader about a target community. We
build models to classify fear speech and observe that current state-of-the-art
NLP models do not perform well at this task. Fear speech messages tend to
spread faster and could potentially go undetected by classifiers built to
detect traditional toxic speech due to their low toxic nature. Finally, using a
novel methodology to target users with Facebook ads, we conduct a survey among
the users of these WhatsApp groups to understand the types of users who consume
and share fear speech. We believe that this work opens up new research
questions that are very different from tackling hate speech which the research
community has been traditionally involved in.

---------------

### 10 Jan 2023 | [AI-Based Affective Music Generation Systems: A Review of Methods, and  Challenges](https://arxiv.org/abs/2301.06890) | [⬇️](https://arxiv.org/pdf/2301.06890)
*Adyasha Dash, Kat R. Agres* 

  Music is a powerful medium for altering the emotional state of the listener.
In recent years, with significant advancement in computing capabilities,
artificial intelligence-based (AI-based) approaches have become popular for
creating affective music generation (AMG) systems that are empowered with the
ability to generate affective music. Entertainment, healthcare, and
sensor-integrated interactive system design are a few of the areas in which
AI-based affective music generation (AI-AMG) systems may have a significant
impact. Given the surge of interest in this topic, this article aims to provide
a comprehensive review of AI-AMG systems. The main building blocks of an AI-AMG
system are discussed, and existing systems are formally categorized based on
the core algorithm used for music generation. In addition, this article
discusses the main musical features employed to compose affective music, along
with the respective AI-based approaches used for tailoring them. Lastly, the
main challenges and open questions in this field, as well as their potential
solutions, are presented to guide future research. We hope that this review
will be useful for readers seeking to understand the state-of-the-art in AI-AMG
systems, and gain an overview of the methods used for developing them, thereby
helping them explore this field in the future.

---------------

### 12 Nov 2020 | [Automatic Neural Lyrics and Melody Composition](https://arxiv.org/abs/2011.06380) | [⬇️](https://arxiv.org/pdf/2011.06380)
*Gurunath Reddy Madhumani, Yi Yu, Florian Harsco\"et, Simon Canales,  Suhua Tang* 

  In this paper, we propose a technique to address the most challenging aspect
of algorithmic songwriting process, which enables the human community to
discover original lyrics, and melodies suitable for the generated lyrics. The
proposed songwriting system, Automatic Neural Lyrics and Melody Composition
(AutoNLMC) is an attempt to make the whole process of songwriting automatic
using artificial neural networks. Our lyric to vector (lyric2vec) model trained
on a large set of lyric-melody pairs dataset parsed at syllable, word and
sentence levels are large scale embedding models enable us to train data driven
model such as recurrent neural networks for popular English songs. AutoNLMC is
a encoder-decoder sequential recurrent neural network model consisting of a
lyric generator, a lyric encoder and melody decoder trained end-to-end.
AutoNLMC is designed to generate both lyrics and corresponding melody
automatically for an amateur or a person without music knowledge. It can also
take lyrics from professional lyric writer to generate matching melodies. The
qualitative and quantitative evaluation measures revealed that the proposed
method is indeed capable of generating original lyrics and corresponding melody
for composing new songs.

---------------

### 01 Feb 2023 | [Grading Conversational Responses Of Chatbots](https://arxiv.org/abs/2303.12038) | [⬇️](https://arxiv.org/pdf/2303.12038)
*Grant Rosario, David Noever* 

  Chatbots have long been capable of answering basic questions and even
responding to obscure prompts, but recently their improvements have been far
more significant. Modern chatbots like Open AIs ChatGPT3 not only have the
ability to answer basic questions but can write code and movie scripts and
imitate well-known people. In this paper, we analyze ChatGPTs' responses to
various questions from a dataset of queries from the popular Quora forum. We
submitted sixty questions to ChatGPT and scored the answers based on three
industry-standard metrics for grading machine translation: BLEU, METEOR, and
ROUGE. These metrics allow us to compare the machine responses with the most
upvoted human answer to the same question to assess ChatGPT's ability to submit
a humanistic reply. The results showed that while the responses and translation
abilities of ChatGPT are remarkable, they still fall short of what a typical
human reaction would be.

---------------

### 01 Jan 2021 | [Key Phrase Extraction & Applause Prediction](https://arxiv.org/abs/2101.03235) | [⬇️](https://arxiv.org/pdf/2101.03235)
*Krishna Yadav, Lakshya Choudhary* 

  With the increase in content availability over the internet it is very
difficult to get noticed. It has become an upmost the priority of the blog
writers to get some feedback over their creations to be confident about the
impact of their article. We are training a machine learning model to learn
popular article styles, in the form of vector space representations using
various word embeddings, and their popularity based on claps and tags.

---------------