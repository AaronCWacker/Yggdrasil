Science Fiction Movie Scenes

<s>[INST] Context:
 1. <b> Robot Grasping and Manipulation: A Prospective </b> 
 Abstract:   ``A simple handshake would give them away''. This is how Anthony Hopkins'
fictional character, Dr Robert Ford, summarises a particular flaw of the 2016
science-fiction \emph{Westworld}'s hosts. In the storyline, Westworld is a
futuristic theme park and the hosts are autonomous robots engineered to be
indistinguishable from the human guests, except for their hands that have not
been perfected yet. In another classic science-fiction saga, scientists unlock
the secrets of full synthetic intelligence, Skynet, by reverse engineering a
futuristic hand.
  In both storylines, reality inspires fiction on one crucial point: designing
hands and reproducing robust and reliable manipulation actions is one of the
biggest challenges in robotics.
  Solving this problem would lead us to a new, improved era of autonomy. A
century ago, the third industrial revolution brought robots into the assembly
lines, changing our way of working forever. The next revolution has already
started by bringing us artificial intelligence (AI) assistants, enhancing our
quality of life in our jobs and everyday lives--even combating worldwide
pandemics.
2. <b> Multilevel profiling of situation and dialogue-based deep networks for  movie genre classification using movie trailers </b> 
 Abstract:   Automated movie genre classification has emerged as an active and essential
area of research and exploration. Short duration movie trailers provide useful
insights about the movie as video content consists of the cognitive and the
affective level features. Previous approaches were focused upon either
cognitive or affective content analysis. In this paper, we propose a novel
multi-modality: situation, dialogue, and metadata-based movie genre
classification framework that takes both cognition and affect-based features
into consideration. A pre-features fusion-based framework that takes into
account: situation-based features from a regular snapshot of a trailer that
includes nouns and verbs providing the useful affect-based mapping with the
corresponding genres, dialogue (speech) based feature from audio, metadata
which together provides the relevant information for cognitive and affect based
video analysis. We also develop the English movie trailer dataset (EMTD), which
contains 2000 Hollywood movie trailers belonging to five popular genres:
Action, Romance, Comedy, Horror, and Science Fiction, and perform
cross-validation on the standard LMTD-9 dataset for validating the proposed
framework. The results demonstrate that the proposed methodology for movie
genre classification has performed excellently as depicted by the F1 scores,
precision, recall, and area under the precision-recall curves.
3. <b> MovieCLIP: Visual Scene Recognition in Movies </b> 
 Abstract:   Longform media such as movies have complex narrative structures, with events
spanning a rich variety of ambient visual scenes. Domain specific challenges
associated with visual scenes in movies include transitions, person coverage,
and a wide array of real-life and fictional scenarios. Existing visual scene
datasets in movies have limited taxonomies and don't consider the visual scene
transition within movie clips. In this work, we address the problem of visual
scene recognition in movies by first automatically curating a new and extensive
movie-centric taxonomy of 179 scene labels derived from movie scripts and
auxiliary web-based video datasets. Instead of manual annotations which can be
expensive, we use CLIP to weakly label 1.12 million shots from 32K movie clips
based on our proposed taxonomy. We provide baseline visual models trained on
the weakly labeled dataset called MovieCLIP and evaluate them on an independent
dataset verified by human raters. We show that leveraging features from models
pretrained on MovieCLIP benefits downstream tasks such as multi-label scene and
genre classification of web videos and movie trailers.
4. <b> Robots as Actors in a Film: No War, A Robot Story </b> 
 Abstract:   Will the Third World War be fought by robots? This short film is a
light-hearted comedy that aims to trigger an interesting discussion and
reflexion on the terrifying killer-robot stories that increasingly fill us with
dread when we read the news headlines. The fictional scenario takes inspiration
from current scientific research and describes a future where robots are asked
by humans to join the war. Robots are divided, sparking protests in robot
society... will robots join the conflict or will they refuse to be employed in
human warfare? Food for thought for engineers, roboticists and anyone imagining
what the upcoming robot revolution could look like. We let robots pop on camera
to tell a story, taking on the role of actors playing in the film, instructed
through code on how to "act" for each scene.
5. <b> Imitating Interactive Intelligence </b> 
 Abstract:   A common vision from science fiction is that robots will one day inhabit our
physical spaces, sense the world as we do, assist our physical labours, and
communicate with us through natural language. Here we study how to design
artificial agents that can interact naturally with humans using the
simplification of a virtual environment. This setting nevertheless integrates a
number of the central challenges of artificial intelligence (AI) research:
complex visual perception and goal-directed physical control, grounded language
comprehension and production, and multi-agent social interaction. To build
agents that can robustly interact with humans, we would ideally train them
while they interact with humans. However, this is presently impractical.
Therefore, we approximate the role of the human with another learned agent, and
use ideas from inverse reinforcement learning to reduce the disparities between
human-human and agent-agent interactive behaviour. Rigorously evaluating our
agents poses a great challenge, so we develop a variety of behavioural tests,
including evaluation by humans who watch videos of agents or interact directly
with them. These evaluations convincingly demonstrate that interactive training
and auxiliary losses improve agent behaviour beyond what is achieved by
supervised learning of actions alone. Further, we demonstrate that agent
capabilities generalise beyond literal experiences in the dataset. Finally, we
train evaluation models whose ratings of agents agree well with human
judgement, thus permitting the evaluation of new agent models without
additional effort. Taken together, our results in this virtual environment
provide evidence that large-scale human behavioural imitation is a promising
tool to create intelligent, interactive agents, and the challenge of reliably
evaluating such agents is possible to surmount.
6. <b> Creating Multimodal Interactive Agents with Imitation and  Self-Supervised Learning </b> 
 Abstract:   A common vision from science fiction is that robots will one day inhabit our
physical spaces, sense the world as we do, assist our physical labours, and
communicate with us through natural language. Here we study how to design
artificial agents that can interact naturally with humans using the
simplification of a virtual environment. We show that imitation learning of
human-human interactions in a simulated world, in conjunction with
self-supervised learning, is sufficient to produce a multimodal interactive
agent, which we call MIA, that successfully interacts with non-adversarial
humans 75% of the time. We further identify architectural and algorithmic
techniques that improve performance, such as hierarchical action selection.
Altogether, our results demonstrate that imitation of multi-modal, real-time
human behaviour may provide a straightforward and surprisingly effective means
of imbuing agents with a rich behavioural prior from which agents might then be
fine-tuned for specific purposes, thus laying a foundation for training capable
agents for interactive robots or digital assistants. A video of MIA's behaviour
may be found at https://youtu.be/ZFgRhviF7mY
7. <b> A Theme-Rewriting Approach for Generating Algebra Word Problems </b> 
 Abstract:   Texts present coherent stories that have a particular theme or overall
setting, for example science fiction or western. In this paper, we present a
text generation method called {\it rewriting} that edits existing
human-authored narratives to change their theme without changing the underlying
story. We apply the approach to math word problems, where it might help
students stay more engaged by quickly transforming all of their homework
assignments to the theme of their favorite movie without changing the math
concepts that are being taught. Our rewriting method uses a two-stage decoding
process, which proposes new words from the target theme and scores the
resulting stories according to a number of factors defining aspects of
syntactic, semantic, and thematic coherence. Experiments demonstrate that the
final stories typically represent the new theme well while still testing the
original math concepts, outperforming a number of baselines. We also release a
new dataset of human-authored rewrites of math word problems in several themes.
8. <b> QUEST: A Retrieval Dataset of Entity-Seeking Queries with Implicit Set  Operations </b> 
 Abstract:   Formulating selective information needs results in queries that implicitly
specify set operations, such as intersection, union, and difference. For
instance, one might search for "shorebirds that are not sandpipers" or
"science-fiction films shot in England". To study the ability of retrieval
systems to meet such information needs, we construct QUEST, a dataset of 3357
natural language queries with implicit set operations, that map to a set of
entities corresponding to Wikipedia documents. The dataset challenges models to
match multiple constraints mentioned in queries with corresponding evidence in
documents and correctly perform various set operations. The dataset is
constructed semi-automatically using Wikipedia category names. Queries are
automatically composed from individual categories, then paraphrased and further
validated for naturalness and fluency by crowdworkers. Crowdworkers also assess
the relevance of entities based on their documents and highlight attribution of
query constraints to spans of document text. We analyze several modern
retrieval systems, finding that they often struggle on such queries. Queries
involving negation and conjunction are particularly challenging and systems are
further challenged with combinations of these operations.
9. <b> Science Fiction as a Worldwide Phenomenon: A Study of International  Creation, Consumption and Dissemination </b> 
 Abstract:   This paper examines the international nature of science fiction. The focus of
this research is to determine whether science fiction is primarily English
speaking and Western or global; being created and consumed by people in
non-Western, non-English speaking countries? Science fiction's international
presence was found in three ways, by network analysis, by examining a online
retailer and with a survey. Condor, a program developed by GalaxyAdvisors was
used to determine if science fiction is being talked about by non-English
speakers. An analysis of the international Amazon.com websites was done to
discover if it was being consumed worldwide. A survey was also conducted to see
if people had experience with science fiction. All three research methods
revealed similar results. Science fiction was found to be international, with
science fiction creators originating in different countries and writing in a
host of different languages. English and non-English science fiction was being
created and consumed all over the world, not just in the English speaking West.
10. <b> From None to Severe: Predicting Severity in Movie Scripts </b> 
 Abstract:   In this paper, we introduce the task of predicting severity of age-restricted
aspects of movie content based solely on the dialogue script. We first
investigate categorizing the ordinal severity of movies on 5 aspects: Sex,
Violence, Profanity, Substance consumption, and Frightening scenes. The problem
is handled using a siamese network-based multitask framework which concurrently
improves the interpretability of the predictions. The experimental results show
that our method outperforms the previous state-of-the-art model and provides
useful information to interpret model predictions. The proposed dataset and
source code are publicly available at our GitHub repository.
 
 Given the following scientific paper abstracts, take a deep breath and lets think step by step to answer the question. Cite the titles of your sources when answering, do not cite links or dates. Question: Science Fiction Movie Scenes[/INST]