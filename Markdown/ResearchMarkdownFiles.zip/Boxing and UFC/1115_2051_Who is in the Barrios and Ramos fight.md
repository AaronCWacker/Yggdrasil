Who is in the Barrios and Ramos fight?

Jesús Ramos and Brian Mendoza are scheduled to fight each other on February 11, 2023 in Glendale, Arizona.

Jesús Ramos is an undefeated American professional boxer with a record of 19-0. He holds the WBA Interim Super Lightweight title.

Brian Mendoza is a Mexican professional boxer with a record of 21-2. He is the former WBC Continental Americas super lightweight champion.

Their bout is a scheduled 10-round super lightweight contest on the undercard of the David Benavidez vs. Caleb Plant Showtime PPV event.