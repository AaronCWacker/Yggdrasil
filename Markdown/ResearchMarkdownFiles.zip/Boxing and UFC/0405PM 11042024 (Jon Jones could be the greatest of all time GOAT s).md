# Query: Jon Jones could be the greatest of all time (GOAT) since he never lost.

## AI Response
 He was stripped of his title twice due to his actions outside the octagon. He was the youngest champion in UFC history. He has a record of 26-1-0.

Jones has been in the UFC since 2008. He has been a champion since 2011. He has defended his title 11 times. He has beaten many great fighters such as Daniel Cormier, Alexander Gustafsson, and Rashad Evans.

Jones has been in some controversy outside the octagon. He has been arrested for DWI and hit and run. He has also tested positive for steroids. However, he has never lost a fight in the octagon.

Jones is still young and has many years left in his career. He could break many records and become the greatest of all time. He has the skills, the heart, and the determination to be the best.

Jones is a true champion and a true warrior. He has faced many challenges and obstacles in his career, but he has always come out on top. He is a role model for many young fighters and a inspiration to all.

Jones is the greatest of all time and he will continue to prove it in the octagon. He will continue to defend his title and break records. He will continue to be a champion and a warrior. Jones is the GOAT and he will always be remembered as such.</s>

 He has defended his title a record 10 times and has been the UFC light heavyweight champion for over 12 years.

However, Jones’ legacy has been tarnished by several controversies, including failed drug tests and hit-and-run incidents.

Jones’ most recent controversy came in March 2022 when he tested positive for a banned substance, hydrochlorothiazide, which he claimed was due to a contaminated supplement.

Despite this, many still consider Jones to be the GOAT due to his impressive record and dominance in the light heavyweight division.

Here are some reasons why Jon Jones could be considered the greatest of all time in UFC history:

1. Unbeaten Record: Jones has an impressive record of 26 wins and no losses, with 17 of those wins coming by knockout or submission. He has never lost a title fight and has defended his belt a record 10 times.
2. Dominance in the Light Heavyweight Division: Jones has been the UFC light heavyweight champion for over 12 years, which is a testament to his dominance in the division. He has defeated some of the best fighters in the division, including Daniel Cormier, Alexander Gustafsson, and Anthony Johnson.
3. Versatility: Jones is a versatile fighter who can finish fights in various ways. He has a black belt in Brazilian Jiu-Jitsu and is known for his striking skills, particularly his reach and accuracy. He has also shown the ability to adapt to different fighting styles and adjust his game plan accordingly.
4. Work Ethic: Jones is known for his intense work ethic and dedication to the sport. He trains relentlessly and is always looking for ways to improve his skills and prepare for his next fight.
5. Impact on the Sport: Jones has had a significant impact on the sport of MMA and has helped to popularize it among a wider audience. He has been a mainstay in the UFC for over a decade and has been involved in some of the most memorable fights in the promotion’s history.

However, it’s important to note that Jones’ legacy is not without controversy. His failed drug tests and other off-the-mat incidents have raised questions about his character and whether he truly deserves to be considered the greatest of all time. Ultimately,
