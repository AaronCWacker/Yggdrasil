# Query: George St. Pierre

## AI Response
is a Canadian mixed martial artist who is currently signed with the Ultimate Fighting Championship (UFC). He is a three-time UFC Welterweight Champion and a former UFC Middleweight Champion. St. Pierre is widely regarded as one of the greatest mixed martial artists of all time.

St. Pierre was born on May 19, 1981, in Saint-Isidore, Quebec, Canada. He began training in Kyokushin karate at the age of seven and later added wrestling, Brazilian jiu-jitsu, and boxing to his repertoire. St. Pierre made his professional MMA debut in January 2002 and quickly established himself as a top prospect in the sport.

In January 2004, St. Pierre made his UFC debut, defeating Karo Parisyan via unanimous decision. He would go on to compile an impressive record in the UFC, defeating some of the top welterweights in the world, including Matt Hughes, B.J. Penn, and Johny Hendricks.

In November 2013, St. Pierre vacated the welterweight title and took a break from MMA. He returned to the sport in November 2017, defeating Michael Bisping to become the UFC Middleweight Champion. St. Pierre would go on to vacate the title and retire from MMA in February 2019.

Throughout his career, St. Pierre has been known for his excellent striking, grappling, and conditioning. He has also been praised for his sportsmanship and professionalism both inside and outside the cage.

St. Pierre has been inducted into the UFC Hall of Fame and is a member of the UFC's "Pound-for-Pound" rankings. He has also won numerous awards and accolades, including the "Fighter of the Year" award from several MMA publications.

St. Pierre is currently retired from MMA, but he remains active in the sport as a coach and mentor. He is also involved in various business ventures, including his own line of nutritional supplements and a clothing brand. St. Pierre is also a philanthropist, donating time and money to various charitable causes, including children's hospitals and cancer research.</s>

is a Canadian professional mixed martial artist, actor, and former UFC Welterweight Champion. He is widely regarded as one of the greatest mixed martial artists of all time. GSP has won numerous awards and accolades throughout his career, including being inducted into the UFC Hall of Fame. In this article, we will explore George St. Pierre’s net worth, earnings, and career highlights.

## Early Life and Career Beginnings

George St. Pierre was born on May 21, 1981, in Saint-Isidore, Quebec, Canada. He grew up in a working-class family and took up martial arts at a young age to defend himself against bullies. St. Pierre began training in karate at the age of 12 and later added Brazilian jiu-jitsu, wrestling, and boxing to his skillset.

St. Pierre made his professional MMA debut in 1999, competing primarily in regional promotions in Canada and the United States. He compiled a record of 11-2 before catching the attention of the UFC.

## UFC Career and Achievements

St. Pierre joined the UFC in 2004 and quickly made a name for himself as a formidable welterweight contender. He won his first five fights in the promotion, including a submission victory over Matt Hughes, who was the reigning UFC Welterweight Champion at the time.

St. Pierre went on to defend his title a record-tying 11 times, defeating notable opponents such as B.J. Penn, Thiago Alves, and Josh Koscheck. He also held the UFC Middleweight Championship for a brief period in 2008, becoming the first Canadian to hold a UFC title.

St. Pierre retired from MMA competition in 2019, compiling a career record of 26-2-1. He is widely regarded as one of the greatest mixed martial artists of all time and was inducted into the UFC Hall of Fame in 2014.

## Acting Career

In addition to his MMA career, St. Pierre has also pursued an acting career. He made his acting debut in the 2010 film “The Warrior’s Way,” which was filmed in South Korea.
