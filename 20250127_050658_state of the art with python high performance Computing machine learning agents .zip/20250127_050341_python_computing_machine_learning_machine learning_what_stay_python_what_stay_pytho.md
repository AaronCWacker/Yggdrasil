what is the stay of the art with python high performance Computing machine learning agents Python has become a popular choice for high-performance computing and machine learning applications due to its rich ecosystem of libraries and tools. Here are some of the state-of-the-art technologies and frameworks for Python in these domains:

1. **NumPy**: NumPy is a fundamental library for scientific computing in Python. It provides support for large, multi-dimensional arrays and matrices, along with a collection of high-level mathematical functions to operate on these arrays. NumPy is highly optimized for numerical operations and is widely used in machine learning and high-performance computing.

2. **SciPy**: SciPy is a library for scientific and technical computing in Python. It builds on NumPy and provides many user-friendly and efficient numerical routines, such as routines for numerical integration, interpolation, optimization, linear algebra, and statistics.

3. **Pandas**: Pandas is a powerful data analysis and manipulation library for Python. It provides efficient data structures and data analysis tools for working with structured (tabular, multidimensional, potentially heterogeneous) and time series data.

4. **Scikit-learn**: Scikit-learn is one of the most popular and comprehensive machine learning libraries for Python. It features various classification, regression, clustering, dimensionality reduction, model selection, and preprocessing algorithms.

5. **TensorFlow**: TensorFlow is an open-source library developed by Google for numerical computation and machine learning. It provides a flexible and efficient framework for building and deploying machine learning models, including deep neural networks.

6. **PyTorch**: PyTorch is an open-source machine learning library primarily used for applications such as computer vision and natural language processing. It provides a flexible and intuitive way to build and train deep neural networks, with strong support for GPU acceleration.

7. **Numba**: Numba is a just-in-time (JIT) compiler for Python that translates a subset of Python and NumPy code into fast machine code, using the LLVM compiler infrastructure. It can significantly speed up numerical and scientific computing in Python.

8. **Dask**: Dask is a parallel computing library for Python that scales NumPy, Pandas, and other Python libraries to larger-than-memory or distributed datasets. It provides high-performance analytics on large datasets by breaking them into smaller chunks and processing them in parallel across multiple cores or machines.

9. **MPI4Py**: MPI4Py is a Python library that provides bindings to the Message Passing Interface (MPI) standard, allowing Python programs to run in parallel on distributed memory systems. It is widely used in high-performance computing applications.

10. **Horovod**: Horovod is a distributed deep learning training framework for TensorFlow, Keras, PyTorch, and Apache MXNet. It provides a way to scale out deep learning training across multiple GPUs or machines, with efficient communication and data transfer between them.

These are just a few examples of the state-of-the-art tools and frameworks available in Python for high-performance computing and machine learning. The Python ecosystem is continuously evolving, and new libraries and tools are being developed to further enhance the performance and capabilities of Python in these domains.

🔎 what is the stay of the art with python high performance Computing machine learning agents Python has become a popular choice for high-performance computing and machine learning applications due to its rich ecosystem of libraries and tools. Here are some of the state-of-the-art technologies and frameworks for Python in these domains:

1. **NumPy**: NumPy is a fundamental library for scientific computing in Python. It provides support for large, multi-dimensional arrays and matrices, along with a collection of high-level mathematical functions to operate on these arrays. NumPy is highly optimized for numerical operations and is widely used in machine learning and high-performance computing.

2. **SciPy**: SciPy is a library for scientific and technical computing in Python. It builds on NumPy and provides many user-friendly and efficient numerical routines, such as routines for numerical integration, interpolation, optimization, linear algebra, and statistics.

3. **Pandas**: Pandas is a powerful data analysis and manipulation library for Python. It provides efficient data structures and data analysis tools for working with structured (tabular, multidimensional, potentially heterogeneous) and time series data.

4. **Scikit-learn**: Scikit-learn is one of the most popular and comprehensive machine learning libraries for Python. It features various classification, regression, clustering, dimensionality reduction, model selection, and preprocessing algorithms.

5. **TensorFlow**: TensorFlow is an open-source library developed by Google for numerical computation and machine learning. It provides a flexible and efficient framework for building and deploying machine learning models, including deep neural networks.

6. **PyTorch**: PyTorch is an open-source machine learning library primarily used for applications such as computer vision and natural language processing. It provides a flexible and intuitive way to build and train deep neural networks, with strong support for GPU acceleration.

7. **Numba**: Numba is a just-in-time (JIT) compiler for Python that translates a subset of Python and NumPy code into fast machine code, using the LLVM compiler infrastructure. It can significantly speed up numerical and scientific computing in Python.

8. **Dask**: Dask is a parallel computing library for Python that scales NumPy, Pandas, and other Python libraries to larger-than-memory or distributed datasets. It provides high-performance analytics on large datasets by breaking them into smaller chunks and processing them in parallel across multiple cores or machines.

9. **MPI4Py**: MPI4Py is a Python library that provides bindings to the Message Passing Interface (MPI) standard, allowing Python programs to run in parallel on distributed memory systems. It is widely used in high-performance computing applications.

10. **Horovod**: Horovod is a distributed deep learning training framework for TensorFlow, Keras, PyTorch, and Apache MXNet. It provides a way to scale out deep learning training across multiple GPUs or machines, with efficient communication and data transfer between them.

These are just a few examples of the state-of-the-art tools and frameworks available in Python for high-performance computing and machine learning. The Python ecosystem is continuously evolving, and new libraries and tools are being developed to further enhance the performance and capabilities of Python in these domains.

# 🩺🔍 Search Results
### 24 Aug 2022 | [OMB-Py: Python Micro-Benchmarks for Evaluating Performance of MPI  Libraries on HPC Systems](https://arxiv.org/abs/2110.10659) | [⬇️](https://arxiv.org/pdf/2110.10659)
*Nawras Alnaasan, Arpan Jain, Aamir Shafi, Hari Subramoni, and  Dhabaleswar K Panda* 

  Python has become a dominant programming language for emerging areas like
Machine Learning (ML), Deep Learning (DL), and Data Science (DS). An attractive
feature of Python is that it provides easy-to-use programming interface while
allowing library developers to enhance performance of their applications by
harnessing the computing power offered by High Performance Computing (HPC)
platforms. Efficient communication is key to scaling applications on parallel
systems, which is typically enabled by the Message Passing Interface (MPI)
standard and compliant libraries on HPC hardware. mpi4py is a Python-based
communication library that provides an MPI-like interface for Python
applications allowing application developers to utilize parallel processing
elements including GPUs. However, there is currently no benchmark suite to
evaluate communication performance of mpi4py -- and Python MPI codes in general
-- on modern HPC systems. In order to bridge this gap, we propose OMB-Py --
Python extensions to the open-source OSU Micro-Benchmark (OMB) suite -- aimed
to evaluate communication performance of MPI-based parallel applications in
Python. To the best of our knowledge, OMB-Py is the first communication
benchmark suite for parallel Python applications. OMB-Py consists of a variety
of point-to-point and collective communication benchmark tests that are
implemented for a range of popular Python libraries including NumPy, CuPy,
Numba, and PyCUDA. Our evaluation reveals that mpi4py introduces a small
overhead when compared to native MPI libraries. We plan to publicly release
OMB-Py to benefit the Python HPC community.

---------------

### 06 Oct 2022 | [hyperbox-brain: A Toolbox for Hyperbox-based Machine Learning Algorithms](https://arxiv.org/abs/2210.02704) | [⬇️](https://arxiv.org/pdf/2210.02704)
*Thanh Tung Khuat and Bogdan Gabrys* 

  Hyperbox-based machine learning algorithms are an important and popular
branch of machine learning in the construction of classifiers using fuzzy sets
and logic theory and neural network architectures. This type of learning is
characterised by many strong points of modern predictors such as a high
scalability, explainability, online adaptation, effective learning from a small
amount of data, native ability to deal with missing data and accommodating new
classes. Nevertheless, there is no comprehensive existing package for
hyperbox-based machine learning which can serve as a benchmark for research and
allow non-expert users to apply these algorithms easily. hyperbox-brain is an
open-source Python library implementing the leading hyperbox-based machine
learning algorithms. This library exposes a unified API which closely follows
and is compatible with the renowned scikit-learn and numpy toolboxes. The
library may be installed from Python Package Index (PyPI) and the conda package
manager and is distributed under the GPL-3 license. The source code,
documentation, detailed tutorials, and the full descriptions of the API are
available at https://uts-caslab.github.io/hyperbox-brain.

---------------

### 15 May 2023 | [Dragon-Alpha&cu32: A Java-based Tensor Computing Framework With its  High-Performance CUDA Library](https://arxiv.org/abs/2305.08819) | [⬇️](https://arxiv.org/pdf/2305.08819)
*Zhiyi Zhang, Pengfei Zhang, Qi Wang* 

  Java is very powerful, but in Deep Learning field, its capabilities probably
has not been sufficiently exploited. Compared to the Java-based
deep-learning-frameworks, the Python-based (PyTorch, TensorFlow, etc) are
undoubtedly the mainstream, due to their easy-to-use, flexibility and better
ecosystem. Dragon-Alpha is a Java-based Tensor Computing Framework, with
easy-to-use, high-scalability and high-performance, trying to break Java's
dilemma in deep learning field and make it more effective. Dragon-Alpha
supports different levels of APIs, and can be used as a deep-learning-framework
through its user-friendly high-level APIs. Dragon-Alpha has potential to
aggregate computing-power across heterogeneous platforms and devices, based on
its multi-layer architecture and Java's big-data ecosystem. Dragon-Alpha has
its asynchronized APIs to improve parallelism, and highly-optimized CUDA
library cu32 which adopts unique convolution\deconvolution operators for small
feature maps. The experiments show that, compared to PyTorch&cuDNN,
Dragon-Alpha&cu32 costs less time and memory (75.38% to 97.32%, 29.2% to
66.4%), to train some typical neural networks (AlexNet, VGG, GoogleNet, ResNet)
on Cifar-10.

---------------

### 03 Jun 2018 | [Deploying Customized Data Representation and Approximate Computing in  Machine Learning Applications](https://arxiv.org/abs/1806.00875) | [⬇️](https://arxiv.org/pdf/1806.00875)
*Mahdi Nazemi, Massoud Pedram* 

  Major advancements in building general-purpose and customized hardware have
been one of the key enablers of versatility and pervasiveness of machine
learning models such as deep neural networks. To sustain this ubiquitous
deployment of machine learning models and cope with their computational and
storage complexity, several solutions such as low-precision representation of
model parameters using fixed-point representation and deploying approximate
arithmetic operations have been employed. Studying the potency of such
solutions in different applications requires integrating them into existing
machine learning frameworks for high-level simulations as well as implementing
them in hardware to analyze their effects on power/energy dissipation,
throughput, and chip area. Lop is a library for design space exploration that
bridges the gap between machine learning and efficient hardware realization. It
comprises a Python module, which can be integrated with some of the existing
machine learning frameworks and implements various customizable data
representations including fixed-point and floating-point as well as approximate
arithmetic operations.Furthermore, it includes a highly-parameterized Scala
module, which allows synthesizing hardware based on the said data
representations and arithmetic operations. Lop allows researchers and designers
to quickly compare quality of their models using various data representations
and arithmetic operations in Python and contrast the hardware cost of viable
representations by synthesizing them on their target platforms (e.g., FPGA or
ASIC). To the best of our knowledge, Lop is the first library that allows both
software simulation and hardware realization using customized data
representations and approximate computing techniques.

---------------

### 08 Apr 2021 | [Kernel Operations on the GPU, with Autodiff, without Memory Overflows](https://arxiv.org/abs/2004.11127) | [⬇️](https://arxiv.org/pdf/2004.11127)
*Benjamin Charlier, Jean Feydy, Joan Alexis Glaun\`es,  Fran\c{c}ois-David Collin, Ghislain Durif* 

  The KeOps library provides a fast and memory-efficient GPU support for
tensors whose entries are given by a mathematical formula, such as kernel and
distance matrices. KeOps alleviates the major bottleneck of tensor-centric
libraries for kernel and geometric applications: memory consumption. It also
supports automatic differentiation and outperforms standard GPU baselines,
including PyTorch CUDA tensors or the Halide and TVM libraries. KeOps combines
optimized C++/CUDA schemes with binders for high-level languages: Python (Numpy
and PyTorch), Matlab and GNU R. As a result, high-level "quadratic" codes can
now scale up to large data sets with millions of samples processed in seconds.
KeOps brings graphics-like performances for kernel methods and is freely
available on standard repositories (PyPi, CRAN). To showcase its versatility,
we provide tutorials in a wide range of settings online at
\url{www.kernel-operations.io}.

---------------

### 07 Apr 2020 | [Geomstats: A Python Package for Riemannian Geometry in Machine Learning](https://arxiv.org/abs/2004.04667) | [⬇️](https://arxiv.org/pdf/2004.04667)
*Nina Miolane, Alice Le Brigant, Johan Mathe, Benjamin Hou, Nicolas  Guigui, Yann Thanwerdas, Stefan Heyder, Olivier Peltre, Niklas Koep, Hadi  Zaatiti, Hatem Hajri, Yann Cabanes, Thomas Gerald, Paul Chauchat, Christian  Shewmake, Bernhard Kainz, Claire Donnat, Susan Holmes, Xavier Pennec* 

  We introduce Geomstats, an open-source Python toolbox for computations and
statistics on nonlinear manifolds, such as hyperbolic spaces, spaces of
symmetric positive definite matrices, Lie groups of transformations, and many
more. We provide object-oriented and extensively unit-tested implementations.
Among others, manifolds come equipped with families of Riemannian metrics, with
associated exponential and logarithmic maps, geodesics and parallel transport.
Statistics and learning algorithms provide methods for estimation, clustering
and dimension reduction on manifolds. All associated operations are vectorized
for batch computation and provide support for different execution backends,
namely NumPy, PyTorch and TensorFlow, enabling GPU acceleration. This paper
presents the package, compares it with related libraries and provides relevant
code examples. We show that Geomstats provides reliable building blocks to
foster research in differential geometry and statistics, and to democratize the
use of Riemannian geometry in machine learning applications. The source code is
freely available under the MIT license at \url{geomstats.ai}.

---------------

### 16 Feb 2020 | [fastai: A Layered API for Deep Learning](https://arxiv.org/abs/2002.04688) | [⬇️](https://arxiv.org/pdf/2002.04688)
*Jeremy Howard and Sylvain Gugger* 

  fastai is a deep learning library which provides practitioners with
high-level components that can quickly and easily provide state-of-the-art
results in standard deep learning domains, and provides researchers with
low-level components that can be mixed and matched to build new approaches. It
aims to do both things without substantial compromises in ease of use,
flexibility, or performance. This is possible thanks to a carefully layered
architecture, which expresses common underlying patterns of many deep learning
and data processing techniques in terms of decoupled abstractions. These
abstractions can be expressed concisely and clearly by leveraging the dynamism
of the underlying Python language and the flexibility of the PyTorch library.
fastai includes: a new type dispatch system for Python along with a semantic
type hierarchy for tensors; a GPU-optimized computer vision library which can
be extended in pure Python; an optimizer which refactors out the common
functionality of modern optimizers into two basic pieces, allowing optimization
algorithms to be implemented in 4-5 lines of code; a novel 2-way callback
system that can access any part of the data, model, or optimizer and change it
at any point during training; a new data block API; and much more. We have used
this library to successfully create a complete deep learning course, which we
were able to write more quickly than using previous approaches, and the code
was more clear. The library is already in wide use in research, industry, and
teaching. NB: This paper covers fastai v2, which is currently in pre-release at
http://dev.fast.ai/

---------------

### 31 Oct 2022 | [The Open MatSci ML Toolkit: A Flexible Framework for Machine Learning in  Materials Science](https://arxiv.org/abs/2210.17484) | [⬇️](https://arxiv.org/pdf/2210.17484)
*Santiago Miret, Kin Long Kelvin Lee, Carmelo Gonzales, Marcel Nassar,  Matthew Spellings* 

  We present the Open MatSci ML Toolkit: a flexible, self-contained, and
scalable Python-based framework to apply deep learning models and methods on
scientific data with a specific focus on materials science and the OpenCatalyst
Dataset. Our toolkit provides: 1. A scalable machine learning workflow for
materials science leveraging PyTorch Lightning, which enables seamless scaling
across different computation capabilities (laptop, server, cluster) and
hardware platforms (CPU, GPU, XPU). 2. Deep Graph Library (DGL) support for
rapid graph neural network prototyping and development. By publishing and
sharing this toolkit with the research community via open-source release, we
hope to: 1. Lower the entry barrier for new machine learning researchers and
practitioners that want to get started with the OpenCatalyst dataset, which
presently comprises the largest computational materials science dataset. 2.
Enable the scientific community to apply advanced machine learning tools to
high-impact scientific challenges, such as modeling of materials behavior for
clean energy applications. We demonstrate the capabilities of our framework by
enabling three new equivariant neural network models for multiple OpenCatalyst
tasks and arrive at promising results for compute scaling and model
performance.

---------------

### 23 Oct 2023 | [Quantum Advantage Seeker with Kernels (QuASK): a software framework to  speed up the research in quantum machine learning](https://arxiv.org/abs/2206.15284) | [⬇️](https://arxiv.org/pdf/2206.15284)
*Francesco Di Marcantonio, Massimiliano Incudini, Davide Tezza and  Michele Grossi* 

  Exploiting the properties of quantum information to the benefit of machine
learning models is perhaps the most active field of research in quantum
computation. This interest has supported the development of a multitude of
software frameworks (e.g. Qiskit, Pennylane, Braket) to implement, simulate,
and execute quantum algorithms. Most of them allow us to define quantum
circuits, run basic quantum algorithms, and access low-level primitives
depending on the hardware such software is supposed to run. For most
experiments, these frameworks have to be manually integrated within a larger
machine learning software pipeline. The researcher is in charge of knowing
different software packages, integrating them through the development of long
code scripts, analyzing the results, and generating the plots. Long code often
leads to erroneous applications, due to the average number of bugs growing
proportional with respect to the program length. Moreover, other researchers
will struggle to understand and reproduce the experiment, due to the need to be
familiar with all the different software frameworks involved in the code
script. We propose QuASK, an open-source quantum machine learning framework
written in Python that aids the researcher in performing their experiments,
with particular attention to quantum kernel techniques. QuASK can be used as a
command-line tool to download datasets, pre-process them, quantum machine
learning routines, analyze and visualize the results. QuASK implements most
state-of-the-art algorithms to analyze the data through quantum kernels, with
the possibility to use projected kernels, (gradient-descent) trainable quantum
kernels, and structure-optimized quantum kernels. Our framework can also be
used as a library and integrated into pre-existing software, maximizing code
reuse.

---------------

### 25 Oct 2022 | [Comparing neural network training performance between Elixir and Python](https://arxiv.org/abs/2210.13945) | [⬇️](https://arxiv.org/pdf/2210.13945)
*Lucas C. Tavano, Lucas K. Amin, Adolfo Gustavo Serra-Seca-Neto* 

  With a wide range of libraries focused on the machine learning market, such
as TensorFlow, NumPy, Pandas, Keras, and others, Python has made a name for
itself as one of the main programming languages. In February 2021, Jos\'e Valim
and Sean Moriarity published the first version of the Numerical Elixir (Nx)
library, a library for tensor operations written in Elixir. Nx aims to allow
the language be a good choice for GPU-intensive operations. This work aims to
compare the results of Python and Elixir on training convolutional neural
networks (CNN) using MNIST and CIFAR-10 datasets, concluding that Python
achieved overall better results, and that Elixir is already a viable
alternative.

---------------

### 18 Aug 2022 | [NetKet 3: Machine Learning Toolbox for Many-Body Quantum Systems](https://arxiv.org/abs/2112.10526) | [⬇️](https://arxiv.org/pdf/2112.10526)
*Filippo Vicentini, Damian Hofmann, Attila Szab\'o, Dian Wu,  Christopher Roth, Clemens Giuliani, Gabriel Pescia, Jannes Nys, Vladimir  Vargas-Calderon, Nikita Astrakhantsev and Giuseppe Carleo* 

  We introduce version 3 of NetKet, the machine learning toolbox for many-body
quantum physics. NetKet is built around neural-network quantum states and
provides efficient algorithms for their evaluation and optimization. This new
version is built on top of JAX, a differentiable programming and accelerated
linear algebra framework for the Python programming language. The most
significant new feature is the possibility to define arbitrary neural network
ans\"atze in pure Python code using the concise notation of machine-learning
frameworks, which allows for just-in-time compilation as well as the implicit
generation of gradients thanks to automatic differentiation. NetKet 3 also
comes with support for GPU and TPU accelerators, advanced support for discrete
symmetry groups, chunking to scale up to thousands of degrees of freedom,
drivers for quantum dynamics applications, and improved modularity, allowing
users to use only parts of the toolbox as a foundation for their own code.

---------------

### 11 Jan 2019 | [Machine Learning Automation Toolbox (MLaut)](https://arxiv.org/abs/1901.03678) | [⬇️](https://arxiv.org/pdf/1901.03678)
*Viktor Kazakov and Franz J. Kir\'aly* 

  In this paper we present MLaut (Machine Learning AUtomation Toolbox) for the
python data science ecosystem. MLaut automates large-scale evaluation and
benchmarking of machine learning algorithms on a large number of datasets.
MLaut provides a high-level workflow interface to machine algorithm algorithms,
implements a local back-end to a database of dataset collections, trained
algorithms, and experimental results, and provides easy-to-use interfaces to
the scikit-learn and keras modelling libraries. Experiments are easy to set up
with default settings in a few lines of code, while remaining fully
customizable to the level of hyper-parameter tuning, pipeline composition, or
deep learning architecture.
  As a principal test case for MLaut, we conducted a large-scale supervised
classification study in order to benchmark the performance of a number of
machine learning algorithms - to our knowledge also the first larger-scale
study on standard supervised learning data sets to include deep learning
algorithms. While corroborating a number of previous findings in literature, we
found (within the limitations of our study) that deep neural networks do not
perform well on basic supervised learning, i.e., outside the more specialized,
image-, audio-, or text-based tasks.

---------------

### 06 Sep 2021 | [RDFFrames: Knowledge Graph Access for Machine Learning Tools](https://arxiv.org/abs/2002.03614) | [⬇️](https://arxiv.org/pdf/2002.03614)
*Aisha Mohamed, Ghadeer Abuoda, Abdurrahman Ghanem, Zoi Kaoudi, Ashraf  Aboulnaga* 

  Knowledge graphs represented as RDF datasets are integral to many machine
learning applications. RDF is supported by a rich ecosystem of data management
systems and tools, most notably RDF database systems that provide a SPARQL
query interface. Surprisingly, machine learning tools for knowledge graphs do
not use SPARQL, despite the obvious advantages of using a database system. This
is due to the mismatch between SPARQL and machine learning tools in terms of
data model and programming style. Machine learning tools work on data in
tabular format and process it using an imperative programming style, while
SPARQL is declarative and has as its basic operation matching graph patterns to
RDF triples. We posit that a good interface to knowledge graphs from a machine
learning software stack should use an imperative, navigational programming
paradigm based on graph traversal rather than the SPARQL query paradigm based
on graph patterns. In this paper, we present RDFFrames, a framework that
provides such an interface. RDFFrames provides an imperative Python API that
gets internally translated to SPARQL, and it is integrated with the PyData
machine learning software stack. RDFFrames enables the user to make a sequence
of Python calls to define the data to be extracted from a knowledge graph
stored in an RDF database system, and it translates these calls into a compact
SPQARL query, executes it on the database system, and returns the results in a
standard tabular format. Thus, RDFFrames is a useful tool for data preparation
that combines the usability of PyData with the flexibility and performance of
RDF database systems.

---------------

### 31 Oct 2023 | [MLatom 3: Platform for machine learning-enhanced computational chemistry  simulations and workflows](https://arxiv.org/abs/2310.20155) | [⬇️](https://arxiv.org/pdf/2310.20155)
*Pavlo O. Dral, Fuchun Ge, Yi-Fan Hou, Peikun Zheng, Yuxinxin Chen,  Mario Barbatti, Olexandr Isayev, Cheng Wang, Bao-Xin Xue, Max Pinheiro Jr,  Yuming Su, Yiheng Dai, Yangtao Chen, Lina Zhang, Shuang Zhang, Arif Ullah,  Quanhao Zhang, Yanchi Ou* 

  Machine learning (ML) is increasingly becoming a common tool in computational
chemistry. At the same time, the rapid development of ML methods requires a
flexible software framework for designing custom workflows. MLatom 3 is a
program package designed to leverage the power of ML to enhance typical
computational chemistry simulations and to create complex workflows. This
open-source package provides plenty of choice to the users who can run
simulations with the command line options, input files, or with scripts using
MLatom as a Python package, both on their computers and on the online XACS
cloud computing at XACScloud.com. Computational chemists can calculate energies
and thermochemical properties, optimize geometries, run molecular and quantum
dynamics, and simulate (ro)vibrational, one-photon UV/vis absorption, and
two-photon absorption spectra with ML, quantum mechanical, and combined models.
The users can choose from an extensive library of methods containing
pre-trained ML models and quantum mechanical approximations such as AIQM1
approaching coupled-cluster accuracy. The developers can build their own models
using various ML algorithms. The great flexibility of MLatom is largely due to
the extensive use of the interfaces to many state-of-the-art software packages
and libraries.

---------------

### 13 Aug 2021 | [Neko: a Library for Exploring Neuromorphic Learning Rules](https://arxiv.org/abs/2105.00324) | [⬇️](https://arxiv.org/pdf/2105.00324)
*Zixuan Zhao, Nathan Wycoff, Neil Getty, Rick Stevens, Fangfang Xia* 

  The field of neuromorphic computing is in a period of active exploration.
While many tools have been developed to simulate neuronal dynamics or convert
deep networks to spiking models, general software libraries for learning rules
remain underexplored. This is partly due to the diverse, challenging nature of
efforts to design new learning rules, which range from encoding methods to
gradient approximations, from population approaches that mimic the Bayesian
brain to constrained learning algorithms deployed on memristor crossbars. To
address this gap, we present Neko, a modular, extensible library with a focus
on aiding the design of new learning algorithms. We demonstrate the utility of
Neko in three exemplar cases: online local learning, probabilistic learning,
and analog on-device learning. Our results show that Neko can replicate the
state-of-the-art algorithms and, in one case, lead to significant
outperformance in accuracy and speed. Further, it offers tools including
gradient comparison that can help develop new algorithmic variants. Neko is an
open source Python library that supports PyTorch and TensorFlow backends.

---------------

### 09 May 2018 | [TensorLy: Tensor Learning in Python](https://arxiv.org/abs/1610.09555) | [⬇️](https://arxiv.org/pdf/1610.09555)
*Jean Kossaifi, Yannis Panagakis, Anima Anandkumar and Maja Pantic* 

  Tensors are higher-order extensions of matrices. While matrix methods form
the cornerstone of machine learning and data analysis, tensor methods have been
gaining increasing traction. However, software support for tensor operations is
not on the same footing. In order to bridge this gap, we have developed
\emph{TensorLy}, a high-level API for tensor methods and deep tensorized neural
networks in Python. TensorLy aims to follow the same standards adopted by the
main projects of the Python scientific community, and seamlessly integrates
with them. Its BSD license makes it suitable for both academic and commercial
applications. TensorLy's backend system allows users to perform computations
with NumPy, MXNet, PyTorch, TensorFlow and CuPy. They can be scaled on multiple
CPU or GPU machines. In addition, using the deep-learning frameworks as backend
allows users to easily design and train deep tensorized neural networks.
TensorLy is available at https://github.com/tensorly/tensorly

---------------

### 03 Dec 2019 | [PyTorch: An Imperative Style, High-Performance Deep Learning Library](https://arxiv.org/abs/1912.01703) | [⬇️](https://arxiv.org/pdf/1912.01703)
*Adam Paszke, Sam Gross, Francisco Massa, Adam Lerer, James Bradbury,  Gregory Chanan, Trevor Killeen, Zeming Lin, Natalia Gimelshein, Luca Antiga,  Alban Desmaison, Andreas K\"opf, Edward Yang, Zach DeVito, Martin Raison,  Alykhan Tejani, Sasank Chilamkurthy, Benoit Steiner, Lu Fang, Junjie Bai,  Soumith Chintala* 

  Deep learning frameworks have often focused on either usability or speed, but
not both. PyTorch is a machine learning library that shows that these two goals
are in fact compatible: it provides an imperative and Pythonic programming
style that supports code as a model, makes debugging easy and is consistent
with other popular scientific computing libraries, while remaining efficient
and supporting hardware accelerators such as GPUs.
  In this paper, we detail the principles that drove the implementation of
PyTorch and how they are reflected in its architecture. We emphasize that every
aspect of PyTorch is a regular Python program under the full control of its
user. We also explain how the careful and pragmatic implementation of the key
components of its runtime enables them to work together to achieve compelling
performance.
  We demonstrate the efficiency of individual subsystems, as well as the
overall speed of PyTorch on several common benchmarks.

---------------

### 30 Jul 2023 | [RoseNNa: A performant, portable library for neural network inference  with application to computational fluid dynamics](https://arxiv.org/abs/2307.16322) | [⬇️](https://arxiv.org/pdf/2307.16322)
*Ajay Bati, Spencer H. Bryngelson* 

  The rise of neural network-based machine learning ushered in high-level
libraries, including TensorFlow and PyTorch, to support their functionality.
Computational fluid dynamics (CFD) researchers have benefited from this trend
and produced powerful neural networks that promise shorter simulation times.
For example, multilayer perceptrons (MLPs) and Long Short Term Memory (LSTM)
recurrent-based (RNN) architectures can represent sub-grid physical effects,
like turbulence. Implementing neural networks in CFD solvers is challenging
because the programming languages used for machine learning and CFD are mostly
non-overlapping, We present the roseNNa library, which bridges the gap between
neural network inference and CFD. RoseNNa is a non-invasive, lightweight (1000
lines), and performant tool for neural network inference, with focus on the
smaller networks used to augment PDE solvers, like those of CFD, which are
typically written in C/C++ or Fortran. RoseNNa accomplishes this by
automatically converting trained models from typical neural network training
packages into a high-performance Fortran library with C and Fortran APIs. This
reduces the effort needed to access trained neural networks and maintains
performance in the PDE solvers that CFD researchers build and rely upon.
Results show that RoseNNa reliably outperforms PyTorch (Python) and libtorch
(C++) on MLPs and LSTM RNNs with less than 100 hidden layers and 100 neurons
per layer, even after removing the overhead cost of API calls. Speedups range
from a factor of about 10 and 2 faster than these established libraries for the
smaller and larger ends of the neural network size ranges tested.

---------------

### 10 Dec 2018 | [BindsNET: A machine learning-oriented spiking neural networks library in  Python](https://arxiv.org/abs/1806.01423) | [⬇️](https://arxiv.org/pdf/1806.01423)
*Hananel Hazan and Daniel J. Saunders and Hassaan Khan and Darpan T.  Sanghavi and Hava T. Siegelmann and Robert Kozma* 

  The development of spiking neural network simulation software is a critical
component enabling the modeling of neural systems and the development of
biologically inspired algorithms. Existing software frameworks support a wide
range of neural functionality, software abstraction levels, and hardware
devices, yet are typically not suitable for rapid prototyping or application to
problems in the domain of machine learning. In this paper, we describe a new
Python package for the simulation of spiking neural networks, specifically
geared towards machine learning and reinforcement learning. Our software,
called BindsNET, enables rapid building and simulation of spiking networks and
features user-friendly, concise syntax. BindsNET is built on top of the PyTorch
deep neural networks library, enabling fast CPU and GPU computation for large
spiking networks. The BindsNET framework can be adjusted to meet the needs of
other existing computing and hardware environments, e.g., TensorFlow. We also
provide an interface into the OpenAI gym library, allowing for training and
evaluation of spiking networks on reinforcement learning problems. We argue
that this package facilitates the use of spiking networks for large-scale
machine learning experimentation, and show some simple examples of how we
envision BindsNET can be used in practice. BindsNET code is available at
https://github.com/Hananel-Hazan/bindsnet

---------------

### 13 Oct 2023 | [pose-format: Library for Viewing, Augmenting, and Handling .pose Files](https://arxiv.org/abs/2310.09066) | [⬇️](https://arxiv.org/pdf/2310.09066)
*Amit Moryossef, Mathias M\"uller, Rebecka Fahrni* 

  Managing and analyzing pose data is a complex task, with challenges ranging
from handling diverse file structures and data types to facilitating effective
data manipulations such as normalization and augmentation. This paper presents
\texttt{pose-format}, a comprehensive toolkit designed to address these
challenges by providing a unified, flexible, and easy-to-use interface. The
library includes a specialized file format that encapsulates various types of
pose data, accommodating multiple individuals and an indefinite number of time
frames, thus proving its utility for both image and video data. Furthermore, it
offers seamless integration with popular numerical libraries such as NumPy,
PyTorch, and TensorFlow, thereby enabling robust machine-learning applications.
Through benchmarking, we demonstrate that our \texttt{.pose} file format offers
vastly superior performance against prevalent formats like OpenPose, with added
advantages like self-contained pose specification. Additionally, the library
includes features for data normalization, augmentation, and easy-to-use
visualization capabilities, both in Python and Browser environments.
\texttt{pose-format} emerges as a one-stop solution, streamlining the
complexities of pose data management and analysis.

---------------