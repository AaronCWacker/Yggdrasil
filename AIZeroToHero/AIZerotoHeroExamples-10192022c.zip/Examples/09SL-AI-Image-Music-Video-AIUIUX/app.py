import streamlit as st      
import gradio as gr
import IPython
import streamlit as st
import streamlit.components.v1 as components
from IPython.display import IFrame

src=''   # URL parameter to change the iframe url
def SetIframeURL(option_selected):
    if (option_selected=='Collager'):
        src='https://www.artbreeder.com/'
    if (option_selected=='Midjourney'):
        src='https://www.midjourney.com/'
    if (option_selected=='DreamStudio'):
        src='https://beta.dreamstudio.ai/'
    if (option_selected=='NightCafe'):
        src='https://creator.nightcafe.studio/'
    if (option_selected=='RunwayML'):
        src='https://app.runwayml.com/'
    if (option_selected=='ArtFromTextandImages'):
        src='https://huggingface.co/spaces/awacke1/Art-from-Text-and-Images'   
    if (option_selected=='Boomy'):
        src='https://boomy.com/'   
    
    width = st.sidebar.slider("Width", 200, 1500, 800, 100)
    height = st.sidebar.slider("Height", 200, 1500, 900, 100)
    st.components.v1.iframe(src, width, height, scrolling=True)

try:
    options = ['Midjourney', 'RunwayML', 'Boomy']
    query_params = st.experimental_get_query_params()
    query_option = query_params['option'][0] #throws an exception when visiting http://host:port
    option_selected = st.sidebar.selectbox('Pick option', options, index=options.index(query_option))
    if option_selected:
        st.experimental_set_query_params(option=option_selected)
        SetIframeURL(option_selected)
except: 
    options = ['Midjourney', 'RunwayML', 'Boomy']
    st.experimental_set_query_params(option=options[1]) # defaults to 1
    query_params = st.experimental_get_query_params()
    query_option = query_params['option'][0]
    option_selected = st.sidebar.selectbox('Pick option', options, index=options.index(query_option))
    if option_selected:
        st.experimental_set_query_params(option=option_selected)
        SetIframeURL(option_selected)